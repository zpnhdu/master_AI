import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  testMatch: "backend-entry.spec.ts",
  fullyParallel: true,
  reporter: "list",
  use: {
    baseURL: "http://127.0.0.1:8890",
    trace: "retain-on-failure",
    ...devices["Desktop Chrome"],
  },
  webServer: {
    command: `pnpm build && cd .. && test_db_path="$(mktemp /tmp/ai-hr-v1-playwright.XXXXXX)" && trap 'rm -f "$test_db_path"' EXIT && export FRONTEND_APP_ENABLED=1 TESTING=1 DB_PATH="$test_db_path" PYTHONPATH=. && venv/bin/python -c 'from app import db; db.init_db(); db._migrate(); db.create_monitor_tables()' && venv/bin/uvicorn app.main:app --host 127.0.0.1 --port=8890`,
    reuseExistingServer: false,
    timeout: 120_000,
    url: "http://127.0.0.1:8890/login",
  },
});
