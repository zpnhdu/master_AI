import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  testMatch: ["smoke.spec.ts", "pages-smoke.spec.ts", "full-pipeline.spec.ts", "responsive.spec.ts"],
  fullyParallel: true,
  reporter: "list",
  use: {
    baseURL: "http://127.0.0.1:5173",
    trace: "retain-on-failure",
    ...devices["Desktop Chrome"],
  },
  webServer: {
    command: "pnpm exec vite --host=127.0.0.1 --port=5173",
    reuseExistingServer: true,
    timeout: 120_000,
    url: "http://127.0.0.1:5173/",
  },
});
