import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

const defaultBackendOrigin = "http://127.0.0.1:8888";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "VITE_");
  const backendOrigin = env.VITE_BACKEND_ORIGIN || defaultBackendOrigin;

  return {
    plugins: [react()],
    server: {
      proxy: {
        "/api": {
          target: backendOrigin,
          changeOrigin: true,
        },
        "/ws": {
          target: backendOrigin,
          changeOrigin: true,
          ws: true,
        },
      },
    },
    build: {
      outDir: "dist",
      target: "es2022",
      sourcemap: false,
      cssCodeSplit: true,
      rolldownOptions: {
        output: {
          codeSplitting: {
            groups: [
              {
                name: "echarts",
                test: /node_modules[\\/]echarts[\\/]/,
                priority: 20,
              },
              {
                name: "d3",
                test: /node_modules[\\/]d3-[^\\/]+[\\/]/,
                priority: 20,
              },
              {
                name: "query",
                test: /node_modules[\\/]@tanstack[\\/]react-query[\\/]/,
                priority: 10,
              },
            ],
          },
        },
      },
    },
  };
});
