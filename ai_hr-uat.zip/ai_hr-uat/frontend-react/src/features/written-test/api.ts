import { ApiError, requestWithTimeout } from "../pipelines/api";

const runtimeClientIds = new Map<string, string>();

function clientId(token: string) {
  const key = `written-test-client:${token}`;
  const runtime = runtimeClientIds.get(token);
  if (runtime) return runtime;
  let existing = "";
  try {
    existing = window.sessionStorage.getItem(key) || "";
  } catch {
    /* storage unavailable */
  }
  if (existing) return existing;
  const value = `${crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`}`;
  runtimeClientIds.set(token, value);
  try {
    window.sessionStorage.setItem(key, value);
  } catch {
    /* storage unavailable */
  }
  return value;
}

function leaseHeaders(token: string) {
  return { "X-Session-Client-Id": clientId(token) };
}

export async function claimWrittenTestSession(token: string) {
  const response = await fetch(`/api/written-test/session/${encodeURIComponent(token)}/claim`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
  });
  if (!response.ok)
    throw new ApiError(await responseMessage(response, "该考试已在其他设备或窗口答题"), { status: response.status });
  return response.json() as Promise<{ status: string; lease_expires_at: string }>;
}

export function heartbeatWrittenTestSession(token: string) {
  return fetch(`/api/written-test/session/${encodeURIComponent(token)}/heartbeat`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
  });
}

export function releaseWrittenTestSession(token: string) {
  return fetch(`/api/written-test/session/${encodeURIComponent(token)}/release`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
    keepalive: true,
  });
}

export type WrittenTestQuestion = {
  id?: string;
  type?: string;
  question?: string;
  difficulty?: string;
  time_limit_seconds?: number;
  answer_mode?: string;
};

export type WrittenTestSession = {
  candidate_name: string;
  role: string;
  company_name: string;
  company_logo?: string;
  questions: WrittenTestQuestion[];
  time_limit_minutes: number;
  camera_optional: boolean;
  expires_at: string;
};

export type WrittenTestAnswer = {
  question_index: number;
  answer_text: string;
};

export type WrittenTestSessionResult =
  | { kind: "ok"; session: WrittenTestSession }
  | { kind: "expired"; message: string }
  | { kind: "submitted"; message: string }
  | { kind: "error"; message: string };

type ErrorPayload = { detail?: string; message?: string };

async function responseMessage(response: Response, fallback: string) {
  const payload = (await response.json().catch(() => ({}))) as ErrorPayload;
  return payload.detail || payload.message || fallback;
}

export async function fetchWrittenTestSession(token: string): Promise<WrittenTestSessionResult> {
  try {
    return await requestWithTimeout(
      `/api/written-test/session/${encodeURIComponent(token)}`,
      { credentials: "include", headers: leaseHeaders(token) },
      async (response) => {
        if (response.status === 410) {
          const data = (await response.json().catch(() => ({}))) as ErrorPayload & {
            candidate_name?: string;
            role?: string;
            expires_at?: string;
          };
          return { kind: "expired", message: data.message || "笔试链接已过期" };
        }
        if (!response.ok) {
          throw new ApiError(await responseMessage(response, "笔试链接无效或已过期"), { status: response.status });
        }
        const payload = (await response.json()) as WrittenTestSession | (ErrorPayload & { error?: string });
        if ("error" in payload && payload.error === "expired") {
          return { kind: "expired", message: payload.message || "笔试链接已过期" };
        }
        if ("error" in payload && payload.error === "already_submitted") {
          return { kind: "submitted", message: payload.message || "您已提交答案，无需重复作答" };
        }
        if (!("questions" in payload) || !Array.isArray(payload.questions)) {
          return { kind: "error", message: "笔试数据格式无效，请联系招聘人员" };
        }
        return { kind: "ok", session: payload };
      },
    );
  } catch (error) {
    return { kind: "error", message: error instanceof Error ? error.message : "网络错误，请刷新后重试" };
  }
}

export async function submitWrittenTestAnswers(token: string, answers: WrittenTestAnswer[]) {
  return requestWithTimeout(
    `/api/written-test/session/${encodeURIComponent(token)}/submit`,
    {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json", ...leaseHeaders(token) },
      body: JSON.stringify({ answers }),
    },
    async (response) => {
      if (!response.ok)
        throw new ApiError(await responseMessage(response, "答案提交失败"), { status: response.status });
      return response.json() as Promise<{ status: string; message?: string; score?: number | null }>;
    },
  );
}

export async function transcribeWrittenAnswer(token: string, questionIndex: number, audio: Blob) {
  const formData = new FormData();
  formData.append("file", audio, `answer-q${questionIndex + 1}.webm`);
  formData.append("question_index", String(questionIndex));
  const payload = await requestWithTimeout(
    `/api/written-test/session/${encodeURIComponent(token)}/transcribe`,
    { method: "POST", credentials: "include", headers: leaseHeaders(token), body: formData },
    async (response) => {
      if (!response.ok)
        throw new ApiError(await responseMessage(response, "语音转写失败"), { status: response.status });
      return (await response.json()) as { transcript?: string };
    },
  );
  const transcript = payload.transcript?.trim() ?? "";
  if (!transcript || transcript.startsWith("[转写失败")) throw new Error(transcript || "没有识别到语音内容");
  return transcript;
}

export async function uploadWrittenTestVideo(token: string, video: Blob) {
  const prepared = await prepareDirectUpload(token, video);
  if (!prepared) return uploadWrittenTestVideoViaBackend(token, video);

  await uploadBlobToOss(prepared, video);
  return completeDirectUpload(token, prepared);
}

type DirectUploadPrepareResponse = {
  upload_url: string;
  method: "POST";
  fields: Record<string, string>;
  object_key: string;
  upload_token: string;
  expires_at: number;
  max_size_bytes: number;
};

async function prepareDirectUpload(token: string, blob: Blob): Promise<DirectUploadPrepareResponse | null> {
  const resp = await fetch(`/api/written-test/session/${encodeURIComponent(token)}/video-upload/prepare`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...leaseHeaders(token) },
    body: JSON.stringify({
      filename: "written-test.webm",
      content_type: blob.type || "video/webm",
      size_bytes: blob.size,
    }),
    credentials: "include",
  });

  // 404 支持滚动发布期间后端尚无新接口；503 表示 OSS 未配置，回退到后端流式上传。
  if (resp.status === 404 || resp.status === 503) return null;
  if (!resp.ok) throw new Error(await responseMessage(resp, "申请 OSS 上传凭证失败"));
  return (await resp.json()) as DirectUploadPrepareResponse;
}

function uploadBlobToOss(prepared: DirectUploadPrepareResponse, blob: Blob): Promise<void> {
  const formData = new FormData();
  for (const [key, value] of Object.entries(prepared.fields)) formData.append(key, value);
  // OSS 表单上传要求 file 字段放在其他策略字段之后。
  formData.append("file", blob, "written-test.webm");

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.timeout = 30 * 60 * 1000;
    xhr.ontimeout = () => reject(new Error("OSS 上传超时，请切换稳定网络后重试"));
    xhr.onerror = () => reject(new Error("无法连接 OSS，请检查网络及 Bucket CORS 配置"));
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
        return;
      }
      reject(new Error(`OSS 上传失败 (HTTP ${xhr.status})`));
    };
    xhr.open(prepared.method, prepared.upload_url);
    xhr.send(formData);
  });
}

async function completeDirectUpload(
  token: string,
  prepared: DirectUploadPrepareResponse,
): Promise<{ status: string; object_key?: string }> {
  let lastError: Error | null = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const resp = await fetch(`/api/written-test/session/${encodeURIComponent(token)}/video-upload/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...leaseHeaders(token) },
        body: JSON.stringify({
          object_key: prepared.object_key,
          upload_token: prepared.upload_token,
        }),
        credentials: "include",
      });
      if (!resp.ok) throw new Error(await responseMessage(resp, "确认上传失败"));
      return (await resp.json()) as { status: string; object_key?: string };
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("确认上传失败");
    }
  }
  throw lastError || new Error("确认上传失败");
}

async function uploadWrittenTestVideoViaBackend(
  token: string,
  video: Blob,
): Promise<{ status: string; filename?: string }> {
  const formData = new FormData();
  formData.append("file", video, "written-test.webm");
  return requestWithTimeout(
    `/api/written-test/session/${encodeURIComponent(token)}/upload-video`,
    { method: "POST", credentials: "include", headers: leaseHeaders(token), body: formData },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await responseMessage(response, "答题录像上传失败"), { status: response.status });
      }
      return response.json() as Promise<{ status: string; filename?: string }>;
    },
  );
}
