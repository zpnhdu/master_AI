import { afterEach, describe, expect, it, vi } from "vitest";

import {
  fetchWrittenTestSession,
  submitWrittenTestAnswers,
  transcribeWrittenAnswer,
  uploadWrittenTestVideo,
} from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

class FakeXMLHttpRequest {
  static instances: FakeXMLHttpRequest[] = [];

  status = 204;
  timeout = 0;
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  ontimeout: (() => void) | null = null;
  method = "";
  url = "";
  body: Document | XMLHttpRequestBodyInit | null = null;

  constructor() {
    FakeXMLHttpRequest.instances.push(this);
  }

  open(method: string, url: string) {
    this.method = method;
    this.url = url;
  }

  send(body: Document | XMLHttpRequestBodyInit | null) {
    this.body = body;
    queueMicrotask(() => this.onload?.());
  }
}

describe("written-test api", () => {
  it("loads a valid candidate session without requiring authentication", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      response({
        candidate_name: "张三",
        role: "店长",
        company_name: "锅圈食汇",
        questions: [{ id: "q1", question: "如何提升门店销售？" }],
        time_limit_minutes: 90,
        camera_optional: true,
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchWrittenTestSession("token 1")).resolves.toMatchObject({
      kind: "ok",
      session: { candidate_name: "张三", questions: [{ id: "q1" }] },
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/written-test/session/token%201",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
  });

  it("maps expired and already submitted sessions to terminal states", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(response({ error: "expired", message: "面试链接已过期" }))
      .mockResolvedValueOnce(response({ error: "already_submitted", message: "您已提交答案，无需重复作答" }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchWrittenTestSession("expired")).resolves.toEqual({
      kind: "expired",
      message: "面试链接已过期",
    });
    await expect(fetchWrittenTestSession("submitted")).resolves.toEqual({
      kind: "submitted",
      message: "您已提交答案，无需重复作答",
    });
  });

  it("submits answers using the written-test protocol", async () => {
    const fetchMock = vi.fn().mockResolvedValue(response({ status: "submitted", message: "提交成功" }));
    vi.stubGlobal("fetch", fetchMock);

    await submitWrittenTestAnswers("token-1", [{ question_index: 0, answer_text: "我的回答" }]);

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/written-test/session/token-1/submit",
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        body: JSON.stringify({ answers: [{ question_index: 0, answer_text: "我的回答" }] }),
      }),
    );
  });

  it("falls back to backend video upload when OSS direct upload is unavailable", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(response({ status: "ok", transcript: "语音回答" }))
      .mockResolvedValueOnce(response({ detail: { code: "oss_direct_upload_unavailable" } }, 503))
      .mockResolvedValueOnce(response({ status: "uploaded", filename: "camera.webm" }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(transcribeWrittenAnswer("token-1", 2, new Blob(["voice"]))).resolves.toBe("语音回答");
    await expect(uploadWrittenTestVideo("token-1", new Blob(["video"]))).resolves.toMatchObject({
      status: "uploaded",
    });

    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "/api/written-test/session/token-1/transcribe",
      expect.objectContaining({ method: "POST", body: expect.any(FormData), credentials: "include" }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/written-test/session/token-1/video-upload/prepare",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      3,
      "/api/written-test/session/token-1/upload-video",
      expect.objectContaining({ method: "POST", body: expect.any(FormData), credentials: "include" }),
    );
  });

  it("uploads video to OSS and confirms the object", async () => {
    FakeXMLHttpRequest.instances = [];
    vi.stubGlobal("XMLHttpRequest", FakeXMLHttpRequest as unknown as typeof XMLHttpRequest);
    const prepared = {
      upload_url: "https://bucket.oss-cn-hangzhou.aliyuncs.com",
      method: "POST" as const,
      fields: { key: "interviews/p1/c1/full_interview.webm", policy: "policy" },
      object_key: "interviews/p1/c1/full_interview.webm",
      upload_token: "upload-token",
      expires_at: 9999999999,
      max_size_bytes: 1024 * 1024,
    };
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(response(prepared))
      .mockResolvedValueOnce(response({ status: "uploaded", object_key: prepared.object_key }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(uploadWrittenTestVideo("token-1", new Blob(["video"], { type: "video/webm" }))).resolves.toMatchObject(
      {
        status: "uploaded",
        object_key: prepared.object_key,
      },
    );

    expect(FakeXMLHttpRequest.instances).toHaveLength(1);
    expect(FakeXMLHttpRequest.instances[0].method).toBe("POST");
    expect(FakeXMLHttpRequest.instances[0].url).toBe(prepared.upload_url);
    expect(FakeXMLHttpRequest.instances[0].body).toBeInstanceOf(FormData);
    expect((FakeXMLHttpRequest.instances[0].body as FormData).get("key")).toBe(prepared.object_key);
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/written-test/session/token-1/video-upload/complete",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
  });
});
