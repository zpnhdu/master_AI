import { ApiError, requestWithTimeout } from "../pipelines/api";

export type AgentPipelineStage = {
  stage_id: string;
  status: string;
  output: Record<string, unknown>;
};

export type AgentCandidate = {
  id: string;
  name?: string;
  email?: string;
  phone?: string;
  resume_text?: string;
  overall_score?: number;
  status?: string;
  [key: string]: unknown;
};

export type AgentPipeline = {
  id: string;
  role: string;
  status?: string;
  agents: string[];
  stages: AgentPipelineStage[];
  candidates: AgentCandidate[];
  [key: string]: unknown;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asRecord(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {};
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function parseJson(value: unknown): Record<string, unknown> {
  if (isRecord(value)) return value;
  if (typeof value !== "string" || !value.trim()) return {};
  try {
    const parsed: unknown = JSON.parse(value);
    return isRecord(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

export function normalizeAgentPipeline(value: unknown): AgentPipeline | null {
  if (!isRecord(value)) return null;
  const stages = Array.isArray(value.stages)
    ? value.stages.flatMap((stage) => {
        if (!isRecord(stage)) return [];
        return [
          {
            stage_id: asString(stage.stage_id),
            status: asString(stage.status, "pending"),
            output: parseJson(stage.output),
          },
        ];
      })
    : [];
  const candidates = Array.isArray(value.candidates)
    ? value.candidates.flatMap((candidate) => {
        if (!isRecord(candidate)) return [];
        const id = asString(candidate.id ?? candidate.candidate_id);
        return id ? [{ ...candidate, id }] : [];
      })
    : [];
  return {
    ...value,
    id: asString(value.id ?? value.pipeline_id),
    role: asString(value.role, "未命名岗位"),
    agents: Array.isArray(value.agents) ? value.agents.filter((item): item is string => typeof item === "string") : [],
    stages,
    candidates,
  };
}

async function parseResponse<T>(response: Response, fallback: string): Promise<T> {
  const payload: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = isRecord(payload) && typeof payload.detail === "string" ? payload.detail : fallback;
    // 面向用户展示服务端返回的具体原因，不把 HTTP 状态码（如 429/502）
    // 当成错误文案的一部分。
    throw new ApiError(detail, { status: response.status, data: payload });
  }
  return payload as T;
}

export async function requestJson<T>(
  url: string,
  init: RequestInit = {},
  fallback = "请求失败",
  timeoutMs?: number,
): Promise<T> {
  return requestWithTimeout(
    url,
    { ...init, credentials: "include" },
    (response) => parseResponse<T>(response, fallback),
    timeoutMs,
  );
}

export async function fetchAgentPipeline(pipelineId: string): Promise<AgentPipeline> {
  const payload = await requestJson<unknown>(`/api/pipelines/${encodeURIComponent(pipelineId)}`, {}, "岗位加载失败");
  const pipeline = normalizeAgentPipeline(payload);
  if (!pipeline) throw new ApiError("岗位数据格式无效");
  return pipeline;
}

export function fetchCandidateResume(pipelineId: string, candidateId: string) {
  return requestJson<AgentCandidate>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/candidates/${encodeURIComponent(candidateId)}/resume`,
    {},
    "简历详情加载失败",
  );
}

export async function passAgentArtifact(pipelineId: string, fromAgent: string, artifacts: Record<string, unknown>) {
  return requestJson<{ success: boolean; from_agent?: string; to_agent?: string; to_name?: string }>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/pass-artifact`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ from_agent: fromAgent, to_agent: "next", artifacts }),
    },
    "传递产物失败",
  );
}

export function stageOutput(pipeline: AgentPipeline, stageId: string): Record<string, any> {
  return asRecord(pipeline.stages.find((stage) => stage.stage_id === stageId)?.output);
}
