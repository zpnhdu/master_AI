import { Tag } from 'antd';

import type { AgentId } from '../../../shared/agent-config';
import { AGENT_CONFIG, STAGE_NAMES } from '../../../shared/agent-config';
import type { AgentPipeline, AgentPipelineStage } from '../api';

type AgentArtifactsPanelProps = {
  agentId: AgentId;
  pipeline: AgentPipeline;
  sources?: {
    poolImported?: number;
    fileUploaded?: number;
    talentPoolImported?: number;
    localUploaded?: number;
    talentPool?: number;
    localUpload?: number;
  };
  showStages?: boolean;
  candidateHeading?: string;
  ariaLabel?: string;
  onCandidateSelect?: (candidate: AgentPipeline['candidates'][number]) => void;
  selectedCandidateId?: string;
};

const STATUS_LABELS: Record<string, string> = {
  done: '已完成',
  running: '进行中',
  pending: '待开始',
};

const STAGE_ICONS: Record<string, string> = {
  jd_write: '文',
  profile_build: '像',
  poster_gen: '海',
  crawl: '寻',
  match: '筛',
  interview_gen: '面',
  report: '评',
};

export function AgentArtifactsPanel({
  agentId,
  pipeline,
  sources,
  showStages = true,
  candidateHeading = '候选人',
  ariaLabel = '阶段产出与候选人',
  onCandidateSelect,
  selectedCandidateId,
}: AgentArtifactsPanelProps) {
  const agent = AGENT_CONFIG[agentId];
  const stages = pipeline.stages.length
    ? pipeline.stages
    : agent.stages.map((stageId) => ({ stage_id: stageId, status: 'pending', output: {} }));

  return (
    <aside className="xun-artifacts-pane" aria-label={ariaLabel}>
      {showStages ? (
        <>
          <div className="xun-pane-heading">
            <strong>阶段产出</strong>
            <span>{agent.name}</span>
          </div>
          <div>
            {stages.map((stage) => (
              <StageSummary key={stage.stage_id} stage={stage} />
            ))}
          </div>
        </>
      ) : null}

      {sources ? (
        <>
          <div className="xun-pane-heading">
            <strong>候选人来源</strong>
            <span>{pipeline.candidates.length} 人</span>
          </div>
          <div className="xun-source-summary">
            <SourceSummary
              label="人才库导入"
              value={sources.poolImported ?? sources.talentPoolImported ?? sources.talentPool ?? 0}
              color="green"
            />
            <SourceSummary
              label="本地上传"
              value={sources.fileUploaded ?? sources.localUploaded ?? sources.localUpload ?? 0}
              color="blue"
            />
          </div>
        </>
      ) : null}

      <div className="xun-pane-heading">
        <strong>{candidateHeading}</strong>
        <span>{pipeline.candidates.length} 人</span>
      </div>
      <div className="xun-candidate-list">
        {pipeline.candidates.length ? (
          pipeline.candidates.map((candidate) => (
            <button
              className={`xun-candidate-summary${selectedCandidateId === candidate.id ? ' selected' : ''}`}
              key={candidate.id}
              type="button"
              disabled={!onCandidateSelect}
              aria-label={`查看${String(candidate.name || '未知候选人')}简历`}
              onClick={() => onCandidateSelect?.(candidate)}
            >
              <div className="xun-candidate-avatar">{String(candidate.name || '候').slice(0, 1)}</div>
              <div>
                <strong>{String(candidate.name || '未知候选人')}</strong>
                <span>{candidateMeta(candidate)}</span>
              </div>
            </button>
          ))
        ) : (
          <div className="xun-empty-copy">暂无候选人</div>
        )}
      </div>
    </aside>
  );
}

function SourceSummary({ label, value, color }: { label: string; value: number; color: string }) {
  return <div className={`xun-source-row ${color}`}><span>{label}</span><strong>{value}</strong></div>;
}

function StageSummary({ stage }: { stage: AgentPipelineStage }) {
  const status = STATUS_LABELS[stage.status] || stage.status || '待开始';
  const tagColor = stage.status === 'done' ? 'success' : stage.status === 'running' ? 'processing' : 'default';
  return (
    <div className={`xun-source-row${stage.status === 'running' ? ' active' : ''}`}>
      <span className="xun-stage-icon" aria-hidden="true">
        {STAGE_ICONS[stage.stage_id] || '·'}
      </span>
      <div className="xun-stage-copy">
        <strong>{STAGE_NAMES[stage.stage_id] || stage.stage_id}</strong>
        <span>{stageSummary(stage.output)}</span>
      </div>
      <Tag color={tagColor}>{status}</Tag>
    </div>
  );
}

function stageSummary(output: Record<string, unknown>) {
  const jd = output.jd;
  if (jd && typeof jd === 'object' && !Array.isArray(jd)) {
    const title = 'title' in jd && jd.title ? String(jd.title) : 'JD 已生成';
    return title;
  }
  if (typeof output.resume_count === 'number') return `${output.resume_count} 份简历`;
  if (typeof output.pass_count === 'number') return `通过 ${output.pass_count} 人`;
  if (Array.isArray(output.interviews)) return `${output.interviews.length} 人面试题`;
  if (output.report && typeof output.report === 'object') return '评估报告已生成';
  return Object.keys(output).length ? '数据已产出' : '等待处理';
}

function candidateMeta(candidate: AgentPipeline['candidates'][number]) {
  const values = [candidate.title, candidate.current_position, candidate.location]
    .filter((value) => typeof value === 'string' && value.trim())
    .map(String);
  return values.join(' · ') || '等待解析详情';
}
