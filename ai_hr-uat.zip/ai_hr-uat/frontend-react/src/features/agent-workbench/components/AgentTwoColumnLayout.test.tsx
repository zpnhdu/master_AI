import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { AgentTwoColumnLayout } from './AgentTwoColumnLayout';

describe('AgentTwoColumnLayout', () => {
  it('renders the aside and content slots with a shared layout contract', () => {
    render(
      <AgentTwoColumnLayout asideLabel="批量操作" asideWidth="wide" aside={<div>操作区</div>}>
        <div>主工作区</div>
      </AgentTwoColumnLayout>,
    );

    expect(screen.getByLabelText('批量操作')).toHaveClass('agent-two-column-layout__aside');
    expect(screen.getByText('操作区')).toBeInTheDocument();
    expect(screen.getByText('主工作区')).toBeInTheDocument();
    expect(document.querySelector('.agent-two-column-layout--wide')).toBeInTheDocument();
  });
});
