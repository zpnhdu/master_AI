import type { ReactNode } from 'react';

type AgentTwoColumnLayoutProps = {
  aside: ReactNode;
  asideLabel: string;
  children: ReactNode;
  asideWidth?: 'compact' | 'wide';
  className?: string;
  contentClassName?: string;
  contentLabel?: string;
};

export function AgentTwoColumnLayout({
  aside,
  asideLabel,
  children,
  asideWidth = 'compact',
  className = '',
  contentClassName = '',
  contentLabel,
}: AgentTwoColumnLayoutProps) {
  const layoutClassName = ['agent-two-column-layout', `agent-two-column-layout--${asideWidth}`, className]
    .filter(Boolean)
    .join(' ');
  const contentClasses = ['agent-two-column-layout__content', contentClassName].filter(Boolean).join(' ');

  return (
    <main className={layoutClassName}>
      <div className="agent-two-column-layout__aside" role="region" aria-label={asideLabel}>
        {aside}
      </div>
      <section className={contentClasses} aria-label={contentLabel}>
        {children}
      </section>
    </main>
  );
}
