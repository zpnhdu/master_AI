import { requestJson } from "../agent-workbench/api";

export type RoleStageConfig = {
  model?: string;
  complexity?: string;
  temperature?: number;
  timeout?: number;
  retry_count?: number;
  enabled?: boolean;
  human_approval?: boolean;
  [key: string]: unknown;
};

export type RoleStage = {
  stage_id: string;
  config: RoleStageConfig;
  [key: string]: unknown;
};

export type RoleDetail = {
  role_id: string;
  name: string;
  display_name: string;
  description?: string;
  icon?: string;
  enabled?: boolean;
  stages: RoleStage[];
  [key: string]: unknown;
};

export type AgentStat = {
  agent_id: string;
  total_calls?: number;
  success_count?: number;
  total_tokens?: number;
  avg_duration_ms?: number;
  [key: string]: unknown;
};

export type AgentRecentCall = {
  agent_id?: string;
  status?: string;
  duration_ms?: number;
  tokens_used?: number;
  created_at?: string;
  [key: string]: unknown;
};

export type AgentStatsResponse = {
  stats?: AgentStat[];
  recent_calls?: AgentRecentCall[];
  [key: string]: unknown;
};

export type AgentTestResult = {
  status?: string;
  data?: unknown;
  error?: string;
  tokens_used?: number;
  duration_ms?: number;
  [key: string]: unknown;
};

export function fetchRoleDetail(roleId: string) {
  return requestJson<RoleDetail>(`/api/roles/${encodeURIComponent(roleId)}`, {}, "角色信息加载失败");
}

export function fetchAgentStats() {
  return requestJson<AgentStatsResponse>("/api/agents/stats", {}, "Agent 统计加载失败");
}

export function saveAgentConfig(stageId: string, config: Partial<RoleStageConfig>) {
  return requestJson<{ status: string; agent_id: string }>(
    `/api/agents/${encodeURIComponent(stageId)}/config`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config),
    },
    "保存配置失败",
  );
}

export function testAgent(stageId: string, params: Record<string, unknown>) {
  return requestJson<AgentTestResult>(
    `/api/agents/${encodeURIComponent(stageId)}/test`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pipeline_id: "test", params }),
    },
    "测试运行失败",
  );
}
