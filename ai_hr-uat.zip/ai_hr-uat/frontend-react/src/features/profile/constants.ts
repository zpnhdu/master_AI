/** 候选人画像 22 维标签与分组，与 frontend/shared.js 的 DIM_LABELS / PROFILE_GROUPS 保持一致。 */

export const DIM_LABELS: Record<string, string> = {
  location: "工作地点",
  salary_expectation: "薪资期望",
  availability: "到岗时间",
  work_mode: "工作模式",
  degree: "学历要求",
  school_tier: "学校层次",
  major: "专业方向",
  certifications: "相关证书",
  years: "工作年限",
  industry: "行业背景",
  company_tier: "公司背景",
  role_progression: "职级路径",
  project_scale: "项目规模",
  tech_stack: "技术栈",
  soft_skills: "软技能",
  language: "语言能力",
  domain_expertise: "领域专长",
  leadership_experience: "管理经验",
  work_style: "工作风格",
  team_size_preference: "团队规模",
  growth_orientation: "成长导向",
  values: "价值观",
};

export type ProfileGroup = {
  key: string;
  name: string;
  icon: string;
  color: string;
  keys: string[];
};

export const PROFILE_GROUPS: ProfileGroup[] = [
  {
    key: "basic",
    name: "基础信息",
    icon: "📋",
    color: "#2563eb",
    keys: ["location", "salary_expectation", "availability", "work_mode"],
  },
  {
    key: "education",
    name: "教育背景",
    icon: "🎓",
    color: "#10b981",
    keys: ["degree", "school_tier", "major", "certifications"],
  },
  {
    key: "experience",
    name: "经验要求",
    icon: "💼",
    color: "#f59e0b",
    keys: ["years", "industry", "company_tier", "role_progression", "project_scale"],
  },
  {
    key: "skills",
    name: "技能要求",
    icon: "🛠️",
    color: "#8b5cf6",
    keys: ["tech_stack", "soft_skills", "language", "domain_expertise", "leadership_experience"],
  },
  {
    key: "culture",
    name: "文化匹配",
    icon: "🎯",
    color: "#ec4899",
    keys: ["work_style", "team_size_preference", "growth_orientation", "values"],
  },
];

/** 把后端 recommended 值格式化为可读文本（对齐旧版 profile.html 逻辑）。 */
export function formatRecommended(value: unknown): string {
  if (Array.isArray(value)) return value.join(", ");
  if (typeof value === "object" && value !== null) {
    const record = value as Record<string, unknown>;
    if (record.min !== undefined && record.max !== undefined) return `${record.min}-${record.max}年`;
    return JSON.stringify(value);
  }
  return String(value || "-");
}
