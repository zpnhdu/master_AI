import { fetchAgentPipeline, requestJson, type AgentPipeline } from "../agent-workbench/api";

export type ProfileDimension = {
  weight?: number;
  recommended?: unknown;
  reasoning?: string;
  [key: string]: unknown;
};

export type CandidateProfile = {
  dimensions: Record<string, ProfileDimension>;
  role?: string;
  [key: string]: unknown;
};

export type ProfileResponse = {
  profile: CandidateProfile;
  pipeline_id: string;
};

export function fetchCandidateProfile(pipelineId: string) {
  return requestJson<ProfileResponse>(`/api/profile/${encodeURIComponent(pipelineId)}`, {}, "候选人画像加载失败");
}

export function fetchProfilePipeline(pipelineId: string): Promise<AgentPipeline> {
  return fetchAgentPipeline(pipelineId);
}
