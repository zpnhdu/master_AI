import { afterEach, describe, expect, it, vi } from "vitest";

import {
  completePipeline,
  fetchCandidateReports,
  fetchLatestAggregateReportJob,
  generateCandidateReports,
  startAggregateReportJob,
} from "./api";

describe("candidate assessment report api", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it("loads and batch-generates candidate reports", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ pipeline_id: "p/1", reports: [] }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await fetchCandidateReports("p/1");
    await generateCandidateReports("p/1", ["c1", "c2"], true);

    expect(fetchMock.mock.calls[0][0]).toBe("/api/assessment-flow/p%2F1/reports");
    expect(fetchMock.mock.calls[1][0]).toBe("/api/assessment-flow/p%2F1/reports/generate");
    expect(fetchMock.mock.calls[1][1]).toEqual(
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        body: JSON.stringify({ candidate_ids: ["c1", "c2"], force: true }),
      }),
    );
  });

  it("starts and reads an aggregate AI report background job", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ job: { id: "job-1", status: "queued" } }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await startAggregateReportJob("pipeline-1");
    await fetchLatestAggregateReportJob("pipeline-1");

    expect(fetchMock.mock.calls[0][0]).toBe("/api/assessment-flow/pipeline-1/aggregate-report/jobs");
    expect(JSON.parse(String(fetchMock.mock.calls[0][1]?.body))).toEqual({ passed_only: true });
    expect(fetchMock.mock.calls[1][0]).toBe("/api/assessment-flow/pipeline-1/aggregate-report/jobs/latest");
  });

  it("confirms the report and closes the pipeline through the completion endpoint", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ status: "completed", pipeline_id: "p/1" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(completePipeline("p/1")).resolves.toEqual({ status: "completed", pipeline_id: "p/1" });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p%2F1/complete",
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        body: JSON.stringify({ actor_id: "hr" }),
      }),
    );
  });
});
