import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import type { AggregateReportJob, CandidateReportsResponse } from "./api";
import {
  completePipeline,
  fetchAssessmentQueue,
  fetchCandidateReports,
  fetchLatestAggregateReportJob,
  generateCandidateReports,
  reviewAssessmentCandidate,
  startAggregateReportJob,
} from "./api";

export const xiaoPingKeys = {
  queue: (id: string) => ["xiao-ping", "queue", id] as const,
  reports: (id: string) => ["xiao-ping", "candidate-reports", id] as const,
  aggregateReportJob: (id: string) => ["xiao-ping", "aggregate-report-job", id] as const,
};
export function useAssessmentQueueQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoPingKeys.queue(pipelineId),
    queryFn: () => fetchAssessmentQueue(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
    refetchInterval: 5000,
    refetchIntervalInBackground: false,
  });
}
export function useReviewAssessmentMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      candidateId,
      body,
    }: {
      candidateId: string;
      body: Parameters<typeof reviewAssessmentCandidate>[2];
    }) => reviewAssessmentCandidate(pipelineId, candidateId, body),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: xiaoPingKeys.queue(pipelineId) }),
        queryClient.invalidateQueries({ queryKey: xiaoPingKeys.reports(pipelineId) }),
      ]);
    },
  });
}
export function useAggregateReportJobQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoPingKeys.aggregateReportJob(pipelineId),
    queryFn: () => fetchLatestAggregateReportJob(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
    refetchInterval: (query) =>
      query.state.data?.status === "queued" || query.state.data?.status === "running" ? 2000 : false,
  });
}
export function useStartAggregateReportJobMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation<AggregateReportJob, Error>({
    mutationFn: () => startAggregateReportJob(pipelineId),
    onSuccess: (job) => queryClient.setQueryData(xiaoPingKeys.aggregateReportJob(pipelineId), job),
  });
}
export function useCandidateReportsQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoPingKeys.reports(pipelineId),
    queryFn: () => fetchCandidateReports(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
    refetchInterval: (query) => (query.state.data?.generating_candidate_ids?.length ? 3000 : false),
  });
}
export function useGenerateCandidateReportsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation<CandidateReportsResponse, Error, { candidateIds: string[]; force?: boolean }>({
    mutationFn: ({ candidateIds, force = false }) => generateCandidateReports(pipelineId, candidateIds, force),
    onSuccess: (data) =>
      queryClient.setQueryData<CandidateReportsResponse>(xiaoPingKeys.reports(pipelineId), (current) => {
        const generatedIds = new Set(data.reports.map((item) => item.candidate_id));
        const reports = [
          ...data.reports,
          ...(current?.reports ?? []).filter((item) => !generatedIds.has(item.candidate_id)),
        ];
        return { ...data, reports, total: reports.length };
      }),
  });
}
export function useCompletePipelineMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => completePipeline(pipelineId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["xiao-ping", "pipeline", pipelineId] }),
  });
}
