import type { AssessmentQueue, AssessmentQueueItem, CandidateAssessmentReport, ReportData } from "./api";

export type AssessmentCriterionAnalysis = {
  id: string;
  name: string;
  level?: number;
  score?: number;
  confidence?: number;
  evidence: string;
};

export type AssessmentQuestionAnalysis = {
  key: string;
  modality: string;
  questionIndex: number;
  question: string;
  answer: string;
  score?: number;
  reviewRequired: boolean;
  technicalFailure: boolean;
  failureReason: string;
  comment: string;
  candidateFeedback: string;
  hitPoints: string[];
  missedPoints: string[];
  criteria: AssessmentCriterionAnalysis[];
};

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : {};
}

function records(value: unknown): Record<string, unknown>[] {
  return Array.isArray(value) ? value.map(record) : [];
}

function strings(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String).filter(Boolean) : [];
}

function finiteNumber(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function criteria(value: unknown): AssessmentCriterionAnalysis[] {
  return records(value).map((item, index) => ({
    id: String(item.id ?? index),
    name: String(item.name ?? item.id ?? `评分项 ${index + 1}`),
    level: finiteNumber(item.level),
    score: finiteNumber(item.score),
    confidence: finiteNumber(item.confidence),
    evidence: String(item.evidence ?? ""),
  }));
}

function videoCriteria(evaluation: Record<string, unknown>, answer: Record<string, unknown>, questionIndex: number) {
  const direct = criteria(answer.criteria);
  if (direct.length) return direct;

  for (const details of Object.values(record(evaluation.dim_detail))) {
    const detail = records(details).find((item) => finiteNumber(item.question_index) === questionIndex);
    if (!detail) continue;
    const fallback = criteria(detail.criteria);
    if (fallback.length) return fallback;
  }
  return [];
}

function scoredPointNames(
  value: unknown,
  criterionRows: AssessmentCriterionAnalysis[],
  predicate: (level: number) => boolean,
) {
  const direct = strings(value);
  if (direct.length || !criterionRows.length) return direct;
  return criterionRows.filter((item) => item.level !== undefined && predicate(item.level)).map((item) => item.name);
}

export function decisionScore(candidate: AssessmentQueueItem) {
  return Number(candidate.final_score ?? candidate.overall_score ?? candidate.score ?? 0) || 0;
}

export type DecisionOutcome = "通过" | "淘汰";

export const PASSING_SCORE = 60;

/** 小评只按正式决策分二分：60 分及以上通过，低于 60 分淘汰。 */
export function decisionOutcome(candidate: AssessmentQueueItem): DecisionOutcome {
  return decisionScore(candidate) >= PASSING_SCORE ? "通过" : "淘汰";
}

export function decisionScoreSource(candidate?: AssessmentQueueItem | null) {
  const source = candidate?.decision_score_source;
  if (source === "video_interview") return "视频面试";
  if (source === "written_test") return "在线笔试";
  if (source === "manual_interview") return "人工面试";
  return "评估结果";
}

export function decisionCandidates(queue: AssessmentQueue) {
  return [...(queue.ready_for_decision ?? [])].sort((left, right) => decisionScore(right) - decisionScore(left));
}

export function candidateReportActionLabel(report?: Pick<CandidateAssessmentReport, "is_stale">) {
  if (!report) return "报告生成中";
  return report.is_stale ? "重新生成报告" : "查看报告";
}

export function assessmentReviewTarget(candidate?: AssessmentQueueItem | null) {
  const entries = Object.entries(candidate?.step_results ?? {});
  const blockers = new Set(candidate?.blockers ?? []);
  const selected =
    entries.find(([stepId]) => blockers.has(stepId)) ??
    entries.find(
      ([, result]) =>
        result.review_status === "pending" ||
        result.scoring_status === "failed" ||
        result.execution_status === "failed",
    ) ??
    entries[0];
  const [stepId = "", result = {}] = selected ?? [];
  const score = typeof result.score === "number" ? result.score : undefined;
  const evaluation = record(record(result.evidence).evaluation);
  const failedQuestions = Array.isArray(evaluation.failed_questions)
    ? evaluation.failed_questions
        .map((item) => (typeof item === "object" && item ? Number(record(item).question_index) : Number(item)))
        .filter(Number.isFinite)
    : [];

  return {
    stepId,
    modality: result.modality ?? "manual_interview",
    score,
    scoringStatus: result.scoring_status ?? "",
    resultStatus: result.result_status ?? "",
    scoreStatus: String(evaluation.score_status ?? ""),
    provisionalScore: finiteNumber(evaluation.provisional_score),
    failedQuestions,
    scoredQuestionCount: finiteNumber(evaluation.scored_question_count),
    totalQuestionCount: finiteNumber(evaluation.total_question_count),
    scoreCoverageRatio: finiteNumber(evaluation.score_coverage_ratio),
    requiresOverride: result.scoring_status !== "succeeded" || score === undefined,
  };
}

export function assessmentQuestionAnalyses(candidate?: AssessmentQueueItem | null): AssessmentQuestionAnalysis[] {
  const output: AssessmentQuestionAnalysis[] = [];
  for (const [stepId, step] of Object.entries(candidate?.step_results ?? {})) {
    const evidence = record(step.evidence);
    const questions = records(evidence.questions);
    const answers = records(evidence.answers);
    const evaluation = record(evidence.evaluation);
    const modality = step.modality ?? "";

    if (modality === "written_test") {
      for (const [position, detail] of records(evaluation.detail).entries()) {
        const questionIndex = finiteNumber(detail.question_index) ?? position;
        const question = record(questions[questionIndex]);
        const answer = answers.find((item) => item.question_index === questionIndex) ?? record(answers[questionIndex]);
        output.push({
          key: `${stepId}-${questionIndex}`,
          modality,
          questionIndex,
          question: String(question.question ?? answer.question ?? `第 ${questionIndex + 1} 题`),
          answer: String(answer.answer ?? answer.answer_text ?? ""),
          score: finiteNumber(detail.score),
          reviewRequired: Boolean(
            !detail.technical_failure &&
            (detail.scoring_failed || detail.asr_failed || finiteNumber(detail.score) === undefined),
          ),
          technicalFailure: Boolean(detail.technical_failure),
          failureReason: String(detail.failure_reason ?? ""),
          comment: String(detail.comment ?? ""),
          candidateFeedback: String(detail.candidate_feedback ?? ""),
          hitPoints: strings(detail.hit_points),
          missedPoints: strings(detail.missed_points),
          criteria: criteria(detail.criteria),
        });
      }
      continue;
    }

    if (modality === "video_interview") {
      for (const [position, answer] of answers.entries()) {
        const questionIndex = finiteNumber(answer.question_index) ?? position;
        const question = record(questions[questionIndex]);
        const criterionRows = videoCriteria(evaluation, answer, questionIndex);
        output.push({
          key: `${stepId}-${questionIndex}`,
          modality,
          questionIndex,
          question: String(answer.question ?? question.question ?? `第 ${questionIndex + 1} 题`),
          answer: String(answer.answer ?? answer.transcript ?? ""),
          score: finiteNumber(answer.score),
          reviewRequired: Boolean(
            !answer.technical_failure &&
            (answer.scoring_failed || answer.asr_failed || finiteNumber(answer.score) === undefined),
          ),
          technicalFailure: Boolean(answer.technical_failure),
          failureReason: String(answer.failure_reason ?? ""),
          comment: String(answer.comment ?? ""),
          candidateFeedback: String(answer.candidate_feedback ?? ""),
          hitPoints: scoredPointNames(answer.hit_points, criterionRows, (level) => level >= 3),
          missedPoints: scoredPointNames(answer.missed_points, criterionRows, (level) => level <= 1),
          criteria: criterionRows,
        });
      }
    }
  }
  const modalityPriority = (modality: string) =>
    modality === "video_interview" ? 0 : modality === "written_test" ? 1 : 2;
  return output.sort(
    (left, right) =>
      modalityPriority(left.modality) - modalityPriority(right.modality) || left.questionIndex - right.questionIndex,
  );
}

export function reportGroups(queue: AssessmentQueue) {
  const candidates = decisionCandidates(queue);
  return {
    pass: candidates.filter((item) => decisionOutcome(item) === "通过"),
    eliminate: candidates.filter((item) => decisionOutcome(item) === "淘汰"),
  };
}

export function fallbackReport(queue: AssessmentQueue): ReportData | null {
  const candidates = decisionCandidates(queue);
  if (!candidates.length) return null;
  return { ...reportGroups(queue), ranking: candidates };
}
