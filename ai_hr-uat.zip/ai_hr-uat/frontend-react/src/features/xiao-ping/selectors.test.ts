import { describe, expect, it } from "vitest";

import type { AssessmentQueue } from "./api";
import {
  candidateReportActionLabel,
  assessmentQuestionAnalyses,
  assessmentReviewTarget,
  decisionCandidates,
  decisionOutcome,
  decisionScoreSource,
  reportGroups,
} from "./selectors";

describe("xiao-ping selectors", () => {
  it("shows generate, regenerate, and view labels from report freshness", () => {
    expect(candidateReportActionLabel()).toBe("报告生成中");
    expect(candidateReportActionLabel({ is_stale: true })).toBe("重新生成报告");
    expect(candidateReportActionLabel({ is_stale: false })).toBe("查看报告");
  });
  it("ranks ready candidates and groups fallback decisions", () => {
    const queue: AssessmentQueue = {
      ready_for_decision: [
        { candidate_id: "c1", candidate_name: "王芳", overall_score: 66 },
        { candidate_id: "c2", candidate_name: "李明", overall_score: 92 },
        { candidate_id: "c3", candidate_name: "赵强", overall_score: 48 },
      ],
      incomplete: [],
      counts: { ready_for_decision: 3, incomplete: 0 },
    };

    expect(decisionCandidates(queue).map((item) => item.candidate_id)).toEqual(["c2", "c1", "c3"]);
    expect(reportGroups(queue).pass.map((item) => item.candidate_id)).toEqual(["c2", "c1"]);
    expect(reportGroups(queue).eliminate.map((item) => item.candidate_id)).toEqual(["c3"]);
  });

  it("uses a strict 60-point pass threshold regardless of legacy recommendation text", () => {
    expect(decisionOutcome({ candidate_id: "a", overall_score: 60, recommendation: "不推荐" })).toBe("通过");
    expect(decisionOutcome({ candidate_id: "b", overall_score: 59, recommendation: "强烈推荐录用" })).toBe("淘汰");
  });

  it("labels the selected decision score source", () => {
    expect(decisionScoreSource({ candidate_id: "c1", decision_score_source: "video_interview" })).toBe("视频面试");
    expect(decisionScoreSource({ candidate_id: "c2", decision_score_source: "written_test" })).toBe("在线笔试");
  });

  it("selects the blocked assessment step for manual review", () => {
    const target = assessmentReviewTarget({
      candidate_id: "c-review",
      blockers: ["video-step"],
      step_results: {
        written: { modality: "written_test", scoring_status: "succeeded", score: 82 },
        "video-step": { modality: "video_interview", scoring_status: "failed", score: null },
      },
    });

    expect(target).toMatchObject({
      stepId: "video-step",
      modality: "video_interview",
      requiresOverride: true,
    });
  });

  it("allows a reason-only review when the existing score succeeded", () => {
    const target = assessmentReviewTarget({
      candidate_id: "c-red-flag",
      blockers: ["written"],
      step_results: {
        written: {
          modality: "written_test",
          scoring_status: "succeeded",
          review_status: "pending",
          score: 76,
        },
      },
    });

    expect(target).toMatchObject({ modality: "written_test", score: 76, requiresOverride: false });
  });

  it("extracts provisional video score progress for manual review", () => {
    const target = assessmentReviewTarget({
      candidate_id: "c-provisional",
      blockers: ["video"],
      step_results: {
        video: {
          modality: "video_interview",
          scoring_status: "failed",
          review_status: "pending",
          score: 80,
          evidence: {
            evaluation: {
              score_status: "provisional",
              provisional_score: 80,
              failed_questions: [1],
              scored_question_count: 3,
              total_question_count: 4,
              score_coverage_ratio: 0.75,
            },
          },
        },
      },
    });

    expect(target).toMatchObject({
      scoreStatus: "provisional",
      provisionalScore: 80,
      failedQuestions: [1],
      scoredQuestionCount: 3,
      totalQuestionCount: 4,
      scoreCoverageRatio: 0.75,
      requiresOverride: true,
    });
  });

  it("normalizes written-test question analyses from assessment evidence", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "written-candidate",
      step_results: {
        written: {
          modality: "written_test",
          evidence: {
            questions: [{ question: "如何落地方案？" }],
            answers: [{ question_index: 0, answer: "分阶段落地。" }],
            evaluation: {
              detail: [
                {
                  question_index: 0,
                  score: 75,
                  comment: "方案结构清晰。",
                  candidate_feedback: "补充风险预案。",
                  hit_points: ["实施步骤"],
                  criteria: [{ id: "feasibility", name: "可执行性", score: 75, evidence: "给出了步骤" }],
                },
              ],
            },
          },
        },
      },
    });

    expect(analyses[0]).toMatchObject({
      modality: "written_test",
      question: "如何落地方案？",
      answer: "分阶段落地。",
      score: 75,
      comment: "方案结构清晰。",
      candidateFeedback: "补充风险预案。",
      hitPoints: ["实施步骤"],
    });
  });

  it("normalizes video-interview question analyses from assessment evidence", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "video-candidate",
      step_results: {
        video: {
          modality: "video_interview",
          evidence: {
            questions: [{ question: "介绍一次项目经历" }],
            answers: [
              {
                question_index: 0,
                answer: "我负责项目上线。",
                score: 88,
                comment: "回答有完整案例。",
                missed_points: ["量化结果"],
              },
            ],
          },
        },
      },
    });

    expect(analyses[0]).toMatchObject({
      modality: "video_interview",
      question: "介绍一次项目经历",
      answer: "我负责项目上线。",
      score: 88,
      comment: "回答有完整案例。",
      missedPoints: ["量化结果"],
    });
  });

  it("uses video criterion evidence from the final evaluation when legacy answers omit it", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "legacy-video-candidate",
      step_results: {
        video: {
          modality: "video_interview",
          evidence: {
            questions: [{ question: "介绍一次项目经历" }],
            answers: [{ question_index: 0, answer: "我负责项目上线" }],
            evaluation: {
              dim_detail: {
                综合表现: [
                  {
                    question_index: 0,
                    criteria: [
                      { id: "coverage", name: "岗位要点匹配", level: 1, score: 25, evidence: "未说明职责" },
                      { id: "accuracy", name: "专业准确性", level: 3, score: 75, evidence: "说明上线方案" },
                    ],
                  },
                ],
              },
            },
          },
        },
      },
    });

    expect(analyses[0].criteria).toHaveLength(2);
    expect(analyses[0].missedPoints).toEqual(["岗位要点匹配"]);
    expect(analyses[0].hitPoints).toEqual(["专业准确性"]);
  });

  it("shows video analyses before written-test supplements", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "combined-candidate",
      step_results: {
        written: {
          modality: "written_test",
          evidence: {
            questions: [{ question: "笔试题" }],
            answers: [{ question_index: 0, answer: "笔试回答" }],
            evaluation: { detail: [{ question_index: 0, score: 80 }] },
          },
        },
        video: {
          modality: "video_interview",
          evidence: {
            questions: [{ question: "视频题" }],
            answers: [{ question_index: 0, answer: "视频回答", score: 88 }],
          },
        },
      },
    });

    expect(analyses.map((item) => item.modality)).toEqual(["video_interview", "written_test"]);
  });

  it("marks a failed video question for manual review while retaining other scores", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "partial-video",
      step_results: {
        video: {
          modality: "video_interview",
          evidence: {
            questions: [{ question: "成功题" }, { question: "失败题" }],
            answers: [
              { question_index: 0, answer: "有效回答", score: 82 },
              { question_index: 1, answer: "[语音识别未完成]", score: null, scoring_failed: true, asr_failed: true },
            ],
          },
        },
      },
    });

    expect(analyses[0]).toMatchObject({ questionIndex: 0, score: 82, reviewRequired: false });
    expect(analyses[1]).toMatchObject({ questionIndex: 1, score: undefined, reviewRequired: true });
  });

  it("shows a technical scoring failure as a zero score instead of a review blocker", () => {
    const analyses = assessmentQuestionAnalyses({
      candidate_id: "technical-zero",
      step_results: {
        written: {
          modality: "written_test",
          evidence: {
            questions: [{ question: "异常题" }],
            answers: [{ question_index: 0, answer: "已提交作答" }],
            evaluation: {
              detail: [
                {
                  question_index: 0,
                  score: 0,
                  technical_failure: true,
                  failure_reason: "AI 评分服务异常",
                },
              ],
            },
          },
        },
      },
    });

    expect(analyses[0]).toMatchObject({
      score: 0,
      technicalFailure: true,
      failureReason: "AI 评分服务异常",
      reviewRequired: false,
    });
  });
});
