import { requestJson } from "../agent-workbench/api";

export type AssessmentQueueItem = {
  candidate_id: string;
  candidate_name?: string;
  overall_score?: number;
  decision_score_source?: "video_interview" | "written_test" | "manual_interview" | string;
  final_score?: number;
  tech_score?: number;
  experience_score?: number;
  education_score?: number;
  blockers?: string[];
  next_actions?: Array<{ name?: string; modality?: string }>;
  step_results?: Record<
    string,
    {
      modality?: string;
      execution_status?: string;
      scoring_status?: string;
      review_status?: string;
      result_status?: string;
      score?: number | null;
      evidence?: Record<string, unknown>;
    }
  >;
  recommendation?: string;
  [key: string]: unknown;
};

export type AssessmentQueue = {
  plan?: {
    config?: {
      name?: string;
      selection_policy?: string;
      steps?: Array<{ modality?: string }>;
    };
  };
  ready_for_decision: AssessmentQueueItem[];
  incomplete: AssessmentQueueItem[];
  closed_incomplete?: AssessmentQueueItem[];
  counts: { ready_for_decision: number; incomplete: number; closed_incomplete?: number };
};

export type ReportData = {
  executive_summary?: string;
  recommend?: AssessmentQueueItem[];
  consider?: AssessmentQueueItem[];
  reject?: AssessmentQueueItem[];
  ranking?: AssessmentQueueItem[];
  team_fit_analysis?: string;
  market_insights?: string;
  risk_assessment?: string;
  comparison_matrix?: unknown;
  next_steps?: unknown[];
  salary_recommendations?: unknown;
  [key: string]: unknown;
};

export type AggregateReportJob = {
  id: string;
  pipeline_id: string;
  status: "queued" | "running" | "succeeded" | "failed";
  passed_only: boolean;
  progress: number;
  result?: { report?: ReportData; report_data?: ReportData; message?: string; reply?: string };
  message?: string;
  error_code?: string;
  error_message?: string;
  created_at?: string;
  started_at?: string;
  completed_at?: string;
};

export type CandidateQuestionReport = {
  evidence_ref: string;
  modality: string;
  modality_label: string;
  question_index: number;
  question: string;
  score?: number | null;
  review_required: boolean;
  technical_failure?: boolean;
  failure_reason?: string;
  hit_points: string[];
  missed_points: string[];
  key_evidence?: string;
};

export type CandidateAssessmentReport = {
  candidate_id: string;
  candidate_name: string;
  role?: string;
  report_status: string;
  queue_status: string;
  is_formal: boolean;
  score?: number | null;
  score_status: "final" | "provisional" | "unavailable" | string;
  score_source_label: string;
  recommendation: string;
  dimensions: Record<string, number>;
  strengths: string[];
  risks: string[];
  questions: CandidateQuestionReport[];
  comprehensive_evaluation: string;
  hiring_advice: string;
  evidence_hash?: string;
  is_stale?: boolean;
  generated_at?: string;
};

export type CandidateReportsResponse = {
  pipeline_id: string;
  reports: CandidateAssessmentReport[];
  generating_candidate_ids?: string[];
  counts?: { total: number; formal: number; draft: number };
  total?: number;
};

export async function fetchAssessmentQueue(pipelineId: string) {
  return requestJson<AssessmentQueue>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/queue`,
    {},
    "评估队列加载失败",
  );
}

export function reviewAssessmentCandidate(
  pipelineId: string,
  candidateId: string,
  body: { modality: string; reason: string; actor_id: string; override_score?: number },
) {
  return requestJson<unknown>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/candidates/${encodeURIComponent(candidateId)}/review`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
    "人工复核失败",
  );
}

export async function startAggregateReportJob(pipelineId: string) {
  const response = await requestJson<{ job: AggregateReportJob }>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/aggregate-report/jobs`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ passed_only: true }),
    },
    "综合评估报告任务启动失败",
  );
  return response.job;
}

export async function fetchLatestAggregateReportJob(pipelineId: string) {
  const response = await requestJson<{ job: AggregateReportJob | null }>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/aggregate-report/jobs/latest`,
    {},
    "综合评估报告任务状态加载失败",
  );
  return response.job;
}

export function fetchCandidateReports(pipelineId: string) {
  return requestJson<CandidateReportsResponse>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/reports`,
    {},
    "候选人评估报告加载失败",
  );
}

export function generateCandidateReports(pipelineId: string, candidateIds: string[], force = false) {
  return requestJson<CandidateReportsResponse>(
    `/api/assessment-flow/${encodeURIComponent(pipelineId)}/reports/generate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ candidate_ids: candidateIds, force }),
    },
    "候选人评估报告生成失败",
  );
}

export function completePipeline(pipelineId: string) {
  return requestJson<{ status: string; pipeline_id: string }>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/complete`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ actor_id: "hr" }),
    },
    "岗位完成失败",
  );
}
