import { afterEach, describe, expect, it, vi } from "vitest";

import { ApiError, NETWORK_SAFETY_TIMEOUT_MS } from "../pipelines/api";
import {
  approveJd,
  cloneJdPipeline,
  fetchJdWorkspace,
  generateJdDraft,
  passArtifactToDownstream,
  readErrorCode,
  reviseJdPreview,
  runProfileBuild,
  saveJdDraft,
  transcribeAudio,
} from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

function mockJsonResponse(payload: unknown, init: { ok?: boolean; status?: number } = {}) {
  return {
    ok: init.ok ?? true,
    status: init.status ?? 200,
    json: async () => payload,
  };
}

describe("xiao-wen api", () => {
  it("normalizes the workspace payload including array-form profile dimensions", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        pipeline_id: "p1",
        role: "店长",
        jd_locked: true,
        jd_locked_at: "2026-08-26T10:00:00Z",
        jd_locked_by_stage: "xiao_hai",
        cloned_from_pipeline_id: "p0",
        jd: { title: "店长", responsibilities: "负责门店运营" },
        quality_checks: [{ field: "title", label: "岗位名称", status: "ready", message: "已填写" }, "garbage"],
        profile: {
          dimensions: [
            { name: "years", score: "0.8", recommended: { min: 3, max: 5 } },
            { dimension: "degree", weight: 0.6 },
            { label: "" },
            "garbage",
          ],
        },
        workflow: [
          {
            group: "招聘流程",
            items: [{ stage_id: "jd_write", status: "draft" }, { label: "缺 stage_id" }],
          },
        ],
        downstream: { agent_id: "xiao_hai", name: "小海", action: "生成海报", passed: true },
        messages: [
          { id: 1, role: "user", content: "你好" },
          { id: 2, role: "robot", content: "非法角色被丢弃" },
        ],
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const workspace = await fetchJdWorkspace("p1");

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/jd/p1/workspace",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
    expect(workspace.role).toBe("店长");
    expect(workspace.jd_locked).toBe(true);
    expect(workspace.jd_locked_at).toBe("2026-08-26T10:00:00Z");
    expect(workspace.jd_locked_by_stage).toBe("xiao_hai");
    expect(workspace.cloned_from_pipeline_id).toBe("p0");
    // JD 列表字段：字符串归一为单元素数组。
    expect(workspace.jd.responsibilities).toEqual(["负责门店运营"]);
    expect(workspace.quality_checks).toHaveLength(1);
    // 画像数组形态归一为对象，score 回退到 weight。
    expect(workspace.profile.dimensions?.years).toMatchObject({ weight: 0.8 });
    expect(workspace.profile.dimensions?.degree).toMatchObject({ weight: 0.6 });
    expect(workspace.workflow[0].items).toHaveLength(1);
    expect(workspace.workflow[0].items[0]).toMatchObject({
      stage_id: "jd_write",
      status: "draft",
      status_label: "",
    });
    expect(workspace.downstream).toMatchObject({ agent_id: "xiao_hai", passed: true });
    expect(workspace.messages).toHaveLength(1);
    expect(workspace.messages[0]).toMatchObject({ id: 1, role: "user", content: "你好" });
  });

  it("normalizes object-form profile dimensions and primitive values", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        mockJsonResponse({
          pipeline_id: "p1",
          role: "店长",
          profile: {
            dimensions: {
              years: { weight: "0.7", description: "3-5 年" },
              major: "连锁经营管理",
            },
          },
        }),
      ),
    );

    const workspace = await fetchJdWorkspace("p1");

    expect(workspace.profile.dimensions?.years).toMatchObject({ weight: 0.7 });
    expect(workspace.profile.dimensions?.major).toEqual({ description: "连锁经营管理" });
  });

  it("throws an ApiError carrying the backend detail and exposes the business error code", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValue(
          mockJsonResponse(
            { detail: { code: "jd_generation_in_progress", message: "生成中" } },
            { ok: false, status: 409 },
          ),
        ),
    );

    const error = await fetchJdWorkspace("p1").catch((reason: unknown) => reason);

    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).status).toBe(409);
    expect(readErrorCode(error)).toBe("jd_generation_in_progress");
  });

  it("falls back to a status-coded message when the error body has no detail", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(mockJsonResponse({}, { ok: false, status: 500 })));

    await expect(fetchJdWorkspace("p1")).rejects.toThrow("JD 工作台加载失败 (500)");
  });

  it("posts the draft payload with pipeline id and source", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(mockJsonResponse({ status: "saved", revision: 3, approval_status: "draft" }));
    vi.stubGlobal("fetch", fetchMock);

    const result = await saveJdDraft("p1", { title: "店长" }, "manual", {
      expectedRevision: 2,
      keepalive: true,
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/jd/edit",
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        keepalive: true,
        body: JSON.stringify({
          pipeline_id: "p1",
          jd: { title: "店长" },
          source: "manual",
          expected_revision: 2,
        }),
      }),
    );
    expect(result.revision).toBe(3);
  });

  it("omits the source field for manual chat generation and includes it for auto entry", async () => {
    const fetchMock = vi.fn().mockResolvedValue(mockJsonResponse({ jd: { title: "店长" } }));
    vi.stubGlobal("fetch", fetchMock);

    await generateJdDraft("p1", "帮我写 JD");
    await generateJdDraft("p1", "自动初稿", "auto_entry");

    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "/api/jd/p1/generate",
      expect.objectContaining({ body: JSON.stringify({ message: "帮我写 JD" }) }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/jd/p1/generate",
      expect.objectContaining({
        body: JSON.stringify({ message: "自动初稿", source: "auto_entry" }),
      }),
    );
  });

  it("sends the expected revision for generation, preview and approval", async () => {
    const fetchMock = vi.fn().mockResolvedValue(mockJsonResponse({ jd: { title: "店长" } }));
    vi.stubGlobal("fetch", fetchMock);

    await generateJdDraft("p1", "自动初稿", "auto_entry", 2);
    await reviseJdPreview("p1", "修改地点", 2);
    await approveJd("p1", 2);

    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "/api/jd/p1/generate",
      expect.objectContaining({
        body: JSON.stringify({ message: "自动初稿", source: "auto_entry", expected_revision: 2 }),
      }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/jd/p1/revise-preview",
      expect.objectContaining({
        body: JSON.stringify({ instruction: "修改地点", expected_revision: 2 }),
      }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      3,
      "/api/jd/p1/approve",
      expect.objectContaining({ body: JSON.stringify({ expected_revision: 2 }) }),
    );
  });

  it("keeps the friendly no-op reason and message from the JD preview", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        mockJsonResponse({
          status: "no_op",
          jd: { title: "店长" },
          changed_fields: [],
          no_op_reason: "off_topic",
          message: "天气可以聊，不过我现在主要帮你完善招聘 JD。",
        }),
      ),
    );

    await expect(reviseJdPreview("p1", "今天天气怎么样")).resolves.toMatchObject({
      status: "no_op",
      no_op_reason: "off_topic",
      message: expect.stringContaining("天气可以聊"),
    });
  });

  it("uses the public network safety timeout for the LLM-backed JD preview", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn(
      (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Promise<ReturnType<typeof mockJsonResponse>>((_resolve, reject) => {
          _init?.signal?.addEventListener("abort", () => {
            reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
          });
        }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const request = reviseJdPreview("p1", "语气更有吸引力");
    const result = expect(request).rejects.toMatchObject({ kind: "timeout" });
    await vi.advanceTimersByTimeAsync(NETWORK_SAFETY_TIMEOUT_MS);
    expect(fetchMock).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ signal: expect.objectContaining({ aborted: true }) }),
    );
    await result;
  });

  it("uses the public network safety timeout for the initial JD draft", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn(
      (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Promise<ReturnType<typeof mockJsonResponse>>((_resolve, reject) => {
          _init?.signal?.addEventListener("abort", () => {
            reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
          });
        }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const request = generateJdDraft("p1", "自动初稿", "auto_entry");
    const result = expect(request).rejects.toMatchObject({ kind: "timeout" });
    await vi.advanceTimersByTimeAsync(NETWORK_SAFETY_TIMEOUT_MS);
    expect(fetchMock).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ signal: expect.objectContaining({ aborted: true }) }),
    );
    await result;
  });

  it("uses the public network safety timeout for candidate profile generation", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn(
      (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Promise<ReturnType<typeof mockJsonResponse>>((_resolve, reject) => {
          _init?.signal?.addEventListener("abort", () => {
            reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
          });
        }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const request = runProfileBuild("p1");
    const result = expect(request).rejects.toMatchObject({ kind: "timeout" });
    await vi.advanceTimersByTimeAsync(NETWORK_SAFETY_TIMEOUT_MS);
    expect(fetchMock).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ signal: expect.objectContaining({ aborted: true }) }),
    );
    await result;
  });

  it("pins the from_agent when passing artifacts downstream", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(mockJsonResponse({ success: true, to_agent: "xiao_hai", to_name: "小海" }));
    vi.stubGlobal("fetch", fetchMock);

    const result = await passArtifactToDownstream("p1", "xiao_hai", { jd_write: { jd: {} } });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p1/pass-artifact",
      expect.objectContaining({
        body: JSON.stringify({
          from_agent: "xiao_wen",
          to_agent: "xiao_hai",
          artifacts: { jd_write: { jd: {} } },
        }),
      }),
    );
    expect(result.to_name).toBe("小海");
  });

  it("posts a request to clone a locked JD pipeline", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        status: "cloned",
        pipeline_id: "p2",
        source_pipeline_id: "p1",
        role: "店长",
        revision: 1,
        approval_status: "draft",
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(cloneJdPipeline("p1")).resolves.toMatchObject({
      pipeline_id: "p2",
      source_pipeline_id: "p1",
      status: "cloned",
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/jd/p1/clone",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
  });

  it("returns the trimmed transcript and rejects empty results", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(mockJsonResponse({ text: "  工作地点在上海  " })));

    await expect(transcribeAudio(new Blob(["voice"]))).resolves.toBe("工作地点在上海");

    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(mockJsonResponse({ text: "   " })));
    await expect(transcribeAudio(new Blob(["voice"]))).rejects.toThrow("语音转文字失败");
  });
});
