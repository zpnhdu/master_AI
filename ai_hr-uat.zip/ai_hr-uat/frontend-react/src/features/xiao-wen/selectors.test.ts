import { describe, expect, it } from "vitest";

import type { JdWorkspace } from "./api";
import {
  buildJdCopyText,
  canGenerateProfile,
  changedJdFields,
  findWorkflowItem,
  formatVoiceTime,
  hasJd,
  isApproved,
  jdStageStatus,
  missingChecks,
  profileListItems,
  profileRadarValues,
  recommendedText,
  topPriorities,
} from "./selectors";

function makeWorkspace(overrides: Partial<JdWorkspace> = {}): JdWorkspace {
  return {
    pipeline_id: "p1",
    role: "店长",
    pipeline_status: "active",
    jd_locked: false,
    jd_locked_at: "",
    jd_locked_by_stage: "",
    cloned_from_pipeline_id: "",
    jd: {},
    revision: 1,
    approval_status: "draft",
    approved_revision: 0,
    updated_at: "",
    quality_checks: [],
    profile: {},
    profile_revision: 0,
    profile_status: "pending",
    profile_is_current: false,
    workflow: [],
    downstream: null,
    messages: [],
    ...overrides,
  };
}

describe("xiao-wen selectors", () => {
  it("detects whether a usable JD draft exists", () => {
    expect(hasJd(null)).toBe(false);
    expect(hasJd(makeWorkspace())).toBe(false);
    expect(hasJd(makeWorkspace({ jd: { title: "店长" } }))).toBe(true);
    expect(hasJd(makeWorkspace({ jd: { error: "HTTP 401", parse_error: true } }))).toBe(false);
  });

  it("reads the approval status", () => {
    expect(isApproved(makeWorkspace())).toBe(false);
    expect(isApproved(makeWorkspace({ approval_status: "approved" }))).toBe(true);
  });

  it("finds workflow items across groups and derives the jd stage status", () => {
    const workspace = makeWorkspace({
      workflow: [
        {
          group: "前置",
          items: [
            {
              stage_id: "jd_write",
              label: "JD 撰写",
              status: "running",
              status_label: "进行中",
              tab: "editor",
              agent: "",
            },
          ],
        },
        {
          group: "后续",
          items: [
            {
              stage_id: "poster_gen",
              label: "招聘海报",
              status: "pending",
              status_label: "待开始",
              tab: "",
              agent: "xiao_hai",
            },
          ],
        },
      ],
    });

    expect(findWorkflowItem(workspace, "poster_gen")?.agent).toBe("xiao_hai");
    expect(findWorkflowItem(workspace, "missing")).toBeUndefined();
    expect(jdStageStatus(workspace)).toBe("running");
    expect(jdStageStatus(makeWorkspace())).toBe("pending");
  });

  it("collects only the missing quality checks", () => {
    const workspace = makeWorkspace({
      quality_checks: [
        { field: "title", label: "岗位名称", status: "ready", message: "已填写" },
        { field: "location", label: "工作地点", status: "missing", message: "待补充" },
      ],
    });

    expect(missingChecks(workspace)).toHaveLength(1);
    expect(missingChecks(workspace)[0].field).toBe("location");
  });

  it("allows retrying profile generation after JD approval when the profile is missing", () => {
    const workspace = makeWorkspace({
      jd: { title: "店长" },
      approval_status: "approved",
      quality_checks: [{ field: "title", label: "岗位名称", status: "ready", message: "已填写" }],
    });

    expect(canGenerateProfile(workspace, { busy: false, dirty: false, preview: false })).toBe(true);
    expect(
      canGenerateProfile(
        { ...workspace, profile_is_current: true, profile_status: "done" },
        { busy: false, dirty: false, preview: false },
      ),
    ).toBe(false);
    expect(
      canGenerateProfile({ ...workspace, profile_status: "running" }, { busy: false, dirty: false, preview: false }),
    ).toBe(false);
  });

  it("keeps the profile action clickable for an incomplete generated draft", () => {
    const workspace = makeWorkspace({
      jd: { title: "店长" },
      quality_checks: [
        { field: "title", label: "岗位名称", status: "ready", message: "已准备" },
        { field: "benefits", label: "福利待遇", status: "missing", message: "请补充福利待遇" },
      ],
    });

    expect(canGenerateProfile(workspace, { busy: false, dirty: false, preview: false })).toBe(true);
  });

  it("derives visible JD changes when the preview response omits field names", () => {
    const previous = { title: "店长", location: "上海", requirements: ["3 年经验"] };
    const next = { title: "店长", location: "杭州", requirements: ["3 年经验", "带队经验"] };

    expect(changedJdFields(previous, next)).toEqual(["location", "requirements"]);
    expect(changedJdFields(previous, next, ["location", "unknown_field"])).toEqual(["location", "requirements"]);
  });

  it("formats recommended values across string, array and range shapes", () => {
    expect(recommendedText(null)).toBe("待确认");
    expect(recommendedText("")).toBe("待确认");
    expect(recommendedText("本科")).toBe("本科");
    expect(recommendedText(["上海", "杭州"])).toBe("上海、杭州");
    expect(recommendedText({ min: 3, max: 5 })).toBe("3-5年");
    expect(recommendedText({ max: 5 })).toBe("-5年");
    expect(recommendedText(3)).toBe("3");
  });

  it("picks the top priority dimensions by weight", () => {
    const profile = {
      dimensions: {
        years: { weight: 0.9 },
        degree: { weight: 0.5 },
        major: { weight: 0.7 },
        location: { weight: 0.4 },
        values: { weight: 0.95 },
      },
    };

    const priorities = topPriorities(profile);

    expect(priorities.map((item) => item.key)).toEqual(["values", "years", "major", "degree"]);
  });

  it("averages dimension weights per profile group for the radar chart", () => {
    const profile = {
      dimensions: {
        location: { weight: 0.8 },
        work_mode: { weight: 0.4 },
        degree: { weight: 0.5 },
      },
    };

    // 基础条件组（location 0.8 + work_mode 0.4）/ 2 = 60；教育背景组 degree 0.5 = 50。
    expect(profileRadarValues(profile)).toEqual([60, 50, 0, 0, 0]);
    expect(profileRadarValues({})).toEqual([0, 0, 0, 0, 0]);
  });

  it("builds profile list items with the description fallback chain and labels", () => {
    const profile = {
      dimensions: {
        years: { weight: 0.9, description: "3-5 年门店管理" },
        degree: { weight: 0.5, criteria: "大专以上" },
        major: { requirement: "连锁经营优先" },
        values: { recommended: "客户第一" },
      },
    };

    const items = profileListItems(profile);
    const byKey = Object.fromEntries(items.map((item) => [item.key, item]));

    expect(byKey.years).toMatchObject({ name: "工作年限", weight: 0.9, description: "3-5 年门店管理" });
    expect(byKey.degree.description).toBe("大专以上");
    expect(byKey.major.description).toBe("连锁经营优先");
    expect(byKey.values.description).toBe("客户第一");
  });

  it("builds the plain-text JD copy in the legacy format", () => {
    const text = buildJdCopyText({
      title: "店长",
      department: "营运部",
      location: "上海",
      salary_range: "12-18K",
      responsibilities: ["负责门店运营", "带领团队"],
      requirements: ["3 年经验"],
      benefits: ["五险一金", "包吃"],
    });

    expect(text).toBe(
      [
        "店长",
        "营运部 · 上海 · 12-18K",
        "",
        "岗位职责",
        "1. 负责门店运营",
        "2. 带领团队",
        "",
        "任职要求",
        "1. 3 年经验",
        "",
        "福利待遇",
        "- 五险一金",
        "- 包吃",
      ].join("\n"),
    );
  });

  it("formats the voice recording timer as mm:ss", () => {
    expect(formatVoiceTime(0)).toBe("00:00");
    expect(formatVoiceTime(7)).toBe("00:07");
    expect(formatVoiceTime(60)).toBe("01:00");
  });
});
