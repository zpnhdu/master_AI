import { ApiError, requestWithTimeout } from "../pipelines/api";

/** 结构化 JD 文档。除已知字段外允许后端透传的扩展键。 */
export type JdDocument = {
  title?: string;
  department?: string;
  location?: string;
  salary_range?: string;
  work_hours?: string;
  responsibilities?: string[];
  requirements?: string[];
  tech_stack?: string[];
  benefits?: string[];
  team_intro?: string;
  [key: string]: unknown;
};

export type QualityCheck = {
  field: string;
  label: string;
  status: "ready" | "missing";
  message: string;
};

export type WorkflowItem = {
  stage_id: string;
  label: string;
  status: string;
  status_label: string;
  /** 非空表示在当前工作台内切换文档 tab，否则跳转到对应 Agent 工作台。 */
  tab: string;
  agent: string;
};

export type WorkflowGroup = {
  group: string;
  items: WorkflowItem[];
};

export type ProfileDimension = {
  weight?: number;
  recommended?: unknown;
  description?: string;
  [key: string]: unknown;
};

export type CandidateProfile = {
  dimensions?: Record<string, ProfileDimension>;
};

export type DownstreamInfo = {
  agent_id: string;
  name: string;
  action: string;
  page: string;
  passed: boolean;
};

export type JdMessage = {
  id: number | string;
  role: "user" | "assistant" | "system";
  content: string;
  card_type?: string | null;
  card_data?: Record<string, unknown>;
  stage_id?: string;
  created_at?: string;
};

export type JdWorkspace = {
  pipeline_id: string;
  role: string;
  pipeline_status: string;
  jd_locked: boolean;
  jd_locked_at: string;
  jd_locked_by_stage: string;
  cloned_from_pipeline_id: string;
  jd: JdDocument;
  revision: number;
  approval_status: string;
  approved_revision: number;
  updated_at: string;
  quality_checks: QualityCheck[];
  profile: CandidateProfile;
  profile_revision: number;
  profile_status: string;
  profile_is_current: boolean;
  workflow: WorkflowGroup[];
  downstream: DownstreamInfo | null;
  messages: JdMessage[];
};

export type SaveJdResponse = {
  status: string;
  revision: number;
  approval_status: string;
  quality_checks: QualityCheck[];
  workflow: WorkflowGroup[];
};

export type GenerateJdResponse = {
  status: string;
  jd: JdDocument;
  revision: number;
  quality_checks: QualityCheck[];
  workflow: WorkflowGroup[];
  reply: string;
};

export type RevisePreviewResponse = {
  status: string;
  jd: JdDocument;
  changed_fields: string[];
  no_op_reason?: string;
  message?: string;
};

export type ApproveJdResponse = {
  status: string;
  revision: number;
  approved_revision: number;
  approval_status: string;
  workflow: WorkflowGroup[];
};

export type ProfileBuildResponse = {
  success: boolean;
  stage_id: string;
  status: string;
  profile: CandidateProfile;
  cached?: boolean;
};

export type PassArtifactResponse = {
  success: boolean;
  from_agent: string;
  to_agent: string;
  to_name: string;
  jd_revision?: number;
  artifacts?: Record<string, unknown>;
};

export type CloneJdResponse = {
  status: string;
  pipeline_id: string;
  source_pipeline_id: string;
  role: string;
  revision: number;
  approval_status: string;
};

type RevisionRequestOptions = {
  expectedRevision?: number;
  keepalive?: boolean;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getString(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function getNumber(value: unknown): number | undefined {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim() !== "") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : undefined;
  }
  return undefined;
}

function getBoolean(value: unknown): boolean {
  return value === true || value === "true";
}

function getStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === "string");
  }
  return [];
}

function readErrorMessage(data: unknown, fallback: string): string {
  if (isRecord(data)) {
    const detail = data.detail;
    if (typeof detail === "string") {
      return detail;
    }
    if (isRecord(detail) && typeof detail.message === "string") {
      return detail.message;
    }
    if (typeof data.message === "string") {
      return data.message;
    }
  }
  return fallback;
}

/** 读取业务错误码（如 jd_generation_in_progress），用于自动草稿等待分支。 */
export function readErrorCode(error: unknown): string {
  if (error instanceof ApiError && isRecord(error.data)) {
    const detail = error.data.detail;
    if (isRecord(detail) && typeof detail.code === "string") {
      return detail.code;
    }
  }
  return "";
}

async function parseJson<T>(response: Response, fallback: string, normalize: (data: unknown) => T): Promise<T> {
  if (!response.ok) {
    const data: unknown = await response.json().catch(() => ({}));
    throw new ApiError(readErrorMessage(data, `${fallback} (${response.status})`), {
      status: response.status,
      data,
    });
  }
  const data: unknown = await response.json();
  return normalize(data);
}

function normalizeJdDocument(value: unknown): JdDocument {
  if (!isRecord(value)) {
    return {};
  }
  if (value.parse_error === true || value.error) {
    return {};
  }
  const jd: JdDocument = { ...value };
  for (const field of ["responsibilities", "requirements", "tech_stack", "benefits"] as const) {
    if (value[field] !== undefined && !Array.isArray(value[field])) {
      const text = getString(value[field]);
      jd[field] = text ? [text] : [];
    }
  }
  return jd;
}

function normalizeQualityChecks(value: unknown): QualityCheck[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.flatMap((item) => {
    if (!isRecord(item)) {
      return [];
    }
    const status: QualityCheck["status"] = item.status === "ready" ? "ready" : "missing";
    return [
      {
        field: getString(item.field) ?? "",
        label: getString(item.label) ?? "",
        status,
        message: getString(item.message) ?? "",
      },
    ];
  });
}

function normalizeWorkflow(value: unknown): WorkflowGroup[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.flatMap((group) => {
    if (!isRecord(group)) {
      return [];
    }
    const items = Array.isArray(group.items)
      ? group.items.flatMap((item) => {
          if (!isRecord(item)) {
            return [];
          }
          const stageId = getString(item.stage_id);
          if (!stageId) {
            return [];
          }
          return [
            {
              stage_id: stageId,
              label: getString(item.label) ?? stageId,
              status: getString(item.status) ?? "pending",
              status_label: getString(item.status_label) ?? "",
              tab: getString(item.tab) ?? "",
              agent: getString(item.agent) ?? "",
            },
          ];
        })
      : [];
    return [{ group: getString(group.group) ?? "", items }];
  });
}

function normalizeProfile(value: unknown): CandidateProfile {
  if (!isRecord(value)) {
    return {};
  }
  const raw = value.dimensions;
  const dimensions: Record<string, ProfileDimension> = {};
  if (Array.isArray(raw)) {
    // 兼容数组形态：以 name/dimension/label 作为维度键。
    for (const item of raw) {
      if (!isRecord(item)) {
        continue;
      }
      const key = getString(item.name) ?? getString(item.dimension) ?? getString(item.label);
      if (!key) {
        continue;
      }
      dimensions[key] = { ...item, weight: getNumber(item.weight ?? item.score) };
    }
  } else if (isRecord(raw)) {
    for (const [key, dimension] of Object.entries(raw)) {
      dimensions[key] = isRecord(dimension)
        ? { ...dimension, weight: getNumber(dimension.weight ?? dimension.score) }
        : { description: String(dimension) };
    }
  }
  return Object.keys(dimensions).length ? { dimensions } : {};
}

function normalizeDownstream(value: unknown): DownstreamInfo | null {
  if (!isRecord(value)) {
    return null;
  }
  const agentId = getString(value.agent_id);
  if (!agentId) {
    return null;
  }
  return {
    agent_id: agentId,
    name: getString(value.name) ?? agentId,
    action: getString(value.action) ?? "",
    page: getString(value.page) ?? agentId,
    passed: getBoolean(value.passed),
  };
}

function normalizeMessages(value: unknown): JdMessage[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.flatMap((item, index) => {
    if (!isRecord(item)) {
      return [];
    }
    const role = getString(item.role);
    if (role !== "user" && role !== "assistant" && role !== "system") {
      return [];
    }
    const message: JdMessage = {
      id: getNumber(item.id) ?? `server-${index}`,
      role,
      content: getString(item.content) ?? "",
    };
    const cardType = getString(item.card_type);
    if (cardType) {
      message.card_type = cardType;
    }
    if (isRecord(item.card_data)) {
      message.card_data = item.card_data;
    }
    const stageId = getString(item.stage_id);
    if (stageId) {
      message.stage_id = stageId;
    }
    const createdAt = getString(item.created_at);
    if (createdAt) {
      message.created_at = createdAt;
    }
    return [message];
  });
}

function normalizeWorkspace(data: unknown): JdWorkspace {
  if (!isRecord(data)) {
    throw new ApiError("JD 工作台数据格式异常");
  }
  return {
    pipeline_id: getString(data.pipeline_id) ?? "",
    role: getString(data.role) ?? "未命名岗位",
    pipeline_status: getString(data.pipeline_status) ?? "draft",
    jd_locked: getBoolean(data.jd_locked),
    jd_locked_at: getString(data.jd_locked_at) ?? "",
    jd_locked_by_stage: getString(data.jd_locked_by_stage) ?? "",
    cloned_from_pipeline_id: getString(data.cloned_from_pipeline_id) ?? "",
    jd: normalizeJdDocument(data.jd),
    revision: getNumber(data.revision) ?? 0,
    approval_status: getString(data.approval_status) ?? "draft",
    approved_revision: getNumber(data.approved_revision) ?? 0,
    updated_at: getString(data.updated_at) ?? "",
    quality_checks: normalizeQualityChecks(data.quality_checks),
    profile: normalizeProfile(data.profile),
    profile_revision: getNumber(data.profile_revision) ?? 0,
    profile_status: getString(data.profile_status) ?? "pending",
    profile_is_current: getBoolean(data.profile_is_current),
    workflow: normalizeWorkflow(data.workflow),
    downstream: normalizeDownstream(data.downstream),
    messages: normalizeMessages(data.messages),
  };
}

function normalizeSaveResponse(data: unknown): SaveJdResponse {
  const record = isRecord(data) ? data : {};
  return {
    status: getString(record.status) ?? "saved",
    revision: getNumber(record.revision) ?? 0,
    approval_status: getString(record.approval_status) ?? "draft",
    quality_checks: normalizeQualityChecks(record.quality_checks),
    workflow: normalizeWorkflow(record.workflow),
  };
}

function normalizeGenerateResponse(data: unknown): GenerateJdResponse {
  const record = isRecord(data) ? data : {};
  return {
    status: getString(record.status) ?? "",
    jd: normalizeJdDocument(record.jd),
    revision: getNumber(record.revision) ?? 0,
    quality_checks: normalizeQualityChecks(record.quality_checks),
    workflow: normalizeWorkflow(record.workflow),
    reply: getString(record.reply) ?? "",
  };
}

export async function fetchJdWorkspace(pipelineId: string): Promise<JdWorkspace> {
  return requestWithTimeout(
    `/api/jd/${encodeURIComponent(pipelineId)}/workspace`,
    { credentials: "include" },
    (response) => parseJson(response, "JD 工作台加载失败", normalizeWorkspace),
  );
}

export async function cloneJdPipeline(pipelineId: string): Promise<CloneJdResponse> {
  return requestWithTimeout(
    `/api/jd/${encodeURIComponent(pipelineId)}/clone`,
    {
      method: "POST",
      credentials: "include",
    },
    (response) =>
      parseJson(response, "复制岗位失败", (data) => {
        const record = isRecord(data) ? data : {};
        return {
          status: getString(record.status) ?? "cloned",
          pipeline_id: getString(record.pipeline_id) ?? "",
          source_pipeline_id: getString(record.source_pipeline_id) ?? pipelineId,
          role: getString(record.role) ?? "未命名岗位",
          revision: getNumber(record.revision) ?? 0,
          approval_status: getString(record.approval_status) ?? "draft",
        };
      }),
  );
}

export async function saveJdDraft(
  pipelineId: string,
  jd: JdDocument,
  source: string,
  options: RevisionRequestOptions = {},
): Promise<SaveJdResponse> {
  return requestWithTimeout(
    "/api/jd/edit",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      keepalive: options.keepalive,
      body: JSON.stringify({
        pipeline_id: pipelineId,
        jd,
        source,
        ...(options.expectedRevision === undefined ? {} : { expected_revision: options.expectedRevision }),
      }),
    },
    (response) => parseJson(response, "保存失败", normalizeSaveResponse),
  );
}

export async function generateJdDraft(
  pipelineId: string,
  message: string,
  source?: string,
  expectedRevision?: number,
): Promise<GenerateJdResponse> {
  return requestWithTimeout(
    `/api/jd/${encodeURIComponent(pipelineId)}/generate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        message,
        ...(source ? { source } : {}),
        ...(expectedRevision === undefined ? {} : { expected_revision: expectedRevision }),
      }),
    },
    (response) => parseJson(response, "JD 生成失败", normalizeGenerateResponse),
  );
}

export async function reviseJdPreview(
  pipelineId: string,
  instruction: string,
  expectedRevision?: number,
): Promise<RevisePreviewResponse> {
  return requestWithTimeout(
    `/api/jd/${encodeURIComponent(pipelineId)}/revise-preview`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        instruction,
        ...(expectedRevision === undefined ? {} : { expected_revision: expectedRevision }),
      }),
    },
    (response) =>
      parseJson(response, "修改建议生成失败", (data) => {
        const record = isRecord(data) ? data : {};
        return {
          status: getString(record.status) ?? "preview",
          jd: normalizeJdDocument(record.jd),
          changed_fields: getStringArray(record.changed_fields),
          no_op_reason: getString(record.no_op_reason),
          message: getString(record.message),
        };
      }),
  );
}

export async function approveJd(pipelineId: string, expectedRevision?: number): Promise<ApproveJdResponse> {
  return requestWithTimeout(
    `/api/jd/${encodeURIComponent(pipelineId)}/approve`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(expectedRevision === undefined ? {} : { expected_revision: expectedRevision }),
    },
    (response) =>
      parseJson(response, "JD 确认失败", (data) => {
        const record = isRecord(data) ? data : {};
        return {
          status: getString(record.status) ?? "approved",
          revision: getNumber(record.revision) ?? 0,
          approved_revision: getNumber(record.approved_revision) ?? 0,
          approval_status: getString(record.approval_status) ?? "approved",
          workflow: normalizeWorkflow(record.workflow),
        };
      }),
  );
}

export async function runProfileBuild(pipelineId: string): Promise<ProfileBuildResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/stages/profile_build/run`,
    { method: "POST", credentials: "include" },
    (response) =>
      parseJson(response, "候选人画像生成失败", (data) => {
        const record = isRecord(data) ? data : {};
        return {
          success: getBoolean(record.success),
          stage_id: getString(record.stage_id) ?? "profile_build",
          status: getString(record.status) ?? "",
          profile: normalizeProfile(record.profile),
          cached: record.cached === true ? true : undefined,
        };
      }),
  );
}

export async function passArtifactToDownstream(
  pipelineId: string,
  toAgent: string,
  artifacts: Record<string, unknown>,
): Promise<PassArtifactResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/pass-artifact`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ from_agent: "xiao_wen", to_agent: toAgent, artifacts }),
    },
    (response) =>
      parseJson(response, "传递失败", (data) => {
        const record = isRecord(data) ? data : {};
        return {
          success: getBoolean(record.success),
          from_agent: getString(record.from_agent) ?? "xiao_wen",
          to_agent: getString(record.to_agent) ?? toAgent,
          to_name: getString(record.to_name) ?? "",
          jd_revision: getNumber(record.jd_revision),
          artifacts: isRecord(record.artifacts) ? record.artifacts : undefined,
        };
      }),
  );
}

export async function transcribeAudio(audio: Blob): Promise<string> {
  const formData = new FormData();
  formData.append("audio", audio, "xiao-wen-voice.webm");
  return requestWithTimeout(
    "/api/interview/asr",
    { method: "POST", credentials: "include", body: formData },
    async (response) => {
      if (!response.ok) {
        throw new ApiError("语音转文字失败", { status: response.status });
      }
      const data: unknown = await response.json();
      const text = isRecord(data) ? getString(data.text)?.trim() : undefined;
      if (!text) {
        throw new ApiError("语音转文字失败");
      }
      return text;
    },
  );
}
