import { useCallback, useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { message } from "antd";

import { ApiError } from "../pipelines/api";
import {
  approveJd,
  cloneJdPipeline,
  generateJdDraft,
  passArtifactToDownstream,
  readErrorCode,
  reviseJdPreview,
  runProfileBuild,
  saveJdDraft,
  fetchJdWorkspace,
  type CandidateProfile,
  type JdDocument,
  type JdMessage,
  type JdWorkspace,
} from "./api";
import { AUTO_DRAFT_MESSAGE, FIELD_LABELS, QUICK_PROMPTS_EMPTY, QUICK_PROMPTS_REFINE } from "./constants";
import {
  buildJdCopyText,
  canGenerateProfile,
  changedJdFields,
  hasJd,
  isApproved,
  jdStageStatus,
  missingChecks,
} from "./selectors";
import { jdWorkspaceQueryKey, useJdWorkspaceQuery } from "./hooks";

export type DocumentSection = "editor" | "quality" | "profile";
export type MobileView = "chat" | "document";
export type AutoDraftStatus = "idle" | "running" | "waiting" | "success" | "error";

export type ChatCard =
  | { type: "profile"; profile: CandidateProfile }
  | { type: "proposal"; labels: string[]; previewId: string }
  | { type: "open_agent"; agentId: string; label: string };

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  card?: ChatCard;
};

export type RevisePreview = {
  id: string;
  jd: JdDocument;
  changed_fields: string[];
};

/** 请求文档区聚焦某个字段；nonce 保证同一字段重复点击也能触发。 */
export type FieldFocusRequest = {
  field: string;
  nonce: number;
};

export type SaveState = {
  type: "" | "dirty" | "error";
  text: string;
};

let messageSequence = 0;

function nextMessageId(prefix: string) {
  messageSequence += 1;
  return `${prefix}-${Date.now()}-${messageSequence}`;
}

function serverMessageToChat(message: JdMessage): ChatMessage {
  const chat: ChatMessage = {
    id: `server-${message.id}`,
    role: message.role,
    content: message.content,
  };
  if (message.card_type === "profile_card" && message.card_data) {
    // 后端 card_data 可能是 {profile} 或直接是画像本体。
    const cardData = message.card_data;
    const profile =
      cardData.profile && typeof cardData.profile === "object"
        ? (cardData.profile as CandidateProfile)
        : (cardData as unknown as CandidateProfile);
    if (profile.dimensions && Object.keys(profile.dimensions).length) {
      chat.card = { type: "profile", profile };
    }
  }
  return chat;
}

/** 保存前对草稿做与旧版 collectJD 一致的裁剪：字符串 trim、列表去空行。 */
function normalizeDraftForSave(draft: JdDocument): JdDocument {
  const payload: JdDocument = { ...draft };
  for (const field of ["title", "department", "location", "salary_range", "work_hours", "team_intro"]) {
    const value = payload[field];
    if (typeof value === "string") {
      payload[field] = value.trim();
    }
  }
  for (const field of ["responsibilities", "requirements", "tech_stack", "benefits"]) {
    const value = payload[field];
    if (Array.isArray(value)) {
      payload[field] = value
        .filter((item): item is string => typeof item === "string")
        .map((item) => item.trim())
        .filter(Boolean);
    }
  }
  return payload;
}

const AUTO_DRAFT_POLL_LIMIT = 30;
const AUTO_DRAFT_POLL_INTERVAL_MS = 2000;
const SAVE_DEBOUNCE_MS = 700;

export function useXiaoWenController(pipelineId: string) {
  const queryClient = useQueryClient();
  const antdMessage = message;
  const workspaceQuery = useJdWorkspaceQuery(pipelineId);
  const workspace = workspaceQuery.data ?? null;

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [typing, setTyping] = useState(false);
  const [activeSection, setActiveSection] = useState<DocumentSection>("editor");
  const [mobileView, setMobileView] = useState<MobileView>("chat");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [preview, setPreview] = useState<RevisePreview | null>(null);
  const [draft, setDraft] = useState<JdDocument>({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState(false);
  const [saveState, setSaveState] = useState<SaveState>({ type: "", text: "所有更改已保存" });
  const [autoDraft, setAutoDraft] = useState<{ status: AutoDraftStatus; error: string }>({
    status: "idle",
    error: "",
  });
  const [composerValue, setComposerValue] = useState("");
  const [focusRequest, setFocusRequest] = useState<FieldFocusRequest | null>(null);

  const workspaceRef = useRef(workspace);
  workspaceRef.current = workspace;
  const draftRef = useRef(draft);
  draftRef.current = draft;
  const previewRef = useRef(preview);
  previewRef.current = preview;
  const busyRef = useRef(busy);
  busyRef.current = busy;
  const dirtyRef = useRef(dirty);
  dirtyRef.current = dirty;
  const savingRef = useRef(saving);
  savingRef.current = saving;

  const initializedRef = useRef(false);
  const autoDraftAttemptedRef = useRef(false);
  const editSequenceRef = useRef(0);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveInFlightRef = useRef<Promise<void> | null>(null);
  const revisionRef = useRef(0);

  const updateWorkspace = useCallback(
    (updater: (current: JdWorkspace) => JdWorkspace) => {
      queryClient.setQueryData<JdWorkspace>(jdWorkspaceQueryKey(pipelineId), (current) =>
        current ? updater(current) : current,
      );
    },
    [queryClient, pipelineId],
  );

  /** 统一接口反馈：antd message 浮层，默认 3 秒自动消失。 */
  const showToast = useCallback(
    (text: string, type: "success" | "error" | "info" | "warning" = "info") => {
      antdMessage[type](text);
    },
    [antdMessage],
  );

  const flushPendingDraft = useCallback(() => {
    if (workspaceRef.current?.jd_locked) {
      return;
    }
    if (saveInFlightRef.current) {
      const pending = saveInFlightRef.current;
      void pending.finally(() => flushPendingDraft());
      return;
    }
    if (!dirtyRef.current || previewRef.current) {
      return;
    }
    const payload = normalizeDraftForSave(draftRef.current);
    if (!Object.keys(payload).length) {
      return;
    }
    dirtyRef.current = false;
    void saveJdDraft(pipelineId, payload, "auto_unmount", {
      expectedRevision: revisionRef.current,
      keepalive: true,
    }).catch(() => {});
  }, [pipelineId]);

  useEffect(() => {
    window.addEventListener("pagehide", flushPendingDraft);
    return () => {
      window.removeEventListener("pagehide", flushPendingDraft);
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
      }
      flushPendingDraft();
    };
  }, [flushPendingDraft]);

  const appendMessage = useCallback((role: ChatMessage["role"], content: string, card?: ChatCard) => {
    setMessages((current) => [...current, { id: nextMessageId(role), role, content, card }]);
  }, []);

  /** 重新拉取工作台（保留本地对话），并同步编辑器草稿。对应旧版 loadWorkspace(false)。 */
  const reloadWorkspace = useCallback(async (): Promise<JdWorkspace | null> => {
    try {
      const fresh = await queryClient.fetchQuery({
        queryKey: jdWorkspaceQueryKey(pipelineId),
        queryFn: () => fetchJdWorkspace(pipelineId),
        staleTime: 0,
      });
      setPreview(null);
      previewRef.current = null;
      setDirty(false);
      dirtyRef.current = false;
      setDraft(fresh.jd);
      draftRef.current = fresh.jd;
      revisionRef.current = fresh.revision;
      setSaveState({ type: "", text: "所有更改已保存" });
      return fresh;
    } catch {
      return null;
    }
  }, [queryClient, pipelineId]);

  const saveDraft = useCallback(
    async (explicitJd?: JdDocument, source = "manual"): Promise<void> => {
      if (workspaceRef.current?.jd_locked) {
        showToast("当前 JD 已锁定，请新建岗位后修改", "warning");
        return;
      }
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
        saveTimerRef.current = null;
      }
      if (saveInFlightRef.current) {
        await saveInFlightRef.current.catch(() => {});
        if (!explicitJd && !dirtyRef.current) {
          return;
        }
      }
      const payload = normalizeDraftForSave(explicitJd ?? draftRef.current);
      if (!Object.keys(payload).length) {
        return;
      }
      const snapshot = editSequenceRef.current;
      const expectedRevision = revisionRef.current;
      dirtyRef.current = false;
      setDirty(false);
      savingRef.current = true;
      setSaving(true);
      setSaveState({ type: "dirty", text: "正在保存..." });
      const request = saveJdDraft(pipelineId, payload, source, { expectedRevision });
      saveInFlightRef.current = request.then((result) => {
        revisionRef.current = result.revision;
      });
      try {
        const result = await request;
        revisionRef.current = result.revision;
        const changedDuringSave = editSequenceRef.current !== snapshot;
        updateWorkspace((current) => ({
          ...current,
          jd: payload,
          revision: result.revision,
          approval_status: result.approval_status,
          quality_checks: result.quality_checks,
          workflow: result.workflow,
          profile: {},
          profile_status: "pending",
          profile_is_current: false,
          downstream: current.downstream ? { ...current.downstream, passed: false } : null,
        }));
        setPreview(null);
        previewRef.current = null;
        if (changedDuringSave) {
          dirtyRef.current = true;
          setDirty(true);
          setSaveState({ type: "dirty", text: "等待保存..." });
        } else {
          setSaveState({ type: "", text: "所有更改已保存" });
        }
      } catch (error) {
        dirtyRef.current = true;
        setDirty(true);
        setSaveState({ type: "error", text: "保存失败" });
        if (error instanceof ApiError && error.status === 409) {
          showToast("检测到其他页面更新，已重新加载最新内容");
          await reloadWorkspace();
        } else if (error instanceof ApiError && error.status === 423) {
          dirtyRef.current = false;
          setDirty(false);
          showToast("当前 JD 已锁定，请新建岗位后修改", "warning");
          await reloadWorkspace();
        } else {
          showToast(error instanceof Error ? error.message : "保存失败", "error");
        }
        throw error;
      } finally {
        saveInFlightRef.current = null;
        savingRef.current = false;
        setSaving(false);
      }
      if (dirtyRef.current && editSequenceRef.current !== snapshot) {
        return saveDraft();
      }
    },
    [pipelineId, updateWorkspace, showToast, reloadWorkspace],
  );

  const scheduleSave = useCallback(() => {
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }
    saveTimerRef.current = setTimeout(() => {
      void saveDraft().catch(() => {});
    }, SAVE_DEBOUNCE_MS);
  }, [saveDraft]);

  /** 编辑器内容变更：预览态只更新本地预览，正式态走防抖自动保存。 */
  const updateDraft = useCallback(
    (next: JdDocument) => {
      if (workspaceRef.current?.jd_locked) {
        return;
      }
      setDraft(next);
      draftRef.current = next;
      if (previewRef.current) {
        const synced = { ...previewRef.current, jd: next };
        setPreview(synced);
        previewRef.current = synced;
        return;
      }
      dirtyRef.current = true;
      setDirty(true);
      editSequenceRef.current += 1;
      setSaveState({ type: "dirty", text: "等待保存..." });
      scheduleSave();
    },
    [scheduleSave],
  );

  const updateDraftField = useCallback(
    (field: string, value: string) => {
      updateDraft({ ...draftRef.current, [field]: value });
    },
    [updateDraft],
  );

  const updateDraftListItem = useCallback(
    (field: string, index: number, value: string) => {
      const current = draftRef.current[field];
      const list = Array.isArray(current) ? [...current] : [""];
      list[index] = value;
      updateDraft({ ...draftRef.current, [field]: list });
    },
    [updateDraft],
  );

  const removeDraftListItem = useCallback(
    (field: string, index: number) => {
      const current = draftRef.current[field];
      const list = Array.isArray(current) ? [...current] : [];
      list.splice(index, 1);
      updateDraft({ ...draftRef.current, [field]: list });
    },
    [updateDraft],
  );

  const waitForAutoDraft = useCallback(async () => {
    for (let attempt = 0; attempt < AUTO_DRAFT_POLL_LIMIT; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, AUTO_DRAFT_POLL_INTERVAL_MS));
      try {
        const fresh = await queryClient.fetchQuery({
          queryKey: jdWorkspaceQueryKey(pipelineId),
          queryFn: () => fetchJdWorkspace(pipelineId),
          staleTime: 0,
        });
        if (hasJd(fresh)) {
          setAutoDraft({ status: "success", error: "" });
          setDraft(fresh.jd);
          draftRef.current = fresh.jd;
          revisionRef.current = fresh.revision;
          return;
        }
        if (jdStageStatus(fresh) !== "running") {
          break;
        }
      } catch {
        // 轮询失败继续重试，直到达到上限。
      }
    }
    throw new Error("生成时间比预计稍长，可以点击重试");
  }, [queryClient, pipelineId]);

  const startAutoDraft = useCallback(
    async (force = false) => {
      const current = workspaceRef.current;
      if (!current || hasJd(current) || (!force && autoDraftAttemptedRef.current)) {
        return;
      }
      if (current.jd_locked) {
        return;
      }
      autoDraftAttemptedRef.current = true;
      const stageStatus = jdStageStatus(current);
      if (!force && stageStatus === "failed") {
        setAutoDraft({ status: "error", error: "上次生成没有完成，可以点击重试初稿。" });
        return;
      }
      if (stageStatus === "running") {
        setAutoDraft({ status: "waiting", error: "" });
        try {
          await waitForAutoDraft();
        } catch (error) {
          setAutoDraft({
            status: "error",
            error: error instanceof Error ? error.message : "生成失败",
          });
        }
        return;
      }

      setAutoDraft({ status: "running", error: "" });
      try {
        const result = await generateJdDraft(pipelineId, AUTO_DRAFT_MESSAGE, "auto_entry", revisionRef.current);
        if (Object.keys(result.jd).length && !hasJd(workspaceRef.current)) {
          updateWorkspace((ws) => ({
            ...ws,
            jd: result.jd,
            revision: result.revision,
            approval_status: "draft",
            quality_checks: result.quality_checks,
            workflow: result.workflow,
          }));
          setDraft(result.jd);
          draftRef.current = result.jd;
          revisionRef.current = result.revision;
          setAutoDraft({ status: "success", error: "" });
          appendMessage(
            "assistant",
            result.reply || `已为「${workspaceRef.current?.role ?? "该岗位"}」生成一版 JD 初稿，你可以继续编辑。`,
          );
          setActiveSection("editor");
        } else {
          const fresh = await reloadWorkspace();
          setAutoDraft(
            hasJd(fresh) ? { status: "success", error: "" } : { status: "error", error: "没有拿到有效的 JD 草稿" },
          );
        }
      } catch (error) {
        if (readErrorCode(error) === "jd_generation_in_progress") {
          setAutoDraft({ status: "waiting", error: "" });
          try {
            await waitForAutoDraft();
          } catch (waitError) {
            setAutoDraft({
              status: "error",
              error: waitError instanceof Error ? waitError.message : "生成失败",
            });
          }
          return;
        }
        if (error instanceof ApiError && error.status === 409) {
          const fresh = await reloadWorkspace();
          if (hasJd(fresh)) {
            setAutoDraft({ status: "success", error: "" });
            return;
          }
        }
        setAutoDraft({
          status: "error",
          error: error instanceof Error ? error.message : "生成失败",
        });
      }
    },
    [pipelineId, updateWorkspace, appendMessage, waitForAutoDraft, reloadWorkspace],
  );

  // 首次加载：初始化对话与草稿；无 JD 时触发自动初稿。
  useEffect(() => {
    if (!workspace || initializedRef.current) {
      return;
    }
    initializedRef.current = true;
    setMessages(workspace.messages.map(serverMessageToChat));
    setDraft(workspace.jd);
    draftRef.current = workspace.jd;
    revisionRef.current = workspace.revision;
    if (!hasJd(workspace)) {
      void startAutoDraft();
    }
  }, [workspace, startAutoDraft]);

  const sendMessage = useCallback(async () => {
    const text = composerValue.trim();
    let current = workspaceRef.current;
    if (!text || busyRef.current || !current) {
      return;
    }
    if (current.jd_locked) {
      showToast("当前 JD 已锁定，请新建岗位后修改", "warning");
      return;
    }
    setBusy(true);
    busyRef.current = true;
    setComposerValue("");
    appendMessage("user", text);
    setTyping(true);
    try {
      if (dirtyRef.current || savingRef.current) {
        await saveDraft();
        current = queryClient.getQueryData<JdWorkspace>(jdWorkspaceQueryKey(pipelineId)) ?? workspaceRef.current;
        if (!current) {
          throw new Error("工作台数据已失效，请刷新后重试");
        }
      }
      if (!hasJd(current)) {
        const result = await generateJdDraft(pipelineId, text, undefined, revisionRef.current);
        updateWorkspace((ws) => ({
          ...ws,
          jd: result.jd,
          revision: result.revision,
          approval_status: "draft",
          quality_checks: result.quality_checks,
          workflow: result.workflow,
        }));
        setDraft(result.jd);
        draftRef.current = result.jd;
        revisionRef.current = result.revision;
        setTyping(false);
        appendMessage("assistant", result.reply);
        setActiveSection("editor");
      } else {
        const result = await reviseJdPreview(pipelineId, text, revisionRef.current);
        const changedFields = changedJdFields(current.jd, result.jd, result.changed_fields);
        setTyping(false);
        const labels = changedFields.map((field) => FIELD_LABELS[field] || field);
        if (!labels.length) {
          appendMessage(
            "assistant",
            result.message ??
              "我明白你想继续调整这份 JD，不过还不确定你想改哪部分。比如工作地点、岗位职责、任职要求或福利待遇？",
          );
          return;
        }
        const previewId = nextMessageId("preview");
        const nextPreview = { id: previewId, jd: result.jd, changed_fields: changedFields };
        setPreview(nextPreview);
        previewRef.current = nextPreview;
        setDraft(result.jd);
        draftRef.current = result.jd;
        appendMessage("assistant", "我先把建议放到右侧预览，蓝色字段是本次改动。确认后才会覆盖当前草稿。", {
          type: "proposal",
          labels,
          previewId,
        });
        setActiveSection("editor");
        setMobileView("document");
      }
    } catch (error) {
      setTyping(false);
      if (error instanceof ApiError && error.status === 409) {
        await reloadWorkspace();
      }
      appendMessage("assistant", `这次没有成功处理：${error instanceof Error ? error.message : "请求失败"}`);
      setComposerValue(text);
    } finally {
      setBusy(false);
      busyRef.current = false;
    }
  }, [composerValue, pipelineId, queryClient, saveDraft, reloadWorkspace, updateWorkspace, appendMessage, showToast]);

  const applyPreview = useCallback(async () => {
    if (!previewRef.current || busyRef.current || workspaceRef.current?.jd_locked) {
      if (workspaceRef.current?.jd_locked) {
        showToast("当前 JD 已锁定，请新建岗位后修改", "warning");
      }
      return;
    }
    setBusy(true);
    busyRef.current = true;
    try {
      await saveDraft(draftRef.current, "ai_revision");
      appendMessage("system", "AI 修改已应用");
      showToast("修改已应用", "success");
    } catch {
      // saveDraft 已展示具体错误并保留当前草稿。
    } finally {
      setBusy(false);
      busyRef.current = false;
    }
  }, [saveDraft, appendMessage, showToast]);

  const discardPreview = useCallback(() => {
    setPreview(null);
    previewRef.current = null;
    const current = workspaceRef.current;
    if (current) {
      setDraft(current.jd);
      draftRef.current = current.jd;
    }
    appendMessage("system", "已放弃本次修改建议");
  }, [appendMessage]);

  const approve = useCallback(async () => {
    if (busyRef.current || workspaceRef.current?.jd_locked) {
      if (workspaceRef.current?.jd_locked) {
        showToast("当前 JD 已锁定，请新建岗位后修改", "warning");
      }
      return;
    }
    if (dirtyRef.current || savingRef.current) {
      try {
        await saveDraft();
      } catch {
        return;
      }
    }
    const current = queryClient.getQueryData<JdWorkspace>(jdWorkspaceQueryKey(pipelineId)) ?? workspaceRef.current;
    if (!current) {
      return;
    }
    const missing = missingChecks(current);
    if (missing.length) {
      setActiveSection("quality");
      setMobileView("document");
      showToast(`请先补充 ${missing.length} 项必需内容`, "warning");
      return;
    }
    setBusy(true);
    busyRef.current = true;
    appendMessage("user", "确认当前 JD，并生成候选人画像");
    setTyping(true);
    try {
      const approvalResult = await approveJd(pipelineId, current.revision);
      revisionRef.current = approvalResult.revision;
      updateWorkspace((ws) => ({
        ...ws,
        revision: approvalResult.revision,
        approval_status: "approved",
        approved_revision: approvalResult.approved_revision,
        workflow: approvalResult.workflow,
      }));
      setTyping(false);
      appendMessage("assistant", "JD 已确认。我正在基于这份内容构建候选人画像。 ");
      setTyping(true);
      await runProfileBuild(pipelineId);
      setTyping(false);
      const fresh = await reloadWorkspace();
      if (!fresh?.profile_is_current || !Object.keys(fresh.profile.dimensions ?? {}).length) {
        throw new Error("画像状态未同步；如 JD 已修改，请重新确认并生成画像");
      }
      setActiveSection("profile");
      appendMessage("assistant", "22维候选人画像已生成。核心人才特征已经整理完成，你可以在这里展开查看。", {
        type: "profile",
        profile: fresh.profile,
      });
      setMobileView("chat");
    } catch (error) {
      setTyping(false);
      await reloadWorkspace();
      appendMessage("assistant", `确认或画像生成未完成：${error instanceof Error ? error.message : "请求失败"}`);
    } finally {
      setBusy(false);
      busyRef.current = false;
    }
  }, [pipelineId, queryClient, saveDraft, updateWorkspace, appendMessage, showToast, reloadWorkspace]);

  const passDownstream = useCallback(async (): Promise<boolean> => {
    const current = workspaceRef.current;
    const downstream = current?.downstream;
    if (!current || !downstream || busyRef.current || dirtyRef.current || savingRef.current || previewRef.current) {
      return false;
    }
    if (downstream.passed) {
      showToast(`岗位流水线进行中，进入${downstream.name}工作台`, "info");
      return true;
    }
    setBusy(true);
    busyRef.current = true;
    try {
      const result = await passArtifactToDownstream(pipelineId, downstream.agent_id, {
        jd_write: { jd: current.jd },
        profile_build: { profile: current.profile },
      });
      await reloadWorkspace();
      appendMessage(
        "assistant",
        `岗位流水线已开始，JD 和候选人画像已传递给${result.to_name}。你可以进入下游工作台继续处理。`,
        { type: "open_agent", agentId: result.to_agent, label: `前往${result.to_name}` },
      );
      showToast(`岗位流水线已开始，正在进入${result.to_name}工作台`, "success");
      return true;
    } catch (error) {
      showToast(error instanceof Error ? error.message : "传递失败", "error");
      return false;
    } finally {
      setBusy(false);
      busyRef.current = false;
    }
  }, [pipelineId, appendMessage, showToast, reloadWorkspace]);

  /** 质量检查「去补充」：切到编辑器并聚焦对应字段。对应旧版 focusField。 */
  const requestFieldFocus = useCallback((field: string) => {
    setActiveSection("editor");
    setMobileView("document");
    setFocusRequest({ field, nonce: Date.now() });
  }, []);

  /** 切换文档区 tab；移动端同时切到文档视图。 */
  const openDocumentSection = useCallback((section: DocumentSection) => {
    setActiveSection(section);
    setMobileView("document");
  }, []);

  const copyJd = useCallback(async () => {
    const currentDraft = draftRef.current;
    if (!Object.keys(currentDraft).length) {
      return;
    }
    try {
      await navigator.clipboard.writeText(buildJdCopyText(normalizeDraftForSave(currentDraft)));
      showToast("JD 已复制", "success");
    } catch {
      showToast("复制失败，请检查浏览器权限", "error");
    }
  }, [showToast]);

  const clonePipeline = useCallback(async (): Promise<string | null> => {
    if (busyRef.current) {
      return null;
    }
    setBusy(true);
    busyRef.current = true;
    try {
      const result = await cloneJdPipeline(pipelineId);
      showToast("已复制岗位，可以继续修改", "success");
      return result.pipeline_id || null;
    } catch (error) {
      showToast(error instanceof Error ? error.message : "复制岗位失败", "error");
      return null;
    } finally {
      setBusy(false);
      busyRef.current = false;
    }
  }, [pipelineId, showToast]);

  const autoDraftBusy = autoDraft.status === "running" || autoDraft.status === "waiting";
  const missingCount = missingChecks(workspace).length;
  const approved = isApproved(workspace);
  const jdReady = hasJd(workspace);
  const jdLocked = Boolean(workspace?.jd_locked);
  const profileReady = Boolean(workspace?.profile_is_current);
  const profileBuilding = workspace?.profile_status === "running";
  const canApprove =
    !jdLocked && canGenerateProfile(workspace, { busy: busy || saving, dirty, preview: Boolean(preview) });
  const approveLabel = approved && !profileReady ? "生成画像" : "确认并生成画像";
  const approveTitle = jdLocked
    ? "当前 JD 已锁定，请新建岗位后修改"
    : missingCount
      ? `还有 ${missingCount} 项内容待补充`
      : profileReady
        ? "当前 JD 与候选人画像已完成"
        : profileBuilding
          ? "候选人画像正在生成，请稍候"
          : approved
            ? "当前 JD 已确认，可继续生成候选人画像"
            : "确认 JD 并生成候选人画像";

  return {
    workspace,
    workspaceQuery,
    messages,
    typing,
    activeSection,
    setActiveSection,
    mobileView,
    setMobileView,
    previewOpen,
    setPreviewOpen,
    preview,
    draft,
    dirty,
    saving,
    busy,
    saveState,
    autoDraft,
    autoDraftBusy,
    composerValue,
    setComposerValue,
    focusRequest,
    requestFieldFocus,
    openDocumentSection,
    quickPrompts: jdLocked ? QUICK_PROMPTS_EMPTY : jdReady ? QUICK_PROMPTS_REFINE : QUICK_PROMPTS_EMPTY,
    jdLocked,
    approved,
    jdReady,
    canApprove,
    approveLabel,
    approveTitle,
    missingCount,
    updateDraftField,
    updateDraftListItem,
    removeDraftListItem,
    sendMessage,
    applyPreview,
    discardPreview,
    approve,
    passDownstream,
    clonePipeline,
    copyJd,
    retryAutoDraft: () => void startAutoDraft(true),
  };
}
