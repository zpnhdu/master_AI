/** 小文 JD 工作台的文案与分组常量，与旧版 frontend/xiao_wen.html 保持一致。 */

export const FIELD_LABELS: Record<string, string> = {
  title: "岗位名称",
  department: "所属部门",
  location: "工作地点",
  salary_range: "薪资范围",
  work_hours: "工作时间",
  responsibilities: "岗位职责",
  requirements: "任职要求",
  tech_stack: "关键技能",
  benefits: "福利待遇",
  team_intro: "团队介绍",
};

export const PROFILE_LABELS: Record<string, string> = {
  location: "工作地点",
  salary_expectation: "薪资期望",
  availability: "到岗时间",
  work_mode: "工作模式",
  degree: "学历",
  school_tier: "院校背景",
  major: "专业方向",
  certifications: "专业证书",
  years: "工作年限",
  industry: "行业经验",
  company_tier: "公司背景",
  role_progression: "职业发展",
  project_scale: "项目规模",
  tech_stack: "专业技能",
  soft_skills: "软技能",
  language: "语言能力",
  domain_expertise: "领域知识",
  leadership_experience: "管理经验",
  work_style: "工作风格",
  team_size_preference: "团队偏好",
  growth_orientation: "成长导向",
  values: "价值观",
};

export type ProfileGroup = {
  name: string;
  keys: string[];
};

export const PROFILE_GROUPS: ProfileGroup[] = [
  { name: "基础条件", keys: ["location", "salary_expectation", "availability", "work_mode"] },
  { name: "教育背景", keys: ["degree", "school_tier", "major", "certifications"] },
  { name: "工作经验", keys: ["years", "industry", "company_tier", "role_progression", "project_scale"] },
  {
    name: "专业能力",
    keys: ["tech_stack", "soft_skills", "language", "domain_expertise", "leadership_experience"],
  },
  { name: "文化与潜力", keys: ["work_style", "team_size_preference", "growth_orientation", "values"] },
];

export const FLOW_ICONS: Record<string, string> = {
  jd_write: "JD",
  profile_build: "像",
  poster_gen: "海",
  crawl: "寻",
  match: "筛",
  interview_gen: "面",
  video_assess: "视",
  report: "评",
};

export const QUICK_PROMPTS_EMPTY = ["工作地点在上海", "薪资范围 12-18K", "需要 3 年相关经验", "强调门店管理经验"];

export const QUICK_PROMPTS_REFINE = ["让职责更量化", "降低任职门槛", "补充差异化福利", "语气更有吸引力"];

export const AUTO_DRAFT_MESSAGE = "请先根据岗位名称和现有招聘上下文生成一版完整、可编辑的JD初稿。";

/** 语音录制上限（秒），与旧版保持一致。 */
export const VOICE_MAX_SECONDS = 60;
