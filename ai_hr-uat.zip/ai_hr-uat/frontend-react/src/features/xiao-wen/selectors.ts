import { FIELD_LABELS, PROFILE_GROUPS, PROFILE_LABELS } from "./constants";
import type { CandidateProfile, JdDocument, JdWorkspace, ProfileDimension, WorkflowItem } from "./api";

const JD_CONTENT_FIELDS = [
  "title",
  "department",
  "location",
  "salary_range",
  "responsibilities",
  "requirements",
  "tech_stack",
  "benefits",
  "team_intro",
] as const;

export function hasJd(workspace: JdWorkspace | null | undefined): boolean {
  const jd = workspace?.jd;
  if (!jd || jd.parse_error === true || jd.error) {
    return false;
  }
  return JD_CONTENT_FIELDS.some((field) => {
    const value = jd[field];
    return Array.isArray(value) ? value.length > 0 : Boolean(value);
  });
}

export function isApproved(workspace: JdWorkspace | null | undefined): boolean {
  return workspace?.approval_status === "approved";
}

export function findWorkflowItem(workspace: JdWorkspace | null | undefined, stageId: string): WorkflowItem | undefined {
  return workspace?.workflow.flatMap((group) => group.items).find((item) => item.stage_id === stageId);
}

export function jdStageStatus(workspace: JdWorkspace | null | undefined): string {
  return findWorkflowItem(workspace, "jd_write")?.status ?? "pending";
}

export function missingChecks(workspace: JdWorkspace | null | undefined) {
  return (workspace?.quality_checks ?? []).filter((item) => item.status === "missing");
}

export function canGenerateProfile(
  workspace: JdWorkspace | null | undefined,
  options: { busy: boolean; dirty: boolean; preview: boolean },
): boolean {
  return Boolean(
    workspace &&
    hasJd(workspace) &&
    !workspace.profile_is_current &&
    workspace.profile_status !== "running" &&
    // 初稿阶段允许点击；缺失字段由 approve 流程切到质量检查并提示补充。
    !options.busy &&
    !options.dirty &&
    !options.preview,
  );
}

/** 仅返回右侧编辑器可展示且实际发生变化的 JD 字段。 */
export function changedJdFields(previous: JdDocument, next: JdDocument, reportedFields: string[] = []): string[] {
  const supportedFields = Object.keys(FIELD_LABELS);
  const changed = supportedFields.filter((field) => JSON.stringify(previous[field]) !== JSON.stringify(next[field]));
  const reported = reportedFields.filter((field) => supportedFields.includes(field) && changed.includes(field));
  return [...new Set([...reported, ...changed])];
}

/** 画像维度推荐值的展示文本，支持字符串、数组和 {min,max} 区间。 */
export function recommendedText(value: unknown): string {
  if (value == null || value === "") {
    return "待确认";
  }
  if (Array.isArray(value)) {
    return value.join("、");
  }
  if (typeof value === "object") {
    const record = value as Record<string, unknown>;
    if (record.min != null || record.max != null) {
      return `${record.min ?? ""}-${record.max ?? ""}年`;
    }
    return Object.values(record).join("、");
  }
  return String(value);
}

function dimensionEntries(profile: CandidateProfile | null | undefined) {
  return Object.entries(profile?.dimensions ?? {}) as [string, ProfileDimension][];
}

/** 按权重取前 count 个高优先级特征。 */
export function topPriorities(profile: CandidateProfile | null | undefined, count = 4) {
  return dimensionEntries(profile)
    .map(([key, value]) => ({ key, weight: Number(value.weight || 0) }))
    .sort((left, right) => right.weight - left.weight)
    .slice(0, count);
}

/** 雷达图数值：每个画像分组内维度权重的平均值（0-100）。 */
export function profileRadarValues(profile: CandidateProfile | null | undefined): number[] {
  const dimensions = profile?.dimensions ?? {};
  return PROFILE_GROUPS.map((group) => {
    const weights = group.keys.filter((key) => dimensions[key]).map((key) => Number(dimensions[key].weight || 0));
    if (!weights.length) {
      return 0;
    }
    return Math.round((weights.reduce((sum, weight) => sum + weight, 0) / weights.length) * 100);
  });
}

export const PROFILE_RADAR_LABELS = PROFILE_GROUPS.map((group) => group.name);

export type ProfileListItem = {
  key: string;
  name: string;
  weight: number;
  description: string;
};

/** 候选人画像 tab 的列表模型；dimensions 已在 api 层归一为对象形态。 */
export function profileListItems(profile: CandidateProfile | null | undefined): ProfileListItem[] {
  return Object.entries(profile?.dimensions ?? {}).map(([key, dimension]) => {
    const description =
      (typeof dimension.description === "string" && dimension.description) ||
      (typeof dimension.criteria === "string" && dimension.criteria) ||
      (typeof dimension.requirement === "string" && dimension.requirement) ||
      recommendedText(dimension.recommended);
    return {
      key,
      name: PROFILE_LABELS[key] || key || "画像维度",
      weight: Number(dimension.weight || 0),
      description,
    };
  });
}

/** 复制 JD 的纯文本格式，与旧版 copyJD 保持一致。 */
export function buildJdCopyText(jd: JdDocument): string {
  const lines = [
    jd.title,
    [jd.department, jd.location, jd.salary_range].filter(Boolean).join(" · "),
    "",
    "岗位职责",
    ...(jd.responsibilities ?? []).map((item, index) => `${index + 1}. ${item}`),
    "",
    "任职要求",
    ...(jd.requirements ?? []).map((item, index) => `${index + 1}. ${item}`),
    "",
    "福利待遇",
    ...(jd.benefits ?? []).map((item) => `- ${item}`),
  ];
  return lines.filter((line) => line !== undefined).join("\n");
}

export function formatVoiceTime(totalSeconds: number): string {
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}
