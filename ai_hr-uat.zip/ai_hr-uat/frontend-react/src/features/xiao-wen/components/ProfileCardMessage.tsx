import { useState } from 'react';

import type { CandidateProfile } from '../api';
import { PROFILE_GROUPS, PROFILE_LABELS } from '../constants';
import {
  PROFILE_RADAR_LABELS,
  profileRadarValues,
  recommendedText,
  topPriorities,
} from '../selectors';
import { ProfileRadar } from './ProfileRadar';

type ProfileCardMessageProps = {
  profile: CandidateProfile;
  onOpenProfile: () => void;
};

/** 对话流中的 22 维候选人画像卡片。 */
export function ProfileCardMessage({
  profile,
  onOpenProfile,
}: ProfileCardMessageProps) {
  const [expanded, setExpanded] = useState(false);
  const dimensions = profile.dimensions ?? {};
  if (!Object.keys(dimensions).length) {
    return null;
  }

  const priorities = topPriorities(profile);
  return (
    <div className={`xw-profile-message-card${expanded ? ' expanded' : ''}`}>
      <div className="xw-profile-card-head">
        <div>
          <strong>22维候选人画像</strong>
          <span>已提炼岗位的核心人才特征</span>
        </div>
        <span className="xw-profile-status">已生成</span>
      </div>
      <div className="xw-profile-card-summary">
        <div className="xw-profile-radar">
          <ProfileRadar values={profileRadarValues(profile)} labels={PROFILE_RADAR_LABELS} />
        </div>
        <div className="xw-profile-priorities">
          <div className="xw-profile-priorities-title">高优先级特征</div>
          {priorities.map((item) => (
            <div className="xw-priority-row" key={item.key}>
              <span className="xw-priority-name">{PROFILE_LABELS[item.key] || item.key}</span>
              <span className="xw-priority-score">{Math.round(item.weight * 100)}%</span>
              <div className="xw-priority-track">
                <div
                  className="xw-priority-fill"
                  style={{ width: `${Math.round(item.weight * 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="xw-profile-dimensions">
        {PROFILE_GROUPS.map((group) => {
          const items = group.keys.filter((key) => dimensions[key]);
          if (!items.length) {
            return null;
          }
          return (
            <div className="xw-dimension-group" key={group.name}>
              <div className="xw-dimension-group-title">{group.name}</div>
              <div className="xw-dimension-grid">
                {items.map((key) => {
                  const dimension = dimensions[key];
                  const text = recommendedText(dimension.recommended);
                  return (
                    <div className="xw-dimension-chip" key={key} title={text}>
                      <strong>{PROFILE_LABELS[key] || key}</strong>
                      <span>{text}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      <div className="xw-profile-card-actions">
        <button className="xw-button small" type="button" onClick={() => setExpanded(!expanded)}>
          {expanded ? '收起全部维度' : '展开全部维度'}
        </button>
        <button className="xw-button small" type="button" onClick={onOpenProfile}>
          查看完整画像
        </button>
      </div>
    </div>
  );
}
