import { useEffect, useRef } from 'react';

import { formatVoiceTime } from '../selectors';
import type { ChatMessage } from '../useXiaoWenController';
import type { VoiceNoticeType, VoiceStatus } from '../useVoiceRecorder';
import { ProfileCardMessage } from './ProfileCardMessage';

type ChatPaneProps = {
  role: string;
  messages: ChatMessage[];
  typing: boolean;
  autoDraftBusy: boolean;
  hasJd: boolean;
  quickPrompts: string[];
  composerValue: string;
  composerDisabled: boolean;
  activePreviewId: string | null;
  voiceSupported: boolean;
  voiceStatus: VoiceStatus;
  voiceSeconds: number;
  voiceNotice: string;
  voiceNoticeType: VoiceNoticeType;
  voiceBusy: boolean;
  onComposerChange: (value: string) => void;
  onSend: () => void;
  onToggleVoice: () => void;
  onApplyPreview: () => void;
  onDiscardPreview: () => void;
  onOpenProfile: () => void;
  onOpenAgent: (agentId: string) => void;
  jdLocked?: boolean;
};

const COMPOSER_MAX_HEIGHT = 140;

/** 左侧对话区：欢迎语、消息流（含画像/建议卡片）、快捷提示与输入框。 */
export function ChatPane({
  role,
  messages,
  typing,
  autoDraftBusy,
  hasJd,
  quickPrompts,
  composerValue,
  composerDisabled,
  activePreviewId,
  voiceSupported,
  voiceStatus,
  voiceSeconds,
  voiceNotice,
  voiceNoticeType,
  voiceBusy,
  onComposerChange,
  onSend,
  onToggleVoice,
  onApplyPreview,
  onDiscardPreview,
  onOpenProfile,
  onOpenAgent,
  jdLocked = false,
}: ChatPaneProps) {
  const messagesRef = useRef<HTMLDivElement>(null);
  const composerRef = useRef<HTMLTextAreaElement>(null);

  // 新消息或 typing 变化时滚到底部，对齐旧版 scrollMessages。
  useEffect(() => {
    const element = messagesRef.current;
    if (element) {
      element.scrollTop = element.scrollHeight;
    }
  }, [messages, typing]);

  // 输入框随内容自动增高，对齐旧版 resizeComposer。
  useEffect(() => {
    const element = composerRef.current;
    if (!element) {
      return;
    }
    element.style.height = 'auto';
    element.style.height = `${Math.min(element.scrollHeight, COMPOSER_MAX_HEIGHT)}px`;
  }, [composerValue]);

  const welcomeText = jdLocked
    ? '当前 JD 已传递给下游并锁定，岗位流水线正在进行中。如需调整，请新建岗位。'
    : autoDraftBusy
    ? '我先根据岗位名称准备一版可编辑草稿，生成后你可以继续补充和调整。'
    : hasJd
      ? '右侧是当前生效草稿。你可以直接编辑，也可以告诉我希望怎么调整；AI 修改会先给你预览。'
      : '告诉我工作地点、薪资、经验要求或业务目标，我会先生成一版结构化草稿。信息不完整也可以开始。';

  const recording = voiceStatus === 'recording';
  const transcribing = voiceStatus === 'transcribing';
  const voiceStatusText = recording
    ? `正在录音 ${formatVoiceTime(voiceSeconds)}，点击停止`
    : transcribing
      ? '语音转文字中，请稍候...'
      : voiceNotice;
  const composerPlaceholder = autoDraftBusy
    ? '小文正在准备 JD，生成后即可继续补充要求'
    : '补充岗位要求，例如：工作地点在上海，薪资 12-18K';

  const handleQuickPrompt = (text: string) => {
    onComposerChange(text);
    composerRef.current?.focus();
  };

  return (
    <section className="xw-chat-pane" aria-label="与小文对话">
      <div className="xw-pane-heading">
        <strong>与小文对话</strong>
        <span className={`xw-online${jdLocked ? ' locked' : ''}`}>{jdLocked ? 'JD 已锁定' : '可继续修改'}</span>
      </div>
      <div className="xw-messages" ref={messagesRef} aria-live="polite">
        <div className="xw-welcome-block">
          <h2>一起完善「{role}」的招聘 JD</h2>
          <p>{welcomeText}</p>
        </div>
        {messages.map((message) => {
          if (message.role === 'system') {
            return (
              <div className="xw-system-message" key={message.id}>
                {message.content}
              </div>
            );
          }
          const card = message.card;
          return (
            <div className={`xw-message ${message.role}`} key={message.id}>
              {message.role === 'assistant' && <div className="xw-avatar">文</div>}
              <div className="xw-message-body">
                <div className="xw-sender">{message.role === 'user' ? '你' : '小文'}</div>
                <div className="xw-bubble">{message.content}</div>
                {card?.type === 'profile' && (
                  <ProfileCardMessage
                    profile={card.profile}
                    onOpenProfile={onOpenProfile}
                  />
                )}
                {card?.type === 'proposal' && (
                  <div className="xw-proposal">
                    <div className="xw-proposal-title">修改建议已准备</div>
                    <div className="xw-field-tags">
                      {card.labels.map((label) => (
                        <span className="xw-field-tag" key={label}>
                          {label}
                        </span>
                      ))}
                    </div>
                    <div className="xw-proposal-actions">
                      <button
                        className="xw-button primary small"
                        type="button"
                        disabled={jdLocked || activePreviewId !== card.previewId}
                        onClick={onApplyPreview}
                      >
                        应用修改
                      </button>
                      <button
                        className="xw-button small"
                        type="button"
                        disabled={activePreviewId !== card.previewId}
                        onClick={onDiscardPreview}
                      >
                        放弃
                      </button>
                    </div>
                  </div>
                )}
                {card?.type === 'open_agent' && (
                  <div className="xw-proposal">
                    <div className="xw-proposal-actions">
                      <button
                        className="xw-button primary small"
                        type="button"
                        onClick={() => onOpenAgent(card.agentId)}
                      >
                        {card.label}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        {typing && (
          <div className="xw-message assistant">
            <div className="xw-avatar">文</div>
            <div className="xw-message-body">
              <div className="xw-sender">小文</div>
              <div className="xw-bubble">
                <span className="xw-typing">
                  <i />
                  <i />
                  <i />
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="xw-composer-wrap">
        <div className="xw-quick-prompts">
          {quickPrompts.map((prompt) => (
            <button
              className="xw-prompt-chip"
              type="button"
              key={prompt}
              onClick={() => handleQuickPrompt(prompt)}
            >
              {prompt}
            </button>
          ))}
        </div>
        <div className="xw-composer">
          <textarea
            ref={composerRef}
            rows={1}
            value={composerValue}
            placeholder={composerPlaceholder}
            disabled={composerDisabled}
            onChange={(event) => onComposerChange(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                onSend();
              }
            }}
          />
          <button
            className={`xw-voice-button${recording ? ' recording' : ''}`}
            type="button"
            title={recording ? '停止录音' : '开始录音'}
            aria-label={recording ? '停止录音' : '开始录音'}
            disabled={jdLocked || !voiceSupported || voiceBusy || transcribing}
            onClick={onToggleVoice}
          >
            {recording ? '■' : '🎙'}
          </button>
          <button
            className="xw-send-button"
            type="button"
            title="发送"
            aria-label="发送"
            disabled={composerDisabled}
            onClick={onSend}
          >
            ↑
          </button>
        </div>
        <div className="xw-composer-meta">
          <span
            className={`xw-voice-status${voiceNoticeType ? ` ${voiceNoticeType}` : ''}${
              recording ? ' recording' : ''
            }`}
            role="status"
            aria-live="polite"
          >
            {voiceStatusText}
          </span>
          <span className="xw-composer-help">Enter 发送，Shift + Enter 换行</span>
        </div>
      </div>
    </section>
  );
}
