import { useEffect } from 'react';

import type { JdDocument } from '../api';
import { FIELD_LABELS } from '../constants';

type PreviewModalProps = {
  open: boolean;
  /** 预览展示当前草稿（含未保存的编辑），对齐旧版 collectJD 语义。 */
  draft: JdDocument;
  onClose: () => void;
};

function previewText(value: unknown): string {
  if (Array.isArray(value)) {
    return value.filter(Boolean).join('、') || '未填写';
  }
  return value == null || value === '' ? '未填写' : String(value);
}

function PreviewField({ label, value }: { label: string; value: unknown }) {
  return (
    <div className="xw-preview-jd-field">
      <label>{label}</label>
      <span>{previewText(value)}</span>
    </div>
  );
}

function PreviewListSection({ label, values }: { label: string; values: unknown }) {
  const items = Array.isArray(values)
    ? values.filter((item): item is string => typeof item === 'string' && Boolean(item))
    : typeof values === 'string' && values
      ? [values]
      : [];
  return (
    <section className="xw-preview-jd-section">
      <h3>{label}</h3>
      {items.length ? (
        <ul className="xw-preview-jd-list">
          {items.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      ) : (
        <div className="xw-preview-jd-field">
          <span>未填写</span>
        </div>
      )}
    </section>
  );
}

/** JD 完整内容预览弹层；Esc 或点击遮罩关闭。 */
export function PreviewModal({ open, draft, onClose }: PreviewModalProps) {
  useEffect(() => {
    if (!open) {
      return;
    }
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) {
    return null;
  }

  const meta = [draft.department, draft.location, draft.salary_range, draft.work_hours]
    .filter((item): item is string => typeof item === 'string' && Boolean(item))
    .join(' · ');

  return (
    <div
      className="xw-preview-overlay active"
      role="presentation"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          onClose();
        }
      }}
    >
      <section
        className="xw-preview-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="xw-preview-title"
      >
        <header className="xw-preview-modal-head">
          <div>
            <strong id="xw-preview-title">JD 预览</strong>
            <span>完整内容预览</span>
          </div>
          <button
            className="xw-preview-modal-close"
            type="button"
            aria-label="关闭预览"
            onClick={onClose}
          >
            ×
          </button>
        </header>
        <div className="xw-preview-modal-body">
          <h2 className="xw-preview-jd-title">{draft.title || '未命名岗位'}</h2>
          <div className="xw-preview-jd-meta">{meta || '岗位信息待补充'}</div>
          <section className="xw-preview-jd-section">
            <h3>岗位信息</h3>
            <div className="xw-preview-jd-grid">
              <PreviewField label={FIELD_LABELS.department} value={draft.department} />
              <PreviewField label={FIELD_LABELS.location} value={draft.location} />
              <PreviewField label={FIELD_LABELS.salary_range} value={draft.salary_range} />
              <PreviewField label={FIELD_LABELS.work_hours} value={draft.work_hours} />
            </div>
          </section>
          <PreviewListSection label={FIELD_LABELS.responsibilities} values={draft.responsibilities} />
          <PreviewListSection label={FIELD_LABELS.requirements} values={draft.requirements} />
          <PreviewListSection label={FIELD_LABELS.tech_stack} values={draft.tech_stack} />
          <PreviewListSection label={FIELD_LABELS.benefits} values={draft.benefits} />
          <section className="xw-preview-jd-section">
            <h3>{FIELD_LABELS.team_intro}</h3>
            <div className="xw-preview-jd-text">{previewText(draft.team_intro)}</div>
          </section>
        </div>
        <footer className="xw-preview-modal-foot">
          <button className="xw-button small" type="button" onClick={onClose}>
            关闭
          </button>
        </footer>
      </section>
    </div>
  );
}
