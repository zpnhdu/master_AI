import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { DocumentPane } from "./DocumentPane";

describe("DocumentPane", () => {
  afterEach(cleanup);

  it("exposes an append row and remove controls for JD list fields", () => {
    const onUpdateListItem = vi.fn();
    const onRemoveListItem = vi.fn();
    render(
      <DocumentPane
        activeSection="editor"
        onSectionChange={vi.fn()}
        role="店长"
        draft={{
          title: "门店店长",
          responsibilities: ["负责经营目标", "管理门店团队"],
          requirements: ["两年经验"],
          tech_stack: [],
          benefits: [],
        }}
        changedFields={[]}
        autoDraftStatus="success"
        autoDraftError=""
        qualityChecks={[]}
        profile={{}}
        approved={false}
        saveState={{ type: "", text: "所有更改已保存" }}
        previewDisabled={false}
        focusRequest={null}
        onCopy={vi.fn()}
        onOpenPreview={vi.fn()}
        onRetryAutoDraft={vi.fn()}
        onFixField={vi.fn()}
        onUpdateField={vi.fn()}
        onUpdateListItem={onUpdateListItem}
        onRemoveListItem={onRemoveListItem}
      />,
    );

    fireEvent.change(screen.getByRole("textbox", { name: "岗位职责第3项" }), {
      target: { value: "复盘经营数据" },
    });
    fireEvent.click(screen.getByRole("button", { name: "删除岗位职责第2项" }));

    expect(onUpdateListItem).toHaveBeenCalledWith("responsibilities", 2, "复盘经营数据");
    expect(onRemoveListItem).toHaveBeenCalledWith("responsibilities", 1);
  });

  it("keeps the copy action in the document area", () => {
    const onCopy = vi.fn();
    render(
      <DocumentPane
        activeSection="editor"
        onSectionChange={vi.fn()}
        role="店长"
        draft={{ title: "门店店长" }}
        changedFields={[]}
        autoDraftStatus="success"
        autoDraftError=""
        qualityChecks={[{ field: "title", label: "岗位名称", status: "ready", message: "已填写" }]}
        profile={{}}
        approved={false}
        saveState={{ type: "", text: "所有更改已保存" }}
        previewDisabled={false}
        focusRequest={null}
        onCopy={onCopy}
        onOpenPreview={vi.fn()}
        onRetryAutoDraft={vi.fn()}
        onFixField={vi.fn()}
        onUpdateField={vi.fn()}
        onUpdateListItem={vi.fn()}
        onRemoveListItem={vi.fn()}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "复制 JD" }));

    expect(onCopy).toHaveBeenCalledTimes(1);
  });

  it("makes a locked JD read-only and hides the clone action", () => {
    render(
      <DocumentPane
        activeSection="editor"
        onSectionChange={vi.fn()}
        role="店长"
        draft={{ title: "门店店长", responsibilities: ["负责经营目标"] }}
        changedFields={[]}
        autoDraftStatus="success"
        autoDraftError=""
        qualityChecks={[{ field: "location", label: "工作地点", status: "missing", message: "请填写工作地点" }]}
        profile={{}}
        approved
        saveState={{ type: "", text: "所有更改已保存" }}
        previewDisabled={false}
        focusRequest={null}
        locked
        onCopy={vi.fn()}
        onOpenPreview={vi.fn()}
        onRetryAutoDraft={vi.fn()}
        onFixField={vi.fn()}
        onUpdateField={vi.fn()}
        onUpdateListItem={vi.fn()}
        onRemoveListItem={vi.fn()}
      />,
    );

    expect(screen.getByRole("status")).toHaveTextContent("JD 已锁定");
    expect(screen.getByRole("status")).toHaveTextContent("岗位仅支持查看");
    expect(screen.queryByRole("button", { name: "复制岗位并修改" })).not.toBeInTheDocument();
    expect(screen.getByRole("textbox", { name: "岗位名称" })).toBeDisabled();
    expect(screen.queryByRole("button", { name: "去补充" })).not.toBeInTheDocument();

  });
});
