import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ChatPane } from "./ChatPane";

describe("ChatPane", () => {
  afterEach(cleanup);

  it("only enables actions on the currently active AI preview", () => {
    const onApplyPreview = vi.fn();
    render(
      <ChatPane
        role="店长"
        messages={[
          {
            id: "message-a",
            role: "assistant",
            content: "建议 A",
            card: { type: "proposal", labels: ["地点"], previewId: "preview-a" },
          },
          {
            id: "message-b",
            role: "assistant",
            content: "建议 B",
            card: { type: "proposal", labels: ["薪资"], previewId: "preview-b" },
          },
        ]}
        typing={false}
        autoDraftBusy={false}
        hasJd
        quickPrompts={[]}
        composerValue=""
        composerDisabled={false}
        activePreviewId="preview-b"
        voiceSupported={false}
        voiceStatus="idle"
        voiceSeconds={0}
        voiceNotice=""
        voiceNoticeType=""
        voiceBusy={false}
        onComposerChange={vi.fn()}
        onSend={vi.fn()}
        onToggleVoice={vi.fn()}
        onApplyPreview={onApplyPreview}
        onDiscardPreview={vi.fn()}
        onOpenProfile={vi.fn()}
        onOpenAgent={vi.fn()}
      />,
    );

    const applyButtons = screen.getAllByRole("button", { name: "应用修改" });
    expect(applyButtons[0]).toBeDisabled();
    expect(applyButtons[1]).toBeEnabled();

    fireEvent.click(applyButtons[0]);
    fireEvent.click(applyButtons[1]);
    expect(onApplyPreview).toHaveBeenCalledTimes(1);
  });

  it("explains that a locked JD must be copied before editing", () => {
    const onApplyPreview = vi.fn();
    render(
      <ChatPane
        role="店长"
        messages={[
          {
            id: "preview-message",
            role: "assistant",
            content: "建议调整地点",
            card: { type: "proposal", labels: ["工作地点"], previewId: "preview-1" },
          },
        ]}
        typing={false}
        autoDraftBusy={false}
        hasJd
        quickPrompts={[]}
        composerValue=""
        composerDisabled
        activePreviewId="preview-1"
        voiceSupported
        voiceStatus="idle"
        voiceSeconds={0}
        voiceNotice=""
        voiceNoticeType=""
        voiceBusy={false}
        onComposerChange={vi.fn()}
        onSend={vi.fn()}
        onToggleVoice={vi.fn()}
        onApplyPreview={onApplyPreview}
        onDiscardPreview={vi.fn()}
        onOpenProfile={vi.fn()}
        onOpenAgent={vi.fn()}
        jdLocked
      />,
    );

    expect(screen.getByText("JD 已锁定")).toBeInTheDocument();
    expect(screen.getByText("当前 JD 已传递给下游并锁定，岗位流水线正在进行中。如需调整，请新建岗位。")).toBeInTheDocument();
    expect(screen.getByRole("textbox")).toBeDisabled();
    expect(screen.getByRole("button", { name: "开始录音" })).toBeDisabled();
    const applyButton = screen.getByRole("button", { name: "应用修改" });
    expect(applyButton).toBeDisabled();
    fireEvent.click(applyButton);
    expect(onApplyPreview).not.toHaveBeenCalled();
  });
});
