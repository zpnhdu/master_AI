import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import type { ComponentProps } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { XiaoWenTopbar } from './XiaoWenTopbar';

function renderTopbar(overrides: Partial<ComponentProps<typeof XiaoWenTopbar>> = {}) {
  return render(
    <MemoryRouter>
      <XiaoWenTopbar
        role="店长"
        approved
        pipelineId="p1"
        downstreamPassed={false}
        canPass
        passDisabledReason=""
        passLoading={false}
        onPassDownstream={vi.fn()}
        canApprove
        approveLabel="确认并生成画像"
        approveTitle="确认 JD"
        onApprove={vi.fn()}
        {...overrides}
      />
    </MemoryRouter>,
  );
}

describe('XiaoWenTopbar', () => {
  afterEach(() => {
    cleanup();
  });

  it('shows the handoff action and triggers its handler', () => {
    const onPassDownstream = vi.fn();
    renderTopbar({ onPassDownstream });

    fireEvent.click(screen.getByRole('button', { name: '传递给下游' }));

    expect(onPassDownstream).toHaveBeenCalledTimes(1);
  });

  it('changes to enter action after the handoff succeeds', () => {
    renderTopbar({ downstreamPassed: true });

    expect(screen.getByRole('button', { name: '进入下游' })).toBeInTheDocument();
  });

  it('shows the profile generation action in the top bar', () => {
    const onApprove = vi.fn();
    renderTopbar({ onApprove });

    const action = screen.getByRole('button', { name: '确认并生成画像' });
    expect(action).toBeInTheDocument();

    fireEvent.click(action);

    expect(onApprove).toHaveBeenCalledTimes(1);
  });

  it('disables the handoff action when the current data is not ready', () => {
    renderTopbar({ canPass: false, passDisabledReason: '请先确认 JD 并生成候选人画像' });

    expect(screen.getByRole('button', { name: '传递给下游' })).toBeDisabled();
  });

  it('shows the locked JD status and disables approval', () => {
    renderTopbar({ locked: true, canApprove: false });

    expect(screen.getByText('JD 已锁定')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '确认并生成画像' })).toBeDisabled();
  });

  it('does not show redundant navigation or copy actions', () => {
    renderTopbar();

    expect(screen.queryByRole('button', { name: /打开|复制|返回工作室|更多/ })).not.toBeInTheDocument();
  });
});
