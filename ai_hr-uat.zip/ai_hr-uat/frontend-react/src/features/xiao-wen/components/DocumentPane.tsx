import { useEffect, useLayoutEffect, useRef } from 'react';

import type { CandidateProfile, JdDocument, QualityCheck } from '../api';
import { FIELD_LABELS } from '../constants';
import { profileListItems } from '../selectors';
import type {
  AutoDraftStatus,
  DocumentSection,
  FieldFocusRequest,
  SaveState,
} from '../useXiaoWenController';

type DocumentPaneProps = {
  activeSection: DocumentSection;
  onSectionChange: (section: DocumentSection) => void;
  role: string;
  draft: JdDocument;
  changedFields: string[];
  autoDraftStatus: AutoDraftStatus;
  autoDraftError: string;
  qualityChecks: QualityCheck[];
  profile: CandidateProfile;
  approved: boolean;
  saveState: SaveState;
  previewDisabled: boolean;
  focusRequest: FieldFocusRequest | null;
  onCopy: () => void;
  onOpenPreview: () => void;
  onRetryAutoDraft: () => void;
  onFixField: (field: string) => void;
  onUpdateField: (field: string, value: string) => void;
  onUpdateListItem: (field: string, index: number, value: string) => void;
  onRemoveListItem: (field: string, index: number) => void;
  locked?: boolean;
};

const SECTION_HEADINGS: Record<DocumentSection, { title: string; note: string }> = {
  editor: { title: 'JD 文档', note: '逐项编辑，完整展示' },
  quality: { title: '质量检查', note: '补齐必填内容后即可确认' },
  profile: { title: '候选人画像', note: '基于当前 JD 自动整理' },
};

function fieldText(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

type AutoTextareaProps = {
  value: string;
  minHeight: number;
  onChange: (value: string) => void;
} & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'value' | 'onChange'>;

/** 受控 textarea，随内容自动增高，对齐旧版 resizeDocumentTextarea。 */
function AutoTextarea({ value, minHeight, onChange, ...rest }: AutoTextareaProps) {
  const ref = useRef<HTMLTextAreaElement>(null);
  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) {
      return;
    }
    element.style.height = 'auto';
    element.style.height = `${Math.max(element.scrollHeight, minHeight)}px`;
  }, [value, minHeight]);
  return (
    <textarea
      ref={ref}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      {...rest}
    />
  );
}

type TextFieldProps = {
  field: string;
  value: unknown;
  changed: boolean;
  onUpdate: (field: string, value: string) => void;
  disabled?: boolean;
};

function TextField({ field, value, changed, onUpdate, disabled = false }: TextFieldProps) {
  return (
    <div className={`xw-field${changed ? ' changed' : ''}`}>
      <label>
        {FIELD_LABELS[field]}
        {changed && <span className="xw-changed-label">AI 建议</span>}
      </label>
      <input
        data-field={field}
        value={fieldText(value)}
        disabled={disabled}
        onChange={(event) => onUpdate(field, event.target.value)}
      />
    </div>
  );
}

type LineListFieldProps = {
  field: string;
  value: unknown;
  hint: string;
  changed: boolean;
  onUpdateItem: (field: string, index: number, value: string) => void;
  onRemoveItem: (field: string, index: number) => void;
  disabled?: boolean;
};

function LineListField({ field, value, hint, changed, onUpdateItem, onRemoveItem, disabled = false }: LineListFieldProps) {
  const items = Array.isArray(value)
    ? value.filter((item): item is string => typeof item === 'string')
    : typeof value === 'string' && value
      ? [value]
      : [];
  const rows = items.at(-1) === '' ? items : [...items, ''];
  return (
    <div className={`xw-jd-line-field${changed ? ' changed' : ''}`}>
      <div className="xw-jd-line-label">
        <strong>
          {FIELD_LABELS[field]}
          {changed && <span className="xw-changed-label"> AI 建议</span>}
        </strong>
        <span>{hint}</span>
      </div>
      <div className="xw-jd-line-list">
        {rows.map((item, index) => {
          const appendRow = index >= items.length;
          return (
            <div className="xw-jd-line-row" key={index}>
              <span className="xw-jd-line-index">{index + 1}</span>
              <AutoTextarea
                data-field-list={field}
                aria-label={`${FIELD_LABELS[field]}第${index + 1}项`}
                rows={1}
                minHeight={34}
                value={item}
                placeholder={appendRow ? '输入新一项' : undefined}
                disabled={disabled}
                onChange={(next) => onUpdateItem(field, index, next)}
              />
              {appendRow ? (
                <span aria-hidden="true" />
              ) : (
                <button
                  className="xw-jd-line-remove"
                  type="button"
                  disabled={disabled}
                  aria-label={`删除${FIELD_LABELS[field]}第${index + 1}项`}
                  onClick={() => onRemoveItem(field, index)}
                >
                  ×
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

type JdEditorProps = {
  role: string;
  draft: JdDocument;
  changedFields: string[];
  autoDraftStatus: AutoDraftStatus;
  autoDraftError: string;
  onRetryAutoDraft: () => void;
  onUpdateField: (field: string, value: string) => void;
  onUpdateListItem: (field: string, index: number, value: string) => void;
  onRemoveListItem: (field: string, index: number) => void;
  readOnly?: boolean;
};

function JdEditor({
  role,
  draft,
  changedFields,
  autoDraftStatus,
  autoDraftError,
  onRetryAutoDraft,
  onUpdateField,
  onUpdateListItem,
  onRemoveListItem,
  readOnly = false,
}: JdEditorProps) {
  if (!Object.keys(draft).length) {
    if (autoDraftStatus === 'running' || autoDraftStatus === 'waiting') {
      const waiting = autoDraftStatus === 'waiting';
      return (
        <div className="xw-auto-draft-state" aria-live="polite">
          <div className="xw-auto-draft-card">
            <div className="xw-auto-draft-orb" aria-hidden="true">
              文
            </div>
            <strong>{waiting ? '正在接收小文的初稿' : `小文正在为「${role}」准备 JD`}</strong>
            <p>
              {waiting ? '已有生成任务在处理中，页面会自动更新' : '正在结合岗位信息整理职责、要求和福利'}
              <span className="xw-auto-draft-dots" aria-hidden="true">
                <i />
                <i />
                <i />
              </span>
            </p>
          </div>
        </div>
      );
    }
    if (autoDraftStatus === 'error') {
      return (
        <div className="xw-auto-draft-state">
          <div className="xw-auto-draft-card error">
            <div className="xw-auto-draft-orb" aria-hidden="true">
              !
            </div>
            <strong>这次初稿没有生成成功</strong>
            <p>{autoDraftError || '可以稍后重试，或直接在左侧告诉小文岗位要求'}</p>
            <button
              className="xw-button primary small xw-auto-draft-retry"
              type="button"
              disabled={readOnly}
              onClick={onRetryAutoDraft}
            >
              重新生成初稿
            </button>
          </div>
        </div>
      );
    }
    return (
      <div className="xw-empty-document">
        <div>
          <strong>JD 将在这里实时生成</strong>
          <span>先在左侧描述岗位要求</span>
        </div>
      </div>
    );
  }

  const changed = (field: string) => changedFields.includes(field);
  return (
    <>
      <div className={`xw-document-title${changed('title') ? ' changed' : ''}`}>
        <input
          data-field="title"
          aria-label="岗位名称"
          value={fieldText(draft.title)}
          disabled={readOnly}
          onChange={(event) => onUpdateField('title', event.target.value)}
        />
      </div>
      <div className="xw-field-grid">
        <TextField field="department" value={draft.department} changed={changed('department')} onUpdate={onUpdateField} disabled={readOnly} />
        <TextField field="location" value={draft.location} changed={changed('location')} onUpdate={onUpdateField} disabled={readOnly} />
        <TextField field="salary_range" value={draft.salary_range} changed={changed('salary_range')} onUpdate={onUpdateField} disabled={readOnly} />
        <TextField field="work_hours" value={draft.work_hours} changed={changed('work_hours')} onUpdate={onUpdateField} disabled={readOnly} />
      </div>
      <h3 className="xw-section-heading">岗位内容</h3>
      <div className="xw-jd-line-grid">
        <LineListField
          field="responsibilities"
          value={draft.responsibilities}
          hint="每行一条，至少 3 条"
          changed={changed('responsibilities')}
          onUpdateItem={onUpdateListItem}
          onRemoveItem={onRemoveListItem}
          disabled={readOnly}
        />
        <LineListField
          field="requirements"
          value={draft.requirements}
          hint="每行一条，至少 3 条"
          changed={changed('requirements')}
          onUpdateItem={onUpdateListItem}
          onRemoveItem={onRemoveListItem}
          disabled={readOnly}
        />
        <LineListField
          field="tech_stack"
          value={draft.tech_stack}
          hint="每行一项"
          changed={changed('tech_stack')}
          onUpdateItem={onUpdateListItem}
          onRemoveItem={onRemoveListItem}
          disabled={readOnly}
        />
        <LineListField
          field="benefits"
          value={draft.benefits}
          hint="每行一项"
          changed={changed('benefits')}
          onUpdateItem={onUpdateListItem}
          onRemoveItem={onRemoveListItem}
          disabled={readOnly}
        />
        <div className={`xw-field full${changed('team_intro') ? ' changed' : ''}`}>
          <label>
            {FIELD_LABELS.team_intro}
            {changed('team_intro') && <span className="xw-changed-label">AI 建议</span>}
          </label>
          <AutoTextarea
            data-field="team_intro"
            placeholder="介绍团队、门店或工作场景"
            minHeight={38}
            value={fieldText(draft.team_intro)}
            disabled={readOnly}
            onChange={(next) => onUpdateField('team_intro', next)}
          />
        </div>
      </div>
    </>
  );
}

function QualityPanel({
  checks,
  onFixField,
  locked = false,
}: {
  checks: QualityCheck[];
  onFixField: (field: string) => void;
  locked?: boolean;
}) {
  const ready = checks.filter((item) => item.status === 'ready').length;
  return (
    <>
      <div className="xw-quality-summary">
        <div>
          <strong>
            {ready}/{checks.length}
          </strong>
          <span> 项已准备</span>
        </div>
        <span>
          {locked ? 'JD 已锁定，当前岗位不可修改' : ready === checks.length ? '可以确认 JD' : '补齐后可确认并生成画像'}
        </span>
      </div>
      <ul className="xw-quality-list">
        {checks.map((item) => (
          <li className={`xw-quality-item ${item.status}`} key={item.field}>
            <span className="xw-quality-icon">{item.status === 'ready' ? '✓' : '!'}</span>
            <div className="xw-quality-detail">
              <strong>{item.label}</strong>
              <span>{item.message}</span>
            </div>
            {item.status === 'missing' && !locked && (
              <button className="xw-fix-button" type="button" onClick={() => onFixField(item.field)}>
                去补充
              </button>
            )}
          </li>
        ))}
      </ul>
    </>
  );
}

function ProfilePanel({ profile, approved }: { profile: CandidateProfile; approved: boolean }) {
  const items = profileListItems(profile);
  if (!items.length) {
    return (
      <div className="xw-empty-document">
        <div>
          <strong>{approved ? '画像正在等待生成' : '确认 JD 后生成画像'}</strong>
          <span>确认 JD 后会自动整理候选人特征</span>
        </div>
      </div>
    );
  }
  return (
    <>
      <div className="xw-quality-summary">
        <div>
          <strong>{items.length}</strong>
          <span> 个画像维度</span>
        </div>
        <span>基于当前 JD</span>
      </div>
      <h3 className="xw-section-heading">优先人才特征</h3>
      <div className="xw-profile-list">
        {items.map((item) => (
          <div className="xw-profile-item" key={item.key}>
            <div className="xw-profile-head">
              <strong>{item.name}</strong>
              {item.weight ? (
                <span className="xw-weight">
                  {Math.round(item.weight <= 1 ? item.weight * 100 : item.weight)}%
                </span>
              ) : null}
            </div>
            {item.description ? <p>{item.description}</p> : null}
          </div>
        ))}
      </div>
    </>
  );
}

/** 右侧 JD 工作台：tab 切换（文档/质量检查/候选人画像）、预览入口与保存状态。 */
export function DocumentPane({
  activeSection,
  onSectionChange,
  role,
  draft,
  changedFields,
  autoDraftStatus,
  autoDraftError,
  qualityChecks,
  profile,
  approved,
  saveState,
  previewDisabled,
  focusRequest,
  onCopy,
  onOpenPreview,
  onRetryAutoDraft,
  onFixField,
  onUpdateField,
  onUpdateListItem,
  onRemoveListItem,
  locked = false,
}: DocumentPaneProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  // 质量检查「去补充」：tab 已切到编辑器后聚焦对应字段，对齐旧版 focusField。
  useEffect(() => {
    if (!focusRequest || activeSection !== 'editor') {
      return;
    }
    const root = scrollRef.current;
    const target =
      root?.querySelector<HTMLElement>(`[data-field="${focusRequest.field}"]`) ??
      root?.querySelector<HTMLElement>(`[data-field-list="${focusRequest.field}"]`);
    target?.focus();
  }, [focusRequest, activeSection]);

  const heading = SECTION_HEADINGS[activeSection];
  return (
    <section className="xw-document-pane" aria-label="JD 工作台">
      <div className="xw-document-toolbar">
        <div className="xw-tabs" role="tablist" aria-label="JD 工作台内容">
          {(Object.keys(SECTION_HEADINGS) as DocumentSection[]).map((section) => (
            <button
              key={section}
              className={`xw-tab${activeSection === section ? ' active' : ''}`}
              type="button"
              role="tab"
              aria-selected={activeSection === section}
              onClick={() => onSectionChange(section)}
            >
              {SECTION_HEADINGS[section].title}
            </button>
          ))}
        </div>
        <div className="xw-document-toolbar-actions">
          <button className="xw-button small" type="button" disabled={previewDisabled} onClick={onCopy}>
            复制 JD
          </button>
          <button
            className="xw-button small xw-document-preview-button"
            type="button"
            disabled={previewDisabled}
            onClick={onOpenPreview}
          >
            预览 JD
          </button>
        </div>
      </div>
      <div className="xw-document-scroll" ref={scrollRef}>
        {locked && (
          <div className="xw-locked-banner" role="status">
            <div>
              <strong>JD 已锁定</strong>
              <span>下游流程正在使用当前 JD，当前岗位仅支持查看；如需调整，请新建岗位。</span>
            </div>
          </div>
        )}
        <section className="xw-document-section" data-document-section={activeSection}>
          <div className="xw-document-section-heading">
            <h2>{heading.title}</h2>
            <span>{heading.note}</span>
          </div>
          {activeSection === 'editor' && (
            <JdEditor
              role={role}
              draft={draft}
              changedFields={changedFields}
              autoDraftStatus={autoDraftStatus}
              autoDraftError={autoDraftError}
              onRetryAutoDraft={onRetryAutoDraft}
              onUpdateField={onUpdateField}
              onUpdateListItem={onUpdateListItem}
              onRemoveListItem={onRemoveListItem}
              readOnly={locked}
            />
          )}
          {activeSection === 'quality' && (
            <QualityPanel checks={qualityChecks} onFixField={onFixField} locked={locked} />
          )}
          {activeSection === 'profile' && <ProfilePanel profile={profile} approved={approved} />}
        </section>
      </div>
      <footer className="xw-document-footer">
        <span className={`xw-save-state${saveState.type ? ` ${saveState.type}` : ''}`}>
          {saveState.text}
        </span>
      </footer>
    </section>
  );
}
