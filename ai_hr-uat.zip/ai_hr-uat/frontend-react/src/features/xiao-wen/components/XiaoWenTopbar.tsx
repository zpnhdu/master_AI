import { AgentTopbar } from '../../../app/components/AgentTopbar';

type XiaoWenTopbarProps = {
  role: string;
  approved: boolean;
  pipelineId: string;
  downstreamPassed: boolean;
  canPass: boolean;
  passDisabledReason: string;
  passLoading: boolean;
  onPassDownstream: () => void;
  canApprove: boolean;
  approveLabel: string;
  approveTitle: string;
  onApprove: () => void;
  locked?: boolean;
};

/** 小文顶栏适配器：复用公共顶栏，提供画像生成与数据交接操作。 */
export function XiaoWenTopbar({
  role,
  approved,
  pipelineId,
  downstreamPassed,
  canPass,
  passDisabledReason,
  passLoading,
  onPassDownstream,
  canApprove,
  approveLabel,
  approveTitle,
  onApprove,
  locked = false,
}: XiaoWenTopbarProps) {
  return (
    <AgentTopbar
      pipelineId={pipelineId}
      mark="文"
      title={role}
      subtitle="小文 · JD 工作台"
      status={{
        label: locked ? 'JD 已锁定' : approved ? '已确认' : '草稿',
        tone: locked ? 'neutral' : approved ? 'ok' : 'pending',
      }}
      secondaryActions={
        <button
          className="xw-button primary xw-topbar-profile-action"
          type="button"
          disabled={!canApprove}
          title={approveTitle}
          onClick={onApprove}
        >
          {approveLabel}
        </button>
      }
      primaryAction={{
        label: downstreamPassed ? '进入下游' : '传递给下游',
        onClick: onPassDownstream,
        disabled: !canPass,
        loading: passLoading,
        title: passDisabledReason,
      }}
    />
  );
}