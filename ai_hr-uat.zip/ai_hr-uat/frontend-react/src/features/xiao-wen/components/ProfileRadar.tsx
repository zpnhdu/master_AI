import { useId } from 'react';

type ProfileRadarProps = {
  /** 各分组的得分（0-100），顺序与 labels 对应。 */
  values: number[];
  labels: string[];
  max?: number;
};

const VIEW_BOX = 200;
const CENTER_X = VIEW_BOX / 2;
const CENTER_Y = VIEW_BOX * 0.52;
const RADIUS = VIEW_BOX * 0.315;
const SPLIT_RINGS = 4;

function axisPoint(index: number, total: number, ratio: number): [number, number] {
  const angle = -Math.PI / 2 + (index * 2 * Math.PI) / total;
  return [
    CENTER_X + RADIUS * ratio * Math.cos(angle),
    CENTER_Y + RADIUS * ratio * Math.sin(angle),
  ];
}

function polygonPoints(values: number[], max: number): string {
  return values
    .map((value, index) => {
      const ratio = Math.max(0, Math.min(value / max, 1));
      const [x, y] = axisPoint(index, values.length, ratio);
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(' ');
}

/**
 * 候选人画像雷达图（SVG 实现，无图表库依赖）。
 * 视觉对齐旧版 echarts 雷达：4 圈网格、蓝色填充多边形、分组标签。
 */
export function ProfileRadar({ values, labels, max = 100 }: ProfileRadarProps) {
  const gradientId = useId();
  const total = values.length;
  if (!total) {
    return null;
  }

  return (
    <svg
      className="xw-profile-radar-svg"
      viewBox={`0 0 ${VIEW_BOX} ${VIEW_BOX}`}
      role="img"
      aria-label="候选人画像分组雷达图"
    >
      <defs>
        <radialGradient id={gradientId} cx="50%" cy="50%" r="65%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#f8fafc" />
        </radialGradient>
      </defs>
      <polygon
        points={polygonPoints(new Array(total).fill(100), 100)}
        fill={`url(#${gradientId})`}
        stroke="none"
      />
      {Array.from({ length: SPLIT_RINGS }, (_, ringIndex) => {
        const ratio = (ringIndex + 1) / SPLIT_RINGS;
        return (
          <polygon
            key={ratio}
            points={polygonPoints(new Array(total).fill(ratio * max), max)}
            fill="none"
            stroke="#e8eaed"
            strokeWidth={1}
          />
        );
      })}
      {labels.map((label, index) => {
        const [x, y] = axisPoint(index, total, 1);
        const [labelX, labelY] = axisPoint(index, total, 1.18);
        return (
          <g key={label}>
            <line x1={CENTER_X} y1={CENTER_Y} x2={x} y2={y} stroke="#dbe4f0" strokeWidth={1} />
            <text
              x={labelX}
              y={labelY}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize={10}
              fill="#6b7280"
            >
              {label}
            </text>
          </g>
        );
      })}
      <polygon
        points={polygonPoints(values, max)}
        fill="rgba(37, 99, 235, 0.18)"
        stroke="#2563eb"
        strokeWidth={2}
        strokeLinejoin="round"
      />
      {values.map((value, index) => {
        const ratio = Math.max(0, Math.min(value / max, 1));
        const [x, y] = axisPoint(index, total, ratio);
        return <circle key={index} cx={x} cy={y} r={2.5} fill="#2563eb" />;
      })}
    </svg>
  );
}
