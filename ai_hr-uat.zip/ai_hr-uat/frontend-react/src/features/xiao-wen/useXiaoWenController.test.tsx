import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, cleanup, renderHook, waitFor } from "@testing-library/react";
import { App as AntApp } from "antd";
import { createElement, type ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
  approveJd,
  cloneJdPipeline,
  fetchJdWorkspace,
  passArtifactToDownstream,
  runProfileBuild,
  saveJdDraft,
  type JdWorkspace,
} from "./api";
import { useXiaoWenController } from "./useXiaoWenController";

vi.mock("./api", async () => {
  const actual = await vi.importActual<typeof import("./api")>("./api");
  return {
    ...actual,
    approveJd: vi.fn(),
    fetchJdWorkspace: vi.fn(),
    saveJdDraft: vi.fn(),
    cloneJdPipeline: vi.fn(),
    runProfileBuild: vi.fn(),
    passArtifactToDownstream: vi.fn(),
  };
});

const workspace: JdWorkspace = {
  pipeline_id: "p1",
  role: "门店店长",
  pipeline_status: "draft",
  jd_locked: false,
  jd_locked_at: "",
  jd_locked_by_stage: "",
  cloned_from_pipeline_id: "",
  jd: {
    title: "门店店长",
    department: "上海门店",
    location: "上海",
    salary_range: "8-12K",
    responsibilities: ["负责经营目标", "管理门店团队", "执行库存盘点"],
    requirements: ["两年经验", "团队管理经验", "适应排班"],
    benefits: ["五险一金"],
  },
  revision: 4,
  approval_status: "approved",
  approved_revision: 4,
  updated_at: "",
  quality_checks: [],
  profile: { dimensions: { years: { weight: 0.8 } } },
  profile_revision: 4,
  profile_status: "done",
  profile_is_current: true,
  workflow: [],
  downstream: { agent_id: "xiao_hai", name: "小海", action: "生成海报", page: "xiao_hai", passed: false },
  messages: [],
};

function renderController() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const wrapper = ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, createElement(AntApp, null, children));
  return renderHook(() => useXiaoWenController("p1"), { wrapper });
}

describe("useXiaoWenController", () => {
  beforeEach(() => {
    vi.mocked(fetchJdWorkspace).mockResolvedValue(structuredClone(workspace));
    vi.mocked(saveJdDraft).mockResolvedValue({
      status: "saved",
      revision: 5,
      approval_status: "draft",
      quality_checks: [],
      workflow: [],
    });
  });

  afterEach(() => {
    cleanup();
    vi.clearAllMocks();
  });

  it("flushes a dirty draft with keepalive when the page unmounts", async () => {
    const { result, unmount } = renderController();
    await waitFor(() => expect(result.current.workspace?.revision).toBe(4));

    act(() => result.current.updateDraftField("location", "杭州"));
    unmount();

    expect(saveJdDraft).toHaveBeenCalledWith("p1", expect.objectContaining({ location: "杭州" }), "auto_unmount", {
      expectedRevision: 4,
      keepalive: true,
    });
  });

  it("copies the visible local draft instead of the cached server draft", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText },
    });
    const { result } = renderController();
    await waitFor(() => expect(result.current.workspace?.revision).toBe(4));

    act(() => result.current.updateDraftField("location", "杭州"));
    await act(async () => result.current.copyJd());

    expect(writeText).toHaveBeenCalledWith(expect.stringContaining("上海门店 · 杭州 · 8-12K"));
  });

  it("refuses to pass stale artifacts while the draft is dirty", async () => {
    const { result } = renderController();
    await waitFor(() => expect(result.current.workspace?.revision).toBe(4));

    act(() => result.current.updateDraftField("location", "杭州"));
    await expect(result.current.passDownstream()).resolves.toBe(false);

    expect(passArtifactToDownstream).not.toHaveBeenCalled();
  });

  it("does not show a successful profile card when the refreshed workspace rejects the result", async () => {
    const pendingWorkspace: JdWorkspace = {
      ...structuredClone(workspace),
      approval_status: "draft",
      approved_revision: 0,
      profile: {},
      profile_revision: 0,
      profile_status: "pending",
      profile_is_current: false,
    };
    const staleWorkspace: JdWorkspace = {
      ...pendingWorkspace,
      approval_status: "approved",
      approved_revision: pendingWorkspace.revision,
      profile_status: "done",
    };
    vi.mocked(fetchJdWorkspace).mockReset();
    vi.mocked(fetchJdWorkspace).mockResolvedValueOnce(pendingWorkspace).mockResolvedValue(staleWorkspace);
    vi.mocked(approveJd).mockResolvedValue({
      status: "approved",
      revision: pendingWorkspace.revision,
      approved_revision: pendingWorkspace.revision,
      approval_status: "approved",
      workflow: [],
    });
    vi.mocked(runProfileBuild).mockResolvedValue({
      success: true,
      stage_id: "profile_build",
      status: "done",
      profile: { dimensions: { location: { weight: 0.8 } } },
    });
    const { result } = renderController();
    await waitFor(() => expect(result.current.workspace?.approval_status).toBe("draft"));

    await act(async () => result.current.approve());

    expect(result.current.messages.some((item) => item.card?.type === "profile")).toBe(false);
  });

  it("blocks JD edits after lock and can clone the pipeline", async () => {
    vi.mocked(fetchJdWorkspace).mockResolvedValue({
      ...structuredClone(workspace),
      jd_locked: true,
      jd_locked_at: "2026-08-26T10:00:00Z",
      jd_locked_by_stage: "xiao_hai",
    });
    vi.mocked(cloneJdPipeline).mockResolvedValue({
      status: "cloned",
      pipeline_id: "p2",
      source_pipeline_id: "p1",
      role: "门店店长",
      revision: 1,
      approval_status: "draft",
    });
    const { result } = renderController();
    await waitFor(() => expect(result.current.jdLocked).toBe(true));

    act(() => result.current.updateDraftField("location", "杭州"));
    expect(result.current.draft.location).toBe("上海");

    let clonedPipelineId: string | null = null;
    await act(async () => {
      clonedPipelineId = await result.current.clonePipeline();
    });
    expect(clonedPipelineId).toBe("p2");
    expect(cloneJdPipeline).toHaveBeenCalledWith("p1");
  });
});
