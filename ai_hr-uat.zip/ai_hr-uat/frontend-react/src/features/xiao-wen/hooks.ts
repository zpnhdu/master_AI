import { useQuery } from "@tanstack/react-query";

import { fetchJdWorkspace } from "./api";

export function jdWorkspaceQueryKey(pipelineId: string) {
  return ["jd-workspace", pipelineId] as const;
}

export function useJdWorkspaceQuery(pipelineId: string) {
  return useQuery({
    queryKey: jdWorkspaceQueryKey(pipelineId),
    queryFn: () => fetchJdWorkspace(pipelineId),
    enabled: Boolean(pipelineId),
    staleTime: 5 * 1000,
  });
}
