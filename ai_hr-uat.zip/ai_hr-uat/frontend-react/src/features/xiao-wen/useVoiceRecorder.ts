import { useCallback, useEffect, useRef, useState } from "react";

import { VOICE_MAX_SECONDS } from "./constants";
import { transcribeAudio } from "./api";

export type VoiceStatus = "idle" | "recording" | "transcribing";
export type VoiceNoticeType = "" | "error" | "success";

type UseVoiceRecorderOptions = {
  /** 转写成功后回调，把文字追加到输入框。 */
  onTranscript: (text: string) => void;
  /** 发送消息等忙碌状态时禁止开始录音。 */
  disabled: boolean;
};

function pickMimeType(): string {
  if (MediaRecorder.isTypeSupported("audio/webm;codecs=opus")) {
    return "audio/webm;codecs=opus";
  }
  if (MediaRecorder.isTypeSupported("audio/webm")) {
    return "audio/webm";
  }
  if (MediaRecorder.isTypeSupported("audio/ogg;codecs=opus")) {
    return "audio/ogg;codecs=opus";
  }
  return "";
}

/** 语音录入 → /api/interview/asr 转写，行为与旧版 xiao_wen.html 保持一致。 */
export function useVoiceRecorder({ onTranscript, disabled }: UseVoiceRecorderOptions) {
  const [supported] = useState(
    () => Boolean(navigator.mediaDevices?.getUserMedia) && typeof MediaRecorder !== "undefined",
  );
  const [status, setStatus] = useState<VoiceStatus>("idle");
  const [seconds, setSeconds] = useState(0);
  const [notice, setNotice] = useState("");
  const [noticeType, setNoticeType] = useState<VoiceNoticeType>("");

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const onTranscriptRef = useRef(onTranscript);
  onTranscriptRef.current = onTranscript;

  const setVoiceNotice = useCallback((message: string, type: VoiceNoticeType = "") => {
    setNotice(message);
    setNoticeType(type);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const releaseStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    if (!supported) {
      setNotice("当前浏览器不支持语音输入，请使用文字");
      setNoticeType("error");
    }
  }, [supported]);

  useEffect(
    () => () => {
      stopTimer();
      releaseStream();
      recorderRef.current = null;
    },
    [stopTimer, releaseStream],
  );

  const stop = useCallback(() => {
    const recorder = recorderRef.current;
    if (!recorder || recorder.state === "inactive") {
      return;
    }
    stopTimer();
    recorder.stop();
  }, [stopTimer]);

  const start = useCallback(async () => {
    if (!supported || recorderRef.current || disabled) {
      return;
    }
    setVoiceNotice("");

    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
      });
    } catch {
      setVoiceNotice("无法获取麦克风权限，请检查浏览器设置", "error");
      return;
    }
    streamRef.current = stream;

    const mimeType = pickMimeType();
    let recorder: MediaRecorder;
    try {
      recorder = mimeType
        ? new MediaRecorder(stream, { mimeType, audioBitsPerSecond: 64000 })
        : new MediaRecorder(stream);
    } catch {
      releaseStream();
      setVoiceNotice("录音初始化失败，请改用文字输入", "error");
      return;
    }

    chunksRef.current = [];
    setSeconds(0);
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunksRef.current.push(event.data);
      }
    };
    recorder.onerror = () => {
      stopTimer();
      releaseStream();
      recorderRef.current = null;
      setStatus("idle");
      setVoiceNotice("录音失败，请重试或使用文字输入", "error");
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, {
        type: recorder.mimeType || mimeType || "audio/webm",
      });
      stopTimer();
      releaseStream();
      recorderRef.current = null;
      setStatus("transcribing");
      void (async () => {
        try {
          const text = await transcribeAudio(blob);
          setStatus("idle");
          setVoiceNotice("已转成文字，可编辑后发送", "success");
          onTranscriptRef.current(text);
        } catch {
          setStatus("idle");
          setVoiceNotice("语音转文字失败，请重试或使用文字输入", "error");
        }
      })();
    };

    try {
      recorder.start();
    } catch {
      releaseStream();
      recorderRef.current = null;
      setVoiceNotice("录音启动失败，请重试或使用文字输入", "error");
      return;
    }
    recorderRef.current = recorder;
    setStatus("recording");
    timerRef.current = setInterval(() => {
      setSeconds((current) => {
        const next = current + 1;
        if (next >= VOICE_MAX_SECONDS) {
          stop();
        }
        return next;
      });
    }, 1000);
  }, [supported, disabled, setVoiceNotice, releaseStream, stopTimer, stop]);

  const toggle = useCallback(() => {
    if (status === "recording") {
      stop();
    } else {
      void start();
    }
  }, [status, start, stop]);

  return { supported, status, seconds, notice, noticeType, toggle };
}
