// @vitest-environment jsdom

import { afterEach, describe, expect, it, vi } from "vitest";

import { sendCandidateOffer } from "./api";

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("sendCandidateOffer", () => {
  it("posts the selected candidate to the offer endpoint", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ status: "sent", candidate_id: "candidate/1" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(sendCandidateOffer("pipeline 1", "candidate/1")).resolves.toEqual({
      status: "sent",
      candidate_id: "candidate/1",
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(fetchMock.mock.calls[0]?.[0]).toBe("/api/mass-interview/pipeline%201/offer");
    expect(fetchMock.mock.calls[0]?.[1]).toMatchObject({
      method: "POST",
      credentials: "include",
      body: JSON.stringify({ candidate_id: "candidate/1" }),
    });
  });
});
