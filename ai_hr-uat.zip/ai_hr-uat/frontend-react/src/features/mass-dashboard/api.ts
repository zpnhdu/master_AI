import { ApiError, requestWithTimeout } from "../pipelines/api";

export type MassPipeline = {
  id: string;
  role: string;
  job_type?: string;
  hr_name?: string;
  owner_user_id?: string;
};

export type MassHrUser = {
  id: string;
  username: string;
  display_name: string;
  role_id: string;
};

export type MassInterviewStats = {
  total: number;
  invited: number;
  started: number;
  in_progress: number;
  completed: number;
  evaluated: number;
  expired: number;
  recorded: number;
  online_count?: number;
};

export type MassAnswer = {
  question_index?: number;
  question?: string;
  answer?: string;
  score?: number;
  hit_points?: string[];
  missed_points?: string[];
  comment?: string;
  red_flag_reason?: string;
};

export type MassRanking = {
  id?: number;
  token?: string;
  invite_type?: "video_interview" | "written_test";
  candidate_id: string;
  candidate_name: string;
  status: string;
  assessment_completed?: boolean;
  completed_modalities?: string[];
  hr_action?: "" | "pass" | "review" | "reject";
  recommendation?: string;
  trend?: string;
  red_flags?: unknown[];
  rank?: number;
  match_score?: number;
  interview_score?: number;
  total_score?: number;
  dimension_scores?: Record<string, number>;
  video_paths?: string[];
  recording_url?: string;
  oss_object_key?: string;
  video_url?: string;
  expires_at?: string;
  started_at?: string;
  current_question?: number;
  total_questions?: number;
  questions?: Array<Record<string, unknown>>;
  answers?: MassAnswer[];
  scoring_status?: string;
  [key: string]: unknown;
};

export type MassStream = {
  stream_name: string;
  candidate_id: string;
  candidate_name: string;
  is_online: boolean;
  video_url?: string;
  hls_url?: string;
  snapshot_url?: string;
  current_question?: number;
  total_questions?: number;
  interview_score?: number;
  status?: string;
  stream_started_at?: string;
};

export type CandidateProfile = {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  resume_text?: string;
  years_experience?: string | number;
  education?: string;
  skills?: string[];
  source?: string;
  resume_id?: string;
  storage_backend?: string;
  storage_key?: string;
  original_filename?: string;
  [key: string]: unknown;
};

export type MassAssessmentReport = {
  candidate_id: string;
  candidate_name?: string;
  report_status?: string;
  score?: number | null;
  score_status?: string;
  recommendation?: string;
  dimensions?: Record<string, number>;
  questions?: Array<{
    question_index?: number;
    question?: string;
    answer?: string;
    score?: number | null;
    comment?: string;
    hit_points?: string[];
    missed_points?: string[];
    key_evidence?: string;
    red_flag_reason?: string;
  }>;
};

export type MassStatusResponse = {
  pipeline_id: string;
  role?: string;
  stats: MassInterviewStats;
  sessions: Array<Record<string, unknown>>;
};

export type MassStreamsResponse = {
  online_count: number;
  recorded: number;
  streams: MassStream[];
};

export type MassRankingResponse = {
  pipeline_id: string;
  total: number;
  ranking: MassRanking[];
};

export type MassSchedule = {
  id: string;
  pipeline_id: string;
  candidate_id: string;
  date: string;
  time?: string;
  interviewer?: string;
  method?: string;
  round?: string;
  status?: string;
  notes?: string;
};

export type MassSchedulesResponse = {
  pipeline_id: string;
  schedules: MassSchedule[];
};

export type WeComScheduleResult = {
  status: "created" | "disabled" | "failed";
  schedule_id?: string;
  message?: string;
};

export type MarkMassCandidateResponse = {
  status: string;
  candidate_id?: string;
  action?: "pass" | "review" | "reject";
  schedule_id?: string;
  wecom_schedule?: WeComScheduleResult;
  email_notification?: {
    status: "sent" | "skipped" | "failed";
    message?: string;
  };
};

export type SendOfferResponse = {
  status: "sent" | "skipped" | "failed";
  candidate_id: string;
  message?: string;
};

export type MonitorUsage = {
  total_llm_calls: number;
  total_tokens: number;
  total_cost_usd: number;
};

export type MonitorDashboardResponse = {
  last_24h?: MonitorUsage;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function asString(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function asStringArray(value: unknown) {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function normalizeInviteType(
  item: Record<string, unknown>,
  completedModalities: string[],
  videoPaths: string[],
): MassRanking["invite_type"] {
  // Video is the authoritative modality whenever the response contains a
  // video session or video completion record. This protects legacy rows whose
  // invite_type was persisted incorrectly during session rebuilding.
  if (
    item.invite_type === "video_interview" ||
    completedModalities.includes("video_interview") ||
    (typeof item.recording_url === "string" && item.recording_url.length > 0) ||
    (typeof item.video_url === "string" && item.video_url.length > 0) ||
    (typeof item.oss_object_key === "string" && item.oss_object_key.length > 0) ||
    videoPaths.length > 0
  ) {
    return "video_interview";
  }
  if (item.invite_type === "written_test" || completedModalities.includes("written_test")) {
    return "written_test";
  }
  // The ranking endpoint's primary session table is the video-session table;
  // keep unknown legacy rows on the video card instead of guessing "written".
  return "video_interview";
}

function asNumberMap(value: unknown) {
  if (!isRecord(value)) {
    return {};
  }

  return Object.fromEntries(
    Object.entries(value).flatMap(([key, item]) => {
      const number = asNumber(item, Number.NaN);
      return Number.isFinite(number) ? [[key, number]] : [];
    }),
  );
}

async function requestJson<T>(input: RequestInfo | URL, init: RequestInit = {}) {
  return requestWithTimeout(input, { credentials: "include", ...init }, async (response) => {
    if (!response.ok) {
      const payload: unknown = await response.json().catch(() => ({}));
      const detail = isRecord(payload) ? payload.detail : undefined;
      const reason =
        typeof detail === "string"
          ? detail
          : isRecord(detail) && typeof detail.message === "string"
            ? detail.message
            : "多人面试请求失败";
      throw new ApiError(reason, { status: response.status, data: payload });
    }
    return (await response.json()) as T;
  });
}

export type MassPipelineListParams = {
  q?: string;
  ownerUserId?: string;
  hrName?: string;
  role?: string;
  startDate?: string;
  endDate?: string;
};

export async function fetchMassPipelines(filters: MassPipelineListParams = {}) {
  const params = new URLSearchParams();
  if (filters.q?.trim()) params.set("q", filters.q.trim());
  if (filters.ownerUserId) params.set("owner_user_id", filters.ownerUserId);
  if (filters.hrName) params.set("hr_name", filters.hrName);
  if (filters.role) params.set("role", filters.role);
  if (filters.startDate) params.set("start_date", filters.startDate);
  if (filters.endDate) params.set("end_date", filters.endDate);
  const query = params.toString();
  const data = await requestJson<unknown>(`/api/mass-interview/pipelines${query ? `?${query}` : ""}`);
  const pipelines = isRecord(data) && Array.isArray(data.pipelines) ? data.pipelines : [];

  return pipelines.flatMap((item): MassPipeline[] => {
    if (!isRecord(item) || !asString(item.id)) {
      return [];
    }
    return [
      {
        id: asString(item.id),
        role: asString(item.role, asString(item.id)),
        job_type: asString(item.job_type, "general"),
        hr_name: asString(item.hr_name),
        owner_user_id: asString(item.owner_user_id),
      },
    ];
  });
}

export async function fetchMassHrUsers() {
  const data = await requestJson<unknown>("/api/mass-interview/hr-users");
  const record = isRecord(data) ? data : {};
  const users = Array.isArray(record.users) ? record.users : [];
  return {
    users: users.flatMap((item): MassHrUser[] => {
      if (!isRecord(item) || !asString(item.id)) return [];
      return [
        {
          id: asString(item.id),
          username: asString(item.username),
          display_name: asString(item.display_name, asString(item.username, asString(item.id))),
          role_id: asString(item.role_id),
        },
      ];
    }),
    current_user_id: asString(record.current_user_id),
    can_select_all: record.can_select_all === true,
  };
}

export async function fetchMassPipelineForSource(sourcePipelineId: string): Promise<string> {
  const data = await requestJson<unknown>(`/api/mass-interview/pipeline-for/${encodeURIComponent(sourcePipelineId)}`);
  return isRecord(data) ? asString(data.pipeline_id, "") : "";
}

export async function fetchMassStatus(
  pipelineId: string,
  ownerUserId = "",
  includeUnsent = false,
): Promise<MassStatusResponse> {
  const params = new URLSearchParams();
  if (ownerUserId) params.set("owner_user_id", ownerUserId);
  if (includeUnsent) params.set("include_unsent", "true");
  const query = params.toString() ? `?${params.toString()}` : "";
  const data = await requestJson<unknown>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/status${query}`);
  const record = isRecord(data) ? data : {};
  const rawStats = isRecord(record.stats) ? record.stats : {};
  const stats: MassInterviewStats = {
    total: asNumber(rawStats.total),
    invited: asNumber(rawStats.invited),
    started: asNumber(rawStats.started),
    in_progress: asNumber(rawStats.in_progress),
    completed: asNumber(rawStats.completed),
    evaluated: asNumber(rawStats.evaluated),
    expired: asNumber(rawStats.expired),
    recorded: asNumber(rawStats.recorded),
  };

  return {
    pipeline_id: asString(record.pipeline_id, pipelineId),
    role: asString(record.role),
    stats,
    sessions: Array.isArray(record.sessions) ? record.sessions.filter(isRecord) : [],
  };
}

export async function fetchMassStreams(pipelineId: string, ownerUserId = ""): Promise<MassStreamsResponse> {
  const query = ownerUserId ? `?owner_user_id=${encodeURIComponent(ownerUserId)}` : "";
  const data = await requestJson<unknown>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/streams${query}`);
  const record = isRecord(data) ? data : {};
  const streams = Array.isArray(record.streams) ? record.streams : [];

  return {
    online_count: asNumber(record.online_count),
    recorded: asNumber(record.recorded),
    streams: streams.flatMap((item): MassStream[] => {
      if (!isRecord(item)) {
        return [];
      }
      return [
        {
          stream_name: asString(item.stream_name),
          candidate_id: asString(item.candidate_id),
          candidate_name: asString(item.candidate_name, "候选人"),
          is_online: item.is_online === true,
          video_url: asString(item.video_url),
          hls_url: asString(item.hls_url),
          snapshot_url: asString(item.snapshot_url),
          current_question: asNumber(item.current_question),
          total_questions: asNumber(item.total_questions, 1),
          interview_score: asNumber(item.interview_score),
          status: asString(item.status),
          stream_started_at: asString(item.stream_started_at),
        },
      ];
    }),
  };
}

export type MassRankingParams = {
  startFrom?: string;
  startTo?: string;
  ownerUserId?: string;
};

export async function fetchMassRanking(
  pipelineId: string,
  params: MassRankingParams = {},
): Promise<MassRankingResponse> {
  const query = new URLSearchParams();
  if (params.startFrom) query.set("start_from", params.startFrom);
  if (params.startTo) query.set("start_to", params.startTo);
  if (params.ownerUserId) query.set("owner_user_id", params.ownerUserId);
  const queryString = query.toString();
  const endpoint = `/api/mass-interview/${encodeURIComponent(pipelineId)}/ranking${
    queryString ? `?${queryString}` : ""
  }`;
  const data = await requestJson<unknown>(endpoint);
  const record = isRecord(data) ? data : {};
  const ranking = Array.isArray(record.ranking) ? record.ranking : [];

  return {
    pipeline_id: asString(record.pipeline_id, pipelineId),
    total: asNumber(record.total, ranking.length),
    ranking: ranking.flatMap((item): MassRanking[] => {
      if (!isRecord(item) || !asString(item.candidate_id)) {
        return [];
      }
      return [
        {
          ...item,
          candidate_id: asString(item.candidate_id),
          candidate_name: asString(item.candidate_name, "候选人"),
          status: asString(item.status, "invited"),
          assessment_completed: item.assessment_completed === true,
          completed_modalities: asStringArray(item.completed_modalities),
          hr_action:
            item.hr_action === "pass" || item.hr_action === "review" || item.hr_action === "reject"
              ? item.hr_action
              : "",
          recommendation: asString(item.recommendation),
          trend:
            item.trend === "improving" || item.trend === "declining" || item.trend === "stable" ? item.trend : "stable",
          rank: asNumber(item.rank),
          match_score: asNumber(item.match_score),
          interview_score: asNumber(item.interview_score),
          total_score: asNumber(item.total_score),
          dimension_scores: asNumberMap(item.dimension_scores),
          scoring_status:
            isRecord(item.dimension_scores) && typeof item.dimension_scores.scoring_status === "string"
              ? item.dimension_scores.scoring_status
              : asString(item.scoring_status),
          video_paths: asStringArray(item.video_paths),
          invite_type: normalizeInviteType(
            item,
            asStringArray(item.completed_modalities),
            asStringArray(item.video_paths),
          ),
          token: asString(item.token),
          expires_at: asString(item.expires_at),
          answers: Array.isArray(item.answers) ? (item.answers.filter(isRecord) as MassAnswer[]) : [],
        },
      ];
    }),
  };
}

export async function fetchMassSchedules(pipelineId: string): Promise<MassSchedulesResponse> {
  let data: unknown;
  try {
    data = await requestJson<unknown>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/schedules`);
  } catch (error) {
    // Older backend workers may not expose the calendar endpoint yet. Use the
    // shared pipeline schedule endpoint so saved follow-up interviews remain
    // visible while workers are being refreshed.
    if (error instanceof ApiError && error.status === 404) {
      data = await requestJson<unknown>(`/api/pipelines/${encodeURIComponent(pipelineId)}/interview-schedules`);
    } else {
      throw error;
    }
  }
  const record = isRecord(data) ? data : {};
  const schedules = Array.isArray(data) ? data : Array.isArray(record.schedules) ? record.schedules : [];
  return {
    pipeline_id: asString(record.pipeline_id, pipelineId),
    schedules: schedules
      .flatMap((item): MassSchedule[] => {
        if (!isRecord(item) || !asString(item.id) || !asString(item.date)) return [];
        return [
          {
            id: asString(item.id),
            pipeline_id: asString(item.pipeline_id, pipelineId),
            candidate_id: asString(item.candidate_id),
            date: asString(item.date),
            time: asString(item.time),
            interviewer: asString(item.interviewer),
            method: asString(item.method),
            round: asString(item.round),
            status: asString(item.status, "scheduled"),
            notes: asString(item.notes),
          },
        ];
      })
      .sort((left, right) => `${left.date} ${left.time ?? ""}`.localeCompare(`${right.date} ${right.time ?? ""}`)),
  };
}

export async function fetchMonitorDashboard(): Promise<MonitorDashboardResponse> {
  const data = await requestJson<unknown>("/api/monitor/dashboard");
  const record = isRecord(data) ? data : {};
  const usage = isRecord(record.last_24h) ? record.last_24h : {};
  return {
    last_24h: {
      total_llm_calls: asNumber(usage.total_llm_calls),
      total_tokens: asNumber(usage.total_tokens),
      total_cost_usd: asNumber(usage.total_cost_usd),
    },
  };
}

export async function fetchMassAssessmentReport(
  pipelineId: string,
  candidateId: string,
): Promise<MassAssessmentReport | null> {
  try {
    const data = await requestJson<unknown>(
      `/api/assessment-flow/${encodeURIComponent(pipelineId)}/reports/${encodeURIComponent(candidateId)}`,
    );
    return isRecord(data) && isRecord(data.report)
      ? {
          ...(data.report as Record<string, unknown>),
          candidate_id: asString(data.report.candidate_id, candidateId),
          dimensions: asNumberMap(data.report.dimensions),
          questions: Array.isArray(data.report.questions)
            ? (data.report.questions.filter(isRecord) as MassAssessmentReport["questions"])
            : [],
        }
      : null;
  } catch (error) {
    if (error instanceof ApiError && error.status === 404) return null;
    throw error;
  }
}

export async function fetchCandidateProfiles(pipelineId: string) {
  const data = await requestJson<unknown>(`/api/pipelines/${encodeURIComponent(pipelineId)}/candidates`);
  const candidates = Array.isArray(data)
    ? data
    : isRecord(data) && Array.isArray(data.candidates)
      ? data.candidates
      : [];

  return candidates.flatMap((item): CandidateProfile[] => {
    if (!isRecord(item) || !asString(item.id)) {
      return [];
    }
    return [
      {
        ...item,
        id: asString(item.id),
        name: asString(item.name, "候选人"),
        phone: asString(item.phone),
        email: asString(item.email),
        resume_text: asString(item.resume_text),
        years_experience:
          typeof item.years_experience === "number" || typeof item.years_experience === "string"
            ? item.years_experience
            : "",
        education: asString(item.education),
        skills: asStringArray(item.skills),
        source: asString(item.source),
        resume_id: asString(item.resume_id),
        storage_backend: asString(item.storage_backend),
        storage_key: asString(item.storage_key),
        original_filename: asString(item.original_filename),
      },
    ];
  });
}

function postJson<T>(input: string, body: Record<string, unknown>) {
  return requestJson<T>(input, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

export function markMassCandidate(
  pipelineId: string,
  candidateId: string,
  action: "pass" | "review" | "reject",
  schedule?: Record<string, string | number>,
) {
  return postJson<MarkMassCandidateResponse>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/mark`, {
    candidate_id: candidateId,
    action,
    note: "",
    schedule,
  });
}

export function sendCandidateOffer(pipelineId: string, candidateId: string) {
  return postJson<SendOfferResponse>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/offer`, {
    candidate_id: candidateId,
  });
}

export function extendMassSession(token: string) {
  return postJson<{ status: string; new_expires_at?: string }>(
    `/api/mass-interview/session/${encodeURIComponent(token)}/extend`,
    { extend_hours: 24 },
  );
}

export function batchExtendMassSessions(pipelineId: string, candidateIds: string[]) {
  return postJson<{ extended: number }>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/batch-extend`, {
    extend_hours: 24,
    candidate_ids: candidateIds,
  });
}

export type MassInviteTarget = {
  candidate_id: string;
  token: string;
};

export function sendMassInvite(pipelineId: string, invites?: MassInviteTarget[]) {
  return postJson<{
    sent?: number;
    failed?: number;
    skipped_no_email?: number;
    warning?: string;
    links?: Array<{ token: string; url: string }>;
  }>(`/api/mass-interview/${encodeURIComponent(pipelineId)}/invite`, {
    method: "email",
    invites,
    // 邮件中的链接必须指向候选人可访问的前端页面，而不是后端 API 地址。
    base_url: typeof window !== "undefined" ? window.location.origin : "",
  });
}

export function kickMassStream(streamName: string) {
  return postJson<{ status: string }>(`/api/mass-interview/stream/${encodeURIComponent(streamName)}/kick`, {});
}
