import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook, waitFor } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import {
  invalidateMassDashboardLiveQueries,
  invalidateMassDashboardStatusQueries,
  massDashboardKeys,
  useKickMassStreamMutation,
  useMassSchedulesQuery,
} from "./hooks";

function createQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: false },
    },
  });
}

function createQueryWrapper(queryClient: QueryClient) {
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
}

function response(body: unknown) {
  return new Response(JSON.stringify(body), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("mass dashboard hooks", () => {
  it("invalidates owner-specific status queries through the pipeline prefix", async () => {
    const queryClient = createQueryClient();
    const invalidateSpy = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);

    await invalidateMassDashboardStatusQueries(queryClient, "pipeline-1");

    expect(invalidateSpy).toHaveBeenCalledWith({ queryKey: ["mass-dashboard", "status", "pipeline-1"] });
    expect(invalidateSpy).toHaveBeenCalledWith({ queryKey: ["mass-dashboard", "streams", "pipeline-1"] });
    expect(invalidateSpy).toHaveBeenCalledTimes(2);
    queryClient.clear();
  });

  it("invalidates ranking along with owner-specific status queries for score updates", async () => {
    const queryClient = createQueryClient();
    const invalidateSpy = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);

    await invalidateMassDashboardLiveQueries(queryClient, "pipeline-1");

    expect(invalidateSpy).toHaveBeenCalledWith({ queryKey: ["mass-dashboard", "ranking", "pipeline-1"] });
    expect(invalidateSpy).toHaveBeenCalledTimes(3);
    queryClient.clear();
  });

  it("invalidates owner-specific dashboard queries after kicking a stream", async () => {
    const fetchMock = vi.fn().mockResolvedValue(response({ status: "kicked" }));
    vi.stubGlobal("fetch", fetchMock);
    const queryClient = createQueryClient();
    const ownerUserId = "hr-1";
    const rankingParams = { ownerUserId };
    const keys = [
      massDashboardKeys.status("pipeline-1", ownerUserId),
      massDashboardKeys.streams("pipeline-1", ownerUserId),
      massDashboardKeys.ranking("pipeline-1", rankingParams),
      massDashboardKeys.schedules("pipeline-1"),
    ];
    keys.forEach((key) => queryClient.setQueryData(key, { ready: true }));

    const { result } = renderHook(() => useKickMassStreamMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    await result.current.mutateAsync("stream-1");

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/mass-interview/stream/stream-1/kick",
      expect.objectContaining({ credentials: "include", method: "POST" }),
    );
    expect(keys.map((key) => queryClient.getQueryState(key)?.isInvalidated)).toEqual([true, true, true, true]);
    queryClient.clear();
  });

  it("does not request schedules while disabled", () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    const queryClient = createQueryClient();

    const { result } = renderHook(() => useMassSchedulesQuery("pipeline-1", false), {
      wrapper: createQueryWrapper(queryClient),
    });

    expect(result.current.fetchStatus).toBe("idle");
    expect(fetchMock).not.toHaveBeenCalled();
    queryClient.clear();
  });

  it("requests and normalizes schedules when enabled", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      response({
        pipeline_id: "pipeline-1",
        schedules: [
          {
            id: "schedule-1",
            pipeline_id: "pipeline-1",
            candidate_id: "candidate-1",
            date: "2026-09-02",
            time: "14:00",
          },
        ],
      }),
    );
    vi.stubGlobal("fetch", fetchMock);
    const queryClient = createQueryClient();

    const { result } = renderHook(() => useMassSchedulesQuery("pipeline-1", true), {
      wrapper: createQueryWrapper(queryClient),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/mass-interview/pipeline-1/schedules",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
    expect(result.current.data?.schedules[0]).toMatchObject({
      id: "schedule-1",
      candidate_id: "candidate-1",
      status: "scheduled",
    });
    queryClient.clear();
  });
});
