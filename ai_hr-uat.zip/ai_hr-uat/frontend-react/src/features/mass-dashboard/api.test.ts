import { afterEach, describe, expect, it, vi } from "vitest";

import { fetchMassPipelines, fetchMassRanking, fetchMassStatus } from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("mass dashboard api", () => {
  it("passes the pipeline name query to the backend", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => ({ pipelines: [] }) }));

    await fetchMassPipelines({ q: "店长" });

    expect(fetch).toHaveBeenCalledWith(
      "/api/mass-interview/pipelines?q=%E5%BA%97%E9%95%BF",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("passes the ranking date range to the backend", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => ({ ranking: [] }) }));

    await fetchMassRanking("pipeline-1", { startFrom: "2026-08-01", startTo: "2026-08-31" });

    expect(fetch).toHaveBeenCalledWith(
      "/api/mass-interview/pipeline-1/ranking?start_from=2026-08-01&start_to=2026-08-31",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("requests generated but unsent links when requested by XiaoMian", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({
          pipeline_id: "pipeline-1",
          stats: {},
          sessions: [{ token: "token-1", invite_sent_at: "" }],
        }),
      }),
    );

    const result = await fetchMassStatus("pipeline-1", "", true);

    expect(fetch).toHaveBeenCalledWith(
      "/api/mass-interview/pipeline-1/status?include_unsent=true",
      expect.objectContaining({ credentials: "include" }),
    );
    expect(result.sessions[0]).toMatchObject({ token: "token-1", invite_sent_at: "" });
  });
});
