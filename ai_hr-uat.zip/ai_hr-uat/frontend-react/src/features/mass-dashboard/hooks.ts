import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";

import {
  batchExtendMassSessions,
  extendMassSession,
  fetchCandidateProfiles,
  fetchMassAssessmentReport,
  fetchMassHrUsers,
  fetchMassPipelineForSource,
  fetchMassPipelines,
  fetchMassRanking,
  fetchMassSchedules,
  fetchMassStatus,
  fetchMassStreams,
  fetchMonitorDashboard,
  kickMassStream,
  markMassCandidate,
  sendCandidateOffer,
  sendMassInvite,
  type MassPipelineListParams,
  type MassRankingParams,
  type MassInviteTarget,
} from "./api";

export const massDashboardKeys = {
  pipelines: (params: MassPipelineListParams = {}) => ["mass-dashboard", "pipelines", params] as const,
  status: (pipelineId: string, ownerUserId = "") => ["mass-dashboard", "status", pipelineId, ownerUserId] as const,
  statusPrefix: (pipelineId: string) => ["mass-dashboard", "status", pipelineId] as const,
  streams: (pipelineId: string, ownerUserId = "") => ["mass-dashboard", "streams", pipelineId, ownerUserId] as const,
  streamsPrefix: (pipelineId: string) => ["mass-dashboard", "streams", pipelineId] as const,
  ranking: (pipelineId: string, params: MassRankingParams = {}) =>
    ["mass-dashboard", "ranking", pipelineId, params] as const,
  rankingPrefix: (pipelineId: string) => ["mass-dashboard", "ranking", pipelineId] as const,
  schedules: (pipelineId: string) => ["mass-dashboard", "schedules", pipelineId] as const,
  candidates: (pipelineId: string) => ["mass-dashboard", "candidates", pipelineId] as const,
  assessmentReport: (pipelineId: string, candidateId: string) =>
    ["mass-dashboard", "assessment-report", pipelineId, candidateId] as const,
  usage: ["mass-dashboard", "usage"] as const,
};

export function useMassPipelinesQuery(filters: MassPipelineListParams = {}) {
  return useQuery({
    queryKey: massDashboardKeys.pipelines(filters),
    queryFn: () => fetchMassPipelines(filters),
    staleTime: 30_000,
  });
}

export function useMassHrUsersQuery() {
  return useQuery({
    queryKey: ["mass-dashboard", "hr-users"] as const,
    queryFn: fetchMassHrUsers,
    staleTime: 5 * 60_000,
  });
}

export function useMassPipelineForSourceQuery(sourcePipelineId: string) {
  return useQuery({
    queryKey: ["mass-dashboard", "pipeline-for", sourcePipelineId] as const,
    queryFn: () => fetchMassPipelineForSource(sourcePipelineId),
    enabled: Boolean(sourcePipelineId),
    staleTime: 30_000,
  });
}

export function useMassStatusQuery(pipelineId: string, ownerUserId = "", includeUnsent = false) {
  return useQuery({
    queryKey: includeUnsent
      ? ([...massDashboardKeys.status(pipelineId, ownerUserId), true] as const)
      : massDashboardKeys.status(pipelineId, ownerUserId),
    queryFn: () => fetchMassStatus(pipelineId, ownerUserId, includeUnsent),
    enabled: Boolean(pipelineId),
    refetchInterval: 15_000,
  });
}

export function useMassStreamsQuery(pipelineId: string, ownerUserId = "") {
  return useQuery({
    queryKey: massDashboardKeys.streams(pipelineId, ownerUserId),
    queryFn: () => fetchMassStreams(pipelineId, ownerUserId),
    enabled: Boolean(pipelineId),
    refetchInterval: 15_000,
  });
}

export function useMassRankingQuery(pipelineId: string, params: MassRankingParams = {}) {
  return useQuery({
    queryKey: massDashboardKeys.ranking(pipelineId, params),
    queryFn: () => fetchMassRanking(pipelineId, params),
    enabled: Boolean(pipelineId),
    refetchInterval: 15_000,
  });
}

export function useMassSchedulesQuery(pipelineId: string, enabled = true) {
  return useQuery({
    queryKey: massDashboardKeys.schedules(pipelineId),
    queryFn: () => fetchMassSchedules(pipelineId),
    enabled: Boolean(pipelineId) && enabled,
    refetchInterval: 60_000,
  });
}

export function useMonitorDashboardQuery() {
  return useQuery({
    queryKey: massDashboardKeys.usage,
    queryFn: fetchMonitorDashboard,
    staleTime: 30_000,
  });
}

export function useMassCandidatesQuery(pipelineId: string, enabled: boolean) {
  return useQuery({
    queryKey: massDashboardKeys.candidates(pipelineId),
    queryFn: () => fetchCandidateProfiles(pipelineId),
    enabled: Boolean(pipelineId) && enabled,
    staleTime: 30_000,
  });
}

export function useMassAssessmentReportQuery(pipelineId: string, candidateId: string) {
  return useQuery({
    queryKey: massDashboardKeys.assessmentReport(pipelineId, candidateId),
    queryFn: () => fetchMassAssessmentReport(pipelineId, candidateId),
    enabled: Boolean(pipelineId) && Boolean(candidateId),
    refetchInterval: 15_000,
    retry: false,
  });
}

export function invalidateMassDashboardStatusQueries(queryClient: QueryClient, pipelineId: string) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: massDashboardKeys.statusPrefix(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: massDashboardKeys.streamsPrefix(pipelineId) }),
  ]);
}

export function invalidateMassDashboardLiveQueries(queryClient: QueryClient, pipelineId: string) {
  return Promise.all([
    invalidateMassDashboardStatusQueries(queryClient, pipelineId),
    queryClient.invalidateQueries({ queryKey: massDashboardKeys.rankingPrefix(pipelineId) }),
  ]);
}

function invalidateDashboard(queryClient: ReturnType<typeof useQueryClient>, pipelineId: string) {
  return Promise.all([
    invalidateMassDashboardLiveQueries(queryClient, pipelineId),
    queryClient.invalidateQueries({ queryKey: massDashboardKeys.schedules(pipelineId) }),
  ]);
}

export function useMarkMassCandidateMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: {
      candidateId: string;
      action: "pass" | "review" | "reject";
      schedule?: Record<string, string | number>;
    }) => markMassCandidate(pipelineId, input.candidateId, input.action, input.schedule),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}

export function useSendCandidateOfferMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (candidateId: string) => sendCandidateOffer(pipelineId, candidateId),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}

export function useExtendMassSessionMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (token: string) => extendMassSession(token),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}

export function useBatchExtendMassSessionsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (candidateIds: string[]) => batchExtendMassSessions(pipelineId, candidateIds),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}

export function useSendMassInviteMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (invites?: MassInviteTarget[]) => sendMassInvite(pipelineId, invites),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}

export function useKickMassStreamMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (streamName: string) => kickMassStream(streamName),
    onSuccess: () => invalidateDashboard(queryClient, pipelineId),
  });
}
