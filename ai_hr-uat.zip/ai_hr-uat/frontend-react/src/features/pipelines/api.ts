export type PipelineStage = {
  stage_id?: string;
  status?: string;
};

export type Pipeline = {
  id?: string;
  pipeline_id?: string;
  role?: string;
  type?: string;
  /** 兼容现有 Studio 页面，后端字段以 type 为准。 */
  pipeline_type?: string;
  status?: string;
  candidate_count?: number;
  created_at?: string;
  agents?: string[];
  stages?: PipelineStage[];
  /** 创建该岗位的 HR 账号与展示名（管理员视角）。 */
  owner_user_id?: string;
  hr_name?: string;
};

export type PipelineHrUser = {
  id: string;
  username: string;
  display_name: string;
  role_id?: string;
};

export type PipelineHrUsersResponse = {
  users: PipelineHrUser[];
  current_user_id?: string;
  can_select_all: boolean;
};

export type CreatePipelineRequest = {
  role: string;
  hints: string;
  location?: string;
  type: string;
  agents: string[];
  enabled_agents: string[];
};

export type CreatePipelineResponse = {
  pipeline_id?: string;
  status?: string;
  role?: string;
};

export type BatchDeletePipelinesResponse = {
  deleted: string[];
  failed: string[];
  count: number;
};

type ApiErrorOptions = {
  kind?: "http" | "timeout" | "aborted" | "backend_timeout" | "offline";
  status?: number;
  code?: string;
  /** 错误响应体，供调用方读取业务错误码等细节。 */
  data?: unknown;
};

export class ApiError extends Error {
  readonly kind: NonNullable<ApiErrorOptions["kind"]>;
  readonly status?: number;
  readonly code?: string;
  readonly data?: unknown;

  constructor(message: string, options: ApiErrorOptions = {}) {
    super(message);
    this.name = "ApiError";
    this.kind = options.kind ?? "http";
    this.status = options.status;
    this.code = options.code;
    this.data = options.data;
  }
}

/**
 * 仅用于避免网络连接无限挂起；耗时任务提交后由任务状态接口负责跟踪。
 * 各业务可为提交和状态查询传入更短的请求超时。
 */
export const NETWORK_SAFETY_TIMEOUT_MS = 300_000;

function getBackendErrorMessage(data: unknown): string {
  if (isRecord(data)) {
    if (typeof data.message === "string") {
      return data.message;
    }

    if (typeof data.detail === "string") {
      return data.detail;
    }

    if (isRecord(data.detail) && typeof data.detail.message === "string") {
      return data.detail.message;
    }
  }

  return "任务执行超时，请稍后重试。";
}

function getBackendErrorCode(data: unknown): string {
  if (isRecord(data) && typeof data.code === "string") {
    return data.code;
  }

  if (isRecord(data) && isRecord(data.detail) && typeof data.detail.code === "string") {
    return data.detail.code;
  }

  return "backend_timeout";
}

async function readErrorDetail(response: Response, fallback: string): Promise<string> {
  try {
    const data: unknown = await response.json();
    if (isRecord(data)) {
      const detail = getString(data.detail);
      if (detail) return detail;
    }
  } catch {
    // 忽略解析失败，使用兜底文案
  }
  return `${fallback}：${response.status}`;
}

async function createBackendTimeoutError(response: Response): Promise<ApiError> {
  const data: unknown = await response.json().catch(() => ({}));
  return new ApiError(getBackendErrorMessage(data), {
    kind: "backend_timeout",
    status: response.status,
    code: getBackendErrorCode(data),
    data,
  });
}

export async function requestWithTimeout<T>(
  input: RequestInfo | URL,
  init: RequestInit,
  parseResponse: (response: Response) => Promise<T>,
  timeoutMs = NETWORK_SAFETY_TIMEOUT_MS,
): Promise<T> {
  const controller = new AbortController();
  const callerSignal = init.signal;
  let didTimeout = false;
  const timeoutId = setTimeout(() => {
    didTimeout = true;
    controller.abort();
  }, timeoutMs);

  const abortFromCaller = () => controller.abort();
  if (callerSignal) {
    if (callerSignal.aborted) {
      controller.abort();
    } else {
      callerSignal.addEventListener("abort", abortFromCaller, { once: true });
    }
  }

  try {
    const response = await fetch(input, { ...init, signal: controller.signal });
    if (response.status === 504) {
      throw await createBackendTimeoutError(response);
    }

    return await parseResponse(response);
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }

    if (error instanceof Error && error.name === "AbortError") {
      if (callerSignal?.aborted) {
        throw new ApiError("请求已取消。", { kind: "aborted" });
      }

      throw new ApiError("请求超时，请稍后重试。", { kind: "timeout" });
    }

    if (didTimeout) {
      throw new ApiError("请求超时，请稍后重试。", { kind: "timeout" });
    }

    if (error instanceof TypeError) {
      throw new ApiError("网络不可用，请检查网络连接后重试。", { kind: "offline" });
    }

    throw error;
  } finally {
    clearTimeout(timeoutId);
    callerSignal?.removeEventListener("abort", abortFromCaller);
  }
}

export type PipelineListParams = {
  q?: string;
  createdFrom?: string;
  createdTo?: string;
  ownerUserId?: string;
};

export async function fetchPipelines(params: PipelineListParams = {}): Promise<Pipeline[]> {
  const query = new URLSearchParams();
  if (params.q?.trim()) {
    query.set("q", params.q.trim());
  }
  if (params.createdFrom) {
    query.set("created_from", params.createdFrom);
  }
  if (params.createdTo) {
    query.set("created_to", params.createdTo);
  }
  if (params.ownerUserId) {
    query.set("owner_user_id", params.ownerUserId);
  }
  const queryString = query.toString();
  const endpoint = queryString ? `/api/pipelines?${queryString}` : "/api/pipelines";

  return requestWithTimeout(endpoint, { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(await readErrorDetail(response, "岗位请求失败"), { status: response.status });
    }

    const data: unknown = await response.json();
    const pipelines = Array.isArray(data)
      ? data
      : data && typeof data === "object" && "pipelines" in data && Array.isArray(data.pipelines)
        ? data.pipelines
        : [];

    return pipelines.flatMap((pipeline) => {
      const normalizedPipeline = normalizePipeline(pipeline);
      return normalizedPipeline ? [normalizedPipeline] : [];
    });
  });
}

export async function fetchPipelineHrUsers(): Promise<PipelineHrUsersResponse> {
  return requestWithTimeout("/api/pipelines/hr-users", { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(`HR 列表请求失败：${response.status}`, { status: response.status });
    }

    const data: unknown = await response.json();
    if (!isRecord(data)) {
      return { users: [], can_select_all: false };
    }

    const users: PipelineHrUser[] = Array.isArray(data.users)
      ? data.users.flatMap((item) => {
          if (!isRecord(item)) {
            return [];
          }

          const id = getString(item.id);
          const username = getString(item.username);
          const displayName = getString(item.display_name) || username;
          if (!id || !displayName) {
            return [];
          }

          return [{ id, username: username ?? "", display_name: displayName, role_id: getString(item.role_id) }];
        })
      : [];

    return {
      users,
      current_user_id: getString(data.current_user_id),
      can_select_all: data.can_select_all === true,
    };
  });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getString(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function getStringArray(value: unknown) {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === "string");
  }

  if (typeof value === "string") {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
    } catch {
      return [];
    }
  }

  return [];
}

function normalizeStage(value: unknown): PipelineStage | null {
  if (!isRecord(value)) {
    return null;
  }

  const stage: PipelineStage = {};
  const stageId = getString(value.stage_id);
  const status = getString(value.status);

  if (stageId) {
    stage.stage_id = stageId;
  }

  if (status) {
    stage.status = status;
  }

  return stage;
}

function normalizePipeline(value: unknown): Pipeline | null {
  if (!isRecord(value)) {
    return null;
  }

  const pipeline: Pipeline = {};
  const id = getString(value.id);
  const pipelineId = getString(value.pipeline_id);
  const role = getString(value.role);
  const status = getString(value.status);
  const createdAt = getString(value.created_at);
  const type = getString(value.type) ?? getString(value.pipeline_type);
  const agents = getStringArray(value.agents);
  const ownerUserId = getString(value.owner_user_id);
  const hrName = getString(value.hr_name);

  if (id) {
    pipeline.id = id;
  }

  if (pipelineId) {
    pipeline.pipeline_id = pipelineId;
  }

  if (role) {
    pipeline.role = role;
  }

  if (status) {
    pipeline.status = status;
  }

  if (createdAt) {
    pipeline.created_at = createdAt;
  }

  if (type) {
    pipeline.type = type;
    pipeline.pipeline_type = type;
  }

  if (ownerUserId) {
    pipeline.owner_user_id = ownerUserId;
  }

  if (hrName) {
    pipeline.hr_name = hrName;
  }

  if (typeof value.candidate_count === "number") {
    pipeline.candidate_count = value.candidate_count;
  }

  if (agents.length > 0) {
    pipeline.agents = agents;
  }

  if (Array.isArray(value.stages)) {
    pipeline.stages = value.stages.flatMap((stage) => {
      const normalizedStage = normalizeStage(stage);
      return normalizedStage ? [normalizedStage] : [];
    });
  }

  return pipeline;
}

function normalizeCreatePipelineResponse(value: unknown): CreatePipelineResponse {
  if (!isRecord(value)) {
    return {};
  }

  const response: CreatePipelineResponse = {};
  const pipelineId = getString(value.pipeline_id);
  const status = getString(value.status);
  const role = getString(value.role);

  if (pipelineId) {
    response.pipeline_id = pipelineId;
  }

  if (status) {
    response.status = status;
  }

  if (role) {
    response.role = role;
  }

  return response;
}

export async function createPipeline(request: CreatePipelineRequest): Promise<CreatePipelineResponse> {
  return requestWithTimeout(
    "/api/pipelines",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(request),
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "岗位创建失败"), { status: response.status });
      }

      return normalizeCreatePipelineResponse(await response.json());
    },
  );
}

export async function deletePipeline(pipelineId: string): Promise<void> {
  await requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}`,
    {
      method: "DELETE",
      credentials: "include",
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "岗位删除失败"), { status: response.status });
      }
    },
  );
}

export async function batchDeletePipelines(pipelineIds: string[]): Promise<BatchDeletePipelinesResponse> {
  return requestWithTimeout(
    "/api/pipelines/batch",
    {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ ids: pipelineIds }),
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "批量删除岗位失败"), { status: response.status });
      }

      const data: unknown = await response.json();
      if (!isRecord(data)) {
        return { deleted: [], failed: pipelineIds, count: 0 };
      }

      const deleted = getStringArray(data.deleted);
      const failed = getStringArray(data.failed);
      return {
        deleted,
        failed,
        count: typeof data.count === "number" ? data.count : deleted.length,
      };
    },
  );
}

export async function startPipeline(pipelineId: string): Promise<void> {
  await requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/auto-run`,
    {
      method: "POST",
      credentials: "include",
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "岗位启动失败"), { status: response.status });
      }
    },
  );
}

export function getPipelineStatus(pipeline: Pipeline) {
  if (pipeline.status === "completed") {
    return "已完成";
  }

  if (
    pipeline.status === "running" ||
    pipeline.status === "running_auto" ||
    pipeline.status === "waiting_human" ||
    pipeline.status === "waiting_for_resumes" ||
    pipeline.status === "waiting_for_videos" ||
    pipeline.stages?.some((stage) => stage.status === "running")
  ) {
    return "进行中";
  }

  return "待启动";
}

export function getPipelineStats(pipelines: Pipeline[]) {
  const total = pipelines.length;
  const running = pipelines.filter((pipeline) => getPipelineStatus(pipeline) === "进行中").length;
  const done = pipelines.filter((pipeline) => getPipelineStatus(pipeline) === "已完成").length;
  const candidates = pipelines.reduce((sum, pipeline) => sum + (pipeline.candidate_count ?? 0), 0);

  return {
    total,
    running,
    done,
    candidates,
    rate: total ? Math.round((done / total) * 100) : 0,
  };
}
