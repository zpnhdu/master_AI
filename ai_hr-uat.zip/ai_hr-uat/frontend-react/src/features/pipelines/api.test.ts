import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import {
  batchDeletePipelines,
  createPipeline,
  deletePipeline,
  fetchPipelineHrUsers,
  fetchPipelines,
  getPipelineStats,
  getPipelineStatus,
  NETWORK_SAFETY_TIMEOUT_MS,
  requestWithTimeout,
  startPipeline,
} from "./api";
import { useCreatePipelineMutation, useDeletePipelineMutation } from "./hooks";

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("pipelines api", () => {
  function createQueryWrapper(queryClient: QueryClient) {
    return ({ children }: { children: ReactNode }) =>
      createElement(QueryClientProvider, { client: queryClient }, children);
  }

  it("loads a list response and derives pipeline stats", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [
          { id: "done", status: "completed", type: "tech", candidate_count: 3 },
          { id: "running", stages: [{ status: "running" }], candidate_count: 2 },
        ],
      }),
    );

    const pipelines = await fetchPipelines();

    expect(pipelines).toHaveLength(2);
    expect(pipelines[0].type).toBe("tech");
    expect(pipelines[0].pipeline_type).toBe("tech");
    expect(getPipelineStatus(pipelines[0])).toBe("已完成");
    expect(getPipelineStats(pipelines)).toEqual({
      total: 2,
      running: 1,
      done: 1,
      candidates: 5,
      rate: 50,
    });
  });

  it("passes list filters as encoded query parameters", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => [] }));

    await fetchPipelines({
      q: "Java 后端",
      createdFrom: "2026-08-01",
      createdTo: "2026-08-31",
      ownerUserId: "user_hr_01",
    });

    expect(fetch).toHaveBeenCalledWith(
      "/api/pipelines?q=Java+%E5%90%8E%E7%AB%AF&created_from=2026-08-01&created_to=2026-08-31&owner_user_id=user_hr_01",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("loads the HR selector accounts and the admin flag", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({
          users: [
            { id: "user_a", username: "zhangsan", display_name: "张三", role_id: "hr_specialist" },
            { id: "user_b", username: "lisi", display_name: "", role_id: "hr_specialist" },
          ],
          current_user_id: "user_admin",
          can_select_all: true,
        }),
      }),
    );

    const selector = await fetchPipelineHrUsers();

    expect(selector).toEqual({
      users: [
        { id: "user_a", username: "zhangsan", display_name: "张三", role_id: "hr_specialist" },
        { id: "user_b", username: "lisi", display_name: "lisi", role_id: "hr_specialist" },
      ],
      current_user_id: "user_admin",
      can_select_all: true,
    });
  });

  it("falls back to an empty selector when the HR list response is malformed", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => [] }));

    await expect(fetchPipelineHrUsers()).resolves.toEqual({ users: [], can_select_all: false });
  });

  it("throws when the server returns an error", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 500 }));

    await expect(fetchPipelines()).rejects.toThrow("岗位请求失败：500");
  });

  it("returns an empty list for an unexpected list response", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => ({}) }));

    await expect(fetchPipelines()).resolves.toEqual([]);
  });

  it("drops invalid pipeline items from a list response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [null, "bad", { id: "ok", status: "completed" }],
      }),
    );

    await expect(fetchPipelines()).resolves.toEqual([{ id: "ok", status: "completed" }]);
  });

  it("propagates network errors from the list request", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("网络不可用")));

    await expect(fetchPipelines()).rejects.toThrow("网络不可用");
  });

  it.each([
    [Object.assign(new Error("The operation timed out"), { name: "AbortError" }), "请求超时，请稍后重试。"],
    [new TypeError("Failed to fetch"), "网络不可用，请检查网络连接后重试。"],
  ])("maps %s from the list request to a user-readable error", async (error, message) => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(error));

    await expect(fetchPipelines()).rejects.toThrow(message);
  });

  it("aborts a list request when it exceeds the timeout", async () => {
    vi.useFakeTimers();
    vi.stubGlobal(
      "fetch",
      vi.fn(
        (_input, init) =>
          new Promise((_resolve, reject) => {
            init?.signal?.addEventListener("abort", () => {
              reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
            });
          }),
      ),
    );

    const request = expect(fetchPipelines()).rejects.toMatchObject({
      kind: "timeout",
      message: "请求超时，请稍后重试。",
    });
    await vi.advanceTimersByTimeAsync(NETWORK_SAFETY_TIMEOUT_MS);

    await request;
  });

  it("aborts while reading a response body when it exceeds the timeout", async () => {
    vi.useFakeTimers();
    vi.stubGlobal(
      "fetch",
      vi.fn((_input, init) =>
        Promise.resolve({
          ok: true,
          status: 200,
          json: () =>
            new Promise((_resolve, reject) => {
              init?.signal?.addEventListener("abort", () => {
                reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
              });
            }),
        }),
      ),
    );

    const request = expect(fetchPipelines()).rejects.toMatchObject({
      kind: "timeout",
      message: "请求超时，请稍后重试。",
    });
    await vi.advanceTimersByTimeAsync(NETWORK_SAFETY_TIMEOUT_MS);

    await request;
  });

  it("classifies a caller abort separately from the network safety timeout", async () => {
    const abortController = new AbortController();
    abortController.abort();
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(Object.assign(new Error("Aborted"), { name: "AbortError" })));

    await expect(
      requestWithTimeout("/api/cancel", { signal: abortController.signal }, async () => "done"),
    ).rejects.toMatchObject({
      kind: "aborted",
      message: "请求已取消。",
    });
  });

  it("classifies a backend 504 response with the structured timeout error", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: false,
        status: 504,
        json: async () => ({ detail: { code: "backend_timeout", message: "任务执行超时，请稍后重试" } }),
      }),
    );

    await expect(requestWithTimeout("/api/slow", {}, async () => "done")).rejects.toMatchObject({
      kind: "backend_timeout",
      code: "backend_timeout",
      status: 504,
      message: "任务执行超时，请稍后重试",
    });
  });

  it.each(["running", "running_auto", "waiting_human", "waiting_for_resumes", "waiting_for_videos"])(
    "treats pipeline status %s as in progress",
    (status) => {
      expect(getPipelineStatus({ status })).toBe("进行中");
    },
  );

  it("creates a pipeline with the supported request body", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 201,
      json: async () => ({ pipeline_id: "p_created", status: "created" }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const request = {
      role: "高级前端工程师",
      hints: "熟悉 React",
      type: "tech",
      agents: ["xiao_wen", "xiao_xun"],
      enabled_agents: ["xiao_wen", "xiao_xun"],
    };

    await expect(createPipeline(request)).resolves.toEqual({
      pipeline_id: "p_created",
      status: "created",
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines",
      expect.objectContaining({
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(request),
        signal: expect.any(AbortSignal),
      }),
    );
  });

  it.each([null, "bad"])("returns an empty response for invalid create response %p", async (body) => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => body }));

    await expect(
      createPipeline({ role: "后端工程师", hints: "", type: "tech", agents: [], enabled_agents: [] }),
    ).resolves.toEqual({});
  });

  it("deletes a pipeline with credentials included", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 204 });
    vi.stubGlobal("fetch", fetchMock);

    await expect(deletePipeline("p_delete")).resolves.toBeUndefined();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p_delete",
      expect.objectContaining({
        method: "DELETE",
        credentials: "include",
        signal: expect.any(AbortSignal),
      }),
    );
  });

  it("batch deletes pipelines and reports partial failures", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ deleted: ["p_1"], failed: ["p_2"], count: 1 }),
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(batchDeletePipelines(["p_1", "p_2"])).resolves.toEqual({
      deleted: ["p_1"],
      failed: ["p_2"],
      count: 1,
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/batch",
      expect.objectContaining({
        method: "DELETE",
        body: JSON.stringify({ ids: ["p_1", "p_2"] }),
        signal: expect.any(AbortSignal),
      }),
    );
  });

  it("starts a created pipeline through the auto-run endpoint", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 200 });
    vi.stubGlobal("fetch", fetchMock);

    await expect(startPipeline("p_start")).resolves.toBeUndefined();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p_start/auto-run",
      expect.objectContaining({ method: "POST", signal: expect.any(AbortSignal) }),
    );
  });

  it("propagates create and delete HTTP errors", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 400 })
      .mockResolvedValueOnce({ ok: false, status: 404 });
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      createPipeline({ role: "后端工程师", hints: "", type: "tech", agents: [], enabled_agents: [] }),
    ).rejects.toThrow("岗位创建失败：400");
    await expect(deletePipeline("p_missing")).rejects.toThrow("岗位删除失败：404");
  });

  it("invalidates pipelines after a successful create mutation", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 201,
        json: async () => ({ pipeline_id: "p_created" }),
      }),
    );
    const queryClient = new QueryClient();
    let resolveInvalidation!: () => void;
    const invalidation = new Promise<void>((resolve) => {
      resolveInvalidation = resolve;
    });
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockReturnValue(invalidation);

    const { result } = renderHook(() => useCreatePipelineMutation(), {
      wrapper: createQueryWrapper(queryClient),
    });

    const mutationPromise = result.current.mutateAsync({
      role: "数据分析师",
      hints: "",
      type: "tech",
      agents: ["xiao_wen"],
      enabled_agents: ["xiao_wen"],
    });

    await vi.waitFor(() => expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipelines"] }));
    let mutationResolved = false;
    void mutationPromise.then(() => {
      mutationResolved = true;
    });
    await Promise.resolve();
    expect(mutationResolved).toBe(false);
    resolveInvalidation();
    await mutationPromise;
    expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipelines"] });
  });

  it("invalidates pipelines after a successful delete mutation", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 204 }));
    const queryClient = new QueryClient();
    let resolveInvalidation!: () => void;
    const invalidation = new Promise<void>((resolve) => {
      resolveInvalidation = resolve;
    });
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockReturnValue(invalidation);

    const { result } = renderHook(() => useDeletePipelineMutation(), {
      wrapper: createQueryWrapper(queryClient),
    });

    const mutationPromise = result.current.mutateAsync("p_delete");

    await vi.waitFor(() => expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipelines"] }));
    let mutationResolved = false;
    void mutationPromise.then(() => {
      mutationResolved = true;
    });
    await Promise.resolve();
    expect(mutationResolved).toBe(false);
    resolveInvalidation();
    await mutationPromise;
    expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipelines"] });
  });
});
