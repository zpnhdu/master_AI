import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  batchDeletePipelines,
  createPipeline,
  deletePipeline,
  fetchPipelineHrUsers,
  fetchPipelines,
  startPipeline,
  type PipelineListParams,
} from "./api";

export function usePipelinesQuery(params: PipelineListParams = {}) {
  return useQuery({
    queryKey: ["pipelines", params],
    queryFn: () => fetchPipelines(params),
    staleTime: 15 * 1000,
  });
}

export function usePipelineHrUsersQuery() {
  return useQuery({
    queryKey: ["pipelines", "hr-users"] as const,
    queryFn: fetchPipelineHrUsers,
    staleTime: 5 * 60_000,
  });
}

export function useCreatePipelineMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createPipeline,
    onSuccess: () => {
      return queryClient.invalidateQueries({ queryKey: ["pipelines"] });
    },
  });
}

export function useDeletePipelineMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deletePipeline,
    onSuccess: () => {
      return queryClient.invalidateQueries({ queryKey: ["pipelines"] });
    },
  });
}

export function useBatchDeletePipelinesMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: batchDeletePipelines,
    onSuccess: () => {
      return queryClient.invalidateQueries({ queryKey: ["pipelines"] });
    },
  });
}

export function useStartPipelineMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: startPipeline,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["pipelines"] }),
  });
}
