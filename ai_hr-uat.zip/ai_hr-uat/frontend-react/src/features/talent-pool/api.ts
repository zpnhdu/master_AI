import { requestJson } from "../agent-workbench/api";
import { ApiError, requestWithTimeout } from "../pipelines/api";

export type TalentResume = {
  id: string;
  name?: string;
  title?: string;
  current_company?: string;
  years_experience?: number;
  skills?: string[];
  source?: string;
  location?: string;
  resume_text?: string;
  education?: string;
  email?: string;
  phone?: string;
  gender?: string;
  original_filename?: string;
  storage_backend?: string;
  storage_key?: string;
  tags?: string[];
  fingerprint_confidence?: number;
  linked_resume_id?: string;
  [key: string]: unknown;
};

export type TalentResumeSearchResult = {
  items?: TalentResume[];
  results: TalentResume[];
  total: number;
  returned: number;
  page?: number;
  page_size?: number;
};

export type UploadResult = {
  id?: string;
  existing_id?: string;
  filename?: string;
  skipped?: boolean;
  reason?: string;
  duplicate?: boolean;
  [key: string]: unknown;
};

export type TalentPoolSearchParams = {
  q?: string;
  location?: string;
  min_years?: number;
  limit?: number;
  page?: number;
  page_size?: number;
  sort_by?: TalentResumeSortField;
  sort_order?: SortOrder;
};

export type TalentResumeSortField =
  "name" | "title" | "current_company" | "years_experience" | "location" | "created_at" | "updated_at";

export type SortOrder = "asc" | "desc";

export function searchTalentResumes(params: TalentPoolSearchParams) {
  const search = new URLSearchParams();
  if (params.q) search.set("q", params.q);
  if (params.location) search.set("location", params.location);
  if (params.min_years) search.set("min_years", String(params.min_years));
  if (params.page) search.set("page", String(params.page));
  if (params.page_size) search.set("page_size", String(params.page_size));
  if (params.sort_by) search.set("sort_by", params.sort_by);
  if (params.sort_order) search.set("sort_order", params.sort_order);
  search.set("limit", String(params.limit ?? 20));
  return requestJson<TalentResumeSearchResult>(`/api/talent-pool/resumes?${search.toString()}`, {}, "人才库加载失败");
}

export function fetchTalentResume(resumeId: string) {
  return requestJson<TalentResume>(`/api/talent-pool/resumes/${encodeURIComponent(resumeId)}`, {}, "简历详情加载失败");
}

/** 简历原件的统一取件地址：项目里所有查看/下载简历原件的地方都应经由它拼接，勿再散落手写 URL。 */
export function talentResumeOriginalUrl(
  resumeId: string,
  options: { proxy?: boolean; download?: boolean } = {},
): string {
  if (!resumeId) return "";
  const params = new URLSearchParams();
  if (options.proxy) params.set("proxy", "true");
  if (options.download) params.set("download", "true");
  const query = params.toString();
  return `/api/talent-pool/resumes/${encodeURIComponent(resumeId)}/original${query ? `?${query}` : ""}`;
}

export function addTalentResume(body: Record<string, unknown>) {
  return requestJson<Record<string, unknown>>(
    "/api/talent-pool/resumes",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, source: body.source ?? "manual" }),
    },
    "添加简历失败",
  );
}

export function deleteTalentResume(resumeId: string) {
  return requestJson<{ status: string; id: string }>(
    `/api/talent-pool/resumes/${encodeURIComponent(resumeId)}`,
    { method: "DELETE" },
    "删除简历失败",
  );
}

export async function uploadTalentResumes(files: File[], text = "", pipelineId = "") {
  const form = new FormData();
  for (const file of files) form.append("files", file);
  if (text.trim()) form.append("text", text);
  const query = pipelineId ? `?pipeline_id=${encodeURIComponent(pipelineId)}` : "";
  return requestWithTimeout(
    `/api/talent-pool/upload${query}`,
    { method: "POST", credentials: "include", body: form },
    async (response) => {
      const payload: unknown = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail =
          typeof payload === "object" && payload !== null && "detail" in payload && typeof payload.detail === "string"
            ? payload.detail
            : "简历上传失败";
        throw new ApiError(`${detail}（${response.status}）`, { status: response.status, data: payload });
      }
      return payload as { results: UploadResult[]; count: number };
    },
  );
}

export type EmailSyncRun = {
  id: string;
  email_account_id: string;
  account_name?: string;
  email_address?: string;
  status: "queued" | "running" | "succeeded" | "failed" | "partial_success" | string;
  error_code?: string;
  error_message?: string;
  imported_count?: number;
  deduped_count?: number;
  failed_count?: number;
  [key: string]: unknown;
};

export function triggerSyncAllEmailAccounts() {
  return requestJson<{ triggered: number; run_ids: string[] }>(
    "/api/email-accounts/sync-all",
    { method: "POST" },
    "触发邮箱同步失败",
  );
}

export function fetchEmailSyncRuns(runIds: string[]) {
  const search = new URLSearchParams({ run_ids: runIds.join(",") });
  return requestJson<{ items: EmailSyncRun[] }>(
    `/api/email-accounts/sync-runs?${search.toString()}`,
    {},
    "获取邮箱同步结果失败",
  );
}
