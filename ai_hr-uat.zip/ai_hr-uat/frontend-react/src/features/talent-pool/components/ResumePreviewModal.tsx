import { useQuery } from "@tanstack/react-query";
import { Alert, Button, Divider, Empty, Modal, Space, Spin } from "antd";
import { DownloadOutlined, PrinterOutlined, ZoomInOutlined, ZoomOutOutlined } from "@ant-design/icons";
import { useEffect, useRef, useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import mammoth from "mammoth";

import pdfjsWorkerRaw from "pdfjs-dist/build/pdf.worker.min.mjs?raw";

import { fetchCandidateResume } from "../../agent-workbench/api";
import { fetchTalentResume, talentResumeOriginalUrl } from "../api";

pdfjs.GlobalWorkerOptions.workerSrc = URL.createObjectURL(
  new Blob([pdfjsWorkerRaw], { type: "application/javascript" }),
);

export type ResumeDetailCandidate = {
  id?: string;
  name?: string;
  resumeId?: string;
  resume_id?: string;
  original_filename?: string;
  storage_key?: string;
  [key: string]: unknown;
};

type ResumePreviewModalProps = {
  pipelineId: string;
  candidate: ResumeDetailCandidate | null;
  /** 人才库场景：直接指定简历 id，跳过「候选人→简历」解析接口 */
  resumeId?: string;
  onClose: () => void;
};

function appendResumeQuery(url: string, options: { proxy?: boolean; download?: boolean }): string {
  const params = new URLSearchParams();
  if (options.proxy) params.set("proxy", "true");
  if (options.download) params.set("download", "true");
  const query = params.toString();
  if (!query) return url;
  return `${url}${url.includes("?") ? "&" : "?"}${query}`;
}

function PdfPreview({ url, scale }: { url: string; scale: number }) {
  const [numPages, setNumPages] = useState(0);
  const [loadError, setLoadError] = useState("");
  const [previewStatus, setPreviewStatus] = useState<"loading" | "ready" | "corrupted" | "error">("loading");

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;
    setPreviewStatus("loading");
    setLoadError("");

    void fetch(appendResumeQuery(url, { proxy: true }), {
      credentials: "include",
      signal: controller.signal,
    })
      .then((response) => {
        if (cancelled) return;
        if (response.status === 404) {
          setPreviewStatus("corrupted");
          return;
        }
        if (!response.ok) throw new Error(`PDF preview request failed: ${response.status}`);
        setPreviewStatus("ready");
      })
      .catch((error: unknown) => {
        if (cancelled || (error instanceof DOMException && error.name === "AbortError")) return;
        setLoadError(error instanceof Error ? error.message : "加载失败");
        setPreviewStatus("error");
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [url]);

  if (previewStatus === "corrupted") {
    return <Alert type="warning" showIcon title="PDF 文件已损坏" />;
  }

  if (previewStatus === "error") {
    return (
      <Alert
        type="warning"
        showIcon
        title="PDF 原件暂时无法预览。"
        description={loadError || "加载失败"}
      />
    );
  }

  const previewUrl = appendResumeQuery(url, { proxy: true });
  return (
    <div style={{ maxHeight: "calc(100vh - 260px)", overflow: "auto" }}>
      {previewStatus === "loading" ? (
        <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
          <Spin description="正在加载 PDF 预览" />
        </div>
      ) : null}
      {previewStatus === "ready" ? (
        <Document
          file={previewUrl}
          onLoadSuccess={({ numPages }: { numPages: number }) => {
            setNumPages(numPages);
            setLoadError("");
          }}
          onLoadError={(error: Error) => setLoadError(error?.message || "加载失败")}
          loading={
            <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
              <Spin description="正在加载 PDF 预览" />
            </div>
          }
          error={
            <Alert
              type="warning"
              showIcon
              title="PDF 原件暂时无法预览。"
              description={loadError || "加载失败"}
            />
          }
        >
          {Array.from({ length: numPages }, (_, i) => (
            <Page
              key={`page_${i + 1}`}
              pageNumber={i + 1}
              renderTextLayer={false}
              renderAnnotationLayer={false}
              width={760 * scale}
            />
          ))}
        </Document>
      ) : null}
    </div>
  );
}

function DocxPreview({ url }: { url: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "corrupted" | "error">("loading");

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;
    const container = containerRef.current;
    if (!container) return () => controller.abort();

    container.replaceChildren();
    setStatus("loading");
    void fetch(appendResumeQuery(url, { proxy: true }), { credentials: "include", signal: controller.signal })
      .then((response) => {
        if (cancelled) return null;
        if (response.status === 404) {
          setStatus("corrupted");
          return null;
        }
        if (!response.ok) throw new Error(`DOCX preview request failed: ${response.status}`);
        return response.arrayBuffer();
      })
      .then(async (data) => {
        if (data === null) return;
        const result = await mammoth.convertToHtml({ arrayBuffer: data });
        if (cancelled) return;
        container.innerHTML = result.value;
        setStatus("ready");
      })
      .catch((error: unknown) => {
        if (cancelled || (error instanceof DOMException && error.name === "AbortError")) return;
        setStatus("error");
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [url]);

  return (
    <div style={{ position: "relative", minHeight: 240 }}>
      {status === "loading" ? (
        <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
          <Spin description="正在加载简历预览" />
        </div>
      ) : null}
      {status === "corrupted" ? (
        <Alert type="warning" showIcon title="DOCX 文件已损坏" />
      ) : null}
      {status === "error" ? (
        <Alert type="warning" showIcon title="DOCX 原件暂时无法预览。" />
      ) : null}
      <div
        ref={containerRef}
        aria-label="DOCX 简历预览"
        className="resume-docx-preview"
        style={{
          display: status === "ready" ? "block" : "none",
          overflow: "auto",
          maxHeight: "calc(100vh - 200px)",
        }}
      />
    </div>
  );
}

function MdPreview({ url }: { url: string }) {
  const [content, setContent] = useState<string | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "corrupted" | "error">("loading");

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;
    setStatus("loading");

    void fetch(appendResumeQuery(url, { proxy: true }), { credentials: "include", signal: controller.signal })
      .then((response) => {
        if (cancelled) return null;
        if (response.status === 404) {
          setStatus("corrupted");
          return null;
        }
        if (!response.ok) throw new Error(`MD preview request failed: ${response.status}`);
        return response.text();
      })
      .then((text) => {
        if (text === null) return;
        if (!cancelled) {
          setContent(text);
          setStatus("ready");
        }
      })
      .catch((error: unknown) => {
        if (cancelled || (error instanceof DOMException && error.name === "AbortError")) return;
        setStatus("error");
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [url]);

  return (
    <div style={{ maxHeight: "calc(100vh - 200px)", overflow: "auto" }}>
      {status === "loading" ? (
        <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
          <Spin description="正在加载简历预览" />
        </div>
      ) : null}
      {status === "corrupted" ? (
        <Alert type="warning" showIcon title="MD 文件已损坏" />
      ) : null}
      {status === "error" ? (
        <Alert type="warning" showIcon title="MD 原件暂时无法预览。" />
      ) : null}
      {status === "ready" && content !== null ? (
        <div className="resume-md-preview">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
        </div>
      ) : null}
    </div>
  );
}

function TxtPreview({ url }: { url: string }) {
  const [content, setContent] = useState<string | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "corrupted" | "error">("loading");

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;
    setStatus("loading");

    void fetch(appendResumeQuery(url, { proxy: true }), { credentials: "include", signal: controller.signal })
      .then((response) => {
        if (cancelled) return null;
        if (response.status === 404) {
          setStatus("corrupted");
          return null;
        }
        if (!response.ok) throw new Error(`TXT preview request failed: ${response.status}`);
        return response.text();
      })
      .then((text) => {
        if (text === null) return;
        if (!cancelled) {
          setContent(text);
          setStatus("ready");
        }
      })
      .catch((error: unknown) => {
        if (cancelled || (error instanceof DOMException && error.name === "AbortError")) return;
        setStatus("error");
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [url]);

  return (
    <div style={{ maxHeight: "calc(100vh - 200px)", overflow: "auto" }}>
      {status === "loading" ? (
        <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
          <Spin description="正在加载简历预览" />
        </div>
      ) : null}
      {status === "corrupted" ? (
        <Alert type="warning" showIcon title="TXT 文件已损坏" />
      ) : null}
      {status === "error" ? (
        <Alert type="warning" showIcon title="TXT 原件暂时无法预览。" />
      ) : null}
      {status === "ready" && content !== null ? (
        <pre
          style={{
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            fontFamily: "inherit",
            fontSize: 14,
            lineHeight: 1.6,
            margin: 0,
          }}
        >
          {content}
        </pre>
      ) : null}
    </div>
  );
}

type PreviewToolbarProps = {
  downloadUrl: string;
  extension: string;
  scale: number;
  onScaleChange: (scale: number) => void;
};

function PreviewToolbar({
  downloadUrl,
  extension,
  scale,
  onScaleChange,
}: PreviewToolbarProps) {
  const showZoom = extension === "pdf";

  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
      <Space size={4}>
        <Button
          size="small"
          icon={<DownloadOutlined />}
          href={appendResumeQuery(downloadUrl, { download: true, proxy: true })}
          target="_blank"
          rel="noopener noreferrer"
        >
          下载
        </Button>
        <Button
          size="small"
          icon={<PrinterOutlined />}
          onClick={() => {
            if (extension === "pdf") {
              window.open(appendResumeQuery(downloadUrl, { proxy: true }), "_blank");
            } else {
              window.print();
            }
          }}
        >
          打印
        </Button>
        {showZoom ? (
          <>
            <Button
              size="small"
              icon={<ZoomOutOutlined />}
              disabled={scale <= 0.5}
              onClick={() => onScaleChange(Math.max(0.5, scale - 0.25))}
            />
            <span style={{ minWidth: 48, textAlign: "center", fontSize: 13, color: "#6b7280" }}>
              {Math.round(scale * 100)}%
            </span>
            <Button
              size="small"
              icon={<ZoomInOutlined />}
              disabled={scale >= 2.5}
              onClick={() => onScaleChange(Math.min(2.5, scale + 0.25))}
            />
          </>
        ) : null}
      </Space>
    </div>
  );
}

export function ResumePreviewModal({ pipelineId, candidate, resumeId: directResumeId, onClose }: ResumePreviewModalProps) {
  const candidateId = candidate ? String(candidate.id || "") : "";
  const resumeQuery = useQuery({
    queryKey: ["pipeline-candidate-resume", pipelineId, candidateId],
    queryFn: () => fetchCandidateResume(pipelineId, candidateId),
    enabled: Boolean(candidate && pipelineId && candidateId && !directResumeId),
    retry: false,
  });

  const [scale, setScale] = useState(1);

  const detail = resumeQuery.data;
  const originalFilename = String(
    detail?.original_filename
    || candidate?.original_filename
    || candidate?.filename
    || (typeof candidate?.source === "string" && candidate.source.startsWith("file:")
        ? candidate.source.slice(5)
        : "")
    || ""
  );
  // 后端找不到人才库简历时会回退返回候选人快照（storage_source=candidate_snapshot），
  // 此时 data.id 是候选人 id 而不是简历 id，不能用来拼原件 URL。
  const isCandidateSnapshot = detail?.storage_source === "candidate_snapshot";
  const resumeId = String(
    directResumeId
    || (isCandidateSnapshot ? detail?.resume_id : detail?.id || detail?.resume_id)
    || candidate?.resumeId
    || candidate?.resume_id
    || ""
  );
  // 已拿到简历 id 但文件名未知时（如人才库推荐项），补查一次元数据来推断文件格式。
  const needsMeta = Boolean(resumeId) && !originalFilename;
  const resumeMetaQuery = useQuery({
    queryKey: ["talent-pool-resume-meta", resumeId],
    queryFn: () => fetchTalentResume(resumeId),
    enabled: needsMeta,
    retry: false,
  });
  const effectiveFilename = originalFilename || String(resumeMetaQuery.data?.original_filename || "");
  const originalUrl = talentResumeOriginalUrl(resumeId);
  const extension = effectiveFilename.split(".").pop()?.toLowerCase() ?? "";

  const previewLoading =
    (resumeQuery.isPending && resumeQuery.fetchStatus !== "idle") ||
    (needsMeta && resumeMetaQuery.isPending && resumeMetaQuery.fetchStatus !== "idle");

  return (
    <Modal
      title={`${String(candidate?.name || "候选人")} · 简历详情`}
      open={Boolean(candidate)}
      onCancel={onClose}
      footer={null}
      centered
      width={820}
      destroyOnHidden
    >
      <Divider style={{ margin: "0 0 12px 0" }} />
      {originalUrl ? (
        <PreviewToolbar
          downloadUrl={originalUrl}
          extension={extension}
          scale={scale}
          onScaleChange={setScale}
        />
      ) : null}
      {previewLoading ? (
        <div style={{ display: "grid", minHeight: 240, placeItems: "center" }}>
          <Spin description="正在加载简历信息" />
        </div>
      ) : originalUrl && extension === "pdf" ? (
        <PdfPreview url={originalUrl} scale={scale} />
      ) : originalUrl && extension === "docx" ? (
        <DocxPreview url={originalUrl} />
      ) : originalUrl && extension === "md" ? (
        <MdPreview url={originalUrl} />
      ) : originalUrl && extension === "txt" ? (
        <TxtPreview url={originalUrl} />
      ) : resumeQuery.isError ? (
        <Alert
          type="error"
          showIcon
          title="简历详情加载失败"
          description={resumeQuery.error instanceof Error ? resumeQuery.error.message : "请稍后重试"}
        />
      ) : needsMeta && resumeMetaQuery.isError ? (
        <Alert type="warning" showIcon title="简历信息加载失败，无法判断文件格式。" />
      ) : originalUrl ? (
        <Alert type="info" showIcon title="暂不支持预览此格式的简历。" />
      ) : (
        <Empty description="暂无简历文件" />
      )}
    </Modal>
  );
}