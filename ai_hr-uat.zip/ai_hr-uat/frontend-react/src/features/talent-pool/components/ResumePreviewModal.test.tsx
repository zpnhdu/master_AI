import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { fetchCandidateResume } from "../../agent-workbench/api";
import { fetchTalentResume } from "../api";
import type { TalentResume } from "../api";
import { ResumePreviewModal } from "./ResumePreviewModal";

vi.mock("../../agent-workbench/api", () => ({
  fetchCandidateResume: vi.fn(),
}));

vi.mock("../api", async () => {
  const actual = await vi.importActual<typeof import("../api")>("../api");
  return { ...actual, fetchTalentResume: vi.fn() };
});

vi.mock("react-pdf", () => ({
  pdfjs: { GlobalWorkerOptions: { workerSrc: "" }, version: "6.0.0" },
  Document: ({ file, loading, error, children }: { file: string; loading: React.ReactNode; error: React.ReactNode; children: React.ReactNode }) => (
    <div data-testid="pdf-document" data-file={file}>
      {children}
    </div>
  ),
  Page: ({ pageNumber }: { pageNumber: number }) => (
    <div data-testid="pdf-page" data-page={pageNumber} />
  ),
}));

vi.mock("mammoth", () => ({
  default: {
    convertToHtml: vi.fn().mockResolvedValue({ value: "<p>DOCX 页面内容</p>" }),
  },
}));

vi.mock("react-markdown", () => ({
  default: ({ children }: { children: string }) => (
    <div data-testid="md-content">{children}</div>
  ),
}));

vi.mock("remark-gfm", () => ({
  default: {},
}));

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

function buildCandidate(overrides: Record<string, unknown> = {}) {
  return {
    id: "candidate-1",
    name: "张三",
    ...overrides,
  };
}

function renderWithQuery(ui: React.ReactElement) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={queryClient}>{ui}</QueryClientProvider>,
  );
}

describe("ResumePreviewModal", () => {
  it("renders PDF preview", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-pdf",
      name: "张三",
      original_filename: "张三简历.pdf",
      storage_key: "ai-hr/resume.pdf",
    });
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(null, { status: 200 }),
    );
    vi.stubGlobal("fetch", fetchMock);

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByTestId("pdf-document")).toHaveAttribute(
      "data-file",
      "/api/talent-pool/resumes/resume-pdf/original?proxy=true",
    );
    expect(screen.getByText("张三 · 简历详情")).toBeInTheDocument();
  });

  it("renders DOCX preview with mammoth", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-1",
      name: "张三",
      original_filename: "张三简历.docx",
      storage_key: "ai-hr/resume.docx",
    });
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(new Uint8Array([1, 2, 3]), {
        status: 200,
        headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        "/api/talent-pool/resumes/resume-1/original?proxy=true",
        expect.objectContaining({ credentials: "include" }),
      );
    });

    const { default: mammoth } = await import("mammoth");
    expect(mammoth.convertToHtml).toHaveBeenCalled();
  });

  it("renders MD preview with react-markdown", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-md",
      name: "张三",
      original_filename: "张三简历.md",
      storage_key: "ai-hr/resume.md",
    });
    const fetchMock = vi.fn().mockResolvedValue(
      new Response("# 简历标题\n\n内容", { status: 200, headers: { "Content-Type": "text/markdown" } }),
    );
    vi.stubGlobal("fetch", fetchMock);

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    const mdContent = await screen.findByTestId("md-content");
    expect(mdContent.textContent).toContain("# 简历标题");
    expect(mdContent.textContent).toContain("内容");
  });

  it("renders TXT preview", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-txt",
      name: "张三",
      original_filename: "张三简历.txt",
      storage_key: "ai-hr/resume.txt",
    });
    const fetchMock = vi.fn().mockResolvedValue(
      new Response("纯文本简历内容", { status: 200, headers: { "Content-Type": "text/plain" } }),
    );
    vi.stubGlobal("fetch", fetchMock);

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("纯文本简历内容")).toBeInTheDocument();
  });

  it("does not render when candidate is null", () => {
    renderWithQuery(
      <ResumePreviewModal pipelineId="pipeline-1" candidate={null} onClose={vi.fn()} />,
    );

    const titles = screen.queryAllByText("简历详情");
    expect(titles).toHaveLength(0);
  });

  it("shows empty state when no resume file", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "",
      name: "张三",
      original_filename: "",
      storage_key: "",
    });
    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("暂无简历文件")).toBeInTheDocument();
  });

  it("shows alert for unsupported file format", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-xls",
      name: "张三",
      original_filename: "张三简历.xls",
      storage_key: "ai-hr/resume.xls",
    });
    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("暂不支持预览此格式的简历。")).toBeInTheDocument();
  });

  it("uses candidate name for modal title", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-1",
      name: "李四",
      original_filename: "李四简历.pdf",
      storage_key: "ai-hr/resume.pdf",
    });
    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate({ name: "李四" })}
        onClose={vi.fn()}
      />,
    );

    expect(screen.getByText("李四 · 简历详情")).toBeInTheDocument();
  });

  it("shows empty state for a candidate snapshot without a linked resume id", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "candidate-1",
      candidate_id: "candidate-1",
      storage_source: "candidate_snapshot",
      name: "张三",
    });
    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("暂无简历文件")).toBeInTheDocument();
  });

  it("uses the linked resume id when the backend returns a candidate snapshot", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "candidate-1",
      resume_id: "resume-snapshot-linked",
      storage_source: "candidate_snapshot",
      name: "张三",
      original_filename: "张三简历.pdf",
    });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 200 })));

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByTestId("pdf-document")).toHaveAttribute(
      "data-file",
      "/api/talent-pool/resumes/resume-snapshot-linked/original?proxy=true",
    );
  });

  it("renders a talent-pool resume directly from its resume id without the pipeline hop", async () => {
    vi.mocked(fetchCandidateResume).mockReset();
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 200 })));
    renderWithQuery(
      <ResumePreviewModal
        pipelineId=""
        resumeId="resume-direct"
        candidate={{ id: "resume-direct", name: "王五", original_filename: "王五简历.pdf" }}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByTestId("pdf-document")).toHaveAttribute(
      "data-file",
      "/api/talent-pool/resumes/resume-direct/original?proxy=true",
    );
    expect(fetchCandidateResume).not.toHaveBeenCalled();
  });

  it("fetches resume metadata when the direct resume id has no filename", async () => {
    vi.mocked(fetchTalentResume).mockResolvedValue({
      id: "resume-direct",
      name: "赵六",
      original_filename: "赵六简历.pdf",
    } as TalentResume);
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 200 })));
    renderWithQuery(
      <ResumePreviewModal
        pipelineId=""
        resumeId="resume-direct"
        candidate={{ id: "resume-direct", name: "赵六" }}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByTestId("pdf-document")).toHaveAttribute(
      "data-file",
      "/api/talent-pool/resumes/resume-direct/original?proxy=true",
    );
    expect(fetchTalentResume).toHaveBeenCalledWith("resume-direct");
  });

  it("shows corrupted message when PDF file not found (404)", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-pdf-404",
      name: "张三",
      original_filename: "张三简历.pdf",
      storage_key: "ai-hr/resume.pdf",
    });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 404 })));

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("PDF 文件已损坏")).toBeInTheDocument();
  });

  it("shows corrupted message when DOCX file not found (404)", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-docx-404",
      name: "张三",
      original_filename: "张三简历.docx",
      storage_key: "ai-hr/resume.docx",
    });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 404 })));

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("DOCX 文件已损坏")).toBeInTheDocument();
  });

  it("shows corrupted message when MD file not found (404)", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-md-404",
      name: "张三",
      original_filename: "张三简历.md",
      storage_key: "ai-hr/resume.md",
    });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 404 })));

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("MD 文件已损坏")).toBeInTheDocument();
  });

  it("shows corrupted message when TXT file not found (404)", async () => {
    vi.mocked(fetchCandidateResume).mockResolvedValue({
      id: "resume-txt-404",
      name: "张三",
      original_filename: "张三简历.txt",
      storage_key: "ai-hr/resume.txt",
    });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(null, { status: 404 })));

    renderWithQuery(
      <ResumePreviewModal
        pipelineId="pipeline-1"
        candidate={buildCandidate()}
        onClose={vi.fn()}
      />,
    );

    expect(await screen.findByText("TXT 文件已损坏")).toBeInTheDocument();
  });
});
