import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  addTalentResume,
  deleteTalentResume,
  searchTalentResumes,
  triggerSyncAllEmailAccounts,
  uploadTalentResumes,
  type TalentPoolSearchParams,
} from "./api";

export const talentPoolKeys = {
  all: ["talent-pool"] as const,
  resumes: (params: TalentPoolSearchParams) => ["talent-pool", "resumes", params] as const,
};

export function useTalentResumesQuery(params: TalentPoolSearchParams) {
  return useQuery({
    queryKey: talentPoolKeys.resumes(params),
    queryFn: () => searchTalentResumes(params),
    placeholderData: keepPreviousData,
  });
}

function useInvalidateTalentPool() {
  const queryClient = useQueryClient();
  return () => queryClient.invalidateQueries({ queryKey: talentPoolKeys.all });
}

export function useAddTalentResumeMutation() {
  const invalidate = useInvalidateTalentPool();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) => addTalentResume(body),
    onSuccess: invalidate,
  });
}

export function useDeleteTalentResumeMutation() {
  const invalidate = useInvalidateTalentPool();
  return useMutation({
    mutationFn: ({ resumeId }: { resumeId: string }) => deleteTalentResume(resumeId),
    onSuccess: invalidate,
  });
}

export function useUploadTalentResumesMutation() {
  const invalidate = useInvalidateTalentPool();
  return useMutation({
    mutationFn: ({ files, text }: { files: File[]; text?: string }) => uploadTalentResumes(files, text ?? ""),
    onSuccess: invalidate,
  });
}

export function useTriggerSyncAllEmailAccountsMutation() {
  const invalidate = useInvalidateTalentPool();
  return useMutation({ mutationFn: triggerSyncAllEmailAccounts, onSuccess: invalidate });
}
