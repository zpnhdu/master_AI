import '@testing-library/jest-dom/vitest';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { MaterialPicker } from './MaterialPicker';

afterEach(() => {
  vi.restoreAllMocks();
});

describe('MaterialPicker', () => {
  it('supports one background and multiple element selections', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(
      new Response(
        JSON.stringify({
          backgrounds: [
            { id: 'bg-1', label: '门店背景', url: '/bg-1.png' },
            { id: 'bg-2', label: '绿色背景', url: '/bg-2.png' },
          ],
          elements: [
            { id: 'el-1', label: '品牌贴纸', url: '/el-1.png' },
            { id: 'el-2', label: '小熊 IP', url: '/el-2.png' },
          ],
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } },
      ),
    );
    const onBackgroundChange = vi.fn();
    const onElementIdsChange = vi.fn();
    const onUseDefault = vi.fn();

    render(
      <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
        <MemoryRouter>
          <MaterialPicker
            canvasId="long"
            selectedBackgroundId=""
            selectedElementIds={['el-1']}
            onBackgroundChange={onBackgroundChange}
            onElementIdsChange={onElementIdsChange}
            onUseDefault={onUseDefault}
          />
        </MemoryRouter>
      </QueryClientProvider>,
    );

    expect(screen.getByText('锅圈品牌底图')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '选择背景与装饰' }));
    await waitFor(() => expect(screen.getByRole('button', { name: '选择门店背景' })).toBeInTheDocument());
    fireEvent.click(screen.getByRole('button', { name: '选择门店背景' }));
    fireEvent.click(screen.getByRole('button', { name: '选择小熊 IP' }));
    fireEvent.click(screen.getByRole('button', { name: '取消选择品牌贴纸' }));

    expect(onBackgroundChange).toHaveBeenCalledWith('bg-1');
    expect(onElementIdsChange).toHaveBeenNthCalledWith(1, ['el-1', 'el-2']);
    expect(onElementIdsChange).toHaveBeenNthCalledWith(2, []);
    expect(screen.getByText('装饰 · 1/2')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '恢复品牌默认' }));
    expect(onUseDefault).toHaveBeenCalledOnce();
  });
});
