import { requestJson } from "../agent-workbench/api";

export const GENERATION_SUBMIT_TIMEOUT_MS = 15_000;
export const GENERATION_STATUS_TIMEOUT_MS = 10_000;

export type PosterFieldSet = Record<string, unknown> & {
  jobTitle?: string;
  companyName?: string;
  salary?: string;
  location?: string;
  hero_kicker?: string;
  hero_title?: string;
  slogan?: string;
};

export type PosterVersion = {
  id: string;
  version_number?: number;
  image_url?: string;
  image_asset_id?: string;
  status?: string;
  approved_at?: string;
  canvas_id?: string;
  fields?: PosterFieldSet;
  created_at?: string;
  [key: string]: unknown;
};

export type PosterJob = {
  id: string;
  pipeline_id: string;
  command_id?: string;
  source: "workspace" | "conversation";
  status: "queued" | "running" | "cancel_requested" | "succeeded" | "failed" | "cancelled";
  phase: string;
  progress: number;
  created_at: string;
  started_at?: string | null;
  completed_at?: string | null;
  server_time: string;
  elapsed_seconds: number;
  estimated_remaining_seconds?: [number, number] | null;
  estimate_basis: string;
  estimate_overrun: boolean;
  result_version_id: string;
  error_code?: string;
  error_message?: string;
};

export const isActivePosterJob = (job: PosterJob) => ["queued", "running", "cancel_requested"].includes(job.status);

export function fetchPosterJobs(pipelineId: string) {
  return requestJson<{ jobs: PosterJob[] }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs`,
    {},
    "生成状态查询失败",
  ).then((data) => ({
    jobs: Array.isArray(data.jobs) ? data.jobs.filter((job) => job && typeof job.id === "string") : [],
  }));
}

export function createPosterJob(
  pipelineId: string,
  body: Parameters<typeof generatePoster>[1] & { client_request_id: string },
) {
  return requestJson<{ job: PosterJob }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
    "生成任务提交失败",
  ).then((data) => {
    if (!data.job?.id) throw new Error("生成任务提交成功，但服务端未返回任务状态");
    return data;
  });
}

export type PosterBootstrap = {
  pipeline_id: string;
  role: string;
  jd_ready: boolean;
  fields: PosterFieldSet;
  poster: {
    status?: string;
    approval_status?: string;
    selected_version_id?: string;
    poster_html?: string;
    variants?: Record<string, unknown>;
  };
  versions: PosterVersion[];
  canvases: Array<{ id: string; label?: string; width?: number; height?: number }>;
  default_canvas_id?: string;
  auto_generate_eligible?: boolean;
  references?: Array<{ id: string; label?: string; url?: string }>;
};

export type XiaoHaiGenerationJob = {
  id: string;
  pipeline_id: string;
  client_request_id: string;
  status: "queued" | "running" | "cancel_requested" | "succeeded" | "failed" | "cancelled";
  stage: string;
  progress: number;
  result_version_id?: string;
  result_payload?: Record<string, unknown>;
  error_code?: string;
  error_message?: string;
  created_at?: string;
  started_at?: string;
  updated_at?: string;
  completed_at?: string;
};

export async function fetchPosterBootstrap(pipelineId: string) {
  return requestJson<PosterBootstrap>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/bootstrap`,
    {},
    "小海工作台加载失败",
    GENERATION_STATUS_TIMEOUT_MS,
  );
}

export function generatePoster(
  pipelineId: string,
  body: {
    fields: PosterFieldSet;
    canvas_id?: string;
    base_version_id?: string;
    instruction?: string;
    operation?: "text" | "visual";
    generation_mode?: "fresh" | "edit";
    protected_field_keys?: string[];
    use_default_materials?: boolean;
    background_element_id?: string;
    element_ids?: string[];
    client_request_id?: string;
  },
) {
  return requestJson<{ job: XiaoHaiGenerationJob; job_id: string; status: XiaoHaiGenerationJob["status"] }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/generate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, client_request_id: body.client_request_id ?? createClientRequestId() }),
    },
    "海报生成失败",
    GENERATION_SUBMIT_TIMEOUT_MS,
  );
}

export async function fetchPosterGenerationJob(pipelineId: string, jobId: string) {
  const result = await requestJson<{ job: XiaoHaiGenerationJob }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs/${encodeURIComponent(jobId)}`,
    {},
    "生成任务状态获取失败",
    GENERATION_STATUS_TIMEOUT_MS,
  );
  return result.job;
}

export async function findPosterGenerationJob(pipelineId: string, clientRequestId: string) {
  const result = await requestJson<{ jobs: XiaoHaiGenerationJob[] }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs?client_request_id=${encodeURIComponent(clientRequestId)}`,
    {},
    "生成任务查询失败",
    GENERATION_STATUS_TIMEOUT_MS,
  );
  return result.jobs?.[0] ?? null;
}

export async function fetchPosterGenerationJobs(pipelineId: string) {
  const result = await requestJson<{ jobs: XiaoHaiGenerationJob[] }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs`,
    {},
    "生成任务列表获取失败",
    GENERATION_STATUS_TIMEOUT_MS,
  );
  return result.jobs ?? [];
}

export function selectPosterVersion(pipelineId: string, versionId: string) {
  return requestJson<{ version: PosterVersion }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/versions/${encodeURIComponent(versionId)}/select`,
    { method: "POST" },
    "版本切换失败",
  );
}

export function approvePosterVersion(pipelineId: string, versionId: string) {
  return requestJson<{ version: PosterVersion }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/versions/${encodeURIComponent(versionId)}/approve`,
    { method: "POST" },
    "海报确认失败",
  );
}

/** 取消海报生成任务（旧版 cancelXhaiJobCard 调用的接口）。 */
export function cancelPosterJob(pipelineId: string, jobId: string) {
  return requestJson<{ status?: string }>(
    `/api/xiao-hai/${encodeURIComponent(pipelineId)}/jobs/${encodeURIComponent(jobId)}/cancel`,
    { method: "POST" },
    "取消生成失败",
  );
}

function createClientRequestId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `xiao_hai_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
