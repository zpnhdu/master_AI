import { afterEach, describe, expect, it, vi } from "vitest";

import { GENERATION_SUBMIT_TIMEOUT_MS, generatePoster } from "./api";

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("xiao-hai api", () => {
  it("uses a short timeout for poster task submission", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn(
      (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          _init?.signal?.addEventListener("abort", () => {
            reject(Object.assign(new Error("Aborted"), { name: "AbortError" }));
          });
        }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const request = generatePoster("p1", { fields: { jobTitle: "店长" } });
    const result = expect(request).rejects.toMatchObject({ kind: "timeout" });
    await vi.advanceTimersByTimeAsync(GENERATION_SUBMIT_TIMEOUT_MS);
    expect(fetchMock).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ signal: expect.objectContaining({ aborted: true }) }),
    );
    await result;
  });
});
