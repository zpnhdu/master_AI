import { App, Button, Typography } from 'antd';
import { useEffect, useState, type ReactNode } from 'react';

import type { CommandActions } from '../conversations/ConversationPanel';
import type { ConversationCommand, ConversationLatestData, ConversationResource } from '../conversations/api';
import { PosterGenerationProgress } from './PosterGenerationProgress';
import { usePosterJobs } from './usePosterJobs';
import { cancelPosterJob, selectPosterVersion, type PosterVersion } from './api';

const USAGE_LABELS: Record<string, string> = {
  background: '替换背景',
  style: '参考风格',
  composition: '参考构图',
  base: '基于当前海报',
  text: '修改文案',
};

/**
 * 小海对话修改命令卡片。对齐旧版 xiao_hai.html 的 xhaiCommandCard：
 * clarifying → awaiting_confirm（预览+确认/取消）→ queued/running（进度+取消生成）
 * → succeeded（新版本+采用/继续修改）/ failed（限流倒计时+重新提交）/ cancelled。
 */
export function XiaoHaiCommandCard({
  command,
  actions,
  latestData,
  pipelineId,
  onWorkspaceChanged,
}: {
  command: ConversationCommand;
  actions: CommandActions;
  latestData?: ConversationLatestData;
  pipelineId: string;
  onWorkspaceChanged: () => void;
}) {
  const preview = command.preview ?? {};
  const result = command.result ?? {};
  const isTextEdit = preview.operation === 'text';
  const isMixedEdit = preview.operation === 'mixed';
  const busy = actions.actingCommandId === command.id;
  const [cancelling, setCancelling] = useState(false);
  const { message } = App.useApp();
  const jobsQuery = usePosterJobs(pipelineId);
  const jobs = jobsQuery.jobs;
  const job = jobs.find((item) => item.id && item.id === result.job_id);
  const workspace = (latestData?.resources ?? []).find(
    (item: ConversationResource) => item.key === 'poster_workspace',
  );
  const workspaceData = (workspace?.data ?? {}) as { versions?: PosterVersion[] };
  const versions = workspaceData.versions ?? [];
  const version = versions.find((item) => item.id === result.version_id);

  async function cancelRunningJob() {
    const jobId = job?.id ?? (typeof result.job_id === 'string' ? result.job_id : '');
    if (jobId) {
      setCancelling(true);
      try {
        await cancelPosterJob(pipelineId, jobId);
      } catch {
        message.warning('取消未确认，正在重新查询任务状态');
      } finally {
        setCancelling(false);
      }
    }
    void jobsQuery.refetch();
  }

  async function adoptVersion(target: PosterVersion) {
    try {
      await selectPosterVersion(pipelineId, target.id);
      onWorkspaceChanged();
    } catch {
      // 失败时由页面 notice 提示，这里保持静默避免打断会话流。
    }
  }

  let body: ReactNode;
  if (command.status === 'clarifying') {
    body = (
      <>
        <div className="command-title">需要补充信息</div>
        <div className="command-summary">{stringOf(result.reply) || '请补充图片用途'}</div>
      </>
    );
  } else if (command.status === 'awaiting_confirm') {
    body = (
      <>
        <div className="command-title">
          {isTextEdit ? '文字修改预览' : isMixedEdit ? '背景与文字混合修改预览' : '海报修改预览'}
        </div>
        <div className="command-summary">
          <div>基础版本：{stringOf(preview.base_version_id)}</div>
          {preview.target_canvas_id ? <div>目标画幅：{stringOf(preview.target_canvas_id)}</div> : null}
          <div>参考用途：{USAGE_LABELS[stringOf(preview.reference_usage)] ?? stringOf(preview.reference_usage)}</div>
          <div>处理方式：AI 生成主体，程序排版投递区，统一放置邮箱、白底和真实二维码</div>
          <div>预计调用模型：1 次；原始 Logo 不重绘、不改色，二维码合成前后解码校验</div>
          <div>修改要求：{stringOf(preview.instruction)}</div>
          <div>保留：品牌、主体风格、文案和真实二维码；底部投递区自动适配画幅</div>
        </div>
        <div className="command-actions">
          <Button type="primary" size="small" loading={busy} disabled={Boolean(jobsQuery.activeJob)} onClick={() => actions.confirm(command)}>
            确认生成
          </Button>
          <Button size="small" disabled={busy} onClick={() => actions.cancel(command)}>
            取消
          </Button>
        </div>
      </>
    );
  } else if (command.status === 'queued' || command.status === 'running') {
    body = job ? <PosterGenerationProgress job={job} receivedAt={jobsQuery.dataUpdatedAt}
      disconnected={jobsQuery.disconnected} cancelling={cancelling || busy} onCancel={() => void cancelRunningJob()} />
      : <div role="status">正在恢复任务状态…</div>;
  } else if (command.status === 'failed') {
    const rateLimited = result.outcome_code === 'rate_limited' || job?.error_code === 'rate_limited';
    const instruction = stringOf(preview.instruction) || stringOf(result.instruction);
    body = (
      <>
        <div className="command-title">生成失败</div>
        <div className="command-summary">{stringOf(result.reply) || '请稍后重试'}</div>
        {rateLimited ? <RateLimitNotice job={job} /> : null}
        <div className="command-actions">
          <Button type="primary" size="small" disabled={!instruction || Boolean(jobsQuery.activeJob)} onClick={() => actions.sendDirect(instruction)}>
            重新提交
          </Button>
        </div>
      </>
    );
  } else if (command.status === 'cancelled') {
    body = (
      <>
        <div className="command-title">已取消</div>
        <div className="command-summary">{stringOf(result.reply) || '操作已取消，数据未发生变化。'}</div>
      </>
    );
  } else if (command.status === 'succeeded' && version) {
    body = (
      <>
        <div className="command-title">新海报版本</div>
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          {version.id}
        </Typography.Text>
        {version.image_url ? (
          <img
            className="xhai-command-card__image"
            src={version.image_url}
            alt="生成的海报"
            loading="lazy"
            decoding="async"
          />
        ) : null}
        <div className="command-actions">
          <Button type="primary" size="small" onClick={() => void adoptVersion(version)}>
            采用此版本
          </Button>
          <Button size="small" onClick={() => void adoptVersion(version).then(() => actions.fillComposer(''))}>
            继续修改
          </Button>
        </div>
      </>
    );
  } else {
    body = <div className="command-summary">{stringOf(result.reply) || '操作已更新'}</div>;
  }

  return (
    <div className="xhai-command-card">
      {job && !['running', 'queued'].includes(command.status) ? (
        <PosterGenerationProgress job={job} receivedAt={jobsQuery.dataUpdatedAt} />
      ) : null}
      {body}
    </div>
  );
}

/** 限流倒计时（对齐旧版 startXhaiRateCountdown）。 */
function RateLimitNotice({ job }: { job?: { error_message?: string } }) {
  const [seconds, setSeconds] = useState(() => {
    try {
      const info = JSON.parse(job?.error_message || '{}') as { retry_after?: number };
      return Math.max(1, Number(info.retry_after) || 60);
    } catch {
      return 60;
    }
  });
  useEffect(() => {
    const timer = setInterval(() => setSeconds((current) => Math.max(0, current - 1)), 1000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div className="xhai-rate-limit">
      {seconds > 0 ? (
        <>
          限流中，约 <span className="xhai-rate-limit__secs">{seconds}</span> 秒后可重试
        </>
      ) : (
        '限流已解除，可重新提交'
      )}
    </div>
  );
}

function stringOf(value: unknown) {
  return typeof value === 'string' ? value : '';
}
