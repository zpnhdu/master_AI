import { Alert, Button, Card, Drawer, Empty, Skeleton, Tag, Typography, message } from 'antd';
import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

import {
  fetchMaterialLibrary,
  MATERIAL_LIBRARY_QUERY_KEY,
  type MaterialKind,
  type MaterialLibraryEntry,
} from '../material-library/api';
import { routePaths } from '../../app/routes/route-paths';

const MAX_ELEMENTS = 2;
const MATERIAL_GROUPS: Array<{ kind: MaterialKind; label: string; selectionHint: string }> = [
  { kind: 'backgrounds', label: '背景图', selectionHint: '单选' },
  { kind: 'elements', label: '装饰元素', selectionHint: `最多 ${MAX_ELEMENTS} 个` },
];

type MaterialPickerProps = {
  canvasId: string;
  compact?: boolean;
  selectedBackgroundId: string;
  selectedElementIds: string[];
  disabled?: boolean;
  onBackgroundChange: (entryId: string) => void;
  onElementIdsChange: (entryIds: string[]) => void;
  onUseDefault?: () => void;
};

export function MaterialPicker({
  canvasId,
  compact = false,
  selectedBackgroundId,
  selectedElementIds,
  disabled = false,
  onBackgroundChange,
  onElementIdsChange,
  onUseDefault,
}: MaterialPickerProps) {
  const [open, setOpen] = useState(false);
  const libraryQuery = useQuery({
    queryKey: MATERIAL_LIBRARY_QUERY_KEY,
    queryFn: fetchMaterialLibrary,
    enabled: open,
    staleTime: 5 * 60 * 1000,
    retry: false,
  });
  const entriesById = useMemo(() => {
    const entries = [...(libraryQuery.data?.backgrounds ?? []), ...(libraryQuery.data?.elements ?? [])];
    return new Map(entries.map((entry) => [materialEntryId(entry), entry]));
  }, [libraryQuery.data]);
  const selectedBackground = entriesById.get(selectedBackgroundId);
  const selectedElements = selectedElementIds.map((id) => entriesById.get(id)).filter(Boolean) as MaterialLibraryEntry[];
  const defaultBackground = '/brand/guoquan-poster-bg.svg';
  const isCustom = Boolean(selectedBackgroundId || selectedElementIds.length);
  const materialStatus = isCustom ? '自定义' : '品牌默认';
  const compactLabel = `素材：${materialStatus}`;

  const clearSelection = () => {
    onBackgroundChange('');
    onElementIdsChange([]);
    onUseDefault?.();
  };

  return (
    <>
      {compact ? (
        <div className="poster-material-picker poster-material-picker--compact">
          <Button
            className="poster-material-picker__compact-trigger"
            disabled={disabled}
            onClick={() => setOpen(true)}
            title="打开素材库选择背景与装饰"
          >
            {compactLabel}
          </Button>
        </div>
      ) : (
        <Card
          title={
            <div className="poster-material-picker__title">
              <span>当前素材方案</span>
              <Tag color={isCustom ? 'blue' : 'green'}>{materialStatus}</Tag>
            </div>
          }
          className="agent-card poster-material-picker xhai-material-card"
        >
          <div className="poster-material-summary">
            <MaterialSummaryRow
              image={String(selectedBackground?.thumb_url ?? selectedBackground?.url ?? defaultBackground)}
              label={String(selectedBackground?.label ?? '锅圈品牌底图')}
              meta="背景 · 单选"
            />
            <MaterialSummaryRow
              image={String(selectedElements[0]?.thumb_url ?? selectedElements[0]?.url ?? '/brand/guoquan-mascot.png')}
              label={selectedElements.length
                ? selectedElements.map((entry) => String(entry.label ?? entry.file)).join('、')
                : '默认锅圈品牌 IP'}
              meta={`装饰 · ${selectedElements.length ? `${selectedElements.length}/${MAX_ELEMENTS}` : '默认'}`}
            />
          </div>
          <Typography.Paragraph type="secondary" className="poster-material-summary__hint">
            未选择背景时使用品牌默认底图；选中素材后会严格保留你选择的背景和装饰。
          </Typography.Paragraph>
          <Button type="primary" block disabled={disabled} onClick={() => setOpen(true)}>
            选择背景与装饰
          </Button>
        </Card>
      )}

      <Drawer
        title="选择海报素材"
        placement="left"
        size="large"
        open={open}
        onClose={() => setOpen(false)}
        extra={
          <div className="poster-material-drawer__actions">
            <Button type="text" disabled={disabled} onClick={clearSelection}>恢复品牌默认</Button>
            <Link to={routePaths.knowledgeMaterials} target="_blank" rel="noreferrer">管理素材</Link>
          </div>
        }
      >
        <Typography.Paragraph type="secondary" className="poster-material-drawer__intro">
          背景图单选；装饰元素最多选择 {MAX_ELEMENTS} 个。选择装饰后会替换默认品牌元素。
        </Typography.Paragraph>
        {libraryQuery.isPending ? (
          <Skeleton active paragraph={{ rows: 8 }} title={false} />
        ) : libraryQuery.isError ? (
          <Alert
            type="warning"
            showIcon
            message="素材库加载失败"
            action={<Button onClick={() => void libraryQuery.refetch()}>重试</Button>}
          />
        ) : (
          <MaterialGroups
            data={libraryQuery.data}
            disabled={disabled}
            selectedBackgroundId={selectedBackgroundId}
            selectedElementIds={selectedElementIds}
            onBackgroundChange={onBackgroundChange}
            onElementIdsChange={onElementIdsChange}
          />
        )}
      </Drawer>
    </>
  );
}

function MaterialSummaryRow({ image, label, meta }: { image: string; label: string; meta: string }) {
  return (
    <div className="poster-material-summary__row">
      <img src={image} alt="" loading="lazy" decoding="async" />
      <div>
        <Typography.Text strong ellipsis title={label}>{label}</Typography.Text>
        <Typography.Text type="secondary">{meta}</Typography.Text>
      </div>
    </div>
  );
}

function MaterialGroups({
  data,
  disabled,
  selectedBackgroundId,
  selectedElementIds,
  onBackgroundChange,
  onElementIdsChange,
}: {
  data?: Partial<Record<MaterialKind, MaterialLibraryEntry[]>>;
  disabled: boolean;
  selectedBackgroundId: string;
  selectedElementIds: string[];
  onBackgroundChange: (entryId: string) => void;
  onElementIdsChange: (entryIds: string[]) => void;
}) {
  return (
    <div className="poster-material-picker__groups poster-material-picker__groups--drawer">
      {MATERIAL_GROUPS.map((group) => {
        const entries = (data?.[group.kind] ?? []).filter(
          (entry) => materialEntryId(entry) && (entry.url || entry.thumb_url),
        );
        return (
          <section className="poster-material-picker__group" key={group.kind} aria-labelledby={`poster-material-${group.kind}`}>
            <div className="poster-material-picker__group-heading">
              <div className="poster-material-picker__group-title">
                <Typography.Text id={`poster-material-${group.kind}`} strong>{group.label}</Typography.Text>
                <Typography.Text type="secondary">{group.selectionHint}</Typography.Text>
              </div>
              <Typography.Text type="secondary">{entries.length} 项</Typography.Text>
            </div>
            {entries.length ? (
              <div className="poster-material-picker__grid">
                {entries.map((entry) => (
                  <MaterialButton
                    key={materialEntryId(entry)}
                    entry={entry}
                    kind={group.kind}
                    disabled={disabled}
                    selectedBackgroundId={selectedBackgroundId}
                    selectedElementIds={selectedElementIds}
                    onBackgroundChange={onBackgroundChange}
                    onElementIdsChange={onElementIdsChange}
                  />
                ))}
              </div>
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={`暂无${group.label}`} />
            )}
          </section>
        );
      })}
    </div>
  );
}

function MaterialButton({
  entry,
  kind,
  disabled,
  selectedBackgroundId,
  selectedElementIds,
  onBackgroundChange,
  onElementIdsChange,
}: {
  entry: MaterialLibraryEntry;
  kind: MaterialKind;
  disabled: boolean;
  selectedBackgroundId: string;
  selectedElementIds: string[];
  onBackgroundChange: (entryId: string) => void;
  onElementIdsChange: (entryIds: string[]) => void;
}) {
  const entryId = materialEntryId(entry);
  const label = String(entry.label ?? entry.file ?? '未命名素材');
  const selected = kind === 'backgrounds' ? selectedBackgroundId === entryId : selectedElementIds.includes(entryId);
  const select = () => {
    if (kind === 'backgrounds') {
      onBackgroundChange(selected ? '' : entryId);
      return;
    }
    if (!selected && selectedElementIds.length >= MAX_ELEMENTS) {
      message.warning(`装饰元素最多选择 ${MAX_ELEMENTS} 个`);
      return;
    }
    onElementIdsChange(selected ? selectedElementIds.filter((id) => id !== entryId) : [...selectedElementIds, entryId]);
  };
  return (
    <button
      type="button"
      className={`poster-material-picker__item${selected ? ' is-selected' : ''}`}
      aria-pressed={selected}
      aria-label={`${selected ? '取消选择' : '选择'}${label}`}
      title={String(entry.placement_hint || label)}
      disabled={disabled}
      onClick={select}
    >
      <span className="poster-material-picker__preview">
        <img src={String(entry.thumb_url ?? entry.url)} alt="" loading="lazy" decoding="async" />
        {selected ? <span className="poster-material-picker__selected-mark">已选</span> : null}
      </span>
      <span className="poster-material-picker__label">{label}</span>
    </button>
  );
}

function materialEntryId(entry: MaterialLibraryEntry) {
  return String(entry.id ?? entry.file ?? '');
}
