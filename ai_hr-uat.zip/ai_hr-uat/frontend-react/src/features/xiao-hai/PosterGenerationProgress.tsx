import { Alert, Button, Progress, Typography } from 'antd';
import { useEffect, useState } from 'react';
import type { PosterJob } from './api';

const PHASES: Record<string, string> = {
  queued: '任务排队中', preparing: '准备素材', refining: '整理文案', generating: '生成画面',
  composing: '合成校验', saving: '保存结果', completed: '生成完成',
};

export function duration(seconds: number) {
  const value = Math.max(0, Math.floor(seconds));
  return value < 60 ? `${value} 秒` : `${Math.floor(value / 60)} 分 ${value % 60} 秒`;
}

export function PosterGenerationProgress({ job, receivedAt, disconnected = false, onCancel, cancelling = false }: {
  job: PosterJob; receivedAt: number; disconnected?: boolean; onCancel?: () => void; cancelling?: boolean;
}) {
  const [now, setNow] = useState(Date.now());
  const terminal = ['succeeded', 'failed', 'cancelled'].includes(job.status);
  useEffect(() => {
    setNow(Date.now());
    if (terminal) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [terminal, job.id]);
  const advance = terminal ? 0 : Math.max(0, (now - receivedAt) / 1000);
  const elapsed = job.elapsed_seconds + advance;
  const remaining = job.estimated_remaining_seconds;
  const overrun = job.estimate_overrun || Boolean(remaining && advance > remaining[1]);
  const title = job.status === 'succeeded' ? '生成完成' : job.status === 'failed' ? '生成失败' : job.status === 'cancelled' ? '已取消生成'
    : job.status === 'cancel_requested' ? '正在取消生成' : PHASES[job.phase] || '正在处理';
  return (
    <section className="xhai-task-progress" aria-label="海报生成进度">
      <div className="xhai-task-progress__heading">
        <strong role="status" aria-live="polite">{title}</strong>
        <Typography.Text type="secondary">阶段进度</Typography.Text>
      </div>
      <Progress percent={job.status === 'succeeded' ? 100 : Math.min(95, job.progress)}
        format={percent => `${percent}%`}
        status={job.status === 'failed' ? 'exception' : job.status === 'succeeded' ? 'success' : terminal ? 'normal' : 'active'}
        aria-label="海报阶段进度" />
      <div className="xhai-task-progress__timing">
        <span>{job.status === 'queued' ? '已等待' : '已用'} {duration(elapsed)}</span>
        {!terminal && job.status === 'running' && !disconnected ? <span>
          {overrun ? '耗时比平时长，仍在处理' : remaining
            ? `预计还需 ${duration(remaining[0] - advance)}～${duration(remaining[1] - advance)}（估算）`
            : '正在估算剩余时间'}
        </span> : null}
      </div>
      {disconnected && !terminal ? <Alert type="warning" showIcon title="连接中断，正在恢复状态" /> : null}
      {job.status === 'failed' ? <Alert type="error" showIcon title={job.error_message || '生成失败，请重新提交'} /> : null}
      {job.status === 'cancel_requested' ? <Typography.Text type="secondary">已请求取消，等待当前调用返回；结果不会发布。</Typography.Text> : null}
      {!terminal && onCancel ? <Button size="small" loading={cancelling} disabled={job.status === 'cancel_requested'} onClick={onCancel}>取消生成</Button> : null}
    </section>
  );
}
