import '@testing-library/jest-dom/vitest';
import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { PosterGenerationProgress } from './PosterGenerationProgress';
import type { PosterJob } from './api';

const base: PosterJob = {
  id: 'task-1', pipeline_id: 'p1', source: 'workspace', status: 'running', phase: 'generating',
  progress: 38, elapsed_seconds: 80, estimated_remaining_seconds: [40, 120],
  created_at: '2026-08-31T00:00:00Z', server_time: '2026-08-31T00:01:20Z',
  estimate_basis: 'default', estimate_overrun: false, result_version_id: '',
};
beforeEach(() => { vi.useFakeTimers(); vi.setSystemTime(new Date('2026-08-31T08:00:00Z')); });
afterEach(() => { cleanup(); vi.useRealTimers(); });

describe('poster task clock and truthful phase progress', () => {
  it('restores server elapsed time despite client clock skew and does not invent model progress', () => {
    render(<PosterGenerationProgress job={base} receivedAt={Date.now()} />);
    expect(screen.getByText('已用 1 分 20 秒')).toBeInTheDocument();
    expect(screen.getByText('阶段进度')).toBeInTheDocument();
    act(() => vi.advanceTimersByTime(5000));
    expect(screen.getByText('已用 1 分 25 秒')).toBeInTheDocument();
    expect(screen.getByText(/预计还需 35 秒～1 分 55 秒/)).toBeInTheDocument();
    expect(screen.getByText('38%')).toBeInTheDocument();
    expect(screen.queryByText('100%')).not.toBeInTheDocument();
  });

  it('resets remaining estimates on a phase change and freezes the final clock', () => {
    const view = render(<PosterGenerationProgress job={base} receivedAt={Date.now()} />);
    act(() => vi.advanceTimersByTime(10000));
    view.rerender(<PosterGenerationProgress job={{ ...base, phase: 'saving', progress: 95, elapsed_seconds: 90, estimated_remaining_seconds: [5, 10] }} receivedAt={Date.now()} />);
    expect(screen.getByText('保存结果')).toBeInTheDocument();
    expect(screen.getByText(/预计还需 5 秒～10 秒/)).toBeInTheDocument();
    view.rerender(<PosterGenerationProgress job={{ ...base, status: 'succeeded', elapsed_seconds: 93 }} receivedAt={Date.now()} />);
    act(() => vi.advanceTimersByTime(60000));
    expect(screen.getByText('已用 1 分 33 秒')).toBeInTheDocument();
    expect(screen.getByText('100%')).toBeInTheDocument();
  });

  it('shows overrun instead of negative remaining seconds or a false completion', () => {
    render(<PosterGenerationProgress job={base} receivedAt={Date.now()} />);
    act(() => vi.advanceTimersByTime(121000));
    expect(screen.getByText('耗时比平时长，仍在处理')).toBeInTheDocument();
    expect(screen.getByText('38%')).toBeInTheDocument();
    expect(screen.queryByText(/预计还需/)).not.toBeInTheDocument();
  });

  it('shows only waiting time in queue and keeps cancellation available while disconnected', () => {
    const cancel = vi.fn();
    const view = render(<PosterGenerationProgress job={{ ...base, status: 'queued', phase: 'queued', progress: 0, elapsed_seconds: 8 }} receivedAt={Date.now()} onCancel={cancel} disconnected />);
    expect(screen.getByText('已等待 8 秒')).toBeInTheDocument();
    expect(screen.getByText('连接中断，正在恢复状态')).toBeInTheDocument();
    expect(screen.queryByText(/预计还需/)).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '取消生成' }));
    expect(cancel).toHaveBeenCalledTimes(1);
    view.rerender(<PosterGenerationProgress job={{ ...base, status: 'cancel_requested' }} receivedAt={Date.now()} onCancel={cancel} />);
    expect(screen.getByRole('button', { name: '取消生成' })).toBeDisabled();
    expect(screen.getByText('正在取消生成')).toBeInTheDocument();
  });

  it.each(['failed', 'cancelled'] as const)('freezes elapsed time on %s', status => {
    render(<PosterGenerationProgress job={{ ...base, status, error_message: '任务已中断' }} receivedAt={Date.now()} />);
    act(() => vi.advanceTimersByTime(60000));
    expect(screen.getByText('已用 1 分 20 秒')).toBeInTheDocument();
    expect(screen.queryByText(/预计还需/)).not.toBeInTheDocument();
  });
});
