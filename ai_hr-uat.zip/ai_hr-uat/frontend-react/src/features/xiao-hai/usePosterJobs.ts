import { useQuery } from "@tanstack/react-query";
import { fetchPosterJobs, isActivePosterJob } from "./api";

export const posterJobsKey = (pipelineId: string) => ["xiao-hai", "jobs", pipelineId] as const;

export function usePosterJobs(pipelineId: string) {
  const query = useQuery({
    queryKey: posterJobsKey(pipelineId),
    queryFn: () => fetchPosterJobs(pipelineId),
    enabled: Boolean(pipelineId),
    retry: 1,
    refetchInterval: (state) => (state.state.data?.jobs?.some(isActivePosterJob) ? 2000 : 10000),
    refetchOnWindowFocus: "always",
    refetchOnReconnect: "always",
  });
  const jobs = query.data?.jobs ?? [];
  return {
    ...query,
    jobs,
    activeJob: jobs.find(isActivePosterJob),
    disconnected: query.isError || query.fetchStatus === "paused",
  };
}
