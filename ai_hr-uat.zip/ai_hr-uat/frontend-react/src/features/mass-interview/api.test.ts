import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { uploadFullVideo } from "./api";

class FakeXMLHttpRequest {
  static instances: FakeXMLHttpRequest[] = [];

  timeout = 0;
  status = 200;
  responseText = "";
  upload: { onprogress: ((event: ProgressEvent) => void) | null } = { onprogress: null };
  ontimeout: (() => void) | null = null;
  onload: (() => void) | null = null;
  onerror: (() => void) | null = null;
  method = "";
  url = "";
  body: Document | XMLHttpRequestBodyInit | null = null;
  requestHeaders: Record<string, string> = {};

  constructor() {
    FakeXMLHttpRequest.instances.push(this);
  }

  open(method: string, url: string) {
    this.method = method;
    this.url = url;
  }

  setRequestHeader(name: string, value: string) {
    this.requestHeaders[name] = value;
  }

  send(body: Document | XMLHttpRequestBodyInit | null) {
    this.body = body;
    if (this.url.startsWith("/api/")) this.responseText = JSON.stringify({ status: "uploaded" });
    const file = body instanceof FormData ? body.get("file") || body.get("video") : null;
    const size = file instanceof Blob ? file.size : 0;
    this.upload.onprogress?.({ lengthComputable: true, loaded: size, total: size } as ProgressEvent);
    queueMicrotask(() => this.onload?.());
  }
}

describe("mass interview video upload", () => {
  beforeEach(() => {
    FakeXMLHttpRequest.instances = [];
    vi.stubGlobal("XMLHttpRequest", FakeXMLHttpRequest as unknown as typeof XMLHttpRequest);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it("uploads the video directly to OSS and then confirms it with the backend", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            upload_url: "https://bucket.oss-cn-hangzhou.aliyuncs.com",
            method: "POST",
            fields: {
              key: "interviews/p1/c1/video.webm",
              policy: "policy",
              "x-oss-signature-version": "OSS4-HMAC-SHA256",
              "x-oss-credential": "access-id/20260821/cn-hangzhou/oss/aliyun_v4_request",
              "x-oss-date": "20260821T010203Z",
              "x-oss-signature": "signature",
              success_action_status: "200",
              "Content-Type": "video/webm",
            },
            object_key: "interviews/p1/c1/video.webm",
            upload_token: "signed-upload-token-value",
            expires_at: 9999999999,
            max_size_bytes: 1024 * 1024,
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({ status: "uploaded" }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        }),
      );
    vi.stubGlobal("fetch", fetchMock);
    const progress = vi.fn();
    const blob = new Blob([new Uint8Array(2048)], { type: "video/webm" });

    const result = await uploadFullVideo("token", blob, [{ q: 0, start: 1, end: 4 }], progress);

    expect(result.status).toBe("uploaded");
    expect(FakeXMLHttpRequest.instances).toHaveLength(1);
    const ossRequest = FakeXMLHttpRequest.instances[0];
    expect(ossRequest.method).toBe("POST");
    expect(ossRequest.url).toBe("https://bucket.oss-cn-hangzhou.aliyuncs.com");
    expect(ossRequest.body).toBeInstanceOf(FormData);
    expect((ossRequest.body as FormData).get("key")).toBe("interviews/p1/c1/video.webm");
    expect((ossRequest.body as FormData).get("file")).toBeInstanceOf(Blob);
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/mass-interview/session/token/video-upload/complete",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
    expect(progress).toHaveBeenLastCalledWith({ pct: 100, loadedMB: "0.0", sizeMB: "0.0" });
  });

  it("falls back to the existing backend stream upload when OSS is not configured", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ detail: { code: "oss_direct_upload_unavailable" } }), {
          status: 503,
          headers: { "Content-Type": "application/json" },
        }),
      ),
    );
    const blob = new Blob([new Uint8Array(2048)], { type: "video/mp4" });

    const promise = uploadFullVideo("token", blob, [], vi.fn());
    await vi.waitFor(() => expect(FakeXMLHttpRequest.instances).toHaveLength(1));
    const backendRequest = FakeXMLHttpRequest.instances[0];
    const result = await promise;

    expect(result.status).toBe("uploaded");
    expect(backendRequest.url).toBe("/api/mass-interview/session/token/full-video");
    expect((backendRequest.body as FormData).get("video")).toBeInstanceOf(File);
    expect(((backendRequest.body as FormData).get("video") as File).name).toBe("interview.mp4");
  });
});