/**
 * 候选人自助面试（/mass-interview/:token）API 层。
 * 免登页面：/mass-interview/ 与 /api/mass-interview/ 均在 AUTH_PREFIX_WHITELIST 中。
 * 与旧版 frontend/mass-interview.html 的请求行为保持一致。
 */

import { ApiError, requestWithTimeout } from "../pipelines/api";

const runtimeClientIds = new Map<string, string>();

function clientId(token: string): string {
  const existing = runtimeClientIds.get(token);
  if (existing) return existing;
  const key = `mass-interview-client:${token}`;
  let stored = "";
  try {
    stored = window.sessionStorage.getItem(key) || "";
  } catch {
    /* storage unavailable */
  }
  const value = stored || crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;
  runtimeClientIds.set(token, value);
  if (!stored) {
    try {
      window.sessionStorage.setItem(key, value);
    } catch {
      /* storage unavailable */
    }
  }
  return value;
}

function leaseHeaders(token: string): Record<string, string> {
  return { "X-Session-Client-Id": clientId(token) };
}

export async function claimMassInterviewSession(token: string) {
  const response = await fetch(`/api/mass-interview/session/${encodeURIComponent(token)}/claim`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
  });
  if (!response.ok) {
    throw new ApiError(await responseError(response, "该面试已在其他设备或窗口进行"), { status: response.status });
  }
  return response.json() as Promise<{ status: string; lease_expires_at: string }>;
}

export function heartbeatMassInterviewSession(token: string) {
  return fetch(`/api/mass-interview/session/${encodeURIComponent(token)}/heartbeat`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
  });
}

export function releaseMassInterviewSession(token: string) {
  return fetch(`/api/mass-interview/session/${encodeURIComponent(token)}/release`, {
    method: "POST",
    headers: leaseHeaders(token),
    credentials: "include",
    keepalive: true,
  });
}

export type MassInterviewQuestion = {
  id?: string;
  type?: string;
  question?: string;
  tts_prefix?: string;
  time_limit_seconds?: number;
  answer_mode?: string;
  difficulty?: string;
};

export type MassInterviewSession = {
  token: string;
  candidate_name: string;
  role: string;
  company_name: string;
  company_logo: string;
  brand_color: string;
  status: string;
  questions: MassInterviewQuestion[];
  current_question: number;
  total_questions: number;
  estimated_minutes: number;
  expires_at: string;
  tts_urls: Array<string | null>;
};

export type SessionResult =
  | { kind: "ok"; session: MassInterviewSession }
  | { kind: "expired"; candidateName: string; role: string; expiresAt: string }
  | { kind: "error"; message: string };

/** GET session — 410 单独识别为过期态，其余非 2xx 为错误态。 */
export async function fetchMassInterviewSession(token: string): Promise<SessionResult> {
  try {
    return await requestWithTimeout(
      `/api/mass-interview/session/${encodeURIComponent(token)}`,
      { credentials: "include", headers: leaseHeaders(token) },
      async (response) => {
        if (response.status === 410) {
          const data = (await response.json().catch(() => ({}))) as Record<string, string>;
          return {
            kind: "expired",
            candidateName: data.candidate_name ?? "",
            role: data.role ?? "",
            expiresAt: data.expires_at ?? "",
          };
        }
        if (!response.ok) {
          const data = (await response.json().catch(() => ({}))) as Record<string, string>;
          throw new ApiError(data.detail || "面试链接无效或已过期", { status: response.status, data });
        }
        const session = (await response.json()) as MassInterviewSession;
        return { kind: "ok", session };
      },
    );
  } catch (error) {
    return { kind: "error", message: error instanceof Error ? error.message : "网络错误，请刷新重试" };
  }
}

export type DeviceCheckResult = {
  camera_ok: boolean;
  audio_ok: boolean;
  lighting_ok: boolean;
  face_detected: boolean;
  suggestions: string[];
};

/** POST device-check — 上传 3 秒试录片段。 */
export async function postDeviceCheck(token: string, blob: Blob): Promise<DeviceCheckResult> {
  const formData = new FormData();
  formData.append("video_file", blob, "device_check.webm");
  return requestWithTimeout(
    `/api/mass-interview/session/${encodeURIComponent(token)}/device-check`,
    { method: "POST", body: formData, credentials: "include", headers: leaseHeaders(token) },
    async (response) => {
      if (!response.ok) throw new ApiError("设备检测上传失败", { status: response.status });
      return (await response.json()) as DeviceCheckResult;
    },
  );
}

export type QuestionTimestamp = { q: number; start: number; end?: number };

export type UploadProgress = {
  pct: number;
  loadedMB: string;
  sizeMB: string;
};

type DirectUploadPrepareResponse = {
  upload_url: string;
  method: "POST";
  fields: Record<string, string>;
  object_key: string;
  upload_token: string;
  expires_at: number;
  max_size_bytes: number;
};

type UploadResult = { status?: string; message?: string };

function recordingFilename(blob: Blob): string {
  const baseType = blob.type.toLowerCase().split(";", 1)[0];
  if (baseType === "video/mp4") return "interview.mp4";
  if (baseType === "video/ogg") return "interview.ogv";
  if (baseType === "video/quicktime") return "interview.mov";
  return "interview.webm";
}

async function responseError(resp: Response, fallback: string): Promise<string> {
  const data = (await resp.json().catch(() => null)) as {
    detail?: string | { message?: string };
    message?: string;
  } | null;
  if (typeof data?.detail === "string") return data.detail;
  if (data?.detail && typeof data.detail === "object" && data.detail.message) return data.detail.message;
  return data?.message || fallback;
}

async function prepareDirectUpload(
  token: string,
  blob: Blob,
  filename: string,
): Promise<DirectUploadPrepareResponse | null> {
  const resp = await fetch(`/api/mass-interview/session/${encodeURIComponent(token)}/video-upload/prepare`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...leaseHeaders(token) },
    body: JSON.stringify({
      filename,
      content_type: blob.type || "video/webm",
      size_bytes: blob.size,
    }),
    credentials: "include",
  });

  // 404 supports rolling deployments with an older backend; 503 means OSS is not configured.
  if (resp.status === 404 || resp.status === 503) return null;
  if (!resp.ok) throw new Error(await responseError(resp, `申请 OSS 上传凭证失败 (HTTP ${resp.status})`));
  return (await resp.json()) as DirectUploadPrepareResponse;
}

function uploadBlobToOss(
  prepared: DirectUploadPrepareResponse,
  blob: Blob,
  filename: string,
  onProgress: (progress: UploadProgress) => void,
): Promise<void> {
  const sizeMB = (blob.size / 1024 / 1024).toFixed(1);
  const formData = new FormData();
  for (const [key, value] of Object.entries(prepared.fields)) formData.append(key, value);
  // OSS 表单上传要求 file 字段放在其他策略字段之后。
  formData.append("file", blob, filename);

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.timeout = 30 * 60 * 1000;
    xhr.ontimeout = () => reject(new Error("OSS 上传超时，请切换稳定网络后重试"));
    xhr.upload.onprogress = (event) => {
      if (!event.lengthComputable) return;
      onProgress({
        pct: Math.min(99, Math.round((event.loaded / event.total) * 100)),
        loadedMB: (Math.min(event.loaded, blob.size) / 1024 / 1024).toFixed(1),
        sizeMB,
      });
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
        return;
      }
      reject(new Error(`OSS 上传失败 (HTTP ${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error("无法连接 OSS，请检查网络及 Bucket CORS 配置"));
    xhr.open(prepared.method, prepared.upload_url);
    xhr.send(formData);
  });
}

async function completeDirectUpload(
  token: string,
  prepared: DirectUploadPrepareResponse,
  timestamps: QuestionTimestamp[],
): Promise<UploadResult> {
  let lastError: Error | null = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const resp = await fetch(`/api/mass-interview/session/${encodeURIComponent(token)}/video-upload/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...leaseHeaders(token) },
        body: JSON.stringify({
          object_key: prepared.object_key,
          upload_token: prepared.upload_token,
          timestamps,
        }),
        credentials: "include",
      });
      if (!resp.ok) throw new Error(await responseError(resp, `确认上传失败 (HTTP ${resp.status})`));
      return (await resp.json()) as UploadResult;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("确认上传失败");
    }
  }
  throw lastError || new Error("确认上传失败");
}

function uploadFullVideoViaBackend(
  token: string,
  blob: Blob,
  timestamps: QuestionTimestamp[],
  onProgress: (progress: UploadProgress) => void,
): Promise<UploadResult> {
  const sizeMB = (blob.size / 1024 / 1024).toFixed(1);
  const formData = new FormData();
  formData.append("video", blob, recordingFilename(blob));
  formData.append("timestamps", JSON.stringify(timestamps));

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.timeout = 120000;
    xhr.ontimeout = () => reject(new Error("上传超时，请切换WiFi后重试"));
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        onProgress({
          pct: Math.round((event.loaded / event.total) * 100),
          loadedMB: (event.loaded / 1024 / 1024).toFixed(1),
          sizeMB,
        });
      }
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText) as UploadResult);
        } catch {
          resolve({});
        }
        return;
      }
      let message = `上传失败 (HTTP ${xhr.status})`;
      try {
        const err = JSON.parse(xhr.responseText) as { detail?: string };
        if (err.detail) message = err.detail;
      } catch {
        /* 保留默认文案 */
      }
      reject(new Error(message));
    };
    xhr.onerror = () => reject(new Error("网络错误，请检查网络后重试"));
    xhr.open("POST", `/api/mass-interview/session/${encodeURIComponent(token)}/full-video`);
    xhr.setRequestHeader("X-Session-Client-Id", clientId(token));
    xhr.send(formData);
  });
}

/**
 * 完整视频上传：优先使用后端签发的短期 OSS 表单策略，让浏览器直接上传到 OSS；
 * OSS 未配置或滚动发布期间后端尚无新接口时，兼容回退到原有后端流式上传。
 */
export async function uploadFullVideo(
  token: string,
  blob: Blob,
  timestamps: QuestionTimestamp[],
  onProgress: (progress: UploadProgress) => void,
): Promise<UploadResult> {
  const filename = recordingFilename(blob);
  const prepared = await prepareDirectUpload(token, blob, filename);
  if (!prepared) return uploadFullVideoViaBackend(token, blob, timestamps, onProgress);

  await uploadBlobToOss(prepared, blob, filename, onProgress);
  onProgress({
    pct: 100,
    loadedMB: (blob.size / 1024 / 1024).toFixed(1),
    sizeMB: (blob.size / 1024 / 1024).toFixed(1),
  });
  return completeDirectUpload(token, prepared, timestamps);
}
