/**
 * 候选人自助面试的媒体工具：摄像头采集降级链、MediaRecorder 封装、TTS 播放。
 * 行为与旧版 frontend/mass-interview.html 保持一致。
 */

/** 正式录制：低分辨率优先，三级降级（移动端内存考虑）。 */
export async function acquireInterviewStream(): Promise<MediaStream> {
  try {
    return await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: 480, height: 360, frameRate: 15 },
      audio: true,
    });
  } catch {
    try {
      return await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: 640, height: 480 },
        audio: true,
      });
    } catch {
      return await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    }
  }
}

/** 设备检测试录：320×240 降级到默认约束。 */
export async function acquireProbeStream(): Promise<MediaStream> {
  try {
    return await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: 320, height: 240 },
      audio: true,
    });
  } catch {
    return await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  }
}

/** 正式录制 mimeType 四级降级链。 */
export function pickRecorderMimeType(): string {
  if (MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")) return "video/webm;codecs=vp8,opus";
  if (MediaRecorder.isTypeSupported("video/webm")) return "video/webm";
  if (MediaRecorder.isTypeSupported("video/mp4;codecs=h264")) return "video/mp4;codecs=h264";
  if (MediaRecorder.isTypeSupported("video/mp4")) return "video/mp4";
  return "video/mp4";
}

/** 设备检测试录 mimeType 两级降级。 */
export function pickProbeMimeType(): string {
  return MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus") ? "video/webm;codecs=vp8,opus" : "video/webm";
}

export function stopStream(stream: MediaStream | null): void {
  if (!stream) return;
  for (const track of stream.getTracks()) track.stop();
}

export function formatRecTime(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

/** 录 3 秒试录片段（设备检测用）。 */
export async function recordProbeClip(): Promise<Blob> {
  const stream = await acquireProbeStream();
  try {
    const mimeType = pickProbeMimeType();
    const chunks: Blob[] = [];
    const recorder = new MediaRecorder(stream, { mimeType });
    const stopped = new Promise<void>((resolve) => {
      recorder.onstop = () => resolve();
    });
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunks.push(event.data);
    };
    recorder.start();
    await new Promise((resolve) => setTimeout(resolve, 3000));
    recorder.stop();
    await stopped;
    return new Blob(chunks, { type: recorder.mimeType });
  } finally {
    stopStream(stream);
  }
}

/**
 * 一镜到底录制器：timeslice 1000ms 分片，onChunk 回调用于恢复点元数据。
 */
export class ContinuousRecorder {
  private recorder: MediaRecorder | null = null;
  private chunks: Blob[] = [];

  start(stream: MediaStream, onChunk?: (chunkCount: number, totalSize: number) => void): void {
    const mimeType = pickRecorderMimeType();
    this.chunks = [];
    this.recorder = new MediaRecorder(stream, { mimeType });
    this.recorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        this.chunks.push(event.data);
        onChunk?.(this.chunks.length, this.totalSize);
      }
    };
    this.recorder.start(1000);
  }

  get totalSize(): number {
    return this.chunks.reduce((sum, chunk) => sum + chunk.size, 0);
  }

  /** 停止并合成 Blob；未启动时 resolve null。 */
  stop(): Promise<Blob | null> {
    return new Promise((resolve) => {
      if (!this.recorder || this.recorder.state === "inactive") {
        resolve(null);
        return;
      }
      this.recorder.onstop = () => {
        resolve(new Blob(this.chunks, { type: this.recorder?.mimeType || "video/webm" }));
      };
      this.recorder.stop();
    });
  }
}

export const TTS_PLAYBACK_RATE = 1.15;

/** speechSynthesis 兜底播报；支持通过 signal 立即中断。 */
export function speakText(text: string, onEnd: () => void, signal?: AbortSignal): void {
  if (!("speechSynthesis" in window)) {
    let completed = false;
    const finish = () => {
      if (completed) return;
      completed = true;
      clearTimeout(fallbackTimer);
      signal?.removeEventListener("abort", finish);
      onEnd();
    };
    const fallbackTimer = setTimeout(finish, 2000);
    signal?.addEventListener("abort", finish, { once: true });
    return;
  }
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  let completed = false;
  const finish = () => {
    if (completed) return;
    completed = true;
    signal?.removeEventListener("abort", abortSpeech);
    onEnd();
  };
  const abortSpeech = () => {
    speechSynthesis.cancel();
    finish();
  };
  utterance.lang = "zh-CN";
  utterance.rate = TTS_PLAYBACK_RATE;
  utterance.pitch = 1.0;
  utterance.volume = 1;
  utterance.onend = finish;
  utterance.onerror = finish;
  signal?.addEventListener("abort", abortSpeech, { once: true });
  speechSynthesis.speak(utterance);
}

export function stopAllTts(audioElements: Array<HTMLAudioElement | null>): void {
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  for (const audio of audioElements) {
    if (audio) {
      audio.pause();
      audio.currentTime = 0;
    }
  }
}

/**
 * 题目语音播放（三级策略 + 动态安全超时）：
 * 预生成 CosyVoice 音频 → 自动播放被拒/加载失败 → speechSynthesis → 不支持则 2s 后结束。
 * signal 用于候选人点击“开始答题”时立即停止读题并结束等待。
 */
export function playQuestionTts(
  question: { question?: string; tts_prefix?: string } | undefined,
  preloadedAudio: HTMLAudioElement | null,
  signal?: AbortSignal,
): Promise<void> {
  return new Promise((resolve) => {
    const prefix = question?.tts_prefix || "";
    const text = question?.question || "";
    const fullText = prefix ? `${prefix} ${text}` : text;

    const audioDurationSeconds =
      preloadedAudio && Number.isFinite(preloadedAudio.duration) ? preloadedAudio.duration / TTS_PLAYBACK_RATE : 0;
    const estimatedSpeechSeconds = (fullText.length * 0.5) / TTS_PLAYBACK_RATE + 15;
    const safetyTimeoutMs = Math.max(60, audioDurationSeconds + 10, estimatedSpeechSeconds) * 1000;

    let settled = false;
    let timeout: ReturnType<typeof setTimeout>;
    const stopPlayback = () => {
      if ("speechSynthesis" in window) speechSynthesis.cancel();
      if (preloadedAudio) {
        preloadedAudio.pause();
        preloadedAudio.currentTime = 0;
      }
    };

    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      signal?.removeEventListener("abort", abortPlayback);
      if (preloadedAudio) {
        preloadedAudio.onended = null;
        preloadedAudio.onerror = null;
      }
      resolve();
    };

    const abortPlayback = () => {
      stopPlayback();
      done();
    };

    timeout = setTimeout(abortPlayback, safetyTimeoutMs);

    if (signal?.aborted) {
      abortPlayback();
      return;
    }
    signal?.addEventListener("abort", abortPlayback, { once: true });

    if (preloadedAudio && preloadedAudio.readyState >= 2) {
      preloadedAudio.playbackRate = TTS_PLAYBACK_RATE;
      preloadedAudio.onended = done;
      preloadedAudio.onerror = () => {
        preloadedAudio.onended = null;
        preloadedAudio.onerror = null;
        speakText(fullText, done, signal);
      };
      preloadedAudio.play().catch(() => {
        preloadedAudio.onended = null;
        preloadedAudio.onerror = null;
        speakText(fullText, done, signal);
      });
    } else {
      speakText(fullText, done, signal);
    }
  });
}
