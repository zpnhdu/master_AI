import { afterEach, describe, expect, it, vi } from "vitest";

import { TTS_PLAYBACK_RATE, playQuestionTts, speakText } from "./media";

class MockUtterance {
  lang = "";
  rate = 1;
  pitch = 1;
  volume = 1;
  onend: (() => void) | null = null;
  onerror: (() => void) | null = null;

  constructor(readonly text: string) {}
}

function installSpeechSynthesis() {
  const speak = vi.fn();
  const cancel = vi.fn();
  vi.stubGlobal("SpeechSynthesisUtterance", MockUtterance);
  vi.stubGlobal("speechSynthesis", { speak, cancel });
  return { speak, cancel };
}

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("mass interview TTS", () => {
  it("uses the faster playback rate for system speech", () => {
    const { speak } = installSpeechSynthesis();

    speakText("请介绍一次项目经历。", vi.fn());

    const utterance = speak.mock.calls[0][0] as MockUtterance;
    expect(utterance.rate).toBe(TTS_PLAYBACK_RATE);
    expect(utterance.lang).toBe("zh-CN");
  });

  it("speeds up preloaded audio and resolves immediately when interrupted", async () => {
    installSpeechSynthesis();
    const audio = {
      duration: 60,
      readyState: 4,
      playbackRate: 1,
      currentTime: 12,
      onended: null,
      onerror: null,
      play: vi.fn().mockResolvedValue(undefined),
      pause: vi.fn(),
    } as unknown as HTMLAudioElement;
    const controller = new AbortController();

    const playback = playQuestionTts({ question: "请完整回答这道题。" }, audio, controller.signal);
    controller.abort();
    await playback;

    expect(audio.playbackRate).toBe(TTS_PLAYBACK_RATE);
    expect(audio.pause).toHaveBeenCalled();
    expect(audio.currentTime).toBe(0);
  });

  it("does not cut system speech off at the previous ten-second limit", async () => {
    vi.useFakeTimers();
    installSpeechSynthesis();
    const controller = new AbortController();
    let completed = false;

    const playback = playQuestionTts(
      { question: "请结合实际案例，完整说明你如何识别问题、制定方案并推动团队落地。" },
      null,
      controller.signal,
    ).then(() => {
      completed = true;
    });

    await vi.advanceTimersByTimeAsync(10_001);
    expect(completed).toBe(false);

    controller.abort();
    await playback;
    expect(completed).toBe(true);
  });
});
