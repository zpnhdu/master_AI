import { cleanup, render, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it } from 'vitest';

import { WikiGraphCanvas } from './WikiGraphCanvas';

describe('WikiGraphCanvas node sizing', () => {
  afterEach(() => {
    cleanup();
  });

  it('keeps the node body and halo size stable as degree changes', async () => {
    const nodes = [
      { id: 'center', name: '中心', type: 'concept' },
      { id: 'leaf-a', name: '叶子 A', type: 'concept' },
      { id: 'leaf-b', name: '叶子 B', type: 'concept' },
      { id: 'leaf-c', name: '叶子 C', type: 'concept' },
    ];
    const edges = [
      { source: 'center', target: 'leaf-a' },
      { source: 'center', target: 'leaf-b' },
      { source: 'center', target: 'leaf-c' },
    ];

    const { container } = render(
      <WikiGraphCanvas
        nodes={nodes}
        edges={edges}
        visibleTypes={new Set(['concept'])}
        search=""
        focusNodeId={null}
        focusRequestId={0}
        onSelectNode={() => undefined}
      />,
    );

    await waitFor(() => expect(container.querySelectorAll('.knowledge-graph__node')).toHaveLength(nodes.length));

    const shapes = [...container.querySelectorAll<SVGPathElement>('.knowledge-graph__node-shape')].map((shape) => shape.getAttribute('d'));
    const halos = [...container.querySelectorAll<SVGCircleElement>('.knowledge-graph__node-halo')].map((halo) => halo.getAttribute('r'));
    expect(new Set(shapes).size).toBe(1);
    expect(new Set(halos).size).toBe(1);
  });
});
