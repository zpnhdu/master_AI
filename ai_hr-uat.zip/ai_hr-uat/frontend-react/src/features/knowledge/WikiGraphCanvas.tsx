import { drag } from 'd3-drag';
import {
  forceCenter,
  forceCollide,
  forceLink,
  forceManyBody,
  forceSimulation,
  type SimulationLinkDatum,
  type SimulationNodeDatum,
} from 'd3-force';
import { select } from 'd3-selection';
import { arc } from 'd3-shape';
import 'd3-transition';
import { zoom, zoomIdentity, type ZoomBehavior } from 'd3-zoom';
import { useEffect, useMemo, useRef } from 'react';

import type { WikiGraphEdge, WikiGraphNode, WikiPageType } from './api';
import { WIKI_TYPE_COLORS, WIKI_TYPE_MARKS } from './wikiGraphConstants';

function typeColor(type: WikiPageType) {
  return WIKI_TYPE_COLORS[type] ?? '#94a3b8';
}
/** 按类型返回节点 SVG path，与旧版形状语义保持一致。 */
function nodePath(type: WikiPageType, size = 10): string {
  if (type === 'method') {
    return `M ${-size} ${-size} H ${size} V ${size} H ${-size} Z`;
  }
  if (type === 'rule') {
    return `M 0 ${-size * 1.2} L ${size * 1.2} 0 L 0 ${size * 1.2} L ${-size * 1.2} 0 Z`;
  }
  if (type === 'scenario' || type === 'entity') {
    const points = Array.from({ length: 6 }, (_, index) => {
      const angle = (Math.PI / 3) * index - Math.PI / 6;
      return `${(size * 1.15 * Math.cos(angle)).toFixed(2)},${(size * 1.15 * Math.sin(angle)).toFixed(2)}`;
    });
    return `M ${points.join(' L ')} Z`;
  }
  // concept / source / 其它：圆
  return arc()({ innerRadius: 0, outerRadius: size, startAngle: 0, endAngle: Math.PI * 2 }) ?? '';
}

type WikiGraphCanvasProps = {
  nodes: WikiGraphNode[];
  edges: WikiGraphEdge[];
  visibleTypes: Set<string>;
  search: string;
  focusNodeId: string | null;
  focusRequestId: number;
  onSelectNode: (nodeId: string | null) => void;
};

type SimNode = WikiGraphNode & SimulationNodeDatum & { degree: number };
type SimLink = SimulationLinkDatum<SimNode>;

const AUTO_FIT_MAX_SCALE = 1.25;

function nodeRadius(_node: SimNode): number {
  // 关联数通过光晕和边线表达，主体尺寸保持稳定，避免中心节点突然变大。
  return 9;
}

function isCoreNode(node: SimNode): boolean {
  return node.degree >= 3;
}

export function WikiGraphCanvas({
  nodes,
  edges,
  visibleTypes,
  search,
  focusNodeId,
  focusRequestId,
  onSelectNode,
}: WikiGraphCanvasProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const zoomRef = useRef<ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const fitRef = useRef<() => void>(() => undefined);
  const focusRef = useRef<() => void>(() => undefined);
  const autoFitKeyRef = useRef<string | null>(null);
  const onSelectRef = useRef(onSelectNode);
  onSelectRef.current = onSelectNode;

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    const visibleNodes = nodes.filter((node) => visibleTypes.has(node.type));
    const visibleIds = new Set(visibleNodes.map((node) => node.id));
    const visibleEdges = edges.filter((edge) => visibleIds.has(edge.source) && visibleIds.has(edge.target));
    const degreeById = new Map<string, number>();
    visibleEdges.forEach(({ source, target }) => {
      degreeById.set(source, (degreeById.get(source) ?? 0) + 1);
      degreeById.set(target, (degreeById.get(target) ?? 0) + 1);
    });
    const nodesWithDegree = visibleNodes.map((node) => ({
      ...node,
      degree: degreeById.get(node.id) ?? 0,
    }));
    const matchingIds = new Set(
      query
        ? nodesWithDegree
            .filter((node) => `${node.name} ${node.id}`.toLowerCase().includes(query))
            .map((node) => node.id)
        : nodesWithDegree.map((node) => node.id),
    );
    return { nodes: nodesWithDegree, edges: visibleEdges, matchingIds };
  }, [edges, nodes, search, visibleTypes]);

  const graphStructureKey = useMemo(() => {
    const nodeKey = filtered.nodes
      .map((node) => `${node.id}:${node.type}`)
      .sort()
      .join('|');
    const edgeKey = filtered.edges
      .map((edge) => `${edge.source}->${edge.target}`)
      .sort()
      .join('|');
    return `${nodeKey}::${edgeKey}`;
  }, [filtered.edges, filtered.nodes]);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return undefined;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    const svg = select(svgRef.current);
    svg.selectAll('*').remove();
    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const root = svg.append('g');
    const defs = svg.append('defs');
    const haloGradient = defs.append('radialGradient').attr('id', 'knowledge-node-halo-gradient');
    haloGradient.append('stop').attr('offset', '0%').attr('stop-color', '#60a5fa').attr('stop-opacity', 0.34);
    haloGradient.append('stop').attr('offset', '100%').attr('stop-color', '#60a5fa').attr('stop-opacity', 0);
    const graphZoom = zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.3, 4])
      .on('zoom', (event) => root.attr('transform', event.transform.toString()));
    zoomRef.current = graphZoom;
    svg.call(graphZoom);

    const simNodes: SimNode[] = filtered.nodes.map((node) => ({ ...node }));
    const simLinks: SimLink[] = filtered.edges.map((edge) => ({ ...edge }));
    const autoFitNeeded = !focusNodeId && autoFitKeyRef.current !== graphStructureKey;
    const neighborIds = new Set<string>();
    if (focusNodeId) {
      for (const edge of filtered.edges) {
        if (edge.source === focusNodeId) neighborIds.add(edge.target);
        if (edge.target === focusNodeId) neighborIds.add(edge.source);
      }
    }

    const simulation = forceSimulation<SimNode>(simNodes)
      .force('link', forceLink<SimNode, SimLink>(simLinks).id((node) => node.id).distance(110))
      .force('charge', forceManyBody().strength(-260))
      .force('center', forceCenter(width / 2, height / 2))
      .force('collide', forceCollide<SimNode>((node) => nodeRadius(node) + 24));

    const link = root
      .append('g')
      .attr('stroke', '#cbd5e1')
      .attr('stroke-opacity', 0.7)
      .selectAll('line')
      .data(simLinks)
      .join('line')
      .attr('class', (item) => {
        const source = item.source as SimNode;
        const target = item.target as SimNode;
        const active = Boolean(focusNodeId && (source.id === focusNodeId || target.id === focusNodeId));
        return `knowledge-graph__edge${active ? ' knowledge-graph__edge--active' : ''}`;
      })
      .attr('stroke-width', (item) => {
        const source = item.source as SimNode;
        const target = item.target as SimNode;
        return focusNodeId && (source.id === focusNodeId || target.id === focusNodeId) ? 2.4 : 1.2;
      })
      .attr('stroke', (item) => {
        const source = item.source as SimNode;
        const target = item.target as SimNode;
        return focusNodeId && (source.id === focusNodeId || target.id === focusNodeId) ? '#2563eb' : '#cbd5e1';
      })
      .attr('stroke-opacity', (item) => {
        const source = item.source as SimNode;
        const target = item.target as SimNode;
        if (focusNodeId) return source.id === focusNodeId || target.id === focusNodeId ? 0.92 : 0.16;
        if (search.trim()) return filtered.matchingIds.has(source.id) || filtered.matchingIds.has(target.id) ? 0.72 : 0.18;
        return 0.7;
      });

    const tooltip = select(container)
      .append('div')
      .attr('class', 'knowledge-graph__tooltip')
      .style('opacity', 0);

    const node = root
      .append('g')
      .selectAll<SVGGElement, SimNode>('g')
      .data(simNodes)
      .join('g')
      .attr('class', (item) => [
        'knowledge-graph__node',
        item.id === focusNodeId ? 'knowledge-graph__node--selected' : '',
        isCoreNode(item) ? 'knowledge-graph__node--core' : '',
      ].filter(Boolean).join(' '))
      .attr('data-degree', (item) => item.degree)
      .attr('cursor', 'pointer')
      .attr('tabindex', 0)
      .attr('role', 'button')
      .attr('aria-label', (item) => `${item.name}（${item.type}，${item.degree}条关联）`)
      .attr('opacity', (item) => {
        if (focusNodeId) return item.id === focusNodeId || neighborIds.has(item.id) ? 1 : 0.25;
        if (search.trim()) return filtered.matchingIds.has(item.id) ? 1 : 0.25;
        return 1;
      })
      .call(
        drag<SVGGElement, SimNode>()
          .on('start', (event, item) => {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            item.fx = item.x;
            item.fy = item.y;
          })
          .on('drag', (event, item) => {
            item.fx = event.x;
            item.fy = event.y;
          })
          .on('end', (event, item) => {
            if (!event.active) simulation.alphaTarget(0);
            item.fx = null;
            item.fy = null;
          }),
      );

    node
      .append('circle')
      .attr('class', 'knowledge-graph__node-halo')
      .attr('r', (item) => nodeRadius(item) + 14)
      .attr('fill', 'url(#knowledge-node-halo-gradient)')
      .attr('opacity', (item) => item.id === focusNodeId ? 1 : isCoreNode(item) ? 0.42 : 0);

    node
      .append('path')
      .attr('class', 'knowledge-graph__node-shape')
      .attr('d', (item) => nodePath(item.type, nodeRadius(item)))
      .attr('fill', (item) => typeColor(item.type))
      .attr('stroke', (item) => item.id === focusNodeId ? '#0f172a' : '#fff')
      .attr('stroke-width', (item) => item.id === focusNodeId ? 3 : 1.6);

    node
      .append('text')
      .attr('class', 'knowledge-graph__node-mark')
      .text((item) => WIKI_TYPE_MARKS[item.type] ?? '?')
      .attr('y', 3)
      .attr('text-anchor', 'middle')
      .attr('font-size', 8)
      .attr('font-weight', 700)
      .attr('fill', '#fff')
      .attr('pointer-events', 'none');

    node
      .append('text')
      .attr('class', 'knowledge-graph__node-label')
      .text((item) => item.name)
      .attr('y', (item) => nodeRadius(item) + 14)
      .attr('text-anchor', 'middle')
      .attr('font-size', 11)
      .attr('fill', '#334155')
      .attr('pointer-events', 'none');

    node.append('title').text((item) => `${item.name} · ${item.type} · ${item.degree} 条关联`);

    node
      .on('mouseenter', (event, item) => {
        tooltip.style('opacity', 1).html(`<strong>${item.name}</strong>`);
      })
      .on('mousemove', (event) => {
        const rect = container.getBoundingClientRect();
        tooltip.style('left', `${event.clientX - rect.left + 12}px`).style('top', `${event.clientY - rect.top + 12}px`);
      })
      .on('mouseleave', () => tooltip.style('opacity', 0))
      .on('click', (event, item) => {
        event.stopPropagation();
        onSelectRef.current(item.id);
      })
      .on('keydown', (event, item) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          event.stopPropagation();
          onSelectRef.current(item.id);
        }
        if (event.key === 'Escape') {
          event.preventDefault();
          onSelectRef.current(null);
        }
      });

    svg.on('click', () => onSelectRef.current(null));

    simulation.on('tick', () => {
      link
        .attr('x1', (item) => (item.source as SimNode).x ?? 0)
        .attr('y1', (item) => (item.source as SimNode).y ?? 0)
        .attr('x2', (item) => (item.target as SimNode).x ?? 0)
        .attr('y2', (item) => (item.target as SimNode).y ?? 0);
      node.attr('transform', (item) => `translate(${item.x ?? 0},${item.y ?? 0})`);
    });

    focusRef.current = () => {
      if (!focusNodeId || !zoomRef.current || !svgRef.current) return;
      const found = simNodes.find((node) => node.id === focusNodeId);
      if (found?.x === undefined || found.y === undefined) return;
      const transform = zoomIdentity.translate(width / 2 - found.x * 1.3, height / 2 - found.y * 1.3).scale(1.3);
      select(svgRef.current).transition().duration(500).call(zoomRef.current.transform, transform);
    };

    fitRef.current = () => {
      if (!simNodes.length || !zoomRef.current || !svgRef.current) return;
      const xValues = simNodes.map((item) => item.x ?? width / 2);
      const yValues = simNodes.map((item) => item.y ?? height / 2);
      const minX = Math.min(...xValues) - 56;
      const maxX = Math.max(...xValues) + 56;
      const minY = Math.min(...yValues) - 56;
      const maxY = Math.max(...yValues) + 56;
      const scale = Math.max(
        0.3,
        Math.min(AUTO_FIT_MAX_SCALE, Math.min(width / Math.max(1, maxX - minX), height / Math.max(1, maxY - minY))),
      );
      const transform = zoomIdentity
        .translate(width / 2 - ((minX + maxX) / 2) * scale, height / 2 - ((minY + maxY) / 2) * scale)
        .scale(scale);
      select(svgRef.current).transition().duration(350).call(zoomRef.current.transform, transform);
    };
    simulation.on('end', () => {
      if (focusNodeId) focusRef.current();
      else if (autoFitNeeded) {
        autoFitKeyRef.current = graphStructureKey;
        fitRef.current();
      }
    });

    return () => {
      simulation.stop();
      fitRef.current = () => undefined;
      focusRef.current = () => undefined;
      tooltip.remove();
      svg.on('click', null);
    };
  }, [filtered, focusNodeId, focusRequestId, search, graphStructureKey]);

  function applyZoom(scaleDelta: number | null) {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = select(svgRef.current);
    if (scaleDelta === null) {
      svg.transition().duration(300).call(zoomRef.current.transform, zoomIdentity);
    } else {
      svg.transition().duration(200).call(zoomRef.current.scaleBy, scaleDelta);
    }
  }

  return (
    <div ref={containerRef} className="knowledge-graph">
      <svg ref={svgRef} className="knowledge-graph__svg" role="img" aria-label="知识图谱" />
      <div className="knowledge-graph__zoom">
        <button type="button" aria-label="适配画布" onClick={() => fitRef.current()}>适配</button>
        <button type="button" aria-label="重置位置" onClick={() => applyZoom(null)}>重置</button>
        <button type="button" aria-label="放大" onClick={() => applyZoom(1.3)}>＋</button>
        <button type="button" aria-label="缩小" onClick={() => applyZoom(0.7)}>－</button>
      </div>
    </div>
  );
}
