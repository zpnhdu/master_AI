import { requestJson } from "../agent-workbench/api";
import { ApiError, requestWithTimeout } from "../pipelines/api";

// ── LLM-wiki 面向前端的数据模型 ─────────────────────────────────────────
// 后端前缀 /api/knowledge/wiki；旧 /api/knowledge/* 端点保留但页面不再调用。

export type WikiPageType = "entity" | "concept" | "source" | "method" | "rule" | "scenario" | string;

export type WikiTreeNode = {
  slug: string;
  path: string;
  title: string;
};

export type WikiTree = {
  tree: Record<string, WikiTreeNode[]>;
  stats: {
    pages: number;
    types: Record<string, number>;
  };
  recent_log: string;
};

export type WikiGraphNode = {
  id: string;
  name: string;
  type: WikiPageType;
};

export type WikiGraphEdge = {
  source: string;
  target: string;
};

export type WikiGraph = {
  nodes: WikiGraphNode[];
  edges: WikiGraphEdge[];
  missing_links: string[];
};

/** 旧知识图谱节点详情接口，供流水线推荐卡片兼容使用。 */
export type KnowledgeNode = {
  id: string;
  name: string;
  type: string;
  definition?: string;
  tags?: string[];
  confidence?: number;
  [key: string]: unknown;
};

export type KnowledgeNodeDetail = {
  node: KnowledgeNode;
  neighbors?: KnowledgeNode[];
  related_nodes?: KnowledgeNode[];
  edges?: Array<Record<string, unknown>>;
  connection_count?: number;
};

export function fetchKnowledgeNode(nodeId: string) {
  return requestJson<KnowledgeNodeDetail>(`/api/knowledge/node/${encodeURIComponent(nodeId)}`, {}, "知识详情加载失败");
}

export type WikiBacklink = {
  slug: string;
  title: string;
};

export type WikiPage = {
  path: string;
  slug: string;
  frontmatter: Record<string, unknown> | null;
  body: string;
  wikilinks: string[];
  related: string[];
  backlinks: WikiBacklink[];
};

export type WikiSource = {
  source_id: string;
  filename: string;
  ext: string;
  sha256?: string;
  status: "processing" | "done" | "failed" | string;
  progress?: string;
  error_msg?: string;
  pages_written?: string;
  created_at?: string;
  updated_at?: string;
};

export type WikiStorageInfo = {
  backend: string;
  backend_label: string;
  raw_location: string;
  page_backend?: string;
  page_location: string;
  cache_location?: string;
  index_location: string;
  read_write: string;
};

/** 流式问答中召回到的来源页（用于前端标注）。 */
export type WikiCiteSource = {
  slug: string;
  title: string;
  type: string;
  sources: string;
  score: number;
};

export type WikiChatChunk =
  | { type: "phase"; phase: string }
  | { type: "sources"; sources: WikiCiteSource[] }
  | { type: "content"; content: string }
  | { type: "error"; error: string }
  | { type: "done"; total_length: number; sources: WikiCiteSource[] };

// ── 页树 / 图谱 / 单页 ─────────────────────────────────────────────────

export function fetchWikiTree() {
  return requestJson<WikiTree>("/api/knowledge/wiki/tree", {}, "知识库目录加载失败");
}

export function fetchWikiGraph() {
  return requestJson<WikiGraph>("/api/knowledge/wiki/graph", {}, "知识图谱加载失败");
}

export function fetchWikiPage(path: string) {
  return requestJson<WikiPage>(`/api/knowledge/wiki/page/${encodeURIComponent(path)}`, {}, "页面加载失败");
}

// ── 资料管理 ───────────────────────────────────────────────────────────

export function fetchWikiSources() {
  return requestJson<{ sources: WikiSource[] }>("/api/knowledge/wiki/sources", {}, "资料列表加载失败");
}

export function fetchWikiStorage() {
  return requestJson<WikiStorageInfo>("/api/knowledge/wiki/storage", {}, "存储信息加载失败");
}

export function deleteWikiSource(sourceId: string) {
  return requestJson<{ deleted: boolean; id: string; pages_removed: number }>(
    `/api/knowledge/wiki/sources/${encodeURIComponent(sourceId)}`,
    { method: "DELETE" },
    "删除资料失败",
  );
}

export function reprocessWikiSource(sourceId: string) {
  return requestJson<{ id: string; status: string }>(
    `/api/knowledge/wiki/sources/${encodeURIComponent(sourceId)}/reprocess`,
    { method: "POST" },
    "重新解析失败",
  );
}

export async function uploadWikiSources(files: File[]) {
  const form = new FormData();
  for (const file of files) form.append("files", file);
  return requestWithTimeout(
    "/api/knowledge/wiki/upload",
    { method: "POST", credentials: "include", body: form },
    async (response) => {
      const payload: unknown = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail =
          typeof payload === "object" && payload !== null && "detail" in payload && typeof payload.detail === "string"
            ? payload.detail
            : "资料上传失败";
        throw new ApiError(`${detail}（${response.status}）`, { status: response.status, data: payload });
      }
      return payload as { sources: Array<{ id: string; filename: string; ext: string; status: string }> };
    },
  );
}

// ── 流式问答 ───────────────────────────────────────────────────────────

/**
 * 流式调用知识库问答（SSE）。后端 /wiki/query 发射：
 *   {"phase":"retrieving"} / {"phase":"sources","sources":[…]}
 *   {"content":"…"} / {"done":true,"total_length":N,"sources":[…]}
 *   最后一行 data: [DONE]。
 * 采用 fetch + ReadableStream 逐行解析（对齐旧版 knowledge 页面骨架）。
 */
export async function streamWikiChat(
  question: string,
  k: number,
  onChunk: (chunk: WikiChatChunk) => void,
  signal?: AbortSignal,
): Promise<void> {
  await requestWithTimeout(
    "/api/knowledge/wiki/query",
    {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, k }),
      signal,
    },
    async (response) => {
      if (!response.ok || !response.body) {
        const payload: unknown = await response.json().catch(() => ({}));
        const detail =
          typeof payload === "object" && payload !== null && "detail" in payload && typeof payload.detail === "string"
            ? payload.detail
            : `知识问答失败（${response.status}）`;
        throw new ApiError(detail, { status: response.status, data: payload });
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const data = trimmed.slice(5).trim();
          if (!data) continue;
          if (data === "[DONE]") return;
          try {
            const parsed = JSON.parse(data) as Record<string, unknown>;
            if (typeof parsed.phase === "string") {
              if (parsed.phase === "sources" && Array.isArray(parsed.sources)) {
                onChunk({ type: "sources", sources: parsed.sources as WikiCiteSource[] });
              } else {
                onChunk({ type: "phase", phase: parsed.phase });
              }
            } else if (typeof parsed.content === "string") {
              onChunk({ type: "content", content: parsed.content });
            } else if (typeof parsed.error === "string") {
              onChunk({ type: "error", error: parsed.error });
            } else if (parsed.done) {
              onChunk({
                type: "done",
                total_length: typeof parsed.total_length === "number" ? parsed.total_length : 0,
                sources: Array.isArray(parsed.sources) ? (parsed.sources as WikiCiteSource[]) : [],
              });
            }
          } catch {
            // 忽略无法解析的行
          }
        }
      }
    },
  );
}
