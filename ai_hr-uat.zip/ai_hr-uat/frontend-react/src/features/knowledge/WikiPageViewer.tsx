import { Typography } from 'antd';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const WIKILINK_HREF = '#/wiki-link';

/**
 * 渲染 wiki 页正文，支持 GFM（表格/列表/任务项）并识别 [[wikilink]]。
 *
 * [[slug]] 与 [[slug|label]] 会被转换为内部链接；点击后调用 onNavigate(slug)，
 * 由父组件决定跳到哪个页面，不让浏览器做默认跳转。其它链接原样交给浏览器。
 */
export function WikiPageViewer({
  body,
  onNavigate,
}: {
  body: string;
  onNavigate?: (slug: string) => void;
}) {
  const markdown = toWikilinkLinks(body);

  return (
    <div className="wiki-page-viewer">
      <Markdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children }) => {
            const target = href ?? '';
            if (target.startsWith(WIKILINK_HREF)) {
              const slug = target.slice(WIKILINK_HREF.length + 1).replace(/\/$/, '');
              return (
                <a
                  href={target}
                  onClick={(event) => {
                    event.preventDefault();
                    if (slug) onNavigate?.(decodeURIComponent(slug));
                  }}
                >
                  {children}
                </a>
              );
            }
            return (
              <a href={target} target={target.startsWith('http') ? '_blank' : undefined} rel="noreferrer">
                {children}
              </a>
            );
          },
          p: ({ children }) => <Typography.Paragraph style={{ marginBottom: 14 }}>{children}</Typography.Paragraph>,
          h1: ({ children }) => <h1 className="wiki-page-viewer__h1">{children}</h1>,
          h2: ({ children }) => <h2 className="wiki-page-viewer__h2">{children}</h2>,
          h3: ({ children }) => <h3 className="wiki-page-viewer__h3">{children}</h3>,
          code: ({ className, children }) => (
            <code className={`wiki-page-viewer__code${className ? ` ${className}` : ''}`}>{children}</code>
          ),
          pre: ({ children }) => <pre className="wiki-page-viewer__pre">{children}</pre>,
          table: ({ children }) => (
            <div className="wiki-md-table">
              <table>{children}</table>
            </div>
          ),
          blockquote: ({ children }) => <blockquote className="wiki-page-viewer__blockquote">{children}</blockquote>,
          ul: ({ children }) => <ul className="wiki-page-viewer__ul">{children}</ul>,
          ol: ({ children }) => <ol className="wiki-page-viewer__ol">{children}</ol>,
        }}
      >
        {markdown}
      </Markdown>
    </div>
  );
}

function toWikilinkLinks(markdown: string): string {
  // [[slug|label]] / [[slug]] / [[slug#anchor]] -> [label](#/wiki-link/<encoded slug>)
  // 只转化不在代码块内的行（简单逐行跳过 ``` 栅栏内的内容）。
  const lines = markdown.split('\n');
  let inFence = false;
  const out = lines.map((line) => {
    const trimmed = line.trimStart();
    if (trimmed.startsWith('```') || trimmed.startsWith('~~~')) {
      inFence = !inFence;
      return line;
    }
    if (inFence) return line;
    return line.replace(
      /\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]/g,
      (_all, slug: string, label: string) => {
        const clean = slug.trim();
        const text = (label || clean).trim();
        return `[${text}](${WIKILINK_HREF}/${encodeURIComponent(clean)})`;
      },
    );
  });
  return out.join('\n');
}