export const WIKI_TYPE_COLORS: Record<string, string> = {
  concept: "#3b82f6",
  method: "#10b981",
  rule: "#f59e0b",
  scenario: "#8b5cf6",
  entity: "#0891b2",
  source: "#64748b",
};

export const WIKI_TYPE_LABELS: Record<string, string> = {
  entity: "实体",
  concept: "概念",
  source: "来源",
  method: "方法",
  rule: "规则",
  scenario: "场景",
};

/** 知识库首次打开时展示的业务知识类型；来源节点需用户主动开启。 */
export const WIKI_VISIBLE_TYPE_ORDER = ["entity", "concept", "method", "rule", "scenario", "source"] as const;

/** 在节点中提供非颜色的类型编码，兼顾色弱和密集图谱场景。 */
export const WIKI_TYPE_MARKS: Record<string, string> = {
  entity: "实",
  concept: "概",
  method: "法",
  rule: "规",
  scenario: "景",
  source: "源",
};

export const WIKI_TYPE_EMOJIS: Record<string, string> = {
  concept: "📚",
  method: "🛠️",
  rule: "📋",
  scenario: "🎯",
  entity: "🏢",
  source: "📎",
};

export const WIKI_TYPE_USER_LABELS: Record<string, string> = {
  concept: "基础知识",
  method: "操作指南",
  rule: "规范制度",
  scenario: "场景案例",
  entity: "实体信息",
  source: "参考资料",
};
