import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  fetchAgentConfigs,
  fetchCompanyConfig,
  fetchOntology,
  fetchOntologyRules,
  updateAgentConfig,
  updateCompanyConfig,
  type AgentConfigUpdate,
  type CompanyConfig,
} from "./api";

export function useAgentConfigsQuery(enabled: boolean) {
  return useQuery({
    queryKey: ["agent-configs"],
    queryFn: fetchAgentConfigs,
    enabled,
    staleTime: 15 * 1000,
  });
}

export function useUpdateAgentConfigMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ agentId, update }: { agentId: string; update: AgentConfigUpdate }) =>
      updateAgentConfig(agentId, update),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["agent-configs"] }),
  });
}

export function useCompanyConfigQuery(enabled: boolean) {
  return useQuery({
    queryKey: ["company-config"],
    queryFn: fetchCompanyConfig,
    enabled,
    staleTime: 15 * 1000,
  });
}

export function useUpdateCompanyConfigMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (config: CompanyConfig) => updateCompanyConfig(config),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["company-config"] }),
  });
}

export function useOntologyQuery(enabled: boolean) {
  return useQuery({
    queryKey: ["ontology"],
    queryFn: fetchOntology,
    enabled,
    staleTime: 15 * 1000,
  });
}

export function useOntologyRulesQuery(enabled: boolean) {
  return useQuery({
    queryKey: ["ontology-rules"],
    queryFn: fetchOntologyRules,
    enabled,
    staleTime: 15 * 1000,
  });
}
