import { ApiError, requestWithTimeout } from "../pipelines/api";

export type AgentConfig = {
  agent_id: string;
  agent_name?: string;
  display_name?: string;
  model?: string;
  complexity?: string;
  temperature?: number;
  timeout?: number;
  retry_count?: number;
  enabled: boolean;
  human_approval: boolean;
};

export type AgentConfigUpdate = {
  enabled?: boolean;
  model?: string;
  complexity?: string;
  temperature?: number;
  timeout?: number;
  retry_count?: number;
  human_approval?: boolean;
};

export type CompanyConfig = {
  company_name?: string;
  company_short?: string;
  company_en?: string;
  industry?: string;
  company_size?: string;
  company_website?: string;
  company_address?: string;
  default_benefits?: string[];
  company_intro?: string;
  brand_color?: string;
  brand_color_secondary?: string;
  company_logo?: string;
  company_logo_thumb?: string;
  poster_template?: string;
  poster_bg_image?: string;
  poster_bg_image_thumb?: string;
};

/** 公司品牌素材上传类型（对齐旧版 studio.html 的 uploadCompanyFile）。 */
export type CompanyAssetKind = "logo" | "poster-bg";

export const COMPANY_ASSET_MAX_SIZE = 5 * 1024 * 1024;
export const COMPANY_ASSET_EXTENSIONS = ["jpg", "jpeg", "png", "svg", "webp", "gif"];

export type OntologyNode = {
  id?: string;
  name?: string;
  desc?: string;
  node_type?: string;
  rules?: Record<string, unknown>;
  children?: OntologyNode[];
};

export type OntologyRule = {
  id?: string;
  node_id?: string;
  rule_id?: string;
  field?: string;
  old_value?: unknown;
  new_value?: unknown;
  updated_at?: string;
  pipeline_id?: string;
};

export type OntologyResponse = {
  tree?: OntologyNode;
  version?: string;
  conflicts: Array<Record<string, unknown> | string>;
};

export async function fetchAgentConfigs(): Promise<AgentConfig[]> {
  return requestWithTimeout("/api/agents", { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(`Agent 配置请求失败：${response.status}`, { status: response.status });
    }

    const data: unknown = await response.json();
    return Array.isArray(data)
      ? data.flatMap((item) => {
          const config = normalizeAgentConfig(item);
          return config ? [config] : [];
        })
      : [];
  });
}

export async function updateAgentConfig(agentId: string, update: AgentConfigUpdate): Promise<void> {
  await requestWithTimeout(
    `/api/agents/${encodeURIComponent(agentId)}/config`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(update),
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(`Agent 配置保存失败：${response.status}`, { status: response.status });
      }
    },
  );
}

export async function fetchCompanyConfig(): Promise<CompanyConfig> {
  return requestWithTimeout("/api/company-config", { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(`公司配置请求失败：${response.status}`, { status: response.status });
    }

    const data: unknown = await response.json();
    return normalizeCompanyConfig(data);
  });
}

export async function updateCompanyConfig(config: CompanyConfig): Promise<CompanyConfig> {
  return requestWithTimeout(
    "/api/company-config",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(config),
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(`公司配置保存失败：${response.status}`, { status: response.status });
      }

      return normalizeCompanyConfig(await response.json());
    },
  );
}

/**
 * 上传公司 Logo / 海报底图。
 * 后端落盘后会自动写入 company_config 对应字段，返回文件 URL。
 */
export async function uploadCompanyAsset(kind: CompanyAssetKind, file: File): Promise<string> {
  const extension = (file.name.split(".").pop() ?? "").toLowerCase();
  if (!COMPANY_ASSET_EXTENSIONS.includes(extension)) {
    throw new ApiError("仅支持 jpg/png/svg/webp/gif 格式", { status: 0 });
  }
  if (file.size > COMPANY_ASSET_MAX_SIZE) {
    throw new ApiError("文件不能超过 5MB", { status: 0 });
  }

  const body = new FormData();
  body.append("file", file);
  const data = await requestWithTimeout<Record<string, unknown>>(
    `/api/company-config/${kind}`,
    { method: "POST", credentials: "include", body },
    async (response) => {
      const payload = (await response.json().catch(() => ({}))) as Record<string, unknown>;
      if (!response.ok) {
        const detail = typeof payload.detail === "string" ? payload.detail : `上传失败（${response.status}）`;
        throw new ApiError(detail, { status: response.status });
      }
      return payload;
    },
  );
  const url = data.logo_url ?? data.bg_url;
  if (typeof url !== "string" || !url) {
    throw new ApiError("服务器未返回文件地址", { status: 0 });
  }
  return url;
}

export async function fetchOntology(): Promise<OntologyResponse> {
  return requestWithTimeout("/api/ontology", { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(`本体规则请求失败：${response.status}`, { status: response.status });
    }

    const data: unknown = await response.json();
    return normalizeOntologyResponse(data);
  });
}

export async function fetchOntologyRules(): Promise<OntologyRule[]> {
  return requestWithTimeout("/api/ontology/rules", { credentials: "include" }, async (response) => {
    if (!response.ok) {
      throw new ApiError(`本体规则列表请求失败：${response.status}`, { status: response.status });
    }

    const data: unknown = await response.json();
    if (!isRecord(data) || !Array.isArray(data.rules)) {
      return [];
    }

    return data.rules.flatMap((item) => {
      const rule = normalizeOntologyRule(item);
      return rule ? [rule] : [];
    });
  });
}

function normalizeAgentConfig(value: unknown): AgentConfig | null {
  if (!isRecord(value) || typeof value.agent_id !== "string") {
    return null;
  }

  return {
    agent_id: value.agent_id,
    agent_name: getString(value.agent_name),
    display_name: getString(value.display_name),
    model: getString(value.model),
    complexity: getString(value.complexity),
    temperature: getNumber(value.temperature),
    timeout: getNumber(value.timeout),
    retry_count: getNumber(value.retry_count),
    enabled: getBoolean(value.enabled),
    human_approval: getBoolean(value.human_approval),
  };
}

function normalizeCompanyConfig(value: unknown): CompanyConfig {
  if (!isRecord(value)) {
    return {};
  }

  return {
    company_name: getString(value.company_name),
    company_short: getString(value.company_short),
    company_en: getString(value.company_en),
    industry: getString(value.industry),
    company_size: getString(value.company_size),
    company_website: getString(value.company_website),
    company_address: getString(value.company_address),
    default_benefits: Array.isArray(value.default_benefits)
      ? value.default_benefits.filter((item): item is string => typeof item === "string")
      : [],
    company_intro: getString(value.company_intro),
    brand_color: getString(value.brand_color),
    brand_color_secondary: getString(value.brand_color_secondary),
    company_logo: getString(value.company_logo),
    company_logo_thumb: getString(value.company_logo_thumb),
    poster_template: getString(value.poster_template),
    poster_bg_image: getString(value.poster_bg_image),
    poster_bg_image_thumb: getString(value.poster_bg_image_thumb),
  };
}

function normalizeOntologyResponse(value: unknown): OntologyResponse {
  if (!isRecord(value)) {
    return { conflicts: [] };
  }

  const tree = normalizeOntologyNode(value.tree);
  const conflicts = Array.isArray(value.conflicts)
    ? value.conflicts.flatMap((item) => {
        if (typeof item === "string" || isRecord(item)) {
          return [item];
        }
        return [];
      })
    : [];

  return {
    tree: tree ?? undefined,
    version: getString(value.version),
    conflicts,
  };
}

function normalizeOntologyNode(value: unknown): OntologyNode | null {
  if (!isRecord(value)) {
    return null;
  }

  const rules = isRecord(value.rules) ? value.rules : undefined;
  const children = Array.isArray(value.children)
    ? value.children.flatMap((child) => {
        const normalizedChild = normalizeOntologyNode(child);
        return normalizedChild ? [normalizedChild] : [];
      })
    : undefined;

  return {
    id: getString(value.id),
    name: getString(value.name),
    desc: getString(value.desc),
    node_type: getString(value.node_type),
    rules,
    children,
  };
}

function normalizeOntologyRule(value: unknown): OntologyRule | null {
  if (!isRecord(value)) {
    return null;
  }

  return {
    id: getString(value.id),
    node_id: getString(value.node_id),
    rule_id: getString(value.rule_id),
    field: getString(value.field),
    old_value: value.old_value,
    new_value: value.new_value,
    updated_at: getString(value.updated_at),
    pipeline_id: getString(value.pipeline_id),
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getString(value: unknown) {
  return typeof value === "string" ? value : undefined;
}

function getNumber(value: unknown) {
  return typeof value === "number" ? value : undefined;
}

function getBoolean(value: unknown) {
  return value === true || value === 1;
}
