import { afterEach, describe, expect, it, vi } from "vitest";

import {
  fetchAgentConfigs,
  fetchCompanyConfig,
  fetchOntology,
  fetchOntologyRules,
  updateAgentConfig,
  updateCompanyConfig,
} from "./api";

afterEach(() => vi.unstubAllGlobals());

describe("config api", () => {
  it("normalizes agent configuration values from the server", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [
          {
            agent_id: "jd_writer",
            display_name: "JD 撰写",
            enabled: 1,
            human_approval: 0,
            timeout: 90,
          },
        ],
      }),
    );

    await expect(fetchAgentConfigs()).resolves.toEqual([
      {
        agent_id: "jd_writer",
        agent_name: undefined,
        display_name: "JD 撰写",
        model: undefined,
        complexity: undefined,
        temperature: undefined,
        timeout: 90,
        retry_count: undefined,
        enabled: true,
        human_approval: false,
      },
    ]);
  });

  it("updates agent configuration with a typed request", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 200 });
    vi.stubGlobal("fetch", fetchMock);

    await expect(updateAgentConfig("jd_writer", { enabled: false })).resolves.toBeUndefined();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/agents/jd_writer/config",
      expect.objectContaining({
        method: "PUT",
        body: JSON.stringify({ enabled: false }),
        signal: expect.any(AbortSignal),
      }),
    );
  });

  it("loads and saves company configuration", async () => {
    const config = { company_name: "锅圈食汇", default_benefits: ["五险一金"] };
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => config })
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => config });
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchCompanyConfig()).resolves.toEqual({
      company_name: "锅圈食汇",
      default_benefits: ["五险一金"],
      company_short: undefined,
      company_en: undefined,
      industry: undefined,
      company_size: undefined,
      company_website: undefined,
      company_address: undefined,
      company_intro: undefined,
      brand_color: undefined,
      brand_color_secondary: undefined,
      poster_template: undefined,
      poster_bg_image: undefined,
    });
    await expect(updateCompanyConfig(config)).resolves.toMatchObject(config);
    expect(fetchMock).toHaveBeenLastCalledWith(
      "/api/company-config",
      expect.objectContaining({ method: "POST", signal: expect.any(AbortSignal) }),
    );
  });

  it("loads ontology tree and configured rules", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({
          tree: {
            id: "root",
            name: "招聘本体",
            children: [{ id: "skill", name: "技能", rules: { required: true } }],
          },
          conflicts: [{ message: "规则冲突", severity: "warning" }],
        }),
      })
      .mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ rules: [{ id: "rule-1", field: "years", old_value: 3, new_value: 5 }] }),
      });
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchOntology()).resolves.toMatchObject({
      tree: { id: "root", children: [{ id: "skill", rules: { required: true } }] },
      conflicts: [{ message: "规则冲突", severity: "warning" }],
    });
    await expect(fetchOntologyRules()).resolves.toEqual([
      {
        id: "rule-1",
        node_id: undefined,
        rule_id: undefined,
        field: "years",
        old_value: 3,
        new_value: 5,
        updated_at: undefined,
        pipeline_id: undefined,
      },
    ]);
    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "/api/ontology",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "/api/ontology/rules",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
  });
});
