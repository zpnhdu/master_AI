import type { TalentRecommendation, XiaoXunCandidate } from "./api";

export type CandidateSource = "talent_pool" | "local_upload" | "email" | "other";

export type RecommendationFilters = {
  level: "all" | "high" | "possible" | "explore";
  location: string;
  source: "all" | "email" | "upload";
  freshnessDays: number | null;
};

export function getCandidateSource(candidate: XiaoXunCandidate): CandidateSource {
  const source = candidate.source ?? "";
  if (source.startsWith("talent_pool") || candidate.resumeId) {
    return "talent_pool";
  }
  if (candidate.sourceChannel === "email" || source.startsWith("email:")) {
    return "email";
  }
  if (source.startsWith("file:") || source === "local_import" || candidate.sourceChannel === "upload") {
    return "local_upload";
  }
  return "other";
}

export function countCandidateSources(candidates: XiaoXunCandidate[]): Record<CandidateSource, number> {
  const counts: Record<CandidateSource, number> = {
    talent_pool: 0,
    local_upload: 0,
    email: 0,
    other: 0,
  };
  candidates.forEach((candidate) => {
    counts[getCandidateSource(candidate)] += 1;
  });
  return counts;
}

function recommendationMatchesSource(
  recommendation: TalentRecommendation,
  source: RecommendationFilters["source"],
): boolean {
  if (source === "all") return true;
  const rawSource = recommendation.source ?? "";
  if (source === "email") {
    return recommendation.sourceChannel === "email" || rawSource.startsWith("email:");
  }
  return recommendation.sourceChannel === "upload" || rawSource.startsWith("file:") || rawSource === "local_import";
}

function recommendationTimestamp(recommendation: TalentRecommendation): number {
  const value = recommendation.updatedAt;
  if (!value) return 0;
  const normalized = value.includes("T") ? value : value.replace(" ", "T");
  const timestamp = Date.parse(normalized.endsWith("Z") ? normalized : `${normalized}Z`);
  return Number.isFinite(timestamp) ? timestamp : 0;
}

function recommendationIsFresh(
  recommendation: TalentRecommendation,
  freshnessDays: number | null,
  now: number,
): boolean {
  if (!freshnessDays) return true;
  const timestamp = recommendationTimestamp(recommendation);
  return timestamp > 0 && timestamp >= now - freshnessDays * 86_400_000;
}

export function filterRecommendationResults(
  recommendations: TalentRecommendation[],
  filters: RecommendationFilters,
  now = Date.now(),
): TalentRecommendation[] {
  return recommendations.filter((recommendation) => {
    if (filters.level !== "all" && recommendation.relevanceLevel !== filters.level) return false;
    if (filters.location && recommendation.location !== filters.location) return false;
    if (!recommendationMatchesSource(recommendation, filters.source)) return false;
    return recommendationIsFresh(recommendation, filters.freshnessDays, now);
  });
}
