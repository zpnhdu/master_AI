import { describe, expect, it } from "vitest";

import { countCandidateSources, filterRecommendationResults, getCandidateSource } from "./selectors";
import type { TalentRecommendation, XiaoXunCandidate } from "./api";

describe("xiao-xun selectors", () => {
  it("normalizes candidate sources and counts local versus talent-pool origins", () => {
    const candidates: XiaoXunCandidate[] = [
      { source: "talent_pool:email" },
      { resumeId: "resume-2" },
      { source: "file:resume.pdf" },
      { source: "local_import" },
      { sourceChannel: "email" },
      { source: "manual" },
    ];

    expect(candidates.map(getCandidateSource)).toEqual([
      "talent_pool",
      "talent_pool",
      "local_upload",
      "local_upload",
      "email",
      "other",
    ]);
    expect(countCandidateSources(candidates)).toEqual({
      talent_pool: 2,
      local_upload: 2,
      email: 1,
      other: 1,
    });
  });

  it("filters recommendations by level, location, source, and freshness", () => {
    const results: TalentRecommendation[] = [
      {
        resumeId: "high-email",
        relevanceLevel: "high",
        location: "上海",
        source: "email:hr@example.com",
        updatedAt: "2026-08-10 12:00:00",
      },
      {
        resumeId: "possible-upload",
        relevanceLevel: "possible",
        location: "上海",
        source: "file:resume.pdf",
        updatedAt: "2026-06-01 12:00:00",
      },
      {
        resumeId: "local-import",
        relevanceLevel: "possible",
        location: "上海",
        source: "local_import",
      },
      {
        resumeId: "explore-old",
        relevanceLevel: "explore",
        location: "北京",
        source: "file:old.pdf",
        updatedAt: "2025-01-01 12:00:00",
      },
    ];

    expect(
      filterRecommendationResults(
        results,
        { level: "high", location: "上海", source: "email", freshnessDays: 30 },
        new Date("2026-08-18T12:00:00Z").getTime(),
      ),
    ).toEqual([results[0]]);

    expect(
      filterRecommendationResults(results, {
        level: "all",
        location: "",
        source: "upload",
        freshnessDays: null,
      }),
    ).toEqual([results[1], results[2], results[3]]);
  });
});
