import { ApiError, requestWithTimeout } from "../pipelines/api";
import { uploadTalentResumes, type UploadResult } from "../talent-pool/api";

export type XiaoXunCandidate = {
  id?: string;
  name?: string;
  resumeId?: string;
  filename?: string;
  file?: string;
  source?: string;
  sourceChannel?: string;
  title?: string;
  company?: string;
  currentCompany?: string;
  location?: string;
  years?: number;
  yearsExperience?: number | string;
  skills?: string[];
  resumeText?: string;
  phone?: string;
  email?: string;
  contactStatus?: string;
  education?: string;
  updatedAt?: string;
  [key: string]: unknown;
};

export type CrawlStats = {
  uploaded: number;
  parsed: number;
  failed: number;
  scanned: number;
  poolImported: number;
  fileUploaded: number;
  formats: Record<string, number>;
};

export type XiaoXunPipelineStage = {
  stageId: string;
  status: string;
  output: Record<string, unknown>;
};

export type XiaoXunPipeline = {
  id: string;
  role: string;
  status?: string;
  agents: string[];
  stages: XiaoXunPipelineStage[];
  candidates: XiaoXunCandidate[];
  crawlStats: CrawlStats;
};

export type UploadFileResult = {
  name: string;
  status: "success" | "duplicate" | "error";
  resumeId?: string;
  error?: string;
  size?: number;
  format?: string;
};

export type UploadResumesResponse = {
  success: boolean;
  uploaded: number;
  total: number;
  files: UploadFileResult[];
};

export type ParseResult = {
  file: string;
  status: "success" | "duplicate" | "error";
  error?: string;
  errorType?: string;
  data?: XiaoXunCandidate;
};

export type ParseResumesResponse = {
  success: boolean;
  parsed: number;
  total: number;
  fromPool: number;
  duplicates: number;
  missingContactCount: number;
  manualContactCount: number;
  message: string;
  results: ParseResult[];
};

export type RecommendationScope = "precise" | "balanced" | "broad";

export type TalentRecommendation = XiaoXunCandidate & {
  relevanceLevel?: "high" | "possible" | "explore";
  matchedTerms?: string[];
  gaps?: string[];
  missingRequired?: string[];
};

export type RecommendationQuery = {
  limit?: number;
  scope?: RecommendationScope;
  keywords?: string[];
  required?: string[];
  excluded?: string[];
  hardGates?: boolean;
};

export type TalentRecommendationsResponse = {
  results: TalentRecommendation[];
  total: number;
  poolTotal: number;
  pipelineId: string;
  reason: string;
  scope: RecommendationScope;
  criteria: Record<string, unknown>;
  levelCounts: Record<string, number>;
  hardGateFiltered: number;
};

export type AcceptTalentRecommendationsResponse = {
  accepted: number;
  candidates: XiaoXunCandidate[];
};

export type XiaoXunRawFile = {
  name: string;
  extension: string;
  sizeKb: number;
};

export type XiaoXunRawFilesResponse = {
  files: XiaoXunRawFile[];
  count: number;
};

export type TalentPoolSummary = {
  total: number;
};

export type PassXiaoXunArtifactResponse = {
  success: boolean;
  fromAgent: string;
  toAgent: string;
  toName: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function asIdentifier(value: unknown): string {
  return typeof value === "string" || typeof value === "number" ? String(value) : "";
}

function asNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  return fallback;
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === "string");
  }
  if (typeof value === "string") {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
    } catch {
      return value ? [value] : [];
    }
  }
  return [];
}

function parseRecord(value: unknown): Record<string, unknown> {
  if (isRecord(value)) {
    return value;
  }
  if (typeof value !== "string" || !value.trim()) {
    return {};
  }

  let current: unknown = value;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    if (isRecord(current)) {
      return current;
    }
    if (typeof current !== "string") {
      return {};
    }
    try {
      current = JSON.parse(current);
    } catch {
      return {};
    }
  }
  return isRecord(current) ? current : {};
}

function normalizeNumberMap(value: unknown): Record<string, number> {
  if (!isRecord(value)) {
    return {};
  }
  return Object.fromEntries(
    Object.entries(value).flatMap(([key, item]) => {
      const number = asNumber(item, Number.NaN);
      return Number.isFinite(number) ? [[key.toUpperCase(), number]] : [];
    }),
  );
}

export function normalizeCandidate(value: unknown): XiaoXunCandidate | null {
  if (!isRecord(value)) {
    return null;
  }

  const candidate: XiaoXunCandidate = {};
  const id = asIdentifier(value.id ?? value.candidate_id ?? value.candidateId);
  const name = asString(value.name);
  const resumeId = asIdentifier(value.resume_id ?? value.resumeId);
  if (id) candidate.id = id;
  if (name) candidate.name = name;
  if (resumeId) candidate.resumeId = resumeId;

  const fields: Array<[keyof XiaoXunCandidate, string[]]> = [
    ["filename", ["filename", "file"]],
    ["file", ["file"]],
    ["source", ["source"]],
    ["sourceChannel", ["source_channel", "sourceChannel"]],
    ["title", ["title"]],
    ["company", ["company"]],
    ["currentCompany", ["current_company", "currentCompany"]],
    ["location", ["location"]],
    ["resumeText", ["resume_text", "resumeText"]],
    ["phone", ["phone"]],
    ["email", ["email"]],
    ["contactStatus", ["contact_status", "contactStatus"]],
    ["education", ["education"]],
    ["updatedAt", ["updated_at", "updatedAt"]],
  ];
  for (const [key, names] of fields) {
    const sourceKey = names.find((nameKey) => value[nameKey] !== undefined);
    if (sourceKey) {
      const item = value[sourceKey];
      if (typeof item === "string") {
        candidate[key] = item;
      }
    }
  }

  const years = value.years;
  const yearsExperience = value.years_experience ?? value.yearsExperience;
  if (years !== undefined) candidate.years = asNumber(years);
  if (yearsExperience !== undefined) {
    candidate.yearsExperience = typeof yearsExperience === "number" ? yearsExperience : asString(yearsExperience);
  }
  const skills = asStringArray(value.skills);
  if (skills.length > 0) candidate.skills = skills;

  return Object.keys(candidate).length > 0 ? candidate : null;
}

export function normalizeCrawlStats(crawlStage: unknown, candidates: XiaoXunCandidate[] = []): CrawlStats {
  const stage = isRecord(crawlStage) ? crawlStage : {};
  const output = parseRecord(stage.output);
  const uploaded = asNumber(output.resume_count ?? output.total, candidates.length);
  const parsed = asNumber(output.parsed_count ?? output.parsed, stage.status === "done" ? candidates.length : 0);
  const failed = asNumber(output.failed_count ?? output.errors);
  const poolImported = asNumber(
    output.pool_import_count,
    candidates.filter((candidate) => candidate.source?.startsWith("talent_pool") || Boolean(candidate.resumeId)).length,
  );
  let fileUploaded = asNumber(output.file_upload_count, Math.max(candidates.length - poolImported, 0));
  if (uploaded > 0 && poolImported === 0 && fileUploaded === 0) {
    fileUploaded = uploaded;
  }

  return {
    uploaded,
    parsed,
    failed,
    scanned: Math.max(uploaded - parsed - failed, 0),
    poolImported,
    fileUploaded,
    formats: normalizeNumberMap(output.formats),
  };
}

function normalizeStage(value: unknown): XiaoXunPipelineStage | null {
  if (!isRecord(value)) {
    return null;
  }
  const stageId = asString(value.stage_id || value.stageId);
  if (!stageId) {
    return null;
  }
  return {
    stageId,
    status: asString(value.status, "pending"),
    output: parseRecord(value.output),
  };
}

export function normalizeXiaoXunPipeline(value: unknown): XiaoXunPipeline {
  const record = isRecord(value) ? value : {};
  const candidates = Array.isArray(record.candidates)
    ? record.candidates.flatMap((item) => {
        const candidate = normalizeCandidate(item);
        return candidate ? [candidate] : [];
      })
    : [];
  const stages = Array.isArray(record.stages)
    ? record.stages.flatMap((item) => {
        const stage = normalizeStage(item);
        return stage ? [stage] : [];
      })
    : [];
  const crawlStage = stages.find((stage) => stage.stageId === "crawl");

  return {
    id: asIdentifier(record.id ?? record.pipeline_id),
    role: asString(record.role, "未命名岗位"),
    status: asString(record.status) || undefined,
    agents: asStringArray(record.agents),
    stages,
    candidates,
    crawlStats: normalizeCrawlStats(crawlStage, candidates),
  };
}

export async function fetchXiaoXunPipeline(pipelineId: string): Promise<XiaoXunPipeline> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}`,
    { credentials: "include" },
    (response) => parseResponse(response, "岗位加载失败", normalizeXiaoXunPipeline),
  );
}

function readErrorMessage(data: unknown, fallback: string): string {
  if (isRecord(data)) {
    if (typeof data.detail === "string") return data.detail;
    if (isRecord(data.detail) && typeof data.detail.message === "string") {
      return data.detail.message;
    }
    if (typeof data.message === "string") return data.message;
  }
  return fallback;
}

async function parseResponse<T>(response: Response, fallback: string, normalize: (value: unknown) => T): Promise<T> {
  if (!response.ok) {
    const data: unknown = await response.json().catch(() => ({}));
    throw new ApiError(readErrorMessage(data, `${fallback} (${response.status})`), {
      status: response.status,
      data,
    });
  }

  let data: unknown;
  try {
    data = await response.json();
  } catch {
    throw new ApiError(`${fallback}：响应格式无效`, { status: response.status });
  }
  return normalize(data);
}

function normalizeUploadFile(value: unknown): UploadFileResult | null {
  if (!isRecord(value)) return null;
  const status = value.status === "success" || value.status === "duplicate" ? value.status : "error";
  const result: UploadFileResult = {
    name: asString(value.name || value.filename),
    status,
    resumeId: asString(value.id || value.existing_id) || undefined,
  };
  const error = asString(value.error);
  const format = asString(value.format);
  if (error) result.error = error;
  if (format) result.format = format;
  if (value.size !== undefined) result.size = asNumber(value.size);
  return result;
}

function normalizeUploadResponse(value: unknown): UploadResumesResponse {
  const record = isRecord(value) ? value : {};
  return {
    success: value === true || record.success === true,
    uploaded: asNumber(record.uploaded),
    total: asNumber(record.total),
    files: Array.isArray(record.files)
      ? record.files.flatMap((item) => {
          const file = normalizeUploadFile(item);
          return file ? [file] : [];
        })
      : [],
  };
}

export async function uploadResumes(pipelineId: string, files: File[]): Promise<UploadResumesResponse> {
  const payload = (await uploadTalentResumes(files, "", pipelineId)) as { results?: UploadResult[]; count?: number };
  const filesResult = (payload.results ?? [])
    .map((item) =>
      normalizeUploadFile({
        ...item,
        name: item.filename,
        status: item.duplicate ? "duplicate" : item.skipped ? "error" : "success",
      }),
    )
    .filter((item): item is UploadFileResult => item !== null);
  return {
    success: filesResult.some((item) => item.status !== "error"),
    uploaded: filesResult.filter((item) => item.status !== "error").length,
    total: payload.count ?? files.length,
    files: filesResult,
  };
}

function normalizeParseResult(value: unknown): ParseResult | null {
  if (!isRecord(value)) return null;
  const status = value.status === "success" || value.status === "duplicate" ? value.status : "error";
  const result: ParseResult = { file: asString(value.file || value.filename), status };
  const error = asString(value.error);
  const errorType = asString(value.error_type || value.errorType);
  const data = normalizeCandidate(value.data);
  if (error) result.error = error;
  if (errorType) result.errorType = errorType;
  if (data) result.data = data;
  return result;
}

function normalizeParseResponse(value: unknown): ParseResumesResponse {
  const record = isRecord(value) ? value : {};
  return {
    success: record.success !== false,
    parsed: asNumber(record.parsed),
    total: asNumber(record.total),
    fromPool: asNumber(record.from_pool ?? record.fromPool),
    duplicates: asNumber(record.duplicates),
    missingContactCount: asNumber(record.missing_contact_count ?? record.missingContactCount),
    manualContactCount: asNumber(record.manual_contact_count ?? record.manualContactCount),
    message: asString(record.message),
    results: Array.isArray(record.results)
      ? record.results.flatMap((item) => {
          const result = normalizeParseResult(item);
          return result ? [result] : [];
        })
      : [],
  };
}

export async function parseResumes(pipelineId: string): Promise<ParseResumesResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/parse-resumes`,
    { method: "POST", credentials: "include" },
    (response) => parseResponse(response, "简历解析失败", normalizeParseResponse),
  );
}

export async function fetchRawResumeFiles(pipelineId: string): Promise<XiaoXunRawFilesResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/raw-files`,
    { credentials: "include" },
    (response) =>
      parseResponse(response, "已上传文件加载失败", (value) => {
        const record = isRecord(value) ? value : {};
        return {
          files: Array.isArray(record.files)
            ? record.files.flatMap((item) => {
                if (!isRecord(item)) return [];
                return [
                  {
                    name: asString(item.name),
                    extension: asString(item.ext),
                    sizeKb: asNumber(item.size_kb ?? item.sizeKb),
                  },
                ];
              })
            : [],
          count: asNumber(record.count),
        };
      }),
  );
}

export async function fetchTalentPoolSummary(): Promise<TalentPoolSummary> {
  return requestWithTimeout("/api/talent-pool/resumes?limit=1", { credentials: "include" }, (response) =>
    parseResponse(response, "人才库统计加载失败", (value) => ({
      total: asNumber(isRecord(value) ? value.total : 0),
    })),
  );
}

function normalizeRecommendation(value: unknown): TalentRecommendation | null {
  const candidate = normalizeCandidate(value);
  if (!candidate) return null;
  const record = isRecord(value) ? value : {};
  const recommendation: TalentRecommendation = { ...candidate };
  const level = asString(record.relevance_level || record.relevanceLevel);
  if (level === "high" || level === "possible" || level === "explore") {
    recommendation.relevanceLevel = level;
  }
  const matchedTerms = asStringArray(record.matched_terms || record.matchedTerms);
  const gaps = asStringArray(record.gaps);
  const missingRequired = asStringArray(record.missing_required || record.missingRequired);
  if (matchedTerms.length) recommendation.matchedTerms = matchedTerms;
  if (gaps.length) recommendation.gaps = gaps;
  if (missingRequired.length) recommendation.missingRequired = missingRequired;
  return recommendation;
}

function normalizeLevelCounts(value: unknown): Record<string, number> {
  if (!isRecord(value)) return {};
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, asNumber(item)]));
}

function toQueryList(value: string[] | undefined): string {
  return value?.filter(Boolean).join(",") ?? "";
}

export async function fetchTalentRecommendations(
  pipelineId: string,
  query: RecommendationQuery = {},
): Promise<TalentRecommendationsResponse> {
  const params = new URLSearchParams({
    limit: String(query.limit ?? 20),
    scope: query.scope ?? "balanced",
  });
  const optionalParams: Array<[string, string]> = [
    ["keywords", toQueryList(query.keywords)],
    ["required", toQueryList(query.required)],
    ["excluded", toQueryList(query.excluded)],
    ["hard_gates", query.hardGates ? "1" : ""],
  ];
  optionalParams.forEach(([key, value]) => {
    if (value) params.set(key, value);
  });

  return requestWithTimeout(
    `/api/talent-pool/recommend/${encodeURIComponent(pipelineId)}?${params.toString()}`,
    { credentials: "include" },
    (response) =>
      parseResponse(response, "人才库匹配失败", (value) => {
        const record = isRecord(value) ? value : {};
        const scope = asString(record.scope, query.scope ?? "balanced");
        const normalizedScope: RecommendationScope = scope === "precise" || scope === "broad" ? scope : "balanced";
        return {
          results: Array.isArray(record.results)
            ? record.results.flatMap((item) => {
                const result = normalizeRecommendation(item);
                return result ? [result] : [];
              })
            : [],
          total: asNumber(record.total),
          poolTotal: asNumber(record.pool_total ?? record.poolTotal),
          pipelineId: asString(record.pipeline_id ?? record.pipelineId, pipelineId),
          reason: asString(record.reason),
          scope: normalizedScope,
          criteria: parseRecord(record.criteria),
          levelCounts: normalizeLevelCounts(record.level_counts ?? record.levelCounts),
          hardGateFiltered: asNumber(record.hard_gate_filtered ?? record.hardGateFiltered),
        };
      }),
  );
}

export async function acceptTalentRecommendations(
  pipelineId: string,
  resumeIds: string[],
): Promise<AcceptTalentRecommendationsResponse> {
  return requestWithTimeout(
    `/api/talent-pool/recommend/${encodeURIComponent(pipelineId)}/accept`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ resume_ids: resumeIds }),
    },
    (response) =>
      parseResponse(response, "人才库导入失败", (value) => {
        const record = isRecord(value) ? value : {};
        return {
          accepted: asNumber(record.accepted),
          candidates: Array.isArray(record.candidates)
            ? record.candidates.flatMap((item) => {
                const candidate = normalizeCandidate(item);
                return candidate ? [candidate] : [];
              })
            : [],
        };
      }),
  );
}

export async function passXiaoXunArtifact(
  pipelineId: string,
  toAgent: string,
  artifacts: Record<string, unknown>,
): Promise<PassXiaoXunArtifactResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/pass-artifact`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ from_agent: "xiao_xun", to_agent: toAgent, artifacts }),
    },
    (response) =>
      parseResponse(response, "传递失败", (value) => {
        const record = isRecord(value) ? value : {};
        return {
          success: record.success === true,
          fromAgent: asString(record.from_agent, "xiao_xun"),
          toAgent: asString(record.to_agent, toAgent),
          toName: asString(record.to_name),
        };
      }),
  );
}
