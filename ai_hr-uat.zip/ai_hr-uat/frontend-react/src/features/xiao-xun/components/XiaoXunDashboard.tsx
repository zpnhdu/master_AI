import { Card, Progress, Statistic, Tag } from 'antd';

import type { XiaoXunPipeline } from '../api';
import { countCandidateSources } from '../selectors';

type XiaoXunDashboardProps = {
  pipeline: XiaoXunPipeline;
  talentPoolTotal?: number;
};

function formatPercent(value: number, total: number) {
  return total > 0 ? Math.round((value / total) * 100) : 0;
}

export function XiaoXunDashboard({ pipeline, talentPoolTotal }: XiaoXunDashboardProps) {
  const stats = pipeline.crawlStats;
  const sourceCounts = countCandidateSources(pipeline.candidates);
  const pending = Math.max(stats.uploaded - stats.parsed - stats.failed, 0);
  const needsAttention = stats.failed + pending;
  const total = Math.max(stats.uploaded, pipeline.candidates.length, 1);
  const formats = Object.entries(stats.formats);

  return (
    <aside className="xun-dashboard-pane">
      <Card className="xun-card xun-dashboard-card" title="处理概况">
        <div className="xun-kpi-grid">
          <Statistic title="文件总数" value={stats.uploaded} />
          <Statistic title="解析成功" value={stats.parsed} />
          <Statistic title="需处理" value={needsAttention} />
        </div>
        <div className="xun-dashboard-section">
          <div className="xun-dashboard-heading"><strong>解析进度</strong><span>{stats.parsed}/{stats.uploaded || 0} 份已解析</span></div>
          <Progress percent={formatPercent(stats.parsed, stats.uploaded)} strokeColor="#10b981" showInfo={false} />
          <div className="xun-dashboard-tags">
            {stats.failed > 0 ? <Tag color="error">解析失败 {stats.failed}</Tag> : null}
            {pending > 0 ? <Tag color="warning">待解析 {pending}</Tag> : null}
            {stats.scanned > 0 ? <Tag color="warning">扫描件 {stats.scanned}</Tag> : null}
            {stats.failed === 0 && pending === 0 ? <Tag color="success">当前处理完成</Tag> : null}
          </div>
        </div>
        <div className="xun-dashboard-section">
          <div className="xun-dashboard-heading"><strong>候选人来源</strong><span>{pipeline.candidates.length} 人</span></div>
          <div className="xun-bar-list">
            <DashboardBar label="人才库导入" value={sourceCounts.talent_pool} total={total} color="#10b981" />
            <DashboardBar label="本地上传" value={sourceCounts.local_upload} total={total} color="#2563eb" />
            <DashboardBar label="HR 邮箱" value={sourceCounts.email} total={total} color="#8b5cf6" />
          </div>
        </div>
        <div className="xun-dashboard-section">
          <div className="xun-dashboard-heading"><strong>文件概览</strong><span>{formats.length || '—'} 种格式</span></div>
          {formats.length > 0 ? (
            <div className="xun-bar-list">
              {formats.map(([format, value]) => <DashboardBar key={format} label={format.toUpperCase()} value={value} total={total} color="#f59e0b" />)}
            </div>
          ) : <span className="xun-muted-text">解析后显示文件格式分布</span>}
        </div>
        <div className="xun-dashboard-footer">
          <span>人才库可选</span><strong>{talentPoolTotal ?? '—'}</strong>
        </div>
      </Card>
    </aside>
  );
}

function DashboardBar({ label, value, total, color }: { label: string; value: number; total: number; color: string }) {
  return (
    <div className="xun-dashboard-bar">
      <div><span>{label}</span><strong>{value}</strong></div>
      <div className="xun-dashboard-track"><span style={{ width: `${Math.min((value / total) * 100, 100)}%`, background: color }} /></div>
    </div>
  );
}
