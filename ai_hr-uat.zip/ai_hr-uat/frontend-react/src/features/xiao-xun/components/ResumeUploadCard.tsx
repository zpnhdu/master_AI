import { Alert, Button, Card, List, Tag } from 'antd';
import { useRef } from 'react';

import type {
  ParseResult,
  ParseResumesResponse,
  UploadFileResult,
  XiaoXunRawFile,
} from '../api';

type ResumeUploadCardProps = {
  selectedFiles: File[];
  fileResults: UploadFileResult[];
  parseResults: ParseResult[];
  parseSummary: ParseResumesResponse | null;
  validationErrors: string[];
  rawFiles: XiaoXunRawFile[];
  rawFilesLoading: boolean;
  uploadPending: boolean;
  mutationError: string;
  onFilesSelected: (files: File[]) => void;
  onRemoveFile: (index: number) => void;
  onClearFiles: () => void;
  onUpload: () => void;
  onRefreshRawFiles: () => void;
};

function statusLabel(status: UploadFileResult['status'] | ParseResult['status']) {
  if (status === 'success') return '成功';
  if (status === 'duplicate') return '重复';
  return '失败';
}

function statusColor(status: UploadFileResult['status'] | ParseResult['status']) {
  if (status === 'success') return 'success';
  if (status === 'duplicate') return 'warning';
  return 'error';
}

function parseErrorLabel(errorType?: string) {
  const labels: Record<string, string> = {
    scanned_pdf: '扫描件 PDF',
    insufficient_text: '内容不足',
    dependency_missing: '依赖缺失',
    pdf_parse_error: 'PDF 解析错误',
    docx_parse_error: 'DOCX 解析错误',
  };
  return labels[errorType ?? ''] ?? '解析失败';
}

export function ResumeUploadCard({
  selectedFiles,
  fileResults,
  parseResults,
  parseSummary,
  validationErrors,
  rawFiles,
  rawFilesLoading,
  uploadPending,
  mutationError,
  onFilesSelected,
  onRemoveFile,
  onClearFiles,
  onUpload,
  onRefreshRawFiles,
}: ResumeUploadCardProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  function selectFiles(fileList: FileList | null) {
    if (!fileList) return;
    onFilesSelected(Array.from(fileList));
  }

  return (
    <Card className="xun-card xun-upload-card" title="本地上传简历">
      <div className="xun-upload-hint">支持 PDF、DOC、DOCX、MD，最多 50 份，单个文件不超过 10MB</div>
      <button
        className="xun-upload-zone"
        type="button"
        disabled={uploadPending}
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => {
          event.preventDefault();
          selectFiles(event.dataTransfer.files);
        }}
      >
        <span className="xun-upload-icon" aria-hidden="true">↑</span>
        <strong>{uploadPending ? '正在上传并解析…' : '点击或拖拽文件到此处'}</strong>
        <span>批量上传后自动解析，结果会保留在下方</span>
      </button>
      <input
        ref={inputRef}
        className="xun-file-input"
        aria-label="上传简历文件"
        type="file"
        multiple
        accept=".pdf,.doc,.docx,.md"
        onChange={(event) => {
          selectFiles(event.target.files);
          event.target.value = '';
        }}
      />

      {validationErrors.length > 0 ? (
        <Alert
          className="xun-upload-alert"
          type="warning"
          showIcon
          message="部分文件未加入上传"
          description={validationErrors.join('；')}
        />
      ) : null}
      {mutationError ? (
        <Alert className="xun-upload-alert" type="error" showIcon message="上传或解析失败" description={mutationError} />
      ) : null}

      {selectedFiles.length > 0 ? (
        <div className="xun-selected-files">
          <div className="xun-block-heading">
            <strong>待上传文件</strong>
            <span>{selectedFiles.length} 份</span>
          </div>
          <List
            size="small"
            dataSource={selectedFiles}
            renderItem={(file, index) => (
              <List.Item
                actions={[
                  <Button
                    key="remove"
                    type="link"
                    size="small"
                    aria-label={`移除 ${file.name}`}
                    onClick={() => onRemoveFile(index)}
                  >
                    移除
                  </Button>,
                ]}
              >
                <span className="xun-file-name">{file.name}</span>
                <span className="xun-muted-text">{Math.ceil(file.size / 1024)}KB</span>
              </List.Item>
            )}
          />
          <div className="xun-selection-actions">
            <Button type="primary" loading={uploadPending} onClick={onUpload}>
              上传全部
            </Button>
            <Button disabled={uploadPending} onClick={onClearFiles}>清空</Button>
          </div>
        </div>
      ) : null}

      {fileResults.length > 0 ? (
        <div className="xun-result-block">
          <div className="xun-block-heading">
            <strong>上传结果</strong>
            <span>{fileResults.length} 份</span>
          </div>
          <List
            className="xun-file-result-list"
            size="small"
            dataSource={fileResults}
            renderItem={(file) => (
              <List.Item>
                <span className="xun-file-name">{file.name}</span>
                <span>
                  <Tag color={statusColor(file.status)}>{statusLabel(file.status)}</Tag>
                  {file.error ? <span className="xun-error-text">{file.error}</span> : null}
                </span>
              </List.Item>
            )}
          />
        </div>
      ) : null}

      {parseSummary ? (
        <div className="xun-parse-summary">
          <div className="xun-block-heading">
            <strong>解析结果</strong>
            <span>{parseSummary.message || `${parseSummary.parsed}/${parseSummary.total} 份已解析`}</span>
          </div>
          <div className="xun-inline-stats">
            <Tag color="success">解析成功 {parseSummary.parsed}</Tag>
            <Tag color="warning">重复 {parseSummary.duplicates}</Tag>
            <Tag color="error">失败 {Math.max(parseSummary.total - parseSummary.parsed - parseSummary.duplicates, 0)}</Tag>
          </div>
          {parseSummary.missingContactCount > 0 ? (
            <Alert
              className="xun-contact-alert"
              type="warning"
              showIcon
              message={`联系方式缺失 ${parseSummary.missingContactCount} 人`}
              description={parseResults
                .filter((result) => result.data?.contactStatus === 'missing')
                .map((result) => result.data?.name || result.file)
                .slice(0, 10)
                .join('、')}
            />
          ) : null}
          {parseSummary.manualContactCount > 0 ? (
            <Alert
              className="xun-contact-alert"
              type="warning"
              showIcon
              message={`仅有电话、需人工联系 ${parseSummary.manualContactCount} 人`}
              description={parseResults
                .filter((result) => result.data?.contactStatus === 'manual')
                .map((result) => result.data?.name || result.file)
                .slice(0, 10)
                .join('、')}
            />
          ) : null}
          {parseResults.length > 0 ? (
            <List
              className="xun-file-result-list"
              size="small"
              dataSource={parseResults}
              renderItem={(result) => (
                <List.Item>
                  <span className="xun-file-name">{result.file}</span>
                  <span>
                    <Tag color={statusColor(result.status)}>{statusLabel(result.status)}</Tag>
                    {result.status === 'error' ? (
                      <span className="xun-error-text">
                        {parseErrorLabel(result.errorType)}{result.error ? `：${result.error}` : ''}
                      </span>
                    ) : result.error ? <span className="xun-error-text">{result.error}</span> : null}
                  </span>
                </List.Item>
              )}
            />
          ) : null}
        </div>
      ) : null}

      <div className="xun-uploaded-files">
        <div className="xun-block-heading">
          <strong>已上传文件</strong>
          <Button type="link" size="small" loading={rawFilesLoading} onClick={onRefreshRawFiles}>
            刷新
          </Button>
        </div>
        {rawFiles.length > 0 ? (
          <List
            size="small"
            dataSource={rawFiles}
            renderItem={(file) => <List.Item><span>{file.name}</span><span>{file.extension} · {file.sizeKb}KB</span></List.Item>}
          />
        ) : (
          <span className="xun-muted-text">暂无已上传文件</span>
        )}
      </div>
    </Card>
  );
}
