import { Alert, Button, Card, Checkbox, Modal, Space, Tag } from 'antd';
import { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';

import { searchTalentResumes, type TalentResume } from '../../talent-pool/api';
import type { TalentRecommendation, XiaoXunCandidate } from '../api';
import { DataTable, DataTableAction } from '../../../shared/data-table';
import type { DataTableColumn } from '../../../shared/data-table';
import { ListSearch, ListToolbar } from '../../../shared/list-workbench';
import { ResumePreviewModal } from '../../talent-pool/components/ResumePreviewModal';

type TalentPoolImportCardProps = {
  pipelineId: string;
  total: number | undefined;
  jdReady: boolean;
  recommendations: TalentRecommendation[];
  totalRecommendations: number;
  loading: boolean;
  error: string;
  selectedResumeIds: string[];
  importedResumeIds: string[];
  existingResumeIds: string[];
  importPending: boolean;
  hardGateFiltered?: number;
  onUpload: () => void;
  onToggleResume: (resumeId: string, selected: boolean) => void;
  onImport: () => void;
  onImportIds: (resumeIds: string[]) => Promise<void>;
};

const LEVEL_LABELS = {
  high: '高度相关',
  possible: '可能合适',
  explore: '拓展候选',
} as const;

function recommendationId(recommendation: TalentRecommendation) {
  return recommendation.resumeId || recommendation.id || '';
}

function displayValue(value: unknown) {
  return value === undefined || value === null || value === '' ? '—' : String(value);
}

export function TalentPoolImportCard({
  total,
  jdReady,
  recommendations,
  totalRecommendations,
  loading,
  error,
  selectedResumeIds,
  importedResumeIds,
  existingResumeIds,
  importPending,
  hardGateFiltered = 0,
  onUpload,
  onToggleResume,
  onImport,
  onImportIds,
  pipelineId,
}: TalentPoolImportCardProps) {
  const [detailCandidate, setDetailCandidate] = useState<XiaoXunCandidate | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerQuery, setPickerQuery] = useState('');
  const [pickerPage, setPickerPage] = useState(1);
  const [pickerSelectedIds, setPickerSelectedIds] = useState<string[]>([]);

  const pickerQueryResult = useQuery({
    queryKey: ['xiao-xun', 'talent-pool-picker', pickerQuery, pickerPage],
    queryFn: () => searchTalentResumes({ q: pickerQuery, page: pickerPage, page_size: 10 }),
    enabled: pickerOpen,
    placeholderData: keepPreviousData,
  });
  const unavailableIds = new Set([...existingResumeIds, ...importedResumeIds]);
  const pickerRows = pickerQueryResult.data?.results ?? pickerQueryResult.data?.items ?? [];

  function openPicker() {
    setPickerSelectedIds([]);
    setPickerPage(1);
    setPickerOpen(true);
  }

  function closePicker() {
    setPickerOpen(false);
    setPickerSelectedIds([]);
  }

  async function importFromPicker() {
    if (pickerSelectedIds.length === 0 || importPending) return;
    await onImportIds(pickerSelectedIds);
    closePicker();
  }

  const recommendationColumns: DataTableColumn<TalentRecommendation>[] = [
    {
      title: '选择',
      key: 'select',
      width: 64,
      render: (_, recommendation) => {
        const id = recommendationId(recommendation);
        const unavailable = unavailableIds.has(id);
        return (
          <Checkbox
            aria-label={`选择 ${displayValue(recommendation.name)}`}
            checked={selectedResumeIds.includes(id)}
            disabled={!id || unavailable}
            onChange={(event) => onToggleResume(id, event.target.checked)}
          />
        );
      },
    },
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
      role: 'identity',
      render: (name: string | undefined) => <strong>{displayValue(name)}</strong>,
    },
    {
      title: '当前职位',
      key: 'title',
      render: (_, recommendation) => displayValue(recommendation.title),
    },
    {
      title: '公司',
      key: 'company',
      render: (_, recommendation) => displayValue(recommendation.company || recommendation.currentCompany),
    },
    {
      title: '匹配依据',
      key: 'matchedTerms',
      render: (_, recommendation) => (
        <div className="xun-table-tags">
          <Tag color={recommendation.relevanceLevel === 'high' ? 'success' : 'processing'}>
            {LEVEL_LABELS[recommendation.relevanceLevel || 'explore']}
          </Tag>
          <span>{recommendation.matchedTerms?.slice(0, 3).join('、') || '岗位相关经历'}</span>
          {recommendation.missingRequired?.length ? (
            <Tag color="warning" title={`以下岗位必选信息缺失：${recommendation.missingRequired.join('、')}`}>
              信息待确认
            </Tag>
          ) : null}
        </div>
      ),
    },
    {
      title: '操作',
      key: 'actions',
      role: 'actions',
      width: 96,
      render: (_, recommendation) => (
        <DataTableAction onClick={() => setDetailCandidate(recommendation)}>预览简历</DataTableAction>
      ),
    },
  ];

  const pickerColumns: DataTableColumn<TalentResume>[] = [
    { title: '姓名', dataIndex: 'name', key: 'name', role: 'identity', render: (name: string | undefined) => <strong>{displayValue(name)}</strong> },
    { title: '当前职位', dataIndex: 'title', key: 'title', render: (title: string | undefined) => displayValue(title) },
    { title: '公司', dataIndex: 'current_company', key: 'current_company', render: (company: string | undefined) => displayValue(company) },
    { title: '技能', key: 'skills', render: (_, resume) => resume.skills?.slice(0, 3).join('、') || '—' },
    {
      title: '状态',
      key: 'status',
      render: (_, resume) => unavailableIds.has(resume.id) ? <Tag>已在当前岗位</Tag> : null,
    },
  ];

  return (
    <Card
      className="xun-card xun-pool-card"
      title="人才库匹配"
      extra={(
        <div className="xun-pool-actions">
          <Button onClick={openPicker}>从人才库添加</Button>
          <Button type="primary" onClick={onUpload}>上传新简历</Button>
        </div>
      )}
    >
      <div className="xun-pool-summary">
        <strong>人才库已有 {total ?? '—'} 份简历</strong>
        <span>{jdReady ? '已按岗位族和岗位关键词自动匹配。' : '完成 JD 后将自动匹配相似岗位简历。'}</span>
      </div>
      {jdReady && hardGateFiltered > 0 ? (
        <div className="xun-pool-summary">
          <Tag color="default">已按硬性门槛过滤 {hardGateFiltered} 份简历</Tag>
          <span>年限、学历等必选条件与 JD 不符的简历不进匹配列表，条件不全的会标注"信息待确认"。</span>
        </div>
      ) : null}
      {!jdReady ? (
        <Alert
          className="xun-pool-alert"
          type="warning"
          showIcon
          message="当前岗位尚未完成 JD"
          description="仍可从人才库手动添加简历，完成 JD 后会自动生成匹配结果。"
        />
      ) : null}
      {jdReady && total === 0 ? (
        <Alert
          className="xun-pool-alert"
          type="info"
          showIcon
          message="人才库暂无简历"
          description="可以点击上方“上传新简历”导入新的候选人。"
        />
      ) : null}
      {error ? <Alert className="xun-pool-alert" type="error" showIcon message="人才库匹配失败" description={error} /> : null}
      <div className="xun-match-results" role="region" aria-label="人才库匹配">
        <div className="xun-result-heading">
          <strong>匹配到的简历 {totalRecommendations > 0 ? `· ${totalRecommendations} 份` : ''}</strong>
        </div>
        <DataTable<TalentRecommendation>
          tableId="xiao-xun-recommendations"
          showSearch={false}
          showColumnSettings={false}
          showResultCount={false}
          className="xun-recommendation-table"
          rowKey={(recommendation) => recommendationId(recommendation)}
          loading={loading}
          columns={recommendationColumns}
          dataSource={recommendations}
          pagination={{ pageSize: 10, showSizeChanger: false }}
          locale={{ emptyText: jdReady ? '当前岗位暂无匹配简历' : '完成 JD 后自动匹配' }}
          scroll={{ x: 720 }}
        />
        <div className="xun-batch-import-bar">
          <Button type="primary" disabled={selectedResumeIds.length === 0 || importPending} loading={importPending} onClick={onImport}>
            批量导入{selectedResumeIds.length > 0 ? ` (${selectedResumeIds.length})` : ''}
          </Button>
        </div>
        {selectedResumeIds.length > 0 ? (
          <div className="xun-selected-candidates" role="region" aria-label="已选择候选人">
            <div className="xun-selected-candidates__heading">
              <strong>已选择候选人</strong>
            </div>
            <DataTable<TalentRecommendation>
              tableId="xiao-xun-selected"
              compact
              className="xun-selected-candidates-table"
              rowKey={(recommendation) => recommendationId(recommendation)}
              size="small"
              pagination={false}
              scroll={{ x: 560 }}
              columns={[
                {
                  title: '姓名',
                  key: 'name',
                  role: 'identity',
                  render: (_, recommendation) => <strong>{displayValue(recommendation.name)}</strong>,
                },
                {
                  title: '当前职位',
                  key: 'title',
                  render: (_, recommendation) => displayValue(recommendation.title),
                },
                {
                  title: '公司',
                  key: 'company',
                  render: (_, recommendation) => displayValue(recommendation.company || recommendation.currentCompany),
                },
                {
                  title: '操作',
                  key: 'actions',
                  role: 'actions',
                  width: 150,
                  render: (_, recommendation) => (
                    <Space size={4}>
                      <DataTableAction onClick={() => setDetailCandidate(recommendation)}>预览简历</DataTableAction>
                      <DataTableAction tone="danger" onClick={() => onToggleResume(recommendationId(recommendation), false)}>
                        移除
                      </DataTableAction>
                    </Space>
                  ),
                },
              ]}
              dataSource={selectedResumeIds
                .map((resumeId) => recommendations.find((item) => recommendationId(item) === resumeId))
                .filter((recommendation): recommendation is TalentRecommendation => Boolean(recommendation))}
            />
          </div>
        ) : null}
      </div>
      <Modal
        open={pickerOpen}
        title="选择人才库简历"
        width={900}
        onCancel={closePicker}
        destroyOnHidden
        footer={(
          <>
            <Button onClick={closePicker}>取消</Button>
            <Button type="primary" loading={importPending} disabled={pickerSelectedIds.length === 0} onClick={() => void importFromPicker()}>
              添加到当前岗位{pickerSelectedIds.length > 0 ? ` (${pickerSelectedIds.length})` : ''}
            </Button>
          </>
        )}
      >
        <ListToolbar
          search={(
            <ListSearch
              className="xun-pool-picker-search"
              placeholder="搜索姓名、职位、公司或技能"
              value={pickerSearch}
              onChange={(value) => setPickerSearch(value)}
              onQueryChange={(value) => {
                setPickerQuery(value.trim());
                setPickerPage(1);
              }}
            />
          )}
        />
        {pickerQueryResult.isError ? <Alert className="xun-pool-alert" type="error" showIcon message="人才库加载失败" description="请稍后重试。" /> : null}
        <DataTable<TalentResume>
          tableId="xiao-xun-picker"
          mode="remote"
          showSearch={false}
          showColumnSettings={false}
          showResultCount={false}
          rowKey="id"
          rowSelection={{
            selectedRowKeys: pickerSelectedIds,
            preserveSelectedRowKeys: true,
            onChange: (keys) => setPickerSelectedIds(keys.map(String)),
            getCheckboxProps: (resume) => ({ disabled: unavailableIds.has(resume.id) }),
          }}
          loading={pickerQueryResult.isLoading}
          columns={pickerColumns}
          dataSource={pickerRows}
          total={pickerQueryResult.data?.total ?? 0}
          pagination={{ current: pickerPage, pageSize: 10, showSizeChanger: false, onChange: (page) => setPickerPage(page) }}
          locale={{ emptyText: '人才库暂无可选简历' }}
        />
      </Modal>
      <ResumePreviewModal
        pipelineId={pipelineId}
        resumeId={detailCandidate ? recommendationId(detailCandidate) || undefined : undefined}
        candidate={detailCandidate}
        onClose={() => setDetailCandidate(null)}
      />
    </Card>
  );
}