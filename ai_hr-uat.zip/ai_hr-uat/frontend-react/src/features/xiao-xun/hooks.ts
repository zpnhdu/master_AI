import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { ApiError } from "../pipelines/api";
import {
  acceptTalentRecommendations,
  fetchTalentRecommendations,
  fetchXiaoXunPipeline,
  parseResumes,
  uploadResumes,
  type RecommendationQuery,
} from "./api";

export const MAX_RESUME_FILES = 50;
export const MAX_RESUME_FILE_SIZE_BYTES = 10 * 1024 * 1024;

const SUPPORTED_RESUME_EXTENSIONS = new Set(["pdf", "doc", "docx", "md"]);

export type ResumeFileValidationResult = {
  validFiles: File[];
  errors: string[];
};

export function validateResumeFiles(files: FileList | readonly File[]): ResumeFileValidationResult {
  const validFiles: File[] = [];
  const errors: string[] = [];

  for (const file of Array.from(files)) {
    if (validFiles.length >= MAX_RESUME_FILES) {
      errors.push(`最多上传 ${MAX_RESUME_FILES} 份简历，已忽略其余文件`);
      break;
    }

    const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!SUPPORTED_RESUME_EXTENSIONS.has(extension)) {
      errors.push(`${file.name}：仅支持 PDF、DOC、DOCX 和 Markdown（.md）格式`);
      continue;
    }

    if (file.size > MAX_RESUME_FILE_SIZE_BYTES) {
      errors.push(`${file.name}：单个文件不能超过 10MB`);
      continue;
    }

    validFiles.push(file);
  }

  return { validFiles, errors };
}

type NormalizedRecommendationQuery = {
  limit: number;
  scope: NonNullable<RecommendationQuery["scope"]>;
  keywords: string[];
  required: string[];
  excluded: string[];
  hardGates: boolean;
};

function normalizeRecommendationQuery(query: RecommendationQuery = {}): NormalizedRecommendationQuery {
  return {
    limit: query.limit ?? 20,
    scope: query.scope ?? "balanced",
    keywords: query.keywords?.filter(Boolean) ?? [],
    required: query.required?.filter(Boolean) ?? [],
    excluded: query.excluded?.filter(Boolean) ?? [],
    hardGates: Boolean(query.hardGates),
  };
}

const recommendationQueryBase = (pipelineId: string) => ["xiao-xun", "recommendations", pipelineId] as const;

export const xiaoXunQueryKeys = {
  pipeline: (pipelineId: string) => ["xiao-xun", "pipeline", pipelineId] as const,
  recommendations: (pipelineId: string, query?: RecommendationQuery) => {
    const base = recommendationQueryBase(pipelineId);
    return query ? ([...base, normalizeRecommendationQuery(query)] as const) : base;
  },
};

function invalidateXiaoXunQueries(queryClient: ReturnType<typeof useQueryClient>, pipelineId: string) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: xiaoXunQueryKeys.pipeline(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: ["pipeline-detail", pipelineId] }),
    queryClient.invalidateQueries({ queryKey: ["pipeline-candidates", pipelineId] }),
    queryClient.invalidateQueries({ queryKey: ["xiao-xun", "raw-files", pipelineId] }),
    queryClient.invalidateQueries({ queryKey: xiaoXunQueryKeys.recommendations(pipelineId) }),
  ]);
}

export function useXiaoXunPipelineQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoXunQueryKeys.pipeline(pipelineId),
    queryFn: () => fetchXiaoXunPipeline(pipelineId),
    enabled: Boolean(pipelineId),
    staleTime: 5 * 1000,
  });
}

export function useUploadResumesMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  const pendingRef = useRef(false);

  return useMutation({
    mutationFn: async (files: File[]) => {
      if (pendingRef.current) {
        throw new ApiError("上传正在进行中，请勿重复提交");
      }
      pendingRef.current = true;
      try {
        const upload = await uploadResumes(pipelineId, files);
        const resumeIds = upload.files.map((item) => item.resumeId).filter((id): id is string => Boolean(id));
        const accepted = resumeIds.length ? await acceptTalentRecommendations(pipelineId, resumeIds) : null;
        return { upload, parse: null, accepted };
      } finally {
        pendingRef.current = false;
      }
    },
    onSettled: () => invalidateXiaoXunQueries(queryClient, pipelineId),
  });
}

export function useParseResumesMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  const pendingRef = useRef(false);

  return useMutation({
    mutationFn: async () => {
      if (pendingRef.current) {
        throw new ApiError("解析正在进行中，请勿重复提交");
      }
      pendingRef.current = true;
      try {
        return await parseResumes(pipelineId);
      } finally {
        pendingRef.current = false;
      }
    },
    onSettled: () => invalidateXiaoXunQueries(queryClient, pipelineId),
  });
}

export function useTalentRecommendationsQuery(pipelineId: string, query: RecommendationQuery = {}, enabled = true) {
  const normalizedQuery = normalizeRecommendationQuery(query);

  return useQuery({
    queryKey: xiaoXunQueryKeys.recommendations(pipelineId, normalizedQuery),
    queryFn: () => fetchTalentRecommendations(pipelineId, normalizedQuery),
    enabled: Boolean(pipelineId) && enabled,
    staleTime: 10 * 1000,
  });
}

export function useAcceptTalentRecommendationsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  const pendingRef = useRef(false);

  return useMutation({
    mutationFn: async (resumeIds: string[]) => {
      if (pendingRef.current) {
        throw new ApiError("导入正在进行中，请勿重复提交");
      }
      pendingRef.current = true;
      try {
        return await acceptTalentRecommendations(pipelineId, resumeIds);
      } finally {
        pendingRef.current = false;
      }
    },
    onSuccess: () => invalidateXiaoXunQueries(queryClient, pipelineId),
  });
}

export type XiaoXunCondition = {
  value: string;
  source: "jd" | "manual";
};

export type XiaoXunResultFilters = {
  level: "all" | "high" | "possible" | "explore";
  location: string;
  source: "all" | "email" | "upload";
  freshnessDays: number | null;
};

const DEFAULT_RESULT_FILTERS: XiaoXunResultFilters = {
  level: "all",
  location: "",
  source: "all",
  freshnessDays: null,
};

export function useXiaoXunInteractionState(jdConditions: string[] = []) {
  const [conditions, setConditions] = useState<XiaoXunCondition[]>(() =>
    jdConditions.filter(Boolean).map((value) => ({ value, source: "jd" as const })),
  );
  const [removedConditions, setRemovedConditions] = useState<string[]>([]);
  const [selectedResumeIds, setSelectedResumeIds] = useState<string[]>([]);
  const [scope, setScope] = useState<NonNullable<RecommendationQuery["scope"]>>("balanced");
  const [resultFilters, setResultFilters] = useState<XiaoXunResultFilters>(DEFAULT_RESULT_FILTERS);

  useEffect(() => {
    const normalizedConditions = jdConditions.filter(Boolean);
    if (normalizedConditions.length === 0) return;
    setConditions((current) => {
      const currentValues = new Set(current.map((condition) => condition.value));
      const additions = normalizedConditions
        .filter((value) => !currentValues.has(value))
        .map((value) => ({ value, source: "jd" as const }));
      return additions.length > 0 ? [...current, ...additions] : current;
    });
  }, [jdConditions]);

  const recommendationQuery = useMemo<RecommendationQuery>(
    () => ({
      limit: 50,
      scope,
      keywords: conditions
        .filter((condition) => condition.source === "jd" && !removedConditions.includes(condition.value))
        .map(({ value }) => value),
      required: conditions
        .filter((condition) => condition.source === "manual" && !removedConditions.includes(condition.value))
        .map(({ value }) => value),
      excluded: removedConditions,
    }),
    [conditions, removedConditions, scope],
  );

  const addManualCondition = useCallback((value: string) => {
    const normalized = value.trim();
    if (!normalized) return;
    setConditions((current) =>
      current.some((condition) => condition.value === normalized)
        ? current
        : [...current, { value: normalized, source: "manual" }],
    );
    setRemovedConditions((current) => current.filter((condition) => condition !== normalized));
  }, []);

  const removeCondition = useCallback((value: string) => {
    setConditions((current) => current.filter((condition) => condition.value !== value));
    setRemovedConditions((current) => (current.includes(value) ? current : [...current, value]));
  }, []);

  const toggleResume = useCallback((resumeId: string, selected: boolean) => {
    if (!resumeId) return;
    setSelectedResumeIds((current) => {
      if (selected && !current.includes(resumeId)) return [...current, resumeId];
      return selected ? current : current.filter((id) => id !== resumeId);
    });
  }, []);

  const selectVisible = useCallback((resumeIds: string[]) => {
    setSelectedResumeIds((current) => Array.from(new Set([...current, ...resumeIds.filter(Boolean)])));
  }, []);

  const clearSelection = useCallback(() => setSelectedResumeIds([]), []);

  return {
    conditions,
    removedConditions,
    recommendationQuery,
    resultFilters,
    selectedResumeIds,
    scope,
    addManualCondition,
    clearSelection,
    removeCondition,
    selectVisible,
    setResultFilters,
    setScope,
    toggleResume,
  };
}
