import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, renderHook, waitFor } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { acceptTalentRecommendations, fetchTalentRecommendations, parseResumes, uploadResumes } from "./api";
import {
  MAX_RESUME_FILE_SIZE_BYTES,
  MAX_RESUME_FILES,
  useAcceptTalentRecommendationsMutation,
  useParseResumesMutation,
  useTalentRecommendationsQuery,
  useXiaoXunInteractionState,
  useUploadResumesMutation,
  validateResumeFiles,
  xiaoXunQueryKeys,
} from "./hooks";

vi.mock("./api", () => ({
  acceptTalentRecommendations: vi.fn(),
  fetchTalentRecommendations: vi.fn(),
  parseResumes: vi.fn(),
  uploadResumes: vi.fn(),
}));

afterEach(() => {
  vi.clearAllMocks();
});

function createQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });
}

function createQueryWrapper(queryClient: QueryClient) {
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
}

function createResumeFile(name: string, size = 1) {
  return new File([new Uint8Array(size)], name, { type: "application/pdf" });
}

describe("xiao-xun hooks", () => {
  it("validates supported resume formats and returns displayable errors", () => {
    const files = [
      createResumeFile("resume.pdf"),
      createResumeFile("resume.doc"),
      createResumeFile("resume.docx"),
      createResumeFile("resume.md"),
      createResumeFile("resume.exe"),
      createResumeFile("large.pdf", MAX_RESUME_FILE_SIZE_BYTES + 1),
    ];

    const result = validateResumeFiles(files);

    expect(result.validFiles.map((file) => file.name)).toEqual([
      "resume.pdf",
      "resume.doc",
      "resume.docx",
      "resume.md",
    ]);
    expect(result.errors).toEqual([
      "resume.exe：仅支持 PDF、DOC、DOCX 和 Markdown（.md）格式",
      "large.pdf：单个文件不能超过 10MB",
    ]);
  });

  it("limits the valid file collection to 50 resumes", () => {
    const files = Array.from({ length: MAX_RESUME_FILES + 1 }, (_, index) => createResumeFile(`${index + 1}.pdf`));

    const result = validateResumeFiles(files);

    expect(result.validFiles).toHaveLength(MAX_RESUME_FILES);
    expect(result.errors).toEqual(["最多上传 50 份简历，已忽略其余文件"]);
  });

  it("uploads files to the talent pool and accepts them into the pipeline", async () => {
    const queryClient = createQueryClient();
    const files = [createResumeFile("resume.pdf")];
    vi.mocked(uploadResumes).mockResolvedValue({
      success: true,
      uploaded: 1,
      total: 1,
      files: [{ name: "resume.pdf", status: "success", resumeId: "resume-1" }],
    });
    vi.mocked(acceptTalentRecommendations).mockResolvedValue({
      accepted: 1,
      candidates: [],
    });

    const { result } = renderHook(() => useUploadResumesMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    await result.current.mutateAsync(files);

    expect(uploadResumes).toHaveBeenCalledWith("pipeline-1", files);
    expect(acceptTalentRecommendations).toHaveBeenCalledWith("pipeline-1", ["resume-1"]);
    expect(parseResumes).not.toHaveBeenCalled();
  });

  it("parses resumes and refreshes pipeline and recommendation queries", async () => {
    const queryClient = createQueryClient();
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);
    vi.mocked(parseResumes).mockResolvedValue({
      success: true,
      parsed: 1,
      total: 1,
      fromPool: 0,
      duplicates: 0,
      missingContactCount: 0,
      manualContactCount: 0,
      message: "解析完成",
      results: [],
    });

    const { result } = renderHook(() => useParseResumesMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    await result.current.mutateAsync();

    expect(parseResumes).toHaveBeenCalledWith("pipeline-1");
    expect(invalidateQueries).toHaveBeenCalledWith({
      queryKey: xiaoXunQueryKeys.pipeline("pipeline-1"),
    });
    expect(invalidateQueries).toHaveBeenCalledWith({
      queryKey: xiaoXunQueryKeys.recommendations("pipeline-1"),
    });
  });

  it("includes recommendation scope and criteria in the query key", async () => {
    const queryClient = createQueryClient();
    const query = {
      limit: 50,
      scope: "precise" as const,
      keywords: ["React"],
      required: ["三年经验"],
      excluded: ["实习"],
    };
    vi.mocked(fetchTalentRecommendations).mockResolvedValue({
      results: [],
      total: 0,
      poolTotal: 0,
      pipelineId: "pipeline-1",
      reason: "",
      scope: "precise",
      criteria: {},
      levelCounts: {},
      hardGateFiltered: 0,
    });

    const { result } = renderHook(() => useTalentRecommendationsQuery("pipeline-1", query), {
      wrapper: createQueryWrapper(queryClient),
    });

    await waitFor(() => expect(result.current.isSuccess).toBe(true));

    expect(fetchTalentRecommendations).toHaveBeenCalledWith("pipeline-1", { ...query, hardGates: false });
    expect(queryClient.getQueryData(xiaoXunQueryKeys.recommendations("pipeline-1", query))).toEqual({
      results: [],
      total: 0,
      poolTotal: 0,
      pipelineId: "pipeline-1",
      reason: "",
      scope: "precise",
      criteria: {},
      levelCounts: {},
      hardGateFiltered: 0,
    });
  });

  it("does not fetch recommendations without a pipeline id", async () => {
    const queryClient = createQueryClient();

    renderHook(
      () =>
        useTalentRecommendationsQuery("", {
          scope: "balanced",
          keywords: ["React"],
        }),
      { wrapper: createQueryWrapper(queryClient) },
    );

    await Promise.resolve();

    expect(fetchTalentRecommendations).not.toHaveBeenCalled();
  });

  it("imports selected recommendations and invalidates related queries", async () => {
    const queryClient = createQueryClient();
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);
    vi.mocked(acceptTalentRecommendations).mockResolvedValue({
      accepted: 2,
      candidates: [],
    });

    const { result } = renderHook(() => useAcceptTalentRecommendationsMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    await result.current.mutateAsync(["resume-1", "resume-2"]);

    expect(acceptTalentRecommendations).toHaveBeenCalledWith("pipeline-1", ["resume-1", "resume-2"]);
    expect(invalidateQueries).toHaveBeenCalledWith({
      queryKey: xiaoXunQueryKeys.pipeline("pipeline-1"),
    });
    expect(invalidateQueries).toHaveBeenCalledWith({
      queryKey: xiaoXunQueryKeys.recommendations("pipeline-1"),
    });
  });

  it("exposes pending state while batch import is in flight", async () => {
    const queryClient = createQueryClient();
    let resolveImport!: (value: { accepted: number; candidates: [] }) => void;
    vi.mocked(acceptTalentRecommendations).mockReturnValue(
      new Promise((resolve) => {
        resolveImport = resolve;
      }),
    );

    const { result } = renderHook(() => useAcceptTalentRecommendationsMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    let importPromise!: Promise<unknown>;
    await act(async () => {
      importPromise = result.current.mutateAsync(["resume-1"]);
    });
    await waitFor(() => expect(result.current.isPending).toBe(true));
    expect(acceptTalentRecommendations).toHaveBeenCalledTimes(1);

    resolveImport({ accepted: 1, candidates: [] });
    await importPromise;
    await waitFor(() => expect(result.current.isPending).toBe(false));
  });

  it("rejects a duplicate batch import while the first request is pending", async () => {
    const queryClient = createQueryClient();
    let resolveImport!: (value: { accepted: number; candidates: [] }) => void;
    vi.mocked(acceptTalentRecommendations).mockReturnValue(
      new Promise((resolve) => {
        resolveImport = resolve;
      }),
    );

    const { result } = renderHook(() => useAcceptTalentRecommendationsMutation("pipeline-1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    const firstImport = result.current.mutateAsync(["resume-1"]);
    await waitFor(() => expect(result.current.isPending).toBe(true));

    await expect(result.current.mutateAsync(["resume-2"])).rejects.toThrow("导入正在进行中");
    expect(acceptTalentRecommendations).toHaveBeenCalledTimes(1);

    resolveImport({ accepted: 1, candidates: [] });
    await firstImport;
  });

  it("manages recommendation conditions, excluded values, and selected ids", () => {
    const { result } = renderHook(() => useXiaoXunInteractionState(["React"]));

    expect(result.current.recommendationQuery.keywords).toEqual(["React"]);

    act(() => {
      result.current.addManualCondition("三年经验");
      result.current.removeCondition("React");
      result.current.toggleResume("resume-1", true);
      result.current.toggleResume("resume-2", true);
    });

    expect(result.current.recommendationQuery).toMatchObject({
      keywords: [],
      required: ["三年经验"],
      excluded: ["React"],
    });
    expect(result.current.selectedResumeIds).toEqual(["resume-1", "resume-2"]);

    act(() => result.current.selectVisible(["resume-2", "resume-3"]));
    expect(result.current.selectedResumeIds).toEqual(["resume-1", "resume-2", "resume-3"]);

    act(() => result.current.clearSelection());
    expect(result.current.selectedResumeIds).toEqual([]);
  });
});
