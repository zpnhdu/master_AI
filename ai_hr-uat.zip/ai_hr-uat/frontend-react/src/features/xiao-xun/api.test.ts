import { afterEach, describe, expect, it, vi } from "vitest";

import { ApiError } from "../pipelines/api";
import {
  acceptTalentRecommendations,
  fetchRawResumeFiles,
  fetchTalentPoolSummary,
  fetchXiaoXunPipeline,
  fetchTalentRecommendations,
  normalizeXiaoXunPipeline,
  parseResumes,
  passXiaoXunArtifact,
  uploadResumes,
} from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

function mockJsonResponse(payload: unknown, init: { ok?: boolean; status?: number } = {}) {
  return {
    ok: init.ok ?? true,
    status: init.status ?? 200,
    json: async () => payload,
  };
}

describe("xiao-xun api", () => {
  it("loads the pipeline detail used by the workbench", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        mockJsonResponse({
          id: "pipeline-1",
          role: "店长",
          candidates: [{ id: "candidate-1", name: "候选人A", source: "local_import" }],
          stages: [{ stage_id: "crawl", status: "done", output: { resume_count: 1 } }],
        }),
      ),
    );

    await expect(fetchXiaoXunPipeline("pipeline-1")).resolves.toMatchObject({
      id: "pipeline-1",
      role: "店长",
      candidates: [{ id: "candidate-1", name: "候选人A" }],
      crawlStats: { uploaded: 1, parsed: 1 },
    });
  });

  it("normalizes pipeline crawl output and candidate fields", () => {
    const pipeline = normalizeXiaoXunPipeline({
      id: "pipeline-1",
      role: "店长",
      stages: [
        {
          stage_id: "crawl",
          status: "done",
          output: JSON.stringify({
            resume_count: "6",
            parsed_count: 4,
            failed_count: "1",
            pool_import_count: 2,
            file_upload_count: 4,
            formats: { pdf: 3, docx: "1", invalid: "x" },
          }),
        },
      ],
      candidates: [
        { id: 1, name: "候选人A", source: "talent_pool:email", resume_id: "resume-1" },
        { name: "候选人B", source: "file:resume.pdf" },
        { name: "无效候选人", source: null },
      ],
    });

    expect(pipeline).toMatchObject({
      id: "pipeline-1",
      role: "店长",
      crawlStats: {
        uploaded: 6,
        parsed: 4,
        failed: 1,
        scanned: 1,
        poolImported: 2,
        fileUploaded: 4,
        formats: { PDF: 3, DOCX: 1 },
      },
    });
    expect(pipeline.candidates[0]).toMatchObject({ id: "1", name: "候选人A" });
    expect(pipeline.candidates[2].name).toBe("无效候选人");
  });

  it("uploads files as repeated files FormData fields", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        count: 2,
        results: [
          { id: "resume-a", filename: "a.pdf" },
          { filename: "b.exe", skipped: true, reason: "validation_failed" },
        ],
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const firstFile = new File(["resume-a"], "a.pdf", { type: "application/pdf" });
    const secondFile = new File(["resume-b"], "b.exe", { type: "application/octet-stream" });
    const response = await uploadResumes("pipeline/1", [firstFile, secondFile]);

    expect(response).toMatchObject({ uploaded: 1, total: 2 });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/talent-pool/upload?pipeline_id=pipeline%2F1",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
    const request = fetchMock.mock.calls[0][1] as RequestInit;
    expect(request.headers).toBeUndefined();
    expect(request.body).toBeInstanceOf(FormData);
    expect((request.body as FormData).getAll("files")).toEqual([firstFile, secondFile]);
  });

  it("normalizes parse results including duplicates and contact warnings", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        mockJsonResponse({
          success: true,
          parsed: "1",
          total: 2,
          from_pool: 1,
          duplicates: 1,
          missing_contact_count: 1,
          manual_contact_count: 0,
          results: [
            { file: "a.pdf", status: "success", data: { id: 3, name: "候选人A" } },
            { file: "b.pdf", status: "duplicate", error: "重复" },
          ],
        }),
      ),
    );

    await expect(parseResumes("pipeline-1")).resolves.toMatchObject({
      parsed: 1,
      total: 2,
      fromPool: 1,
      duplicates: 1,
      missingContactCount: 1,
      results: [
        { file: "a.pdf", status: "success", data: { id: "3", name: "候选人A" } },
        { file: "b.pdf", status: "duplicate", error: "重复" },
      ],
    });
  });

  it("reports malformed successful responses instead of showing empty data", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: vi.fn().mockRejectedValue(new SyntaxError("invalid json")),
      }),
    );

    const error = await parseResumes("pipeline-1").catch((reason: unknown) => reason);

    expect(error).toBeInstanceOf(ApiError);
    expect((error as ApiError).message).toContain("响应格式无效");
  });

  it("builds talent-pool recommendation query parameters", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        results: [{ resume_id: "resume-1", name: "候选人A", relevance_level: "high" }],
        total: 1,
        pool_total: 9,
        pipeline_id: "pipeline-1",
        reason: "ok",
        scope: "precise",
        criteria: { role: "店长" },
        level_counts: { high: 1, possible: 0, explore: 0 },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      fetchTalentRecommendations("pipeline-1", {
        limit: 50,
        scope: "precise",
        keywords: ["门店", "招聘"],
        required: ["三年经验"],
        excluded: ["实习"],
      }),
    ).resolves.toMatchObject({
      total: 1,
      poolTotal: 9,
      results: [{ resumeId: "resume-1", name: "候选人A" }],
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/talent-pool/recommend/pipeline-1?limit=50&scope=precise&keywords=%E9%97%A8%E5%BA%97%2C%E6%8B%9B%E8%81%98&required=%E4%B8%89%E5%B9%B4%E7%BB%8F%E9%AA%8C&excluded=%E5%AE%9E%E4%B9%A0",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("includes hard-gate filtering and normalizes gated fields", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        results: [
          {
            resume_id: "resume-1",
            name: "候选人A",
            years_experience: 0,
            missing_required: ["工作年限", "学历"],
          },
        ],
        total: 1,
        pool_total: 9,
        pipeline_id: "pipeline-1",
        reason: "ok",
        scope: "broad",
        criteria: { role: "店长" },
        level_counts: { high: 0, possible: 1, explore: 0 },
        hard_gate_filtered: 3,
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const result = await fetchTalentRecommendations("pipeline-1", {
      limit: 50,
      scope: "broad",
      hardGates: true,
    });

    expect(result.hardGateFiltered).toBe(3);
    expect(result.results[0].missingRequired).toEqual(["工作年限", "学历"]);
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/talent-pool/recommend/pipeline-1?limit=50&scope=broad&hard_gates=1",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("omits hard_gates from the query when filtering is not requested", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        results: [],
        total: 0,
        pool_total: 9,
        pipeline_id: "pipeline-1",
        reason: "no_match",
        scope: "balanced",
        criteria: {},
        level_counts: {},
        hard_gate_filtered: 0,
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await fetchTalentRecommendations("pipeline-1", { limit: 20, scope: "balanced" });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/talent-pool/recommend/pipeline-1?limit=20&scope=balanced",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("sends selected resume ids in the batch import request body", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      mockJsonResponse({
        accepted: "2",
        candidates: [{ id: "candidate-1", name: "候选人A" }],
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await expect(acceptTalentRecommendations("pipeline-1", ["resume-1", "resume-2"])).resolves.toMatchObject({
      accepted: 2,
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/talent-pool/recommend/pipeline-1/accept",
      expect.objectContaining({
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resume_ids: ["resume-1", "resume-2"] }),
      }),
    );
  });

  it("normalizes raw files and talent-pool summaries", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(mockJsonResponse({ files: [{ name: "a.pdf", ext: ".pdf", size_kb: "12.5" }], count: 1 }))
      .mockResolvedValueOnce(mockJsonResponse({ total: "8" }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchRawResumeFiles("pipeline-1")).resolves.toEqual({
      files: [{ name: "a.pdf", extension: ".pdf", sizeKb: 12.5 }],
      count: 1,
    });
    await expect(fetchTalentPoolSummary()).resolves.toEqual({ total: 8 });
  });

  it("passes the current artifact downstream", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        mockJsonResponse({ success: true, from_agent: "xiao_xun", to_agent: "next", to_name: "小筛" }),
      );
    vi.stubGlobal("fetch", fetchMock);

    await expect(passXiaoXunArtifact("pipeline-1", "next", { candidates: ["candidate-1"] })).resolves.toMatchObject({
      toName: "小筛",
    });
    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "/api/pipelines/pipeline-1/pass-artifact",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({
          from_agent: "xiao_xun",
          to_agent: "next",
          artifacts: { candidates: ["candidate-1"] },
        }),
      }),
    );
  });
});
