import { Alert, Button, Empty, Modal, Pagination, Popconfirm, Spin, Typography, Upload, message } from 'antd';
import { EyeOutlined } from '@ant-design/icons';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';

import { getErrorMessage } from '../../shared/errors';
import {
  deleteMaterial,
  fetchMaterialLibrary,
  MATERIAL_LIBRARY_QUERY_KEY,
  uploadMaterialFiles,
  type MaterialKind,
  type MaterialLibraryEntry,
} from './api';

const MATERIAL_TAB_CONFIG: Record<MaterialKind, { title: string; description: string }> = {
  backgrounds: {
    title: '背景图',
    description: '用于招聘海报的底层背景，建议上传竖版高清图片。',
  },
  elements: {
    title: '装饰元素',
    description: '可组合到海报中的贴纸、图标和品牌装饰。',
  },
};

const DEFAULT_PAGE_SIZE = 10;

export function MaterialLibrary({
  hideHeader,
  activeTab = 'backgrounds',
}: {
  hideHeader?: boolean;
  activeTab?: MaterialKind;
}) {
  const queryClient = useQueryClient();
  const libraryQuery = useQuery({
    queryKey: MATERIAL_LIBRARY_QUERY_KEY,
    queryFn: fetchMaterialLibrary,
    retry: false,
  });
  const uploadMutation = useMutation({
    mutationFn: ({ kind, files }: { kind: MaterialKind; files: File[] }) => uploadMaterialFiles(kind, files),
    onSuccess: async (result) => {
      const uploadedCount = result.uploaded?.length ?? 0;
      const skipped = result.skipped ?? [];
      if (skipped.length) {
        message.info(`部分成功：上传 ${uploadedCount} 个，跳过 ${skipped.length} 个（${skipped.join('、')}）`);
      } else {
        message.success(`成功上传 ${uploadedCount} 个素材`);
      }
      await queryClient.invalidateQueries({ queryKey: MATERIAL_LIBRARY_QUERY_KEY });
    },
  });
  const deleteMutation = useMutation({
    mutationFn: ({ kind, entryId }: { kind: MaterialKind; entryId: string }) => deleteMaterial(kind, entryId),
    onSuccess: async () => {
      message.success('素材已删除');
      await queryClient.invalidateQueries({ queryKey: MATERIAL_LIBRARY_QUERY_KEY });
    },
  });

  if (libraryQuery.isPending) {
    return (
      <div className="material-library__state">
        <Spin size="large" description="加载中" />
      </div>
    );
  }

  if (libraryQuery.isError) {
    return (
      <div className="material-library__state">
        <Alert
          type="error"
          showIcon
          message="素材库加载失败"
          description={getErrorMessage(libraryQuery.error)}
          action={<Button onClick={() => void libraryQuery.refetch()}>重试</Button>}
        />
      </div>
    );
  }

  const config = MATERIAL_TAB_CONFIG[activeTab];
  const entries = (libraryQuery.data?.[activeTab] ?? []).filter((entry) => entry.url || entry.thumb_url);

  return (
    <div className="material-library">
      {!hideHeader && (
        <header className="material-library__header">
          <Button onClick={() => void libraryQuery.refetch()} loading={libraryQuery.isFetching}>
            刷新素材
          </Button>
        </header>
      )}

      <Spin spinning={libraryQuery.isFetching && !libraryQuery.isPending} description="加载中">
      <MaterialSection
        kind={activeTab}
        title={config.title}
        description={config.description}
        entries={entries}
        uploading={uploadMutation.isPending}
        deleting={deleteMutation.isPending}
        onUpload={(files) => uploadMutation.mutate({ kind: activeTab, files })}
        onDelete={(entryId) => deleteMutation.mutate({ kind: activeTab, entryId })}
      />
      </Spin>
    </div>
  );
}

function MaterialSection({
  kind,
  title,
  description,
  entries,
  uploading,
  deleting,
  onUpload,
  onDelete,
}: {
  kind: MaterialKind;
  title: string;
  description: string;
  entries: MaterialLibraryEntry[];
  uploading: boolean;
  deleting: boolean;
  onUpload: (files: File[]) => void;
  onDelete: (entryId: string) => void;
}) {
  const [previewEntry, setPreviewEntry] = useState<MaterialLibraryEntry | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);

  useEffect(() => {
    setPage(1);
  }, [kind]);

  const paginatedEntries = entries.slice((page - 1) * pageSize, page * pageSize);

  return (
    <section className="material-library__section" aria-labelledby={`material-section-${kind}`}>
      <div className="material-library__section-header">
        <div>
          <Typography.Title id={`material-section-${kind}`} level={2}>
            {title}
          </Typography.Title>
          <Typography.Text type="secondary">{description}</Typography.Text>
        </div>
        <Upload
          multiple
          beforeUpload={(file, fileList) => {
            if (fileList[0] === file) onUpload(fileList);
            return false;
          }}
          showUploadList={false}
          accept="image/png,image/jpeg,image/webp"
        >
          <Button type="primary" loading={uploading}>
            ＋ 上传{title}
          </Button>
        </Upload>
      </div>

      {paginatedEntries.length ? (
        <>
          <div className="material-library__grid">
            {paginatedEntries.map((entry) => {
            const entryId = String(entry.id ?? entry.file ?? '');
            const label = String(entry.label ?? entry.file ?? '未命名素材');
            return (
              <article key={entryId} className="material-library__item">
                <div
                  className="material-library__item-preview"
                  role="button"
                  tabIndex={0}
                  aria-label={`预览${label}`}
                  onClick={() => setPreviewEntry(entry)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setPreviewEntry(entry);
                    }
                  }}
                >
                  <img
                    src={String(entry.thumb_url ?? entry.url)}
                    alt={`${label}`}
                    loading="lazy"
                    decoding="async"
                  />
                  <span className="material-library__item-zoom">
                    <EyeOutlined />
                  </span>
                </div>
                <div className="material-library__item-footer">
                  <Typography.Text ellipsis={{ tooltip: label }}>{label}</Typography.Text>
                  <Popconfirm
                    title="删除这个素材？"
                    description="删除后将无法在小海中继续使用。"
                    okText="删除"
                    cancelText="取消"
                    okButtonProps={{ danger: true }}
                    onConfirm={() => onDelete(entryId)}
                  >
                    <Button type="text" danger disabled={deleting} aria-label={`删除${label}`}>
                      删除
                    </Button>
                  </Popconfirm>
                </div>
              </article>
            );
          })}
          </div>
          <div className="material-library__pagination">
            <Pagination
              current={page}
              pageSize={pageSize}
              total={entries.length}
              showSizeChanger
              pageSizeOptions={[10, 20, 30]}
              showTotal={(total) => `共 ${total} 个素材`}
              locale={{ items_per_page: '个/页' }}
              onChange={(nextPage, nextPageSize) => {
                setPage(nextPage);
                if (nextPageSize !== pageSize) setPageSize(nextPageSize);
              }}
            />
          </div>
        </>
      ) : (
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={`暂无${title}`} />
      )}

      <Modal
        open={previewEntry !== null}
        title={previewEntry ? String(previewEntry.label ?? previewEntry.file ?? '素材预览') : ''}
        footer={null}
        onCancel={() => setPreviewEntry(null)}
        width={720}
        centered
        destroyOnHidden
      >
        {previewEntry ? (
          <div className="material-library__preview">
            <img
              src={String(previewEntry.url ?? previewEntry.thumb_url)}
              alt={String(previewEntry.label ?? previewEntry.file ?? '素材')}
              className="material-library__preview-img"
            />
          </div>
        ) : null}
      </Modal>
    </section>
  );
}