import { requestJson } from "../agent-workbench/api";

export type MaterialKind = "backgrounds" | "elements";

export const MATERIAL_LIBRARY_QUERY_KEY = ["material-library"] as const;

export type MaterialLibraryEntry = {
  id?: string;
  label?: string;
  file?: string;
  url?: string;
  thumb_url?: string;
  placement_hint?: string;
  size_hint?: string;
  [key: string]: unknown;
};

export type MaterialLibraryData = Record<MaterialKind, MaterialLibraryEntry[]>;

export function fetchMaterialLibrary() {
  return requestJson<MaterialLibraryData>("/api/xiao-hai/elements", {}, "素材库加载失败");
}

export function uploadMaterialFiles(kind: MaterialKind, files: File[]) {
  const body = new FormData();
  files.forEach((file) => body.append("files", file, file.name));
  return requestJson<{ uploaded: MaterialLibraryEntry[]; skipped: string[] }>(
    `/api/xiao-hai/elements/${kind}`,
    { method: "POST", body },
    "素材上传失败",
  );
}

export function deleteMaterial(kind: MaterialKind, entryId: string) {
  return requestJson<{ success?: boolean }>(
    `/api/xiao-hai/elements/${kind}/${encodeURIComponent(entryId)}`,
    { method: "DELETE" },
    "素材删除失败",
  );
}
