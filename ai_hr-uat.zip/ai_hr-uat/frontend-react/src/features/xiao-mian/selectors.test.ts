import { describe, expect, it } from "vitest";

import type { InterviewReviewState } from "./api";
import type { AgentPipeline } from "../agent-workbench/api";
import { allInterviewsReviewed, isConversationBlockedByDraft, isReviewReady, shortlistedCandidates } from "./selectors";

describe("xiao-mian selectors", () => {
  it("requires every shortlisted candidate to have reviewed questions", () => {
    const state: InterviewReviewState = {
      interviews: [{ candidate_id: "c1", questions: [{ question: "Q1" }], review_status: "reviewed" }],
    };

    expect(isReviewReady(state.interviews[0])).toBe(true);
    expect(allInterviewsReviewed(state, ["c1"])).toBe(true);
    expect(allInterviewsReviewed(state, ["c1", "c2"])).toBe(false);
  });

  it("uses only the confirmed screening shortlist", () => {
    const pipeline = {
      id: "p1",
      role: "工程师",
      agents: [],
      candidates: [
        { id: "passed", status: "passed" },
        { id: "new", status: "new" },
      ],
      stages: [
        {
          stage_id: "match",
          status: "done",
          output: { workflow_status: "confirmed", shortlisted: ["passed"] },
        },
      ],
    } satisfies AgentPipeline;

    expect(shortlistedCandidates(pipeline).map((candidate) => candidate.id)).toEqual(["passed"]);
  });

  it("defines a pure boundary for blocking question conversation when the draft is unsaved", () => {
    expect(isConversationBlockedByDraft({ hasUnsavedDraft: true, targetsCurrentQuestions: true })).toBe(true);
    expect(isConversationBlockedByDraft({ hasUnsavedDraft: false, targetsCurrentQuestions: true })).toBe(false);
  });
});
