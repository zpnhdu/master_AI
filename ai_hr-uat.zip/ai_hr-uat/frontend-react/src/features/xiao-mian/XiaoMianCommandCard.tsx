import { Button } from 'antd';
import type { ReactNode } from 'react';

import type { CommandActions } from '../conversations/ConversationPanel';
import type { ConversationCommand, ConversationLatestData } from '../conversations/api';

const STATUS_LABELS: Record<string, string> = {
  clarifying: '待补充',
  awaiting_confirm: '待确认',
  previewing: '生成预览中',
  queued: '排队中',
  running: '执行中',
  succeeded: '已完成',
  stale: '数据已变化',
  failed: '失败',
  cancelled: '已取消',
  undone: '已撤销',
  undo_failed: '撤销失败',
};

const INTENT_TITLES: Record<string, string> = {
  schedule_interview: '面试排期',
  reschedule_interview: '面试改期',
  cancel_interview: '取消面试',
  modify_questions: '面试题修改',
  configure_assessment_plan: '评估方案',
};

const MODALITY_LABELS: Record<string, string> = {
  written_test: '在线笔试',
  video_interview: '视频面试',
  manual_interview: '人工面试',
};

const COMBINATION_LABELS: Record<string, string> = {
  all: '全部完成',
  any: '任意完成一个',
  conditional: '条件分支',
};

const OPERATOR_LABELS: Record<string, string> = { gt: '>', gte: '≥', lt: '<', lte: '≤', eq: '=' };

type Preview = Record<string, unknown> & {
  kind?: string;
  candidate_name?: string;
  before_questions?: Array<Record<string, unknown>>;
  after_questions?: Array<Record<string, unknown>>;
  date?: string;
  time?: string;
  timezone?: string;
  interviewer?: string;
  method?: string;
  conflicts?: Array<{ type?: string; interviewer?: string; date?: string; time?: string }>;
};

/**
 * 小面自然语言命令卡片。对齐旧版 xiao_mian.html 的 renderConversationCommand：
 * clarifying（候选人/排期选项）→ awaiting_confirm（题目 diff、排期、改期、评估方案预览）
 * → succeeded（可撤销）/ stale（按最新数据重新预览）。
 */
export function XiaoMianCommandCard({
  command,
  actions,
  onRefreshData,
  disabled = false,
}: {
  command: ConversationCommand;
  actions: CommandActions;
  latestData?: ConversationLatestData;
  onRefreshData: () => void;
  /** 禁止对已结束面试候选人执行任何会改变题目/流程的命令。 */
  disabled?: boolean;
}) {
  const result = command.result ?? {};
  const preview = (command.preview ?? {}) as Preview;
  const status = command.status || 'failed';
  const busy = actions.actingCommandId === command.id;
  const title = INTENT_TITLES[stringOf(command.intent) ?? ''] ?? '自然语言操作';

  let body: ReactNode;
  if (status === 'clarifying') {
    const candidateOptions = arrayOf(result.candidate_options);
    const scheduleOptions = arrayOf(result.schedule_options);
    body = (
      <>
        <div className="command-summary">{stringOf(result.reply) || '请补充必要信息。'}</div>
        {candidateOptions.length ? (
          <div className="command-options">
            {candidateOptions.map((option, index) => (
              <Button
                size="small"
                key={stringOf(option.candidate_id) ?? index}
                disabled={disabled || busy}
                onClick={() =>
                  actions.selectCandidate(command, {
                    candidate_id: stringOf(option.candidate_id),
                    candidate_name: stringOf(option.candidate_name),
                  })
                }
              >
                {stringOf(option.candidate_name) || '候选人'} · {stringOf(option.candidate_id)}
              </Button>
            ))}
          </div>
        ) : null}
        {scheduleOptions.length ? (
          <div className="command-options">
            {scheduleOptions.map((option, index) => (
              <Button
                size="small"
                key={stringOf(option.schedule_id) ?? index}
                disabled={disabled || busy}
                onClick={() => actions.selectSchedule(command, { schedule_id: stringOf(option.schedule_id) })}
              >
                {stringOf(option.date)} {stringOf(option.time)} · {stringOf(option.interviewer)}
              </Button>
            ))}
          </div>
        ) : null}
        <div className="command-actions">
          <Button size="small" loading={busy} disabled={busy} onClick={() => actions.cancel(command)}>
            取消操作
          </Button>
        </div>
      </>
    );
  } else if (status === 'awaiting_confirm') {
    body = (
      <>
        {preview.kind === 'question_diff' ? (
          <QuestionDiffPreview preview={preview} />
        ) : preview.kind === 'assessment_plan' ? (
          <AssessmentPlanPreview preview={preview} />
        ) : preview.kind === 'schedule_change' ? (
          <ScheduleChangePreview preview={preview} />
        ) : (
          <SchedulePreview preview={preview} />
        )}
        <div className="command-actions">
          <Button type="primary" size="small" loading={busy} disabled={disabled} onClick={() => actions.confirm(command)}>
            确认执行
          </Button>
          <Button size="small" disabled={busy} onClick={() => actions.cancel(command)}>
            取消操作
          </Button>
        </div>
      </>
    );
  } else if (status === 'stale') {
    body = (
      <>
        <div className="command-summary">{stringOf(result.reply) || '原数据已变化，本次预览不能直接执行。'}</div>
        <div className="command-actions">
          <Button type="primary" size="small" loading={busy} disabled={disabled} onClick={() => actions.repreview(command)}>
            根据最新数据重新预览
          </Button>
          <Button size="small" disabled={busy} onClick={() => actions.cancel(command)}>
            取消操作
          </Button>
        </div>
      </>
    );
  } else if (status === 'succeeded') {
    body = (
      <>
        <div className="command-summary">{stringOf(result.reply) || '操作已完成。'}</div>
        <div className="command-meta">执行时间：{stringOf(command.executed_at) || stringOf(command.updated_at)}</div>
        <div className="command-actions">
          <Button size="small" onClick={onRefreshData}>
            查看最新数据
          </Button>
          <Button size="small" loading={busy} disabled={disabled} onClick={() => actions.undo(command)}>
            撤销本次操作
          </Button>
        </div>
      </>
    );
  } else {
    body = <div className="command-summary">{stringOf(result.reply) || '操作已结束。'}</div>;
  }

  return (
    <div className="command-card">
      <div className="command-head">
        <span className="command-title">{title}</span>
        <span className={`command-status command-status--${status}`}>{STATUS_LABELS[status] ?? status}</span>
      </div>
      {body}
    </div>
  );
}

function QuestionDiffPreview({ preview }: { preview: Preview }) {
  const beforeQuestions = preview.before_questions ?? [];
  const afterQuestions = preview.after_questions ?? [];
  const changed = afterQuestions
    .map((question, index) => ({ before: beforeQuestions[index] ?? {}, after: question, index }))
    .filter((item) => JSON.stringify(item.before) !== JSON.stringify(item.after));
  return (
    <>
      <div className="command-summary">
        候选人：<b>{preview.candidate_name}</b> · 修改 {changed.length} 道 · 题目总数 {afterQuestions.length} 道
      </div>
      {changed.map((item) => (
        <details className="command-question" open={item.index === 0} key={item.index}>
          <summary>第 {item.index + 1} 题</summary>
          <div className="command-diff">
            <div>
              <b className="command-diff__label">修改前</b>
              <br />
              {stringOf(item.before.question)}
            </div>
            <div>
              <b className="command-diff__label command-diff__label--after">修改后</b>
              <br />
              {stringOf(item.after.question)}
            </div>
          </div>
        </details>
      ))}
    </>
  );
}

function AssessmentPlanPreview({ preview }: { preview: Preview }) {
  const config = (preview.after_config ?? {}) as {
    name?: string;
    combination?: string;
    steps?: Array<{ modality?: string; required?: boolean; weight?: number }>;
    condition?: { source_step?: string; operator?: string; threshold?: unknown; then_step?: string; then_action?: string; else_step?: string; else_action?: string };
  };
  const steps = config.steps ?? [];
  const condition = config.condition ?? {};
  return (
    <>
      <div className="command-summary">
        方案：<b>{config.name || '评估方案'}</b> · 将启用 V{Number(preview.next_version) || 1}
        <br />
        组合规则：{COMBINATION_LABELS[stringOf(config.combination) ?? ''] ?? stringOf(config.combination) ?? '未配置'}
        <br />
        满足规则后自动进入小评，异常进入待复核。
      </div>
      <div className="command-steps">
        {steps.map((step, index) => (
          <div key={index}>
            <div className="command-step">
              <b>{MODALITY_LABELS[stringOf(step.modality) ?? ''] ?? stringOf(step.modality) ?? '评估'}</b> ·{' '}
              {step.required ? '必选' : '可选'}
              {step.weight ? ` · 权重 ${step.weight}%` : ''}
            </div>
            {index < steps.length - 1 ? <div className="command-step-connector">↓</div> : null}
          </div>
        ))}
      </div>
      {config.combination === 'conditional' ? (
        <div className="command-condition">
          {condition.source_step || '首个环节'} {OPERATOR_LABELS[stringOf(condition.operator) ?? ''] ?? stringOf(condition.operator)}{' '}
          {String(condition.threshold ?? '')}：进入 {condition.then_step || condition.then_action || ''}；否则进入{' '}
          {condition.else_step || condition.else_action || ''}
        </div>
      ) : null}
    </>
  );
}

function SchedulePreview({ preview }: { preview: Preview }) {
  const method =
    preview.method === 'online' ? '线上面试' : preview.method === 'offline' ? '线下面试' : stringOf(preview.method);
  return (
    <>
      <div className="command-summary">
        候选人：<b>{preview.candidate_name}</b>
        <br />
        时间：{preview.date} {preview.time}（{preview.timezone || 'Asia/Shanghai'}）
        <br />
        面试官：{preview.interviewer} · 方式：{method}
      </div>
      <ScheduleWarnings preview={preview} />
    </>
  );
}

function ScheduleChangePreview({ preview }: { preview: Preview }) {
  const before = (preview.before_schedule ?? {}) as Preview;
  const after = (preview.after_schedule ?? {}) as Preview;
  if (preview.action === 'cancel') {
    return (
      <div className="command-summary">
        将取消 <b>{preview.candidate_name}</b> 的面试
        <br />
        {stringOf(before.date)} {stringOf(before.time)}（Asia/Shanghai）· {stringOf(before.interviewer)} ·{' '}
        {stringOf(before.method)}
      </div>
    );
  }
  return (
    <>
      <div className="command-summary">
        候选人：<b>{preview.candidate_name}</b> · 修改已有排期
      </div>
      <div className="command-diff">
        <div>
          <b className="command-diff__label">修改前</b>
          <br />
          {stringOf(before.date)} {stringOf(before.time)}（Asia/Shanghai）
          <br />
          {stringOf(before.interviewer)} · {stringOf(before.method)}
        </div>
        <div>
          <b className="command-diff__label command-diff__label--after">修改后</b>
          <br />
          {stringOf(after.date)} {stringOf(after.time)}（Asia/Shanghai）
          <br />
          {stringOf(after.interviewer)} · {stringOf(after.method)}
        </div>
      </div>
      <ScheduleWarnings preview={{ ...after, conflicts: preview.conflicts ?? [] }} />
    </>
  );
}

function ScheduleWarnings({ preview }: { preview: Preview }) {
  const conflicts = preview.conflicts ?? [];
  return (
    <>
      {conflicts.length ? (
        <div className="command-conflicts">
          <b>检测到 {conflicts.length} 个时间冲突</b>
          {conflicts.map((conflict, index) => (
            <div key={index}>
              ·{' '}
              {conflict.type === 'candidate'
                ? '候选人已有排期'
                : `面试官 ${conflict.interviewer ?? ''} 已有排期`}
              ：{conflict.date ?? preview.date ?? ''} {conflict.time ?? preview.time ?? ''}
            </div>
          ))}
        </div>
      ) : null}
      <div className="command-calendar-note">当前仅检查系统内排期，尚未检查面试官外部日历。</div>
    </>
  );
}

function arrayOf(value: unknown): Array<Record<string, unknown>> {
  return Array.isArray(value) ? value.filter((item): item is Record<string, unknown> => typeof item === 'object' && item !== null) : [];
}

function stringOf(value: unknown) {
  return typeof value === 'string' ? value : undefined;
}
