import { requestJson } from "../agent-workbench/api";

export type InterviewQuestion = {
  type?: string;
  question?: string;
  duration?: string;
  difficulty?: string;
  dimension?: string;
  competency_ref?: string;
  follow_up?: string;
  expected_points?: string[];
  [key: string]: unknown;
};

export type InterviewReview = {
  candidate_id: string;
  candidate_name?: string;
  questions: InterviewQuestion[];
  review_status?: "pending" | "reviewed" | string;
  question_edit_locked?: boolean;
  question_edit_lock_status?: string;
  interview_status?: string;
  [key: string]: unknown;
};

export type InterviewReviewState = {
  review_status?: string;
  generated_count?: number;
  max_questions?: number;
  interviews: InterviewReview[];
  [key: string]: unknown;
};

export type GenerationTask = {
  id?: string;
  generation_job_id?: string;
  generation_status?: string;
  status?: string;
  progress?: number;
  candidate_count?: number;
  question_count?: number;
  message?: string;
  error?: string;
};

export type MassInviteSession = {
  token?: string;
  candidate_id?: string;
  candidate_name?: string;
  invite_url?: string;
  expires_at?: string;
  invite_sent_at?: string;
  status?: string;
  total_questions?: number;
};

export type WrittenInviteSession = {
  token?: string;
  candidate_id: string;
  candidate_name?: string;
  invite_url: string;
  status?: string;
  started_at?: string;
  submitted_at?: string;
  expires_at?: string;
  invite_sent_at?: string;
  question_count?: number;
};

export type WrittenTestStatusSession = {
  candidate_id: string;
  candidate_name?: string;
  token?: string;
  status: string;
  started_at?: string;
  submitted_at?: string;
  expires_at?: string;
  camera_enabled?: boolean;
  score?: number | null;
  scoring_status?: string;
  scoring_error?: string;
  evaluation?: {
    comment?: string;
    scoring_version?: string;
    dimension_scores?: Record<string, number>;
  };
};

export type WrittenTestStatus = {
  sessions: WrittenTestStatusSession[];
  submitted: number;
  pending: number;
  total: number;
};

export async function fetchInterviewReview(pipelineId: string) {
  return requestJson<InterviewReviewState>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review?_ts=${Date.now()}`,
    { cache: "no-store" },
    "面试题审核状态加载失败",
  );
}

export function generateInterviewQuestions(pipelineId: string, candidateId?: string) {
  return requestJson<GenerationTask>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/interview-questions/generate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(candidateId ? { candidate_id: candidateId, batch: false } : { batch: true }),
    },
    "面试题生成失败",
  );
}

export function fetchGenerationTask(pipelineId: string, taskId: string) {
  return requestJson<GenerationTask>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/interview-questions/generation/${encodeURIComponent(taskId)}`,
    {},
    "生成任务查询失败",
  );
}

export function setQuestionCount(pipelineId: string, count: number) {
  return requestJson<{ generated_count: number }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/question-count`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ count }) },
    "题数设置失败",
  );
}

export function saveInterviewQuestions(pipelineId: string, candidateId: string, questions: InterviewQuestion[]) {
  return requestJson<{ candidate: InterviewReview }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/questions/${encodeURIComponent(candidateId)}`,
    { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ questions }) },
    "题目保存失败",
  );
}

export function confirmInterviewReview(pipelineId: string, candidateIds?: string[]) {
  return requestJson<{ reviewed_count: number }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/confirm`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ candidate_ids: candidateIds }),
    },
    "题目审核确认失败",
  );
}

export function applyQuestionsToAll(pipelineId: string, candidateId: string) {
  return requestJson<{ interviews: InterviewReview[] }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/apply-to-all/${encodeURIComponent(candidateId)}`,
    { method: "POST" },
    "应用题目失败",
  );
}

export function regenerateInterviewQuestions(pipelineId: string, candidateId: string | undefined, count: number) {
  return requestJson<GenerationTask>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/regenerate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ candidate_id: candidateId, count }),
    },
    "重新生成题目失败",
  );
}

export function generateOneQuestion(pipelineId: string, candidateId: string, direction: string, difficulty: string) {
  return requestJson<{ success: boolean; candidate: InterviewReview }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/questions/${encodeURIComponent(candidateId)}/generate`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ direction, difficulty }),
    },
    "AI 出题失败",
  );
}

export function aiFillQuestion(pipelineId: string, candidateId: string, index: number, difficulty: string) {
  return requestJson<{ success: boolean; question: InterviewQuestion; message: string }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/questions/${encodeURIComponent(candidateId)}/${index}/ai-fill`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ difficulty }),
    },
    "AI 补全失败",
  );
}

export function launchMassInterview(pipelineId: string, expiresHours: number, candidateIds: string[]) {
  return requestJson<{
    status?: string;
    sessions: MassInviteSession[];
    total?: number;
    skipped?: number;
    question_count?: number;
  }>(
    "/api/mass-interview/launch",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pipeline_id: pipelineId, expires_hours: expiresHours, candidate_ids: candidateIds }),
    },
    "发起视频面试失败",
  );
}

export function lockQuestionBatch(pipelineId: string, candidateIds: string[]) {
  return requestJson<{ locked_count: number }>(
    `/api/interview/${encodeURIComponent(pipelineId)}/review/lock`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ candidate_ids: candidateIds }),
    },
    "进入面试中心失败",
  );
}

export function sendInterviewInvites(pipelineId: string, sessionIds?: string[]) {
  return requestJson<{ sent?: number; failed?: number; skipped_no_email?: number; links?: MassInviteSession[] }>(
    `/api/mass-interview/${encodeURIComponent(pipelineId)}/invite`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ method: "email", session_ids: sessionIds, base_url: window.location.origin }),
    },
    "邮件发送失败",
  );
}

export function saveManualInterview(
  pipelineId: string,
  body: {
    candidate_id: string;
    candidate_name: string;
    interviewer: string;
    interview_date: string;
    answers: Array<{ question: string; answer: string }>;
  },
) {
  return requestJson<{ status: string; summary?: string }>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/interview-answers`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
    "面试记录保存失败",
  );
}

export function saveAssessment(
  pipelineId: string,
  body: {
    candidate_id: string;
    candidate_name: string;
    dimensions: Record<string, number>;
    highlights: string;
    concerns: string;
    recommendation: string;
  },
) {
  return requestJson<{ assessment_flow?: unknown }>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/assessments`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
    "人工评估保存失败",
  );
}

export function launchWrittenTest(pipelineId: string, candidateIds: string[], expiresHours: number) {
  return requestJson<{ sessions: WrittenInviteSession[]; total?: number }>(
    "/api/written-test/launch",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pipeline_id: pipelineId, candidate_ids: candidateIds, expires_hours: expiresHours }),
    },
    "在线笔试发起失败",
  );
}

export function fetchWrittenTestStatus(pipelineId: string) {
  return requestJson<WrittenTestStatus>(
    `/api/written-test/${encodeURIComponent(pipelineId)}/status`,
    {},
    "笔试进度加载失败",
  );
}
