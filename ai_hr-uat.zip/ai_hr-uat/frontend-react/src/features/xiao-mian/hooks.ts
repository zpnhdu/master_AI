import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { fetchAgentPipeline, passAgentArtifact } from "../agent-workbench/api";
import {
  applyQuestionsToAll,
  confirmInterviewReview,
  fetchGenerationTask,
  fetchInterviewReview,
  fetchWrittenTestStatus,
  generateInterviewQuestions,
  generateOneQuestion,
  launchMassInterview,
  lockQuestionBatch,
  launchWrittenTest,
  regenerateInterviewQuestions,
  saveAssessment,
  saveInterviewQuestions,
  saveManualInterview,
  sendInterviewInvites,
  setQuestionCount,
} from "./api";

export const xiaoMianKeys = {
  pipeline: (id: string) => ["xiao-mian", "pipeline", id] as const,
  review: (id: string) => ["xiao-mian", "review", id] as const,
  writtenStatus: (id: string) => ["xiao-mian", "written-status", id] as const,
};

export function useXiaoMianPipelineQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoMianKeys.pipeline(pipelineId),
    queryFn: () => fetchAgentPipeline(pipelineId),
    enabled: Boolean(pipelineId),
  });
}
export function useXiaoMianReviewQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoMianKeys.review(pipelineId),
    queryFn: () => fetchInterviewReview(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
  });
}
export function useWrittenTestStatusQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoMianKeys.writtenStatus(pipelineId),
    queryFn: () => fetchWrittenTestStatus(pipelineId),
    enabled: Boolean(pipelineId),
    refetchInterval: (query) => (query.state.data?.pending ? 10000 : false),
  });
}

function invalidate(queryClient: ReturnType<typeof useQueryClient>, pipelineId: string) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: xiaoMianKeys.pipeline(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: xiaoMianKeys.review(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: ["xiao-ping", "queue", pipelineId] }),
    queryClient.invalidateQueries({ queryKey: ["pipeline-detail", pipelineId] }),
  ]);
}

export function useGenerateQuestionsMutation(pipelineId: string) {
  return useMutation({ mutationFn: (candidateId?: string) => generateInterviewQuestions(pipelineId, candidateId) });
}
export function useGenerationTaskQuery(pipelineId: string, taskId: string) {
  return useQuery({
    queryKey: ["xiao-mian", "generation", pipelineId, taskId],
    queryFn: () => fetchGenerationTask(pipelineId, taskId),
    enabled: Boolean(taskId),
    refetchInterval: (query) => {
      const status = query.state.data?.status ?? query.state.data?.generation_status;
      return ["done", "failed"].includes(status ?? "") ? false : 1200;
    },
  });
}
export function useQuestionCountMutation(pipelineId: string) {
  return useMutation({ mutationFn: (count: number) => setQuestionCount(pipelineId, count) });
}
export function useSaveQuestionsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      candidateId,
      questions,
    }: {
      candidateId: string;
      questions: Parameters<typeof saveInterviewQuestions>[2];
    }) => saveInterviewQuestions(pipelineId, candidateId, questions),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useConfirmReviewMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (candidateIds?: string[]) => confirmInterviewReview(pipelineId, candidateIds),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useApplyQuestionsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (candidateId: string) => applyQuestionsToAll(pipelineId, candidateId),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useRegenerateQuestionsMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ candidateId, count }: { candidateId?: string; count: number }) =>
      regenerateInterviewQuestions(pipelineId, candidateId, count),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: xiaoMianKeys.review(pipelineId) });
      void queryClient.invalidateQueries({ queryKey: xiaoMianKeys.pipeline(pipelineId) });
    },
  });
}
export function useGenerateOneQuestionMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      candidateId,
      direction,
      difficulty,
    }: {
      candidateId: string;
      direction: string;
      difficulty: string;
    }) => generateOneQuestion(pipelineId, candidateId, direction, difficulty),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useLaunchMassInterviewMutation(pipelineId: string) {
  return useMutation({
    mutationFn: ({ expiresHours, candidateIds }: { expiresHours: number; candidateIds: string[] }) =>
      launchMassInterview(pipelineId, expiresHours, candidateIds),
  });
}
export function useLockQuestionBatchMutation(pipelineId: string) {
  return useMutation({ mutationFn: (candidateIds: string[]) => lockQuestionBatch(pipelineId, candidateIds) });
}
export function useSendInvitesMutation(pipelineId: string) {
  return useMutation({ mutationFn: (sessionIds?: string[]) => sendInterviewInvites(pipelineId, sessionIds) });
}
export function useSaveManualInterviewMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: Parameters<typeof saveManualInterview>[1]) => saveManualInterview(pipelineId, body),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useSaveAssessmentMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: Parameters<typeof saveAssessment>[1]) => saveAssessment(pipelineId, body),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
export function useLaunchWrittenTestMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ candidateIds, expiresHours }: { candidateIds: string[]; expiresHours: number }) =>
      launchWrittenTest(pipelineId, candidateIds, expiresHours),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: xiaoMianKeys.writtenStatus(pipelineId) }),
  });
}

export function usePassXiaoMianMutation(pipelineId: string) {
  return useMutation({
    mutationFn: (artifacts: Record<string, unknown>) => passAgentArtifact(pipelineId, "xiao_mian", artifacts),
  });
}
