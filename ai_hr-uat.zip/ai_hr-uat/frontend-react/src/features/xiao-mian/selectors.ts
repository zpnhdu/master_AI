import type { AgentPipeline } from "../agent-workbench/api";
import type { InterviewReview, InterviewReviewState } from "./api";

export function shortlistedCandidates(pipeline: AgentPipeline) {
  const match = pipeline.stages.find((stage) => stage.stage_id === "match");
  if (match?.status !== "done" || match.output.workflow_status !== "confirmed") return [];
  const shortlisted = Array.isArray(match.output.shortlisted)
    ? match.output.shortlisted.filter((id): id is string => typeof id === "string")
    : [];
  const shortlistedIds = new Set(shortlisted);
  return pipeline.candidates.filter((candidate) => shortlistedIds.has(candidate.id));
}

export function reviewByCandidate(state: InterviewReviewState) {
  return new Map((state.interviews ?? []).map((item) => [item.candidate_id, item]));
}

export function isReviewReady(item: InterviewReview | undefined) {
  return (
    Boolean(item?.questions?.length) &&
    (item?.review_status === "reviewed" || item?.review_status === "approved" || !item?.review_status)
  );
}

export function allInterviewsReviewed(state: InterviewReviewState, candidateIds: string[]) {
  if (!candidateIds.length) return false;
  const byCandidate = reviewByCandidate(state);
  return candidateIds.every((candidateId) => isReviewReady(byCandidate.get(candidateId)));
}

export function normalizeQuestion(question: Record<string, unknown> = {}) {
  return {
    ...question,
    type: typeof question.type === "string" ? question.type : "综合面试",
    question: typeof question.question === "string" ? question.question : "",
    difficulty: typeof question.difficulty === "string" ? question.difficulty : "中等",
    duration: typeof question.duration === "string" ? question.duration : "3分钟",
    expected_points: Array.isArray(question.expected_points)
      ? question.expected_points.filter((item): item is string => typeof item === "string")
      : [],
  };
}

export function isConversationBlockedByDraft(input: { hasUnsavedDraft: boolean; targetsCurrentQuestions: boolean }) {
  return input.hasUnsavedDraft && input.targetsCurrentQuestions;
}
