import { requestJson } from "../agent-workbench/api";
import { ApiError } from "../pipelines/api";

export type ScreeningConfig = {
  threshold: number | null;
};

export type ScreeningIdReference = string | { id?: string };

export type ScreeningMissingInfo = {
  label: string;
  severity?: "critical" | "important" | "minor" | string;
  reason?: string;
};

export type ScreeningPenalty = {
  label: string;
  severity?: "critical" | "important" | "minor" | string;
  points: number;
  reason?: string;
};

export type ScreeningCandidate = {
  id: string;
  name?: string;
  status: "passed" | "rejected" | "new" | string;
  screening_decision?: "passed" | "rejected" | string;
  overall_score: number;
  model_score?: number;
  adjusted_score?: number;
  penalty_total?: number;
  penalties?: ScreeningPenalty[];
  score_source?: "model" | "model_failed" | "manual_override" | string;
  confidence?: number;
  dimension_scores?: Array<{ key?: string; label?: string; score?: number; evidence?: string }>;
  strengths?: string[];
  concerns?: string[];
  missing_info?: Array<ScreeningMissingInfo | string>;
  information_gaps?: Array<ScreeningMissingInfo | string>;
  summary?: string;
  review_reason?: string;
  reason?: string;
  [key: string]: unknown;
};

export type ScreeningWorkflow = {
  workflow_status?: "review_pending" | "confirmed" | string;
  version?: number;
  total?: number;
  config?: ScreeningConfig;
  counts: { passed: number; rejected: number };
  candidates: ScreeningCandidate[];
  pending_count?: number;
  unscored_count?: number;
  reviewable_count?: number;
  passed_ids?: ScreeningIdReference[];
  shortlisted?: ScreeningIdReference[];
  rejected?: ScreeningIdReference[];
  versions?: Array<Record<string, unknown>>;
  allowed_actions?: string[];
  blocking_reasons?: string[];
  next_required_action?: string;
  [key: string]: unknown;
};

export async function fetchScreeningWorkflow(pipelineId: string) {
  return requestJson<ScreeningWorkflow>(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/screening-workflow`,
    {},
    "筛选工作流加载失败",
  );
}

export async function screeningRequest<T>(pipelineId: string, action: string, body?: unknown) {
  try {
    return await requestJson<T>(
      `/api/pipelines/${encodeURIComponent(pipelineId)}/screening-workflow/${action}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: body === undefined ? undefined : JSON.stringify(body),
      },
      "筛选操作失败",
    );
  } catch (error) {
    // 小筛工作台面向 HR 的拒绝提示不带 HTTP 状态码（如“（400）”），文案本身保持不变。
    if (error instanceof ApiError) {
      throw new ApiError(error.message.replace(/（\d+）$/, ""), { status: error.status, data: error.data });
    }
    throw error;
  }
}

export function previewScreening(pipelineId: string, config: ScreeningConfig, force = false) {
  return screeningRequest<ScreeningWorkflow>(pipelineId, "preview", { ...config, force });
}

export function executeScreening(pipelineId: string, config: ScreeningConfig, force = false) {
  return screeningRequest<ScreeningWorkflow>(pipelineId, "execute", { ...config, force });
}

export function reviewScreeningCandidate(
  pipelineId: string,
  candidateId: string,
  body: { status: string; reason: string; override_score?: number | null },
) {
  return screeningRequest<ScreeningWorkflow>(pipelineId, `review/${encodeURIComponent(candidateId)}`, body);
}

export function finalizeScreening(pipelineId: string) {
  return screeningRequest<ScreeningWorkflow>(pipelineId, "finalize");
}