import { afterEach, describe, expect, it, vi } from "vitest";

import { executeScreening, previewScreening } from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("xiao shai screening api", () => {
  it("sends an explicit screening request without a rescore flag", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ counts: { passed: 1, rejected: 0 }, candidates: [] }),
      }),
    );

    await executeScreening("pipeline/1", { threshold: 70 });

    expect(fetch).toHaveBeenCalledWith(
      "/api/pipelines/pipeline%2F1/screening-workflow/execute",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ threshold: 70, force: false }),
      }),
    );
  });

  it("keeps preview requests distinct from persisted execution", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ counts: { passed: 0, rejected: 1 }, candidates: [] }),
      }),
    );

    await previewScreening("pipeline-1", { threshold: 80 });

    expect(fetch).toHaveBeenCalledWith(
      "/api/pipelines/pipeline-1/screening-workflow/preview",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ threshold: 80, force: false }),
      }),
    );
  });
});
