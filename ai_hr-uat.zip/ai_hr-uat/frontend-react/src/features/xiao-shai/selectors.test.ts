import { describe, expect, it } from "vitest";

import type { ScreeningWorkflow } from "./api";
import { DEFAULT_SCREENING_CONFIG, filterScreeningCandidates, mergeScreeningConfig } from "./selectors";

describe("xiao-shai selectors", () => {
  it("merges a saved threshold over the defaults without mutating them", () => {
    const config = mergeScreeningConfig(DEFAULT_SCREENING_CONFIG, { threshold: 85 });

    expect(config.threshold).toBe(85);
    expect(DEFAULT_SCREENING_CONFIG.threshold).toBe(70);
  });

  it("filters and sorts rejected candidates without mutating workflow data", () => {
    const workflow: ScreeningWorkflow = {
      counts: { passed: 1, rejected: 1 },
      candidates: [
        { id: "1", name: "李明", status: "passed", overall_score: 88 },
        { id: "2", name: "王芳", status: "rejected", overall_score: 72 },
      ],
    };

    expect(filterScreeningCandidates(workflow, "rejected", "", false).map((item) => item.id)).toEqual(["2"]);
    expect(workflow.candidates.map((item) => item.id)).toEqual(["1", "2"]);
  });

  it("hides only candidates already passed to the next node", () => {
    const workflow: ScreeningWorkflow = {
      counts: { passed: 2, rejected: 2 },
      candidates: [
        { id: "1", name: "李明", status: "passed", screening_decision: " passed ", overall_score: 88 },
        { id: "2", name: "王芳", status: "passed", overall_score: 95 },
        { id: "3", name: "赵强", status: "rejected", overall_score: 72 },
        { id: "4", name: "周强", status: "rejected", overall_score: 50 },
      ],
    };

    expect(filterScreeningCandidates(workflow, "all", "", false).map((item) => item.id)).toEqual(["2", "3", "4"]);
    expect(filterScreeningCandidates(workflow, "passed", "", false).map((item) => item.id)).toEqual(["2"]);
  });

  it("supports legacy passed references in a confirmed workflow", () => {
    const workflow: ScreeningWorkflow = {
      workflow_status: "confirmed",
      counts: { passed: 2, rejected: 1 },
      passed_ids: ["1"],
      shortlisted: [{ id: "2" }],
      candidates: [
        { id: "1", name: "李明", status: "passed", overall_score: 88 },
        { id: "2", name: "王芳", status: "passed", overall_score: 85 },
        { id: "3", name: "赵强", status: "rejected", overall_score: 50 },
      ],
    };

    expect(filterScreeningCandidates(workflow, "all", "", false).map((item) => item.id)).toEqual(["3"]);
  });
});
