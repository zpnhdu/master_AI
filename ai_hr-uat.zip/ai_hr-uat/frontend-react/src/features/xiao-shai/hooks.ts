import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { fetchAgentPipeline, passAgentArtifact } from "../agent-workbench/api";
import {
  executeScreening,
  fetchScreeningWorkflow,
  finalizeScreening,
  previewScreening,
  reviewScreeningCandidate,
} from "./api";
import type { ScreeningConfig } from "./api";

export const xiaoShaiKeys = {
  pipeline: (id: string) => ["xiao-shai", "pipeline", id] as const,
  workflow: (id: string) => ["xiao-shai", "workflow", id] as const,
};

export function useXiaoShaiPipelineQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoShaiKeys.pipeline(pipelineId),
    queryFn: () => fetchAgentPipeline(pipelineId),
    enabled: Boolean(pipelineId),
  });
}

export function useXiaoShaiWorkflowQuery(pipelineId: string) {
  return useQuery({
    queryKey: xiaoShaiKeys.workflow(pipelineId),
    queryFn: () => fetchScreeningWorkflow(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
  });
}

function invalidate(queryClient: ReturnType<typeof useQueryClient>, pipelineId: string) {
  return Promise.all([
    queryClient.invalidateQueries({ queryKey: xiaoShaiKeys.pipeline(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: xiaoShaiKeys.workflow(pipelineId) }),
    queryClient.invalidateQueries({ queryKey: ["pipeline-detail", pipelineId] }),
  ]);
}

export function usePreviewScreeningMutation(pipelineId: string) {
  return useMutation({
    mutationFn: ({ config, force = false }: { config: ScreeningConfig; force?: boolean }) =>
      previewScreening(pipelineId, config, force),
  });
}

export function useExecuteScreeningMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ config, force = false }: { config: ScreeningConfig; force?: boolean }) =>
      executeScreening(pipelineId, config, force),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}

export function useReviewScreeningMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({
      candidateId,
      status,
      reason,
      score,
    }: {
      candidateId: string;
      status: string;
      reason: string;
      score?: number | null;
    }) => reviewScreeningCandidate(pipelineId, candidateId, { status, reason, override_score: score }),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}

export function useFinalizeScreeningMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => finalizeScreening(pipelineId),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}

export function usePassScreeningMutation(pipelineId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (artifacts: Record<string, unknown>) => passAgentArtifact(pipelineId, "xiao_shai", artifacts),
    onSuccess: () => invalidate(queryClient, pipelineId),
  });
}
