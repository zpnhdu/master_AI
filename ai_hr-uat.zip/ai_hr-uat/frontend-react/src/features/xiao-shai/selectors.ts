import type { AgentPipeline } from "../agent-workbench/api";
import type { ScreeningConfig, ScreeningWorkflow } from "./api";

export const DEFAULT_SCREENING_CONFIG: ScreeningConfig = {
  threshold: 70,
};

export function mergeScreeningConfig(base: ScreeningConfig, value: Partial<ScreeningConfig>): ScreeningConfig {
  return { ...base, ...value };
}

export function screeningBlocked(pipeline: AgentPipeline) {
  const jdReady = pipeline.stages.some((stage) => stage.stage_id === "jd_write" && stage.status === "done");
  const crawlReady = pipeline.stages.some((stage) => stage.stage_id === "crawl" && stage.status === "done");
  return {
    jdReady,
    crawlReady,
    hasCandidates: pipeline.candidates.length > 0,
    reasons: [
      !jdReady ? "JD 尚未完成或内容不可用" : "",
      !crawlReady ? "小寻简历获取尚未完成" : "",
      pipeline.candidates.length === 0 ? "尚未导入候选人" : "",
    ].filter(Boolean),
  };
}

function screeningId(value: string | { id?: string } | undefined) {
  if (typeof value === "string") return value.trim();
  return typeof value?.id === "string" ? value.id.trim() : "";
}

export function hasEnteredNextNode(workflow: ScreeningWorkflow, candidateId: string) {
  const passedDecision = workflow.candidates.find((candidate) => candidate.id === candidateId)?.screening_decision;
  if (passedDecision?.trim().toLowerCase() === "passed") return true;
  if (workflow.workflow_status !== "confirmed") return false;
  return [...(workflow.passed_ids ?? []), ...(workflow.shortlisted ?? [])].some(
    (reference) => screeningId(reference) === candidateId,
  );
}

export function filterScreeningCandidates(
  workflow: ScreeningWorkflow,
  status: string,
  query: string,
  ascending: boolean,
) {
  const normalized = query.trim().toLowerCase();
  return [...(workflow.candidates ?? [])]
    .filter(
      (item) =>
        !hasEnteredNextNode(workflow, item.id) &&
        (status === "all" || item.status === status) &&
        (!normalized || (item.name ?? "").toLowerCase().includes(normalized)),
    )
    .sort((left, right) =>
      ascending ? left.overall_score - right.overall_score : right.overall_score - left.overall_score,
    );
}
