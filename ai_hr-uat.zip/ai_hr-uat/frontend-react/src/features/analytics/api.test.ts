import { afterEach, describe, expect, it, vi } from "vitest";

import { fetchCandidateRanking, fetchRoleOverview } from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("analytics role overview api", () => {
  it("loads role overview rows with session credentials", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => [
        {
          role: "店长",
          type_code: "management",
          type_label: "管理岗",
          candidate_count: 3,
          interview_passed_count: 2,
          pass_rate: 0.6667,
          pipelines: [],
        },
      ],
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(fetchRoleOverview()).resolves.toHaveLength(1);
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/analytics/role-overview",
      expect.objectContaining({ credentials: "include" }),
    );
  });
});

describe("candidate ranking api", () => {
  it("encodes role filters, limit, detail, and session credentials", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({
        role: "高级前端工程师",
        type_code: "tech",
        type_label: "技术岗",
        keywords: ["React"],
        total: 1,
        candidates: [
          {
            candidate_id: "candidate-1",
            name: "张三",
            score: 92,
            dimension_scores: {
              job_coverage: 95,
              professional_accuracy: 90,
              analytical_logic: 88,
              solution_feasibility: 84,
              evidence_boundaries: 82,
            },
          },
        ],
      }),
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      fetchCandidateRanking({ role: "高级前端工程师/前端", typeCode: "tech", limit: 5, detail: true }),
    ).resolves.toMatchObject({
      total: 1,
      candidates: [{ dimension_scores: { professional_accuracy: 90 } }],
    });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/analytics/candidate-ranking?role=%E9%AB%98%E7%BA%A7%E5%89%8D%E7%AB%AF%E5%B7%A5%E7%A8%8B%E5%B8%88%2F%E5%89%8D%E7%AB%AF&type_code=tech&limit=5&detail=true",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("uses the default top four limit when omitted", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => ({}) });
    vi.stubGlobal("fetch", fetchMock);

    await fetchCandidateRanking({ role: "店长", typeCode: "management" });
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/analytics/candidate-ranking?role=%E5%BA%97%E9%95%BF&type_code=management&limit=4",
      expect.objectContaining({ credentials: "include" }),
    );
  });

  it("propagates backend errors", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({ ok: false, status: 403, json: async () => ({ detail: "无权访问" }) }),
    );

    await expect(fetchCandidateRanking({ role: "店长", typeCode: "management", limit: 3 })).rejects.toThrow("无权访问");
  });
});
