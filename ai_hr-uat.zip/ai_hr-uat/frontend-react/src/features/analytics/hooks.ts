import { keepPreviousData, useMutation, useQuery } from "@tanstack/react-query";

import {
  archiveLeaderChatSession,
  createLeaderChatSession,
  fetchLeaderChatMessages,
  fetchLeaderChatSessions,
  fetchAnalyticsActivity,
  fetchAnalyticsDashboard,
  fetchCandidateRanking,
  fetchRoleOverview,
  fetchTalentPoolSummary,
  fetchTalentAttrition,
  fetchStagePassRateTrend,
  fetchHrPerformance,
  fetchTalentPoolGrowth,
  fetchMonitorDashboard,
  fetchMonitorEvents,
  fetchMonitorLogs,
  fetchMonitorUsage,
  fetchUsageDetail,
  sendLeaderChatMessage,
  type UsageDetailSortField,
  type UsageDetailSortOrder,
} from "./api";

const REFRESH_INTERVAL = 60_000;

export function useLeaderChatSessionsQuery() {
  return useQuery({
    queryKey: ["analytics", "leader-chat", "sessions"],
    queryFn: fetchLeaderChatSessions,
    staleTime: 30_000,
  });
}

export function useLeaderChatMessagesQuery(sessionId: string | undefined) {
  return useQuery({
    queryKey: ["analytics", "leader-chat", "messages", sessionId],
    queryFn: () => fetchLeaderChatMessages(sessionId as string),
    enabled: Boolean(sessionId),
  });
}

export function useCreateLeaderChatSessionMutation() {
  return useMutation({ mutationFn: createLeaderChatSession });
}

export function useSendLeaderChatMessageMutation() {
  return useMutation({ mutationFn: sendLeaderChatMessage });
}

export function useArchiveLeaderChatSessionMutation() {
  return useMutation({ mutationFn: archiveLeaderChatSession });
}

export function useAnalyticsDashboardQuery() {
  return useQuery({
    queryKey: ["analytics", "dashboard"],
    queryFn: fetchAnalyticsDashboard,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useAnalyticsActivityQuery() {
  return useQuery({
    queryKey: ["analytics", "activity"],
    queryFn: fetchAnalyticsActivity,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useRoleOverviewQuery() {
  return useQuery({
    queryKey: ["analytics", "role-overview"],
    queryFn: fetchRoleOverview,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useTalentPoolSummaryQuery() {
  return useQuery({
    queryKey: ["analytics", "talent-pool-summary"],
    queryFn: fetchTalentPoolSummary,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useTalentAttritionQuery() {
  return useQuery({
    queryKey: ["analytics", "talent-attrition"],
    queryFn: fetchTalentAttrition,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useStagePassRateTrendQuery() {
  return useQuery({
    queryKey: ["analytics", "stage-pass-rate-trend"],
    queryFn: fetchStagePassRateTrend,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useHrPerformanceQuery() {
  return useQuery({
    queryKey: ["analytics", "hr-performance"],
    queryFn: fetchHrPerformance,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useTalentPoolGrowthQuery() {
  return useQuery({
    queryKey: ["analytics", "talent-pool-growth"],
    queryFn: fetchTalentPoolGrowth,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useCandidateRankingQuery(params: {
  role?: string;
  typeCode?: string;
  limit?: number;
  detail?: boolean;
  enabled?: boolean;
}) {
  return useQuery({
    queryKey: ["analytics", "candidate-ranking", params],
    queryFn: () => fetchCandidateRanking(params),
    enabled: Boolean(params.enabled ?? true) && Boolean(params.role && params.typeCode),
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useMonitorUsageQuery(params: {
  range?: string;
  call_type?: string;
  from_ts?: string;
  granularity?: string;
}) {
  return useQuery({
    queryKey: ["monitor", "usage", params],
    queryFn: () => fetchMonitorUsage(params),
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useUsageDetailQuery(params: {
  page: number;
  page_size?: number;
  call_type?: string;
  search?: string;
  sort_by?: UsageDetailSortField;
  sort_order?: UsageDetailSortOrder;
}) {
  return useQuery({
    queryKey: ["monitor", "usage-detail", params],
    queryFn: () => fetchUsageDetail(params),
    placeholderData: keepPreviousData,
  });
}

export function useMonitorDashboardQuery() {
  return useQuery({
    queryKey: ["monitor", "dashboard"],
    queryFn: fetchMonitorDashboard,
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useMonitorLogsQuery(params: {
  page: number;
  page_size?: number;
  level?: string;
  source?: string;
  search?: string;
  from_ts?: string;
}) {
  return useQuery({
    queryKey: ["monitor", "logs", params],
    queryFn: () => fetchMonitorLogs(params),
    refetchInterval: REFRESH_INTERVAL,
  });
}

export function useMonitorEventsQuery(params: {
  page?: number;
  page_size?: number;
  entity_type?: string;
  from_ts?: string;
}) {
  return useQuery({
    queryKey: ["monitor", "events", params],
    queryFn: () => fetchMonitorEvents(params),
    refetchInterval: REFRESH_INTERVAL,
  });
}
