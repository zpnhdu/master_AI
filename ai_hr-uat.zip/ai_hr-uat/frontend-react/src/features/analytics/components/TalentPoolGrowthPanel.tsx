import { Card, Empty, Space, Spin, Tooltip, Typography } from "antd";
import type { EChartsOption } from "echarts";

import { EChart } from "../../../shared/EChart";
import { useTalentPoolGrowthQuery } from "../hooks";
import type { TalentPoolGrowth } from "../api";

const HINT_ICON = (
  <svg
    viewBox="0 0 1024 1024"
    width="14"
    height="14"
    fill="#6b7280"
    style={{ cursor: "help", marginLeft: 2 }}
  >
    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 010-96 48.01 48.01 0 010 96z" />
  </svg>
);

function HintTooltip({ title }: { title: string }) {
  return (
    <Tooltip
      placement="right"
      title={title}
      overlayInnerStyle={{
        backgroundColor: "#ffffff",
        color: "#111827",
        border: "1px solid #93c5fd",
        borderRadius: "8px",
        boxShadow: "0 4px 12px rgba(37, 99, 235, 0.12)",
      }}
      arrow={false}
    >
      {HINT_ICON}
    </Tooltip>
  );
}

function TitleWithHint({ label, hint }: { label: string; hint: string }) {
  return (
    <Space size={4}>
      <span>{label}</span>
      <HintTooltip title={hint} />
    </Space>
  );
}

const PERCENT_FORMATTER = (value: unknown) =>
  `${(Math.round(Number(value) * 1000) / 10).toFixed(1)}%`;

function growthOption(data: TalentPoolGrowth): EChartsOption {
  const gradient = (from: string, to: string) => ({
    type: "linear" as const,
    x: 0, y: 0, x2: 0, y2: 1,
    colorStops: [
      { offset: 0, color: from },
      { offset: 1, color: to },
    ],
  });
  return {
    grid: { left: 40, right: 20, top: 60, bottom: 68 },
    legend: {
      top: 0,
      right: 0,
      icon: "roundRect",
      itemWidth: 8,
      itemHeight: 8,
      textStyle: { color: "#6b7280", fontSize: 11 },
      itemGap: 16,
    },
    xAxis: {
      type: "category",
      data: data.days ?? [],
      boundaryGap: false,
      axisLabel: { color: "#9ca3af", fontSize: 10 },
      axisLine: { lineStyle: { color: "#e8eaed" } },
      axisTick: { show: false },
    },
    yAxis: [
      {
        type: "value",
        name: "数量",
        minInterval: 1,
        axisLabel: { color: "#9ca3af", fontSize: 10 },
        splitLine: { lineStyle: { color: "#f3f4f6" } },
      },
      {
        type: "value",
        name: "环比",
        axisLabel: { color: "#9ca3af", fontSize: 10, formatter: PERCENT_FORMATTER },
        splitLine: { show: false },
      },
    ],
    dataZoom: [
      { type: "inside" },
      {
        type: "slider",
        height: 24,
        bottom: 24,
        borderColor: "transparent",
        backgroundColor: "#f3f4f6",
        fillerColor: "rgba(37,99,235,.08)",
        handleSize: "80%",
        handleStyle: { color: "#2563eb", borderRadius: 4 },
        textStyle: { fontSize: 10, color: "#9ca3af" },
        moveHandleSize: 8,
        showDetail: false,
      },
    ],
    series: [
      {
        name: "新增候选人",
        type: "bar",
        data: data.daily_new ?? [],
        barMaxWidth: 18,
        itemStyle: { borderRadius: [3, 3, 0, 0], color: "rgba(37,99,235,.25)" },
      },
      {
        name: "人才库总量",
        type: "line",
        smooth: true,
        showSymbol: false,
        data: data.cumulative_total ?? [],
        lineStyle: { color: "#4F46E5", width: 2.5 },
        itemStyle: { color: "#4F46E5" },
        areaStyle: { color: gradient("rgba(79,70,229,.15)", "rgba(255,255,255,0)") },
      },
      {
        name: "环比增长率",
        type: "line",
        smooth: true,
        showSymbol: false,
        yAxisIndex: 1,
        connectNulls: false,
        data: data.growth_rate ?? [],
        lineStyle: { color: "#F59E0B", width: 2.5, type: "dashed" },
        itemStyle: { color: "#F59E0B" },
        tooltip: { valueFormatter: PERCENT_FORMATTER },
      },
    ],
    tooltip: {
      trigger: "axis",
      backgroundColor: "#fff",
      borderColor: "#e8eaed",
      textStyle: { color: "#111827", fontSize: 12 },
    },
  };
}

export function TalentPoolGrowthPanel() {
  const query = useTalentPoolGrowthQuery();

  if (query.isPending) {
    return (
      <Card className="talent-pool-growth" title={<TitleWithHint label="人才库增长趋势" hint="环比增长率 = (当日新增 − 前一日新增) ÷ 前一日新增" />}>
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </Card>
    );
  }

  if (query.isError || !query.data) {
    return (
      <Card className="talent-pool-growth" title={<TitleWithHint label="人才库增长趋势" hint="环比增长率 = (当日新增 − 前一日新增) ÷ 前一日新增" />}>
        <Empty description="加载失败" />
      </Card>
    );
  }

  const summary = query.data.summary ?? { total: 0, recent_new: 0, latest_growth_rate: null };
  const hasData =
    summary.total > 0
    || (query.data.daily_new ?? []).some((value) => value > 0)
    || (query.data.cumulative_total ?? []).some((value) => value > 0);

  return (
    <Card className="talent-pool-growth" title={<TitleWithHint label="人才库增长趋势" hint="环比增长率 = (当日新增 − 前一日新增) ÷ 前一日新增" />}>
      {hasData ? (
        <EChart option={growthOption(query.data)} height={310} />
      ) : (
        <Empty description="暂无数据" />
      )}
    </Card>
  );
}