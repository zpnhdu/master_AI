import { Card, Empty, Spin } from "antd";
import type { EChartsOption } from "echarts";

import { EChart } from "../../../shared/EChart";
import { useStagePassRateTrendQuery } from "../hooks";

const PERCENT_FORMATTER = (value: unknown) =>
  `${(Math.round(Number(value) * 1000) / 10).toFixed(0)}%`;

function trendOption(days: string[], screening: (number | null)[], interview: (number | null)[]): EChartsOption {
  const gradient = (from: string, to: string) => ({
    type: "linear" as const,
    x: 0, y: 0, x2: 0, y2: 1,
    colorStops: [
      { offset: 0, color: from },
      { offset: 1, color: to },
    ],
  });
  return {
    grid: { left: 40, right: 20, top: 40, bottom: 68 },
    legend: {
      top: 0,
      right: 0,
      icon: "roundRect",
      itemWidth: 8,
      itemHeight: 8,
      textStyle: { color: "#6b7280", fontSize: 11 },
      itemGap: 16,
    },
    xAxis: {
      type: "category",
      data: days,
      boundaryGap: false,
      axisLabel: { color: "#9ca3af", fontSize: 10 },
      axisLine: { lineStyle: { color: "#e8eaed" } },
      axisTick: { show: false },
    },
    yAxis: {
      type: "value",
      max: 1,
      axisLabel: { color: "#9ca3af", fontSize: 10, formatter: PERCENT_FORMATTER },
      splitLine: { lineStyle: { color: "#f3f4f6" } },
    },
    dataZoom: [
      { type: "inside" },
      {
        type: "slider",
        height: 24,
        bottom: 24,
        borderColor: "transparent",
        backgroundColor: "#f3f4f6",
        fillerColor: "rgba(37,99,235,.08)",
        handleSize: "80%",
        handleStyle: { color: "#2563eb", borderRadius: 4 },
        textStyle: { fontSize: 10, color: "#9ca3af" },
        moveHandleSize: 8,
        showDetail: false,
      },
    ],
    series: [
      {
        name: "初筛通过率",
        type: "line",
        smooth: true,
        showSymbol: false,
        data: screening,
        connectNulls: true,
        lineStyle: { color: "#2563eb", width: 2.5 },
        itemStyle: { color: "#2563eb" },
        areaStyle: { color: gradient("rgba(37,99,235,.15)", "rgba(255,255,255,0)") },
      },
      {
        name: "面试通过率",
        type: "line",
        smooth: true,
        showSymbol: false,
        data: interview,
        connectNulls: true,
        lineStyle: { color: "#0EA5A6", width: 2.5, type: "dashed" },
        itemStyle: { color: "#0EA5A6" },
      },
    ],
    tooltip: {
      trigger: "axis",
      backgroundColor: "#fff",
      borderColor: "#e8eaed",
      textStyle: { color: "#111827", fontSize: 12 },
      valueFormatter: (value: unknown) => (value == null ? "—" : PERCENT_FORMATTER(value)),
    },
  };
}

export function StagePassRateTrendPanel() {
  const query = useStagePassRateTrendQuery();

  if (query.isPending) {
    return (
      <Card className="stage-pass-rate-trend" title="各环节通过率趋势">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </Card>
    );
  }

  if (query.isError || !query.data) {
    return (
      <Card className="stage-pass-rate-trend" title="各环节通过率趋势">
        <Empty description="加载失败" />
      </Card>
    );
  }

  const days = query.data.days ?? [];
  const screening = query.data.screening_pass_rate ?? [];
  const interview = query.data.interview_pass_rate ?? [];
  const hasData = screening.some((v) => v != null) || interview.some((v) => v != null);

  return (
    <Card className="stage-pass-rate-trend" title="各环节通过率趋势">
      {hasData ? (
        <EChart option={trendOption(days, screening, interview)} height={340} />
      ) : (
        <Empty description="暂无数据" />
      )}
    </Card>
  );
}
