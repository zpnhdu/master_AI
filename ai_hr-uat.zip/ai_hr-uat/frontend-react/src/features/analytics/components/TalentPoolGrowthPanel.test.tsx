import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { TalentPoolGrowthPanel } from "./TalentPoolGrowthPanel";

vi.mock("../../../shared/EChart", () => ({
  EChart: ({ option }: { option: { series: Array<{ name: string }> } }) => (
    <div data-testid="echart">{JSON.stringify(option.series.map((item) => item.name))}</div>
  ),
}));

const queryMock = vi.fn();

vi.mock("../hooks", () => ({
  useTalentPoolGrowthQuery: () => queryMock(),
}));

describe("TalentPoolGrowthPanel", () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    queryMock.mockReset();
  });

  it("renders a loading state while the query is pending", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: true, isError: false });
    render(<TalentPoolGrowthPanel />);
    expect(screen.getByText("人才库增长趋势")).toBeInTheDocument();
    expect(screen.getByText(/加载中/)).toBeInTheDocument();
  });

  it("renders the combo chart with data", () => {
    queryMock.mockReturnValue({
      data: {
        days: ["07-29", "07-30"],
        daily_new: [1, 3],
        cumulative_total: [4, 7],
        growth_rate: [null, 2.0],
        summary: { total: 7, recent_new: 4, latest_growth_rate: 2.0 },
      },
      isPending: false,
      isError: false,
    });
    render(<TalentPoolGrowthPanel />);
    const chart = screen.getByTestId("echart");
    expect(chart.textContent).toContain("新增候选人");
    expect(chart.textContent).toContain("人才库总量");
    expect(chart.textContent).toContain("环比增长率");
  });

  it("shows an empty placeholder when data is empty", () => {
    queryMock.mockReturnValue({
      data: {
        days: [],
        daily_new: [],
        cumulative_total: [],
        growth_rate: [],
        summary: { total: 0, recent_new: 0, latest_growth_rate: null },
      },
      isPending: false,
      isError: false,
    });
    render(<TalentPoolGrowthPanel />);
    expect(screen.getByText("暂无数据")).toBeInTheDocument();
  });

  it("shows an error placeholder when the query fails", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: false, isError: true });
    render(<TalentPoolGrowthPanel />);
    expect(screen.getByText("加载失败")).toBeInTheDocument();
  });
});