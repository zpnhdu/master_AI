import { useMemo } from "react";
import { Card, Empty, Spin, Typography } from "antd";
import type { EChartsOption } from "echarts";

import { EChart } from "../../../shared/EChart";
import { useTalentAttritionQuery } from "../hooks";
import type { TalentAttrition } from "../api";

type AttritionKey = keyof TalentAttrition;

const SLICES: Array<{ key: AttritionKey; title: string; color: string }> = [
  { key: "job_mismatch", title: "岗位不匹配", color: "#2563eb" },
  { key: "screening_reject", title: "初筛不通过", color: "#16A34A" },
  { key: "interview_reject", title: "面试不通过", color: "#D97706" },
  { key: "interview_declined", title: "拒绝面试", color: "#DC2626" },
];

function combinedDoughnutOption(slices: Array<{ name: string; value: number; color: string }>): EChartsOption {
  return {
    tooltip: { trigger: "item", formatter: "{b}: {c} 人 ({d}%)" },
    series: [
      {
        type: "pie",
        radius: ["44%", "80%"],
        center: ["50%", "50%"],
        label: { show: false },
        emphasis: {
          label: { show: true, fontSize: 14, fontWeight: "bold" },
        },
        data: slices.map((s) => ({
          name: s.name,
          value: s.value,
          itemStyle: { color: s.color },
        })),
      },
    ],
  };
}

export function TalentAttritionPanel() {
  const query = useTalentAttritionQuery();

  const total = Number(query.data?.attrition_total) || 0;
  const hasData = total > 0;

  const sliceData = useMemo(
    () =>
      SLICES.map(({ key, title, color }) => ({
        name: title,
        value: Number(query.data?.[key]) || 0,
        color,
      })),
    [query.data],
  );

  if (query.isPending) {
    return (
      <Card className="talent-attrition" title="人才流失分析">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </Card>
    );
  }

  if (query.isError || !query.data) {
    return (
      <Card className="talent-attrition" title="人才流失分析">
        <Empty description="加载失败" />
      </Card>
    );
  }

  return (
    <Card className="talent-attrition" title="人才流失分析">
      {/* <Typography.Paragraph type="secondary" className="talent-attrition__hint">
        统计口径：当前租户有效招聘流水线（排除已归档、废弃、取消等终态）；按 resume_id 去重，无简历号时回退 candidate_id，流失原因分别为岗位不匹配、初筛不通过、面试不通过与拒绝面试。
      </Typography.Paragraph> */}
      {hasData ? (
        <div className="talent-attrition__chart-row">
          <EChart option={combinedDoughnutOption(sliceData)} height={240} />
          <div className="talent-attrition__legend">
            {sliceData.map((item) => (
              <div key={item.name} className="talent-attrition__legend-item">
                <span className="talent-attrition__legend-dot" style={{ background: item.color }} />
                <span>{item.name}</span>
                <span className="talent-attrition__legend-value">
                  {item.value}人
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <Empty description="暂无数据" />
      )}
    </Card>
  );
}
