import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { TalentAttritionPanel } from "./TalentAttritionPanel";

vi.mock("../../../shared/EChart", () => ({
  EChart: ({ option }: { option: { series: Array<{ data: unknown }> } }) => (
    <div data-testid="echart">{JSON.stringify(option.series[0].data)}</div>
  ),
}));

const queryMock = vi.fn();

vi.mock("../hooks", () => ({
  useTalentAttritionQuery: () => queryMock(),
}));

describe("TalentAttritionPanel", () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    queryMock.mockReset();
  });

  it("renders a loading state while the attrition query is pending", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: true, isError: false });
    render(<TalentAttritionPanel />);
    expect(screen.getByText("人才流失分析")).toBeInTheDocument();
    expect(screen.getByText(/加载中/)).toBeInTheDocument();
  });

  it("renders four doughnut charts with their titles when data is ready", () => {
    queryMock.mockReturnValue({
      data: { job_mismatch: 3, screening_reject: 2, interview_reject: 1, interview_declined: 4, attrition_total: 10 },
      isPending: false,
      isError: false,
    });
    render(<TalentAttritionPanel />);
    for (const title of ["岗位不匹配", "初筛不通过", "面试不通过", "拒绝面试"]) {
      expect(screen.getByText(title)).toBeInTheDocument();
    }
    expect(screen.getAllByTestId("echart")).toHaveLength(1);
    expect(screen.queryByText(/加载中/)).not.toBeInTheDocument();
  });

  it("shows an empty placeholder when all four counts are zero", () => {
    queryMock.mockReturnValue({
      data: { job_mismatch: 0, screening_reject: 0, interview_reject: 0, interview_declined: 0 },
      isPending: false,
      isError: false,
    });
    render(<TalentAttritionPanel />);
    expect(screen.queryByTestId("echart")).not.toBeInTheDocument();
    expect(screen.getByText("暂无数据")).toBeInTheDocument();
  });
});