import { cleanup, render, screen } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { HrPerformancePanel } from "./HrPerformancePanel";

const queryMock = vi.fn();

// 将 Tooltip 的提示文字内联渲染，便于直接断言统计口径文案。
vi.mock("antd", async (importOriginal) => {
  const actual = await importOriginal<typeof import("antd")>();
  return {
    ...actual,
    Tooltip: ({ title, children }: { title?: string; children?: ReactNode }) => (
      <>
        {children}
        {typeof title === "string" ? <span>{title}</span> : null}
      </>
    ),
  };
});

vi.mock("../hooks", () => ({
  useHrPerformanceQuery: () => queryMock(),
}));

describe("HrPerformancePanel", () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    queryMock.mockReset();
  });

  it("renders a loading state while the query is pending", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: true, isError: false, refetch: vi.fn() });
    render(<HrPerformancePanel />);
    expect(screen.getByText("HR 工作观察")).toBeInTheDocument();
    expect(document.querySelector(".ant-spin-spinning")).toBeTruthy();
  });

  it("renders one row per HR with formatted rates and response days", () => {
    queryMock.mockReturnValue({
      data: {
        hrs: [
          {
            hr_id: "u1",
            name: "HR甲",
            jobs: 2,
            resumes: 10,
            interviewed: 10,
            interviews: 6,
            pass_rate: 0.6,
            response_days: 3.9,
          },
          {
            hr_id: "u2",
            name: "HR乙",
            jobs: 1,
            resumes: 0,
            interviewed: 0,
            interviews: 0,
            pass_rate: null,
            response_days: null,
          },
        ],
      },
      isPending: false,
      isError: false,
      refetch: vi.fn(),
    });
    render(<HrPerformancePanel />);
    expect(screen.getByText("HR甲")).toBeInTheDocument();
    expect(screen.getByText("HR乙")).toBeInTheDocument();
    expect(screen.getByText("60%")).toBeInTheDocument();
    expect(screen.getByText("3.9")).toBeInTheDocument();
    // 无分母的通过率与无流水线的响应时间显示占位符
    expect(screen.getAllByText("—").length).toBeGreaterThanOrEqual(2);
    expect(screen.getAllByText("面试（参加）").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText("小面通过（小评通过）").length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText(/通过率 = 小评通过数 ÷ 小筛通过数/).length).toBeGreaterThanOrEqual(1);
  });

  it("shows an error placeholder when the query fails", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: false, isError: true, refetch: vi.fn() });
    render(<HrPerformancePanel />);
    expect(screen.getByText("加载失败")).toBeInTheDocument();
  });
});
