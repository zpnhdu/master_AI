import { Card, Empty, Spin, Typography } from "antd";
import type { EChartsOption } from "echarts";

import { EChart } from "../../../shared/EChart";
import { useTalentPoolSummaryQuery } from "../hooks";
import type { TalentPoolDistributionSlice } from "../api";

type SliceKey = "gender" | "education" | "location" | "years_experience";

const SLICES: Array<{ key: SliceKey; title: string }> = [
  { key: "gender", title: "性别分布" },
  { key: "education", title: "学历分布" },
  { key: "location", title: "区域分布" },
  { key: "years_experience", title: "工作年限分布" },
];

function doughnutOption(items: TalentPoolDistributionSlice): EChartsOption {
  return {
    tooltip: { trigger: "item" },
    legend: {
      bottom: 0,
      itemWidth: 10,
      itemHeight: 10,
      height: Math.ceil(items.length / 4) * 20,
    },
    series: [{
      type: "pie",
      radius: ["38%", "68%"],
      center: ["50%", "42%"],
      label: { show: false },
      data: items.map((item) => ({ name: item.name, value: item.value })),
    }],
  };
}

export function TalentPoolSummaryPanel() {
  const query = useTalentPoolSummaryQuery();

  if (query.isPending) {
    return (
      <Card className="talent-pool-summary" title="候选人指标汇总">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </Card>
    );
  }

  if (query.isError || !query.data) {
    return (
      <Card className="talent-pool-summary" title="候选人指标汇总">
        <Empty description="加载失败" />
      </Card>
    );
  }

  return (
    <Card className="talent-pool-summary" title="候选人指标汇总">
      <div className="talent-pool-summary__grid">
        {SLICES.map(({ key, title }) => {
          const items = query.data[key] ?? [];
          return (
            <div key={key} className="talent-pool-summary__cell">
              <div className="talent-pool-summary__cell-title">{title}</div>
              {items.length ? (
                <EChart option={doughnutOption(items)} height={220} />
              ) : (
                <Empty description="暂无数据" />
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}