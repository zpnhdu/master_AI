import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { TalentPoolSummaryPanel } from "./TalentPoolSummaryPanel";

vi.mock("../../../shared/EChart", () => ({
  EChart: ({ option }: { option: { series: Array<{ data: unknown }> } }) => (
    <div data-testid="echart">{JSON.stringify(option.series[0].data)}</div>
  ),
}));

const queryMock = vi.fn();

vi.mock("../hooks", () => ({
  useTalentPoolSummaryQuery: () => queryMock(),
}));

describe("TalentPoolSummaryPanel", () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    queryMock.mockReset();
  });

  it("renders a loading state while the summary query is pending", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: true, isError: false });
    render(<TalentPoolSummaryPanel />);
    expect(screen.getByText("候选人指标汇总")).toBeInTheDocument();
    expect(screen.getByText(/加载中/)).toBeInTheDocument();
  });

  it("renders four doughnut charts with their titles when data is ready", () => {
    queryMock.mockReturnValue({
      data: {
        gender: [{ name: "男", value: 2 }],
        education: [{ name: "本科", value: 2 }],
        location: [{ name: "上海", value: 2 }],
        years_experience: [{ name: "1-3年", value: 2 }],
      },
      isPending: false,
      isError: false,
    });
    render(<TalentPoolSummaryPanel />);
    for (const title of ["性别分布", "学历分布", "区域分布", "工作年限分布"]) {
      expect(screen.getByText(title)).toBeInTheDocument();
    }
    expect(screen.getAllByTestId("echart")).toHaveLength(4);
    expect(screen.queryByText(/加载中/)).not.toBeInTheDocument();
  });

  it("shows an empty placeholder for slices without rows", () => {
    queryMock.mockReturnValue({
      data: { gender: [], education: [], location: [], years_experience: [] },
      isPending: false,
      isError: false,
    });
    render(<TalentPoolSummaryPanel />);
    expect(screen.queryByTestId("echart")).not.toBeInTheDocument();
    expect(screen.getAllByText("暂无数据")).toHaveLength(4);
  });
});