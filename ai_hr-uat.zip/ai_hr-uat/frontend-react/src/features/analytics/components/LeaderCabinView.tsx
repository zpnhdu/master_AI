﻿import { InboxOutlined, MessageOutlined, PlusOutlined, ReloadOutlined, SendOutlined } from "@ant-design/icons";
import { Alert, Button, Card, Empty, Input, Space, Spin, Typography } from "antd";
import { useEffect, useMemo, useRef, useState } from "react";
import type { EChartsOption } from "echarts";

import type { LeaderChatChart, LeaderChatMessage } from "../api";
import { streamLeaderChatMessage } from "../api";
import {
  useArchiveLeaderChatSessionMutation,
  useCreateLeaderChatSessionMutation,
  useLeaderChatMessagesQuery,
  useLeaderChatSessionsQuery,
} from "../hooks";
import { EChart } from "../../../shared/EChart";
import { TalentPoolSummaryPanel } from "./TalentPoolSummaryPanel";
import { TalentPoolGrowthPanel } from "./TalentPoolGrowthPanel";
import { TalentAttritionPanel } from "./TalentAttritionPanel";
import { StagePassRateTrendPanel } from "./StagePassRateTrendPanel";
import { HrPerformancePanel } from "./HrPerformancePanel";

export type LeaderCabinMessage = LeaderChatMessage & {
  clientRequestId?: string;
  error?: boolean;
};

export function chartOption(chart: LeaderChatChart): EChartsOption | null {
  if (!chart || typeof chart !== "object") return null;
  if (chart.kind === "line" || chart.kind === "bar") {
    if (
      !Array.isArray(chart.categories)
      || chart.categories.length > 50
      || chart.categories.some((item) => typeof item !== "string")
      || !Array.isArray(chart.series)
      || !chart.series.length
      || chart.series.some((series) => (
        !series || typeof series.name !== "string"
        || !Array.isArray(series.values)
        || series.values.length !== chart.categories.length
        || series.values.length > 50
        || series.values.some((value) => typeof value !== "number" || !Number.isFinite(value))
      ))
    ) return null;
    return {
      title: { text: chart.title, left: 0, textStyle: { fontSize: 14, fontWeight: 600 } },
      grid: { left: 42, right: 18, top: 48, bottom: 34 },
      tooltip: { trigger: "axis" },
      xAxis: { type: "category", data: chart.categories },
      yAxis: { type: "value" },
      series: chart.series.map((series) => ({
        name: series.name,
        type: chart.kind,
        data: series.values,
        ...(series.unit ? { name: `${series.name} (${series.unit})` } : {}),
      })),
    };
  }
  if (chart.kind === "pie") {
    if (
      !Array.isArray(chart.items)
      || chart.items.length > 50
      || chart.items.some((item) => (
        !item || typeof item.name !== "string"
        || typeof item.value !== "number"
        || !Number.isFinite(item.value)
      ))
    ) return null;
    return {
      title: { text: chart.title, left: 0, textStyle: { fontSize: 14, fontWeight: 600 } },
      tooltip: { trigger: "item" },
      series: [{ type: "pie", radius: ["35%", "68%"], top: 30, data: chart.items }],
    };
  }
  if (chart.kind === "radar") {
    if (
      !Array.isArray(chart.indicators)
      || chart.indicators.length > 50
      || chart.indicators.some((item) => (
        !item || typeof item.name !== "string"
        || typeof item.max !== "number"
        || !Number.isFinite(item.max)
      ))
      || !Array.isArray(chart.series)
      || !chart.series.length
      || chart.series.some((series) => (
        !series || typeof series.name !== "string"
        || !Array.isArray(series.values)
        || series.values.length !== chart.indicators.length
        || series.values.some((value) => typeof value !== "number" || !Number.isFinite(value))
      ))
    ) return null;
    return {
      title: { text: chart.title, left: 0, textStyle: { fontSize: 14, fontWeight: 600 } },
      radar: { indicator: chart.indicators },
      series: [{
        type: "radar",
        data: chart.series.map((series) => ({ name: series.name, value: series.values })),
      }],
    };
  }
  return null;
}

function createClientRequestId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `leader-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function messageKey(message: LeaderCabinMessage, index: number): string | number {
  return message.id ?? message.request_id ?? message.clientRequestId ?? index;
}

function replaceLastAssistant(messages: LeaderCabinMessage[], update: Partial<LeaderCabinMessage>) {
  const next = [...messages];
  const index = next.length - 1;
  if (next[index]?.role === "assistant") next[index] = { ...next[index], ...update };
  return next;
}

function appendLastAssistant(messages: LeaderCabinMessage[], appendText: string) {
  const next = [...messages];
  const index = next.length - 1;
  if (next[index]?.role === "assistant") {
    next[index] = { ...next[index], content: (next[index].content ?? "") + appendText };
  }
  return next;
}

export function LeaderCabinView() {
  const sessionsQuery = useLeaderChatSessionsQuery();
  const createMutation = useCreateLeaderChatSessionMutation();
  const archiveMutation = useArchiveLeaderChatSessionMutation();
  const [sessionId, setSessionId] = useState<string>();
  const [messages, setMessages] = useState<LeaderCabinMessage[]>([]);
  const [input, setInput] = useState("");
  const [initializing, setInitializing] = useState(true);
  const [initializationError, setInitializationError] = useState<string>();
  const [activeRequest, setActiveRequest] = useState<string>();
  const [chatOpen, setChatOpen] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const initializedRef = useRef(false);
  const historyQuery = useLeaderChatMessagesQuery(sessionId);

  useEffect(() => {
    if (initializedRef.current || sessionsQuery.isPending) return;
    if (sessionsQuery.isError) {
      setInitializationError("分析会话加载失败");
      setInitializing(false);
      return;
    }
    initializedRef.current = true;
    const existing = sessionsQuery.data?.sessions?.[0];
    if (existing) {
      setSessionId(existing.id);
      setInitializing(false);
      return;
    }
    void createMutation.mutateAsync()
      .then((result) => {
        setSessionId(result.session.id);
        setInitializing(false);
      })
      .catch((error: unknown) => {
        setInitializationError(error instanceof Error ? error.message : "创建分析会话失败");
        setInitializing(false);
      });
  }, [createMutation, sessionsQuery.data, sessionsQuery.isError, sessionsQuery.isPending]);

  useEffect(() => {
    if (!historyQuery.data) return;
    setMessages([
      ...(historyQuery.data.messages ?? []),
      {
        role: "assistant",
        content: "您好，我是您的AI助手。您可以问我关于招聘漏斗、岗位、HR对比等方面的问题",
      },
    ]);
  }, [historyQuery.data]);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollTop = el.scrollHeight;
    });
  }, [messages]);

  const chartOptions = useMemo(() => {
    const options = new Map<string | number, EChartsOption>();
    messages.forEach((item, index) => {
      if (item.role !== "assistant" || !item.chart_spec || "kind" in item.chart_spec === false) return;
      const option = chartOption(item.chart_spec as LeaderChatChart);
      if (option) options.set(messageKey(item, index), option);
    });
    return options;
  }, [messages]);

  async function sendMessage(message: string, clientRequestId = createClientRequestId(), replaceFrom?: number) {
    const question = message.trim();
    if (!question || !sessionId || activeRequest) return;
    setInput("");
    setActiveRequest(clientRequestId);
    setMessages((current) => {
      const base = replaceFrom === undefined
        ? current
        : current.slice(0, replaceFrom + 1).map((item, index) => (
          index === replaceFrom ? { ...item, clientRequestId } : item
        ));
      return replaceFrom === undefined
        ? [...base, { role: "user", content: question, clientRequestId }, { role: "assistant", content: "", clientRequestId }]
        : [...base, { role: "assistant", content: "", clientRequestId }];
    });
    try {
      await streamLeaderChatMessage(
        {
          session_id: sessionId,
          message: question,
          client_request_id: clientRequestId,
        },
        (event) => {
          if (event.type === "data") {
            setMessages((current) => replaceLastAssistant(current, {
              content: event.text,
              chart_spec: event.chart ?? {},
            }));
          } else if (event.type === "content") {
            setMessages((current) => appendLastAssistant(current, event.content));
          } else if (event.type === "done") {
            setMessages((current) => replaceLastAssistant(current, {
              chart_spec: event.chart ?? {},
              request_id: event.request_id,
            }));
          } else if (event.type === "error") {
            setMessages((current) => replaceLastAssistant(current, {
              content: event.error,
              error: true,
            }));
          }
        },
      );
    } catch (error: unknown) {
      setMessages((current) => replaceLastAssistant(current, {
        content: error instanceof Error ? error.message : "本次分析暂时无法完成，请稍后重试",
        error: true,
      }));
    } finally {
      setActiveRequest(undefined);
    }
  }

  function retryMessage(message: LeaderCabinMessage) {
    if (!message.clientRequestId || !message.content || !sessionId) return;
    const userIndex = messages.findIndex((item) => item.clientRequestId === message.clientRequestId && item.role === "user");
    const question = userIndex >= 0 ? messages[userIndex].content : "";
    if (!question) return;
    void sendMessage(question, createClientRequestId(), userIndex);
  }

  async function startNewSession() {
    if (activeRequest) return;
    try {
      const result = await createMutation.mutateAsync();
      setSessionId(result.session.id);
      setMessages([]);
    } catch (error: unknown) {
      setInitializationError(error instanceof Error ? error.message : "创建分析会话失败");
    }
  }

  async function archiveCurrentSession() {
    if (!sessionId || activeRequest) return;
    await archiveMutation.mutateAsync(sessionId);
    await startNewSession();
  }

  if (initializationError) {
    return <Alert type="error" showIcon message="加载失败" description={initializationError} action={<Button icon={<ReloadOutlined />} onClick={() => window.location.reload()}>重试</Button>} />;
  }
  if (initializing || !sessionId) {
    return <div className="app-loading"><Spin size="large" tip="加载中" /></div>;
  }

  return (
    <div className="leader-cabin">
      <div className="leader-cabin__row">
        <HrPerformancePanel />
        <StagePassRateTrendPanel />
      </div>
      <div className="leader-cabin__row">
        <TalentPoolGrowthPanel />
        <TalentAttritionPanel />
      </div>
      <TalentPoolSummaryPanel />
      <button
        type="button"
        className="leader-cabin__chat-fab"
        aria-label="AI助手"
        onClick={() => setChatOpen((v) => !v)}
      >
        <MessageOutlined />
      </button>
      {chatOpen ? (
        <Card
          className="leader-cabin__chat-overlay"
          title="AI助手"
          size="small"
          extra={
            <Space>
              {/* <Button type="text" icon={<PlusOutlined />} onClick={() => void startNewSession()} disabled={Boolean(activeRequest)} aria-label="新建会话" /> */}
              {/* <Button type="text" icon={<InboxOutlined />} onClick={() => void archiveCurrentSession()} disabled={Boolean(activeRequest)} aria-label="归档会话" /> */}
              <Button type="text" onClick={() => setChatOpen(false)} aria-label="关闭对话">✕</Button>
            </Space>
          }
        >
          <div ref={listRef} className="leader-cabin__messages">
            {!messages.length ? <Empty description="开始询问招聘数据" /> : null}
            {messages.map((item, index) => {
              const option = item.role === "assistant" && item.chart_spec && "kind" in item.chart_spec
                ? chartOptions.get(messageKey(item, index))
                : undefined;
              return (
                <div key={`${item.request_id ?? item.clientRequestId ?? "message"}-${index}`} className={`leader-cabin__message leader-cabin__message--${item.role}`}>
                  <Typography.Paragraph className="leader-cabin__message-text">{item.content || (activeRequest === item.clientRequestId ? "正在分析…" : "")}</Typography.Paragraph>
                  {option ? <EChart option={option} height={220} className="leader-cabin__chart" /> : null}
                  {item.error ? <Button type="link" size="small" icon={<ReloadOutlined />} onClick={() => retryMessage(item)}>重试</Button> : null}
                </div>
              );
            })}
            {historyQuery.isPending ? <Spin size="small" /> : null}
          </div>
          <Space.Compact className="leader-cabin__composer">
            <Input
              value={input}
              maxLength={2000}
              placeholder="询问招聘漏斗、岗位或 HR 对比…"
              disabled={Boolean(activeRequest)}
              onChange={(event) => setInput(event.target.value)}
              onPressEnter={() => void sendMessage(input)}
            />
            <Button type="primary" icon={<SendOutlined />} onClick={() => void sendMessage(input)} disabled={!input.trim() || Boolean(activeRequest)} loading={Boolean(activeRequest)}>
              发送
            </Button>
          </Space.Compact>
        </Card>
      ) : null}
    </div>
  );
}
