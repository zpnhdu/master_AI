import { describe, expect, it } from "vitest";

import { chartOption } from "./LeaderCabinView";

const lineChart = {
  kind: "line" as const,
  title: "趋势",
  categories: ["周一", "周二"],
  series: [{ name: "新增候选人", values: [1, 2] }],
};

describe("leader cabin chart builder", () => {
  it("converts all supported semantic chart shapes", () => {
    expect(chartOption(lineChart)?.series).toEqual([{ name: "新增候选人", type: "line", data: [1, 2] }]);
    expect(
      chartOption({
        kind: "bar",
        title: "对比",
        categories: ["甲"],
        series: [{ name: "录用", values: [3], unit: "%" }],
      })?.series,
    ).toEqual([{ name: "录用 (%)", type: "bar", data: [3] }]);
    expect(
      chartOption({
        kind: "pie",
        title: "来源",
        items: [{ name: "内推", value: 4 }],
      })?.series,
    ).toEqual([{ type: "pie", radius: ["35%", "68%"], top: 30, data: [{ name: "内推", value: 4 }] }]);
    expect(
      chartOption({
        kind: "radar",
        title: "能力",
        indicators: [{ name: "沟通", max: 10 }],
        series: [{ name: "候选人", values: [8] }],
      })?.series,
    ).toEqual([{ type: "radar", data: [{ name: "候选人", value: [8] }] }]);
  });

  it("rejects malformed or oversized numeric data", () => {
    expect(
      chartOption({
        ...lineChart,
        series: [{ name: "趋势", values: [Number.NaN, 2] }],
      }),
    ).toBeNull();
    expect(
      chartOption({
        kind: "pie",
        title: "非法",
        items: [{ name: "x", value: Number.POSITIVE_INFINITY }],
      }),
    ).toBeNull();
    expect(chartOption({ kind: "scatter", title: "未知" } as never)).toBeNull();
    expect(
      chartOption({
        ...lineChart,
        categories: Array.from({ length: 51 }, (_, index) => String(index)),
        series: [{ name: "趋势", values: Array.from({ length: 51 }, () => 1) }],
      }),
    ).toBeNull();
  });
});
