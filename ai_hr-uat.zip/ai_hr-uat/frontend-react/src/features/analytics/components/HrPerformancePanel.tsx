import { Card, Space, Tooltip } from "antd";

import { DataTable } from "../../../shared/data-table";
import type { DataTableInputColumn } from "../../../shared/data-table";
import { useHrPerformanceQuery } from "../hooks";
import type { HrPerformanceRow } from "../api";

function formatRate(value: number | null | undefined): string {
  if (value == null) return "—";
  return `${Math.round(Number(value) * 1000) / 10}%`;
}

const HINT_ICON = (
  <svg
    viewBox="0 0 1024 1024"
    width="14"
    height="14"
    fill="#6b7280"
    style={{ cursor: "help", marginLeft: 2 }}
  >
    <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 010-96 48.01 48.01 0 010 96z" />
  </svg>
);

function HintTooltip({ title }: { title: string }) {
  return (
    <Tooltip
      placement="right"
      title={title}
      overlayInnerStyle={{
        backgroundColor: "#ffffff",
        color: "#111827",
        border: "1px solid #93c5fd",
        borderRadius: "8px",
        boxShadow: "0 4px 12px rgba(37, 99, 235, 0.12)",
      }}
      arrow={false}
    >
      {HINT_ICON}
    </Tooltip>
  );
}

function TitleWithHint({ label, hint }: { label: string; hint: string }) {
  return (
    <Space size={4}>
      <span>{label}</span>
      <HintTooltip title={hint} />
    </Space>
  );
}

const COLUMNS: DataTableInputColumn<HrPerformanceRow>[] = [
  { title: "HR", dataIndex: "name", key: "name", width: 96 },
  { title: "岗位", dataIndex: "jobs", key: "jobs", width: 56, align: "center" },
  {
    title: <TitleWithHint label="简历" hint="小筛通过数量" />,
    dataIndex: "resumes",
    key: "resumes",
    width: 68,
    align: "center",
  },
  {
    title: <TitleWithHint label="面试（参加）" hint="参加面试人数（含未通过）" />,
    dataIndex: "interviewed",
    key: "interviewed",
    width: 120,
    align: "center",
  },
  {
    title: <TitleWithHint label="小面通过（小评通过）" hint="小评正式通过人数" />,
    dataIndex: "interviews",
    key: "interviews",
    width: 148,
    align: "center",
  },
  {
    title: <TitleWithHint label="通过率" hint="通过率 = 小评通过数 ÷ 小筛通过数" />,
    key: "pass_rate",
    width: 76,
    align: "center",
    render: (_value: unknown, row: HrPerformanceRow) => formatRate(row.pass_rate),
  },
  {
    title: <TitleWithHint label="响应时间" hint="响应时间 = 小评结束 − 流水线创建 − 候选人面试时长，然后求平均值，单位天" />,
    key: "response_days",
    width: 92,
    align: "center",
    render: (_value: unknown, row: HrPerformanceRow) => (row.response_days == null ? "—" : row.response_days.toFixed(1)),
  },
];

export function HrPerformancePanel() {
  const query = useHrPerformanceQuery();
  const rows = query.data?.hrs ?? [];
  const needsVerticalScroll = rows.length > 7;

  return (
    <Card className="hr-performance" title={<TitleWithHint label="HR 工作观察" hint="仅统计已完成的招聘岗位" />}>
      <DataTable<HrPerformanceRow>
        tableId="hr-performance"
        columns={COLUMNS}
        dataSource={rows}
        rowKey="hr_id"
        compact
        size="middle"
        scroll={needsVerticalScroll ? { y: 300 } : {}}
        loading={query.isPending}
        error={query.isError ? "加载失败" : undefined}
        onRetry={() => query.refetch()}
        emptyText="暂无数据"
      />
    </Card>
  );
}
