import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { StagePassRateTrendPanel } from "./StagePassRateTrendPanel";

vi.mock("../../../shared/EChart", () => ({
  EChart: ({ option }: { option: { series: Array<{ name: string; showSymbol: boolean; connectNulls: boolean }> } }) => (
    <div data-testid="echart">{JSON.stringify(option.series)}</div>
  ),
}));

const queryMock = vi.fn();

vi.mock("../hooks", () => ({
  useStagePassRateTrendQuery: () => queryMock(),
}));

describe("StagePassRateTrendPanel", () => {
  afterEach(() => {
    cleanup();
  });

  beforeEach(() => {
    queryMock.mockReset();
  });

  it("renders a loading state while the trend query is pending", () => {
    queryMock.mockReturnValue({ data: undefined, isPending: true, isError: false });
    render(<StagePassRateTrendPanel />);
    expect(screen.getByText("各环节通过率趋势")).toBeInTheDocument();
    expect(screen.getByText(/加载中/)).toBeInTheDocument();
  });

  it("renders a single line chart with both series when data is ready", () => {
    queryMock.mockReturnValue({
      data: {
        days: ["07-29", "07-30"],
        screening_pass_rate: [0.5, null],
        interview_pass_rate: [null, 0.25],
      },
      isPending: false,
      isError: false,
    });
    render(<StagePassRateTrendPanel />);
    const chart = screen.getByTestId("echart");
    expect(chart.textContent).toContain("初筛通过率");
    expect(chart.textContent).toContain("面试通过率");
    expect(chart.textContent?.match(/"showSymbol":false/g)).toHaveLength(2);
    expect(chart.textContent?.match(/"connectNulls":true/g)).toHaveLength(2);
    expect(screen.queryByText(/加载中/)).not.toBeInTheDocument();
  });

  it("shows an empty placeholder when all rates are null", () => {
    queryMock.mockReturnValue({
      data: {
        days: ["07-29", "07-30"],
        screening_pass_rate: [null, null],
        interview_pass_rate: [null, null],
      },
      isPending: false,
      isError: false,
    });
    render(<StagePassRateTrendPanel />);
    expect(screen.queryByTestId("echart")).not.toBeInTheDocument();
    expect(screen.getByText("暂无数据")).toBeInTheDocument();
  });
});
