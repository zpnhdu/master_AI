import { ApiError, requestWithTimeout } from "../pipelines/api";
import { requestJson } from "../agent-workbench/api";

export type FunnelStageCounts = {
  talent_pool?: number;
  not_applied?: number;
  applied?: number;
  screened?: number;
  interviewed?: number;
  interview_passed?: number;
};

export type DashboardPipeline = {
  id: string;
  role?: string;
  status?: string;
  candidate_count?: number;
  stage_progress?: number;
  [key: string]: unknown;
};

export type DashboardSummary = {
  weekly_new?: number;
  weekly_interviews?: number;
  weekly_interview_passed?: number;
  live_interviews?: number;
  avg_hire_cycle?: number;
  daily_trend?: {
    days?: string[];
    applied?: number[];
    screened?: number[];
    interviewed?: number[];
    interview_passed?: number[];
  };
  [key: string]: unknown;
};

export type DashboardData = {
  funnel?: {
    total_pipelines?: number;
    total_candidates?: number;
    stages?: FunnelStageCounts;
    pipelines?: DashboardPipeline[];
    channel_breakdown?: Record<string, { total?: number; passed?: number }>;
    avg_scores?: Record<string, number>;
  };
  summary?: DashboardSummary;
  [key: string]: unknown;
};

export type LeaderChatSession = {
  id: string;
  tenant_id?: string;
  actor_user_id?: string;
  status: "active" | "archived" | string;
  created_at?: string;
  updated_at?: string;
  archived_at?: string | null;
};

export type LeaderChatChartSeries = {
  name: string;
  values: number[];
  unit?: string;
};

export type LeaderChatChart =
  | {
      kind: "line" | "bar";
      title: string;
      categories: string[];
      series: LeaderChatChartSeries[];
    }
  | {
      kind: "pie";
      title: string;
      items: Array<{ name: string; value: number }>;
    }
  | {
      kind: "radar";
      title: string;
      indicators: Array<{ name: string; max: number }>;
      series: Array<{ name: string; values: number[] }>;
    };

export type LeaderChatMessage = {
  id?: number;
  request_id?: string;
  role: "user" | "assistant";
  content: string;
  chart_spec?: LeaderChatChart | Record<string, never>;
  created_at?: string;
};

export type LeaderChatResponse = {
  text: string;
  chart?: LeaderChatChart | null;
  status: "succeeded" | "failed" | "processing" | string;
  request_id?: string;
};

export function createLeaderChatSession() {
  return requestJson<{ session: LeaderChatSession }>(
    "/api/analytics/leader-chat/sessions",
    { method: "POST" },
    "创建分析会话失败",
  );
}

export function fetchLeaderChatSessions() {
  return requestJson<{ sessions: LeaderChatSession[] }>("/api/analytics/leader-chat/sessions", {}, "分析会话加载失败");
}

export function fetchLeaderChatMessages(sessionId: string) {
  return requestJson<{ session: LeaderChatSession; messages: LeaderChatMessage[] }>(
    `/api/analytics/leader-chat/sessions/${encodeURIComponent(sessionId)}/messages`,
    {},
    "分析历史加载失败",
  );
}

export function archiveLeaderChatSession(sessionId: string) {
  return requestJson<{ session: LeaderChatSession }>(
    `/api/analytics/leader-chat/sessions/${encodeURIComponent(sessionId)}/archive`,
    { method: "POST" },
    "归档分析会话失败",
  );
}

export function sendLeaderChatMessage(payload: { session_id: string; message: string; client_request_id: string }) {
  return requestJson<LeaderChatResponse>(
    "/api/analytics/leader-chat",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    },
    "领导数据分析失败",
  );
}

export type LeaderChatStreamEvent =
  | { type: "data"; text: string; chart: LeaderChatChart | null }
  | { type: "content"; content: string }
  | { type: "done"; request_id?: string; chart?: LeaderChatChart | null }
  | { type: "error"; error: string };

/**
 * 流式调用领导数据舱对话（SSE）。后端 /api/analytics/leader-chat/stream 发射：
 *   {"phase":"data","text":…,"chart":…} → 首帧确定性数字 + 图表
 *   {"content":"…"}                    → 洞察/闲聊逐字增量
 *   {"done":true,"status":"…","request_id":…,"chart":…} → 结束
 *   {"error":"…"}                      → 失败
 * 最后一行 data: [DONE]。
 */
export async function streamLeaderChatMessage(
  payload: { session_id: string; message: string; client_request_id: string },
  onEvent: (event: LeaderChatStreamEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  await requestWithTimeout(
    "/api/analytics/leader-chat/stream",
    {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal,
    },
    async (response) => {
      if (!response.ok || !response.body) {
        const body: unknown = await response.json().catch(() => ({}));
        const detail =
          typeof body === "object" && body !== null && "detail" in body && typeof body.detail === "string"
            ? body.detail
            : `领导数据分析失败（${response.status}）`;
        throw new ApiError(detail, { status: response.status, data: body });
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const data = trimmed.slice(5).trim();
          if (!data) continue;
          if (data === "[DONE]") return;
          let parsed: Record<string, unknown>;
          try {
            parsed = JSON.parse(data) as Record<string, unknown>;
          } catch {
            continue;
          }
          if (typeof parsed.error === "string") {
            onEvent({ type: "error", error: parsed.error });
          } else if (typeof parsed.phase === "string") {
            onEvent({
              type: "data",
              text: typeof parsed.text === "string" ? parsed.text : "",
              chart: normalizeStreamChart(parsed.chart),
            });
          } else if (typeof parsed.content === "string") {
            onEvent({ type: "content", content: parsed.content });
          } else if (parsed.done) {
            onEvent({
              type: "done",
              request_id: typeof parsed.request_id === "string" ? parsed.request_id : undefined,
              chart: normalizeStreamChart(parsed.chart),
            });
          }
        }
      }
    },
  );
}

function normalizeStreamChart(chart: unknown): LeaderChatChart | null {
  if (!chart || typeof chart !== "object" || !("kind" in chart)) return null;
  return chart as LeaderChatChart;
}

export type TalentPoolDistributionSlice = Array<{ name: string; value: number }>;

export type TalentPoolDistribution = {
  gender: TalentPoolDistributionSlice;
  education: TalentPoolDistributionSlice;
  location: TalentPoolDistributionSlice;
  years_experience: TalentPoolDistributionSlice;
};

export type TalentAttrition = {
  talent_pool_total?: number;
  interview_passed?: number;
  attrition_total?: number;
  job_mismatch: number;
  screening_reject: number;
  interview_reject: number;
  interview_declined: number;
};

export type StagePassRateTrend = {
  days: string[];
  screening_pass_rate: (number | null)[];
  interview_pass_rate: (number | null)[];
};

export type HrPerformanceRow = {
  hr_id: string;
  name: string;
  jobs: number;
  resumes: number;
  interviewed: number;
  /** Count of unique candidates that passed the formal small review (legacy field name). */
  interviews: number;
  pass_rate: number | null;
  response_days: number | null;
};

export type TalentPoolGrowth = {
  days: string[];
  daily_new: number[];
  cumulative_total: number[];
  growth_rate: (number | null)[];
  summary: {
    total: number;
    recent_new: number;
    latest_growth_rate: number | null;
  };
};

export type RoleOverviewPipeline = {
  id: string;
  status?: string;
  screened_count?: number;
  interview_passed_count?: number;
};

export type RoleOverviewItem = {
  role: string;
  type_code: string;
  type_label: string;
  candidate_count: number;
  interview_passed_count: number;
  pass_rate: number;
  pipelines: RoleOverviewPipeline[];
};

export type CandidateDimensionScores = Partial<{
  job_coverage: number;
  professional_accuracy: number;
  analytical_logic: number;
  solution_feasibility: number;
  evidence_boundaries: number;
}>;

export type CandidateRankingCandidate = {
  candidate_id: string;
  name: string;
  years_experience?: number | string;
  skills?: string[];
  score: number;
  score_source?: "small_review" | "screening_match_legacy" | string;
  pipeline_id?: string;
  rank?: number;
  dimension_scores?: CandidateDimensionScores;
};

export type CandidateRankingResult = {
  role: string;
  type_code: string;
  type_label: string;
  keywords: string[];
  total: number;
  candidates: CandidateRankingCandidate[];
};

export type ActivityItem = {
  type?: "complete" | "progress" | "warning" | "error" | string;
  text?: string;
  tag?: string;
  pipeline_id?: string;
  created_at?: string;
  time_ago?: string;
  [key: string]: unknown;
};

export type MonitorUsageSummary = {
  total_calls?: number;
  total_tokens?: number;
  total_prompt_tokens?: number;
  total_completion_tokens?: number;
  total_estimated_cost_usd?: number;
  success_rate?: number;
  by_model?: Record<string, { call_count?: number; total_tokens?: number; estimated_cost_usd?: number }>;
  by_type?: Record<string, number>;
  [key: string]: unknown;
};

export type MonitorUsage = {
  summary?: MonitorUsageSummary;
  timeseries?: Array<{
    bucket: string;
    call_count?: number;
    prompt_tokens?: number;
    completion_tokens?: number;
    cost_usd?: number;
  }>;
  [key: string]: unknown;
};

export type UsageDetailItem = {
  id?: string;
  timestamp?: string;
  model?: string;
  call_type?: string;
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
  estimated_cost_usd?: number;
  agent?: string;
  operation?: string;
  pipeline_id?: string;
  latency_ms?: number;
  success?: boolean;
  [key: string]: unknown;
};

export type UsageDetailResult = {
  items: UsageDetailItem[];
  total: number;
  page: number;
  page_size: number;
};

export type UsageDetailSortField =
  | "timestamp"
  | "model"
  | "call_type"
  | "prompt_tokens"
  | "completion_tokens"
  | "total_tokens"
  | "estimated_cost_usd"
  | "agent"
  | "operation"
  | "pipeline_id"
  | "latency_ms"
  | "success";

export type UsageDetailSortOrder = "asc" | "desc";

export type MonitorDashboard = {
  last_24h?: {
    total_llm_calls?: number;
    total_tokens?: number;
    total_cost_usd?: number;
    error_count?: number;
    pipeline_events?: number;
  };
  recent_errors?: Array<Record<string, unknown>>;
  recent_events?: Array<Record<string, unknown>>;
  cost_by_model?: Record<string, number>;
  [key: string]: unknown;
};

export type MonitorLogItem = {
  timestamp?: string;
  level?: string;
  source?: string;
  message?: string;
  [key: string]: unknown;
};

export type MonitorEventItem = {
  timestamp?: string;
  event_type?: string;
  summary?: string;
  actor?: string;
  entity_type?: string;
  entity_id?: string;
  details?: unknown;
  [key: string]: unknown;
};

export function fetchAnalyticsDashboard() {
  return requestJson<DashboardData>("/api/analytics/dashboard", {}, "数据看板加载失败");
}

export function fetchAnalyticsActivity() {
  return requestJson<ActivityItem[]>("/api/analytics/activity", {}, "实时动态加载失败");
}

export function fetchRoleOverview() {
  return requestJson<RoleOverviewItem[]>("/api/analytics/role-overview", {}, "岗位一览加载失败");
}

export function fetchCandidateRanking(params: { role?: string; typeCode?: string; limit?: number; detail?: boolean }) {
  const search = new URLSearchParams();
  if (params.role) search.set("role", params.role);
  if (params.typeCode) search.set("type_code", params.typeCode);
  search.set("limit", String(params.limit ?? 4));
  if (params.detail) search.set("detail", "true");
  return requestJson<CandidateRankingResult>(
    `/api/analytics/candidate-ranking?${search.toString()}`,
    {},
    "候选人评分排名加载失败",
  );
}

export function fetchTalentPoolSummary() {
  return requestJson<TalentPoolDistribution>("/api/analytics/talent-pool-summary", {}, "候选人指标汇总加载失败");
}

export function fetchTalentAttrition() {
  return requestJson<TalentAttrition>("/api/analytics/talent-attrition", {}, "人才流失分析加载失败");
}

export function fetchStagePassRateTrend() {
  return requestJson<StagePassRateTrend>("/api/analytics/stage-pass-rate-trend", {}, "各环节通过率趋势加载失败");
}

export function fetchHrPerformance() {
  return requestJson<{ hrs: HrPerformanceRow[] }>("/api/analytics/hr-performance", {}, "HR 工作观察加载失败");
}

export function fetchTalentPoolGrowth() {
  return requestJson<TalentPoolGrowth>("/api/analytics/talent-pool-growth", {}, "人才库增长趋势加载失败");
}

export function fetchMonitorUsage(
  params: { range?: string; call_type?: string; from_ts?: string; granularity?: string } = {},
) {
  const search = new URLSearchParams();
  if (params.range) search.set("range", params.range);
  if (params.call_type) search.set("call_type", params.call_type);
  if (params.from_ts) search.set("from_ts", params.from_ts);
  if (params.granularity) search.set("granularity", params.granularity);
  const suffix = search.toString();
  return requestJson<MonitorUsage>(`/api/monitor/usage${suffix ? `?${suffix}` : ""}`, {}, "Token 用量加载失败");
}

export function fetchUsageDetail(params: {
  page?: number;
  page_size?: number;
  call_type?: string;
  search?: string;
  sort_by?: UsageDetailSortField;
  sort_order?: UsageDetailSortOrder;
}) {
  const search = new URLSearchParams();
  search.set("page", String(params.page ?? 1));
  search.set("page_size", String(params.page_size ?? 20));
  if (params.call_type) search.set("call_type", params.call_type);
  if (params.search) search.set("search", params.search);
  if (params.sort_by) search.set("sort_by", params.sort_by);
  if (params.sort_order) search.set("sort_order", params.sort_order);
  return requestJson<UsageDetailResult>(`/api/monitor/usage/detail?${search.toString()}`, {}, "Token 明细加载失败");
}

export function usageDetailCsvUrl(params: {
  call_type?: string;
  search?: string;
  sort_by?: UsageDetailSortField;
  sort_order?: UsageDetailSortOrder;
}) {
  const search = new URLSearchParams({ format: "csv" });
  if (params.call_type) search.set("call_type", params.call_type);
  if (params.search) search.set("search", params.search);
  if (params.sort_by) search.set("sort_by", params.sort_by);
  if (params.sort_order) search.set("sort_order", params.sort_order);
  return `/api/monitor/usage/detail?${search.toString()}`;
}

export function fetchMonitorDashboard() {
  return requestJson<MonitorDashboard>("/api/monitor/dashboard", {}, "监控概览加载失败");
}

export function fetchMonitorLogs(params: {
  page?: number;
  page_size?: number;
  level?: string;
  source?: string;
  search?: string;
  from_ts?: string;
}) {
  const search = new URLSearchParams();
  search.set("page", String(params.page ?? 1));
  search.set("page_size", String(params.page_size ?? 50));
  if (params.level) search.set("level", params.level);
  if (params.source) search.set("source", params.source);
  if (params.search) search.set("search", params.search);
  if (params.from_ts) search.set("from_ts", params.from_ts);
  return requestJson<{ items: MonitorLogItem[]; total: number; page: number; page_size: number }>(
    `/api/monitor/logs?${search.toString()}`,
    {},
    "日志加载失败",
  );
}

export function fetchMonitorEvents(params: {
  page?: number;
  page_size?: number;
  entity_type?: string;
  from_ts?: string;
}) {
  const search = new URLSearchParams();
  search.set("page", String(params.page ?? 1));
  search.set("page_size", String(params.page_size ?? 100));
  if (params.entity_type) search.set("entity_type", params.entity_type);
  if (params.from_ts) search.set("from_ts", params.from_ts);
  return requestJson<{ items: MonitorEventItem[]; total: number; page: number; page_size: number }>(
    `/api/monitor/events?${search.toString()}`,
    {},
    "审计事件加载失败",
  );
}
