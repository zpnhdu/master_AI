import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import {
  autoRunPipeline,
  fetchKGRecommendations,
  fetchPipelineCandidates,
  fetchPipelineDetail,
  ocrImportCandidates,
  simpleImportCandidates,
} from "./api";
import { useAutoRunMutation, useSimpleImportMutation } from "./hooks";

afterEach(() => {
  vi.unstubAllGlobals();
});

function createQueryWrapper(queryClient: QueryClient) {
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
}

describe("pipeline-detail api", () => {
  it("normalizes the detail response with string-encoded agents and outputs", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({
        pipeline_id: "p1",
        role: "店长",
        agents: '["xiao_wen","xiao_mian"]',
        stages: [
          { stage_id: "jd_write", status: "done", output: '{"resume_count":3}' },
          {
            stage_id: "crawl",
            status: "done",
            output: JSON.stringify(JSON.stringify({ resume_count: 5 })),
          },
          { stage_id: "match" },
          "garbage",
        ],
      }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const detail = await fetchPipelineDetail("p1");

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p1",
      expect.objectContaining({ credentials: "include", signal: expect.any(AbortSignal) }),
    );
    expect(detail.id).toBe("p1");
    expect(detail.agents).toEqual(["xiao_wen", "xiao_mian"]);
    expect(detail.stages).toHaveLength(3);
    expect(detail.stages[0].output).toEqual({ resume_count: 3 });
    expect(detail.stages[1].output).toEqual({ resume_count: 5 });
    expect(detail.stages[2]).toEqual({ stage_id: "match", status: "pending", output: null });
  });

  it("propagates the backend detail message for detail errors", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: false,
        status: 404,
        json: async () => ({ detail: "岗位不存在" }),
      }),
    );

    await expect(fetchPipelineDetail("missing")).rejects.toThrow("岗位不存在");
  });

  it("falls back to a status-coded message when the error body has no detail", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 500, json: async () => ({}) }));

    await expect(fetchPipelineDetail("p1")).rejects.toThrow("岗位加载失败：500");
  });

  it("rejects a non-object detail payload", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => [] }));

    await expect(fetchPipelineDetail("p1")).rejects.toThrow("岗位数据格式异常");
  });

  it("drops invalid candidates and tolerates a non-list response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [{ id: "c1", name: "张三", phone: "138****8000" }, { bad: true }, null],
      }),
    );

    await expect(fetchPipelineCandidates("p1")).resolves.toEqual([{ id: "c1", name: "张三", phone: "138****8000" }]);

    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200, json: async () => ({}) }));

    await expect(fetchPipelineCandidates("p1")).resolves.toEqual([]);
  });

  it("posts to the auto-run endpoint and propagates its detail message", async () => {
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, status: 200 });
    vi.stubGlobal("fetch", fetchMock);

    await expect(autoRunPipeline("p1")).resolves.toBeUndefined();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/pipelines/p1/auto-run",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );

    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: false,
        status: 409,
        json: async () => ({ detail: "岗位已在运行中" }),
      }),
    );

    await expect(autoRunPipeline("p1")).rejects.toThrow("岗位已在运行中");
  });

  it("returns an empty recommendation list when the KG request fails", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 500 }));

    await expect(fetchKGRecommendations("店长")).resolves.toEqual([]);
  });

  it("filters invalid KG recommendation entries", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({
        recommendations: [
          { id: "n1", name: "餐饮行业经验", type: "rule", definition: "需具备餐饮经验", relevance: 0.9 },
          { id: "n2" },
          { name: "缺ID" },
        ],
      }),
    });
    vi.stubGlobal("fetch", fetchMock);

    const result = await fetchKGRecommendations("店长");

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/knowledge/recommend",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ role: "店长", stage: "" }),
      }),
    );
    expect(result).toEqual([
      { id: "n1", name: "餐饮行业经验", type: "rule", definition: "需具备餐饮经验", relevance: 0.9 },
    ]);
  });

  it("invalidates the detail query after a successful auto-run mutation", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, status: 200 }));
    const queryClient = new QueryClient();
    let resolveInvalidation!: () => void;
    const invalidation = new Promise<void>((resolve) => {
      resolveInvalidation = resolve;
    });
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockReturnValue(invalidation);

    const { result } = renderHook(() => useAutoRunMutation("p1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    const mutationPromise = result.current.mutateAsync(undefined);

    await vi.waitFor(() => expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipeline-detail", "p1"] }));
    let mutationResolved = false;
    void mutationPromise.then(() => {
      mutationResolved = true;
    });
    await Promise.resolve();
    expect(mutationResolved).toBe(false);
    resolveInvalidation();
    await mutationPromise;
  });

  it("invalidates detail and candidates queries after a successful simple import", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ created: 1, candidates: [], errors: [] }),
      }),
    );
    const queryClient = new QueryClient();
    const invalidateQueries = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);

    const { result } = renderHook(() => useSimpleImportMutation("p1"), {
      wrapper: createQueryWrapper(queryClient),
    });

    await result.current.mutateAsync({ candidates: [{ name: "张三", phone: "13800138000" }] });

    expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipeline-detail", "p1"] });
    expect(invalidateQueries).toHaveBeenCalledWith({ queryKey: ["pipeline-candidates", "p1"] });
  });
});
