import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  autoRunPipeline,
  fetchKGRecommendations,
  fetchPipelineCandidates,
  fetchPipelineDetail,
  ocrImportCandidates,
  simpleImportCandidates,
  type SimpleImportRequest,
} from "./api";

function detailQueryKey(pipelineId: string) {
  return ["pipeline-detail", pipelineId] as const;
}

function candidatesQueryKey(pipelineId: string) {
  return ["pipeline-candidates", pipelineId] as const;
}

export function usePipelineDetailQuery(pipelineId: string) {
  return useQuery({
    queryKey: detailQueryKey(pipelineId),
    queryFn: () => fetchPipelineDetail(pipelineId),
    staleTime: 10 * 1000,
  });
}

export function usePipelineCandidatesQuery(pipelineId: string, enabled: boolean) {
  return useQuery({
    queryKey: candidatesQueryKey(pipelineId),
    queryFn: () => fetchPipelineCandidates(pipelineId),
    enabled,
    staleTime: 10 * 1000,
  });
}

export function useKGRecommendationsQuery(role: string | undefined) {
  return useQuery({
    queryKey: ["kg-recommendations", role ?? ""],
    queryFn: () => fetchKGRecommendations(role ?? ""),
    enabled: Boolean(role),
    staleTime: 5 * 60 * 1000,
  });
}

export function useAutoRunMutation(pipelineId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => autoRunPipeline(pipelineId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: detailQueryKey(pipelineId) }),
  });
}

export function useSimpleImportMutation(pipelineId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (request: SimpleImportRequest) => simpleImportCandidates(pipelineId, request),
    onSuccess: () =>
      Promise.all([
        queryClient.invalidateQueries({ queryKey: detailQueryKey(pipelineId) }),
        queryClient.invalidateQueries({ queryKey: candidatesQueryKey(pipelineId) }),
      ]),
  });
}

export function useOcrImportMutation(pipelineId: string) {
  return useMutation({
    mutationFn: (imageFile: File) => ocrImportCandidates(pipelineId, imageFile),
  });
}
