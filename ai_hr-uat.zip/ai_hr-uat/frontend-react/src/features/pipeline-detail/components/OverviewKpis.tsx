import type { PipelineOverview } from '../selectors';

type OverviewKpisProps = {
  overview: PipelineOverview;
};

/** KPI 概览卡（对齐旧版 pd-overview：总进度/已完成/候选人/耗时 + 状态条）。 */
export function OverviewKpis({ overview }: OverviewKpisProps) {
  const elapsedMatch = overview.elapsedText.match(/^(\d+)(.+)$/);
  const elapsedValue = elapsedMatch ? elapsedMatch[1] : overview.elapsedText;
  const elapsedUnit = elapsedMatch ? elapsedMatch[2] : null;

  return (
    <div className="pd-overview">
      <div className="pd-overview-kpis">
        <div className="pd-overview-kpi">
          <span className="kpi-val primary">{overview.pct}%</span>
          <span className="kpi-lbl">总进度</span>
        </div>
        <div className="pd-overview-sep" />
        <div className="pd-overview-kpi">
          <span className="kpi-val">
            {overview.doneCount}/{overview.totalAgents}
          </span>
          <span className="kpi-lbl">已完成</span>
        </div>
        <div className="pd-overview-sep" />
        <div className="pd-overview-kpi">
          <span className="kpi-val">{overview.candidates}</span>
          <span className="kpi-lbl">候选人</span>
        </div>
        <div className="pd-overview-sep" />
        <div className="pd-overview-kpi">
          <span className="kpi-val">
            <span>{elapsedValue}</span>
            {elapsedUnit && <span className="pd-kpi-unit">{elapsedUnit}</span>}
          </span>
          <span className="kpi-lbl">耗时</span>
        </div>
      </div>
      <div className="pd-overview-status">
        <span className={`status-dot ${overview.statusKind}`} />
        <span>{overview.statusMessage}</span>
      </div>
    </div>
  );
}