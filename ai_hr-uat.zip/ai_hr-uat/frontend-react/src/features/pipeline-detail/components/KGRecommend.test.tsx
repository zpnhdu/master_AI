import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { fetchKnowledgeNode } from '../../knowledge/api';
import { KGRecommend } from './KGRecommend';

vi.mock('../../knowledge/api', () => ({
  fetchKnowledgeNode: vi.fn(),
}));

const fetchKnowledgeNodeMock = vi.mocked(fetchKnowledgeNode);

function renderComponent() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });

  return render(
    <QueryClientProvider client={queryClient}>
      <KGRecommend
        recommendations={[
          {
            id: 'method-1',
            name: '结构化面试法',
            type: 'method',
            definition: '统一题目和评分标准',
          },
        ]}
      />
    </QueryClientProvider>,
  );
}

describe('KGRecommend', () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  it('opens the knowledge detail drawer after clicking a recommendation', async () => {
    fetchKnowledgeNodeMock.mockResolvedValue({
      node: {
        id: 'method-1',
        name: '结构化面试法',
        type: 'method',
        definition: '使用统一题目和评分标准进行面试。',
        tags: ['面试方法'],
        confidence: 0.9,
      },
      neighbors: [
        { id: 'rule-1', name: '评分一致性', type: 'rule', definition: '统一评分口径' },
      ],
      connection_count: 1,
    });

    renderComponent();
    fireEvent.click(screen.getByRole('button', { name: '结构化面试法' }));

    expect(fetchKnowledgeNodeMock).toHaveBeenCalledWith('method-1');
    expect(await screen.findByText('使用统一题目和评分标准进行面试。')).toBeInTheDocument();
    expect(screen.getByText('评分一致性')).toBeInTheDocument();
    expect(screen.getByText('知识详情')).toBeInTheDocument();
  });
});
