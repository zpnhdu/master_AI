import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

import {
  AGENT_CONFIG,
  STAGE_NAMES,
  agentWorkspaceUrl,
  type AgentConfig,
  type AgentId,
} from '../../../shared/agent-config';
import type { PipelineDetail } from '../api';
import {
  buildStagesDict,
  getAgentCardStatus,
  getStageOutputSummary,
  isKnownAgent,
  type StagesDict,
} from '../selectors';

type AgentCardListProps = {
  pipeline: PipelineDetail;
};

/** Agent 卡片网格（对齐旧版 pd-section-hd + pd-agent-list 三列布局）。 */
export function AgentCardList({ pipeline }: AgentCardListProps) {
  const stagesDict = useMemo(() => buildStagesDict(pipeline.stages), [pipeline.stages]);

  // 旧页逻辑：agents 为空时显示空状态（不回退到六个 Agent）
  if (pipeline.agents.length === 0) {
    return (
      <div className="pd-empty">
        <div className="icon">○</div>
        <div>该岗位暂无 Agent</div>
      </div>
    );
  }

  return (
    <div>
      <div className="pd-section-hd">流程详情</div>
      <div className="pd-agent-list">
        {pipeline.agents.map((agentId, index) =>
          isKnownAgent(agentId) ? (
            <AgentCard
              key={agentId}
              agentId={agentId}
              cfg={AGENT_CONFIG[agentId]}
              stagesDict={stagesDict}
              index={index}
              pipelineId={pipeline.id}
            />
          ) : null,
        )}
      </div>
    </div>
  );
}

type AgentCardProps = {
  agentId: AgentId;
  cfg: AgentConfig;
  stagesDict: StagesDict;
  index: number;
  pipelineId: string;
};

function AgentCard({ agentId, cfg, stagesDict, index, pipelineId }: AgentCardProps) {
  const navigate = useNavigate();
  const status = getAgentCardStatus(stagesDict, cfg.stages);
  const gradStart = cfg.gradStart || cfg.color;
  const gradEnd = cfg.gradEnd || cfg.color;

  function openWorkspace() {
    navigate(agentWorkspaceUrl(agentId, pipelineId));
  }

  return (
    <div
      className="pd-agent-card"
      style={{ animationDelay: `${index * 0.06}s` }}
      onClick={openWorkspace}
    >
      <div
        className="pd-accent"
        style={{ background: `linear-gradient(90deg,${gradStart},${gradEnd})` }}
      />
      <div className="pd-card-hd">
        <div
          className="pd-icon"
          style={{ background: `linear-gradient(135deg,${gradStart},${gradEnd})` }}
        >
          {cfg.icon}
        </div>
        <div className="pd-info">
          <span className="pd-name">
            {cfg.name}
            <span className="pd-name-desc">· {cfg.desc}</span>
          </span>
        </div>
        <div className="pd-meta-right">
          <span className={`pd-status ${status.kind}`}>{status.text}</span>
          <span className="pd-pct">{status.progress}%</span>
        </div>
      </div>
      {cfg.stages.length > 0 ? (
        <div className="pd-card-bd">
          <div className="pd-card-progress">
            <div className="pd-card-progress-bar">
              <div
                className={`pd-card-progress-fill${status.kind === 'done' ? ' success' : ''}`}
                style={{ width: `${status.progress}%` }}
              />
            </div>
          </div>
          <div className="pd-stages-row">
            {cfg.stages.map((stageId) => {
              const stage = stagesDict[stageId];
              const dotClass =
                stage?.status === 'done'
                  ? 'done'
                  : stage?.status === 'running'
                    ? 'running'
                    : 'pending';
              const outputText = stage ? getStageOutputSummary(stage.output) : '';
              return (
                <div className="pd-stage-item" key={stageId}>
                  <span className={`pd-stage-dot ${dotClass}`} />
                  <span className="pd-stage-name">{STAGE_NAMES[stageId] ?? stageId}</span>
                  {outputText ? <span className="pd-stage-output">{outputText}</span> : null}
                </div>
              );
            })}
          </div>
        </div>
      ) : null}
      <div className="pd-card-ft">
        <button
          type="button"
          className="pd-ft-btn"
          onClick={(event) => {
            event.stopPropagation();
            openWorkspace();
          }}
        >
          进入工作台 →
        </button>
      </div>
    </div>
  );
}