import { Fragment, useMemo } from 'react';
import { Link } from 'react-router-dom';

import { AGENT_CONFIG } from '../../../shared/agent-config';
import { routePaths } from '../../../app/routes/route-paths';
import type { PipelineDetail } from '../api';
import {
  buildStagesDict,
  computeOverview,
  countCandidatesFromStages,
  formatCreatedDate,
  getAgentProgress,
  getEnabledAgents,
  getPipelineBadge,
  isKnownAgent,
} from '../selectors';

type HeroHeaderProps = {
  pipeline: PipelineDetail | null;
  onAutoRun: () => void;
  autoRunning: boolean;
};

/** 顶部 Hero：返回、角色、徽标、操作按钮、meta 胶囊与六 Agent stepper（对齐旧版 pd-hero）。 */
export function HeroHeader({ pipeline }: HeroHeaderProps) {
  const stagesDict = useMemo(() => buildStagesDict(pipeline?.stages ?? []), [pipeline]);
  const enabledAgents = getEnabledAgents(pipeline?.agents ?? []);
  const progressList = enabledAgents.map((agentId) =>
    isKnownAgent(agentId) ? getAgentProgress(stagesDict, AGENT_CONFIG[agentId].stages) : null,
  );

  const badge = pipeline ? getPipelineBadge(pipeline, stagesDict) : null;
  const overview = pipeline ? computeOverview(pipeline, stagesDict) : null;
  const type = pipeline?.pipeline_type || pipeline?.role_type || '';
  const created = formatCreatedDate(pipeline?.created_at);
  const candidates = pipeline ? countCandidatesFromStages(pipeline.stages) : 0;
  const pct = overview?.pct ?? 0;

  return (
    <header className="pd-hero">
      <div className="pd-hero-row1">
        <Link to={routePaths.studio} className="pd-back-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          返回
        </Link>
        <span className="pd-role-name">{pipeline?.role || '加载中...'}</span>
        {type ? <span className="pd-type-badge">{type}</span> : null}
        {badge ? <span className={`pd-status-badge ${badge.kind}`}>{badge.text}</span> : null}
      </div>
      {pipeline ? (
        <div className="pd-hero-row2">
          {type ? (
            <span className="hero-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z" />
                <line x1="7" y1="7" x2="7.01" y2="7" />
              </svg>
              {type}
            </span>
          ) : null}
          {created ? (
            <span className="hero-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="4" width="18" height="18" rx="2" />
                <path d="M16 2v4M8 2v4M3 10h18" />
              </svg>
              创建于 {created}
            </span>
          ) : null}
          <span className="hero-meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82.33l.06.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
            </svg>
            {pipeline.agents.length} Agent
          </span>
          {candidates > 0 ? (
            <span className="hero-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
              </svg>
              {candidates} 候选人
            </span>
          ) : null}
        </div>
      ) : null}
      <div className="pd-hero-stepper">
        <div className="pd-stepper">
          {pipeline
            ? enabledAgents.map((agentId, index) => {
                const cfg = isKnownAgent(agentId) ? AGENT_CONFIG[agentId] : null;
                const progress = progressList[index];
                const isDone = progress?.isDone ?? false;
                const isRunning = progress?.isRunning ?? false;
                const dotClass = isDone ? 'done' : isRunning ? 'active' : '';
                const dotLabel = isDone ? '✓' : (cfg?.icon ?? '?');
                const statusLabel = isDone ? '已完成' : isRunning ? '进行中' : '待启动';
                const nextDone = progressList[index + 1]?.isDone ?? false;

                return (
                  <Fragment key={agentId}>
                    <span
                      className={`pd-stepper-dot ${dotClass}`}
                      title={`${cfg?.name ?? agentId} · ${statusLabel}`}
                    >
                      {dotLabel}
                    </span>
                    {index < enabledAgents.length - 1 ? (
                      <span className={`pd-stepper-line${isDone && nextDone ? ' done' : ''}`} />
                    ) : null}
                  </Fragment>
                );
              })
            : null}
        </div>
        <div className="pd-stepper-pct-bar">
          <div className="pd-stepper-pct-fill" style={{ width: `${pct}%` }} />
        </div>
        <span className="pd-stepper-pct">{pct}%</span>
      </div>
    </header>
  );
}
