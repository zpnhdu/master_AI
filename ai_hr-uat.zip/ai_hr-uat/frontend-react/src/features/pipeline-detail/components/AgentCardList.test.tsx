import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { MemoryRouter, useLocation } from 'react-router-dom';

import type { PipelineDetail } from '../api';

import { AgentCardList } from './AgentCardList';

function LocationProbe() {
  const location = useLocation();
  return <output data-testid="current-location">{location.pathname}{location.search}</output>;
}

const pipeline: PipelineDetail = {
  id: 'p1',
  role: '店长',
  agents: ['xiao_wen'],
  stages: [
    { stage_id: 'jd_write', status: 'done', output: null },
    { stage_id: 'profile_build', status: 'pending', output: null },
  ],
};

describe('AgentCardList', () => {
  it('navigates to an agent workspace without a full page reload', () => {
    render(
      <MemoryRouter initialEntries={['/pipelines/p1']}>
        <LocationProbe />
        <AgentCardList pipeline={pipeline} />
      </MemoryRouter>,
    );

    fireEvent.click(screen.getByRole('button', { name: '进入工作台 →' }));

    expect(screen.getByTestId('current-location')).toHaveTextContent('/xiao-wen?pipeline=p1');
  });
});
