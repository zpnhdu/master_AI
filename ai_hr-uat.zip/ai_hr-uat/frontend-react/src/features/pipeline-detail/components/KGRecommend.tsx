import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Alert, Button, Drawer, List, Skeleton, Space, Tag, Typography } from 'antd';

import { fetchKnowledgeNode } from '../../knowledge/api';
import type { KGRecommendation } from '../api';

/** 与旧版 shared.js renderKGRecommendationChips 的 typeColors 一致。 */
const TYPE_COLORS: Record<string, string> = {
  method: '#10b981',
  rule: '#f59e0b',
  scenario: '#8b5cf6',
  concept: '#2563eb',
};
const DEFAULT_COLOR = '#6b7280';
const TYPE_LABELS: Record<string, string> = {
  method: '方法',
  rule: '规则',
  scenario: '场景',
  concept: '概念',
};

type KGRecommendProps = {
  recommendations: KGRecommendation[];
};

/**
 * KG 相关知识推荐 chips（对齐旧版 pd-kg-recommend）。
 * 点击后复用知识节点详情接口，在右侧抽屉展示完整信息。
 */
export function KGRecommend({ recommendations }: KGRecommendProps) {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const detailQuery = useQuery({
    queryKey: ['knowledge', 'node', selectedNodeId],
    queryFn: () => fetchKnowledgeNode(selectedNodeId as string),
    enabled: Boolean(selectedNodeId),
  });

  if (recommendations.length === 0) {
    return null;
  }

  return (
    <div className="pd-overview">
      <div className="pd-kg-inner">
        <div className="pd-kg-title">◈ 相关知识推荐</div>
        <div className="pd-kg-chips">
          {recommendations.map((rec) => {
            const color = (rec.type ? TYPE_COLORS[rec.type] : undefined) ?? DEFAULT_COLOR;
            return (
              <button
                type="button"
                key={rec.id}
                className="pd-kg-chip"
                title={rec.definition ?? ''}
                onClick={() => setSelectedNodeId(rec.id)}
                style={{
                  background: `${color}15`,
                  color,
                  border: `1px solid ${color}30`,
                }}
              >
                {rec.name}
              </button>
            );
          })}
        </div>
      </div>
      <Drawer
        title="知识详情"
        open={Boolean(selectedNodeId)}
        onClose={() => setSelectedNodeId(null)}
        width={380}
      >
        {detailQuery.isPending ? (
          <Skeleton active paragraph={{ rows: 6 }} />
        ) : detailQuery.isError || !detailQuery.data ? (
          <Alert
            type="error"
            showIcon
            message="知识详情加载失败"
            action={
              <Button size="small" onClick={() => void detailQuery.refetch()}>
                重试
              </Button>
            }
          />
        ) : (
          <KnowledgeNodeContent
            detail={detailQuery.data}
            onSelectNode={setSelectedNodeId}
          />
        )}
      </Drawer>
    </div>
  );
}

type KnowledgeNodeContentProps = {
  detail: Awaited<ReturnType<typeof fetchKnowledgeNode>>;
  onSelectNode: (nodeId: string) => void;
};

function KnowledgeNodeContent({ detail, onSelectNode }: KnowledgeNodeContentProps) {
  const node = detail.node;
  const neighbors = detail.neighbors ?? detail.related_nodes ?? [];

  return (
    <>
      <Space direction="vertical" size={4} style={{ width: '100%' }}>
        <Space wrap>
          <Typography.Title level={4} style={{ margin: 0 }}>
            {node.name}
          </Typography.Title>
          <Tag color={TYPE_COLORS[node.type] ?? 'default'}>
            {TYPE_LABELS[node.type] ?? node.type}
          </Tag>
        </Space>
        <Typography.Text type="secondary">
          关联节点 {detail.connection_count ?? neighbors.length} 个
          {node.confidence !== undefined
            ? ` · 置信度 ${Math.round(node.confidence * 100)}%`
            : ''}
        </Typography.Text>
      </Space>

      <Typography.Paragraph style={{ marginTop: 16 }}>
        {node.definition || '暂无定义'}
      </Typography.Paragraph>

      {(node.tags ?? []).length > 0 ? (
        <Space wrap style={{ marginBottom: 16 }}>
          {(node.tags ?? []).map((tag) => (
            <Tag key={tag}>{tag}</Tag>
          ))}
        </Space>
      ) : null}

      <Typography.Text strong>关联概念</Typography.Text>
      <List
        size="small"
        dataSource={neighbors}
        locale={{ emptyText: '暂无关联概念' }}
        renderItem={(neighbor) => (
          <List.Item>
            <Button type="link" size="small" onClick={() => onSelectNode(neighbor.id)}>
              {neighbor.name}
            </Button>
            <Tag color={TYPE_COLORS[neighbor.type] ?? 'default'}>
              {TYPE_LABELS[neighbor.type] ?? neighbor.type}
            </Tag>
          </List.Item>
        )}
      />
    </>
  );
}
