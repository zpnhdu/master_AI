import { describe, expect, it } from "vitest";

import { AGENT_ORDER } from "../../shared/agent-config";
import type { PipelineDetail, PipelineDetailStage, StageOutput } from "./api";
import {
  buildStagesDict,
  computeOverview,
  countCandidatesFromStages,
  formatCreatedDate,
  formatElapsed,
  getAgentCardStatus,
  getAgentProgress,
  getEnabledAgents,
  getPipelineBadge,
  getStageOutputSummary,
} from "./selectors";

function makeStage(stageId: string, status: string, output: StageOutput | null = null): PipelineDetailStage {
  return { stage_id: stageId, status, output };
}

function makePipeline(overrides: Partial<PipelineDetail> = {}): PipelineDetail {
  return {
    id: "p1",
    role: "店长",
    agents: [],
    stages: [],
    ...overrides,
  };
}

describe("pipeline-detail selectors", () => {
  it("builds a stages dict keyed by stage id", () => {
    const stages = [makeStage("jd_write", "done"), makeStage("crawl", "running")];

    const dict = buildStagesDict(stages);

    expect(dict.jd_write.status).toBe("done");
    expect(dict.crawl.status).toBe("running");
  });

  it("falls back to all six agents when the pipeline has no agent list", () => {
    expect(getEnabledAgents([])).toEqual(AGENT_ORDER);
    expect(getEnabledAgents(["xiao_mian"])).toEqual(["xiao_mian"]);
  });

  it("treats an agent as done only when its last stage is done", () => {
    const dict = buildStagesDict([makeStage("jd_write", "done"), makeStage("profile_build", "running")]);

    const progress = getAgentProgress(dict, ["jd_write", "profile_build"]);

    expect(progress.isDone).toBe(false);
    expect(progress.isRunning).toBe(true);
    expect(progress.doneStages).toBe(1);
    expect(progress.progress).toBe(50);
  });

  it("marks an agent done when its final stage is done even if earlier stages are not", () => {
    const dict = buildStagesDict([makeStage("jd_write", "pending"), makeStage("profile_build", "done")]);

    const progress = getAgentProgress(dict, ["jd_write", "profile_build"]);

    expect(progress.isDone).toBe(true);
    expect(progress.isRunning).toBe(false);
  });

  it("prefers the completed status for the pipeline badge", () => {
    const badge = getPipelineBadge(makePipeline({ status: "completed" }), {});

    expect(badge).toEqual({ kind: "done", text: "已完成" });
  });

  it("does not mark the pipeline complete from stage status alone", () => {
    const pipeline = makePipeline({ agents: ["xiao_mian"] });
    const dict = buildStagesDict([makeStage("interview_gen", "done")]);

    expect(getPipelineBadge(pipeline, dict)).toEqual({ kind: "running", text: "进行中" });
  });

  it("marks the badge running when any stage is running", () => {
    const pipeline = makePipeline({
      agents: ["xiao_mian"],
      stages: [makeStage("interview_gen", "running")],
    });

    expect(getPipelineBadge(pipeline, {}).kind).toBe("running");
  });

  it("falls back to a pending badge otherwise", () => {
    const pipeline = makePipeline({ agents: ["xiao_mian"] });

    expect(getPipelineBadge(pipeline, {})).toEqual({ kind: "pending", text: "待启动" });
  });

  it("sums resume and pass counts across stage outputs", () => {
    const stages = [
      makeStage("crawl", "done", { resume_count: 5 }),
      makeStage("match", "done", { pass_count: 3 }),
      makeStage("report", "done"),
    ];

    expect(countCandidatesFromStages(stages)).toBe(8);
  });

  it.each<[string | undefined, string | undefined, boolean, string]>([
    [undefined, undefined, false, "--"],
    ["not-a-date", undefined, false, "--"],
    ["2026-08-18T10:00:00Z", undefined, false, "30分钟"],
    ["2026-08-18T08:00:00Z", undefined, false, "3小时"],
    ["2026-08-15T10:00:00Z", undefined, false, "3天"],
    ["2026-08-18T08:00:00Z", "2026-08-18T09:00:00Z", true, "1小时"],
  ])(
    "formats elapsed time for created=%s completed=%s isCompleted=%s",
    (createdAt, completedAt, isCompleted, expected) => {
      const now = new Date("2026-08-18T10:30:00Z");

      expect(formatElapsed(createdAt, completedAt, isCompleted, now)).toBe(expected);
    },
  );

  it("computes the overview with a running agent message", () => {
    const pipeline = makePipeline({
      agents: ["xiao_wen", "xiao_mian"],
      created_at: "2026-08-18T10:00:00Z",
      stages: [
        makeStage("jd_write", "done"),
        makeStage("profile_build", "done"),
        makeStage("interview_gen", "running", { pass_count: 2 }),
      ],
    });
    const dict = buildStagesDict(pipeline.stages);

    const overview = computeOverview(pipeline, dict, new Date("2026-08-18T10:30:00Z"));

    expect(overview.doneCount).toBe(1);
    expect(overview.totalAgents).toBe(2);
    expect(overview.pct).toBe(50);
    expect(overview.candidates).toBe(2);
    expect(overview.statusKind).toBe("running");
    expect(overview.statusMessage).toBe("小面正在面试出题安排中");
  });

  it("waits for final confirmation after all agents finish", () => {
    const pipeline = makePipeline({
      agents: ["xiao_mian"],
      stages: [makeStage("interview_gen", "done")],
    });

    const overview = computeOverview(pipeline, buildStagesDict(pipeline.stages));

    expect(overview.statusKind).toBe("running");
    expect(overview.statusMessage).toBe("等待最终确认");
  });

  it.each<[StageOutput | null, string]>([
    [{ resume_count: 4 }, "✓ 4份"],
    [{ pass_count: 2 }, "✓ 2人"],
    [{ jd: { title: "店长JD" } }, "✓ 店长JD"],
    [{ profile: { dimensions: [] } }, "✓ 22维"],
    [{ other: 1 }, "✓ 已生成"],
    [null, ""],
  ])("summarizes stage output %p as %s", (output, expected) => {
    expect(getStageOutputSummary(output)).toBe(expected);
  });

  it("shows in-progress once any stage is done, and done only when every stage is done", () => {
    const pendingDict = buildStagesDict([makeStage("jd_write", "done"), makeStage("profile_build", "pending")]);
    // 部分完成显示“进行中”而非“待启动”（ISSUE-1-03）
    expect(getAgentCardStatus(pendingDict, ["jd_write", "profile_build"])).toEqual({
      kind: "running",
      text: "进行中",
      progress: 50,
    });

    const runningDict = buildStagesDict([makeStage("jd_write", "done"), makeStage("profile_build", "running")]);
    expect(getAgentCardStatus(runningDict, ["jd_write", "profile_build"]).kind).toBe("running");

    const doneDict = buildStagesDict([makeStage("jd_write", "done"), makeStage("profile_build", "done")]);
    expect(getAgentCardStatus(doneDict, ["jd_write", "profile_build"])).toEqual({
      kind: "done",
      text: "已完成",
      progress: 100,
    });
  });

  it("formats the created date in zh-CN short form", () => {
    const value = "2026-08-18T10:00:00Z";

    expect(formatCreatedDate(value)).toBe(new Date(value).toLocaleDateString("zh-CN"));
    expect(formatCreatedDate("not-a-date")).toBe("");
    expect(formatCreatedDate(undefined)).toBe("");
  });
});
