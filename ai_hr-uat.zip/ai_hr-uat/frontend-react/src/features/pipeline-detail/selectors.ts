import { AGENT_CONFIG, AGENT_ORDER, type AgentId } from "../../shared/agent-config";
import type { PipelineDetail, PipelineDetailStage, StageOutput } from "./api";

export type StagesDict = Record<string, PipelineDetailStage>;

export type AgentProgress = {
  isDone: boolean;
  isRunning: boolean;
  doneStages: number;
  totalStages: number;
  progress: number;
};

export type PipelineBadge = {
  kind: "done" | "running" | "pending";
  text: string;
};

export type PipelineOverview = {
  pct: number;
  doneCount: number;
  totalAgents: number;
  candidates: number;
  elapsedText: string;
  statusKind: "done" | "running" | "pending";
  statusMessage: string;
};

export function buildStagesDict(stages: PipelineDetailStage[]): StagesDict {
  const dict: StagesDict = {};
  for (const stage of stages) {
    dict[stage.stage_id] = stage;
  }
  return dict;
}

/** 旧页逻辑：pipeline.agents 为空时展示全部六个 Agent。 */
export function getEnabledAgents(agents: string[]): string[] {
  return agents.length > 0 ? agents : [...AGENT_ORDER];
}

export function isKnownAgent(agentId: string): agentId is AgentId {
  return agentId in AGENT_CONFIG;
}

/** Agent 完成判定：其最后一个阶段 done 即视为完成（与旧页 stepper 一致）。 */
export function getAgentProgress(stagesDict: StagesDict, stageIds: string[]): AgentProgress {
  const lastStageId = stageIds[stageIds.length - 1];
  const isDone = Boolean(lastStageId && stagesDict[lastStageId]?.status === "done");
  const isRunning =
    !isDone && stageIds.some((stageId) => ["running", "waiting_human"].includes(stagesDict[stageId]?.status ?? ""));
  const doneStages = stageIds.filter((stageId) => stagesDict[stageId]?.status === "done").length;
  const totalStages = stageIds.length;
  const progress = totalStages ? Math.round((doneStages / totalStages) * 100) : 0;

  return { isDone, isRunning, doneStages, totalStages, progress };
}

/** Hero 顶部状态徽标（与旧页 renderTopBar 的状态分支一致）。 */
export function getPipelineBadge(pipeline: PipelineDetail, stagesDict: StagesDict): PipelineBadge {
  const agents = pipeline.agents;
  const anyRunning = pipeline.stages.some((stage) => ["running", "waiting_human"].includes(stage.status));

  if (pipeline.status === "completed") {
    return { kind: "done", text: "已完成" };
  }
  if (pipeline.status === "waiting_human") {
    return { kind: "running", text: "等待人工处理" };
  }
  if (anyRunning) {
    return { kind: "running", text: "进行中" };
  }
  // 部分阶段已完成但整体未结束（等待手动触发下一阶段）：不应再显示“待启动”（ISSUE-0-04）
  const anyDone =
    stagesDict &&
    agents.some((agentId) => {
      if (!isKnownAgent(agentId)) {
        return false;
      }
      return AGENT_CONFIG[agentId].stages.some((stageId) => stagesDict[stageId]?.status === "done");
    });
  if (anyDone) {
    return { kind: "running", text: "进行中" };
  }
  return { kind: "pending", text: "待启动" };
}

/** 候选人数：各阶段产出中 resume_count 与 pass_count 累加（与旧页一致）。 */
export function countCandidatesFromStages(stages: PipelineDetailStage[]): number {
  let candidates = 0;
  for (const stage of stages) {
    const output = stage.output;
    if (!output) {
      continue;
    }
    if (typeof output.resume_count === "number") {
      candidates += output.resume_count;
    }
    if (typeof output.pass_count === "number") {
      candidates += output.pass_count;
    }
  }
  return candidates;
}

export function formatElapsed(
  createdAt: string | undefined,
  completedAt: string | undefined,
  isCompleted: boolean,
  now: Date = new Date(),
): string {
  if (!createdAt) {
    return "--";
  }

  const start = new Date(createdAt);
  if (Number.isNaN(start.getTime())) {
    return "--";
  }

  let end = now;
  if (isCompleted && completedAt) {
    const completedTime = new Date(completedAt);
    if (!Number.isNaN(completedTime.getTime())) {
      end = completedTime;
    }
  }

  const diffMs = end.getTime() - start.getTime();
  if (diffMs <= 0) {
    return "--";
  }

  const diffMin = Math.round(diffMs / 60_000);
  if (diffMin < 60) {
    return `${diffMin}分钟`;
  }
  if (diffMin < 1440) {
    return `${Math.round(diffMin / 60)}小时`;
  }
  return `${Math.round(diffMin / 1440)}天`;
}

/** KPI 概览 + 运行状态文案（与旧页 renderOverview 一致）。 */
export function computeOverview(pipeline: PipelineDetail, stagesDict: StagesDict, now?: Date): PipelineOverview {
  const enabledAgents = getEnabledAgents(pipeline.agents);
  let doneCount = 0;
  let runningAgentId: string | null = null;

  for (const agentId of enabledAgents) {
    if (!isKnownAgent(agentId)) {
      continue;
    }
    const progress = getAgentProgress(stagesDict, AGENT_CONFIG[agentId].stages);
    if (progress.isDone) {
      doneCount += 1;
    } else if (!runningAgentId && progress.isRunning) {
      runningAgentId = agentId;
    }
  }

  const totalAgents = enabledAgents.length || 1;
  const pct = Math.round((doneCount / totalAgents) * 100);
  const candidates = countCandidatesFromStages(pipeline.stages);
  const elapsedText = formatElapsed(pipeline.created_at, pipeline.completed_at, pipeline.status === "completed", now);

  let statusKind: PipelineOverview["statusKind"] = "pending";
  let statusMessage = "等待启动";
  if (runningAgentId && isKnownAgent(runningAgentId)) {
    const cfg = AGENT_CONFIG[runningAgentId];
    statusKind = "running";
    statusMessage = `${cfg.name}正在${cfg.desc || "执行任务"}中`;
  } else if (pipeline.status === "completed") {
    statusKind = "done";
    statusMessage = "岗位已完成";
  } else if (doneCount === totalAgents && totalAgents > 0) {
    statusKind = "running";
    statusMessage = "等待最终确认";
  } else if (pipeline.status === "waiting_human") {
    statusKind = "running";
    statusMessage = "等待人工处理";
  } else if (doneCount > 0) {
    // 部分 Agent 已完成、后续等待手动触发：与顶部徽标保持一致（ISSUE-0-04）
    statusKind = "running";
    statusMessage = "进行中";
  }

  return { pct, doneCount, totalAgents, candidates, elapsedText, statusKind, statusMessage };
}

/** 阶段产出摘要（与旧页 renderAgentCard 的 outputText 分支一致）。 */
export function getStageOutputSummary(output: StageOutput | null): string {
  if (!output) {
    return "";
  }

  if (typeof output.resume_count === "number" && output.resume_count > 0) {
    return `✓ ${output.resume_count}份`;
  }
  if (typeof output.pass_count === "number" && output.pass_count > 0) {
    return `✓ ${output.pass_count}人`;
  }
  const jd = output.jd;
  if (jd && typeof jd === "object" && !Array.isArray(jd)) {
    const title = (jd as Record<string, unknown>).title;
    if (typeof title === "string" && title) {
      return `✓ ${title}`;
    }
  }
  if (output.profile) {
    return "✓ 22维";
  }
  return "✓ 已生成";
}

export type AgentCardStatus = {
  kind: "done" | "running" | "pending";
  text: string;
  progress: number;
};

/**
 * Agent 卡片状态（与旧页 renderAgentCard 一致）：
 * 全部阶段 done 才算完成，与 stepper 的末阶段判定不同。
 */
export function getAgentCardStatus(stagesDict: StagesDict, stageIds: string[]): AgentCardStatus {
  const doneStages = stageIds.filter((stageId) => stagesDict[stageId]?.status === "done").length;
  const anyRunning = stageIds.some((stageId) => stagesDict[stageId]?.status === "running");
  const allDone = stageIds.length > 0 && doneStages === stageIds.length;
  const progress = stageIds.length ? Math.round((doneStages / stageIds.length) * 100) : 0;

  if (allDone) {
    return { kind: "done", text: "已完成", progress };
  }
  if (anyRunning) {
    return { kind: "running", text: "进行中", progress };
  }
  // 部分阶段已完成但等待手动触发下一阶段：显示“进行中”而非“待启动”（ISSUE-1-03）
  if (doneStages > 0) {
    return { kind: "running", text: "进行中", progress };
  }
  return { kind: "pending", text: "待启动", progress };
}

/** 创建日期短格式（旧页 toLocaleDateString('zh-CN')）。 */
export function formatCreatedDate(createdAt: string | undefined): string {
  if (!createdAt) {
    return "";
  }
  const date = new Date(createdAt);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleDateString("zh-CN");
}
