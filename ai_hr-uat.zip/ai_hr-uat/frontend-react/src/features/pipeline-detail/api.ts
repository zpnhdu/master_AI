import { ApiError, requestWithTimeout } from "../pipelines/api";

export type StageOutput = Record<string, unknown>;

export type PipelineDetailStage = {
  stage_id: string;
  status: string;
  output: StageOutput | null;
};

export type PipelineDetail = {
  id: string;
  role: string;
  pipeline_type?: string;
  role_type?: string;
  status?: string;
  created_at?: string;
  completed_at?: string;
  agents: string[];
  stages: PipelineDetailStage[];
};

export type PipelineCandidate = {
  id?: string;
  name: string;
  phone: string;
};

export type SimpleImportRequest = {
  candidates: Array<{ name: string; phone: string }>;
};

export type SimpleImportResponse = {
  created: number;
  candidates: PipelineCandidate[];
  errors: string[];
};

export type OcrImportResponse = {
  candidates: Array<{ name: string; phone: string }>;
};

export type KGRecommendation = {
  id: string;
  name: string;
  type?: string;
  definition?: string;
  relevance?: number;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getString(value: unknown): string | undefined {
  return typeof value === "string" ? value : undefined;
}

function getStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((item): item is string => typeof item === "string");
  }

  if (typeof value === "string") {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
    } catch {
      return [];
    }
  }

  return [];
}

function normalizeOutput(value: unknown): StageOutput | null {
  if (isRecord(value)) {
    return value;
  }

  if (typeof value === "string" && value.trim()) {
    // 后端偶发双重编码，最多解两层
    let text: string = value;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const parsed: unknown = JSON.parse(text);
        if (isRecord(parsed)) {
          return parsed;
        }
        if (typeof parsed !== "string") {
          return null;
        }
        text = parsed;
      } catch {
        return null;
      }
    }
  }

  return null;
}

function normalizeStage(value: unknown): PipelineDetailStage | null {
  if (!isRecord(value)) {
    return null;
  }

  const stageId = getString(value.stage_id);
  if (!stageId) {
    return null;
  }

  return {
    stage_id: stageId,
    status: getString(value.status) ?? "pending",
    output: normalizeOutput(value.output),
  };
}

function normalizeCandidate(value: unknown): PipelineCandidate | null {
  if (!isRecord(value)) {
    return null;
  }

  const name = getString(value.name) ?? "";
  const phone = getString(value.phone) ?? "";
  if (!name && !phone) {
    return null;
  }

  const candidate: PipelineCandidate = { name, phone };
  const id = getString(value.id);
  if (id) {
    candidate.id = id;
  }
  return candidate;
}

/** 读取错误响应体里的 detail 字段，用于透传后端业务错误信息。 */
async function readErrorDetail(response: Response, fallback: string): Promise<string> {
  try {
    const data: unknown = await response.json();
    if (isRecord(data)) {
      const detail = getString(data.detail);
      if (detail) {
        return detail;
      }
    }
  } catch {
    // 忽略解析失败，使用兜底文案
  }
  return `${fallback}：${response.status}`;
}

export async function fetchPipelineDetail(pipelineId: string): Promise<PipelineDetail> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}`,
    { credentials: "include" },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "岗位加载失败"), {
          status: response.status,
        });
      }

      const data: unknown = await response.json();
      if (!isRecord(data)) {
        throw new ApiError("岗位数据格式异常", { status: response.status });
      }

      return {
        id: getString(data.id) ?? getString(data.pipeline_id) ?? pipelineId,
        role: getString(data.role) ?? "未命名岗位",
        pipeline_type: getString(data.pipeline_type),
        role_type: getString(data.role_type),
        status: getString(data.status),
        created_at: getString(data.created_at),
        completed_at: getString(data.completed_at),
        agents: getStringArray(data.agents),
        stages: Array.isArray(data.stages)
          ? data.stages.flatMap((stage) => {
              const normalized = normalizeStage(stage);
              return normalized ? [normalized] : [];
            })
          : [],
      };
    },
  );
}

export async function fetchPipelineCandidates(pipelineId: string): Promise<PipelineCandidate[]> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/candidates`,
    { credentials: "include" },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(`候选人加载失败：${response.status}`, { status: response.status });
      }

      const data: unknown = await response.json();
      if (!Array.isArray(data)) {
        return [];
      }
      return data.flatMap((item) => {
        const candidate = normalizeCandidate(item);
        return candidate ? [candidate] : [];
      });
    },
  );
}

export async function autoRunPipeline(pipelineId: string): Promise<void> {
  await requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/auto-run`,
    { method: "POST", credentials: "include" },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "启动失败"), {
          status: response.status,
        });
      }
    },
  );
}

export async function simpleImportCandidates(
  pipelineId: string,
  request: SimpleImportRequest,
): Promise<SimpleImportResponse> {
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/candidates/simple-import`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(request),
    },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "导入失败"), { status: response.status });
      }
      const data: unknown = await response.json();
      if (!isRecord(data)) return { created: 0, candidates: [], errors: [] };
      return {
        created: typeof data.created === "number" ? data.created : 0,
        candidates: Array.isArray(data.candidates)
          ? data.candidates.flatMap((item) => {
              const candidate = normalizeCandidate(item);
              return candidate ? [candidate] : [];
            })
          : [],
        errors: Array.isArray(data.errors)
          ? data.errors.filter((item): item is string => typeof item === "string")
          : [],
      };
    },
  );
}

export async function ocrImportCandidates(pipelineId: string, imageFile: File): Promise<OcrImportResponse> {
  const formData = new FormData();
  formData.append("image_file", imageFile);
  return requestWithTimeout(
    `/api/pipelines/${encodeURIComponent(pipelineId)}/candidates/ocr-import`,
    { method: "POST", credentials: "include", body: formData },
    async (response) => {
      if (!response.ok) {
        throw new ApiError(await readErrorDetail(response, "识别失败"), { status: response.status });
      }
      const data: unknown = await response.json();
      if (!isRecord(data) || !Array.isArray(data.candidates)) return { candidates: [] };
      return {
        candidates: data.candidates.flatMap((item) => {
          if (!isRecord(item)) return [];
          const name = getString(item.name) ?? "";
          const phone = getString(item.phone) ?? "";
          return name || phone ? [{ name, phone }] : [];
        }),
      };
    },
  );
}

export async function fetchKGRecommendations(role: string): Promise<KGRecommendation[]> {
  return requestWithTimeout(
    "/api/knowledge/recommend",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ role, stage: "" }),
    },
    async (response) => {
      if (!response.ok) {
        // 知识推荐是辅助信息，失败不阻塞页面
        return [];
      }

      const data: unknown = await response.json();
      if (!isRecord(data) || !Array.isArray(data.recommendations)) {
        return [];
      }

      return data.recommendations.flatMap((item) => {
        if (!isRecord(item)) {
          return [];
        }
        const id = getString(item.id);
        const name = getString(item.name);
        if (!id || !name) {
          return [];
        }
        const recommendation: KGRecommendation = { id, name };
        const type = getString(item.type);
        const definition = getString(item.definition);
        if (type) {
          recommendation.type = type;
        }
        if (definition) {
          recommendation.definition = definition;
        }
        if (typeof item.relevance === "number") {
          recommendation.relevance = item.relevance;
        }
        return [recommendation];
      });
    },
  );
}
