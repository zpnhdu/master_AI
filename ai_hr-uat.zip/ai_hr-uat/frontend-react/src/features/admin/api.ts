import { requestJson } from "../agent-workbench/api";

export type AdminUser = {
  id: string;
  username: string;
  display_name: string;
  role_id: string;
  role_name?: string;
  is_active: boolean;
  last_login_at?: string;
  hr_contact?: string;
  hr_qr_code_storage_key?: string;
  hr_qr_code_url?: string;
  email_provider?: string;
  email_smtp_host?: string;
  email_smtp_port?: number;
  email_smtp_security?: string;
  email_imap_host?: string;
  email_imap_port?: number;
  email_imap_security?: string;
};

export type EmailProvider = {
  key: string;
  label: string;
  smtp: { host: string; port: number; security: string };
  imap: { host: string; port: number; security: string };
};

export type AdminRole = {
  id: string;
  name: string;
  description?: string;
  permissions: string[];
  is_system: boolean;
  user_count?: number;
};

export type AdminPermission = {
  id: string;
  label: string;
};

export type ListUsersResponse = { users: AdminUser[] };
export type ListRolesResponse = { roles: AdminRole[] };
export type ListPermissionsResponse = { permissions: AdminPermission[] };

export type CreateUserPayload = {
  username: string;
  display_name: string;
  password: string;
  role_id: string;
  is_active: boolean;
  hr_contact: string;
  email_provider: string;
  credential: string;
  smtp_host?: string;
  smtp_port?: number;
  smtp_security?: string;
  imap_host?: string;
  imap_port?: number;
  imap_security?: string;
  hr_qr_code_storage_key?: string;
};

export type UpdateUserPayload = {
  display_name?: string;
  password?: string;
  role_id?: string;
  is_active?: boolean;
  hr_contact?: string;
  email_provider?: string;
  credential?: string;
  smtp_host?: string;
  smtp_port?: number;
  smtp_security?: string;
  imap_host?: string;
  imap_port?: number;
  imap_security?: string;
  hr_qr_code_storage_key?: string;
};

export type EmailProvidersResponse = { providers: EmailProvider[] };
export type HrQrUploadResponse = { storage_key: string; url: string };

export type UpdateRolePayload = {
  description?: string;
  permissions?: string[];
};

export function fetchUsers() {
  return requestJson<ListUsersResponse>("/api/admin/users", {}, "用户列表加载失败");
}

export function createUser(payload: CreateUserPayload) {
  return requestJson<AdminUser>(
    "/api/admin/users",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    },
    "用户创建失败",
  );
}

export function updateUser(userId: string, payload: UpdateUserPayload) {
  return requestJson<AdminUser>(
    `/api/admin/users/${encodeURIComponent(userId)}`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    },
    "用户更新失败",
  );
}

export function deleteUser(userId: string) {
  return requestJson<{ status: string }>(
    `/api/admin/users/${encodeURIComponent(userId)}`,
    {
      method: "DELETE",
    },
    "用户删除失败",
  );
}

export function fetchRoles() {
  return requestJson<ListRolesResponse>("/api/admin/roles", {}, "角色列表加载失败");
}

export function updateRole(roleId: string, payload: UpdateRolePayload) {
  return requestJson<AdminRole>(
    `/api/admin/roles/${encodeURIComponent(roleId)}`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    },
    "角色更新失败",
  );
}

export function deleteRole(roleId: string) {
  return requestJson<{ status: string }>(
    `/api/admin/roles/${encodeURIComponent(roleId)}`,
    {
      method: "DELETE",
    },
    "角色删除失败",
  );
}

export function fetchPermissions() {
  return requestJson<ListPermissionsResponse>("/api/admin/permissions", {}, "权限列表加载失败");
}

export function fetchEmailProviders() {
  return requestJson<EmailProvidersResponse>("/api/admin/email-providers", {}, "邮箱服务商列表加载失败");
}

export function uploadHrQr(file: File, oldStorageKey?: string) {
  const body = new FormData();
  body.append("file", file);
  if (oldStorageKey) {
    body.append("old_storage_key", oldStorageKey);
  }
  return requestJson<HrQrUploadResponse>("/api/admin/hr-qr", { method: "POST", body }, "二维码上传失败");
}
