import { requestJson } from "../agent-workbench/api";

/**
 * 统一 Agent 会话（/api/conversations/*）。
 * 对齐旧版 frontend/shared.js 的 sendAgentConversation / confirmAgentConversation 流程：
 * 发送消息 → 生成命令（clarifying / awaiting_confirm）→ 确认或取消 → queued/running → succeeded。
 */

export type ConversationSession = {
  id: string;
  pipeline_id: string;
  agent_id: string;
  actor_id?: string;
  status?: string;
  [key: string]: unknown;
};

export type ConversationAttachment = {
  id: string;
  url?: string;
  filename?: string;
  [key: string]: unknown;
};

export type ConversationMessage = {
  id?: string;
  role?: string;
  content?: string;
  command_id?: string;
  attachments?: ConversationAttachment[];
  created_at?: string;
  [key: string]: unknown;
};

export type ConversationResource = {
  key: string;
  data?: unknown;
  [key: string]: unknown;
};

export type ConversationJob = {
  id?: string;
  progress?: number;
  error_code?: string;
  error_message?: string;
  [key: string]: unknown;
};

export type ConversationLatestData = {
  resources?: ConversationResource[];
  jobs?: ConversationJob[];
  revision_map?: Record<string, unknown>;
  [key: string]: unknown;
};

export type ConversationCommand = {
  id: string;
  session_id?: string;
  intent?: string;
  status: string;
  preview?: Record<string, unknown>;
  preview_hash?: string;
  result?: Record<string, unknown>;
  created_at?: string;
  updated_at?: string;
  executed_at?: string;
  [key: string]: unknown;
};

export type ConversationState = {
  messages?: ConversationMessage[];
  recent_commands?: ConversationCommand[];
  latest_data?: ConversationLatestData;
  [key: string]: unknown;
};

export type ConversationCommandResponse = {
  command: ConversationCommand;
  latest_data?: ConversationLatestData;
  [key: string]: unknown;
};

export function ensureConversationSession(pipelineId: string, agentId: string) {
  return requestJson<{ session: ConversationSession }>(
    "/api/conversations/sessions/ensure",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pipeline_id: pipelineId, agent_id: agentId }),
    },
    "会话初始化失败",
  );
}

export function fetchConversationState(sessionId: string, limit = 100) {
  return requestJson<ConversationState>(
    `/api/conversations/sessions/${encodeURIComponent(sessionId)}/state?limit=${limit}`,
    {},
    "会话状态加载失败",
  );
}

export type SubmitConversationMessageBody = {
  content: string;
  source?: string;
  continuationCommandId?: string;
  selectedCandidateId?: string;
  selectedScheduleId?: string;
  attachmentIds?: string[];
  baseVersionId?: string;
  backgroundElementId?: string;
  elementIds?: string[];
  useDefaultMaterials?: boolean;
};

export function submitConversationMessage(sessionId: string, body: SubmitConversationMessageBody) {
  return requestJson<ConversationCommandResponse>(
    `/api/conversations/sessions/${encodeURIComponent(sessionId)}/messages`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_request_id: conversationRequestId(),
        content: body.content,
        source: body.source ?? "text",
        continuation_command_id: body.continuationCommandId ?? "",
        selected_candidate_id: body.selectedCandidateId ?? "",
        selected_schedule_id: body.selectedScheduleId ?? "",
        attachment_ids: body.attachmentIds ?? [],
        base_version_id: body.baseVersionId ?? "",
        background_element_id: body.backgroundElementId ?? "",
        element_ids: body.elementIds ?? [],
        use_default_materials: body.useDefaultMaterials ?? false,
      }),
    },
    "发送失败",
  );
}

export function confirmConversationCommand(commandId: string, previewHash: string) {
  return requestJson<ConversationCommandResponse>(
    `/api/conversations/commands/${encodeURIComponent(commandId)}/confirm`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ preview_hash: previewHash }),
    },
    "确认失败",
  );
}

export function cancelConversationCommand(commandId: string) {
  return requestJson<ConversationCommandResponse>(
    `/api/conversations/commands/${encodeURIComponent(commandId)}/cancel`,
    { method: "POST" },
    "取消失败",
  );
}

export function repreviewConversationCommand(commandId: string) {
  return requestJson<ConversationCommandResponse>(
    `/api/conversations/commands/${encodeURIComponent(commandId)}/repreview`,
    { method: "POST" },
    "重新预览失败",
  );
}

export function undoConversationCommand(commandId: string) {
  return requestJson<ConversationCommandResponse>(
    `/api/conversations/commands/${encodeURIComponent(commandId)}/undo`,
    { method: "POST" },
    "撤销失败",
  );
}

export function uploadConversationAttachment(sessionId: string, file: File) {
  const body = new FormData();
  body.append("file", file);
  return requestJson<{ asset: ConversationAttachment }>(
    `/api/conversations/sessions/${encodeURIComponent(sessionId)}/attachments`,
    { method: "POST", body },
    "附件上传失败",
  );
}

function conversationRequestId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `request_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
