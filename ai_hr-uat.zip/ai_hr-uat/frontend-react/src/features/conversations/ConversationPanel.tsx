import { Alert, Button, Input, Spin, Tag, Typography, Upload } from 'antd';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import type {
  ConversationAttachment,
  ConversationCommand,
  ConversationLatestData,
  ConversationMessage,
} from './api';
import { useVoiceRecorder } from '../xiao-wen/useVoiceRecorder';
import { useConversation } from './useConversation';

/** 传给各 Agent 命令卡片的动作集合。 */
export type CommandActions = {
  confirm: (command: ConversationCommand) => void;
  cancel: (command: ConversationCommand) => void;
  repreview: (command: ConversationCommand) => void;
  undo: (command: ConversationCommand) => void;
  /** 澄清卡片里点选候选人 / 排期，等价旧版 selectConversationCandidate / selectConversationSchedule。 */
  selectCandidate: (command: ConversationCommand, option: { candidate_id?: string; candidate_name?: string }) => void;
  selectSchedule: (command: ConversationCommand, option: { schedule_id?: string }) => void;
  /** 把文本填回输入框（例如「继续修改」「对话改题」）。 */
  fillComposer: (text: string) => void;
  /** 直接重发一条指令（失败卡片的「重新提交」）。 */
  sendDirect: (text: string) => void;
  actingCommandId: string;
};

type ConversationAction = 'confirm' | 'cancel' | 'repreview' | 'undo';

type TimelineItem =
  | { type: 'message'; key: string; message: ConversationMessage; retryText?: string }
  | { type: 'command'; key: string; command: ConversationCommand };

export function ConversationPanel({
  pipelineId,
  agentId,
  avatar,
  placeholder,
  emptyHint,
  emptyContent,
  hideEmptyHint = false,
  supportAttachment = false,
  attachmentButtonText = '图片',
  composerActions,
  conversationCard,
  quickPrompts,
  sendButtonText,
  supportVoice = false,
  baseVersionId = '',
  backgroundElementId = '',
  elementIds = [],
  useDefaultMaterials = false,
  draft,
  onDraftChange,
  onLatestData,
  renderCommand,
  dock = false,
  dockExpanded = true,
  onDockExpandedChange,
  dockContext,
  contextCandidateId = '',
  senderName,
  candidateNames = {},
  composerDisabled = false,
  beforeSend,
  onActivityChange,
  onCommandUpdated,
}: {
  pipelineId: string;
  agentId: string;
  avatar: string;
  placeholder?: string;
  emptyHint?: string | null;
  emptyContent?: ReactNode;
  hideEmptyHint?: boolean;
  supportAttachment?: boolean;
  attachmentButtonText?: string;
  /** 输入框左侧的页面级操作（如海报参考图上传）。 */
  composerActions?: ReactNode;
  /** 对话流中的页面级操作卡片（如小面的流程动作）。 */
  conversationCard?: ReactNode;
  /** 输入框上方的常用指令。 */
  quickPrompts?: Array<{ label: string; value: string }>;
  /** 发送按钮内容；默认保留文字，窄布局可替换成图标。 */
  sendButtonText?: ReactNode;
  supportVoice?: boolean;
  baseVersionId?: string;
  /** 小海当前选中的品牌背景与装饰，随自然语言修改一起提交。 */
  backgroundElementId?: string;
  elementIds?: string[];
  useDefaultMaterials?: boolean;
  draft: string;
  onDraftChange: (value: string) => void;
  onLatestData?: (data: ConversationLatestData) => void;
  renderCommand?: (command: ConversationCommand, actions: CommandActions, latestData?: ConversationLatestData) => ReactNode;
  /** dock 模式：时间线可收起，仅保留常驻输入条（小面底部指令条）。 */
  dock?: boolean;
  dockExpanded?: boolean;
  onDockExpandedChange?: (expanded: boolean) => void;
  /** dock 头部左侧的上下文区（如当前候选人 Chip），由页面注入。 */
  dockContext?: ReactNode;
  /** 新指令发送时携带的默认候选人（指令未点名时后端据此免澄清）。 */
  contextCandidateId?: string;
  senderName?: string;
  candidateNames?: Record<string, string>;
  /** 禁用当前上下文的自然语言改题输入（例如面试已结束的候选人）。 */
  composerDisabled?: boolean;
  /** 页面可在发送前阻止会覆盖本地草稿的对话操作。 */
  beforeSend?: (text: string) => boolean;
  /** 把会话的待处理状态同步给页面，用于锁定冲突操作。 */
  onActivityChange?: (activity: { pendingCount: number; busy: boolean }) => void;
  /** 页面可在确认/取消/重预览/撤销后同步业务选中项。 */
  onCommandUpdated?: (command: ConversationCommand, action: ConversationAction) => void;
}) {
  const conversation = useConversation({ pipelineId, agentId, onLatestData });
  const [attachment, setAttachment] = useState<ConversationAttachment | null>(null);
  const [uploading, setUploading] = useState(false);
  const [sendError, setSendError] = useState('');
  const listRef = useRef<HTMLDivElement | null>(null);
  const lastCountRef = useRef(0);

  const commandMap = useMemo(() => {
    const map = new Map<string, ConversationCommand>();
    for (const command of conversation.commands) map.set(command.id, command);
    return map;
  }, [conversation.commands]);

  const pendingCount = useMemo(
    () =>
      conversation.commands.filter((command) =>
        ['clarifying', 'awaiting_confirm', 'stale'].includes(command.status ?? ''),
      ).length,
    [conversation.commands],
  );
  // dock 收起时出现新的待处理命令（澄清/待确认/需重新预览）→ 自动展开提醒处理。
  const prevPendingCountRef = useRef(pendingCount);
  useEffect(() => {
    const previous = prevPendingCountRef.current;
    prevPendingCountRef.current = pendingCount;
    if (dock && !dockExpanded && pendingCount > previous) onDockExpandedChange?.(true);
  }, [dock, dockExpanded, pendingCount, onDockExpandedChange]);

  useEffect(() => {
    onActivityChange?.({
      pendingCount,
      busy: Boolean(conversation.sending || conversation.actingCommandId),
    });
  }, [conversation.actingCommandId, conversation.sending, onActivityChange, pendingCount]);

  const voice = useVoiceRecorder({
    onTranscript: (text) => {
      const current = draft.trim();
      onDraftChange(current ? `${current}\n${text}` : text);
    },
    disabled: composerDisabled || !supportVoice || conversation.sending,
  });

  useEffect(() => {
    if (composerDisabled && voice.status === 'recording') voice.toggle();
  }, [composerDisabled, voice.status, voice.toggle]);

  // 对齐旧版 restoreAgentConversationMessages：assistant 消息带命令时渲染命令卡片，
  // 同一命令只渲染一次；未被消息引用的命令（历史恢复）追加在时间线末尾。
  const timeline = useMemo<TimelineItem[]>(() => {
    const items: TimelineItem[] = [];
    const rendered = new Set<string>();
    let lastUserContent = '';
    conversation.messages.forEach((message, index) => {
      const command = message.command_id ? commandMap.get(message.command_id) : undefined;
      if (message.role === 'user') lastUserContent = message.content ?? '';
      if (message.role === 'assistant' && command && renderCommand) {
        if (rendered.has(command.id)) return;
        rendered.add(command.id);
        items.push({ type: 'command', key: `cmd-${command.id}`, command });
        return;
      }
      items.push({
        type: 'message',
        key: message.id ?? `msg-${index}`,
        message,
        retryText: message.role === 'assistant' && isRetryableAssistantMessage(message.content ?? '')
          ? lastUserContent
          : undefined,
      });
    });
    for (const command of conversation.commands) {
      if (!renderCommand) break;
      if (!rendered.has(command.id)) {
        rendered.add(command.id);
        items.push({ type: 'command', key: `cmd-${command.id}`, command });
      }
    }
    return items;
  }, [conversation.messages, conversation.commands, commandMap, renderCommand]);
  const hasConversationContent = timeline.length > 0 || conversation.echoes.length > 0 || conversation.sending;
  const shouldRenderMessages = (!dock || dockExpanded) && (hasConversationContent || !hideEmptyHint);

  // 仅当时间线变长（新消息/新卡片）时滚动到底部，轮询刷新不打扰阅读。
  useEffect(() => {
    const count = timeline.length + conversation.echoes.length;
    if (count > lastCountRef.current) {
      listRef.current?.scrollTo?.({ top: listRef.current.scrollHeight, behavior: 'smooth' });
    }
    lastCountRef.current = count;
  }, [timeline.length, conversation.echoes.length]);

  const runAction = (command: ConversationCommand, action: ConversationAction, promise: Promise<void>) =>
    void guarded(
      promise.then(() => {
        onCommandUpdated?.(command, action);
      }),
    );

  const actions: CommandActions = {
    confirm: (command) => runAction(command, 'confirm', conversation.confirm(command)),
    cancel: (command) => runAction(command, 'cancel', conversation.cancel(command)),
    repreview: (command) => runAction(command, 'repreview', conversation.repreview(command)),
    undo: (command) => runAction(command, 'undo', conversation.undo(command)),
    selectCandidate: (command, option) =>
      void guarded(
        conversation.send(`选择候选人：${option.candidate_name ?? '候选人'}`, {
          continuationCommandId: command.id,
          selectedCandidateId: option.candidate_id ?? '',
        }),
      ),
    selectSchedule: (command, option) =>
      void guarded(
        conversation.send('选择这场面试', {
          continuationCommandId: command.id,
          selectedScheduleId: option.schedule_id ?? '',
        }),
      ),
    fillComposer: (text) => {
      onDraftChange(text);
      document.getElementById(`convo-input-${agentId}`)?.focus();
    },
    sendDirect: (text) => void guarded(conversation.send(text, {
      baseVersionId,
      backgroundElementId,
      elementIds,
      useDefaultMaterials,
    })),
    actingCommandId: conversation.actingCommandId,
  };

  async function guarded(promise: Promise<unknown>) {
    try {
      await promise;
    } catch (error) {
      setSendError(error instanceof Error ? error.message : '操作失败');
    }
  }

  async function handleSend() {
    const text = draft.trim();
    if (!text || conversation.sending || voice.status !== 'idle') return;
    if (beforeSend && !beforeSend(text)) return;
    setSendError('');
    const sentAttachment = attachment;
    try {
      const ok = await conversation.send(text, {
        attachment: sentAttachment,
        baseVersionId,
        backgroundElementId,
        elementIds,
        useDefaultMaterials,
        selectedCandidateId: contextCandidateId,
      });
      if (ok) {
        onDraftChange('');
        setAttachment(null);
      }
    } catch (error) {
      setSendError(error instanceof Error ? error.message : '发送失败');
    }
  }

  if (conversation.loading) {
    return (
      <div className="convo-panel convo-panel--status">
        <Spin size="small" /> <Typography.Text type="secondary">会话加载中…</Typography.Text>
      </div>
    );
  }
  if (conversation.error) {
    return (
      <div className="convo-panel convo-panel--status">
        <Alert
          type="error"
          showIcon
          message="对话服务加载失败"
          description={conversation.error instanceof Error ? conversation.error.message : '请稍后重试'}
          action={<Button size="small" onClick={conversation.retry}>重试</Button>}
        />
      </div>
    );
  }

  return (
    <div className="convo-panel">
      {shouldRenderMessages ? (
      <div className="convo-panel__messages" ref={listRef}>
        {!timeline.length && !conversation.echoes.length && !hideEmptyHint ? (
          emptyContent ?? (
            <Typography.Text type="secondary" className="convo-panel__empty">
              {emptyHint ?? '输入自然语言指令，先预览再确认执行。'}
            </Typography.Text>
          )
        ) : null}
        {timeline.map((item) =>
          item.type === 'message' ? (
            <MessageBubble
              key={item.key}
              message={item.message}
              avatar={avatar}
              senderName={item.message.command_id ? resolveMessageCandidateName(commandMap.get(item.message.command_id), candidateNames) || senderName : senderName}
              onRetry={item.retryText
                ? () => void guarded(conversation.send(item.retryText as string, {
                  baseVersionId,
                  backgroundElementId,
                  elementIds,
                  useDefaultMaterials,
                }))
                : undefined}
              retryDisabled={conversation.sending}
            />
          ) : renderCommand ? (
            <div className="convo-msg" key={item.key}>
              <span className="convo-avatar" aria-hidden="true">{avatar}</span>
              <div className="convo-card">{renderCommand(item.command, actions, conversation.latestData)}</div>
            </div>
          ) : null,
        )}
        {conversation.echoes.map((echo) => (
          <div className="convo-msg convo-msg--user" key={echo.id}>
            <div className="convo-user-group">
              {senderName ? <span className="convo-user-label">{senderName}</span> : null}
              <span className="convo-bubble convo-bubble--user">
              {echo.content}
              {echo.attachments?.length ? (
                <span className="convo-ref-images">
                  {echo.attachments.map((item) =>
                    item.url ? (
                      <img
                        className="convo-ref-img"
                        src={item.url}
                        alt={item.filename ?? '参考图'}
                        key={item.id}
                        loading="lazy"
                        decoding="async"
                      />
                    ) : null,
                  )}
                </span>
              ) : null}
              </span>
            </div>
          </div>
        ))}
        {conversationCard ? (
          <div className="convo-msg">
            <span className="convo-avatar" aria-hidden="true">{avatar}</span>
            <div className="convo-card convo-card--workflow">{conversationCard}</div>
          </div>
        ) : null}
        {conversation.sending ? (
          <div className="convo-msg">
            <span className="convo-avatar" aria-hidden="true">{avatar}</span>
            <span className="convo-bubble convo-bubble--assistant">
              <Spin size="small" /> 正在理解并生成操作预览
            </span>
          </div>
        ) : null}
      </div>
      ) : null}
      {quickPrompts?.length ? (
        <div className="convo-quick-prompts" aria-label="常用指令">
          {quickPrompts.map((prompt) => (
            <button
              type="button"
              className="convo-quick-prompt"
              key={prompt.value}
              disabled={composerDisabled}
              onClick={() => {
                onDraftChange(prompt.value);
                requestAnimationFrame(() => document.getElementById(`convo-input-${agentId}`)?.focus());
              }}
            >
              {prompt.label}
            </button>
          ))}
        </div>
      ) : null}
      {dock ? (
        <div className="convo-dock-header">
          {dockContext}
          <span style={{ flex: 1 }} />
          {pendingCount ? (
            <Tag color="orange" style={{ marginInlineEnd: 0 }}>
              {pendingCount} 项待处理
            </Tag>
          ) : null}
        </div>
      ) : null}
      {sendError ? (
        <Alert type="error" showIcon message={sendError} closable onClose={() => setSendError('')} />
      ) : null}
      {attachment ? (
        <div className="convo-attachment">
          {attachment.url ? (
            <img className="convo-ref-img" src={attachment.url} alt="" loading="lazy" decoding="async" />
          ) : null}
          <Typography.Text ellipsis style={{ flex: 1, fontSize: 12 }}>
            {attachment.filename ?? '参考图'}
          </Typography.Text>
          <Button size="small" type="text" onClick={() => setAttachment(null)}>
            移除
          </Button>
        </div>
      ) : null}
      <div className="convo-composer">
        {composerActions}
        {supportAttachment ? (
          <Upload
            accept="image/png,image/jpeg,image/webp"
            showUploadList={false}
            beforeUpload={(file) => {
              setUploading(true);
              conversation
                .uploadAttachment(file)
                .then(setAttachment)
                .catch((error: unknown) =>
                  setSendError(error instanceof Error ? error.message : '附件上传失败'),
                )
                .finally(() => setUploading(false));
              return false;
            }}
          >
            <Button loading={uploading} aria-label={`上传${attachmentButtonText}`}>
              {attachmentButtonText}
            </Button>
          </Upload>
        ) : null}
        <Input.TextArea
          id={`convo-input-${agentId}`}
          value={draft}
          autoSize={{ minRows: 1, maxRows: 4 }}
          onChange={(event) => onDraftChange(event.target.value)}
          onPressEnter={(event) => {
            if (!event.shiftKey) {
              event.preventDefault();
              void handleSend();
            }
          }}
          placeholder={placeholder ?? '输入指令…'}
          disabled={composerDisabled || conversation.sending || voice.status !== 'idle'}
        />
        {supportVoice ? (
          <Button
            className={`convo-voice-button${voice.status === 'recording' ? ' convo-voice-button--recording' : ''}`}
            aria-label={voice.status === 'recording' ? '停止录音' : '开始录音'}
            title={voice.status === 'recording' ? '停止录音' : '开始录音'}
            disabled={composerDisabled || !voice.supported || conversation.sending || voice.status === 'transcribing'}
            onClick={voice.toggle}
          >
            {voice.status === 'recording' ? '■' : '🎙'}
          </Button>
        ) : null}
        <Button
          type="primary"
          loading={conversation.sending}
          disabled={composerDisabled}
          aria-label="发送"
          onClick={() => void handleSend()}
        >
          {sendButtonText ?? '发送'}
        </Button>
      </div>
      {supportVoice && (voice.status !== 'idle' || voice.notice) ? (
        <Typography.Text
          className={`convo-voice-status${voice.noticeType ? ` convo-voice-status--${voice.noticeType}` : ''}`}
          role="status"
          aria-live="polite"
        >
          {voice.status === 'recording'
            ? `正在录音 ${formatVoiceTime(voice.seconds)}，点击停止`
            : voice.status === 'transcribing'
              ? '语音转文字中，请稍候…'
              : voice.notice}
        </Typography.Text>
      ) : null}
    </div>
  );
}

function formatVoiceTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const remainder = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
}

function resolveMessageCandidateName(command: ConversationCommand | undefined, names: Record<string, string>) {
  if (!command) return '';
  const payload = command.payload as { request_context?: { selected_candidate_id?: string }; candidate_name?: string } | undefined;
  const id = payload?.request_context?.selected_candidate_id || '';
  return names[id] || payload?.candidate_name || String(command.preview?.candidate_name || command.result?.candidate_name || '');
}

function MessageBubble({
  message,
  avatar,
  senderName,
  onRetry,
  retryDisabled = false,
}: {
  message: ConversationMessage;
  avatar: string;
  senderName?: string;
  onRetry?: () => void;
  retryDisabled?: boolean;
}) {
  if (message.role === 'system') {
    return (
      <div className="convo-msg convo-msg--system">
        <span className="convo-system">{message.content}</span>
      </div>
    );
  }
  if (message.role === 'user') {
    return (
      <div className="convo-msg convo-msg--user">
        <div className="convo-user-group">
          {senderName ? <span className="convo-user-label">{senderName}</span> : null}
          <span className="convo-bubble convo-bubble--user">
          {message.content}
          {message.attachments?.length ? (
            <span className="convo-ref-images">
              {message.attachments.map((item, index) =>
                item.url ? (
                      <img
                        className="convo-ref-img"
                        src={item.url}
                        alt={item.filename ?? '参考图'}
                        key={item.id ?? index}
                        loading="lazy"
                        decoding="async"
                      />
                ) : null,
              )}
            </span>
          ) : null}
          </span>
        </div>
      </div>
    );
  }
  return (
    <div className="convo-msg">
      <span className="convo-avatar" aria-hidden="true">{avatar}</span>
      <div className="convo-assistant-group">
        <span className="convo-bubble convo-bubble--assistant">{message.content}</span>
        {onRetry ? (
          <Button
            type="link"
            size="small"
            className="convo-retry-button"
            disabled={retryDisabled}
            onClick={onRetry}
          >
            重试上一条
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function isRetryableAssistantMessage(content: string) {
  return /重试|生成操作预览|生成失败|连接中断/.test(content);
}
