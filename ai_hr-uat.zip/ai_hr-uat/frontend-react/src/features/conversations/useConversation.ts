import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
  cancelConversationCommand,
  confirmConversationCommand,
  ensureConversationSession,
  fetchConversationState,
  repreviewConversationCommand,
  submitConversationMessage,
  undoConversationCommand,
  uploadConversationAttachment,
  type ConversationAttachment,
  type ConversationCommand,
  type ConversationCommandResponse,
  type ConversationLatestData,
  type ConversationMessage,
  type ConversationState,
} from "./api";

/** 对齐旧版 startXhaiConversationPolling：活跃命令 2s 轮询，单次激活最多 5 分钟。 */
const POLL_INTERVAL = 2000;
const POLL_MAX_DURATION = 300_000;

export type SendOptions = {
  continuationCommandId?: string;
  selectedCandidateId?: string;
  selectedScheduleId?: string;
  attachment?: ConversationAttachment | null;
  baseVersionId?: string;
  backgroundElementId?: string;
  elementIds?: string[];
  useDefaultMaterials?: boolean;
};

export type ConversationController = {
  sessionId: string;
  loading: boolean;
  error: unknown;
  messages: ConversationMessage[];
  commands: ConversationCommand[];
  /** 尚未被服务端 state 覆盖的本地回声消息（发送后立即可见）。 */
  echoes: Array<{ id: string; content: string; attachments?: ConversationAttachment[] }>;
  latestData: ConversationLatestData | undefined;
  continuationCommand: ConversationCommand | undefined;
  sending: boolean;
  /** 正在执行 confirm/cancel/repreview/undo 的命令 id。 */
  actingCommandId: string;
  polling: boolean;
  send: (content: string, options?: SendOptions) => Promise<boolean>;
  confirm: (command: ConversationCommand) => Promise<void>;
  cancel: (command: ConversationCommand) => Promise<void>;
  repreview: (command: ConversationCommand) => Promise<void>;
  undo: (command: ConversationCommand) => Promise<void>;
  uploadAttachment: (file: File) => Promise<ConversationAttachment>;
  retry: () => void;
};

export function useConversation({
  pipelineId,
  agentId,
  onLatestData,
}: {
  pipelineId: string;
  agentId: string;
  onLatestData?: (data: ConversationLatestData) => void;
}): ConversationController {
  const queryClient = useQueryClient();
  const [sending, setSending] = useState(false);
  const [actingCommandId, setActingCommandId] = useState("");
  const [echoes, setEchoes] = useState<Array<{ id: string; content: string; attachments?: ConversationAttachment[] }>>(
    [],
  );
  const [pollStartedAt, setPollStartedAt] = useState<number | null>(null);
  const onLatestDataRef = useRef(onLatestData);
  const lastLatestDataRev = useRef("");
  onLatestDataRef.current = onLatestData;

  const sessionQuery = useQuery({
    queryKey: ["conversations", "session", pipelineId, agentId],
    queryFn: () => ensureConversationSession(pipelineId, agentId),
    staleTime: Infinity,
    retry: 1,
  });
  const sessionId = sessionQuery.data?.session?.id ?? "";
  const stateKey = ["conversations", "state", sessionId] as const;

  const stateQuery = useQuery({
    queryKey: stateKey,
    queryFn: () => fetchConversationState(sessionId),
    enabled: Boolean(sessionId),
    refetchInterval: (query) => {
      const state = query.state.data;
      if (!hasActiveCommand(state?.recent_commands)) return false;
      if (agentId !== "xiao_hai" && pollStartedAt && Date.now() - pollStartedAt > POLL_MAX_DURATION) return false;
      return POLL_INTERVAL;
    },
  });

  const state = stateQuery.data;
  const commands = useMemo(() => sortCommands(state?.recent_commands ?? []), [state?.recent_commands]);
  const messages = useMemo(() => state?.messages ?? [], [state?.messages]);
  const active = hasActiveCommand(commands);
  const continuationCommand = useMemo(
    () => [...commands].reverse().find((command) => command.status === "clarifying"),
    [commands],
  );

  // 活跃命令出现/消失时维护轮询计时（对齐旧版 5 分钟上限）。
  useEffect(() => {
    if (active && pollStartedAt === null) setPollStartedAt(Date.now());
    if (!active && pollStartedAt !== null) setPollStartedAt(null);
  }, [active, pollStartedAt]);

  // latest_data 变化时通知页面（页面据此失效对应业务查询）。
  useEffect(() => {
    const latest = state?.latest_data;
    if (!latest) return;
    const rev = JSON.stringify(latest);
    if (rev === lastLatestDataRev.current) return;
    lastLatestDataRev.current = rev;
    onLatestDataRef.current?.(latest);
  }, [state?.latest_data]);

  // 服务端消息回来后清除对应的本地回声。
  useEffect(() => {
    if (!messages.length || !echoes.length) return;
    setEchoes((current) =>
      current.filter(
        (echo) => !messages.some((message) => message.role === "user" && message.content === echo.content),
      ),
    );
  }, [messages, echoes.length]);

  const applyResponse = useCallback(
    (data: ConversationCommandResponse | undefined) => {
      if (!data?.command) return;
      queryClient.setQueryData<ConversationState>(stateKey, (old) => {
        const rest = (old?.recent_commands ?? []).filter((item) => item.id !== data.command.id);
        return {
          ...old,
          recent_commands: [...rest, data.command],
          latest_data: data.latest_data ?? old?.latest_data,
        };
      });
    },
    [queryClient, stateKey],
  );

  const runCommandAction = useCallback(
    async (command: ConversationCommand, action: () => Promise<ConversationCommandResponse>) => {
      if (actingCommandId) return;
      setActingCommandId(command.id);
      try {
        applyResponse(await action());
      } finally {
        setActingCommandId("");
        void stateQuery.refetch();
      }
    },
    [actingCommandId, applyResponse, stateQuery],
  );

  const send = useCallback(
    async (content: string, options: SendOptions = {}) => {
      const text = content.trim();
      if (!sessionId || !text || sending) return false;
      setSending(true);
      if (options.attachment) {
        setEchoes((current) => [
          ...current,
          { id: `echo-${Date.now()}`, content: text, attachments: [options.attachment as ConversationAttachment] },
        ]);
      } else {
        setEchoes((current) => [...current, { id: `echo-${Date.now()}`, content: text }]);
      }
      try {
        const data = await submitConversationMessage(sessionId, {
          content: text,
          source: options.attachment ? "multimodal" : "text",
          continuationCommandId: options.continuationCommandId ?? continuationCommand?.id ?? "",
          selectedCandidateId: options.selectedCandidateId ?? "",
          selectedScheduleId: options.selectedScheduleId ?? "",
          attachmentIds: options.attachment ? [options.attachment.id] : [],
          baseVersionId: options.baseVersionId ?? "",
          backgroundElementId: options.backgroundElementId ?? "",
          elementIds: options.elementIds ?? [],
          useDefaultMaterials: options.useDefaultMaterials ?? false,
        });
        applyResponse(data);
        void stateQuery.refetch();
        return true;
      } catch (error) {
        setEchoes((current) => current.filter((echo) => echo.content !== text));
        throw error;
      } finally {
        setSending(false);
      }
    },
    [sessionId, sending, continuationCommand?.id, applyResponse, stateQuery],
  );

  const uploadAttachment = useCallback(
    async (file: File) => {
      if (!sessionId) throw new Error("会话尚未就绪");
      const result = await uploadConversationAttachment(sessionId, file);
      return result.asset;
    },
    [sessionId],
  );

  return {
    sessionId,
    loading: sessionQuery.isPending || (Boolean(sessionId) && stateQuery.isPending),
    error: sessionQuery.error ?? stateQuery.error,
    messages,
    commands,
    echoes,
    latestData: state?.latest_data,
    continuationCommand,
    sending,
    actingCommandId,
    polling: active && pollStartedAt !== null,
    send,
    confirm: (command) =>
      runCommandAction(command, () => confirmConversationCommand(command.id, command.preview_hash ?? "")),
    cancel: (command) => runCommandAction(command, () => cancelConversationCommand(command.id)),
    repreview: (command) => runCommandAction(command, () => repreviewConversationCommand(command.id)),
    undo: (command) => runCommandAction(command, () => undoConversationCommand(command.id)),
    uploadAttachment,
    retry: () => {
      void sessionQuery.refetch();
      void stateQuery.refetch();
    },
  };
}

function hasActiveCommand(commands: ConversationCommand[] | undefined) {
  return Boolean(commands?.some((command) => command.status === "queued" || command.status === "running"));
}

function sortCommands(commands: ConversationCommand[]) {
  return [...commands].sort((a, b) => (a.created_at ?? "").localeCompare(b.created_at ?? ""));
}
