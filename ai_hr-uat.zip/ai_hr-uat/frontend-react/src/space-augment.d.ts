import "antd";

declare module "antd" {
  interface SpaceProps {
    /** 页面工作台中的纵向操作组需要占满容器宽度。 */
    block?: boolean;
  }
}
