/// <reference types="node" />

import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";

import { describe, expect, it } from "vitest";

const stylesPath = resolve(process.cwd(), "src/styles.css");
const stylesManifest = readFileSync(stylesPath, "utf8");
const styleImports = [...stylesManifest.matchAll(/^@import\s+"([^"]+)";\s*$/gm)].map(
  ([, importPath]) => importPath,
);

function readStylesheet(filePath: string, visited = new Set<string>()): string {
  if (visited.has(filePath)) {
    throw new Error(`cyclic CSS import: ${filePath}`);
  }

  const nextVisited = new Set(visited).add(filePath);
  const source = readFileSync(filePath, "utf8");
  return source.replace(
    /^@import\s+"([^"]+)";[ \t]*(?:\r?\n|$)/gm,
    (_, importPath: string) => readStylesheet(resolve(dirname(filePath), importPath), nextVisited),
  );
}

const styles = readStylesheet(stylesPath);
const expectedStyleImports = [
  "./styles/00-foundation-agent.css",
  "./styles/10-xun-and-agent.css",
  "./styles/20-shell-admin-xun.css",
  "./styles/30-auth-studio.css",
  "./styles/40-knowledge-reader.css",
  "./styles/50-studio-parity.css",
  "./styles/60-pipeline-detail.css",
  "./styles/70-mass-dashboard.css",
  "./styles/80-dashboard-and-talent.css",
  "./styles/90-knowledge.css",
  "./styles/100-material-role.css",
  "./styles/110-written-test.css",
  "./styles/120-xhai.css",
  "./styles/130-mass-interview.css",
  "./styles/140-conversation-cabin.css",
  "./styles/150-shared-final-foundation.css",
  "./styles/160-knowledge-final.css",
  "./styles/170-xhai-final.css",
  "./styles/180-studio-final.css",
] as const;

const FINAL_FOUNDATION_IMPORTS = [
  "./150-shared-final-prelude.css",
  "./shared/page-shell.css",
  "./shared/data-table.css",
  "./150-shared-final-middle.css",
  "./shared/page-shell-responsive.css",
  "./150-shared-final-tail.css",
] as const;

function expectMarkersInOrder(source: string, markers: readonly string[]) {
  const indices = markers.map((marker) => source.indexOf(marker));
  for (const index of indices) {
    expect(index).toBeGreaterThanOrEqual(0);
  }
  for (let index = 1; index < indices.length; index += 1) {
    expect(indices[index - 1]).toBeLessThan(indices[index]);
  }
}

const XIAO_SHAI_SELECTORS = [".agent-topbar__secondary", ".xun-screening-results .xun-result-search"] as const;

const XIAO_PING_SELECTORS = [
  ".xun-workspace--xiao-ping",
  ".xiao-ping-pane",
  ".agent-kpis",
  ".xiao-ping-kpi.ant-card",
  ".xiao-ping-kpi--pass.ant-card",
  ".xiao-ping-kpi--eliminate.ant-card",
  ".xiao-ping-kpi__metric",
  ".xiao-ping-kpi__divider",
  ".xiao-ping-kpi__hint",
  ".xiao-ping-kpi__hint-title",
  ".xiao-ping-kpi__hint-title--eliminate",
  ".xiao-ping-kpi__hint-sub",
] as const;

const XIAO_HAI_SELECTORS = [
  ".xhai-workspace--right-chat .xhai-poster-scroll--stage",
  ".xhai-current-poster__action-group--primary .ant-btn-primary",
] as const;

describe("agent page style contracts", () => {
  it("loads every global fragment through the ordered manifest", () => {
    expect(styleImports).toEqual(expectedStyleImports);
    for (const importPath of expectedStyleImports) {
      expect(() => readStylesheet(resolve(dirname(stylesPath), importPath))).not.toThrow();
    }
    expect(styles).toContain(":root {");
  });

  it("keeps shared primitives before their route-specific final overrides", () => {
    expect(styles.indexOf(".agent-topbar {")).toBeLessThan(
      styles.indexOf(".xhai-app .agent-topbar {"),
    );
    expect(styles.indexOf(".convo-panel__messages {")).toBeLessThan(
      styles.indexOf(".xhai-workspace--right-chat .convo-panel__messages {"),
    );
  });

  it("keeps the final foundation fragments in cascade order", () => {
    const finalFoundationPath = resolve(process.cwd(), "src/styles/150-shared-final-foundation.css");
    const finalFoundationManifest = readFileSync(finalFoundationPath, "utf8");
    const finalFoundationImports = [
      ...finalFoundationManifest.matchAll(/^@import\s+"([^"]+)";\s*$/gm),
    ].map(([, importPath]) => importPath);

    expect(finalFoundationImports).toEqual(FINAL_FOUNDATION_IMPORTS);
    expectMarkersInOrder(readStylesheet(finalFoundationPath), [
      ".page-shell {",
      ".data-table {",
      ".xun-app,",
      ".page-shell__actions > .ant-space,",
      ".knowledge-page__filters {",
    ]);
  });

  it("keeps PageShell and DataTable rules in named shared files", () => {
    const pageShell = readStylesheet(resolve(process.cwd(), "src/styles/shared/page-shell.css"));
    const dataTable = readStylesheet(resolve(process.cwd(), "src/styles/shared/data-table.css"));
    const pageShellResponsive = readStylesheet(
      resolve(process.cwd(), "src/styles/shared/page-shell-responsive.css"),
    );
    expect(pageShell).toContain(".page-shell {");
    expect(pageShell).toContain(".page-shell__header {");
    expect(pageShell).toContain(".page-shell__actions {");
    expect(pageShell).toContain(".page-shell__actions > * {");
    expect(pageShell).not.toContain(".page-shell .ant-table-wrapper {");
    expect(dataTable).toContain(".page-shell .ant-table-wrapper {");
    expect(dataTable).toContain(".data-table {");
    expect(dataTable).toContain(".data-table__filter-chips {");
    expect(dataTable).toContain(".data-table__column-settings {");
    expect(dataTable).toContain(".data-table__error {");
    expect(dataTable).toContain(".data-table .ant-table-cell {");
    expect(dataTable).toContain(".data-table .data-table__actions {");
    expect(dataTable).toContain(".data-table--compact .ant-table-cell {");
    expect(pageShellResponsive).toContain("@media (max-width: 991.98px)");
    expect(pageShellResponsive).toContain(".page-shell__actions > .ant-space,");
    expect(pageShellResponsive).toContain("@media (max-width: 576px)");
  });

  it("keeps CSS ownership at the global entry points", () => {
    const pageShellSource = readFileSync(resolve(process.cwd(), "src/app/components/PageShell.tsx"), "utf8");
    const dataTableSource = readFileSync(resolve(process.cwd(), "src/shared/data-table/DataTable.tsx"), "utf8");
    expect(pageShellSource).not.toMatch(/\.css['"];/);
    expect(dataTableSource).not.toMatch(/\.css['"];/);
  });

  it("keeps shared styles in named files", () => {
    const tokens = readStylesheet(resolve(process.cwd(), "src/styles/shared/tokens.css"));
    const agentTopbar = readStylesheet(resolve(process.cwd(), "src/styles/shared/agent-topbar.css"));
    const conversationPanel = readStylesheet(
      resolve(process.cwd(), "src/styles/shared/conversation-panel.css"),
    );
    expect(tokens).toContain("--legacy-primary");
    expect(agentTopbar).toContain(".agent-topbar__secondary");
    expect(conversationPanel).toContain(".convo-composer");
  });

  it("keeps the global CSS entry before shared list-workbench styles", () => {
    const mainSource = readFileSync(resolve(process.cwd(), "src/main.tsx"), "utf8");
    expect(mainSource.indexOf("./styles.css")).toBeGreaterThanOrEqual(0);
    expect(mainSource.indexOf("./styles.css")).toBeLessThan(
      mainSource.indexOf("./shared/list-workbench/list-workbench.css"),
    );
  });

  it("keeps XiaoWen CSS route-lazy and outside the global manifest", () => {
    const xiaoWenSource = readFileSync(
      resolve(process.cwd(), "src/app/pages/XiaoWenPage.tsx"),
      "utf8",
    );
    expect(xiaoWenSource).toContain("../../features/xiao-wen/xiao-wen.css");
    expect(stylesManifest).not.toContain("xiao-wen.css");
  });

  it.each(XIAO_SHAI_SELECTORS)("keeps the XiaoShai selector %s", (selector) => {
    expect(styles).toContain(selector);
  });

  it.each(XIAO_PING_SELECTORS)("keeps the XiaoPing selector %s", (selector) => {
    expect(styles).toContain(selector);
  });

  it("keeps XiaoPing single-column layout more specific than the shared workspace layout", () => {
    expect(styles).toMatch(
      /\.xun-workspace\.xun-workspace--xiao-ping\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/,
    );
  });

  it.each(XIAO_HAI_SELECTORS)("keeps the XiaoHai selector %s", (selector) => {
    expect(styles).toContain(selector);
  });

  it("keeps a visible mobile poster stage", () => {
    expect(styles).toMatch(/\.xhai-workspace--right-chat \.xhai-poster-scroll--stage[\s\S]*?min-height:\s*clamp\(/);
  });

  it("scopes poster toolbar metadata styling away from button labels", () => {
    expect(styles).toContain(".xhai-current-poster__meta span");
    expect(styles).not.toMatch(/\.xhai-current-poster__toolbar span\s*\{/);
  });
});
