import { useCallback, useMemo, useState } from "react";

import type {
  DataTableColumn,
  DataTableMode,
  DataTableRemoteQuery,
  DataTableSortInput,
  DataTableSortOrder,
  DataTableSortState,
} from "./types";

export const DEFAULT_DATA_TABLE_PAGE = 1;
export const DEFAULT_DATA_TABLE_PAGE_SIZE = 20;
export const DEFAULT_DATA_TABLE_PAGE_SIZE_OPTIONS = [10, 20, 50] as const;

export interface DataTableControllerOptions<T> {
  columns?: readonly DataTableColumn<T>[];
  mode?: DataTableMode;
  initialPage?: number;
  defaultPage?: number;
  initialPageSize?: number;
  defaultPageSize?: number;
  pageSizeOptions?: readonly number[];
  initialSearch?: string;
  defaultSearch?: string;
  initialSort?: DataTableSortInput;
  defaultSort?: DataTableSortInput;
  initialVisibleColumnKeys?: readonly string[];
  defaultVisibleColumnKeys?: readonly string[];
  allowedSortFields?: readonly string[];
}

export interface DataTableControllerResult {
  mode: DataTableMode;
  search: string;
  searchTerm: string;
  page: number;
  pageSize: number;
  sort: DataTableSortState;
  sortField: string | undefined;
  sortBy: string | undefined;
  sortOrder: DataTableSortOrder | undefined;
  sortDirection: DataTableSortOrder | undefined;
  visibleColumnKeys: string[];
  hiddenColumnKeys: string[];
  pagination: { current: number; pageSize: number; pageSizeOptions: number[] };
  remoteQuery: DataTableRemoteQuery;
  query: DataTableRemoteQuery;
  setSearch: (value: string) => void;
  setQuery: (value: string) => void;
  setPage: (value: number) => void;
  setPageSize: (value: number) => void;
  setSort: (value: DataTableSortInput | string | null, order?: string | null) => void;
  setSortBy: (value: string | undefined) => void;
  setSortOrder: (value: string | null | undefined) => void;
  setSortDirection: (value: string | null | undefined) => void;
  toggleColumn: (key: string) => void;
  setColumnVisible: (key: string, visible: boolean) => void;
  setVisibleColumnKeys: (keys: readonly string[]) => void;
  setHiddenColumnKeys: (keys: readonly string[]) => void;
  resetColumns: () => void;
  resetSearch: () => void;
  resetSort: () => void;
  resetPage: () => void;
  reset: () => void;
}

function normalizePage(value: number | undefined): number {
  return Number.isInteger(value) && value !== undefined && value >= 1 ? value : DEFAULT_DATA_TABLE_PAGE;
}

function normalizePageSize(value: number | undefined, options: readonly number[]): number {
  return value !== undefined && options.includes(value) ? value : DEFAULT_DATA_TABLE_PAGE_SIZE;
}

function normalizeSortOrder(value: string | null | undefined): DataTableSortOrder | undefined {
  if (value === "asc" || value === "ascend") return "ascend";
  if (value === "desc" || value === "descend") return "descend";
  return undefined;
}

function normalizeSort(value: DataTableSortInput | string | null | undefined): DataTableSortState {
  if (typeof value === "string") return { field: value || undefined, order: "ascend" };
  if (value?.field === undefined || value.field === null || value.field === "") {
    return { field: undefined, order: undefined };
  }

  const order = normalizeSortOrder(value.order);
  return order ? { field: String(value.field), order } : { field: undefined, order: undefined };
}

function defaultVisibleKeys<T>(columns: readonly DataTableColumn<T>[]): string[] {
  return columns
    .filter((column) => column.defaultVisible !== false || column.role === "identity" || column.role === "actions")
    .map((column) => column.key);
}

export function useDataTableController<T>({
  columns = [],
  mode = "client",
  initialPage,
  defaultPage,
  initialPageSize,
  defaultPageSize,
  pageSizeOptions = DEFAULT_DATA_TABLE_PAGE_SIZE_OPTIONS,
  initialSearch = "",
  defaultSearch,
  initialSort,
  defaultSort,
  initialVisibleColumnKeys,
  defaultVisibleColumnKeys,
  allowedSortFields,
}: DataTableControllerOptions<T>): DataTableControllerResult {
  const safePageSizeOptions = useMemo(
    () => (pageSizeOptions.length > 0 ? [...pageSizeOptions] : [...DEFAULT_DATA_TABLE_PAGE_SIZE_OPTIONS]),
    [pageSizeOptions],
  );
  const [page, setPageState] = useState(() => normalizePage(initialPage ?? defaultPage));
  const [pageSize, setPageSizeState] = useState(() =>
    normalizePageSize(initialPageSize ?? defaultPageSize, safePageSizeOptions),
  );
  const [search, setSearchState] = useState(initialSearch || defaultSearch || "");
  const [sort, setSortState] = useState<DataTableSortState>(() => normalizeSort(initialSort ?? defaultSort));
  const [visibleColumnKeys, setVisibleColumnKeysState] = useState(() => {
    const defaults = defaultVisibleKeys(columns);
    const provided = initialVisibleColumnKeys ?? defaultVisibleColumnKeys;
    if (!provided) return defaults;
    return sanitizeVisibleKeys(provided, columns, defaults);
  });

  const validSortFields = useMemo(
    () => (allowedSortFields ? new Set(allowedSortFields) : new Set(columns.map((column) => column.key))),
    [allowedSortFields, columns],
  );
  const requiredKeys = useMemo(
    () =>
      new Set(
        columns.filter((column) => column.role === "identity" || column.role === "actions").map((column) => column.key),
      ),
    [columns],
  );
  const defaultKeys = useMemo(() => defaultVisibleKeys(columns), [columns]);

  const setPage = useCallback((value: number) => setPageState(normalizePage(value)), []);
  const setPageSize = useCallback(
    (value: number) => {
      setPageSizeState(normalizePageSize(value, safePageSizeOptions));
      setPageState(DEFAULT_DATA_TABLE_PAGE);
    },
    [safePageSizeOptions],
  );
  const setSearch = useCallback((value: string) => {
    setSearchState(value);
    setPageState(DEFAULT_DATA_TABLE_PAGE);
  }, []);
  const setSort = useCallback(
    (value: DataTableSortInput | string | null, order?: string | null) => {
      const next =
        typeof value === "string" ? normalizeSort({ field: value, order: order ?? "ascend" }) : normalizeSort(value);
      if (next.field && allowedSortFields && !validSortFields.has(next.field)) {
        setSortState({ field: undefined, order: undefined });
      } else {
        setSortState(next);
      }
      setPageState(DEFAULT_DATA_TABLE_PAGE);
    },
    [allowedSortFields, validSortFields],
  );
  const setSortBy = useCallback(
    (value: string | undefined) => {
      if (value && allowedSortFields && !validSortFields.has(value)) {
        setSortState({ field: undefined, order: undefined });
        setPageState(DEFAULT_DATA_TABLE_PAGE);
        return;
      }
      setSortState((current) =>
        value ? { field: value, order: current.order ?? "ascend" } : { field: undefined, order: undefined },
      );
      setPageState(DEFAULT_DATA_TABLE_PAGE);
    },
    [allowedSortFields, validSortFields],
  );
  const setSortOrder = useCallback(
    (value: string | null | undefined) => {
      const order = normalizeSortOrder(value);
      setSortState((current) => {
        if (!current.field || !order || (allowedSortFields && !validSortFields.has(current.field))) {
          return { field: undefined, order: undefined };
        }
        return { field: current.field, order };
      });
      setPageState(DEFAULT_DATA_TABLE_PAGE);
    },
    [allowedSortFields, validSortFields],
  );

  const sanitizeKeys = useCallback(
    (keys: readonly string[]) => sanitizeVisibleKeys(keys, columns, defaultKeys),
    [columns, defaultKeys],
  );
  const setVisibleColumnKeys = useCallback(
    (keys: readonly string[]) => setVisibleColumnKeysState(sanitizeKeys(keys)),
    [sanitizeKeys],
  );
  const setHiddenColumnKeys = useCallback(
    (keys: readonly string[]) =>
      setVisibleColumnKeysState(sanitizeKeys(columns.map((column) => (keys.includes(column.key) ? "" : column.key)))),
    [columns, sanitizeKeys],
  );
  const setColumnVisible = useCallback(
    (key: string, visible: boolean) => {
      setVisibleColumnKeysState((current) => {
        const next = visible ? [...current, key] : current.filter((item) => item !== key);
        return sanitizeKeys(next);
      });
    },
    [sanitizeKeys],
  );
  const toggleColumn = useCallback(
    (key: string) => {
      setVisibleColumnKeysState((current) => {
        const next = current.includes(key) ? current.filter((item) => item !== key) : [...current, key];
        return sanitizeKeys(next);
      });
    },
    [sanitizeKeys],
  );
  const resetColumns = useCallback(() => setVisibleColumnKeysState(defaultKeys), [defaultKeys]);
  const resetSearch = useCallback(() => setSearch(""), [setSearch]);
  const resetSort = useCallback(() => setSort(null), [setSort]);
  const resetPage = useCallback(() => setPageState(DEFAULT_DATA_TABLE_PAGE), []);
  const reset = useCallback(() => {
    setSearchState("");
    setPageState(DEFAULT_DATA_TABLE_PAGE);
    setSortState({ field: undefined, order: undefined });
    setVisibleColumnKeysState(defaultKeys);
  }, [defaultKeys]);

  const hiddenColumnKeys = useMemo(
    () =>
      columns
        .filter((column) => !visibleColumnKeys.includes(column.key) && !requiredKeys.has(column.key))
        .map((column) => column.key),
    [columns, requiredKeys, visibleColumnKeys],
  );
  const remoteQuery = useMemo<DataTableRemoteQuery>(() => {
    const query: DataTableRemoteQuery = { page, page_size: pageSize };
    if (search.trim()) query.q = search.trim();
    if (sort.field && sort.order) {
      query.sort_by = sort.field;
      query.sort_order = sort.order === "ascend" ? "asc" : "desc";
    }
    return query;
  }, [page, pageSize, search, sort]);

  return {
    mode,
    search,
    searchTerm: search,
    page,
    pageSize,
    sort,
    sortField: sort.field,
    sortBy: sort.field,
    sortOrder: sort.order,
    sortDirection: sort.order,
    visibleColumnKeys,
    hiddenColumnKeys,
    pagination: { current: page, pageSize, pageSizeOptions: [...safePageSizeOptions] },
    remoteQuery,
    query: remoteQuery,
    setSearch,
    setQuery: setSearch,
    setPage,
    setPageSize,
    setSort,
    setSortBy,
    setSortOrder,
    setSortDirection: setSortOrder,
    toggleColumn,
    setColumnVisible,
    setVisibleColumnKeys,
    setHiddenColumnKeys,
    resetColumns,
    resetSearch,
    resetSort,
    resetPage,
    reset,
  };
}

function sanitizeVisibleKeys<T>(
  keys: readonly string[],
  columns: readonly DataTableColumn<T>[],
  defaults: readonly string[],
): string[] {
  const columnKeys = new Set(columns.map((column) => column.key));
  const required = columns
    .filter((column) => column.role === "identity" || column.role === "actions" || column.hideable === false)
    .map((column) => column.key);
  const next = [...new Set([...keys.filter((key) => columnKeys.has(key)), ...required])];
  const businessVisible = columns.filter(
    (column) => column.role !== "identity" && column.role !== "actions" && next.includes(column.key),
  );
  if (businessVisible.length > 0) return next;
  const fallback = defaults.find((key) =>
    columns.some((column) => column.key === key && column.role !== "identity" && column.role !== "actions"),
  );
  return fallback ? [...next, fallback] : next;
}
