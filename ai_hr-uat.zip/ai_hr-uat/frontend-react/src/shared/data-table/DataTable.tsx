import {
  Alert,
  Button,
  Checkbox,
  Empty,
  Popover,
  Space,
  Table,
  Tag,
  Typography,
} from "antd";
import type { PaginationProps, TableProps } from "antd";
import type { ComponentProps, ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";

import { ListSearch, ListToolbar } from "../list-workbench";
import { useDataTableController } from "./useDataTableController";
import type { DataTableColumn, DataTableControllerState, DataTableInputColumn, DataTableMode } from "./types";

export type DataTableController = ReturnType<typeof useDataTableController>;

export interface DataTableFilterChip {
  key: string;
  label: ReactNode;
  onRemove?: () => void;
}

export interface DataTableProps<T> extends Omit<TableProps<T>, "columns" | "dataSource" | "pagination" | "title"> {
  tableId: string;
  title?: ReactNode;
  columns: readonly DataTableInputColumn<T>[];
  dataSource?: readonly T[];
  controller?: DataTableController;
  mode?: DataTableMode;
  compact?: boolean;
  showSearch?: boolean;
  showColumnSettings?: boolean;
  showResultCount?: boolean;
  searchableText?: (record: T) => string;
  searchPlaceholder?: string;
  filters?: ReactNode;
  filterChips?: readonly DataTableFilterChip[];
  actions?: ReactNode;
  total?: number;
  pagination?: TableProps<T>["pagination"];
  initialPageSize?: number;
  error?: ReactNode;
  onRetry?: () => void;
  emptyText?: ReactNode;
  filteredEmptyText?: ReactNode;
  onClearFilters?: () => void;
}

export interface DataTableActionProps extends Omit<ComponentProps<typeof Typography.Link>, "href" | "type"> {
  tone?: "primary" | "success" | "warning" | "danger";
}

export function DataTableAction({
  tone = "primary",
  disabled,
  onClick,
  ...props
}: DataTableActionProps) {
  return (
    <Typography.Link
      {...props}
      href="#"
      type={tone === "primary" ? undefined : tone}
      disabled={disabled}
      onClick={(event) => {
        event.preventDefault();
        if (!disabled) onClick?.(event);
      }}
    />
  );
}

const DATA_TABLE_PAGINATION_LOCALE: NonNullable<PaginationProps["locale"]> = {
  items_per_page: "条/页",
  jump_to: "跳至",
  jump_to_confirm: "确定",
  page: "页",
  prev_page: "上一页",
  next_page: "下一页",
  prev_5: "向前 5 页",
  next_5: "向后 5 页",
  prev_3: "向前 3 页",
  next_3: "向后 3 页",
  page_size: "页码",
};

function requiredColumn(column: DataTableColumn<unknown>) {
  return column.role === "identity" || column.role === "actions" || column.hideable === false;
}

function stableColumnKey<T>(column: DataTableInputColumn<T>, index: number): string {
  if (column.key) return column.key;
  if (typeof column.dataIndex === "string" || typeof column.dataIndex === "number") return String(column.dataIndex);
  return `column-${index}`;
}

function prepareColumns<T>(columns: readonly DataTableInputColumn<T>[]): DataTableColumn<T>[] {
  return columns.map((column, index) => ({ ...column, key: stableColumnKey(column, index) }));
}

function normalizeColumns<T>(
  columns: readonly DataTableColumn<T>[],
  controller: DataTableController,
): DataTableColumn<T>[] {
  return columns
    .filter((column) => controller.visibleColumnKeys.includes(column.key) || requiredColumn(column as DataTableColumn<unknown>))
    .map((column) => ({
      ...column,
      fixed: column.role === "identity" ? "left" : column.role === "actions" ? "right" : column.fixed,
      width: column.width ?? (column.role === "identity" ? 180 : column.role === "actions" ? 140 : undefined),
      className: [column.className, column.role === "actions" ? "data-table__actions" : undefined]
        .filter(Boolean)
        .join(" ") || undefined,
      sortOrder: controller.sortField === column.key ? controller.sortOrder : null,
    }));
}

function getDefaultVisibleColumns<T>(columns: readonly DataTableColumn<T>[]) {
  return columns.filter((column) => column.hideable !== false || requiredColumn(column as DataTableColumn<unknown>));
}

function ColumnSettings<T>({
  columns,
  controller,
}: {
  columns: readonly DataTableColumn<T>[];
  controller: DataTableController;
}) {
  return (
    <div className="data-table__column-settings" aria-label="列设置面板">
      <Typography.Text strong>显示列</Typography.Text>
      <Space orientation="vertical" size={6} className="data-table__column-options">
        {columns.map((column) => (
          <Checkbox
            key={column.key}
            checked={controller.visibleColumnKeys.includes(column.key)}
            disabled={requiredColumn(column as DataTableColumn<unknown>)}
            onChange={(event) => controller.setColumnVisible(column.key, event.target.checked)}
          >
            {typeof column.title === "function" ? column.key : column.title ?? column.key}
          </Checkbox>
        ))}
      </Space>
      <Button type="link" size="small" onClick={controller.resetColumns}>
        恢复默认列
      </Button>
    </div>
  );
}

export function DataTable<T>({
  tableId,
  title,
  columns,
  dataSource = [],
  controller: providedController,
  mode = "client",
  compact = false,
  showSearch = !compact,
  showColumnSettings = !compact,
  showResultCount = !compact,
  searchableText,
  searchPlaceholder = "搜索",
  filters,
  filterChips = [],
  actions,
  total,
  pagination: providedPagination,
  initialPageSize,
  error,
  onRetry,
  emptyText = "暂无数据",
  filteredEmptyText = "没有符合条件的数据",
  onClearFilters,
  locale,
  scroll,
  size,
  onChange,
  ...tableProps
}: DataTableProps<T>) {
  const stableColumns = useMemo(() => prepareColumns(columns), [columns]);
  const internalController = useDataTableController({ columns: stableColumns, mode, initialPageSize });
  const controller = providedController ?? internalController;
  const [searchInput, setSearchInput] = useState(controller.search);
  useEffect(() => setSearchInput(controller.search), [controller.search]);
  const normalizedColumns = useMemo(() => normalizeColumns(stableColumns, controller), [stableColumns, controller]);
  const canSearch = showSearch && Boolean(searchableText || mode === "remote");
  const searchableRows = useMemo(() => {
    const normalizedSearch = controller.search.trim().toLocaleLowerCase();
    if (mode !== "client" || !normalizedSearch || !searchableText) return [...dataSource];
    return dataSource.filter((record) => searchableText(record).toLocaleLowerCase().includes(normalizedSearch));
  }, [controller.search, dataSource, mode, searchableText]);
  const hasActiveSearch = Boolean(controller.search.trim());
  const hasHideableColumns = getDefaultVisibleColumns(stableColumns).some(
    (column) => !requiredColumn(column as DataTableColumn<unknown>) && column.hideable !== false,
  );
  const tableLocale = {
    ...locale,
    emptyText: locale?.emptyText ?? (
      <Empty description={hasActiveSearch ? filteredEmptyText : emptyText}>
        {hasActiveSearch && onClearFilters ? (
          <Button type="link" onClick={() => { controller.resetSearch(); onClearFilters?.(); }}>
            清除筛选
          </Button>
        ) : null}
      </Empty>
    ),
  };
  const pagination =
    compact || providedPagination === false
      ? false
      : {
          current: controller.page,
          pageSize: controller.pageSize,
          total: mode === "remote" ? total : searchableRows.length,
          showSizeChanger: true,
          pageSizeOptions: controller.pagination.pageSizeOptions.map(String),
          showTotal: (count: number) => `共 ${count} 条`,
          locale: {
            ...DATA_TABLE_PAGINATION_LOCALE,
            ...(providedPagination && typeof providedPagination !== "boolean" ? providedPagination.locale : {}),
          },
          ...(providedPagination ?? {}),
          onChange: (nextPage: number, nextPageSize: number) => {
            controller.setPage(nextPage);
            if (nextPageSize !== controller.pageSize) controller.setPageSize(nextPageSize);
            if (providedPagination && typeof providedPagination !== "boolean") {
              providedPagination.onChange?.(nextPage, nextPageSize);
            }
          },
        };

  const handleChange: TableProps<T>["onChange"] = (paginationConfig, filtersConfig, sorter, extra) => {
    const activeSorter = Array.isArray(sorter) ? sorter[0] : sorter;
    const field = activeSorter?.columnKey ?? activeSorter?.field;
    if (field !== undefined || activeSorter?.order !== undefined) {
      controller.setSort(field === undefined ? null : String(field), activeSorter?.order ?? null);
    }
    onChange?.(paginationConfig, filtersConfig, sorter, extra);
  };

  const regionLabel = typeof title === "string" ? title : `${tableId} 数据表格`;
  const resultCount = mode === "remote" ? total ?? 0 : searchableRows.length;
  const columnSettings = showColumnSettings && hasHideableColumns ? (
    <Popover
      trigger="click"
      placement="bottomRight"
      content={<ColumnSettings columns={stableColumns} controller={controller} />}
    >
      <Button aria-label="列设置">列设置</Button>
    </Popover>
  ) : null;
  const toolbarActions = actions || columnSettings ? <>{actions}{columnSettings}</> : undefined;
  const toolbarFilters = title || filters ? <>{title ? <Typography.Title level={5}>{title}</Typography.Title> : null}{filters}</> : undefined;
  const hasToolbar = Boolean(toolbarFilters || toolbarActions || canSearch || showResultCount);

  return (
    <section className={`data-table ${compact ? "data-table--compact" : ""}`} aria-label={regionLabel}>
      {filterChips.length > 0 ? (
        <div className="data-table__filter-chips" aria-label="已生效筛选">
          <Space wrap size={[6, 6]}>
            {filterChips.map((chip) => (
              <Tag key={chip.key} closable={Boolean(chip.onRemove)} onClose={chip.onRemove}>
                {chip.label}
              </Tag>
            ))}
            {onClearFilters ? (
              <Button type="link" size="small" onClick={() => { controller.resetSearch(); onClearFilters(); }}>
                清除全部
              </Button>
            ) : null}
          </Space>
        </div>
      ) : null}
      {hasToolbar ? (
        <ListToolbar
          search={canSearch ? (
            <ListSearch
              aria-label="搜索"
              value={searchInput}
              placeholder={searchPlaceholder}
              allowClear
              debounceMs={mode === "remote" ? 300 : 0}
              onChange={(value) => setSearchInput(value)}
              onQueryChange={(value) => controller.setSearch(value)}
            />
          ) : undefined}
          filters={toolbarFilters}
          count={showResultCount ? <Typography.Text type="secondary">共 {resultCount} 条</Typography.Text> : undefined}
          actions={toolbarActions}
        />
      ) : null}
      {error ? (
        <Alert
          className="data-table__error"
          type="error"
          showIcon
          title={error}
          action={onRetry ? <Button aria-label="重试" onClick={onRetry}>重试</Button> : undefined}
        />
      ) : null}
      <Table<T>
        {...tableProps}
        showSorterTooltip={false}
        rowKey={tableProps.rowKey}
        columns={normalizedColumns as TableProps<T>["columns"]}
        dataSource={searchableRows as T[]}
        locale={tableLocale}
        scroll={scroll ?? { x: "max-content" }}
        size={size ?? (compact ? "small" : undefined)}
        pagination={pagination}
        onChange={handleChange}
      />
    </section>
  );
}

export type { DataTableControllerState } from "./types";