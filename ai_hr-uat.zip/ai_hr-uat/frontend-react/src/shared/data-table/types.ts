import type { ColumnType } from "antd/es/table";

export type DataTableMode = "client" | "remote";
export type DataTableColumnRole = "identity" | "actions";
export type DataTableSortOrder = "ascend" | "descend";
export type DataTableRemoteSortOrder = "asc" | "desc";

export interface DataTableColumn<T> extends ColumnType<T> {
  /** Every normalized column has a stable key so visibility can be tracked safely. */
  key: string;
  hideable?: boolean;
  defaultVisible?: boolean;
  role?: DataTableColumnRole;
}

export type DataTableInputColumn<T> = Omit<DataTableColumn<T>, "key"> & { key?: string };

export interface DataTableSortState {
  field: string | undefined;
  order: DataTableSortOrder | undefined;
}

export interface DataTableSortInput {
  field?: string | number;
  order?: DataTableSortOrder | DataTableRemoteSortOrder | string | null;
}

export interface DataTableRemoteQuery {
  q?: string;
  page: number;
  page_size: number;
  sort_by?: string;
  sort_order?: DataTableRemoteSortOrder;
}

export interface DataTableControllerState {
  search: string;
  page: number;
  pageSize: number;
  sort: DataTableSortState;
  visibleColumnKeys: string[];
  hiddenColumnKeys: string[];
}

export interface DataTableLocalState extends DataTableControllerState {
  mode: "client";
}

export interface DataTableRemoteState extends DataTableControllerState {
  mode: "remote";
  remoteQuery: DataTableRemoteQuery;
}
