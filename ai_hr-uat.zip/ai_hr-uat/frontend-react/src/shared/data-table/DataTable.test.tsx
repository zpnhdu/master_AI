import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { DataTable } from './DataTable';
import type { DataTableColumn } from './types';
import { useDataTableController } from './useDataTableController';

type Row = {
  id: string;
  name: string;
  status: string;
  department: string;
};

const columns: DataTableColumn<Row>[] = [
  { key: 'name', title: '姓名', dataIndex: 'name', role: 'identity' },
  { key: 'status', title: '状态', dataIndex: 'status', hideable: true },
  { key: 'department', title: '部门', dataIndex: 'department', hideable: true },
  { key: 'actions', title: '操作', role: 'actions', render: () => <a href="#view">查看</a> },
];

const rows: Row[] = [
  { id: '1', name: '张三', status: '通过', department: '技术' },
  { id: '2', name: '李四', status: '待复核', department: '运营' },
];

afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

function RemoteTableHarness() {
  const controller = useDataTableController({ columns, mode: 'remote' });

  return (
    <>
      <output data-testid="remote-search">{controller.search}</output>
      <DataTable<Row>
        tableId="remote-people"
        columns={columns}
        controller={controller}
        mode="remote"
        total={rows.length}
        dataSource={rows}
        rowKey="id"
      />
    </>
  );
}

describe('DataTable', () => {
  it('renders an Ant Design table with an accessible region and result count', () => {
    render(<DataTable<Row> tableId="people" title="候选人" columns={columns} dataSource={rows} rowKey="id" />);

    expect(screen.getByRole('region', { name: '候选人' })).toBeInTheDocument();
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getAllByText('共 2 条')).not.toHaveLength(0);
    expect(screen.getByRole('columnheader', { name: '操作' })).toHaveClass('ant-table-cell-fix-end');
    expect(screen.getByText(/条\/页/)).toBeInTheDocument();
    expect(screen.getAllByRole('cell', { name: '查看' })[0]).toHaveClass('data-table__actions');
  });

  it('lets users hide a hideable column while keeping identity and action columns visible', async () => {
    render(<DataTable<Row> tableId="people" columns={columns} dataSource={rows} rowKey="id" />);

    fireEvent.click(screen.getByRole('button', { name: '列设置' }));
    const statusCheckbox = screen.getByRole('checkbox', { name: '状态' });
    fireEvent.click(statusCheckbox);

    await waitFor(() => expect(screen.queryByRole('columnheader', { name: '状态' })).not.toBeInTheDocument());
    expect(screen.getByRole('columnheader', { name: '部门' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: '姓名' })).toBeInTheDocument();
    expect(screen.getByRole('columnheader', { name: '操作' })).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: '姓名' })).toBeDisabled();
    expect(screen.getByRole('checkbox', { name: '操作' })).toBeDisabled();

    fireEvent.click(screen.getByRole('button', { name: '恢复默认列' }));
    await waitFor(() => expect(screen.getByRole('columnheader', { name: '状态' })).toBeInTheDocument());
  });

  it('filters client rows with the search box and supports compact mode without a toolbar', () => {
    render(
      <DataTable<Row>
        tableId="people"
        columns={columns}
        dataSource={rows}
        rowKey="id"
        searchableText={(row) => `${row.name} ${row.status}`}
      />,
    );

    fireEvent.change(screen.getByRole('searchbox', { name: '搜索' }), { target: { value: '待复核' } });
    expect(screen.getByText('李四')).toBeInTheDocument();
    expect(screen.queryByText('张三')).not.toBeInTheDocument();

    cleanup();
    render(<DataTable<Row> tableId="compact" compact columns={columns} dataSource={rows} rowKey="id" />);
    expect(screen.queryByRole('searchbox', { name: '搜索' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '列设置' })).not.toBeInTheDocument();
  });

  it('keeps remote search input responsive while debouncing controller queries', () => {
    vi.useFakeTimers();
    render(<RemoteTableHarness />);

    const input = screen.getByRole('searchbox', { name: '搜索' });
    fireEvent.change(input, { target: { value: '待复核' } });

    expect(input).toHaveValue('待复核');
    expect(screen.getByTestId('remote-search')).toHaveTextContent('');

    act(() => {
      vi.advanceTimersByTime(299);
    });
    expect(screen.getByTestId('remote-search')).toHaveTextContent('');

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(screen.getByTestId('remote-search')).toHaveTextContent('待复核');
  });

  it('shows an error with a retry action and a distinct empty state', () => {
    const onRetry = vi.fn();
    render(
      <DataTable<Row>
        tableId="people"
        columns={columns}
        dataSource={[]}
        rowKey="id"
        error="加载失败"
        onRetry={onRetry}
        emptyText="暂无候选人"
      />,
    );

    expect(screen.getByText('加载失败')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '重试' }));
    expect(onRetry).toHaveBeenCalledOnce();
    expect(screen.getByText('暂无候选人')).toBeInTheDocument();
  });
});
