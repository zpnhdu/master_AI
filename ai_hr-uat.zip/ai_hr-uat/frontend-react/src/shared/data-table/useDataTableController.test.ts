import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { useDataTableController } from "./useDataTableController";
import type { DataTableColumn } from "./types";

type Row = {
  id: string;
  name: string;
  email: string;
};

const columns: DataTableColumn<Row>[] = [
  { key: "identity", dataIndex: "id", role: "identity", hideable: false },
  { key: "name", dataIndex: "name", hideable: true, defaultVisible: true },
  { key: "email", dataIndex: "email", hideable: true, defaultVisible: true },
  { key: "actions", role: "actions", hideable: false },
];

afterEach(cleanup);

describe("useDataTableController", () => {
  it("uses page 1 and page size 20 by default", () => {
    const { result } = renderHook(() => useDataTableController({ columns }));

    expect(result.current.page).toBe(1);
    expect(result.current.pageSize).toBe(20);
  });

  it("resets to page 1 when the search term changes", () => {
    const { result } = renderHook(() => useDataTableController({ columns, initialPage: 3 }));

    act(() => result.current.setSearch("alice"));

    expect(result.current.search).toBe("alice");
    expect(result.current.page).toBe(1);
  });

  it("resets page and builds remote query parameters when sorting", () => {
    const { result } = renderHook(() => useDataTableController({ columns, mode: "remote", initialPage: 4 }));

    act(() => result.current.setSort("name", "descend"));

    expect(result.current.page).toBe(1);
    expect(result.current.remoteQuery).toMatchObject({
      page: 1,
      page_size: 20,
      sort_by: "name",
      sort_order: "desc",
    });
  });

  it("keeps column visibility state local to each hook instance", () => {
    const first = renderHook(() => useDataTableController({ columns }));
    const second = renderHook(() => useDataTableController({ columns }));

    act(() => first.result.current.toggleColumn("email"));

    expect(first.result.current.visibleColumnKeys).not.toContain("email");
    expect(second.result.current.visibleColumnKeys).toContain("email");
  });

  it("never hides identity or action columns", () => {
    const { result } = renderHook(() => useDataTableController({ columns }));

    act(() => {
      result.current.toggleColumn("identity");
      result.current.toggleColumn("actions");
    });

    expect(result.current.hiddenColumnKeys).not.toContain("identity");
    expect(result.current.hiddenColumnKeys).not.toContain("actions");
    expect(result.current.visibleColumnKeys).toEqual(expect.arrayContaining(["identity", "actions"]));
  });

  it("falls back for invalid page, page size, and sort direction", () => {
    const { result } = renderHook(() =>
      useDataTableController({
        columns,
        initialPage: 0,
        initialPageSize: 999,
        initialSort: { field: "name", order: "invalid" as "ascend" },
      }),
    );

    expect(result.current.page).toBe(1);
    expect(result.current.pageSize).toBe(20);
    expect(result.current.sort).toEqual({ field: undefined, order: undefined });
  });

  it("ignores sort fields outside the allowed remote query fields", () => {
    const { result } = renderHook(() =>
      useDataTableController({ columns, mode: "remote", allowedSortFields: ["name"] }),
    );

    act(() => result.current.setSortBy("email"));

    expect(result.current.sort).toEqual({ field: undefined, order: undefined });
    expect(result.current.remoteQuery).not.toHaveProperty("sort_by");
  });
});
