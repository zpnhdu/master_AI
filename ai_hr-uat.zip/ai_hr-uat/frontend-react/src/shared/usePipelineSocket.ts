import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

/** 后端广播的流水线实时事件（与 app/routers/websocket.py 对齐）。 */
export type PipelineSocketMessage = {
  type: string;
  pipeline_id?: string;
  stage_id?: string;
  stage_name?: string;
  message?: string;
  [key: string]: unknown;
};

export type PipelineSocketStatus = "connecting" | "open" | "closed";

/** 触发数据联动的阶段事件类型。 */
const DATA_SYNC_EVENTS = new Set([
  "pipeline_loaded",
  "stage_start",
  "stage_done",
  "stage_card",
  "stage_error",
  "pipeline_done",
  "artifact_passed",
]);

const RECONNECT_DELAY_MS = 3000;
const HEARTBEAT_INTERVAL_MS = 30000;

/**
 * 连接流水线专用 WebSocket（/ws/{pipelineId}），行为与旧版 shared.js connectWS 对齐：
 * - 连接成功后发送 load_pipeline 订阅
 * - 断线 3 秒后自动重连
 * - 额外增加 30 秒心跳保活
 */
export function usePipelineSocket(
  pipelineId: string | undefined,
  onMessage?: (message: PipelineSocketMessage) => void,
) {
  const [status, setStatus] = useState<PipelineSocketStatus>("closed");
  const onMessageRef = useRef(onMessage);
  onMessageRef.current = onMessage;

  useEffect(() => {
    if (!pipelineId || typeof WebSocket === "undefined") {
      return;
    }

    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
    let disposed = false;

    function scheduleReconnect() {
      if (disposed || reconnectTimer) return;
      reconnectTimer = setTimeout(connect, RECONNECT_DELAY_MS);
    }

    function connect() {
      reconnectTimer = undefined;
      if (disposed) return;
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      socket = new WebSocket(`${protocol}//${window.location.host}/ws/${pipelineId}`);
      setStatus("connecting");

      socket.onopen = () => {
        if (disposed) return;
        setStatus("open");
        socket?.send(JSON.stringify({ type: "load_pipeline", pipeline_id: pipelineId }));
        heartbeatTimer = setInterval(() => {
          if (socket?.readyState === WebSocket.OPEN) {
            socket.send(JSON.stringify({ type: "ping" }));
          }
        }, HEARTBEAT_INTERVAL_MS);
      };

      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as PipelineSocketMessage;
          onMessageRef.current?.(message);
        } catch (error) {
          console.warn("WS parse error:", error);
        }
      };

      socket.onclose = () => {
        if (heartbeatTimer) {
          clearInterval(heartbeatTimer);
          heartbeatTimer = undefined;
        }
        if (!disposed) {
          setStatus("closed");
          scheduleReconnect();
        }
      };

      socket.onerror = () => {
        // 错误后浏览器会自动触发 onclose，由重连逻辑接管
      };
    }

    connect();

    return () => {
      disposed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      socket?.close();
      setStatus("closed");
    };
  }, [pipelineId]);

  return status;
}

/**
 * 将流水线实时事件与 react-query 缓存联动：
 * 阶段事件到达时自动 invalidate 流水线详情/候选人查询，页面 1 秒内自动刷新。
 * extraKeys 可追加页面自身缓存（如小文 JD 工作区、小面出题），事件到达时一并刷新。
 * 返回连接状态，可用于展示实时同步指示。
 */
export function usePipelineSocketSync(pipelineId: string | undefined, extraKeys?: readonly (readonly unknown[])[]) {
  const queryClient = useQueryClient();
  const extraKeysRef = useRef(extraKeys);
  extraKeysRef.current = extraKeys;

  return usePipelineSocket(pipelineId, (message) => {
    if (!DATA_SYNC_EVENTS.has(message.type)) return;
    const keys: readonly (readonly unknown[])[] = [
      ["pipeline-detail", pipelineId],
      ["pipeline-candidates", pipelineId],
      ...(extraKeysRef.current ?? []),
    ];
    void Promise.all(keys.map((queryKey) => queryClient.invalidateQueries({ queryKey })));
  });
}
