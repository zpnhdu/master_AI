import { Radio } from 'antd';

interface PageTabsProps {
  value: string;
  onChange: (value: string) => void;
  options: { label: string; value: string }[];
}

export function PageTabs({ value, onChange, options }: PageTabsProps) {
  return (
    <Radio.Group
      className="mass-dashboard__tabs"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      optionType="button"
      buttonStyle="solid"
      options={options}
    />
  );
}