import { notification } from "antd";

export function emitError(description?: string) {
  notification.error({
    message: "提示",
    description: description ?? "请求错误",
    placement: "topRight",
    duration: 4.5,
  });
}
