import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { useSingleTabLock } from './useSingleTabLock';

function LockState({ token }: { token: string }) {
  return <div>{useSingleTabLock(token)}</div>;
}

afterEach(() => {
  cleanup();
  localStorage.clear();
  sessionStorage.clear();
  Reflect.deleteProperty(navigator, 'locks');
  vi.useRealTimers();
});

describe('useSingleTabLock Web Locks path', () => {
  it('acquires a browser-managed lock before allowing the session request', async () => {
    const request = vi.fn(async (_name: string, _options: LockOptions, callback: LockGrantedCallback<void>) => {
      await callback({ name: _name, mode: 'exclusive' });
    });
    Object.defineProperty(navigator, 'locks', { configurable: true, value: { request } });

    render(<LockState token="web-lock-token" />);

    expect(await screen.findByText('acquired')).toBeInTheDocument();
    expect(request).toHaveBeenCalledWith(
      'candidate-session-lock:web-lock-token',
      expect.objectContaining({ mode: 'exclusive' }),
      expect.any(Function),
    );
  });

  it('reports locked when another tab keeps the browser-managed lock', async () => {
    vi.useFakeTimers();
    const request = vi.fn((_name: string, options: LockOptions) => new Promise<void>((_resolve, reject) => {
      options.signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
    }));
    Object.defineProperty(navigator, 'locks', { configurable: true, value: { request } });

    render(<LockState token="busy-web-lock-token" />);
    expect(screen.getByText('checking')).toBeInTheDocument();
    await act(async () => {
      vi.advanceTimersByTime(750);
      await Promise.resolve();
    });

    expect(screen.getByText('locked')).toBeInTheDocument();
  });
});

describe('useSingleTabLock fallback', () => {
  it('acquires a stale lock immediately instead of blocking a reopened link', async () => {
    localStorage.setItem(
      'candidate-session-lock:stale-token',
      JSON.stringify({ owner: 'closed-tab', ts: Date.now() - 20_000 }),
    );

    render(<LockState token="stale-token" />);

    expect(await screen.findByText('acquired')).toBeInTheDocument();
  });

  it('allows the same tab owner to refresh without waiting for the heartbeat to expire', async () => {
    sessionStorage.setItem('candidate-tab-owner:refresh-token', 'same-tab');
    localStorage.setItem(
      'candidate-session-lock:refresh-token',
      JSON.stringify({ owner: 'same-tab', ts: Date.now() }),
    );

    render(<LockState token="refresh-token" />);

    expect(await screen.findByText('acquired')).toBeInTheDocument();
  });

  it('rejects a genuinely active lock owned by another tab', async () => {
    localStorage.setItem(
      'candidate-session-lock:active-token',
      JSON.stringify({ owner: 'another-tab', ts: Date.now() }),
    );

    render(<LockState token="active-token" />);

    expect(await screen.findByText('locked')).toBeInTheDocument();
  });
});
