import { act, renderHook } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createElement, type ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { usePipelineSocket, usePipelineSocketSync } from "./usePipelineSocket";

function createSpyWrapper(queryClient: QueryClient) {
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
}

class MockWebSocket {
  static instances: MockWebSocket[] = [];
  static OPEN = 1;

  url: string;
  readyState = 0;
  onopen: (() => void) | null = null;
  onmessage: ((event: { data: string }) => void) | null = null;
  onclose: (() => void) | null = null;
  onerror: (() => void) | null = null;
  sent: string[] = [];
  closed = false;

  constructor(url: string) {
    this.url = url;
    MockWebSocket.instances.push(this);
  }

  send(data: string) {
    this.sent.push(data);
  }

  close() {
    this.closed = true;
  }

  open() {
    this.readyState = MockWebSocket.OPEN;
    this.onopen?.();
  }

  receive(payload: Record<string, unknown>) {
    this.onmessage?.({ data: JSON.stringify(payload) });
  }

  drop() {
    this.onclose?.();
  }
}

beforeEach(() => {
  MockWebSocket.instances = [];
  vi.stubGlobal("WebSocket", MockWebSocket);
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe("usePipelineSocket", () => {
  it("connects to /ws/{pipelineId} and subscribes with load_pipeline on open", () => {
    renderHook(() => usePipelineSocket("p_123"));

    expect(MockWebSocket.instances).toHaveLength(1);
    expect(MockWebSocket.instances[0].url).toContain("/ws/p_123");

    act(() => MockWebSocket.instances[0].open());
    expect(MockWebSocket.instances[0].sent).toContainEqual(
      JSON.stringify({ type: "load_pipeline", pipeline_id: "p_123" }),
    );
  });

  it("parses incoming messages and forwards them to the callback", () => {
    const onMessage = vi.fn();
    renderHook(() => usePipelineSocket("p_123", onMessage));

    act(() => MockWebSocket.instances[0].open());
    act(() => MockWebSocket.instances[0].receive({ type: "stage_done", stage_id: "jd_write" }));

    expect(onMessage).toHaveBeenCalledWith(expect.objectContaining({ type: "stage_done", stage_id: "jd_write" }));
  });

  it("does not connect when pipelineId is missing", () => {
    renderHook(() => usePipelineSocket(undefined));
    expect(MockWebSocket.instances).toHaveLength(0);
  });

  it("reconnects after close once the delay elapses", () => {
    vi.useFakeTimers();
    renderHook(() => usePipelineSocket("p_123"));

    expect(MockWebSocket.instances).toHaveLength(1);
    act(() => MockWebSocket.instances[0].drop());
    expect(MockWebSocket.instances).toHaveLength(1);

    act(() => {
      vi.advanceTimersByTime(3000);
    });
    expect(MockWebSocket.instances).toHaveLength(2);
  });

  it("closes the socket and stops reconnecting after unmount", () => {
    vi.useFakeTimers();
    const { unmount } = renderHook(() => usePipelineSocket("p_123"));

    unmount();
    expect(MockWebSocket.instances[0].closed).toBe(true);

    act(() => {
      vi.advanceTimersByTime(5000);
    });
    expect(MockWebSocket.instances).toHaveLength(1);
  });
});

describe("usePipelineSocketSync", () => {
  it("invalidates pipeline detail queries on data-sync events", () => {
    const queryClient = new QueryClient();
    const invalidateSpy = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);

    renderHook(() => usePipelineSocketSync("p_123"), {
      wrapper: createSpyWrapper(queryClient),
    });

    act(() => MockWebSocket.instances[0].open());
    act(() => MockWebSocket.instances[0].receive({ type: "stage_done", stage_id: "crawl" }));

    expect(invalidateSpy).toHaveBeenCalledWith(expect.objectContaining({ queryKey: ["pipeline-detail", "p_123"] }));
    expect(invalidateSpy).toHaveBeenCalledWith(expect.objectContaining({ queryKey: ["pipeline-candidates", "p_123"] }));
  });

  it("ignores non-sync events such as pong", () => {
    const queryClient = new QueryClient();
    const invalidateSpy = vi.spyOn(queryClient, "invalidateQueries").mockResolvedValue(undefined);

    renderHook(() => usePipelineSocketSync("p_123"), {
      wrapper: createSpyWrapper(queryClient),
    });

    act(() => MockWebSocket.instances[0].open());
    act(() => MockWebSocket.instances[0].receive({ type: "pong" }));

    expect(invalidateSpy).not.toHaveBeenCalled();
  });
});
