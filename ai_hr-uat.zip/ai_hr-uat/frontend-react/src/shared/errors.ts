/** 统一的接口错误文案提取：Error 取 message，否则回退到通用提示。 */
export function getErrorMessage(error: unknown, fallback = "操作失败，请稍后重试"): string {
  return error instanceof Error && error.message ? error.message : fallback;
}
