import type { EChartsOption } from 'echarts';
import { init, type ECharts, use } from 'echarts/core';
import { BarChart, LineChart, PieChart, RadarChart } from 'echarts/charts';
import {
  DataZoomComponent,
  GridComponent,
  LegendComponent,
  TooltipComponent,
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';
import { useEffect, useRef } from 'react';

use([
  BarChart,
  LineChart,
  PieChart,
  RadarChart,
  CanvasRenderer,
  DataZoomComponent,
  GridComponent,
  LegendComponent,
  TooltipComponent,
]);

type EChartProps = {
  option: EChartsOption;
  height?: number | string;
  className?: string;
  onEvents?: Record<string, (params: unknown) => void>;
};

/** 轻量 ECharts 容器：负责初始化、option 更新、尺寸自适应与卸载清理。 */
export function EChart({ option, height = 320, className, onEvents }: EChartProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const chartRef = useRef<ECharts | null>(null);
  const hasInit = useRef(false);

  useEffect(() => {
    hasInit.current = false;
    if (!containerRef.current) return undefined;
    const chart = init(containerRef.current);
    chartRef.current = chart;
    const observer = new ResizeObserver(() => chart.resize());
    observer.observe(containerRef.current);
    return () => {
      observer.disconnect();
      chart.dispose();
      chartRef.current = null;
    };
  }, []);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    if (!hasInit.current) {
      chart.setOption(option, true);
      if (Array.isArray(option.dataZoom) && option.dataZoom.length) {
        chart.setOption({
          dataZoom: option.dataZoom.map((item) => ({ ...item, start: item.start ?? 50, end: item.end ?? 100 })),
        }, false);
      }
      hasInit.current = true;
    } else {
      chart.setOption(option, false);
    }
  }, [option]);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || !onEvents) return undefined;
    for (const [event, handler] of Object.entries(onEvents)) {
      chart.on(event, handler);
    }
    return () => {
      for (const [event, handler] of Object.entries(onEvents)) {
        chart.off(event, handler);
      }
    };
  }, [onEvents]);

  return <div ref={containerRef} className={className} style={{ width: '100%', height }} />;
}
