import { Input } from 'antd';
import type { SearchProps } from 'antd/es/input/Search';
import type { ChangeEvent } from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';

export interface ListSearchProps
  extends Omit<SearchProps, 'value' | 'defaultValue' | 'onChange' | 'onSearch' | 'onPressEnter' | 'className'> {
  /** 受控搜索词；不传时组件自行维护输入值。 */
  value?: string;
  /** 非受控搜索词初始值。 */
  defaultValue?: string;
  /** 输入值变化时立即回调，不等待防抖。 */
  onChange?: (value: string, event: ChangeEvent<HTMLInputElement>) => void;
  /** 搜索条件变化时回调，默认延迟 300ms。 */
  onQueryChange?: (value: string) => void;
  /** 防抖时间，设置为 0 可关闭延迟。 */
  debounceMs?: number;
  className?: string;
  onSearch?: SearchProps['onSearch'];
  onPressEnter?: SearchProps['onPressEnter'];
}

function mergeClassNames(...classNames: Array<string | undefined>) {
  return classNames.filter(Boolean).join(' ');
}

export function ListSearch({
  value,
  defaultValue = '',
  onChange,
  onQueryChange,
  debounceMs = 300,
  className,
  onSearch,
  onPressEnter,
  allowClear = true,
  'aria-label': ariaLabel = '搜索',
  ...inputProps
}: ListSearchProps) {
  const [inputValue, setInputValue] = useState(value ?? defaultValue);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (value !== undefined && value !== inputValue) {
      setInputValue(value);
      clearTimer();
    }
  }, [clearTimer, inputValue, value]);

  const flushQuery = useCallback(
    (nextValue: string) => {
      clearTimer();
      onQueryChange?.(nextValue);
    },
    [clearTimer, onQueryChange],
  );

  const scheduleQuery = useCallback(
    (nextValue: string) => {
      clearTimer();
      if (!onQueryChange) return;
      if (debounceMs <= 0) {
        onQueryChange(nextValue);
        return;
      }
      timerRef.current = setTimeout(() => {
        timerRef.current = null;
        onQueryChange(nextValue);
      }, debounceMs);
    },
    [clearTimer, debounceMs, onQueryChange],
  );

  useEffect(() => clearTimer, [clearTimer]);

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const nextValue = event.target.value;
    setInputValue(nextValue);
    onChange?.(nextValue, event);

    // Ant Design's clear icon emits a click-shaped change event and invokes
    // onSearch separately. Let that path flush once through handleSearch.
    if (nextValue === '') {
      if (event.type !== 'click') flushQuery(nextValue);
      return;
    }
    scheduleQuery(nextValue);
  };

  const handleSearch: SearchProps['onSearch'] = (nextValue, event, info) => {
    flushQuery(nextValue);
    onSearch?.(nextValue, event, info);
  };

  const handlePressEnter: SearchProps['onPressEnter'] = (event) => {
    onPressEnter?.(event);
  };

  return (
    <Input.Search
      {...inputProps}
      value={value ?? inputValue}
      allowClear={allowClear}
      aria-label={ariaLabel}
      className={mergeClassNames('list-workbench-search', className)}
      onChange={handleChange}
      onSearch={handleSearch}
      onPressEnter={handlePressEnter}
    />
  );
}
