import { Select } from 'antd';
import type { BaseOptionType, DefaultOptionType, SelectProps } from 'antd/es/select';

export interface ListFilterSelectProps<
  ValueType = unknown,
  OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType,
> extends SelectProps<ValueType, OptionType> {}

function mergeClassNames(...classNames: Array<string | undefined>) {
  return classNames.filter(Boolean).join(' ');
}

export function ListFilterSelect<
  ValueType = unknown,
  OptionType extends BaseOptionType | DefaultOptionType = DefaultOptionType,
>({ className, size, allowClear, ...selectProps }: ListFilterSelectProps<ValueType, OptionType>) {
  return (
    <Select<ValueType, OptionType>
      {...selectProps}
      className={mergeClassNames('list-workbench-filter-select', className)}
      size={size ?? 'middle'}
      allowClear={allowClear ?? true}
    />
  );
}
