import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import {
  ListFilterSelect,
  ListSearch,
  ListToolbar,
  SelectionActionBar,
} from './index';

afterEach(cleanup);

describe('ListSearch', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('updates the input immediately and debounces query changes', () => {
    const onChange = vi.fn();
    const onQueryChange = vi.fn();

    render(
      <ListSearch
        aria-label="搜索候选人"
        placeholder="搜索候选人"
        onChange={onChange}
        onQueryChange={onQueryChange}
      />,
    );

    const input = screen.getByRole('searchbox', { name: '搜索候选人' });
    fireEvent.change(input, { target: { value: '张' } });

    expect(input).toHaveValue('张');
    expect(onChange).toHaveBeenCalledWith('张', expect.anything());
    expect(onQueryChange).not.toHaveBeenCalled();

    act(() => {
      vi.advanceTimersByTime(299);
    });
    expect(onQueryChange).not.toHaveBeenCalled();

    act(() => {
      vi.advanceTimersByTime(1);
    });
    expect(onQueryChange).toHaveBeenCalledWith('张');
  });

  it('runs the query immediately on enter and clear', () => {
    const onQueryChange = vi.fn();

    render(<ListSearch defaultValue="张" onQueryChange={onQueryChange} />);
    const input = screen.getByRole('searchbox', { name: '搜索' });

    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter', charCode: 13 });
    expect(onQueryChange).toHaveBeenCalledWith('张');

    fireEvent.change(input, { target: { value: '' } });
    expect(onQueryChange).toHaveBeenCalledWith('');
  });

  it('defaults to clearable and cancels a stale query after a controlled reset', () => {
    const onQueryChange = vi.fn();
    const { rerender } = render(<ListSearch value="张" onQueryChange={onQueryChange} />);
    const input = screen.getByRole('searchbox', { name: '搜索' });

    expect(document.querySelector('.ant-input-clear-icon')).toBeInTheDocument();
    fireEvent.change(input, { target: { value: '张三' } });
    rerender(<ListSearch value="" onQueryChange={onQueryChange} />);

    act(() => {
      vi.advanceTimersByTime(300);
    });
    expect(onQueryChange).not.toHaveBeenCalled();
    expect(input).toHaveValue('');
  });
});

describe('ListFilterSelect', () => {
  it('keeps a labelled select clearable by default', () => {
    const onChange = vi.fn();

    render(
      <ListFilterSelect
        aria-label="状态筛选"
        options={[{ label: '启用', value: 'active' }]}
        value="active"
        onChange={onChange}
      />,
    );

    expect(screen.getByRole('combobox', { name: '状态筛选' })).toBeInTheDocument();
    expect(document.querySelector('.ant-select-clear')).toBeInTheDocument();
  });
});

describe('ListToolbar', () => {
  it('renders search, filters, count and actions through slots', () => {
    render(
      <ListToolbar
        search={<input aria-label="搜索" />}
        filters={<button type="button">状态</button>}
        count={<span>共 2 条</span>}
        actions={<button type="button">新增</button>}
      />,
    );

    expect(screen.getByRole('region', { name: '列表工具栏' })).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: '搜索' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '状态' })).toBeInTheDocument();
    expect(screen.getByText('共 2 条')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '新增' })).toBeInTheDocument();
  });
});

describe('SelectionActionBar', () => {
  it('shows selection counts and clears selected rows', () => {
    const onClear = vi.fn();

    render(
      <SelectionActionBar selectedCount={3} currentPageCount={10} onClear={onClear}>
        <button type="button">批量启用</button>
      </SelectionActionBar>,
    );

    expect(screen.getByText('已选 3 条')).toBeInTheDocument();
    expect(screen.getByText('当前页 10 项')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '清空选择' }));
    expect(onClear).toHaveBeenCalledOnce();
    expect(screen.getByRole('button', { name: '批量启用' })).toBeInTheDocument();
  });
});