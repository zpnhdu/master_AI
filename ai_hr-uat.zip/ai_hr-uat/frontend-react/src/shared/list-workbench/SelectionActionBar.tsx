import type { HTMLAttributes, ReactNode } from 'react';

export interface SelectionActionBarProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  selectedCount: number;
  currentPageCount?: number;
  onClear?: () => void;
  children?: ReactNode;
}

function mergeClassNames(...classNames: Array<string | undefined>) {
  return classNames.filter(Boolean).join(' ');
}

export function SelectionActionBar({
  selectedCount,
  currentPageCount,
  onClear,
  children,
  className,
  ...containerProps
}: SelectionActionBarProps) {
  return (
    <div
      {...containerProps}
      role={containerProps.role ?? 'region'}
      className={mergeClassNames('list-workbench-selection-bar', className)}
      aria-label={containerProps['aria-label'] ?? '批量操作'}
    >
      <div className="list-workbench-selection-summary">
        <span>已选 {selectedCount} 条</span>
        {currentPageCount !== undefined ? <span>当前页 {currentPageCount} 项</span> : null}
        {onClear ? (
          <button type="button" className="list-workbench-selection-clear" onClick={onClear}>
            清空选择
          </button>
        ) : null}
      </div>
      {children ? <div className="list-workbench-selection-actions">{children}</div> : null}
    </div>
  );
}
