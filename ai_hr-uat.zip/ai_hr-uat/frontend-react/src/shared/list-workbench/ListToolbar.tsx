import type { HTMLAttributes, ReactNode } from 'react';

export interface ListToolbarProps extends Omit<HTMLAttributes<HTMLDivElement>, 'children'> {
  search?: ReactNode;
  filters?: ReactNode;
  actions?: ReactNode;
  count?: ReactNode;
}

function mergeClassNames(...classNames: Array<string | undefined>) {
  return classNames.filter(Boolean).join(' ');
}

export function ListToolbar({ search, filters, count, actions, className, ...containerProps }: ListToolbarProps) {
  const hasCount = count !== undefined && count !== null;
  const hasActions = actions !== undefined && actions !== null;

  return (
    <div
      {...containerProps}
      role={containerProps.role ?? 'region'}
      className={mergeClassNames('list-workbench-toolbar', className)}
      aria-label={containerProps['aria-label'] ?? '列表工具栏'}
    >
      <div className="list-workbench-toolbar-main">
        {search ? <div className="list-workbench-toolbar-search">{search}</div> : null}
        {filters ? <div className="list-workbench-toolbar-filters">{filters}</div> : null}
      </div>
      {hasCount || hasActions ? (
        <div className="list-workbench-toolbar-actions">
          {hasCount ? <div className="list-workbench-toolbar-count">{count}</div> : null}
          {hasActions ? <div className="list-workbench-toolbar-buttons">{actions}</div> : null}
        </div>
      ) : null}
    </div>
  );
}
