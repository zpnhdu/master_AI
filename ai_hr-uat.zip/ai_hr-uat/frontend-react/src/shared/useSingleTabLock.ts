import { useEffect, useState } from "react";

export type SingleTabLockState = "checking" | "acquired" | "locked";

const LOCK_WAIT_MS = 750;
const FALLBACK_STALE_MS = 15_000;

type StoredLock = {
  owner: string;
  ts: number;
};

function randomOwner() {
  return crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`;
}

function fallbackTabOwner(token: string) {
  const ownerKey = `candidate-tab-owner:${token}`;
  try {
    const existing = sessionStorage.getItem(ownerKey);
    if (existing) return existing;
    const owner = randomOwner();
    sessionStorage.setItem(ownerKey, owner);
    return owner;
  } catch {
    return randomOwner();
  }
}

function parseStoredLock(value: string | null): StoredLock | null {
  if (!value) return null;
  try {
    const parsed = JSON.parse(value) as Partial<StoredLock>;
    if (typeof parsed.owner !== "string" || typeof parsed.ts !== "number") return null;
    return { owner: parsed.owner, ts: parsed.ts };
  } catch {
    return null;
  }
}

export function useSingleTabLock(token: string): SingleTabLockState {
  const [state, setState] = useState<SingleTabLockState>("checking");

  useEffect(() => {
    if (!token) {
      setState("acquired");
      return;
    }

    let disposed = false;
    let releaseWebLock: (() => void) | null = null;
    let fallbackCleanup: (() => void) | null = null;
    const lockName = `candidate-session-lock:${token}`;
    setState("checking");

    const startFallback = () => {
      if (disposed) return;
      const owner = fallbackTabOwner(token);
      const key = lockName;
      let current: StoredLock | null = null;
      try {
        current = parseStoredLock(localStorage.getItem(key));
      } catch {
        setState("acquired");
        return;
      }

      if (current && Date.now() - current.ts <= FALLBACK_STALE_MS && current.owner !== owner) {
        setState("locked");
        return;
      }

      const write = () => {
        localStorage.setItem(key, JSON.stringify({ owner, ts: Date.now() } satisfies StoredLock));
      };
      const removeOwnedLock = () => {
        const stored = parseStoredLock(localStorage.getItem(key));
        if (stored?.owner === owner) localStorage.removeItem(key);
      };
      write();
      setState("acquired");
      const timer = window.setInterval(() => {
        const stored = parseStoredLock(localStorage.getItem(key));
        if (stored?.owner === owner) write();
        else setState("locked");
      }, 5_000);
      window.addEventListener("pagehide", removeOwnedLock);
      fallbackCleanup = () => {
        window.clearInterval(timer);
        window.removeEventListener("pagehide", removeOwnedLock);
        removeOwnedLock();
      };
    };

    if (navigator.locks?.request) {
      const controller = new AbortController();
      const waitTimer = window.setTimeout(() => controller.abort(), LOCK_WAIT_MS);
      void navigator.locks
        .request(lockName, { mode: "exclusive", signal: controller.signal }, async () => {
          window.clearTimeout(waitTimer);
          if (disposed) return;
          setState("acquired");
          await new Promise<void>((resolve) => {
            releaseWebLock = resolve;
          });
        })
        .catch((error: unknown) => {
          window.clearTimeout(waitTimer);
          if (disposed) return;
          if (error instanceof DOMException && error.name === "AbortError") {
            setState("locked");
            return;
          }
          startFallback();
        });

      return () => {
        disposed = true;
        window.clearTimeout(waitTimer);
        controller.abort();
        releaseWebLock?.();
        fallbackCleanup?.();
      };
    }

    startFallback();
    return () => {
      disposed = true;
      fallbackCleanup?.();
    };
  }, [token]);

  return state;
}
