import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

const SHANGHAI_TIMESTAMP = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::(\d{2}))?$/;
const DEFAULT_FOCUS_GRACE_MS = 2_000;
const EXPIRY_WARNING_MS = 30 * 60 * 1_000;

export function parseAssessmentDeadline(value?: string | null): number | null {
  const normalized = value?.trim();
  if (!normalized) return null;
  const localMatch = SHANGHAI_TIMESTAMP.exec(normalized);
  const timestamp = localMatch
    ? Date.parse(`${localMatch[1]}T${localMatch[2]}:${localMatch[3] ?? '00'}+08:00`)
    : Date.parse(normalized);
  return Number.isFinite(timestamp) ? timestamp : null;
}

export function formatAssessmentDeadline(value?: string | null): string {
  const timestamp = parseAssessmentDeadline(value);
  if (timestamp === null) return '';
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(timestamp);
}

function remainingLabel(remainingMs: number) {
  if (remainingMs <= 0) return '已到截止时间';
  const totalSeconds = Math.max(1, Math.ceil(remainingMs / 1_000));
  const hours = Math.floor(totalSeconds / 3_600);
  const minutes = Math.floor((totalSeconds % 3_600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours} 小时 ${minutes} 分钟后过期`;
  if (minutes > 0) return `${minutes} 分 ${String(seconds).padStart(2, '0')} 秒后过期`;
  return `${seconds} 秒后过期`;
}

function useAssessmentDeadline(expiresAt: string | undefined, onExpired: () => void) {
  const deadline = useMemo(() => parseAssessmentDeadline(expiresAt), [expiresAt]);
  const [now, setNow] = useState(() => Date.now());
  const handledDeadlineRef = useRef<number | null>(null);
  const onExpiredRef = useRef(onExpired);
  onExpiredRef.current = onExpired;

  useEffect(() => {
    setNow(Date.now());
    handledDeadlineRef.current = null;
    if (deadline === null) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1_000);
    return () => window.clearInterval(timer);
  }, [deadline]);

  const remainingMs = deadline === null ? null : deadline - now;
  useEffect(() => {
    if (deadline === null || remainingMs === null || remainingMs > 0) return;
    if (handledDeadlineRef.current === deadline) return;
    handledDeadlineRef.current = deadline;
    onExpiredRef.current();
  }, [deadline, remainingMs]);

  return { deadline, remainingMs };
}

type DepartureWarning = {
  count: number;
  durationSeconds: number;
};

function useWindowDepartureWarning(active: boolean, graceMs: number) {
  const leftAtRef = useRef<number | null>(null);
  const warningCountRef = useRef(0);
  const [warning, setWarning] = useState<DepartureWarning | null>(null);

  useEffect(() => {
    if (!active) {
      leftAtRef.current = null;
      setWarning(null);
      return;
    }

    const markLeft = () => {
      leftAtRef.current ??= Date.now();
    };
    const markReturned = () => {
      const leftAt = leftAtRef.current;
      leftAtRef.current = null;
      if (leftAt === null) return;
      const durationMs = Date.now() - leftAt;
      if (durationMs < graceMs) return;
      warningCountRef.current += 1;
      setWarning({
        count: warningCountRef.current,
        durationSeconds: Math.max(1, Math.round(durationMs / 1_000)),
      });
    };
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') markLeft();
      else markReturned();
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('blur', markLeft);
    window.addEventListener('focus', markReturned);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('blur', markLeft);
      window.removeEventListener('focus', markReturned);
    };
  }, [active, graceMs]);

  return {
    warning,
    acknowledge: useCallback(() => setWarning(null), []),
  };
}

type AssessmentSessionGuardProps = {
  active: boolean;
  expiresAt?: string;
  assessmentName: '面试' | '笔试';
  onExpired: () => void;
  focusGraceMs?: number;
};

export function AssessmentSessionGuard({
  active,
  expiresAt,
  assessmentName,
  onExpired,
  focusGraceMs = DEFAULT_FOCUS_GRACE_MS,
}: AssessmentSessionGuardProps) {
  const { remainingMs } = useAssessmentDeadline(expiresAt, onExpired);
  const { warning, acknowledge } = useWindowDepartureWarning(active, focusGraceMs);
  const showDeadlineWarning = remainingMs !== null && remainingMs > 0 && remainingMs <= EXPIRY_WARNING_MS;

  return (
    <>
      {showDeadlineWarning ? (
        <div
          className={`assessment-deadline-notice${remainingMs <= 5 * 60 * 1_000 ? ' assessment-deadline-notice--urgent' : ''}`}
          role="status"
          aria-live="polite"
        >
          <strong>{assessmentName}链接即将过期</strong>
          <span>{remainingLabel(remainingMs)}</span>
        </div>
      ) : null}
      {warning ? (
        <div
          className="assessment-guard-overlay"
          role="dialog"
          aria-modal="true"
          aria-labelledby="assessment-guard-title"
        >
          <div className="assessment-guard-card">
            <div className="assessment-guard-icon" aria-hidden="true">
              !
            </div>
            <h2 id="assessment-guard-title">检测到你离开了{assessmentName}页面</h2>
            <p>请在{assessmentName}过程中保持当前窗口，独立完成作答。</p>
            <div className="assessment-guard-meta">
              本次离开约 {warning.durationSeconds} 秒 · 累计提醒 {warning.count} 次
            </div>
            <button type="button" onClick={acknowledge}>
              我已知晓，继续{assessmentName}
            </button>
          </div>
        </div>
      ) : null}
    </>
  );
}
