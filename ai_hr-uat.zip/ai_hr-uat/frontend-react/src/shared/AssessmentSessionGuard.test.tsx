import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import {
  AssessmentSessionGuard,
  formatAssessmentDeadline,
  parseAssessmentDeadline,
} from './AssessmentSessionGuard';

afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

describe('AssessmentSessionGuard', () => {
  it('parses database timestamps as Asia/Shanghai time', () => {
    expect(parseAssessmentDeadline('2026-09-01 16:30:00')).toBe(Date.parse('2026-09-01T16:30:00+08:00'));
    expect(formatAssessmentDeadline('2026-09-01 16:30:00')).toContain('16:30');
  });

  it('shows a grayscale warning after the candidate leaves an active assessment for two seconds', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-09-01T08:00:00Z'));
    render(
      <AssessmentSessionGuard
        active
        expiresAt="2026-09-02 16:00:00"
        assessmentName="笔试"
        onExpired={vi.fn()}
      />,
    );

    fireEvent.blur(window);
    act(() => vi.advanceTimersByTime(2_100));
    fireEvent.focus(window);

    expect(screen.getByRole('dialog', { name: '检测到你离开了笔试页面' })).toBeInTheDocument();
    expect(screen.getByText(/累计提醒 1 次/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '我已知晓，继续笔试' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('warns before the database deadline and calls back when it expires', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-09-01T08:00:00Z'));
    const onExpired = vi.fn();
    render(
      <AssessmentSessionGuard
        active={false}
        expiresAt="2026-09-01 16:00:02"
        assessmentName="面试"
        onExpired={onExpired}
      />,
    );

    expect(screen.getByText('面试链接即将过期')).toBeInTheDocument();
    expect(screen.getByText('2 秒后过期')).toBeInTheDocument();
    act(() => vi.advanceTimersByTime(2_000));
    expect(onExpired).toHaveBeenCalledTimes(1);
  });
});
