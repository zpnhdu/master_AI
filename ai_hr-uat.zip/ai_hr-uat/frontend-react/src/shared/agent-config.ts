import { routePaths } from '../app/routes/route-paths';

/**
 * 六 Agent 元数据与阶段名称。
 * 与历史 Agent 配置保持一致，
 * 供 pipeline-detail、后续 xiao_* 工作台迁移复用。
 */

export type AgentId = "xiao_wen" | "xiao_hai" | "xiao_xun" | "xiao_shai" | "xiao_mian" | "xiao_ping";

export type AgentConfig = {
  id: AgentId;
  name: string;
  desc: string;
  icon: string;
  color: string;
  gradStart: string;
  gradEnd: string;
  hasChat: boolean;
  stages: string[];
};

export const AGENT_ORDER: AgentId[] = ["xiao_wen", "xiao_hai", "xiao_xun", "xiao_shai", "xiao_mian", "xiao_ping"];

export const AGENT_CONFIG: Record<AgentId, AgentConfig> = {
  xiao_wen: {
    id: "xiao_wen",
    name: "小文",
    desc: "JD撰写与画像",
    icon: "文",
    color: "#2563eb",
    gradStart: "#2563eb",
    gradEnd: "#3b82f6",
    hasChat: true,
    stages: ["jd_write", "profile_build"],
  },
  xiao_hai: {
    id: "xiao_hai",
    name: "小海",
    desc: "招聘海报生成",
    icon: "海",
    color: "#8b5cf6",
    gradStart: "#7c3aed",
    gradEnd: "#8b5cf6",
    hasChat: false,
    stages: ["poster_gen"],
  },
  xiao_xun: {
    id: "xiao_xun",
    name: "小寻",
    desc: "简历获取导入",
    icon: "寻",
    color: "#10b981",
    gradStart: "#059669",
    gradEnd: "#10b981",
    hasChat: false,
    stages: ["crawl"],
  },
  xiao_shai: {
    id: "xiao_shai",
    name: "小筛",
    desc: "简历规则筛查",
    icon: "筛",
    color: "#f59e0b",
    gradStart: "#d97706",
    gradEnd: "#f59e0b",
    hasChat: false,
    stages: ["match"],
  },
  xiao_mian: {
    id: "xiao_mian",
    name: "小面",
    desc: "面试出题安排",
    icon: "面",
    color: "#ef4444",
    gradStart: "#e11d48",
    gradEnd: "#f43f5e",
    hasChat: true,
    stages: ["interview_gen"],
  },
  xiao_ping: {
    id: "xiao_ping",
    name: "小评",
    desc: "录用评估报告",
    icon: "评",
    color: "#06b6d4",
    gradStart: "#0891b2",
    gradEnd: "#06b6d4",
    hasChat: true,
    stages: ["report"],
  },
};

export const STAGE_NAMES: Record<string, string> = {
  jd_write: "JD撰写",
  profile_build: "候选人画像",
  poster_gen: "招聘海报",
  crawl: "简历获取",
  match: "简历筛查",
  interview_gen: "面试出题",
  video_assess: "视频评估",
  report: "录用报告",
};

/**
 * Agent 工作台地址。
 */
export function agentWorkspaceUrl(agentId: string, pipelineId: string): string {
  return routePaths.agentWorkspace(agentId, pipelineId);
}
