import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, useLocation } from 'react-router-dom';
import { Alert, App as AntApp, Button } from 'antd';

import { AuthProvider, useAuth } from './auth/AuthContext';
import { LoadingPage } from './pages/LoadingPage';
import { AppRoutes } from './router';
import { isPublicBootstrapPath } from './routes/route-definitions';
import { getErrorMessage } from '../shared/errors';
import { emitError } from '../shared/global-error';

const defaultQueryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false },
    mutations: {
      onError: (error) => emitError(getErrorMessage(error)),
    },
  },
});

type AppProps = {
  queryClient?: QueryClient;
};

export function App({ queryClient = defaultQueryClient }: AppProps) {
  return (
    <QueryClientProvider client={queryClient}>
      <AntApp>
        <BrowserRouter>
          <AppBootstrap />
        </BrowserRouter>
      </AntApp>
    </QueryClientProvider>
  );
}

function AppBootstrap() {
  const { pathname } = useLocation();
  const isPublicPage = isPublicBootstrapPath(pathname);

  if (isPublicPage) {
    return <AppRoutes />;
  }

  return <AuthProvider><AppContent /></AuthProvider>;
}

function AppContent() {
  const { error, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingPage />;
  }

  if (error) {
    return <AuthLoadError error={error} />;
  }

  return <AppRoutes />;
}

function AuthLoadError({ error }: { error: Error }) {
  return (
    <div className="auth-page auth-page--loading">
      <Alert
        type="error"
        showIcon
        message="登录状态加载失败"
        description={error.message || '无法获取登录状态，请检查后端服务是否正常运行。'}
        action={
          <Button type="primary" onClick={() => window.location.reload()}>
            重新加载
          </Button>
        }
      />
    </div>
  );
}
