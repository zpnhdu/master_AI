import { lazy, Suspense, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';

import { hasPermission, useAuth } from './auth/AuthContext';
import { RouteLoadErrorBoundary } from './components/RouteLoadErrorBoundary';
import { LoadingPage } from './pages/LoadingPage';
import { routeDefinitions, routePermission } from './routes/route-definitions';

const ForbiddenPage = lazy(() => import('./pages/ForbiddenPage').then(({ ForbiddenPage }) => ({ default: ForbiddenPage })));
const LoginPage = lazy(() => import('./pages/LoginPage').then(({ LoginPage }) => ({ default: LoginPage })));
const LegalPage = lazy(() => import('./pages/LegalPage').then(({ LegalPage }) => ({ default: LegalPage })));
const MassDashboardPage = lazy(() => import('./pages/MassDashboardPage').then(({ MassDashboardPage }) => ({ default: MassDashboardPage })));
const MassInterviewPage = lazy(() => import('./pages/MassInterviewPage').then(({ MassInterviewPage }) => ({ default: MassInterviewPage })));
const WrittenTestPage = lazy(() => import('./pages/WrittenTestPage').then(({ WrittenTestPage }) => ({ default: WrittenTestPage })));
const AdminPage = lazy(() => import('./pages/AdminPage').then(({ AdminPage }) => ({ default: AdminPage })));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage').then(({ NotFoundPage }) => ({ default: NotFoundPage })));
const PipelineDetailModule = lazy(() => import('./pages/PipelineDetailPage').then(({ PipelineDetailPage }) => ({ default: PipelineDetailPage })));
const LegacyPipelineDetailModule = lazy(() => import('./pages/PipelineDetailPage').then(({ LegacyPipelineDetailRedirect }) => ({ default: LegacyPipelineDetailRedirect })));
const DashboardPage = lazy(() => import('./pages/DashboardPage').then(({ DashboardPage }) => ({ default: DashboardPage })));
const KnowledgePage = lazy(() => import('./pages/KnowledgePage').then(({ KnowledgePage }) => ({ default: KnowledgePage })));
const MonitorPage = lazy(() => import('./pages/MonitorPage').then(({ MonitorPage }) => ({ default: MonitorPage })));
const ProfilePage = lazy(() => import('./pages/ProfilePage').then(({ ProfilePage }) => ({ default: ProfilePage })));
const RolePage = lazy(() => import('./pages/RolePage').then(({ RolePage }) => ({ default: RolePage })));
const StudioPage = lazy(() => import('./pages/StudioPage').then(({ StudioPage }) => ({ default: StudioPage })));
const TalentPoolPage = lazy(() => import('./pages/TalentPoolPage').then(({ TalentPoolPage }) => ({ default: TalentPoolPage })));
const XiaoWenPage = lazy(() => import('./pages/XiaoWenPage').then(({ XiaoWenPage }) => ({ default: XiaoWenPage })));
const XiaoXunPage = lazy(() => import('./pages/XiaoXunPage').then(({ XiaoXunPage }) => ({ default: XiaoXunPage })));
const XiaoHaiPage = lazy(() => import('./pages/XiaoHaiPage').then(({ XiaoHaiPage }) => ({ default: XiaoHaiPage })));
const XiaoShaiPage = lazy(() => import('./pages/XiaoShaiPage').then(({ XiaoShaiPage }) => ({ default: XiaoShaiPage })));
const XiaoMianPage = lazy(() => import('./pages/XiaoMianPage').then(({ XiaoMianPage }) => ({ default: XiaoMianPage })));
const XiaoPingPage = lazy(() => import('./pages/XiaoPingPage').then(({ XiaoPingPage }) => ({ default: XiaoPingPage })));

type ProtectedRouteProps = {
  children: ReactNode;
  permission?: string;
};

function ProtectedRoute({ children, permission }: ProtectedRouteProps) {
  const location = useLocation();
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  const requiredPermission = routePermission(location.pathname, location.search) ?? permission;
  if (requiredPermission && !hasPermission(user, requiredPermission)) {
    return <ForbiddenPage />;
  }

  return children;
}

export function AppRoutes() {
  return (
    <RouteLoadErrorBoundary>
      <Suspense fallback={<LoadingPage />}>
        <Routes>
      <Route path={routeDefinitions.login.path} element={<LoginPage />} />
      <Route path={routeDefinitions.privacy.path} element={<LegalPage kind="privacy" />} />
      <Route path={routeDefinitions.terms.path} element={<LegalPage kind="terms" />} />
      <Route path={routeDefinitions.forbidden.path} element={<ForbiddenPage />} />
      {/* 候选人自助面试：免登，页面自身处理 token 无效/过期 */}
      <Route path={routeDefinitions.massInterview.path} element={<MassInterviewPage />} />
      {/* 候选人在线笔试：免登，页面自身处理 token 无效/过期/已提交 */}
      <Route path={routeDefinitions.writtenTest.path} element={<WrittenTestPage />} />
      <Route
        path={routeDefinitions.root.path}
        element={
          <ProtectedRoute permission={routeDefinitions.root.permission}>
            <Navigate to={routeDefinitions.studio.path} replace />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.studio.path}
        element={
          <ProtectedRoute permission={routeDefinitions.studio.permission}>
            <StudioPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.pipelineDetail.path}
        element={
          <ProtectedRoute permission={routeDefinitions.pipelineDetail.permission}>
            <PipelineDetailModule />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.admin.path}
        element={
          <ProtectedRoute permission={routeDefinitions.admin.permission}>
            <AdminPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoWen.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoWen.permission}>
            <XiaoWenPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoXun.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoXun.permission}>
            <XiaoXunPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoHai.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoHai.permission}>
            <XiaoHaiPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoShai.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoShai.permission}>
            <XiaoShaiPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoMian.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoMian.permission}>
            <XiaoMianPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.xiaoPing.path}
        element={
          <ProtectedRoute permission={routeDefinitions.xiaoPing.permission}>
            <XiaoPingPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.massDashboard.path}
        element={
          <ProtectedRoute permission={routeDefinitions.massDashboard.permission}>
            <MassDashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.massDashboardDetail.path}
        element={
          <ProtectedRoute permission={routeDefinitions.massDashboardDetail.permission}>
            <MassDashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.talentPool.path}
        element={
          <ProtectedRoute permission={routeDefinitions.talentPool.permission}>
            <TalentPoolPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.profile.path}
        element={
          <ProtectedRoute permission={routeDefinitions.profile.permission}>
            <ProfilePage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.dashboard.path}
        element={
          <ProtectedRoute permission={routeDefinitions.dashboard.permission}>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.monitor.path}
        element={
          <ProtectedRoute permission={routeDefinitions.monitor.permission}>
            <MonitorPage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.knowledge.path}
        element={
          <ProtectedRoute permission={routeDefinitions.knowledge.permission}>
            <KnowledgePage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.role.path}
        element={
          <ProtectedRoute permission={routeDefinitions.role.permission}>
            <RolePage />
          </ProtectedRoute>
        }
      />
      <Route
        path={routeDefinitions.legacyPipelineDetail.path}
        element={
          <ProtectedRoute permission={routeDefinitions.legacyPipelineDetail.permission}>
            <LegacyPipelineDetailModule />
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </RouteLoadErrorBoundary>
  );
}
