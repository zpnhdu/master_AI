import { cleanup, render, screen } from '@testing-library/react';
import { QueryClient } from '@tanstack/react-query';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../features/material-library/MaterialLibrary', () => ({
  MaterialLibrary: () => <h2>素材库</h2>,
}));
vi.mock('./pages/KnowledgePage', async () => {
  const { AppShell } = await vi.importActual<typeof import('./components/AppShell')>('./components/AppShell');
  return {
    KnowledgePage: () => (
      <AppShell>
        <h2>素材库</h2>
      </AppShell>
    ),
  };
});

import { App } from './App';
import { hasPermission } from './auth/AuthContext';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  window.history.pushState({}, '', '/');
});

beforeEach(() => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => ({ username: 'shanghai', permissions: ['pipeline:read'] }),
    }),
  );
});

function renderApp(path: string, queryClient = new QueryClient()) {
  window.history.pushState({}, '', path);
  return render(<App queryClient={queryClient} />);
}

describe('App routes', () => {
  it('shows an auth error instead of loading forever when auth request times out', async () => {
    const timeoutError = new Error('aborted');
    timeoutError.name = 'AbortError';
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(timeoutError));

    renderApp('/studio', new QueryClient({ defaultOptions: { queries: { retry: false } } }));

    expect(await screen.findByRole('alert')).toHaveTextContent('登录状态加载失败');
    expect(screen.getByRole('alert')).toHaveTextContent('认证状态请求超时');
  });

  it('redirects an authenticated root request to Studio', async () => {
    renderApp('/');

    expect(await screen.findByRole('heading', { name: '招聘岗位管理' })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/studio');
  });

  it('renders Studio for an authenticated studio request', async () => {
    renderApp('/studio');

    expect(await screen.findByRole('heading', { name: '招聘岗位管理' })).toBeInTheDocument();
  });

  it('redirects unauthenticated users to login', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({ ok: false, status: 401, json: async () => ({}) }),
    );
    renderApp('/studio');

    expect(await screen.findByRole('heading', { name: '登录智能招聘助手' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '进入工作台' })).toBeInTheDocument();
    expect(document.querySelector('.ant-form')).toBeNull();
    expect(screen.getByRole('link', { name: '《招聘产品隐私保护协议》' })).toHaveAttribute(
      'href',
      '/privacy',
    );
    expect(screen.getByRole('link', { name: '《用户服务协议》' })).toHaveAttribute('href', '/terms');
  });

  it('renders forbidden for users without pipeline permission', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ username: 'limited', permissions: [] }),
      }),
    );
    renderApp('/studio');

    expect(await screen.findByRole('heading', { name: 'Forbidden' })).toBeInTheDocument();
  });

  it('shows only navigation items allowed by the current role permissions', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ username: 'limited', permissions: ['pipeline:read'] }),
      }),
    );
    renderApp('/studio');

    expect(await screen.findByRole('menuitem', { name: '招聘岗位管理' })).toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '面试中心' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '人才库' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '数据看板' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '知识库' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '素材库' })).not.toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '用户与权限' })).not.toBeInTheDocument();
  });

  it('shows the material library directly below knowledge and selects its sidebar entry', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ username: 'knowledge-user', permissions: ['knowledge:read', 'materials:read'] }),
      }),
    );
    const queryClient = new QueryClient();
    queryClient.setQueryData(['auth', 'me'], {
      username: 'knowledge-user',
      permissions: ['knowledge:read', 'materials:read'],
    });
    renderApp('/knowledge?tab=materials', queryClient);

    const knowledgeItem = await screen.findByRole('menuitem', { name: '知识库' });
    const materialItem = screen.getByRole('menuitem', { name: '素材库' });
    const menuItems = screen.getAllByRole('menuitem');

    expect(menuItems).toEqual([knowledgeItem, materialItem]);
    expect(knowledgeItem).not.toHaveClass('ant-menu-item-selected');
    expect(materialItem).toHaveClass('ant-menu-item-selected');
    expect(await screen.findAllByRole('heading', { name: '素材库' })).not.toHaveLength(0);
  });

  it('allows a materials-only user to open the materials subpage directly', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ username: 'materials-user', permissions: ['materials:read'] }),
      }),
    );
    const queryClient = new QueryClient();
    queryClient.setQueryData(['auth', 'me'], {
      username: 'materials-user',
      permissions: ['materials:read'],
    });
    renderApp('/knowledge?tab=materials', queryClient);

    expect(await screen.findByRole('heading', { name: '素材库' })).toBeInTheDocument();
    expect(screen.queryByRole('menuitem', { name: '知识库' })).not.toBeInTheDocument();
  });

  it('forbids a knowledge-only user from opening the materials subpage', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ username: 'knowledge-user', permissions: ['knowledge:read'] }),
      }),
    );
    renderApp('/knowledge?tab=materials');

    expect(await screen.findByRole('heading', { name: 'Forbidden' })).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: '素材库' })).not.toBeInTheDocument();
  });

  it('treats a legacy write permission as no access in the React permission guard', () => {
    expect(hasPermission({ permissions: ['talent:write'] }, 'talent:read')).toBe(false);
  });

  it('renders NotFound for an unknown route', async () => {
    renderApp('/unknown');

    expect(await screen.findByRole('heading', { name: '页面未找到' })).toBeInTheDocument();
  });

  it('renders the privacy agreement without authentication', async () => {
    renderApp('/privacy');

    expect(await screen.findByRole('heading', { name: '招聘产品隐私保护协议' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '返回登录' })).toHaveAttribute('href', '/login');
  });

  it('renders the terms agreement without authentication', async () => {
    renderApp('/terms');

    expect(await screen.findByRole('heading', { name: '用户服务协议' })).toBeInTheDocument();
    expect(
      screen
        .getAllByRole('link', { name: '《招聘产品隐私保护协议》' })
        .every((link) => link.getAttribute('href') === '/privacy'),
    ).toBe(true);
  });

  it('renders the candidate written-test route without requiring login', async () => {
    const fetchMock = vi.fn().mockImplementation(async () => ({
      ok: true,
      status: 200,
      json: async () => ({ error: 'expired', message: '面试链接已过期' }),
    }));
    vi.stubGlobal(
      'fetch',
      fetchMock,
    );

    renderApp('/written-test/expired-token');

    expect(await screen.findByRole('heading', { name: '链接已过期' })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/written-test/expired-token');
    expect(fetchMock).not.toHaveBeenCalledWith('/api/auth/me', expect.anything());
  });
});
