import { createContext, useContext, type ReactNode } from 'react';
import { useQuery, type QueryClient } from '@tanstack/react-query';

import {
  defaultRouteDefinitions,
  routeDefinitions,
  routePermission as getRoutePermission,
  type AppRouteDefinition,
} from '../routes/route-definitions';

export type AuthUser = {
  id?: string;
  username?: string;
  display_name?: string;
  role_id?: string;
  permissions?: string[];
};

type AuthContextValue = {
  user: AuthUser | null;
  isLoading: boolean;
  error: Error | null;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export const AUTH_QUERY_KEY = ['auth', 'me'] as const;
const AUTH_REQUEST_TIMEOUT_MS = 10_000;

function isCurrentUserQuery(queryKey: readonly unknown[]) {
  return queryKey.length === 2 && queryKey[0] === AUTH_QUERY_KEY[0] && queryKey[1] === AUTH_QUERY_KEY[1];
}

/** 保留认证订阅，清除上一个账号留下的业务数据，再写入当前身份。 */
export function replaceAuthenticatedUser(queryClient: QueryClient, user: AuthUser | null) {
  queryClient.removeQueries({ predicate: (query) => !isCurrentUserQuery(query.queryKey) });
  queryClient.getMutationCache().clear();
  queryClient.setQueryData(AUTH_QUERY_KEY, user);
  window.localStorage.removeItem('hr_os_recent_visits');
}

async function fetchCurrentUser(): Promise<AuthUser | null> {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), AUTH_REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch('/api/auth/me', { credentials: 'include', signal: controller.signal });

    if (response.status === 401) {
      return null;
    }

    if (!response.ok) {
      throw new Error(`认证状态请求失败：${response.status}`);
    }

    return response.json() as Promise<AuthUser>;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error('认证状态请求超时，请检查后端服务是否正常运行');
    }
    throw error;
  } finally {
    window.clearTimeout(timeoutId);
  }
}

type AuthProviderProps = {
  children: ReactNode;
  enabled?: boolean;
};

export function AuthProvider({ children, enabled = true }: AuthProviderProps) {
  const { data, error, isPending } = useQuery({
    queryKey: AUTH_QUERY_KEY,
    queryFn: fetchCurrentUser,
    enabled,
    retry: false,
    staleTime: 5 * 60 * 1000,
  });

  return (
    <AuthContext.Provider
      value={{
        user: data ?? null,
        isLoading: enabled && isPending && data === undefined,
        error: error instanceof Error ? error : null,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth 必须在 AuthProvider 内使用');
  }

  return context;
}

export function hasPermission(user: AuthUser | null, permission: string) {
  const permissions = user?.permissions ?? [];
  return permissions.includes('*') || permissions.includes(permission);
}

export function defaultRouteForUser(user: AuthUser | null) {
  const defaultRoute = (defaultRouteDefinitions as readonly AppRouteDefinition[]).find(
    (route) => route.permission && hasPermission(user, route.permission),
  );
  return defaultRoute?.defaultPath ?? defaultRoute?.path ?? routeDefinitions.forbidden.path;
}

export function routePermission(pathname: string, search = "") {
  return getRoutePermission(pathname, search);
}

export function safeRouteForUser(user: AuthUser | null, requestedPath?: string) {
  const requestedUrl = requestedPath ? new URL(requestedPath, window.location.origin) : null;
  const permission = requestedUrl ? routePermission(requestedUrl.pathname, requestedUrl.search) : null;
  if (requestedPath && permission && hasPermission(user, permission)) {
    return requestedPath;
  }
  return defaultRouteForUser(user);
}
