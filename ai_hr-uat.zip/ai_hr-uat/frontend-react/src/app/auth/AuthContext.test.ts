import { createElement } from "react";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import {
  AUTH_QUERY_KEY,
  AuthProvider,
  defaultRouteForUser,
  replaceAuthenticatedUser,
  safeRouteForUser,
  useAuth,
} from "./AuthContext";

afterEach(cleanup);

function SessionHarness() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return createElement(
    "button",
    {
      onClick: () => replaceAuthenticatedUser(queryClient, { id: "hr-user", username: "luwenxuan" }),
    },
    user?.username ?? "anonymous",
  );
}

describe("replaceAuthenticatedUser", () => {
  it("removes cached data from the previous user before storing the new identity", () => {
    const queryClient = new QueryClient();
    queryClient.setQueryData(["pipelines"], [{ id: "admin-pipeline" }]);
    queryClient.setQueryData(["pipeline", "admin-pipeline"], { role: "管理员岗位" });
    window.localStorage.setItem("hr_os_recent_visits", '[{"id":"admin-pipeline"}]');

    const user = { id: "hr-user", username: "hr" };
    replaceAuthenticatedUser(queryClient, user);

    expect(queryClient.getQueryData(["pipelines"])).toBeUndefined();
    expect(queryClient.getQueryData(["pipeline", "admin-pipeline"])).toBeUndefined();
    expect(queryClient.getQueryData(AUTH_QUERY_KEY)).toEqual(user);
    expect(window.localStorage.getItem("hr_os_recent_visits")).toBeNull();
  });

  it("removes all user-scoped data when logging out", () => {
    const queryClient = new QueryClient();
    queryClient.setQueryData(AUTH_QUERY_KEY, { id: "admin", username: "admin" });
    queryClient.setQueryData(["pipelines"], [{ id: "admin-pipeline" }]);

    replaceAuthenticatedUser(queryClient, null);

    expect(queryClient.getQueryData(["pipelines"])).toBeUndefined();
    expect(queryClient.getQueryData(AUTH_QUERY_KEY)).toBeNull();
  });

  it("updates active AuthProvider consumers when the account changes", async () => {
    const queryClient = new QueryClient();
    queryClient.setQueryData(AUTH_QUERY_KEY, { id: "admin", username: "shanghai" });

    render(
      createElement(
        QueryClientProvider,
        { client: queryClient },
        createElement(AuthProvider, null, createElement(SessionHarness)),
      ),
    );

    fireEvent.click(screen.getByRole("button", { name: "shanghai" }));

    expect(await screen.findByRole("button", { name: "luwenxuan" })).toBeInTheDocument();
  });

  it("does not restore an admin-only route for an HR user", () => {
    const user = { username: "luwenxuan", permissions: ["pipeline:read"] };

    expect(safeRouteForUser(user, "/admin")).toBe("/studio");
    expect(safeRouteForUser(user, "/studio")).toBe("/studio");
    expect(defaultRouteForUser(user)).toBe("/studio");
  });

  it("routes a materials-only user to the materials subpage", () => {
    expect(defaultRouteForUser({ permissions: ["materials:read"] })).toBe("/knowledge?tab=materials");
  });
});
