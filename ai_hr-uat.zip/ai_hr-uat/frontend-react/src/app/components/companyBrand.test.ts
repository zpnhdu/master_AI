import { describe, expect, it } from "vitest";

import { resolveCompanyBrand } from "./companyBrand";

describe("resolveCompanyBrand", () => {
  it("uses the configured company name and asset URL", () => {
    expect(
      resolveCompanyBrand({
        company_name: "示例科技",
        company_logo: "https://cdn.example.com/logo.png?signature=abc",
      }),
    ).toEqual({
      name: "示例科技",
      logo: "https://cdn.example.com/logo.png?signature=abc",
    });
  });

  it("prefers the optimized logo URL when one is available", () => {
    expect(
      resolveCompanyBrand({
        company_logo: "https://cdn.example.com/logo.png?signature=original",
        company_logo_thumb: "https://cdn.example.com/thumbs/logo.webp?signature=thumb",
      }),
    ).toEqual({
      name: "锅圈食汇",
      logo: "https://cdn.example.com/thumbs/logo.webp?signature=thumb",
    });
  });

  it("falls back to the built-in defaults while configuration is loading", () => {
    expect(resolveCompanyBrand()).toEqual({
      name: "锅圈食汇",
      logo: "/brand/company-logo-ui.webp",
    });
  });
});
