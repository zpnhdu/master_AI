import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

import { routePaths } from '../routes/route-paths';

type AgentTopbarStatus = {
  label: string;
  /** pending=黄（默认） / ok=绿 / neutral=灰 */
  tone?: 'pending' | 'ok' | 'neutral';
};

type AgentTopbarPrimaryAction = {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
  title?: string;
  /** 已完成态（如"已传递"），绿色软底不可再点 */
  done?: boolean;
};

type AgentTopbarProps = {
  pipelineId: string;
  /** Agent 单字标记（文/海/寻/筛/面/评） */
  mark: string;
  /** 岗位名 */
  title: string;
  /** 副标题，如「小海 · 招聘海报」 */
  subtitle: string;
  status?: AgentTopbarStatus;
  /** 右侧主操作，通常为「传递给下游」 */
  primaryAction?: AgentTopbarPrimaryAction;
  /** 预留次要操作插槽；默认不渲染，避免顶栏堆叠低频操作。 */
  secondaryActions?: ReactNode;
};

/**
 * Agent 工作台共享顶栏，对齐小文（XiaoWenTopbar）布局并固定在页面顶部：
 * ← 返回岗位 / Agent 标记 / 岗位标题 + 状态徽标 + 副标题 / 次要操作 / 传递下游主按钮。
 */
export function AgentTopbar({
  pipelineId,
  mark,
  title,
  subtitle,
  status,
  primaryAction,
  secondaryActions,
}: AgentTopbarProps) {
  return (
    <header className="agent-topbar">
      <Link
        className="agent-topbar__back"
        to={routePaths.pipelineDetail(pipelineId)}
        title="返回岗位"
        aria-label="返回岗位"
      >
        ←
      </Link>
      <div className="agent-topbar__mark" aria-hidden="true">
        {mark}
      </div>
      <div className="agent-topbar__title-group">
        <div className="agent-topbar__title-line">
          <h1>{title}</h1>
          {status ? (
            <span
              className={`agent-topbar__pill${
                status.tone === 'ok' ? ' agent-topbar__pill--ok' : status.tone === 'neutral' ? ' agent-topbar__pill--neutral' : ''
              }`}
            >
              <span className="agent-topbar__pill-dot" />
              <span>{status.label}</span>
            </span>
          ) : null}
        </div>
        <div className="agent-topbar__subtitle">{subtitle}</div>
      </div>
      <div className="agent-topbar__actions">
        {secondaryActions}
        {primaryAction ? (
          <button
            className={`agent-topbar__primary${primaryAction.done ? ' is-done' : ''}`}
            type="button"
            disabled={primaryAction.disabled || primaryAction.loading || primaryAction.done}
            title={primaryAction.title}
            onClick={primaryAction.onClick}
          >
            {primaryAction.loading ? '传递中…' : primaryAction.label}
          </button>
        ) : null}
      </div>
    </header>
  );
}