import { Button, Result, Typography } from 'antd';
import { Component, type ErrorInfo, type ReactNode } from 'react';

function ErrorIcon() {
  return (
    <svg
      width="80"
      height="80"
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <circle cx="40" cy="40" r="38" fill="#eff6ff" stroke="#bfdbfe" strokeWidth="1.5" />
      <path
        d="M22 18h24l12 12v28a2 2 0 0 1-2 2H22a2 2 0 0 1-2-2V20a2 2 0 0 1 2-2z"
        fill="#fff"
        stroke="#93c5fd"
        strokeWidth="1.5"
      />
      <path d="M46 18v10a2 2 0 0 0 2 2h10" fill="#dbeafe" stroke="#93c5fd" strokeWidth="1.5" />
      <line x1="28" y1="38" x2="40" y2="38" stroke="#bfdbfe" strokeWidth="2" strokeLinecap="round" />
      <line x1="28" y1="44" x2="36" y2="44" stroke="#bfdbfe" strokeWidth="2" strokeLinecap="round" />
      <line x1="28" y1="50" x2="32" y2="50" stroke="#bfdbfe" strokeWidth="2" strokeLinecap="round" />
      <path d="M44 42l6 6M50 42l-6 6" stroke="#93c5fd" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

type RouteLoadErrorBoundaryProps = {
  children: ReactNode;
};

type RouteLoadErrorBoundaryState = {
  hasError: boolean;
};

export class RouteLoadErrorBoundary extends Component<
  RouteLoadErrorBoundaryProps,
  RouteLoadErrorBoundaryState
> {
  state: RouteLoadErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): RouteLoadErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('页面资源加载失败:', error, errorInfo);
  }

  render() {
    if (!this.state.hasError) {
      return this.props.children;
    }

    return (
      <div className="auth-page" role="alert">
        <Typography.Title className="visually-hidden" level={1}>
          页面资源加载失败
        </Typography.Title>
        <Result
          icon={<ErrorIcon />}
          title="页面资源加载失败"
          subTitle="请刷新页面后重试。如果问题持续存在，请联系管理员。"
          extra={
            <Button type="primary" onClick={() => window.location.reload()}>
              刷新页面
            </Button>
          }
        />
      </div>
    );
  }
}