import { cleanup, render, screen } from '@testing-library/react';
import type { ReactElement } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { RouteLoadErrorBoundary } from './RouteLoadErrorBoundary';

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

function BrokenRoute(): ReactElement {
  throw new Error('Failed to fetch dynamically imported module');
}

describe('RouteLoadErrorBoundary', () => {
  it('shows a recoverable error page when a lazy route fails to render', () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);

    render(
      <RouteLoadErrorBoundary>
        <BrokenRoute />
      </RouteLoadErrorBoundary>,
    );

    expect(screen.getByRole('alert')).toHaveTextContent('页面资源加载失败');
    expect(screen.getByRole('button', { name: '刷新页面' })).toBeInTheDocument();
  });
});
