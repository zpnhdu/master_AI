import {
  Alert,
  Button,
  Card,
  Checkbox,
  Empty,
  Form,
  Input,
  Modal,
  Space,
  Spin,
  Tag,
  Typography,
  Upload,
  message,
} from 'antd';
import { useQueryClient } from '@tanstack/react-query';
import { useEffect, useState, type ReactNode } from 'react';

import { ApiError } from '../../features/pipelines/api';
import {
  useAgentConfigsQuery,
  useCompanyConfigQuery,
  useOntologyQuery,
  useOntologyRulesQuery,
  useUpdateAgentConfigMutation,
  useUpdateCompanyConfigMutation,
} from '../../features/config/hooks';
import {
  uploadCompanyAsset,
  type CompanyAssetKind,
  type CompanyConfig,
  type OntologyNode,
  type OntologyRule,
} from '../../features/config/api';

type ConfigModalProps = {
  open: boolean;
  onClose: () => void;
};

export function AgentConfigModal({ open, onClose }: ConfigModalProps) {
  const query = useAgentConfigsQuery(open);
  const updateMutation = useUpdateAgentConfigMutation();
  const [drafts, setDrafts] = useState<Record<string, boolean>>({});
  const [saveError, setSaveError] = useState<unknown>(null);

  useEffect(() => {
    if (query.data) {
      setDrafts(Object.fromEntries(query.data.map((config) => [config.agent_id, config.enabled])));
    }
  }, [query.data]);

  async function handleSave() {
    if (!query.data) {
      return;
    }

    setSaveError(null);
    try {
      for (const config of query.data) {
        const enabled = drafts[config.agent_id] ?? config.enabled;
        if (enabled !== config.enabled) {
          await updateMutation.mutateAsync({ agentId: config.agent_id, update: { enabled } });
        }
      }
      onClose();
    } catch (error) {
      setSaveError(error);
    }
  }

  return (
    <Modal
      destroyOnHidden
      open={open}
      title="Agent 配置"
      okText="保存配置"
      cancelText="取消"
      confirmLoading={updateMutation.isPending}
      onCancel={onClose}
      onOk={handleSave}
    >
      {query.error && (
        <Alert
          action={<Button onClick={() => query.refetch()}>重试</Button>}
          description={getConfigErrorDescription(query.error, '请稍后重试。')}
          showIcon
          title="Agent 配置加载失败"
          type="error"
        />
      )}
      {Boolean(saveError) && (
        <Alert
          action={<Button onClick={handleSave}>重试</Button>}
          className="studio-modal__notice"
          description={getConfigErrorDescription(saveError, '请检查网络连接后重试。')}
          showIcon
          title="Agent 配置保存失败"
          type="error"
        />
      )}
      {query.isPending && <div className="app-loading"><Spin /></div>}
      {!query.isPending && !query.error && query.data?.length === 0 && (
        <Empty description="暂无 Agent 配置" />
      )}
      {!query.isPending && !query.error && query.data && query.data.length > 0 && (
        <Space orientation="vertical" size={12} className="studio-config-list">
          {query.data.map((config) => (
            <div className="studio-config-list__item" key={config.agent_id}>
              <div>
                <Typography.Text strong>
                  {config.display_name || config.agent_name || config.agent_id}
                </Typography.Text>
                <Typography.Text type="secondary">
                  {config.model || '未配置模型'} · {config.agent_id}
                </Typography.Text>
              </div>
              <Checkbox
                checked={drafts[config.agent_id] ?? config.enabled}
                onChange={(event) =>
                  setDrafts((current) => ({ ...current, [config.agent_id]: event.target.checked }))
                }
              >
                启用
              </Checkbox>
            </div>
          ))}
        </Space>
      )}
    </Modal>
  );
}

type CompanyConfigFormValues = {
  company_name?: string;
  company_short?: string;
  company_en?: string;
  industry?: string;
  company_size?: string;
  company_website?: string;
  company_address?: string;
  default_benefits_text?: string;
  company_intro?: string;
  company_logo?: string;
};

type CompanyConfigPanelProps = {
  compact?: boolean;
};

export function CompanyConfigPanel({ compact = false }: CompanyConfigPanelProps) {
  const query = useCompanyConfigQuery(true);
  const updateMutation = useUpdateCompanyConfigMutation();
  const [saveError, setSaveError] = useState<unknown>(null);
  const [form] = Form.useForm<CompanyConfigFormValues>();

  useEffect(() => {
    if (query.data) {
      form.setFieldsValue(toCompanyFormValues(query.data));
    }
  }, [form, query.data]);

  async function handleSave(values: CompanyConfigFormValues) {
    setSaveError(null);
    try {
      await updateMutation.mutateAsync(toCompanyConfig(values));
      message.success('公司配置已保存');
    } catch (error) {
      setSaveError(error);
    }
  }

  if (query.isPending) {
    return <div className="app-loading"><Spin /></div>;
  }

  if (query.error) {
    return (
      <Alert
        action={<Button onClick={() => query.refetch()}>重试</Button>}
        description={getConfigErrorDescription(query.error, '请稍后重试。')}
        showIcon
        title="公司配置加载失败"
        type="error"
      />
    );
  }

  return (
    <div className={compact ? 'admin-company-config' : 'studio-company-config-form'}>
      {Boolean(saveError) && (
        <Alert
          action={<Button onClick={() => form.submit()}>重试</Button>}
          className="studio-modal__notice"
          description={getConfigErrorDescription(saveError, '请检查网络连接后重试。')}
          showIcon
          title="公司配置保存失败"
          type="error"
        />
      )}
      <Form form={form} layout="vertical" onFinish={handleSave}>
        <div className="studio-config-form-grid">
          <Form.Item label="公司名称" name="company_name">
            <Input />
          </Form.Item>
          <Form.Item label="公司简称" name="company_short">
            <Input />
          </Form.Item>
          <Form.Item label="英文名称" name="company_en">
            <Input />
          </Form.Item>
          <Form.Item label="行业" name="industry">
            <Input />
          </Form.Item>
          <Form.Item label="公司规模" name="company_size">
            <Input />
          </Form.Item>
          <Form.Item label="公司官网" name="company_website">
            <Input />
          </Form.Item>
          <Form.Item label="公司地址" name="company_address">
            <Input />
          </Form.Item>
        </div>
        <Form.Item label="默认福利（用顿号分隔）" name="default_benefits_text">
          <Input placeholder="五险一金、带薪年假、员工折扣" />
        </Form.Item>
        <div className="studio-company-config-form__asset-row">
          <CompanyAssetField
            form={form}
            field="company_logo"
            kind="logo"
            label="Logo"
            placeholder="上传后自动使用 OSS 地址"
          />
        </div>
        <Form.Item label="公司介绍" name="company_intro">
          <Input.TextArea autoSize={{ minRows: 2, maxRows: 4 }} />
        </Form.Item>
        <Form.Item style={{ marginBottom: 0 }}>
          <Button type="primary" htmlType="submit" loading={updateMutation.isPending}>
            保存配置
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
}

export function CompanyConfigModal({ open, onClose }: ConfigModalProps) {
  const query = useCompanyConfigQuery(open);
  const updateMutation = useUpdateCompanyConfigMutation();
  const [saveError, setSaveError] = useState<unknown>(null);
  const [form] = Form.useForm<CompanyConfigFormValues>();

  useEffect(() => {
    if (query.data && open) {
      form.setFieldsValue(toCompanyFormValues(query.data));
    }
  }, [form, open, query.data]);

  async function handleSave(values: CompanyConfigFormValues) {
    setSaveError(null);
    try {
      await updateMutation.mutateAsync(toCompanyConfig(values));
      onClose();
    } catch (error) {
      setSaveError(error);
    }
  }

  return (
    <Modal
      centered
      className="studio-company-config-modal"
      destroyOnHidden
      open={open}
      title="公司配置"
      width={760}
      okText="保存配置"
      cancelText="取消"
      confirmLoading={updateMutation.isPending}
      onCancel={onClose}
      onOk={() => form.submit()}
    >
      {query.error && (
        <Alert
          action={<Button onClick={() => query.refetch()}>重试</Button>}
          description={getConfigErrorDescription(query.error, '请稍后重试。')}
          showIcon
          title="公司配置加载失败"
          type="error"
        />
      )}
      {Boolean(saveError) && (
        <Alert
          action={<Button onClick={() => form.submit()}>重试</Button>}
          className="studio-modal__notice"
          description={getConfigErrorDescription(saveError, '请检查网络连接后重试。')}
          showIcon
          title="公司配置保存失败"
          type="error"
        />
      )}
      {query.isPending && <div className="app-loading"><Spin /></div>}
      {!query.isPending && !query.error && (
        <Form className="studio-company-config-form" form={form} layout="vertical" onFinish={handleSave}>
          <div className="studio-config-form-grid">
            <Form.Item label="公司名称" name="company_name">
              <Input />
            </Form.Item>
            <Form.Item label="公司简称" name="company_short">
              <Input />
            </Form.Item>
            <Form.Item label="英文名称" name="company_en">
              <Input />
            </Form.Item>
            <Form.Item label="行业" name="industry">
              <Input />
            </Form.Item>
            <Form.Item label="公司规模" name="company_size">
              <Input />
            </Form.Item>
            <Form.Item label="公司官网" name="company_website">
              <Input />
            </Form.Item>
            <Form.Item label="公司地址" name="company_address">
              <Input />
            </Form.Item>
          </div>
          <Form.Item label="默认福利（用顿号分隔）" name="default_benefits_text">
            <Input placeholder="五险一金、带薪年假、员工折扣" />
          </Form.Item>
          <div className="studio-company-config-form__asset-row">
            <CompanyAssetField
              form={form}
              field="company_logo"
              kind="logo"
              label="Logo"
              placeholder="上传后自动使用 OSS 地址"
            />
          </div>
          <Form.Item label="公司介绍" name="company_intro">
            <Input.TextArea autoSize={{ minRows: 2, maxRows: 4 }} />
          </Form.Item>
        </Form>
      )}
    </Modal>
  );
}

/** Logo / HR 二维码字段：文本框 + 上传按钮 + 缩略预览（对齐旧版 uploadCompanyFile）。 */
function CompanyAssetField({
  form,
  field,
  kind,
  label,
  placeholder,
}: {
  form: ReturnType<typeof Form.useForm<CompanyConfigFormValues>>[0];
  field: keyof CompanyConfigFormValues;
  kind: CompanyAssetKind;
  label: string;
  placeholder?: string;
}) {
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const value = Form.useWatch(field, form);

  async function handleUpload(file: File) {
    setUploading(true);
    try {
      const url = await uploadCompanyAsset(kind, file);
      form.setFieldValue(field, url);
      message.success(`上传成功 ${url}`);
      void queryClient.invalidateQueries({ queryKey: ['company-config'] });
    } catch (error) {
      message.error(error instanceof Error ? error.message : '上传失败');
    } finally {
      setUploading(false);
    }
  }

  return (
    <Form.Item label={label}>
      <Space.Compact style={{ width: '100%' }}>
        <Form.Item name={field} noStyle>
          <Input placeholder={placeholder} />
        </Form.Item>
        <Upload
          accept="image/*"
          showUploadList={false}
          beforeUpload={(file) => {
            void handleUpload(file);
            return false;
          }}
        >
          <Button loading={uploading}>上传</Button>
        </Upload>
      </Space.Compact>
      {typeof value === 'string' && value ? (
        <img
          className="studio-asset-preview"
          src={value}
          alt={`${label}预览`}
          loading="lazy"
          decoding="async"
        />
      ) : null}
    </Form.Item>
  );
}

export function OntologyModal({ open, onClose }: ConfigModalProps) {
  const ontologyQuery = useOntologyQuery(open);
  const rulesQuery = useOntologyRulesQuery(open);
  const error = ontologyQuery.error ?? rulesQuery.error;
  const isPending = ontologyQuery.isPending || rulesQuery.isPending;

  function retry() {
    void Promise.all([ontologyQuery.refetch(), rulesQuery.refetch()]);
  }

  return (
    <Modal
      destroyOnHidden
      footer={null}
      open={open}
      title="本体规则"
      width={760}
      onCancel={onClose}
    >
      {error && (
        <Alert
          action={<Button onClick={retry}>重试</Button>}
          className="studio-modal__notice"
          description={getConfigErrorDescription(error, '请稍后重试。')}
          showIcon
          title="本体规则加载失败"
          type="error"
        />
      )}
      {isPending && <div className="app-loading"><Spin /></div>}
      {!isPending && !error && (
        <Space direction="vertical" size={16} className="studio-ontology">
          {ontologyQuery.data?.version && (
            <Typography.Text type="secondary">
              版本：{ontologyQuery.data.version}
            </Typography.Text>
          )}
          <OntologyConflicts conflicts={ontologyQuery.data?.conflicts ?? []} />
          <OntologyRules rules={rulesQuery.data ?? []} />
          {ontologyQuery.data?.tree ? (
            <div className="studio-ontology__tree">
              {renderOntologyNode(ontologyQuery.data.tree, 0)}
            </div>
          ) : (
            <Empty description="暂无本体规则数据" />
          )}
        </Space>
      )}
    </Modal>
  );
}

function OntologyConflicts({
  conflicts,
}: {
  conflicts: Array<Record<string, unknown> | string>;
}) {
  if (conflicts.length === 0) {
    return null;
  }

  return (
    <Alert
      description={
        <Space orientation="vertical" size={6}>
          {conflicts.map((conflict, index) => (
            <div key={`${getDisplayValue(conflict)}-${index}`}>
              {typeof conflict === 'string' ? conflict : getDisplayValue(conflict)}
            </div>
          ))}
        </Space>
      }
      showIcon
      title={`规则冲突（${conflicts.length} 项）`}
      type="warning"
    />
  );
}

function OntologyRules({ rules }: { rules: OntologyRule[] }) {
  if (rules.length === 0) {
    return null;
  }

  return (
    <Card size="small" title={`已配置规则（${rules.length} 项）`}>
      <Space orientation="vertical" size={8} className="studio-ontology__rules">
        {rules.map((rule, index) => (
          <div className="studio-ontology__rule" key={`${rule.id ?? rule.rule_id ?? 'rule'}-${index}`}>
            <Typography.Text strong>{rule.rule_id || rule.id || '未命名规则'}</Typography.Text>
            {rule.field && <Typography.Text type="secondary">字段：{rule.field}</Typography.Text>}
            {(rule.old_value !== undefined || rule.new_value !== undefined) && (
              <Typography.Text>
                {rule.old_value !== undefined && `旧：${getDisplayValue(rule.old_value)} `}
                {rule.new_value !== undefined && `新：${getDisplayValue(rule.new_value)}`}
              </Typography.Text>
            )}
            {rule.updated_at && <Typography.Text type="secondary">{rule.updated_at}</Typography.Text>}
          </div>
        ))}
      </Space>
    </Card>
  );
}

function renderOntologyNode(node: OntologyNode, depth: number): ReactNode {
  const title = node.name || node.id || '未命名节点';
  const ruleEntries = Object.entries(node.rules ?? {});

  return (
    <Card
      className={`studio-ontology__node studio-ontology__node--depth-${Math.min(depth, 2)}`}
      key={`${node.id ?? title}-${depth}`}
      size="small"
    >
      <Space orientation="vertical" size={4}>
        <Space size={8}>
          <Typography.Text strong>{title}</Typography.Text>
          {node.node_type && <Tag>{node.node_type}</Tag>}
        </Space>
        {node.desc && <Typography.Text type="secondary">{node.desc}</Typography.Text>}
        {ruleEntries.length > 0 && (
          <div className="studio-ontology__node-rules">
            {ruleEntries.map(([key, value]) => (
              <div key={key}>
                <Typography.Text strong>{key}：</Typography.Text>
                <Typography.Text>{getDisplayValue(value)}</Typography.Text>
              </div>
            ))}
          </div>
        )}
        {node.children?.map((child, index) => (
          <div className="studio-ontology__child" key={`${child.id ?? child.name ?? 'child'}-${index}`}>
            {renderOntologyNode(child, depth + 1)}
          </div>
        ))}
      </Space>
    </Card>
  );
}

function getDisplayValue(value: unknown) {
  if (typeof value === 'string') {
    return value;
  }
  if (value === undefined || value === null) {
    return '';
  }
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function toCompanyFormValues(config: CompanyConfig): CompanyConfigFormValues {
  return {
    ...config,
    default_benefits_text: config.default_benefits?.join('、'),
  };
}

function toCompanyConfig(values: CompanyConfigFormValues): CompanyConfig {
  const { default_benefits_text, ...config } = values;
  return {
    ...config,
    default_benefits: default_benefits_text
      ?.split(/[、,，]/)
      .map((benefit) => benefit.trim())
      .filter(Boolean),
  };
}

function getConfigErrorDescription(error: unknown, fallback: string) {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return '登录状态已失效，请重新登录。';
    }
    if (error.status === 403) {
      return '当前账号无权限修改配置。';
    }
    if (error.status && error.status >= 500) {
      return '服务暂时不可用，请稍后重试。';
    }
    if (error.kind === 'timeout' || error.kind === 'backend_timeout' || error.kind === 'offline') {
      return error.message;
    }
  }

  return error instanceof Error && error.message ? error.message : fallback;
}