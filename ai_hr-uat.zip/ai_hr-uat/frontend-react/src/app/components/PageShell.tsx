import type { ReactNode } from 'react';
import { Typography } from 'antd';

import { AppShell } from './AppShell';

interface PageShellProps {
  /** 页面标题 */
  title: string;
  /** 页面标题语义层级，默认保持既有页面的 h3。 */
  titleLevel?: 1 | 2 | 3 | 4 | 5;
  /** 页面标题下的辅助说明。 */
  subtitle?: ReactNode;
  /** header 右侧额外内容（按钮组等），传 null 表示不渲染 header */
  headerExtra?: ReactNode | null;
  /** 页面主体内容 */
  children: ReactNode;
  /** 变体：面试中心用 flex 布局 */
  variant?: 'default' | 'flex';
  /** 额外 className */
  className?: string;
}

export function PageShell({
  title,
  titleLevel = 3,
  subtitle,
  headerExtra,
  children,
  variant = 'default',
  className,
}: PageShellProps) {
  const classNames = [
    'page-shell',
    variant === 'flex' ? 'page-shell--flex' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <AppShell>
      <div className={classNames}>
        {headerExtra !== null && (
          <header className="page-shell__header">
            <div>
              <Typography.Title level={titleLevel} style={{ margin: 0 }}>
                {title}
              </Typography.Title>
              {subtitle ? <div className="page-shell__subtitle">{subtitle}</div> : null}
            </div>
            <div className="page-shell__actions">{headerExtra}</div>
          </header>
        )}
        {children}
      </div>
    </AppShell>
  );
}
