import React from 'react';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';

const antdMocks = vi.hoisted(() => ({
  sider: vi.fn(),
}));

vi.mock('antd', async () => {
  const actual = await vi.importActual<typeof import('antd')>('antd');

  function Sider(props: React.ComponentProps<typeof actual.Layout.Sider>) {
    antdMocks.sider(props);
    return React.createElement(actual.Layout.Sider, props);
  }

  return {
    ...actual,
    Layout: {
      ...actual.Layout,
      Sider,
    },
  };
});

vi.mock('../auth/AuthContext', () => ({
  hasPermission: vi.fn(() => true),
  replaceAuthenticatedUser: vi.fn(),
  useAuth: vi.fn(() => ({
    user: { username: 'test-user', permissions: ['*'] },
    isLoading: false,
    error: null,
  })),
}));

vi.mock('../../features/config/hooks', () => ({
  useCompanyConfigQuery: vi.fn(() => ({ data: undefined })),
  useUpdateCompanyConfigMutation: vi.fn(() => ({
    mutate: vi.fn(),
    mutateAsync: vi.fn(),
    isPending: false,
  })),
}));

import { AppShell } from './AppShell';

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  antdMocks.sider.mockClear();
});

describe('AppShell responsive contract', () => {
  it('uses a custom navigation trigger instead of Ant Design default trigger', () => {
    const queryClient = new QueryClient();

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/studio']}>
          <AppShell>
            <div>页面内容</div>
          </AppShell>
        </MemoryRouter>
      </QueryClientProvider>,
    );

    expect(antdMocks.sider).toHaveBeenCalledWith(
      expect.objectContaining({
        breakpoint: 'lg',
        collapsedWidth: 64,
        collapsible: true,
        trigger: null,
      }),
    );

    const collapseButton = screen.getByRole('button', { name: '收起导航' });
    expect(collapseButton).toHaveAttribute('aria-expanded', 'true');
    expect(document.querySelector('.ant-layout-sider-zero-width-trigger')).not.toBeInTheDocument();

    fireEvent.click(collapseButton);

    expect(screen.getByRole('button', { name: '展开导航' })).toHaveAttribute('aria-expanded', 'false');
    expect(antdMocks.sider).toHaveBeenLastCalledWith(
      expect.objectContaining({ collapsed: true, collapsedWidth: 64 }),
    );
    expect(screen.getByRole('menuitem', { name: '招聘岗位管理' })).toHaveAttribute(
      'title',
      '招聘岗位管理',
    );
  });

  it('opens the mobile navigation as an overlay and closes it from the mask', async () => {
    vi.spyOn(window, 'matchMedia').mockImplementation((query) => ({
      matches: query.includes('991.98px'),
      media: query,
      onchange: null,
      addListener: vi.fn(),
      removeListener: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    }));
    const queryClient = new QueryClient();

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/studio']}>
          <AppShell>
            <div>页面内容</div>
          </AppShell>
        </MemoryRouter>
      </QueryClientProvider>,
    );

    const expandButton = await screen.findByRole('button', { name: '展开导航' });
    fireEvent.click(expandButton);

    expect(screen.getByRole('button', { name: '关闭导航' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '收起导航' })).toHaveAttribute('aria-expanded', 'true');

    fireEvent.click(screen.getByRole('button', { name: '关闭导航' }));

    expect(screen.getByRole('button', { name: '展开导航' })).toHaveAttribute('aria-expanded', 'false');
  });
});
