import type { CompanyConfig } from "../../features/config/api";

export const DEFAULT_COMPANY_NAME = "锅圈食汇";
export const DEFAULT_COMPANY_LOGO = "/brand/company-logo-ui.webp";

export function resolveCompanyBrand(config?: CompanyConfig) {
  return {
    name: config?.company_name?.trim() || config?.company_short?.trim() || DEFAULT_COMPANY_NAME,
    logo: config?.company_logo_thumb?.trim() || config?.company_logo?.trim() || DEFAULT_COMPANY_LOGO,
  };
}
