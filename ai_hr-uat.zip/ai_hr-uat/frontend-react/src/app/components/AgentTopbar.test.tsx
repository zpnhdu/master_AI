import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import type { ComponentProps } from 'react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { AgentTopbar } from './AgentTopbar';

function renderTopbar(
  overrides: Partial<ComponentProps<typeof AgentTopbar>> = {},
) {
  return render(
    <MemoryRouter>
      <AgentTopbar
        pipelineId="pipeline-1"
        mark="海"
        title="前端工程师"
        subtitle="小海 · 招聘海报"
        primaryAction={{
          label: '传递给下游',
          onClick: vi.fn(),
        }}
        {...overrides}
      />
    </MemoryRouter>,
  );
}

describe('AgentTopbar', () => {
  afterEach(cleanup);

  it('renders and invokes the configured primary action', () => {
    const onClick = vi.fn();

    renderTopbar({
      primaryAction: { label: '传递给下游', onClick },
    });

    const action = screen.getByRole('button', { name: '传递给下游' });
    expect(action).toBeInTheDocument();

    fireEvent.click(action);

    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it('uses the handoff loading label while the primary action is pending', () => {
    renderTopbar({
      primaryAction: {
        label: '传递给下游',
        onClick: vi.fn(),
        loading: true,
      },
    });

    expect(screen.getByRole('button', { name: '传递中…' })).toBeDisabled();
  });

  it('disables the primary action when it is not ready', () => {
    renderTopbar({
      primaryAction: {
        label: '传递给下游',
        onClick: vi.fn(),
        disabled: true,
      },
    });

    expect(screen.getByRole('button', { name: '传递给下游' })).toBeDisabled();
  });

  it('does not render extra operation controls without secondary actions', () => {
    renderTopbar();

    expect(screen.getAllByRole('button')).toHaveLength(1);
    expect(screen.queryByRole('button', { name: /更多|复制|打开|返回工作室/ })).not.toBeInTheDocument();
  });

  it('renders the completed state as a disabled success action', () => {
    renderTopbar({
      primaryAction: {
        label: '已传递',
        onClick: vi.fn(),
        done: true,
      },
    });

    expect(screen.getByRole('button', { name: '已传递' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '已传递' })).toHaveClass('is-done');
  });
});
