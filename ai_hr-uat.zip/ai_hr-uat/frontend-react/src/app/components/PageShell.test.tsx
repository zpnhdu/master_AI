import { cleanup, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

vi.mock('./AppShell', () => ({
  AppShell: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

import { PageShell } from './PageShell';

afterEach(cleanup);

describe('PageShell responsive contract', () => {
  it('exposes header actions through a dedicated class', () => {
    render(
      <PageShell title="页面标题" headerExtra={<button type="button">新建</button>}>
        <div>页面内容</div>
      </PageShell>,
    );

    const action = screen.getByRole('button', { name: '新建' });

    expect(action.parentElement).toHaveClass('page-shell__actions');
  });

  it('supports a semantic page heading and supporting description', () => {
    render(
      <PageShell
        title="招聘岗位管理"
        titleLevel={1}
        subtitle="管理岗位、跟踪招聘流程进度"
      >
        <div>页面内容</div>
      </PageShell>,
    );

    expect(screen.getByRole('heading', { level: 1, name: '招聘岗位管理' })).toBeInTheDocument();
    expect(screen.getByText('管理岗位、跟踪招聘流程进度')).toHaveClass('page-shell__subtitle');
  });
});
