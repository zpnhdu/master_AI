import { Avatar, Layout, Menu, Popover, Typography } from 'antd';
import { useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { hasPermission, replaceAuthenticatedUser, useAuth } from '../auth/AuthContext';
import { useCompanyConfigQuery } from '../../features/config/hooks';
import { resolveCompanyBrand } from './companyBrand';
import { navigationDefinitions, selectedRouteRules } from '../routes/route-definitions';
import { routePaths } from '../routes/route-paths';
import { CompanyConfigModal } from './StudioConfigModals';

const { Content, Sider } = Layout;

type NavigationItem = {
  id: (typeof navigationDefinitions)[number]['id'];
  key: string;
  label: string;
  glyph: React.ReactNode;
  /** 外链（跳出 SPA 的旧版页面），点击走整页跳转 */
  external?: boolean;
  /** 查看该菜单项所需的权限 ID，不填则所有用户可见 */
  permission?: string;
};

// 公共导航：所有工作台页面共用，文案/图标对齐 studio 侧栏
const NAVIGATION_GLYPHS: Record<(typeof navigationDefinitions)[number]['id'], React.ReactNode> = {
  studio: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg>,
  massDashboard: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>,
  talentPool: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" /></svg>,
  dashboard: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10" /><line x1="12" y1="20" x2="12" y2="4" /><line x1="6" y1="20" x2="6" y2="14" /></svg>,
  knowledge: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3" /><circle cx="19" cy="5" r="2" /><circle cx="5" cy="5" r="2" /><circle cx="19" cy="19" r="2" /><circle cx="5" cy="19" r="2" /><line x1="8.7" y1="9.3" x2="10.3" y2="10.7" /><line x1="13.7" y1="13.3" x2="15.3" y2="14.7" /><line x1="8.7" y1="14.7" x2="10.3" y2="13.3" /><line x1="13.7" y1="10.7" x2="15.3" y2="9.3" /><line x1="12" y1="15" x2="12" y2="17" /><line x1="12" y1="7" x2="12" y2="9" /></svg>,
  materials: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg>,
};

const NAVIGATION_ITEMS: NavigationItem[] = navigationDefinitions.map((definition) => ({
  id: definition.id,
  key: definition.path,
  label: definition.label,
  glyph: NAVIGATION_GLYPHS[definition.id],
  permission: definition.permission,
}));

const ADMIN_NAVIGATION_ITEM = {
  id: 'admin' as const,
  key: routePaths.admin,
  label: '用户与权限',
  glyph: <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /></svg>,
  permission: 'user:manage',
};

type AppShellProps = {
  children: React.ReactNode;
};

export function AppShell({ children }: AppShellProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: companyConfig } = useCompanyConfigQuery(Boolean(user));
  const companyBrand = resolveCompanyBrand(companyConfig);

  const navigationItems = NAVIGATION_ITEMS.filter(
    (item) => !item.permission || hasPermission(user, item.permission),
  );
  const showAdmin = hasPermission(user, ADMIN_NAVIGATION_ITEM.permission ?? '');
  const showCompanyConfig = hasPermission(user, 'system:manage');
  const [isNavCollapsed, setIsNavCollapsed] = useState(false);
  const [isNavBelowBreakpoint, setIsNavBelowBreakpoint] = useState(false);
  const [companyConfigOpen, setCompanyConfigOpen] = useState(false);
  const collapsedWidth = isNavBelowBreakpoint ? 0 : 64;

  // 对齐旧版 shared.js doLogout：POST /api/auth/logout 后回登录页
  async function handleLogout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } finally {
      replaceAuthenticatedUser(queryClient, null);
      navigate(routePaths.login, { replace: true });
    }
  }

  function handleMenuClick(key: string) {
    const item = navigationItems.find((navigationItem) => navigationItem.key === key);
    if (item?.external) {
      window.location.href = item.key;
      return;
    }
    navigate(key);
    if (isNavBelowBreakpoint) {
      setIsNavCollapsed(true);
    }
  }

  const displayName = user?.display_name || user?.username || '用户';
  const pathname = location.pathname;
  const isMaterialLibrary = pathname === routePaths.knowledge && new URLSearchParams(location.search).get('tab') === 'materials';
  const selectedKey =
    isMaterialLibrary
      ? routePaths.knowledgeMaterials
      : pathname === routePaths.root
      ? routePaths.studio
      : selectedRouteRules.find(({ prefix }) => pathname.startsWith(prefix))?.selectedKey ?? pathname;

  const isAdminPage = pathname.startsWith(routePaths.admin);

  const userMenuContent = (
    <div className="hr-user-menu">
      {showAdmin && (
        <div className={`hr-user-menu__item${isAdminPage ? ' hr-user-menu__item--active' : ''}`} onClick={() => { navigate(ADMIN_NAVIGATION_ITEM.key); }}>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            <polyline points="9 12 11 14 15 10" />
          </svg>
          <span>{ADMIN_NAVIGATION_ITEM.label}</span>
        </div>
      )}
      {showAdmin && showCompanyConfig && <div className="hr-user-menu__divider" />}
      {showCompanyConfig && (
        <div className="hr-user-menu__item" onClick={() => setCompanyConfigOpen(true)}>
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
          <span>公司配置</span>
        </div>
      )}
      <div className="hr-user-menu__divider" />
      <div className="hr-user-menu__item hr-user-menu__item--danger" onClick={() => void handleLogout()}>
        ⏻
        <span>退出登录</span>
      </div>
    </div>
  );

  return (
    <Layout
      className={`hr-app-shell hr-app-shell--studio${isNavCollapsed ? ' hr-app-shell--nav-collapsed' : ''}`}
    >
      <Sider
        id="hr-main-navigation"
        aria-label="主导航"
        className="hr-app-shell__sider"
        theme="light"
        width={200}
        collapsible
        breakpoint="lg"
        collapsedWidth={collapsedWidth}
        collapsed={isNavCollapsed}
        onCollapse={setIsNavCollapsed}
        onBreakpoint={setIsNavBelowBreakpoint}
        trigger={null}
      >
        <div className="hr-brand">
          <div className="hr-brand__mark" aria-hidden="true">
            <img src={companyBrand.logo} alt="" decoding="async" />
          </div>
          <div className="hr-brand__copy">
            <Typography.Text className="hr-brand__title">{companyBrand.name}</Typography.Text>
            <Typography.Text className="hr-brand__subtitle">智能招聘平台</Typography.Text>
          </div>
        </div>
        <Typography.Text className="hr-sider__label">导航</Typography.Text>
        <Menu
          className="hr-sider__menu"
          items={navigationItems.map(({ key, label, glyph }) => ({
            key,
            label,
            icon: glyph,
            title: label,
          }))}
          selectedKeys={[selectedKey]}
          onClick={({ key }) => handleMenuClick(key)}
        />
        <Popover
          content={userMenuContent}
          trigger="click"
          placement="topLeft"
          overlayClassName="hr-user-popover"
        >
          <div className="hr-sider__user">
            <Avatar className="hr-app-shell__avatar" size={30}>
              {displayName.charAt(0)}
            </Avatar>
            <Typography.Text className="hr-sider__user-name" ellipsis={{ tooltip: displayName }}>
              {displayName}
            </Typography.Text>
          </div>
        </Popover>
      </Sider>
      {isNavBelowBreakpoint && !isNavCollapsed && (
        <button
          className="hr-app-shell__nav-mask"
          type="button"
          aria-label="关闭导航"
          onClick={() => setIsNavCollapsed(true)}
        />
      )}
      <button
        className={`hr-app-shell__nav-toggle${isNavCollapsed ? ' hr-app-shell__nav-toggle--collapsed' : ''}`}
        type="button"
        aria-controls="hr-main-navigation"
        aria-expanded={!isNavCollapsed}
        aria-label={isNavCollapsed ? '展开导航' : '收起导航'}
        onClick={() => setIsNavCollapsed((collapsed) => !collapsed)}
      >
        <svg viewBox="0 0 20 20" width="18" height="18" fill="none" aria-hidden="true">
          <path
            d={isNavCollapsed ? 'm8 4 6 6-6 6' : 'm12 4-6 6 6 6'}
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path d="M4 4v12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </button>
      <Layout className="hr-app-shell__body">
        <Content className="hr-app-shell__content">{children}</Content>
      </Layout>
      <CompanyConfigModal
        open={companyConfigOpen}
        onClose={() => setCompanyConfigOpen(false)}
      />
    </Layout>
  );
}
