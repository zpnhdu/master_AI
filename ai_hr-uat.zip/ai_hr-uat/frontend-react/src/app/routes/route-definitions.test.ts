import { describe, expect, it } from "vitest";

import { routePaths } from "./route-paths";
import {
  defaultRouteDefinitions,
  isPublicBootstrapPath,
  navigationDefinitions,
  routePermission,
} from "./route-definitions";

describe("集中路由定义", () => {
  it("统一构造动态路由并编码参数", () => {
    expect(routePaths.pipelineDetail("岗位/一")).toBe("/pipelines/%E5%B2%97%E4%BD%8D%2F%E4%B8%80");
    expect(routePaths.massDashboard("pipeline/1")).toBe("/mass-dashboard/pipeline%2F1");
    expect(routePaths.agentWorkspace("xiao_wen", "pipeline/1")).toBe("/xiao-wen?pipeline=pipeline%2F1");
  });

  it("根据集中定义识别公共页面和权限", () => {
    expect(isPublicBootstrapPath("/login")).toBe(true);
    expect(isPublicBootstrapPath("/mass-interview/token-1/")).toBe(true);
    expect(isPublicBootstrapPath("/studio")).toBe(false);
    expect(routePermission("/pipelines/pipeline-1")).toBe("pipeline:read");
    expect(routePermission("/mass-dashboard/pipeline-1")).toBe("interview:read");
    expect(routePermission("/roles/role-1")).toBe("system:manage");
    expect(routePermission("/knowledge")).toBe("knowledge:read");
    expect(routePermission("/knowledge", "?tab=materials")).toBe("materials:read");
    expect(routePermission("/knowledge?tab=materials")).toBe("materials:read");
    expect(routePermission("/not-found")).toBeNull();
  });

  it("保留默认首页的权限优先级和侧栏路由定义", () => {
    expect(defaultRouteDefinitions.map(({ id }) => id)).toEqual([
      "studio",
      "massDashboard",
      "dashboard",
      "talentPool",
      "knowledge",
      "materials",
      "admin",
    ]);
    expect(navigationDefinitions.map(({ id }) => id)).toContain("materials");
  });
});
