const AGENT_ROUTE_PATHS: Record<string, string> = {
  xiao_wen: '/xiao-wen',
  xiao_hai: '/xiao-hai',
  xiao_xun: '/xiao-xun',
  xiao_shai: '/xiao-shai',
  xiao_mian: '/xiao-mian',
  xiao_ping: '/xiao-ping',
};

export const routePaths = {
  root: '/',
  login: '/login',
  privacy: '/privacy',
  terms: '/terms',
  forbidden: '/forbidden',
  studio: '/studio',
  admin: '/admin',
  xiaoWen: '/xiao-wen',
  xiaoXun: '/xiao-xun',
  xiaoHai: '/xiao-hai',
  xiaoShai: '/xiao-shai',
  xiaoMian: '/xiao-mian',
  xiaoPing: '/xiao-ping',
  talentPool: '/talent-pool',
  profile: '/profile',
  dashboard: '/dashboard',
  monitor: '/monitor',
  knowledge: '/knowledge',
  knowledgeMaterials: '/knowledge?tab=materials',
  pipelineDetail: (pipelineId: string) => `/pipelines/${encodeURIComponent(pipelineId)}`,
  massDashboard: (pipelineId?: string) =>
    pipelineId ? `/mass-dashboard/${encodeURIComponent(pipelineId)}` : '/mass-dashboard',
  role: (roleId: string) => `/roles/${encodeURIComponent(roleId)}`,
  massInterview: (token: string) => `/mass-interview/${encodeURIComponent(token)}`,
  writtenTest: (token: string) => `/written-test/${encodeURIComponent(token)}`,
  agentWorkspace: (agentId: string, pipelineId: string) => {
    const pagePath = AGENT_ROUTE_PATHS[agentId] ?? routePaths.studio;
    return `${pagePath}?pipeline=${encodeURIComponent(pipelineId)}`;
  },
};
