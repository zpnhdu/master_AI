import { routePaths } from "./route-paths";

export type RouteBootstrap = "public" | "auth";

export type AppRouteDefinition = {
  id: string;
  path: string;
  bootstrap: RouteBootstrap;
  permission?: string;
  query?: string;
  defaultPath?: string;
};

export const routeDefinitions = {
  login: { id: "login", path: routePaths.login, bootstrap: "public" },
  privacy: { id: "privacy", path: routePaths.privacy, bootstrap: "public" },
  terms: { id: "terms", path: routePaths.terms, bootstrap: "public" },
  forbidden: { id: "forbidden", path: routePaths.forbidden, bootstrap: "auth" },
  massInterview: { id: "massInterview", path: "/mass-interview/:token", bootstrap: "public" },
  writtenTest: { id: "writtenTest", path: "/written-test/:token", bootstrap: "public" },
  root: { id: "root", path: routePaths.root, bootstrap: "auth", permission: "pipeline:read" },
  studio: { id: "studio", path: routePaths.studio, bootstrap: "auth", permission: "pipeline:read" },
  pipelineDetail: {
    id: "pipelineDetail",
    path: "/pipelines/:pipelineId",
    bootstrap: "auth",
    permission: "pipeline:read",
  },
  admin: { id: "admin", path: routePaths.admin, bootstrap: "auth", permission: "user:manage" },
  xiaoWen: { id: "xiaoWen", path: routePaths.xiaoWen, bootstrap: "auth", permission: "pipeline:read" },
  xiaoXun: { id: "xiaoXun", path: routePaths.xiaoXun, bootstrap: "auth", permission: "pipeline:read" },
  xiaoHai: { id: "xiaoHai", path: routePaths.xiaoHai, bootstrap: "auth", permission: "pipeline:read" },
  xiaoShai: { id: "xiaoShai", path: routePaths.xiaoShai, bootstrap: "auth", permission: "pipeline:read" },
  xiaoMian: { id: "xiaoMian", path: routePaths.xiaoMian, bootstrap: "auth", permission: "pipeline:read" },
  xiaoPing: { id: "xiaoPing", path: routePaths.xiaoPing, bootstrap: "auth", permission: "pipeline:read" },
  massDashboard: {
    id: "massDashboard",
    path: routePaths.massDashboard(),
    bootstrap: "auth",
    permission: "interview:read",
  },
  massDashboardDetail: {
    id: "massDashboardDetail",
    path: "/mass-dashboard/:pipelineId",
    bootstrap: "auth",
    permission: "interview:read",
  },
  talentPool: { id: "talentPool", path: routePaths.talentPool, bootstrap: "auth", permission: "talent:read" },
  profile: { id: "profile", path: routePaths.profile, bootstrap: "auth", permission: "talent:read" },
  dashboard: { id: "dashboard", path: routePaths.dashboard, bootstrap: "auth", permission: "analytics:read" },
  monitor: { id: "monitor", path: routePaths.monitor, bootstrap: "auth", permission: "analytics:read" },
  materials: {
    id: "materials",
    path: routePaths.knowledge,
    query: "tab=materials",
    defaultPath: routePaths.knowledgeMaterials,
    bootstrap: "auth",
    permission: "materials:read",
  },
  knowledge: { id: "knowledge", path: routePaths.knowledge, bootstrap: "auth", permission: "knowledge:read" },
  role: { id: "role", path: "/roles/:roleId", bootstrap: "auth", permission: "system:manage" },
  legacyPipelineDetail: {
    id: "legacyPipelineDetail",
    path: "/pipeline-detail",
    bootstrap: "auth",
    permission: "pipeline:read",
  },
} as const satisfies Record<string, AppRouteDefinition>;

export const navigationDefinitions = [
  { id: "studio", path: routePaths.studio, label: "招聘岗位管理", permission: routeDefinitions.studio.permission },
  {
    id: "massDashboard",
    path: routePaths.massDashboard(),
    label: "面试中心",
    permission: routeDefinitions.massDashboard.permission,
  },
  {
    id: "talentPool",
    path: routePaths.talentPool,
    label: "人才库",
    permission: routeDefinitions.talentPool.permission,
  },
  { id: "dashboard", path: routePaths.dashboard, label: "数据看板", permission: routeDefinitions.dashboard.permission },
  { id: "knowledge", path: routePaths.knowledge, label: "知识库", permission: routeDefinitions.knowledge.permission },
  {
    id: "materials",
    path: routePaths.knowledgeMaterials,
    label: "素材库",
    permission: routeDefinitions.materials.permission,
  },
] as const;

export const selectedRouteRules = [
  { prefix: routePaths.massDashboard(), selectedKey: routePaths.massDashboard() },
  { prefix: "/pipelines", selectedKey: routePaths.studio },
  { prefix: "/roles", selectedKey: routePaths.studio },
  { prefix: routePaths.profile, selectedKey: routePaths.talentPool },
  { prefix: routePaths.monitor, selectedKey: routePaths.dashboard },
  { prefix: routePaths.admin, selectedKey: routePaths.admin },
] as const;

export const defaultRouteDefinitions = [
  routeDefinitions.studio,
  routeDefinitions.massDashboard,
  routeDefinitions.dashboard,
  routeDefinitions.talentPool,
  routeDefinitions.knowledge,
  routeDefinitions.materials,
  routeDefinitions.admin,
] as const;

function normalizePath(pathname: string) {
  if (pathname.length <= 1) return pathname;
  return pathname.replace(/\/+$/, "");
}

function matchesRoutePath(pattern: string, pathname: string) {
  const patternSegments = normalizePath(pattern).split("/").filter(Boolean);
  const pathSegments = normalizePath(pathname).split("/").filter(Boolean);

  if (patternSegments.length !== pathSegments.length) return pattern === "/" && pathname === "/";

  return patternSegments.every((segment, index) => segment.startsWith(":") || segment === pathSegments[index]);
}

export function isPublicBootstrapPath(pathname: string) {
  return Object.values(routeDefinitions).some(
    (route) => route.bootstrap === "public" && matchesRoutePath(route.path, pathname),
  );
}

export function routePermission(pathname: string, search = "") {
  const parsedPath = pathname.includes("?") ? new URL(pathname, "http://localhost") : null;
  const resolvedPathname = parsedPath?.pathname ?? pathname;
  const resolvedSearch = parsedPath?.search ?? search;
  const query = new URLSearchParams(resolvedSearch);
  const route = (Object.values(routeDefinitions) as AppRouteDefinition[]).find(
    (candidate) =>
      candidate.permission &&
      matchesRoutePath(candidate.path, resolvedPathname) &&
      (candidate.query ? candidate.query === query.toString().replace(/^\?/, "") : !query.toString()),
  );
  return route?.permission ?? null;
}
