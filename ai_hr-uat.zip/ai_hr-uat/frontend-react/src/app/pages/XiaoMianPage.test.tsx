import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';

import { AuthProvider } from '../auth/AuthContext';

import { XiaoMianPage } from './XiaoMianPage';

const navigateMock = vi.hoisted(() => vi.fn());

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom');
  return { ...actual, useNavigate: () => navigateMock };
});

afterEach(() => {
  cleanup();
  navigateMock.mockReset();
  vi.unstubAllGlobals();
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function renderPage(initialEntry = '/xiao-mian?pipeline=p1') {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntdApp>
          <AuthProvider>
            <XiaoMianPage />
          </AuthProvider>
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

function stubWorkspaceFetch(locked = false, writtenSessions: unknown[] = []) {
  const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
    const path = String(input);
    if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
    if (path === '/api/pipelines/p1') {
      return response({
        id: 'p1',
        role: '店长',
        agents: ['xiao_mian'],
        candidates: [
          { id: 'c1', name: '张三', overall_score: 90 },
          { id: 'c2', name: '李四', overall_score: 85 },
        ],
        stages: [
          {
            stage_id: 'match',
            status: 'done',
            output: { workflow_status: 'confirmed', shortlisted: ['c1', 'c2'] },
          },
        ],
      });
    }
    if (path.startsWith('/api/interview/p1/review')) {
      return response({
        pipeline_id: 'p1',
        review_status: 'pending',
        generated_count: 1,
        interviews: [
          {
            candidate_id: 'c1',
            candidate_name: '张三',
            review_status: 'pending',
            ...(locked
              ? { question_edit_locked: true, question_edit_lock_status: 'completed', interview_status: 'completed' }
              : {}),
            questions: [{ id: 'q1', question: '张三的题目' }],
          },
          {
            candidate_id: 'c2',
            candidate_name: '李四',
            review_status: 'pending',
            questions: [{ id: 'q2', question: '李四的题目' }],
          },
        ],
      });
    }
    if (path === '/api/written-test/p1/status') {
      return response({
        sessions: writtenSessions,
        total: writtenSessions.length,
        submitted: 0,
        pending: writtenSessions.length,
      });
    }
    if (path === '/api/conversations/sessions/ensure') return response({ session: { id: 'session-1' } });
    if (path === '/api/conversations/sessions/session-1/state?limit=100') {
      return response({ messages: [], recent_commands: [] });
    }
    if (path === '/api/mass-interview/pipeline-for/p1') {
      return response({ source_pipeline_id: 'p1', pipeline_id: 'p2' });
    }
    return response({});
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

describe('XiaoMianPage three-column workspace', () => {
  it('opens the interview center for the current pipeline', async () => {
    stubWorkspaceFetch();

    renderPage('/xiao-mian?pipeline=p1');

    const button = await screen.findByRole('button', { name: '进入面试中心' });
    fireEvent.click(button);

    await waitFor(() => {
      expect(navigateMock).toHaveBeenCalledWith('/mass-dashboard/p2');
    });
  });

  it('shows candidate list, conversation, and current candidate question panes', async () => {
    stubWorkspaceFetch();

    renderPage();

    const candidatePane = await screen.findByRole('region', { name: '候选人列表' });
    expect(within(candidatePane).getByText('张三')).toBeInTheDocument();
    expect(within(candidatePane).getAllByRole('button', { name: '预览简历' })).toHaveLength(2);
    expect(within(candidatePane).queryByRole('button', { name: '生成题目' })).not.toBeInTheDocument();
    expect(within(candidatePane).queryByRole('button', { name: '对话改题' })).not.toBeInTheDocument();
    expect(within(candidatePane).queryByRole('button', { name: '人工记录' })).not.toBeInTheDocument();
    const conversationPane = screen.getByRole('region', { name: '与小面对话' });
    const questionPane = screen.getByRole('region', { name: '当前候选人题目' });
    expect(within(questionPane).getByText('当前候选人')).toBeInTheDocument();
    expect(conversationPane.querySelector('.xiao-mian-conversation-candidate-select')).toBeNull();
    expect(questionPane.querySelector('.xiao-mian-conversation-candidate-select')).not.toBeNull();
    expect(questionPane.querySelectorAll('details.question-editor__details')).toHaveLength(0);
    expect(within(questionPane).queryByText('题目属性')).not.toBeInTheDocument();
    expect(within(questionPane).queryByRole('button', { name: '保存并重新审核' })).not.toBeInTheDocument();
    expect(within(questionPane).queryByRole('button', { name: 'AI 辅助出题' })).not.toBeInTheDocument();
    expect(conversationPane.querySelector('.xiao-mian-next-step-card')).not.toBeNull();
    expect(within(conversationPane).queryByText('下一步操作')).not.toBeInTheDocument();
    expect(within(questionPane).queryByText('下一步操作')).not.toBeInTheDocument();
    expect(within(questionPane).queryByText('审核与导出')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '传递给下游' })).toBeInTheDocument();
  });

  it('locks the conversation composer and question editor for a completed interview', async () => {
    stubWorkspaceFetch(true);

    renderPage();

    const candidatePane = await screen.findByRole('region', { name: '候选人列表' });
    const questionPane = await screen.findByRole('region', { name: '当前候选人题目' });
    await waitFor(() => {
      const candidateCard = within(candidatePane).getByText('张三').closest('.candidate-list__item');
      expect(candidateCard?.textContent).toContain('\u9762\u8bd5\u7ed3\u675f');
    });

    const composer = document.querySelector('#convo-input-xiao_mian') as HTMLTextAreaElement | null;
    expect(composer).not.toBeNull();
    expect(composer).toBeDisabled();
    expect(document.querySelector('.convo-quick-prompt')).toBeDisabled();

    const questionInput = questionPane.querySelector('.question-editor__prompt') as HTMLTextAreaElement | null;
    expect(questionInput).not.toBeNull();
    expect(questionInput).toBeDisabled();
    expect(questionPane.querySelector('.question-editor-actions .ant-btn-primary')).toBeDisabled();
  });

  it('shows the selected candidate questions in the right pane after switching candidates', async () => {
    stubWorkspaceFetch();

    renderPage();

    const questionPane = await screen.findByRole('region', { name: '当前候选人题目' });
    const candidatePane = screen.getByRole('region', { name: '候选人列表' });
    expect(within(questionPane).getByDisplayValue('张三的题目')).toBeInTheDocument();

    fireEvent.click(within(candidatePane).getByRole('button', { name: /李四/ }));

    await waitFor(() => {
      expect(within(questionPane).getByDisplayValue('李四的题目')).toBeInTheDocument();
    });
    expect(within(questionPane).queryByDisplayValue('张三的题目')).not.toBeInTheDocument();
  });

  it('shows the sent status beside the candidate name in the invite list', async () => {
    stubWorkspaceFetch(false, [
      {
        candidate_id: 'c1',
        candidate_name: '张三',
        token: 'written-token',
        invite_url: '/written-test/written-token',
        invite_sent_at: '2026-09-02T09:42:00',
      },
    ]);

    renderPage();

    const sentTag = await screen.findByText('已发送');
    const inviteItem = sentTag.closest('.ant-list-item');
    const title = sentTag.closest('.ant-list-item-meta-title');
    const actions = inviteItem?.querySelector('.ant-list-item-action');

    expect(title).not.toBeNull();
    expect(within(title as HTMLElement).getByText('张三')).toBeInTheDocument();
    expect(actions).not.toBeNull();
    expect(within(actions as HTMLElement).queryByText('已发送')).not.toBeInTheDocument();
    expect(within(actions as HTMLElement).getByRole('button', { name: '再次发送' })).toBeInTheDocument();
  });
});

describe('XiaoMianPage launch results', () => {
  it('keeps written-test links separate from mass-interview email actions', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') {
        return response({
          id: 'p1',
          role: '店长',
          agents: ['xiao_mian'],
          candidates: [{ id: 'c1', name: '张三', email: 'candidate@example.com' }],
          stages: [
            {
              stage_id: 'match',
              status: 'done',
              output: { workflow_status: 'confirmed', shortlisted: ['c1'] },
            },
          ],
        });
      }
      if (path.startsWith('/api/interview/p1/review')) {
        return response({
          pipeline_id: 'p1',
          review_status: 'reviewed',
          generated_count: 1,
          interviews: [
            {
              candidate_id: 'c1',
              candidate_name: '张三',
              review_status: 'reviewed',
              questions: [{ id: 'q1', question: '请介绍一次经营改善案例。' }],
            },
          ],
        });
      }
      if (path === '/api/written-test/p1/status') {
        return response({
          sessions: [
            {
              candidate_id: 'c2',
              candidate_name: '李四',
              status: 'submitted',
              score: 81,
              evaluation: {
                scoring_version: 'written_v2',
                dimension_scores: { 岗位要点: 80, 专业准确性: 85, 分析逻辑: 75 },
              },
            },
          ],
          total: 1,
          submitted: 1,
          pending: 0,
        });
      }
      if (path === '/api/conversations/sessions/ensure') return response({ session: { id: 'session-1' } });
      if (path === '/api/conversations/sessions/session-1/state?limit=100') return response({ messages: [], recent_commands: [] });
      if (path === '/api/written-test/launch' && init?.method === 'POST') {
        return response({
          sessions: [
            {
              candidate_id: 'c1',
              candidate_name: '张三',
              invite_url: '/written-test/written-token',
              expires_at: '2026-08-27T12:00:00',
            },
          ],
        });
      }
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByText('岗位要点 80')).toBeInTheDocument();
    expect(screen.getByText('专业准确性 85')).toBeInTheDocument();
    fireEvent.click(await screen.findByRole('button', { name: '发起在线笔试' }));

    expect(await screen.findByText('在线笔试邀请')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '复制全部笔试链接' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '全部发送邮件' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '发送邮件' })).not.toBeInTheDocument();
    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/written-test/launch',
        expect.objectContaining({ method: 'POST' }),
      );
    });
    expect(fetchMock).not.toHaveBeenCalledWith(expect.stringContaining('/api/mass-interview/'), expect.anything());

  }, 15000);
});
