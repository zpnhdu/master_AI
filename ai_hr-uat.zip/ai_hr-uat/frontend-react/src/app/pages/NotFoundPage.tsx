import { Button, Result, Typography } from 'antd';
import { useNavigate } from 'react-router-dom';

import { routePaths } from '../routes/route-paths';

export function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="auth-page">
      <Typography.Title className="visually-hidden" level={1}>
        页面未找到
      </Typography.Title>
      <Result
        status="404"
        title="页面未找到"
        subTitle="您访问的页面不存在或已被移除。"
        extra={
          <Button type="primary" onClick={() => navigate(routePaths.studio, { replace: true })}>
            返回工作台
          </Button>
        }
      />
    </div>
  );
}