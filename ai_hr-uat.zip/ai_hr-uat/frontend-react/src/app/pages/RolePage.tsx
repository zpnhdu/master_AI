import { Alert, Button, Card, Col, Empty, Form, Input, InputNumber, Row, Select, Space, Spin, Statistic, Switch, Tabs, Tag, Typography, message } from 'antd';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';

import {
  fetchAgentStats,
  fetchRoleDetail,
  saveAgentConfig,
  testAgent,
  type AgentTestResult,
  type RoleStage,
  type RoleStageConfig,
} from '../../features/roles/api';
import { routePaths } from '../routes/route-paths';

export function RolePage() {
  const { roleId = '' } = useParams();
  const queryClient = useQueryClient();
  const roleQuery = useQuery({
    queryKey: ['roles', roleId],
    queryFn: () => fetchRoleDetail(roleId),
    enabled: Boolean(roleId),
    retry: 1,
  });
  const statsQuery = useQuery({
    queryKey: ['agents', 'stats'],
    queryFn: fetchAgentStats,
    enabled: Boolean(roleId),
    retry: 1,
  });

  const role = roleQuery.data;
  const stageIds = useMemo(() => new Set((role?.stages ?? []).map((stage) => stage.stage_id)), [role?.stages]);
  const roleStats = (statsQuery.data?.stats ?? []).filter((item) => stageIds.has(item.agent_id));
  const recentCalls = (statsQuery.data?.recent_calls ?? []).filter((item) => stageIds.has(item.agent_id ?? ''));

  const totalCalls = roleStats.reduce((sum, item) => sum + (item.total_calls ?? 0), 0);
  const totalSuccess = roleStats.reduce((sum, item) => sum + (item.success_count ?? 0), 0);
  const totalTokens = roleStats.reduce((sum, item) => sum + (item.total_tokens ?? 0), 0);
  const avgDuration = roleStats.length
    ? Math.round(roleStats.reduce((sum, item) => sum + (item.avg_duration_ms ?? 0), 0) / roleStats.length)
    : 0;

  if (roleQuery.isPending) {
    return (
      <div className="agent-page">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </div>
    );
  }

  if (roleQuery.isError || !role) {
    return (
      <div className="agent-page agent-page--status">
        <Alert
          type="error"
          showIcon
          message="角色未找到"
          description={roleQuery.error instanceof Error ? roleQuery.error.message : '请检查角色 ID 是否正确'}
          action={
            <Link to={routePaths.studio}>
              <Button>返回工作室</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="agent-page role-page">
      <header className="agent-page__header" style={{ maxWidth: 960 }}>
        <Space size={14}>
          <span className="role-page__icon" aria-hidden="true">{role.icon ?? '🤖'}</span>
          <div>
            <Typography.Title level={3} style={{ margin: 0 }}>
              {role.name} · {role.display_name}
            </Typography.Title>
            <Typography.Text type="secondary">{role.description ?? ''}</Typography.Text>
          </div>
        </Space>
        <Space>
          <Link to={routePaths.studio}>
            <Button>← 返回</Button>
          </Link>
          <Button
            onClick={() => {
              void roleQuery.refetch();
              void statsQuery.refetch();
            }}
          >
            刷新
          </Button>
        </Space>
      </header>

      <div style={{ maxWidth: 960, margin: '0 auto', width: '100%' }}>
        <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
          <Col xs={12} md={6}>
            <Card><Statistic title="调用次数" value={totalCalls} /></Card>
          </Col>
          <Col xs={12} md={6}>
            <Card>
              <Statistic
                title="成功率"
                value={totalCalls ? Math.round((totalSuccess / totalCalls) * 100) : 0}
                suffix="%"
                valueStyle={{ color: '#16a34a' }}
              />
            </Card>
          </Col>
          <Col xs={12} md={6}>
            <Card>
              <Statistic title="平均耗时" value={avgDuration} suffix="ms" valueStyle={{ color: '#d97706' }} />
            </Card>
          </Col>
          <Col xs={12} md={6}>
            <Card>
              <Statistic
                title="Token 消耗"
                value={totalTokens > 999 ? `${(totalTokens / 1000).toFixed(1)}k` : totalTokens}
                valueStyle={{ color: '#7c3aed' }}
              />
            </Card>
          </Col>
        </Row>

        <Card>
          <Tabs
            items={[
              {
                key: 'config',
                label: '⚙️ 配置',
                children: (
                  <StageConfigList
                    stages={role.stages ?? []}
                    onSaved={() => {
                      void queryClient.invalidateQueries({ queryKey: ['roles', roleId] });
                    }}
                  />
                ),
              },
              {
                key: 'logs',
                label: '📋 调用日志',
                children: <CallLogList calls={recentCalls} stages={role.stages ?? []} loading={statsQuery.isPending} />,
              },
              {
                key: 'test',
                label: '🧪 测试',
                children: <StageTestPanel stages={role.stages ?? []} />,
              },
            ]}
          />
        </Card>
      </div>
    </div>
  );
}

function StageConfigList({ stages, onSaved }: { stages: RoleStage[]; onSaved: () => void }) {
  if (!stages.length) return <Empty description="该角色暂无阶段配置" />;
  return (
    <>
      {stages.map((stage) => (
        <StageConfigForm key={stage.stage_id} stage={stage} onSaved={onSaved} messageApi={message} />
      ))}
    </>
  );
}

function StageConfigForm({
  stage,
  onSaved,
  messageApi,
}: {
  stage: RoleStage;
  onSaved: () => void;
  messageApi: typeof message;
}) {
  const saveMutation = useMutation({
    mutationFn: (config: Partial<RoleStageConfig>) => saveAgentConfig(stage.stage_id, config),
    onSuccess: () => {
      messageApi.success(`「${stage.stage_id}」配置已保存`);
      onSaved();
    },
    onError: (error) => messageApi.error(error instanceof Error ? error.message : '保存失败'),
  });
  const config = stage.config ?? {};
  const enabled = config.enabled !== false;

  return (
    <Card size="small" className="agent-card" title={
      <Space>
        <Typography.Text strong>{stage.stage_id}</Typography.Text>
        <Tag color={enabled ? 'success' : 'default'}>{enabled ? '已启用' : '已停用'}</Tag>
      </Space>
    }>
      <Form
        layout="vertical"
        initialValues={{
          model: config.model ?? 'qwen3.6-flash',
          complexity: config.complexity ?? 'flash',
          temperature: config.temperature ?? 0.7,
          timeout: config.timeout,
          retry_count: config.retry_count ?? 2,
          human_approval: config.human_approval ? 'yes' : 'no',
        }}
        onFinish={(values) =>
          saveMutation.mutate({
            model: values.model,
            complexity: values.complexity,
            temperature: Number(values.temperature),
            timeout: Number(values.timeout),
            retry_count: Number(values.retry_count),
            human_approval: values.human_approval === 'yes',
          })
        }
      >
        <Row gutter={16}>
          <Col xs={24} md={12}>
            <Form.Item name="model" label="模型">
              <Input />
            </Form.Item>
          </Col>
          <Col xs={24} md={12}>
            <Form.Item name="complexity" label="复杂度">
              <Select
                options={[
                  { value: 'flash', label: 'flash（快速）' },
                  { value: 'plus', label: 'plus（均衡）' },
                  { value: 'max', label: 'max（深度）' },
                ]}
              />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="temperature" label="Temperature">
              <InputNumber min={0} max={2} step={0.1} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="timeout" label="超时（秒）">
              <InputNumber min={1} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="retry_count" label="重试次数">
              <InputNumber min={0} max={5} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="human_approval" label="人工审核">
              <Select
                options={[
                  { value: 'no', label: '不需要' },
                  { value: 'yes', label: '需要' },
                ]}
              />
            </Form.Item>
          </Col>
        </Row>
        <Space>
          <Button type="primary" htmlType="submit" loading={saveMutation.isPending}>
            保存配置
          </Button>
          {/* 修复旧版 toggleStage 未取反的 no-op 缺陷 */}
          <Button
            onClick={() => saveMutation.mutate({ enabled: !enabled })}
            loading={saveMutation.isPending}
          >
            {enabled ? '停用该阶段' : '启用该阶段'}
          </Button>
        </Space>
      </Form>
    </Card>
  );
}

function CallLogList({
  calls,
  stages,
  loading,
}: {
  calls: Array<{ agent_id?: string; status?: string; duration_ms?: number; tokens_used?: number; created_at?: string }>;
  stages: RoleStage[];
  loading: boolean;
}) {
  const [stageFilter, setStageFilter] = useState('');
  const filtered = calls.filter((call) => !stageFilter || call.agent_id === stageFilter).slice(0, 30);

  if (loading) return <div className="app-loading"><Spin size="large" tip="加载中" /></div>;
  return (
    <>
      <Select
        value={stageFilter}
        onChange={setStageFilter}
        style={{ width: 200, marginBottom: 12 }}
        options={[
          { value: '', label: '全部阶段' },
          ...stages.map((stage) => ({ value: stage.stage_id, label: stage.stage_id })),
        ]}
      />
      {filtered.length ? (
        <div className="role-log-list">
          {filtered.map((call, index) => (
            <div key={index} className="role-log-list__row">
              <span className={`role-log-list__dot role-log-list__dot--${call.status === 'success' ? 'ok' : 'err'}`} />
              <Typography.Text code>{call.agent_id}</Typography.Text>
              <Typography.Text type="secondary">
                {call.duration_ms ?? 0}ms · {call.tokens_used ?? 0} tok
              </Typography.Text>
              <Typography.Text type="secondary" style={{ marginLeft: 'auto' }}>
                {call.created_at ? new Date(call.created_at).toLocaleTimeString('zh-CN', { hour12: false }) : ''}
              </Typography.Text>
            </div>
          ))}
        </div>
      ) : (
        <Empty description="暂无调用日志" />
      )}
    </>
  );
}

function StageTestPanel({ stages }: { stages: RoleStage[] }) {
  const [stageId, setStageId] = useState('');
  const [paramsText, setParamsText] = useState('{}');
  const [result, setResult] = useState<AgentTestResult | null>(null);
  const [elapsed, setElapsed] = useState(0);

  const testMutation = useMutation({
    mutationFn: ({ id, params }: { id: string; params: Record<string, unknown> }) => testAgent(id, params),
  });

  async function run() {
    if (!stageId) {
      message.warning('请先选择阶段');
      return;
    }
    let params: Record<string, unknown>;
    try {
      params = JSON.parse(paramsText || '{}') as Record<string, unknown>;
    } catch {
      message.error('参数不是合法 JSON');
      return;
    }
    const started = performance.now();
    try {
      const data = await testMutation.mutateAsync({ id: stageId, params });
      setElapsed(Math.round(performance.now() - started));
      setResult(data);
    } catch (error) {
      setElapsed(Math.round(performance.now() - started));
      setResult({ status: 'error', error: error instanceof Error ? error.message : '测试失败' });
    }
  }

  return (
    <>
      <Space wrap style={{ marginBottom: 12 }}>
        <Select
          value={stageId || undefined}
          placeholder="选择阶段"
          onChange={setStageId}
          style={{ width: 220 }}
          options={stages.map((stage) => ({ value: stage.stage_id, label: stage.stage_id }))}
        />
      </Space>
      <Input.TextArea
        rows={6}
        value={paramsText}
        onChange={(event) => setParamsText(event.target.value)}
        placeholder='{"key": "value"}'
        style={{ fontFamily: 'Menlo, Monaco, monospace' }}
      />
      <Space style={{ marginTop: 12 }}>
        <Button type="primary" onClick={() => void run()} loading={testMutation.isPending}>
          运行测试
        </Button>
      </Space>
      {result ? (
        <pre className="role-test-result">
          [{elapsed}ms] {JSON.stringify(result, null, 2)}
        </pre>
      ) : null}
    </>
  );
}