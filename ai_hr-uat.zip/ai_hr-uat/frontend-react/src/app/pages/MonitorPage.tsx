import { Alert, Button, Card, Col, Empty, List, Row, Segmented, Space, Spin, Statistic, Tabs, Tag, Typography } from 'antd';
import { useMemo, useState } from 'react';
import type { EChartsOption } from 'echarts';

import { AppShell } from '../components/AppShell';
import type { MonitorEventItem, MonitorLogItem } from '../../features/analytics/api';
import {
  useMonitorDashboardQuery,
  useMonitorEventsQuery,
  useMonitorLogsQuery,
  useMonitorUsageQuery,
} from '../../features/analytics/hooks';
import { EChart } from '../../shared/EChart';
import { DataTable } from '../../shared/data-table';
import type { DataTableColumn } from '../../shared/data-table';
import { ListFilterSelect, ListSearch, ListToolbar } from '../../shared/list-workbench';

const RANGE_HOURS: Record<string, number> = { '1h': 1, '6h': 6, '24h': 24, '7d': 168 };

function rangeToFromTs(range: string): string | undefined {
  const hours = RANGE_HOURS[range];
  if (!hours) return undefined;
  return new Date(Date.now() - hours * 3600 * 1000).toISOString();
}

function formatCompact(value: number): string {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return String(value);
}

export function MonitorPage() {
  return (
    <AppShell>
      <MonitorContent />
    </AppShell>
  );
}

function MonitorContent() {
  const dashboardQuery = useMonitorDashboardQuery();
  const weekAgo = useMemo(() => new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(), []);
  const usageQuery = useMonitorUsageQuery({ from_ts: weekAgo, granularity: 'day' });

  const last24h = dashboardQuery.data?.last_24h ?? {};
  const updatedAt = dashboardQuery.dataUpdatedAt
    ? new Date(dashboardQuery.dataUpdatedAt).toLocaleTimeString('zh-CN', { hour12: false })
    : '';

  const timeseries = usageQuery.data?.timeseries ?? [];
  const usageChart: EChartsOption = {
    grid: { left: 48, right: 48, top: 36, bottom: 28 },
    legend: { top: 0, textStyle: { fontSize: 11, color: '#64748b' } },
    xAxis: {
      type: 'category',
      data: timeseries.map((item) => item.bucket.slice(5)),
      axisLabel: { fontSize: 10, color: '#94a3b8' },
    },
    yAxis: [
      { type: 'value', name: 'Token', splitLine: { lineStyle: { color: '#f1f5f9' } } },
      { type: 'value', name: '费用', splitLine: { show: false }, axisLabel: { formatter: '${value}' } },
    ],
    series: [
      {
        name: 'Prompt Tokens',
        type: 'bar',
        stack: 'tokens',
        data: timeseries.map((item) => item.prompt_tokens ?? 0),
        itemStyle: { color: '#2563ebaa' },
      },
      {
        name: 'Completion Tokens',
        type: 'bar',
        stack: 'tokens',
        data: timeseries.map((item) => item.completion_tokens ?? 0),
        itemStyle: { color: '#10b981aa', borderRadius: [4, 4, 0, 0] },
      },
      {
        name: '费用',
        type: 'line',
        yAxisIndex: 1,
        data: timeseries.map((item) => item.cost_usd ?? 0),
        lineStyle: { color: '#f59e0b', width: 2 },
        itemStyle: { color: '#f59e0b' },
        symbol: 'circle',
        symbolSize: 6,
      },
    ],
    tooltip: { trigger: 'axis' },
  };

  return (
    <div className="monitor-page">
      <div className="monitor-page__header">
        <div>
          <Typography.Title level={3} style={{ margin: 0 }}>
            系统监控
          </Typography.Title>
          <Typography.Text type="secondary">错误日志 · 操作审计 · Token 消耗{updatedAt ? ` · 更新于 ${updatedAt}` : ''}</Typography.Text>
        </div>
        <Button onClick={() => { void dashboardQuery.refetch(); void usageQuery.refetch(); }} loading={dashboardQuery.isRefetching}>
          刷新
        </Button>
      </div>

      {dashboardQuery.isError ? (
        <Alert
          type="error"
          showIcon
          message="监控数据加载失败"
          description={dashboardQuery.error instanceof Error ? dashboardQuery.error.message : '请稍后重试'}
          action={<Button onClick={() => void dashboardQuery.refetch()}>重试</Button>}
          style={{ marginBottom: 16 }}
        />
      ) : null}

      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col xs={12} md={6}>
          <Card><Statistic title="LLM 调用（24h）" value={last24h.total_llm_calls ?? 0} loading={dashboardQuery.isPending} /></Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="Token 用量（24h）"
              value={formatCompact(last24h.total_tokens ?? 0)}
              valueStyle={{ color: '#16a34a' }}
              loading={dashboardQuery.isPending}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="估算费用（24h）"
              value={last24h.total_cost_usd ?? 0}
              precision={4}
              prefix="$"
              valueStyle={{ color: '#d97706' }}
              loading={dashboardQuery.isPending}
            />
          </Card>
        </Col>
        <Col xs={12} md={6}>
          <Card>
            <Statistic
              title="错误数（24h）"
              value={last24h.error_count ?? 0}
              valueStyle={{ color: (last24h.error_count ?? 0) > 0 ? '#dc2626' : undefined }}
              loading={dashboardQuery.isPending}
            />
          </Card>
        </Col>
      </Row>

      <Card title="Token 用量趋势（近 7 天）" className="agent-card">
        <EChart option={usageChart} height={320} />
      </Card>

      <Card className="agent-card">
        <Tabs
          items={[
            { key: 'logs', label: '错误日志', children: <LogsPanel /> },
            { key: 'events', label: '操作审计', children: <EventsPanel /> },
            { key: 'models', label: '模型费用', children: <ModelsPanel /> },
          ]}
        />
      </Card>
    </div>
  );
}

function LogsPanel() {
  const [page, setPage] = useState(1);
  const [level, setLevel] = useState('');
  const [range, setRange] = useState('24h');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');

  const logsQuery = useMonitorLogsQuery({
    page,
    page_size: 50,
    level: level || undefined,
    search: search || undefined,
    from_ts: rangeToFromTs(range),
  });

  const items = logsQuery.data?.items ?? [];
  const sources = useMemo(
    () => Array.from(new Set(items.map((item) => item.source).filter((value): value is string => Boolean(value)))),
    [items],
  );

  const levelColor = (value?: string) => {
    if (value === 'ERROR' || value === 'CRITICAL') return 'error';
    if (value === 'WARNING') return 'warning';
    if (value === 'INFO') return 'processing';
    return 'default';
  };

  return (
    <>
      <ListToolbar
        search={(
          <ListSearch
            value={searchInput}
            placeholder="搜索日志关键词"
            onChange={(value) => setSearchInput(value)}
            onQueryChange={(value) => {
              setSearch(value.trim());
              setPage(1);
            }}
          />
        )}
        filters={(
          <>
            <ListFilterSelect
              aria-label="日志级别"
              value={level || undefined}
              onChange={(value) => { setLevel(String(value ?? '')); setPage(1); }}
              options={[
                { value: 'ERROR', label: 'ERROR' },
                { value: 'WARNING', label: 'WARNING' },
                { value: 'INFO', label: 'INFO' },
                { value: 'DEBUG', label: 'DEBUG' },
              ]}
              placeholder="全部级别"
            />
            <ListFilterSelect
              aria-label="日志时间范围"
              value={range}
              onChange={(value) => { setRange(String(value ?? '24h')); setPage(1); }}
              options={[
                { value: '1h', label: '近 1 小时' },
                { value: '6h', label: '近 6 小时' },
                { value: '24h', label: '近 24 小时' },
                { value: '7d', label: '近 7 天' },
              ]}
              allowClear={false}
            />
          </>
        )}
        count={sources.length ? `来源：${sources.join('、')}` : undefined}
      />
      {logsQuery.isPending ? (
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      ) : logsQuery.isError ? (
        <Alert type="error" showIcon message="日志加载失败" action={<Button size="small" onClick={() => void logsQuery.refetch()}>重试</Button>} />
      ) : items.length ? (
        <List
          className="monitor-log-list"
          dataSource={items}
          renderItem={(item: MonitorLogItem) => (
            <List.Item>
              <Space wrap>
                <Typography.Text code style={{ fontSize: 12 }}>{item.timestamp ?? ''}</Typography.Text>
                <Tag color={levelColor(item.level)}>{item.level ?? '—'}</Tag>
                <Tag color="purple">{item.source ?? '—'}</Tag>
                <Typography.Text style={{ fontFamily: 'Menlo, Monaco, monospace', fontSize: 12 }}>{item.message}</Typography.Text>
              </Space>
            </List.Item>
          )}
        />
      ) : (
        <Empty description="暂无日志" />
      )}
      <Space style={{ marginTop: 12 }}>
        <Button disabled={page <= 1} onClick={() => setPage((value) => value - 1)}>上一页</Button>
        <Typography.Text type="secondary">第 {page} 页 · 共 {logsQuery.data?.total ?? 0} 条</Typography.Text>
        <Button disabled={items.length < 50} onClick={() => setPage((value) => value + 1)}>下一页</Button>
      </Space>
    </>
  );
}

function EventsPanel() {
  const [entityType, setEntityType] = useState('');
  const [range, setRange] = useState('24h');
  const eventsQuery = useMonitorEventsQuery({
    page: 1,
    page_size: 100,
    entity_type: entityType || undefined,
    from_ts: rangeToFromTs(range),
  });
  const items = eventsQuery.data?.items ?? [];

  const dotColor = (value?: string) =>
    value === 'pipeline' ? '#2563eb' : value === 'agent' ? '#8b5cf6' : value === 'candidate' ? '#10b981' : '#94a3b8';

  return (
    <>
      <ListToolbar
        filters={(
          <>
            <Segmented
              value={entityType}
              onChange={(value) => setEntityType(String(value))}
              options={[
                { value: '', label: '全部类型' },
                { value: 'pipeline', label: '岗位' },
                { value: 'agent', label: 'Agent' },
                { value: 'candidate', label: '候选人' },
              ]}
            />
            <Segmented
              value={range}
              onChange={(value) => setRange(String(value))}
              options={[
                { value: '1h', label: '近 1 小时' },
                { value: '24h', label: '近 24 小时' },
                { value: '7d', label: '近 7 天' },
              ]}
            />
          </>
        )}
      />
      {eventsQuery.isPending ? (
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      ) : eventsQuery.isError ? (
        <Alert type="error" showIcon message="审计事件加载失败" action={<Button size="small" onClick={() => void eventsQuery.refetch()}>重试</Button>} />
      ) : items.length ? (
        <List
          dataSource={items}
          renderItem={(item: MonitorEventItem) => (
            <List.Item>
              <Space align="start">
                <span className="dashboard-activity__dot" style={{ background: dotColor(item.entity_type) }} />
                <div>
                  <Typography.Text>{item.summary ?? item.event_type ?? '—'}</Typography.Text>
                  <div>
                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                      {item.timestamp ?? ''} · {item.event_type ?? '—'} · {item.actor || 'system'}
                    </Typography.Text>
                  </div>
                </div>
              </Space>
            </List.Item>
          )}
        />
      ) : (
        <Empty description="暂无审计事件" />
      )}
    </>
  );
}

function ModelsPanel() {
  const usageQuery = useMonitorUsageQuery({});
  const byModel = usageQuery.data?.summary?.by_model ?? {};
  const rows = Object.entries(byModel).map(([model, value]) => ({
    model,
    call_count: value.call_count ?? 0,
    total_tokens: value.total_tokens ?? 0,
    estimated_cost_usd: value.estimated_cost_usd ?? 0,
  }));

  const columns: DataTableColumn<typeof rows[number]>[] = [
    { key: 'model', title: '模型', dataIndex: 'model', role: 'identity', render: (value: string) => <Typography.Text strong>{value}</Typography.Text> },
    { key: 'call_count', title: '调用次数', dataIndex: 'call_count', width: 120 },
    { key: 'total_tokens', title: 'Token 总量', dataIndex: 'total_tokens', width: 140, render: (value: number) => formatCompact(value) },
    {
      key: 'estimated_cost_usd',
      title: '累计费用',
      dataIndex: 'estimated_cost_usd',
      width: 140,
      render: (value: number) => (
        <Typography.Text strong style={{ color: '#d97706' }}>
          ${value.toFixed(6)}
        </Typography.Text>
      ),
    },
  ];

  return (
    <DataTable
      tableId="monitor-models"
      rowKey="model"
      scroll={{ x: 'max-content' }}
      loading={usageQuery.isPending}
      dataSource={rows}
      pagination={false}
      locale={{ emptyText: '暂无 Token 消耗记录' }}
      columns={columns}
    />
  );
}