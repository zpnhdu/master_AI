import { Alert, Button, Card, Col, Empty, List, Modal, Row, Select, Space, Spin, Table, Tag, Typography } from 'antd';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import type { EChartsOption } from 'echarts';

import { PageShell } from '../components/PageShell';
import { PageTabs } from '../../shared/components/PageTabs';
import { routePaths } from '../routes/route-paths';
import { useAuth } from '../auth/AuthContext';
import type { CandidateRankingCandidate, DashboardData, RoleOverviewItem } from '../../features/analytics/api';
import {
  useAnalyticsDashboardQuery,
  useCandidateRankingQuery,
  useRoleOverviewQuery,
} from '../../features/analytics/hooks';
import { EChart } from '../../shared/EChart';
import { DataTable } from '../../shared/data-table';
import type { DataTableInputColumn } from '../../shared/data-table/types';
import { LeaderCabinView } from '../../features/analytics/components/LeaderCabinView';

const CANDIDATE_RADAR_DIMENSIONS = [
  { key: "job_coverage", name: "岗位要点匹配" },
  { key: "professional_accuracy", name: "专业准确性" },
  { key: "analytical_logic", name: "分析逻辑" },
  { key: "solution_feasibility", name: "方案可执行性" },
  { key: "evidence_boundaries", name: "证据与边界" },
] as const;

const CANDIDATE_RADAR_COLORS = ["#38bdf8", "#a78bfa", "#34d399", "#fbbf24", "#fb7185"];

type RadarCandidate = CandidateRankingCandidate & {
  dimension_scores: Record<(typeof CANDIDATE_RADAR_DIMENSIONS)[number]["key"], number>;
};

function completeRadarCandidates(candidates: CandidateRankingCandidate[]): RadarCandidate[] {
  return candidates.filter((candidate): candidate is RadarCandidate => {
    const scores = candidate.dimension_scores;
    return Boolean(scores) && CANDIDATE_RADAR_DIMENSIONS.every(({ key }) => {
      const value = scores?.[key];
      return typeof value === "number" && Number.isFinite(value);
    });
  });
}

function candidateRadarOption(candidates: RadarCandidate[]): EChartsOption {
  const displayScore = (value: number) => {
    // Formal small-review rubrics use a 0–4 level scale, while the radar
    // axis is displayed as 0–100. Keep legacy percentage scores unchanged.
    const normalized = Number.isFinite(value) && value >= 0 ? value : 0;
    return normalized <= 4 ? normalized * 25 : Math.min(100, normalized);
  };
  return {
    backgroundColor: "#ffffff",
    tooltip: { trigger: "item" },
    legend: {
      top: 8,
      left: 12,
      right: 12,
      type: "scroll",
      textStyle: { color: "#374151", fontSize: 12 },
      data: candidates.map((candidate) => candidate.name),
    },
    radar: {
      center: ["50%", "55%"],
      radius: "62%",
      indicator: CANDIDATE_RADAR_DIMENSIONS.map(({ name }) => ({ name, max: 100 })),
      splitNumber: 4,
      axisName: { color: "#6b7280", fontSize: 12 },
      axisLine: { lineStyle: { color: "#d1d5db" } },
      splitLine: { lineStyle: { color: "#e5e7eb" } },
      splitArea: {
        areaStyle: {
          color: ["#f9fafb", "#f3f4f6"],
        },
      },
    },
    series: candidates.map((candidate, index) => {
      const color = CANDIDATE_RADAR_COLORS[index % CANDIDATE_RADAR_COLORS.length];
      return {
        type: "radar" as const,
        name: candidate.name,
        symbol: "circle",
        symbolSize: 5,
        lineStyle: { color, width: 2 },
        itemStyle: { color },
        areaStyle: { color, opacity: 0.12 },
        data: [{
          name: candidate.name,
          value: CANDIDATE_RADAR_DIMENSIONS.map(({ key }) => displayScore(candidate.dimension_scores[key])),
        }],
      };
    }),
  };
}

function trendOption(data: DashboardData, daysCount: number): EChartsOption {
  const trend = data.summary?.daily_trend ?? {};
  const allDays = trend.days ?? [];
  const days = allDays.slice(-daysCount);
  const applied = (trend.applied ?? []).slice(-daysCount);
  const screened = (trend.screened ?? []).slice(-daysCount);
  const interviewed = (trend.interviewed ?? []).slice(-daysCount);
  const interviewPassed = (trend.interview_passed ?? []).slice(-daysCount);
  const gradient = (from: string, to: string) => ({
    type: 'linear' as const,
    x: 0, y: 0, x2: 0, y2: 1,
    colorStops: [
      { offset: 0, color: from },
      { offset: 1, color: to },
    ],
  });
  return {
    grid: { left: 40, right: 20, top: 20, bottom: 68 },
    legend: {
      top: 0,
      right: 0,
      icon: 'roundRect',
      itemWidth: 8,
      itemHeight: 8,
      textStyle: { color: '#6b7280', fontSize: 11 },
      itemGap: 16,
    },
    xAxis: {
      type: 'category',
      data: days,
      boundaryGap: false,
      axisLabel: { color: '#9ca3af', fontSize: 10 },
      axisLine: { lineStyle: { color: '#e8eaed' } },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      axisLabel: { color: '#9ca3af', fontSize: 10 },
      splitLine: { lineStyle: { color: '#f3f4f6' } },
    },
    dataZoom: [
      { type: 'inside' },
      {
        type: 'slider',
        height: 24,
        bottom: 24,
        borderColor: 'transparent',
        backgroundColor: '#f3f4f6',
        fillerColor: 'rgba(37,99,235,.08)',
        handleSize: '80%',
        handleStyle: { color: '#2563eb', borderRadius: 4 },
        textStyle: { fontSize: 10, color: '#9ca3af' },
        moveHandleSize: 8,
        showDetail: false,
      },
    ],
    series: [
      {
        name: '投递',
        type: 'line',
        smooth: true,
        showSymbol: false,
        data: applied,
        lineStyle: { color: '#4F46E5', width: 2.5 },
        itemStyle: { color: '#4F46E5' },
        areaStyle: { color: gradient('rgba(79,70,229,.15)', 'rgba(255,255,255,0)') },
      },
      {
        name: '筛选通过',
        type: 'line',
        smooth: true,
        showSymbol: false,
        data: screened,
        lineStyle: { color: '#2563EB', width: 2 },
        itemStyle: { color: '#2563EB' },
      },
      {
        name: '面试',
        type: 'line',
        smooth: true,
        showSymbol: false,
        data: interviewed,
        lineStyle: { color: '#0EA5A6', width: 2.5, type: 'dashed' },
        itemStyle: { color: '#0EA5A6' },
      },
      {
        name: '录用',
        type: 'line',
        smooth: true,
        showSymbol: false,
        data: interviewPassed,
        lineStyle: { color: '#F59E0B', width: 2, type: 'dotted' },
        itemStyle: { color: '#F59E0B' },
      },
    ],
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#fff',
      borderColor: '#e8eaed',
      textStyle: { color: '#111827', fontSize: 12 },
    },
  };
}

export function DashboardPage() {
  return <DashboardContent />;
}

function DashboardContent() {
  const dashboardQuery = useAnalyticsDashboardQuery();
  const { user } = useAuth();
  const isAdmin = user?.role_id === 'admin';

  const [activeViewTab, setActiveViewTab] = useState<string>('business');
  const [lastUpdated, setLastUpdated] = useState('--:--:--');
  const [countdown, setCountdown] = useState(60);
  const countdownRef = useRef(60);
  const lastUpdatedAtRef = useRef(0);

  useEffect(() => {
    if (dashboardQuery.dataUpdatedAt && dashboardQuery.dataUpdatedAt !== lastUpdatedAtRef.current) {
      lastUpdatedAtRef.current = dashboardQuery.dataUpdatedAt;
      const d = new Date(dashboardQuery.dataUpdatedAt);
      setLastUpdated([d.getHours(), d.getMinutes(), d.getSeconds()].map((v) => String(v).padStart(2, '0')).join(':'));
      countdownRef.current = 60;
      setCountdown(60);
    }
  }, [dashboardQuery.dataUpdatedAt]);

  useEffect(() => {
    const timer = setInterval(() => {
      countdownRef.current -= 1;
      if (countdownRef.current <= 0) countdownRef.current = 60;
      setCountdown(countdownRef.current);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <PageShell
      title="数据看板"
      variant="flex"
      className="dashboard-page-shell"
      headerExtra={
        <Space>
          {isAdmin && (
            <PageTabs
              value={activeViewTab}
              onChange={setActiveViewTab}
              options={[
                { label: '招聘看板', value: 'business' },
                { label: 'HR数据舱', value: 'leader' },
              ]}
            />
          )}
          <div className="dashboard-page__status">
            <span className="dashboard-page__pulse" />
            最近更新 <b>{lastUpdated}</b> · <b>{countdown}</b>s 后自动刷新
          </div>
          <Button onClick={() => void dashboardQuery.refetch()} loading={dashboardQuery.isFetching}>刷新</Button>
        </Space>
      }
    >
      <div className="dashboard-page">
        {activeViewTab === 'leader' ? (
          <LeaderCabinView />
        ) : (
          <BusinessView />
        )}
      </div>
    </PageShell>
  );
}

function BusinessView() {
  const dashboardQuery = useAnalyticsDashboardQuery();
  const roleOverviewQuery = useRoleOverviewQuery();

  const [trendDays, setTrendDays] = useState<30 | 7>(30);
  const [expandedRoles, setExpandedRoles] = useState<Set<string>>(new Set());
  const [selectedRoleKey, setSelectedRoleKey] = useState("");
  const [topLimit, setTopLimit] = useState<3 | 4 | 5>(3);
  const [detailOpen, setDetailOpen] = useState(false);

  const data = dashboardQuery.data;
  const funnel = data?.funnel ?? {};
  const summary = data?.summary ?? {};
  const stages = funnel.stages ?? {};
  const roleRows = roleOverviewQuery.data ?? [];
  const sortedRoleRows = useMemo(
    () => [...roleRows].sort((a, b) => b.candidate_count - a.candidate_count),
    [roleRows],
  );
  const selectedRole = sortedRoleRows.find((item) => `${item.role}:${item.type_code}` === selectedRoleKey) ?? sortedRoleRows[0];
  const selectedKey = selectedRole ? `${selectedRole.role}:${selectedRole.type_code}` : "";
  const rankingQuery = useCandidateRankingQuery({
    role: selectedRole?.role,
    typeCode: selectedRole?.type_code,
    limit: topLimit,
    enabled: Boolean(selectedRole),
  });
  const detailQuery = useCandidateRankingQuery({
    role: selectedRole?.role,
    typeCode: selectedRole?.type_code,
    limit: 1000,
    detail: true,
    enabled: detailOpen && Boolean(selectedRole),
  });

  useEffect(() => {
    if (selectedKey && selectedKey !== selectedRoleKey) setSelectedRoleKey(selectedKey);
  }, [selectedKey, selectedRoleKey]);

  if (dashboardQuery.isPending) {
    return <div className="app-loading"><Spin size="large" tip="加载中" /></div>;
  }
  if (dashboardQuery.isError || !data) {
    return (
      <Alert
        type="error"
        showIcon
        message="加载失败"
        description={dashboardQuery.error instanceof Error ? dashboardQuery.error.message : '请稍后重试'}
        action={
          <Button onClick={() => void dashboardQuery.refetch()}>重试</Button>
        }
      />
    );
  }

  const applied = stages.applied ?? 0;
  const screened = stages.screened ?? 0;
  const interviewed = stages.interviewed ?? 0;
  const interviewPassed = stages.interview_passed ?? 0;
  const conversion = interviewed > 0 ? Math.round((interviewPassed / interviewed) * 100) : 0;

  return (
    <>
      <div className="dashboard-page__kpis">
        <Card className="dashboard-kpi dashboard-kpi--blue">
          <div className="dashboard-kpi__label">活跃岗位</div>
          <div className="dashboard-kpi__value">{funnel.total_pipelines ?? 0}</div>
          <div className={`dashboard-kpi__trend ${summary.weekly_new ? 'dashboard-kpi__trend--up' : 'dashboard-kpi__trend--neutral'}`}>
            {summary.weekly_new ? `↑ ${summary.weekly_new} 本周新增` : '本周无新增'}
          </div>
        </Card>
        <Card className="dashboard-kpi dashboard-kpi--green">
          <div className="dashboard-kpi__label">候选人总数</div>
          <div className="dashboard-kpi__value">{funnel.total_candidates ?? 0}</div>
          <div className={`dashboard-kpi__trend ${summary.weekly_interviews ? 'dashboard-kpi__trend--up' : 'dashboard-kpi__trend--neutral'}`}>
            {summary.weekly_interviews ? `↑ ${summary.weekly_interviews} 本周面试` : '本周无面试'}
          </div>
        </Card>
        <Card className="dashboard-kpi dashboard-kpi--purple">
          <div className="dashboard-kpi__label">面试进行中</div>
          <div className="dashboard-kpi__value">{summary.live_interviews ?? 0}</div>
          <div className="dashboard-kpi__trend dashboard-kpi__trend--neutral">
            <span className="dashboard-page__pulse" />
            实时进行中
          </div>
        </Card>
        <Card className="dashboard-kpi dashboard-kpi--amber">
          <div className="dashboard-kpi__label">录用转化率</div>
          <div className="dashboard-kpi__value">{conversion}%</div>
          <div className={`dashboard-kpi__trend ${summary.weekly_interview_passed ? 'dashboard-kpi__trend--up' : 'dashboard-kpi__trend--neutral'}`}>
            {summary.weekly_interview_passed ? `↑ ${summary.weekly_interview_passed} 本周录用` : '本周无录用'}
          </div>
        </Card>
        <Card className="dashboard-kpi dashboard-kpi--cyan">
          <div className="dashboard-kpi__label">平均招聘周期</div>
          <div className="dashboard-kpi__value">{summary.avg_hire_cycle ?? 0}<span className="dashboard-kpi__unit">天</span></div>
          <div className="dashboard-kpi__trend dashboard-kpi__trend--neutral">
            从投递到录用
          </div>
        </Card>
      </div>

      <div className="dashboard-page__scroll">
        <Row gutter={[16, 16]} align="stretch" style={{ marginBottom: 20 }}>
        <Col xs={24} lg={14}>
          <Card
            title="招聘活动趋势"
            className="agent-card"
            extra={
              <div className="dashboard-trend-tabs">
                <button
                  className={`dashboard-trend-tab${trendDays === 7 ? ' active' : ''}`}
                  onClick={() => setTrendDays(7)}
                >
                  近 7 天
                </button>
                <button
                  className={`dashboard-trend-tab${trendDays === 30 ? ' active' : ''}`}
                  onClick={() => setTrendDays(30)}
                >
                  近 30 天
                </button>
              </div>
            }
          >
            <EChart option={trendOption(data, trendDays)} height={340} />
          </Card>
        </Col>
        <Col xs={24} lg={10}>
          <Card
            className="agent-card"
            title="招聘漏斗"
          >
            <div className="dashboard-funnel">
              {[
                { label: '投递', n: applied, w: 100 },
                {
                  label: '筛选通过',
                  n: screened,
                  w: applied > 0 ? Math.round((screened / applied) * 100) : 0,
                },
                {
                  label: '面试',
                  n: interviewed,
                  w: applied > 0 ? Math.round((interviewed / applied) * 100) : 0,
                },
                {
                  label: '录用',
                  n: interviewPassed,
                  w: applied > 0 ? Math.round((interviewPassed / applied) * 100) : 0,
                },
              ].map((row, idx) => {
                const conv = idx === 0
                  ? <span style={{ color: '#B7BDD1' }}>基准 <span className="dashboard-funnel__conv-num" style={{ color: '#B7BDD1' }}>100%</span></span>
                  : <span>转化 <span className="dashboard-funnel__conv-num">{applied > 0 ? Math.round((row.n / applied) * 100) : 0}%</span></span>;
                return (
                  <div className="dashboard-funnel__row" key={row.label}>
                    <div className="dashboard-funnel__label">{row.label}</div>
                    <div className="dashboard-funnel__track">
                      <div className="dashboard-funnel__bar" style={{ width: `${row.w}%`, minWidth: row.n > 0 ? 88 : 44 }}>
                        <span>{row.n.toLocaleString()}</span><span>人</span>
                      </div>
                    </div>
                    <div className="dashboard-funnel__conv">{conv}</div>
                  </div>
                );
              })}
            </div>
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} className="dashboard-bottom-row">
        <Col xs={24} lg={14}>
          <Card title="岗位一览" className="agent-card dashboard-role-overview">
            {roleOverviewQuery.isPending ? (
              <div className="dashboard-role-overview__loading"><Spin /></div>
            ) : roleOverviewQuery.isError ? (
              <Alert type="error" showIcon message="加载失败" />
            ) : roleOverviewQuery.data?.length ? (
              <DataTable<RoleOverviewItem>
                tableId="dashboard-role-overview"
                columns={roleOverviewColumns(
                  selectedKey,
                  setSelectedRoleKey,
                )}
                dataSource={sortedRoleRows.slice(0, 12)}
                rowKey={(item) => `${item.role}:${item.type_code}`}
                pagination={false}
                compact
                showResultCount={false}
                onRow={(item) => ({
                  onClick: () => setSelectedRoleKey(`${item.role}:${item.type_code}`),
                  className: selectedKey === `${item.role}:${item.type_code}` ? 'dashboard-role-overview__row--selected' : '',
                  style: { cursor: 'pointer' },
                })}
              />
            ) : (
              <Empty description="暂无符合条件的岗位" />
            )}
          </Card>
        </Col>
        <Col xs={24} lg={10}>
          <div className="dashboard-right-section">
            {/* <div className="dashboard-right-section__header">
              <span className="dashboard-right-section__label">
                前
                <Select
                  value={topLimit}
                  onChange={(value) => setTopLimit(value as 3 | 4 | 5)}
                  options={[{ value: 3, label: "3" }, { value: 4, label: "4" }, { value: 5, label: "5" }]}
                  variant="borderless"
                  size="small"
                  popupMatchSelectWidth={false}
                  style={{ width: 44 }}
                />
                名候选人评分
              </span>
            </div> */}
            <Row gutter={[0, 16]}>
              <Col span={24}>
                <CandidateRadarSection role={selectedRole} query={rankingQuery} />
              </Col>
              <Col span={24}>
                <CandidateRankingSection
                  role={selectedRole}
                  query={rankingQuery}
                  onOpenDetail={() => setDetailOpen(true)}
                />
              </Col>
            </Row>
          </div>
        </Col>
      </Row>
      </div>
      <Modal
        title={`全部候选人评分—${selectedRole?.role ?? "岗位"}`}
        open={detailOpen}
        footer={null}
        width={900}
        onCancel={() => setDetailOpen(false)}
      >
        {detailQuery.isPending ? <Spin /> : detailQuery.isError ? <Alert type="error" showIcon message="加载失败" /> : (
          <CandidateRankingTable candidates={detailQuery.data?.candidates ?? []} />
        )}
      </Modal>
    </>
  );
}

function roleOverviewColumns(
  selectedKey: string,
  setSelectedRoleKey: (key: string) => void,
): DataTableInputColumn<RoleOverviewItem>[] {
  return [
    {
      title: "岗位名称",
      dataIndex: "role",
      key: "role",
      role: "identity",
      render: (value: string, item: RoleOverviewItem) => (
        <Button
          type="link"
          style={{ padding: 0, fontWeight: 600 }}
          onClick={(e) => {
            e.stopPropagation();
            setSelectedRoleKey(`${item.role}:${item.type_code}`);
          }}
        >
          {value}
        </Button>
      ),
    },
    {
      title: "类型",
      dataIndex: "type_label",
      key: "type_label",
      render: (value: string, item: RoleOverviewItem) => (
        <span className={`dashboard-role-overview__type dashboard-role-overview__type--${item.type_code}`}>
          {value}
        </span>
      ),
    },
    {
      title: "候选人数",
      dataIndex: "candidate_count",
      key: "candidate_count",
    },
    {
      title: "通过率",
      dataIndex: "pass_rate",
      key: "pass_rate",
      render: (value: number) => `${Math.round(value * 100)}%`,
    },
    // TODO: pipeline 展开功能后续移至独立页面
    // {
    //   title: "操作",
    //   key: "actions",
    //   role: "actions",
    //   render: (_: unknown, item: RoleOverviewItem) => {
    //     const key = `${item.role}:${item.type_code}`;
    //     return (
    //       <Button
    //         type="link"
    //         onClick={(e) => {
    //           e.stopPropagation();
    //           setExpandedRoles((current) => {
    //             const next = new Set(current);
    //             if (next.has(key)) next.delete(key); else next.add(key);
    //             return next;
    //           });
    //         }}
    //       >
    //         {expandedRoles.has(key) ? "收起" : "展开"}
    //       </Button>
    //     );
    //   },
    // },
  ];
}

function CandidateRadarSection({
  role,
  query,
}: {
  role?: RoleOverviewItem;
  query: ReturnType<typeof useCandidateRankingQuery>;
}) {
  const candidates = query.data?.candidates ?? [];
  const radarCandidates = completeRadarCandidates(candidates);

  return (
    <Card
      title={role ? `五维评估雷达图—${role.role}` : "五维评估雷达图"}
      className="agent-card dashboard-candidate-radar"
      styles={{ body: { paddingTop: 1, paddingBottom: 0 } }}
    >
      {query.isLoading ? <div className="dashboard-role-overview__loading"><Spin /></div> : query.isError ? (
        <Alert type="error" showIcon message="加载失败" />
      ) : !candidates.length ? (
        <Empty description="暂无候选人评分" />
      ) : !radarCandidates.length ? (
        <Empty description="暂无完整评估数据" />
      ) : (
        <EChart option={candidateRadarOption(radarCandidates)} height={320} />
      )}
    </Card>
  );
}

function CandidateRankingSection({
  role,
  query,
  onOpenDetail,
}: {
  role?: RoleOverviewItem;
  query: ReturnType<typeof useCandidateRankingQuery>;
  onOpenDetail: () => void;
}) {
  return (
    <Card
      title={role ? `候选人评分排名—${role.role}` : "候选人评分排名"}
      className="agent-card dashboard-candidate-ranking"
      extra={(
        <Button type="link" onClick={onOpenDetail} disabled={!role || !query.data?.total}>详情</Button>
      )}
    >
      {query.isLoading ? <div className="dashboard-role-overview__loading"><Spin /></div> : query.isError ? (
        <Alert type="error" showIcon message="加载失败" />
      ) : query.data?.candidates.length ? (
        <CandidateRankingCards candidates={query.data.candidates} />
      ) : <Empty description="暂无候选人评分" />}
    </Card>
  );
}

function candidateScoreSource(candidate: CandidateRankingCandidate) {
  const isSmallReview = candidate.score_source === "small_review";
  return {
    color: isSmallReview ? "purple" : "blue",
    label: isSmallReview ? "正式小评分" : "初筛匹配分",
  };
}

function CandidateRankingCards({ candidates }: { candidates: CandidateRankingCandidate[] }) {
  const avatarColors = ["#4F46E5", "#0EA5A6", "#059669", "#D97706", "#DC2626"];
  const [expandedSkills, setExpandedSkills] = useState<Set<string>>(new Set());

  return (
    <div className="dashboard-candidate-cards">
      {candidates.map((candidate, index) => (
        <div
          key={candidate.candidate_id}
          className="dashboard-candidate-card"
        >
          <div className="dashboard-candidate-card__avatar" style={{ backgroundColor: avatarColors[index % avatarColors.length] }}>
            {candidate.name?.charAt(0) || "?"}
          </div>
          <div className="dashboard-candidate-card__info">
            <div className="dashboard-candidate-card__name">{candidate.name}</div>
            <div className="dashboard-candidate-card__meta">
              {candidate.skills?.length ? (
                expandedSkills.has(candidate.candidate_id) ? (
                  <span className="dashboard-candidate-card__keywords">
                    {candidate.skills.map((skill) => (
                      <Tag key={skill} color="blue" className="dashboard-candidate-card__keyword">{skill}</Tag>
                    ))}
                    <Button
                      type="link"
                      size="small"
                      className="dashboard-candidate-card__collapse-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setExpandedSkills((prev) => {
                          const next = new Set(prev);
                          next.delete(candidate.candidate_id);
                          return next;
                        });
                      }}
                    >
                      收起
                    </Button>
                  </span>
                ) : (
                  <Tag
                    className="dashboard-candidate-card__keyword-toggle"
                    onClick={(e) => {
                      e.stopPropagation();
                      setExpandedSkills((prev) => {
                        const next = new Set(prev);
                        next.add(candidate.candidate_id);
                        return next;
                      });
                    }}
                  >
                    {candidate.name}的技能
                  </Tag>
                )
              ) : "—"}
              <span className="dashboard-candidate-card__years"> · {candidate.years_experience || 0}年</span>
            </div>
          </div>
          <div className="dashboard-candidate-card__score-block">
            <div className="dashboard-candidate-card__score">{candidate.score}</div>
            <Tag color={candidateScoreSource(candidate).color} className="dashboard-candidate-card__score-source">
              {candidateScoreSource(candidate).label}
            </Tag>
          </div>
        </div>
      ))}
    </div>
  );
}

function CandidateRankingTable({ candidates, onDetail }: { candidates: CandidateRankingCandidate[]; onDetail?: () => void }) {
  return (
    <Table<CandidateRankingCandidate>
      rowKey="candidate_id"
      pagination={false}
      dataSource={candidates}
      scroll={{ x: 620 }}
      columns={[
        { title: "姓名", dataIndex: "name", key: "name", render: (value: string) => <Typography.Text strong>{value}</Typography.Text> },
        { title: "技能", dataIndex: "skills", key: "skills", render: (skills?: string[]) => <span className="dashboard-candidate-ranking__keywords">{skills?.join("、") || "—"}</span> },
        { title: "工作经验", dataIndex: "years_experience", key: "years_experience", render: (value: number | string) => `${value || 0}年` },
        {
          title: "评分",
          dataIndex: "score",
          key: "score",
          render: (value: number, candidate: CandidateRankingCandidate) => {
            const source = candidateScoreSource(candidate);
            return (
              <Space direction="vertical" size={2}>
                <b className="dashboard-candidate-ranking__score">{value}</b>
                <Tag color={source.color} className="dashboard-candidate-ranking__score-source">{source.label}</Tag>
              </Space>
            );
          },
        },
        ...(onDetail ? [{ title: "详情", key: "detail", render: () => <Button type="link" onClick={onDetail}>查看详情</Button> }] : []),
      ]}
    />
  );
}