import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { MemoryRouter, useLocation, useSearchParams } from 'react-router-dom';

import { AuthProvider } from '../auth/AuthContext';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { StudioPage } from './StudioPage';

afterEach(cleanup);
afterEach(() => {
  vi.unstubAllGlobals();
  vi.stubGlobal(
    'ResizeObserver',
    class ResizeObserverMock {
      observe() {}

      unobserve() {}

      disconnect() {}
    },
  );
});

beforeEach(() => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => [],
    }),
  );
});

function renderStudio(initialEntry = '/studio', withLocationProbe = false, withPathProbe = false) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntdApp>
          <AuthProvider>
            <StudioPage />
          </AuthProvider>
          {withLocationProbe && <LocationProbe />}
          {withPathProbe && <PathProbe />}
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

function PathProbe() {
  const location = useLocation();

  return <output data-testid="location-path">{location.pathname}</output>;
}

function LocationProbe() {
  const [searchParams] = useSearchParams();

  return <output data-testid="location-search">{searchParams.toString()}</output>;
}

function createPipelineFixtures(count: number) {
  return Array.from({ length: count }, (_, index) => {
    const sequence = index + 1;

    return {
      id: `pipeline-${sequence}`,
      role: `岗位 ${String(sequence).padStart(2, '0')}`,
      status: 'pending',
      candidate_count: sequence,
      created_at: `2026-08-${String(sequence).padStart(2, '0')}T00:00:00Z`,
    };
  });
}

describe('StudioPage', () => {
  it('renders the recruitment workspace shell', () => {
    renderStudio();

    expect(screen.getByRole('heading', { name: '招聘岗位管理' })).toBeInTheDocument();
    expect(screen.getByText('智能招聘平台')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '创建岗位' })).toBeInTheDocument();
    expect(screen.getByPlaceholderText('搜索岗位名称或HR姓名')).toBeInTheDocument();
  });

  it('renders company branding from the company configuration', async () => {
    const logoUrl = 'https://cdn.example.com/company-logo.png?signature=abc';
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input) => {
        if (String(input) === '/api/company-config') {
          return new Response(
            JSON.stringify({ company_name: '示例科技', company_logo: logoUrl }),
            { status: 200 },
          );
        }

        return new Response(JSON.stringify([]), { status: 200 });
      }),
    );

    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));

    const dialog = await screen.findByRole('dialog', { name: '创建岗位' });
    await waitFor(() => {
      expect(within(dialog).getByText('示例科技')).toBeInTheDocument();
      expect(dialog.querySelector('.studio-create-modal__company img')).toHaveAttribute('src', logoUrl);
    });
  });

  it('hides the minimal pipeline preset in the create dialog', () => {
    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));

    const dialog = screen.getByRole('dialog', { name: '创建岗位' });
    expect(within(dialog).queryByText('⚡极简')).not.toBeInTheDocument();
  });

  it('keeps the Studio page and create dialog aligned with the legacy workspace', async () => {
    renderStudio();

    expect(document.querySelector('.hr-app-shell--studio')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));

    const dialog = screen.getByRole('dialog', { name: '创建岗位' });
    expect(within(dialog).getByText('锅圈食汇')).toBeInTheDocument();
    expect(within(dialog).getByText('输入新岗位，或从常用岗位中选择')).toBeInTheDocument();
    expect(within(dialog).getByRole('button', { name: '锅圈小炒事业部总经理' })).toBeInTheDocument();
    fireEvent.mouseDown(within(dialog).getByRole('combobox', { name: '岗位类型' }));
    expect(await screen.findByTitle('技术岗')).toBeInTheDocument();
    expect(within(dialog).getByText('流程预览')).toBeInTheDocument();
  }, 10_000);

  it('uses lightweight layout updates for create form fields', () => {
    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));

    const modal = document.querySelector('.studio-create-modal-root .ant-modal');
    expect(modal).toBeInTheDocument();
    expect(document.querySelector('.studio-create-modal-root .ant-modal-mask')).toBeInTheDocument();
    const hintsInput = within(modal as HTMLElement).getByPlaceholderText(
      '如：需要零售门店经验，能接受轮班，能接受早班，住在闵行区优先',
    );
    expect(hintsInput).toHaveAttribute('rows', '3');
  });

  it('renders the initial statistics and empty pipeline state', async () => {
    renderStudio();

    expect(screen.getByText('岗位总数')).toBeInTheDocument();
    expect(screen.getByText('进行中')).toBeInTheDocument();
    expect(screen.getByText('已完成')).toBeInTheDocument();
    expect(screen.getByText('完成率')).toBeInTheDocument();
    expect(await screen.findByText('暂无岗位')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '立即创建岗位' })).toBeInTheDocument();
  });

  it('shows an explicit empty HR filter state for tenant administrators', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input) => {
        if (String(input) === '/api/pipelines/hr-users') {
          return new Response(
            JSON.stringify({ users: [], can_select_all: true }),
            { status: 200 },
          );
        }

        return new Response(JSON.stringify([]), { status: 200 });
      }),
    );

    renderStudio();

    const hrSelect = await screen.findByRole('combobox', { name: '筛选HR' });
    expect(hrSelect).toBeDisabled();
    await waitFor(() => {
      expect(hrSelect.closest('.studio-page__hr-filter')).toHaveAttribute('data-state', 'empty');
    });
  });

  it('keeps the filter area understandable when HR options fail to load', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input) => {
        if (String(input) === '/api/pipelines/hr-users') {
          return new Response(JSON.stringify({ detail: 'HR service unavailable' }), { status: 500 });
        }

        return new Response(JSON.stringify([]), { status: 200 });
      }),
    );

    renderStudio();

    expect(await screen.findByText('HR 筛选暂不可用')).toBeInTheDocument();
  });

  it('renders server pipelines and derived statistics', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [
          {
            id: 'pipeline-1',
            role: 'Java 后端工程师',
            status: 'completed',
            candidate_count: 8,
            stages: [{ stage_id: 'jd_write', status: 'done' }],
          },
        ],
      }),
    );

    renderStudio();

    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    expect(screen.getAllByText('1').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('100%').length).toBeGreaterThanOrEqual(1);
  });

  it('restores the filter, sort, and page from the URL', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => createPipelineFixtures(13),
      }),
    );

    renderStudio('/studio?q=岗位&sort=role_desc&page=2', true);

    expect(await screen.findByDisplayValue('岗位')).toBeInTheDocument();
    expect(await screen.findByText('岗位 01')).toBeInTheDocument();
    expect(screen.queryByText('岗位 02')).not.toBeInTheDocument();
    expect(screen.getByText('第 13-13 条，共 13 条')).toBeInTheDocument();
  });

  it('filters pipelines by the selected HR account for tenant administrators', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input) => {
        const url = String(input);
        if (url === '/api/pipelines/hr-users') {
          return new Response(
            JSON.stringify({
              users: [{ id: 'user_zhang', username: 'zhangsan', display_name: '张三' }],
              current_user_id: 'user_admin',
              can_select_all: true,
            }),
            { status: 200 },
          );
        }
        if (url.includes('owner_user_id=user_zhang')) {
          return new Response(
            JSON.stringify([
              {
                id: 'pipeline-zhang',
                role: '张三的岗位',
                status: 'pending',
                candidate_count: 0,
                owner_user_id: 'user_zhang',
                hr_name: '张三',
              },
            ]),
            { status: 200 },
          );
        }
        return new Response(JSON.stringify([]), { status: 200 });
      }),
    );

    renderStudio('/studio', true);

    const hrSelect = await screen.findByRole('combobox', { name: '筛选HR' });
    fireEvent.mouseDown(hrSelect);
    fireEvent.click(await screen.findByTitle('张三'));

    expect(await screen.findByText('张三的岗位')).toBeInTheDocument();
    expect(screen.getByText('HR 张三')).toBeInTheDocument();

    await waitFor(() => {
      const params = new URLSearchParams(screen.getByTestId('location-search').textContent ?? '');
      expect(params.get('owner_user_id')).toBe('user_zhang');
    });
  });

  it('hides the HR filter select for ordinary HR users', () => {
    renderStudio();

    expect(screen.queryByRole('combobox', { name: '筛选HR' })).not.toBeInTheDocument();
  });

  it('writes pagination changes into the URL while retaining filter and sort', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => createPipelineFixtures(13),
      }),
    );

    renderStudio('/studio?q=岗位&sort=role_asc', true);

    expect(await screen.findByText('岗位 01')).toBeInTheDocument();
    fireEvent.click(screen.getByTitle('Next Page'));

    await waitFor(() => {
      const params = new URLSearchParams(screen.getByTestId('location-search').textContent ?? '');
      expect(params.get('q')).toBe('岗位');
      expect(params.get('sort')).toBe('role_asc');
      expect(params.get('page')).toBe('2');
    });
    expect(screen.getByText('岗位 13')).toBeInTheDocument();
  });

  it('opens the pipeline detail page when a pipeline item is clicked', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [
          { id: 'pipeline-1', role: 'Java 后端工程师', status: 'completed', candidate_count: 8 },
        ],
      }),
    );

    renderStudio('/studio', false, true);

    fireEvent.click(await screen.findByText('Java 后端工程师'));

    await waitFor(() => {
      expect(screen.getByTestId('location-path')).toHaveTextContent('/pipelines/pipeline-1');
    });
  });

  it('opens the migrated mass dashboard from the sidebar', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input) => {
        if (String(input).includes('/api/auth/me')) {
          return new Response(JSON.stringify({ username: 'hr', permissions: ['interview:read'] }), { status: 200 });
        }
        return new Response(JSON.stringify([]), { status: 200 });
      }),
    );
    renderStudio('/studio', false, true);

    const interviewMenuItem = await screen.findByRole('menuitem', { name: /面试中心/ });
    expect(interviewMenuItem).not.toHaveAttribute('aria-disabled', 'true');

    fireEvent.click(interviewMenuItem);

    expect(screen.getByTestId('location-path')).toHaveTextContent('/mass-dashboard');
  });

  it('stays on the list when the checkbox or delete button is clicked', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => [
          { id: 'pipeline-1', role: 'Java 后端工程师', status: 'completed', candidate_count: 8 },
        ],
      }),
    );

    renderStudio('/studio', false, true);

    fireEvent.click(await screen.findByRole('checkbox', { name: '选择Java 后端工程师' }));
    expect(screen.getByTestId('location-path')).toHaveTextContent('/studio');

    fireEvent.click(screen.getByRole('button', { name: '删除Java 后端工程师' }));
    expect(screen.getByTestId('location-path')).toHaveTextContent('/studio');
  });

  it.each([
    [401, '登录状态已失效，请重新登录。'],
    [403, '当前账号无权限查看岗位。'],
    [422, '请求参数不合法，请刷新后重试。'],
    [500, '服务暂时不可用，请稍后重试。'],
  ])('shows a readable feedback for a %s list request', async (status, message) => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({ ok: false, status }),
    );

    renderStudio();

    expect(await screen.findByText(message)).toBeInTheDocument();
  });

  it('validates and creates a pipeline from the create dialog', async () => {
    const fetchMock = vi.mocked(fetch);
    let listResponse: unknown[] = [];
    fetchMock.mockImplementation(async (input, init) => {
      if (String(input) === '/api/pipelines' && init?.method === 'POST') {
        listResponse = [
          {
            id: 'pipeline-2',
            role: 'Java 后端工程师',
            status: 'pending',
          },
        ];
        return new Response(JSON.stringify({ pipeline_id: 'pipeline-2', status: 'created' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (String(input).includes('/api/pipelines/pipeline-2/auto-run') && init?.method === 'POST') {
        return new Response(JSON.stringify({ status: 'started' }), { status: 200 });
      }

      return new Response(JSON.stringify(listResponse), { status: 200 });
    });

    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));

    expect(screen.getByRole('dialog', { name: '创建岗位' })).toBeInTheDocument();
    const dialog = screen.getByRole('dialog', { name: '创建岗位' });
    fireEvent.click(within(dialog).getByRole('button', { name: '创建并启动' }));
    expect(await within(dialog).findByText('请输入岗位名称')).toBeInTheDocument();

    fireEvent.change(within(dialog).getByLabelText(/岗位名称/), {
      target: { value: 'Java 后端工程师' },
    });
    fireEvent.change(within(dialog).getByLabelText(/工作地点/), {
      target: { value: '杭州' },
    });
    const jobTypeSelect = within(dialog).getByRole('combobox', { name: '岗位类型' });
    fireEvent.mouseDown(jobTypeSelect);
    fireEvent.click(await screen.findByTitle('销售岗'));
    fireEvent.click(within(dialog).getByRole('button', { name: '创建并启动' }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/pipelines',
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({
            role: 'Java 后端工程师',
            hints: '工作地点：杭州。',
            location: '杭州',
            type: 'sales',
            agents: ['xiao_wen', 'xiao_xun', 'xiao_shai', 'xiao_mian'],
            enabled_agents: ['xiao_wen', 'xiao_xun', 'xiao_shai', 'xiao_mian'],
          }),
        }),
      );
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/pipelines/pipeline-2/auto-run',
        expect.objectContaining({
          method: 'POST',
          credentials: 'include',
          signal: expect.any(AbortSignal),
        }),
      );
    });
    expect(await screen.findByText('岗位创建成功')).toBeInTheDocument();
    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
  }, 20_000);

  it('keeps the create dialog open and shows an error inside it when creation fails', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockImplementation(async (_input, init) => {
      if (init?.method === 'POST') {
        return new Response(null, { status: 500 });
      }

      return new Response(JSON.stringify([]), { status: 200 });
    });

    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '创建岗位' }));
    const dialog = screen.getByRole('dialog', { name: '创建岗位' });
    fireEvent.change(within(dialog).getByLabelText(/岗位名称/), {
      target: { value: 'Java 后端工程师' },
    });
    const jobTypeSelect = within(dialog).getByRole('combobox', { name: '岗位类型' });
    fireEvent.mouseDown(jobTypeSelect);
    fireEvent.click(await screen.findByTitle('技术岗'));
    fireEvent.click(screen.getByRole('button', { name: '创建并启动' }));

    await waitFor(() => {
      expect(within(dialog).getByText('岗位创建失败')).toBeInTheDocument();
    }, { timeout: 5000 });
    const retryButton = within(dialog).getByRole('button', { name: /重\s*试/ });
    expect(retryButton).toBeInTheDocument();
    fireEvent.click(retryButton);
    await waitFor(() => {
      expect(
        fetchMock.mock.calls.filter(([, init]) => init?.method === 'POST'),
      ).toHaveLength(2);
    });
  }, 20_000);

  it('confirms and deletes a pipeline', async () => {
    const fetchMock = vi.mocked(fetch);
    let listResponse: unknown[] = [
      {
        id: 'pipeline-1',
        role: 'Java 后端工程师',
        status: 'completed',
        candidate_count: 8,
      },
    ];
    fetchMock.mockImplementation(async (_input, init) => {
      if (init?.method === 'DELETE') {
        listResponse = [];
        return new Response(JSON.stringify({ status: 'deleted' }), { status: 200 });
      }

      return new Response(JSON.stringify(listResponse), { status: 200 });
    });

    renderStudio();
    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '删除Java 后端工程师' }));

    expect(screen.getByRole('dialog', { name: '删除岗位' })).toBeInTheDocument();
    expect(screen.getByText('确定删除此岗位？此操作不可恢复。')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /^删除$/ }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/pipelines/pipeline-1',
        expect.objectContaining({
          method: 'DELETE',
          credentials: 'include',
          signal: expect.any(AbortSignal),
        }),
      );
    });
    expect(await screen.findByText('岗位已删除')).toBeInTheDocument();
    expect(await screen.findByText('暂无岗位')).toBeInTheDocument();
  });

  it('selects pipelines and prevents duplicate batch deletion', async () => {
    const fetchMock = vi.mocked(fetch);
    let listResponse: unknown[] = [
      { id: 'pipeline-1', role: 'Java 后端工程师', status: 'completed' },
      { id: 'pipeline-2', role: '前端工程师', status: 'pending' },
    ];
    fetchMock.mockImplementation(async (_input, init) => {
      if (init?.method === 'DELETE') {
        listResponse = [{ id: 'pipeline-2', role: '前端工程师', status: 'pending' }];
        return new Response(
          JSON.stringify({ deleted: ['pipeline-1'], failed: ['pipeline-2'], count: 1 }),
          { status: 200 },
        );
      }

      return new Response(JSON.stringify(listResponse), { status: 200 });
    });

    renderStudio();
    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('checkbox', { name: '选择Java 后端工程师' }));
    fireEvent.click(screen.getByRole('checkbox', { name: '选择前端工程师' }));
    expect(screen.getByText(/已选 2 条/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '批量删除' }));
    const dialog = await screen.findByRole('dialog', { name: '批量删除岗位' });
    expect(within(dialog).getByText('确定删除选中的 2 条岗位？此操作不可恢复。')).toBeInTheDocument();
    const confirmButton = within(dialog).getByRole('button', { name: '确认删除' });
    fireEvent.click(confirmButton);
    fireEvent.click(confirmButton);

    await waitFor(() => {
      expect(
        fetchMock.mock.calls.filter(([, init]) => init?.method === 'DELETE'),
      ).toHaveLength(1);
    });
    expect(await screen.findByText(/部分岗位删除失败/)).toBeInTheDocument();
  }, 10_000);

  it('loads and saves company configuration through the config panel', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockImplementation(async (input, init) => {
      if (String(input) === '/api/company-config' && init?.method === 'POST') {
        return new Response(JSON.stringify({ company_name: '新公司' }), { status: 200 });
      }
      if (String(input) === '/api/company-config') {
        return new Response(
          JSON.stringify({ company_name: '锅圈食汇', default_benefits: ['五险一金'] }),
          { status: 200 },
        );
      }

      return new Response(JSON.stringify([]), { status: 200 });
    });

    renderStudio();
    fireEvent.click(screen.getByRole('button', { name: '公司配置' }));
    const dialog = await screen.findByRole('dialog', { name: '公司配置' });
    expect(dialog).toHaveClass('studio-company-config-modal');
    expect(await within(dialog).findByLabelText('公司名称')).toBeInTheDocument();
    expect(within(dialog).queryByLabelText('品牌主色')).not.toBeInTheDocument();
    expect(dialog.querySelector('.studio-company-config-form__asset-row')).toBeInTheDocument();
    expect(within(dialog).queryByLabelText('品牌辅色')).not.toBeInTheDocument();
    expect(within(dialog).queryByLabelText('海报模板')).not.toBeInTheDocument();
    expect(within(dialog).queryByText('海报底图（可选，留空使用品牌色背景）')).not.toBeInTheDocument();
    fireEvent.change(await within(dialog).findByLabelText('公司名称'), {
      target: { value: '新公司' },
    });
    fireEvent.click(within(dialog).getByRole('button', { name: '保存配置' }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/company-config',
        expect.objectContaining({
          method: 'POST',
          body: expect.stringContaining('新公司'),
        }),
      );
    });
    const companySaveCall = fetchMock.mock.calls.find(([, init]) => init?.method === 'POST');
    expect(String(companySaveCall?.[1]?.body)).not.toContain('poster_template');
    expect(String(companySaveCall?.[1]?.body)).not.toContain('poster_bg_image');
    expect(String(companySaveCall?.[1]?.body)).not.toContain('brand_color_secondary');
  }, 10_000);
});
