import {
  Alert,
  Button,
  Card,
  Drawer,
  Empty,
  Modal,
  Spin,
  Tag,
  Typography,
  message,
} from 'antd';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import { AgentTopbar } from '../components/AgentTopbar';
import { routePaths } from '../routes/route-paths';
import { fetchAgentPipeline, passAgentArtifact } from '../../features/agent-workbench/api';
import { ConversationPanel } from '../../features/conversations/ConversationPanel';
import type { ConversationLatestData } from '../../features/conversations/api';
import { MaterialPicker } from '../../features/xiao-hai/MaterialPicker';
import {
  approvePosterVersion,
  fetchPosterBootstrap,
  createPosterJob,
  cancelPosterJob,
  selectPosterVersion,
} from '../../features/xiao-hai/api';
import type { PosterFieldSet, PosterJob, PosterVersion } from '../../features/xiao-hai/api';
import { PosterGenerationProgress } from '../../features/xiao-hai/PosterGenerationProgress';
import { usePosterJobs, posterJobsKey } from '../../features/xiao-hai/usePosterJobs';
import { agentWorkspaceUrl } from '../../shared/agent-config';
import { getErrorMessage as errorMessage } from '../../shared/errors';

type CanvasOption = { id: string; label: string; width: number; height: number };
type GenerationOptions = { canvasId?: string; operation?: 'text' | 'visual' };

const CHANNEL_FALLBACKS: CanvasOption[] = [
  { id: 'long', label: '招聘长图', width: 1080, height: 2400 },
  { id: 'xhs', label: '小红书', width: 1242, height: 1660 },
  { id: 'moments', label: '朋友圈', width: 1080, height: 1440 },
  { id: 'dy_v', label: '抖音竖版', width: 1080, height: 1920 },
  { id: 'dy_h', label: '抖音横版', width: 1920, height: 1080 },
];

const XIAO_HAI_QUICK_PROMPTS = [
  { label: '换背景色', value: '把背景换成更醒目的品牌色' },
  { label: '调整标题', value: '把招聘标题改得更醒目，增强层级和对比度' },
  { label: '换一种风格', value: '保留当前文案和品牌元素，换一种更有吸引力的视觉风格' },
];

export function XiaoHaiPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline') ?? '';
  if (!pipelineId) {
    return <AgentStatus type="warning" message="缺少流水线参数" description="请从流水线详情页进入小海工作台。" />;
  }
  return <XiaoHaiWorkspace key={pipelineId} pipelineId={pipelineId} />;
}
function AgentStatus({ type, message: title, description }: { type: 'warning' | 'error'; message: string; description: string }) {
  return (
    <div className="agent-page agent-page--status">
      <Alert
        type={type}
        showIcon
        message={title}
        description={description}
        action={<Link to={routePaths.studio}><Button size="small">返回工作室</Button></Link>}
      />
    </div>
  );
}

function XiaoHaiWorkspace({ pipelineId }: { pipelineId: string }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const bootstrapQuery = useQuery({
    queryKey: ['xiao-hai', 'bootstrap', pipelineId],
    queryFn: () => fetchPosterBootstrap(pipelineId),
    retry: false,
  });
  const pipelineQuery = useQuery({
    queryKey: ['xiao-hai', 'pipeline', pipelineId],
    queryFn: () => fetchAgentPipeline(pipelineId),
    retry: false,
  });
  const jobsQuery = usePosterJobs(pipelineId);
  const activeJob = jobsQuery.activeJob;
  const displayedJob = activeJob ?? jobsQuery.jobs[0];
  const finishedJobRef = useRef('');
  const jobsInitializedRef = useRef(false);
  const submissionRef = useRef(false);
  const workspaceRevisionRef = useRef('');
  const [fields, setFields] = useState<PosterFieldSet>({});
  const [loadedVersionId, setLoadedVersionId] = useState('');
  const [canvasId, setCanvasId] = useState('xhs');
  const [instruction, setInstruction] = useState('');
  const [chatDraft, setChatDraft] = useState('');
  const [focusPreviewOpen, setFocusPreviewOpen] = useState(false);
  const [selectedBackgroundId, setSelectedBackgroundId] = useState('');
  const [selectedElementIds, setSelectedElementIds] = useState<string[]>([]);
  const [useDefaultMaterials, setUseDefaultMaterials] = useState(false);
  const [generationError, setGenerationError] = useState('');
  const [visualDirty, setVisualDirty] = useState(false);
  const [showAllVersions, setShowAllVersions] = useState(false);
  const bootstrap = bootstrapQuery.data;
  const versions = bootstrap?.versions ?? [];
  const selectedVersionId = bootstrap?.poster.selected_version_id ?? versions[0]?.id ?? '';
  const selectedVersion = versions.find((version) => version.id === selectedVersionId) ?? versions[0];

  const channels = useMemo(() => {
    const options = new Map(CHANNEL_FALLBACKS.map((item) => [item.id, item]));
    for (const item of bootstrap?.canvases ?? []) {
      const fallback = options.get(item.id);
      options.set(item.id, {
        id: item.id,
        label: item.label || fallback?.label || item.id,
        width: item.width || fallback?.width || 1080,
        height: item.height || fallback?.height || 1440,
      });
    }
    return [...options.values()];
  }, [bootstrap?.canvases]);
  const currentCanvas = channels.find((item) => item.id === canvasId) ?? channels[0];
  const defaultCanvasId = bootstrap?.default_canvas_id === 'long' ? 'xhs' : bootstrap?.default_canvas_id || 'xhs';
  const selectedCanvasId = selectedVersion?.canvas_id || defaultCanvasId;
  const selectedCanvas = channels.find((item) => item.id === selectedCanvasId) ?? currentCanvas;

  async function refresh(showNotice = false) {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'bootstrap', pipelineId] }),
      queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'pipeline', pipelineId] }),
      queryClient.invalidateQueries({ queryKey: ['pipeline-detail', pipelineId] }),
    ]);
    if (showNotice) message.success('海报工作区已更新');
  }

  const generateMutation = useMutation({
    mutationFn: (options: GenerationOptions = {}) => {
      const targetCanvasId = options.canvasId ?? canvasId;
      return createPosterJob(pipelineId, {
        client_request_id: crypto.randomUUID(),
        fields,
        canvas_id: targetCanvasId,
        base_version_id: selectedVersion?.id || undefined,
        instruction,
        operation: options.operation ?? 'visual',
        generation_mode: 'fresh',
        protected_field_keys: [],
        background_element_id: selectedBackgroundId || undefined,
        element_ids: selectedElementIds.length ? selectedElementIds : undefined,
        use_default_materials: useDefaultMaterials || undefined,
      });
    },
    retry: false,
    onMutate: () => setGenerationError(''),
    onSettled: () => { submissionRef.current = false; },
    onSuccess: async ({ job }) => {
      queryClient.setQueryData<{ jobs: typeof job[] }>(posterJobsKey(pipelineId), previous => ({
        jobs: [job, ...(previous?.jobs ?? []).filter(item => item.id !== job.id)],
      }));
      await queryClient.invalidateQueries({ queryKey: posterJobsKey(pipelineId) });
    },
    onError: (error) => {
      void queryClient.invalidateQueries({ queryKey: posterJobsKey(pipelineId) });
      const detail = errorMessage(error);
      const visibleMessage = detail.includes('curl') || detail.includes('502')
        ? '连接中断，正在恢复任务状态。请先确认已有任务的结果，再决定是否重试。'
        : detail;
      setGenerationError(visibleMessage);
    },
  });
  const selectMutation = useMutation({
    mutationFn: (versionId: string) => selectPosterVersion(pipelineId, versionId),
    onSuccess: () => refresh(),
  });
  const approveMutation = useMutation({
    mutationFn: (versionId: string) => approvePosterVersion(pipelineId, versionId),
    onSuccess: () => refresh(),
  });
  const passMutation = useMutation({
    mutationFn: () => passAgentArtifact(pipelineId, 'xiao_hai', {
      poster_version_id: selectedVersion?.id,
      image_url: selectedVersion ? posterImageUrl(pipelineId, selectedVersion) : '',
    }),
    onSuccess: (result) => {
      message.success(`已传递给${result.to_name || '下游'}`);
      if (result.to_agent) navigate(agentWorkspaceUrl(result.to_agent, pipelineId));
    },
  });
  const generating = generateMutation.isPending || Boolean(activeJob);
  const cancelMutation = useMutation({
    mutationFn: (id: string) => cancelPosterJob(pipelineId, id),
    onError: (error) => message.error(errorMessage(error)),
    onSettled: () => queryClient.invalidateQueries({ queryKey: posterJobsKey(pipelineId) }),
  });
  const busy = generating || jobsQuery.isPending || jobsQuery.disconnected || selectMutation.isPending || approveMutation.isPending || passMutation.isPending;

  useEffect(() => {
    const completed = jobsQuery.jobs.find(job => job.status === 'succeeded');
    if (!jobsInitializedRef.current) {
      if (jobsQuery.isPending) return;
      jobsInitializedRef.current = true;
      finishedJobRef.current = completed?.id ?? '';
      return;
    }
    if (!completed || finishedJobRef.current === completed.id) return;
    finishedJobRef.current = completed.id;
    setVisualDirty(false);
    setUseDefaultMaterials(false);
    void refresh();
  }, [jobsQuery.jobs]);

  useEffect(() => {
    if (activeJob) setGenerationError('');
  }, [activeJob?.id]);

  useEffect(() => {
    if (!bootstrap) return;
    const contextId = selectedVersion?.id || '__bootstrap__';
    if (loadedVersionId === contextId) return;
    const versionFields = selectedVersion?.fields ?? {};
    const nextCanvasId = selectedVersion?.canvas_id || defaultCanvasId;
    const renderData = (selectedVersion?.render_data ?? {}) as { background_element_id?: string; element_ids?: string[] };
    setFields({ ...(bootstrap.fields ?? {}), ...versionFields });
    setCanvasId(nextCanvasId);
    setInstruction(String(selectedVersion?.instruction ?? ''));
    setSelectedBackgroundId(String(renderData.background_element_id ?? ''));
    setSelectedElementIds(Array.isArray(renderData.element_ids) ? renderData.element_ids : []);
    setUseDefaultMaterials(false);
    setVisualDirty(false);
    setLoadedVersionId(contextId);
  }, [bootstrap, loadedVersionId, selectedVersion]);

  function handleConversationLatestData(data: ConversationLatestData) {
    if (Array.isArray(data.jobs)) {
      queryClient.setQueryData(posterJobsKey(pipelineId), { jobs: data.jobs as unknown as PosterJob[] });
    }
    const resource = (data.resources ?? []).find(item => item.key === 'poster_workspace');
    if (!resource) return;
    const workspace = resource.data as { versions?: PosterVersion[]; selected_version?: PosterVersion };
    const revision = JSON.stringify([workspace?.versions?.map(v => [v.id, v.status]), workspace?.selected_version?.id]);
    if (revision !== workspaceRevisionRef.current) {
      workspaceRevisionRef.current = revision;
      void refresh();
    }
  }

  if (bootstrapQuery.isPending) {
    return <div className="agent-page agent-page--status"><div className="app-loading"><Spin size="large" description="正在恢复当前海报" /></div></div>;
  }
  if (bootstrapQuery.isError || !bootstrap) {
    return <AgentStatus type="error" message="小海工作台加载失败" description={errorMessage(bootstrapQuery.error)} />;
  }

  const pipeline = pipelineQuery.data;
  const role = pipeline?.role || bootstrap.role;
  const approved = selectedVersion
    ? Boolean(selectedVersion.approved_at)
    : bootstrap.poster.approval_status === 'approved';
  const posterStatusLabel = !selectedVersion ? '待生成' : approved ? '海报已确认' : '待确认';
  const visibleVersions = [...versions]
    .filter((version) => showAllVersions || !canvasId || version.canvas_id === canvasId)
    .sort((left, right) => (right.version_number ?? 0) - (left.version_number ?? 0));
  function changeCanvas(nextCanvasId: string) {
    setCanvasId(nextCanvasId);
    setVisualDirty(nextCanvasId !== selectedCanvasId || visualDirty);
  }

  function startGeneration(options: GenerationOptions = {}) {
    if (generating || submissionRef.current || jobsQuery.isPending || jobsQuery.disconnected) return;
    submissionRef.current = true;
    setGenerationError('');
    generateMutation.mutate(options);
  }

  function chooseVersion(version: PosterVersion) {
    if (visualDirty) {
      Modal.confirm({
        title: '确认切换版本？',
        content: '当前有未应用的视觉修改，切换版本后这些修改会丢失，是否继续？',
        okText: '继续切换',
        cancelText: '取消',
        onOk: () => selectMutation.mutate(version.id),
      });
      return;
    }
    selectMutation.mutate(version.id);
  }

  const generationLabel = selectedVersion ? '生成新版本' : '生成海报';

  return (
    <div className="agent-page xun-app xhai-app agent-page--poster">
      <AgentTopbar
        pipelineId={pipelineId}
        mark="海"
        title={role}
        subtitle="小海 · 招聘海报"
        status={{ label: posterStatusLabel, tone: approved ? 'ok' : !selectedVersion ? 'neutral' : 'pending' }}
        primaryAction={{
          label: '传递给下游',
          loading: passMutation.isPending,
          disabled: !selectedVersion || !approved || busy,
          title: !selectedVersion ? '先生成并确认海报' : !approved ? '确认当前海报后再传递' : undefined,
          onClick: () => passMutation.mutate(),
        }}
      />
      <main className={`xhai-workspace xhai-workspace--right-chat${versions.length ? ' xhai-workspace--version-sidebar' : ''}`}>
        {versions.length ? (
          <aside className="xhai-version-rail" aria-label="版本导航">
            <VersionStrip
              layout="sidebar"
              pipelineId={pipelineId}
              versions={versions}
              visibleVersions={visibleVersions}
              selectedVersion={selectedVersion}
              channels={channels}
              currentCanvas={currentCanvas}
              showAllVersions={showAllVersions}
              busy={selectMutation.isPending}
              onToggleAll={() => setShowAllVersions((value) => !value)}
              onChoose={chooseVersion}
            />
          </aside>
        ) : null}
        <section className="xhai-studio-pane" aria-label="海报工作台">
          {generationError ? (
            <Alert
              type="error"
              showIcon
              message="海报生成失败"
              description={generationError}
              action={<Button size="small" type="primary" disabled={busy} onClick={() => startGeneration()}>从当前配置重试</Button>}
              closable
              onClose={() => setGenerationError('')}
            />
          ) : null}
          {displayedJob ? (
            <PosterGenerationProgress job={displayedJob} receivedAt={jobsQuery.dataUpdatedAt}
              disconnected={jobsQuery.disconnected} cancelling={cancelMutation.isPending}
              onCancel={() => cancelMutation.mutate(displayedJob.id)} />
          ) : generateMutation.isPending ? <div role="status">正在提交生成任务…</div> : null}
          {!displayedJob && jobsQuery.disconnected ? <Alert type="warning" showIcon title="连接中断，正在恢复状态" /> : null}
          {displayedJob?.status === 'failed' && !generationError ? (
            <Button disabled={busy} onClick={() => startGeneration()}>从当前配置重试</Button>
          ) : null}
          <div className="xhai-canvas-toolbar" aria-label="发布画幅">
            <div className="xhai-canvas-toolbar__heading">
              <Typography.Text strong>发布画幅</Typography.Text>
              <Typography.Text type="secondary">{currentCanvas?.label} · {currentCanvas?.width}×{currentCanvas?.height}</Typography.Text>
            </div>
            <CanvasPicker
              channels={channels}
              canvasId={canvasId}
              disabled={busy}
              onChange={changeCanvas}
            />
            <MaterialPicker
              compact
              canvasId={canvasId}
              selectedBackgroundId={selectedBackgroundId}
              selectedElementIds={selectedElementIds}
              disabled={busy}
              onBackgroundChange={(value) => {
                setSelectedBackgroundId(value);
                setUseDefaultMaterials(false);
                setVisualDirty(true);
              }}
              onElementIdsChange={(value) => {
                setSelectedElementIds(value);
                setUseDefaultMaterials(false);
                setVisualDirty(true);
              }}
              onUseDefault={() => {
                setUseDefaultMaterials(true);
                setVisualDirty(true);
              }}
            />
          </div>
          <section className="xhai-preview-pane" aria-label="海报预览">
            <Card className="agent-card xhai-card xhai-result-card">
              {selectedVersion ? (
                <PosterResult
                  pipelineId={pipelineId}
                  role={role}
                  version={selectedVersion}
                  versions={versions}
                  approved={approved}
                  busy={busy}
                  canvas={selectedCanvas}
                  generationLabel={generationLabel}
                  generating={generating}
                  onFocus={() => setFocusPreviewOpen(true)}
                  onGenerate={() => startGeneration({ operation: 'visual' })}
                  onApprove={() => approveMutation.mutate(selectedVersion.id)}
                />
              ) : (
                <EmptyPosterResult
                  role={role}
                  canvas={currentCanvas}
                  disabled={!bootstrap.jd_ready || busy}
                  generating={generating}
                  onGenerate={() => startGeneration({ operation: 'visual' })}
                  onGenerateCanvas={(targetCanvasId) => {
                    changeCanvas(targetCanvasId);
                    startGeneration({ canvasId: targetCanvasId, operation: 'visual' });
                  }}
                />
              )}
            </Card>
          </section>
        </section>

        <aside className="xhai-chat-pane" aria-label="与小海对话">
          <div className="xhai-pane-heading">
            <div>
              <Typography.Title level={4}>与小海对话</Typography.Title>
              <Typography.Text type="secondary">描述你想怎么改，海报会生成新版本</Typography.Text>
            </div>
            <span className="xhai-version-context">
              {selectedVersion ? `${shortVersionLabel(selectedVersion.id, versions)} · ${selectedCanvas?.label}` : '尚未生成海报'}
            </span>
          </div>
          <ConversationPanel
            composerDisabled={generating || jobsQuery.isPending || jobsQuery.disconnected}
            pipelineId={pipelineId}
            agentId="xiao_hai"
            avatar="海"
            placeholder={selectedVersion ? '告诉小海如何修改当前海报…' : '告诉小海你的海报设计要求…'}
            emptyHint="直接描述想修改的文案、背景、元素或画幅，小海会直接生成新版本。"
            quickPrompts={XIAO_HAI_QUICK_PROMPTS}
            baseVersionId={selectedVersion?.id ?? ''}
            backgroundElementId={selectedBackgroundId}
            elementIds={selectedElementIds}
            useDefaultMaterials={useDefaultMaterials}
            draft={chatDraft}
            onDraftChange={setChatDraft}
            onLatestData={handleConversationLatestData}
          />
        </aside>
      </main>

      <Drawer
        title={`${selectedVersion ? shortVersionLabel(selectedVersion.id, versions) : ''} · 专注预览`}
        placement="right"
        size="large"
        open={focusPreviewOpen}
        onClose={() => setFocusPreviewOpen(false)}
        extra={selectedVersion ? <Button onClick={() => downloadPoster(pipelineId, selectedVersion)}>下载</Button> : null}
      >
        {selectedVersion ? (
          <div className="xhai-focus-preview"><img src={posterImageUrl(pipelineId, selectedVersion)} alt={`${role} 招聘海报`} /></div>
        ) : <Empty description="还没有海报" />}
      </Drawer>
    </div>
  );
}

function CanvasPicker({
  channels,
  canvasId,
  disabled,
  onChange,
}: {
  channels: CanvasOption[];
  canvasId: string;
  disabled: boolean;
  onChange: (canvasId: string) => void;
}) {
  const byId = new Map(channels.map((item) => [item.id, item]));
  const options = [
    { id: 'xhs', label: '小红书', ratio: '3:4' },
    { id: 'moments', label: '朋友圈', ratio: '3:4' },
    { id: 'dy_v', label: '抖音竖版', ratio: '9:16' },
    { id: 'dy_h', label: '抖音横版', ratio: '16:9' },
  ];
  return (
    <div className="xhai-canvas-picker">
      {options.map((item) => {
        const active = canvasId === item.id;
        const canvas = byId.get(item.id);
        return (
          <button
            type="button"
            className={`xhai-canvas-option${active ? ' is-active' : ''}`}
            key={item.id}
            disabled={disabled}
            onClick={() => onChange(item.id)}
          >
            <span>{item.label}</span><small>{canvas ? `${canvas.width}×${canvas.height}` : item.ratio}</small>
          </button>
        );
      })}
    </div>
  );
}

function QuickStart({ role, disabled, onGenerate }: { role: string; disabled: boolean; onGenerate: (canvasId: string) => void }) {
  const cards = [
    { id: 'xhs', title: '生成小红书', detail: '小红书封面 · 3:4' },
    { id: 'moments', title: '生成朋友圈', detail: '朋友圈分享图 · 3:4' },
    { id: 'dy_v', title: '生成抖音竖版', detail: '短视频封面 · 9:16' },
    { id: 'dy_h', title: '生成抖音横版', detail: '横屏展示 · 16:9' },
  ];
  return (
    <div className="xhai-quick-start">
      <div><Typography.Title level={3}>为「{role}」制作招聘海报</Typography.Title><Typography.Text type="secondary">已从当前 JD 读取招聘内容，选择一个画幅开始。</Typography.Text></div>
      <div className="xhai-quick-start__grid">
        {cards.map((card) => (
          <button type="button" key={card.id} disabled={disabled} onClick={() => onGenerate(card.id)}>
            <strong>{card.title}</strong><span>{card.detail}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function EmptyPosterResult({
  role,
  canvas,
  disabled,
  generating,
  onGenerate,
  onGenerateCanvas,
}: {
  role: string;
  canvas?: CanvasOption;
  disabled: boolean;
  generating: boolean;
  onGenerate: () => void;
  onGenerateCanvas: (canvasId: string) => void;
}) {
  return (
    <div className="xhai-empty-poster">
      <div className="xhai-current-poster__toolbar" role="toolbar" aria-label="海报操作">
        <div className="xhai-current-poster__meta">
          <strong>待生成 · {canvas?.label}</strong>
          <span>{canvas?.width}×{canvas?.height}</span>
        </div>
        <div className="xhai-current-poster__status">
          <Tag>待生成</Tag>
        </div>
        <div className="xhai-current-poster__actions">
          <Button
            type="primary"
            size="middle"
            aria-label="生成新版本"
            loading={generating}
            disabled={disabled}
            onClick={onGenerate}
          >
            生成海报
          </Button>
        </div>
      </div>
      <QuickStart role={role} disabled={disabled} onGenerate={onGenerateCanvas} />
    </div>
  );
}

function PosterResult({
  pipelineId,
  role,
  version,
  versions,
  approved,
  busy,
  canvas,
  generationLabel,
  generating,
  onFocus,
  onGenerate,
  onApprove,
}: {
  pipelineId: string;
  role: string;
  version?: PosterVersion;
  versions: PosterVersion[];
  approved: boolean;
  busy: boolean;
  canvas?: CanvasOption;
  generationLabel: string;
  generating: boolean;
  onFocus: () => void;
  onGenerate: () => void;
  onApprove: () => void;
}) {
  if (!version) return null;
  return (
    <div className="xhai-current-poster">
      <div className="xhai-current-poster__toolbar" role="toolbar" aria-label="海报操作">
        <div className="xhai-current-poster__meta">
          <strong>{shortVersionLabel(version.id, versions)} · {canvas?.label}</strong>
          <span>{canvas?.width}×{canvas?.height}</span>
        </div>
        <div className="xhai-current-poster__status">
          {approved ? <Tag color="success">海报已确认</Tag> : <Tag>待确认</Tag>}
        </div>
        <div className="xhai-current-poster__actions" aria-label="海报工具">
          <div className="xhai-current-poster__action-group xhai-current-poster__action-group--secondary">
            <Button type="default" size="middle" className="xhai-action-button--preview" onClick={onFocus}>查看大图</Button>
            <Button type="default" size="middle" aria-label="下载" onClick={() => downloadPoster(pipelineId, version)}>下载</Button>
          </div>
          <div className="xhai-current-poster__action-group xhai-current-poster__action-group--primary">
            <Button type="default" size="middle" disabled={approved || busy} onClick={onApprove}>
              {approved ? '已确认' : '确认海报'}
            </Button>
            <Button type="default" size="middle" aria-label="生成新版本" loading={generating} disabled={busy} onClick={onGenerate}>
              {generationLabel}
            </Button>
          </div>
        </div>
      </div>
      <button type="button" className="xhai-poster-scroll xhai-poster-scroll--stage" onClick={onFocus} title="点击进入专注预览">
        <img src={posterImageUrl(pipelineId, version)} alt={`${role} 招聘海报`} decoding="async" />
      </button>
    </div>
  );
}

function VersionStrip({
  pipelineId,
  versions,
  visibleVersions,
  selectedVersion,
  channels,
  currentCanvas,
  layout = 'horizontal',
  showAllVersions,
  busy,
  onToggleAll,
  onChoose,
}: {
  pipelineId: string;
  versions: PosterVersion[];
  visibleVersions: PosterVersion[];
  selectedVersion?: PosterVersion;
  channels: CanvasOption[];
  currentCanvas?: CanvasOption;
  layout?: 'horizontal' | 'sidebar';
  showAllVersions: boolean;
  busy: boolean;
  onToggleAll: () => void;
  onChoose: (version: PosterVersion) => void;
}) {
  return (
    <section className={`xhai-version-strip${layout === 'sidebar' ? ' xhai-version-strip--sidebar' : ''}`} aria-label="海报版本">
      <div className="xhai-version-filter">
        <div><strong>版本记录</strong><span>{showAllVersions ? `全部画幅 · ${visibleVersions.length}` : `${currentCanvas?.label} · ${visibleVersions.length}`}</span></div>
        <Button type="link" size="small" onClick={onToggleAll}>
          {showAllVersions ? '仅当前画幅' : '查看全部'}
        </Button>
      </div>
      <div className="poster-version-list">
        {visibleVersions.length ? visibleVersions.map((version) => {
          const canvasLabel = channels.find((item) => item.id === version.canvas_id)?.label ?? version.canvas_id ?? '默认画幅';
          const versionLabel = shortVersionLabel(version.id, versions);
          const selected = version.id === selectedVersion?.id;
          return (
            <button
              type="button"
              className={`poster-version ${selected ? 'active' : ''}`}
              aria-label={`切换到 ${versionLabel} · ${canvasLabel}`}
              aria-current={selected ? 'true' : undefined}
              key={version.id}
              onClick={() => onChoose(version)}
              disabled={busy}
            >
              <img src={posterImageUrl(pipelineId, version)} alt="" loading="lazy" decoding="async" />
              <span>{versionLabel}</span>
              <small>{canvasLabel}</small>
              {version.approved_at ? <Tag color="success">已确认</Tag> : null}
            </button>
          );
        }) : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="当前画幅还没有版本" />}
      </div>
    </section>
  );
}

function posterImageUrl(pipelineId: string, version: PosterVersion) {
  const url = version.image_url || String(version.url ?? '');
  if (url) return url;
  return version.image_asset_id
    ? `/api/xiao-hai/${encodeURIComponent(pipelineId)}/assets/${encodeURIComponent(version.image_asset_id)}`
    : '';
}

function shortVersionLabel(versionId: string, versions: PosterVersion[]) {
  const index = versions.findIndex((version) => version.id === versionId);
  if (index < 0) return '当前版本';
  // Use the persisted number so filtering and the history limit cannot renumber a poster.
  return `V${versions[index].version_number ?? versions.length - index}`;
}

function downloadPoster(pipelineId: string, version: PosterVersion) {
  const url = posterImageUrl(pipelineId, version);
  if (!url) return;
  const link = document.createElement('a');
  link.href = url;
  link.download = `${version.id || 'poster'}.png`;
  link.click();
}
