import { describe, expect, it } from "vitest";

import type { MassRanking } from "../../features/mass-dashboard/api";
import {
  enrichMassRanking,
  filterRankingByDate,
  fiveDimensionScores,
  formatDateTime,
  splitMonitorRanking,
  statusColor,
  statusLabel,
  summarizeRankingStats,
} from "./MassDashboardPage.selectors";

const candidate = (overrides: Partial<MassRanking> = {}): MassRanking => ({
  candidate_id: "candidate-1",
  candidate_name: "候选人",
  status: "invited",
  ...overrides,
});

describe("MassDashboardPage selectors", () => {
  it("filters by completed, started, then created date and keeps undated records", () => {
    const records = [
      candidate({ candidate_id: "completed", completed_at: "2026-09-03T01:00:00Z", started_at: "2026-09-01" }),
      candidate({ candidate_id: "started", started_at: "2026-09-02T10:00:00Z", created_at: "2026-09-01" }),
      candidate({ candidate_id: "created", created_at: "2026-09-02T10:00:00Z" }),
      candidate({ candidate_id: "undated" }),
    ];

    expect(filterRankingByDate(records, "2026-09-02", "2026-09-03").map((item) => item.candidate_id)).toEqual([
      "completed",
      "started",
      "created",
      "undated",
    ]);
    expect(filterRankingByDate(records, "2026-09-03", "2026-09-03").map((item) => item.candidate_id)).toEqual([
      "completed",
      "undated",
    ]);
  });

  it("summarizes statuses and recorded videos without mutating the input", () => {
    const records = [
      candidate({ status: "invited" }),
      candidate({ candidate_id: "started", status: "started" }),
      candidate({ candidate_id: "answering", status: "streaming" }),
      candidate({ candidate_id: "completed", status: "completed", video_paths: ["a/q1.mp4"] }),
      candidate({ candidate_id: "evaluated", status: "evaluated" }),
      candidate({ candidate_id: "expired", status: "expired" }),
    ];

    expect(summarizeRankingStats(records)).toMatchObject({
      total: 6,
      invited: 1,
      started: 1,
      in_progress: 1,
      completed: 1,
      evaluated: 1,
      expired: 1,
      recorded: 1,
    });
  });

  it("enriches ranking scores from the assessment queue without mutating candidates", () => {
    const records = [
      candidate({
        candidate_id: "ready",
        total_score: 10,
        interview_score: 11,
        match_score: 12,
        recommendation: "consider",
      }),
      candidate({ candidate_id: "processing", total_score: 80, interview_score: 81, match_score: 82 }),
      candidate({ candidate_id: "untouched", total_score: 30 }),
    ];
    const originalRecords = structuredClone(records);
    const queue = {
      ready_for_decision: [
        {
          candidate_id: "ready",
          final_score: 91,
          overall_score: 81,
          score: 71,
          recommendation: "recommend",
        },
      ],
      incomplete: [
        {
          candidate_id: "processing",
          overall_score: 66,
          recommendation: "reject",
          step_results: {
            video: { scoring_status: "pending" },
          },
        },
      ],
    };

    const result = enrichMassRanking(records, queue);

    expect(result).toEqual([
      expect.objectContaining({
        candidate_id: "ready",
        interview_score: 91,
        total_score: 91,
        match_score: 91,
        recommendation: "recommend",
      }),
      expect.objectContaining({
        candidate_id: "processing",
        scoring_status: "processing",
        interview_score: undefined,
        total_score: undefined,
        match_score: undefined,
      }),
      expect.objectContaining({ candidate_id: "untouched", total_score: 30 }),
    ]);
    expect(records).toEqual(originalRecords);
    expect(result[0]).not.toBe(records[0]);
    expect(result[2]).toBe(records[2]);
  });

  it("uses the incomplete assessment when a candidate appears in both queue buckets", () => {
    const records = [candidate({ candidate_id: "duplicate", total_score: 10, recommendation: "consider" })];
    const queue = {
      ready_for_decision: [{ candidate_id: "duplicate", final_score: 90, recommendation: "recommend" }],
      incomplete: [{ candidate_id: "duplicate", final_score: 20, recommendation: "reject" }],
    };

    expect(enrichMassRanking(records, queue)[0]).toEqual(
      expect.objectContaining({
        total_score: 20,
        interview_score: 20,
        match_score: 20,
        recommendation: "reject",
      }),
    );
  });

  it("uses a succeeded assessment step for the decision score and preserves an empty recommendation fallback", () => {
    const records = [candidate({ candidate_id: "succeeded", total_score: 10, recommendation: "recommend" })];
    const queue = {
      ready_for_decision: [],
      incomplete: [
        {
          candidate_id: "succeeded",
          overall_score: 73,
          recommendation: "",
          step_results: {
            video: { scoring_status: "succeeded" },
            written: { scoring_status: "failed" },
          },
        },
      ],
    };

    expect(enrichMassRanking(records, queue)[0]).toEqual(
      expect.objectContaining({
        total_score: 73,
        interview_score: 73,
        match_score: 73,
        recommendation: "recommend",
      }),
    );
  });

  it("treats an empty assessment step result map as processing", () => {
    const records = [candidate({ candidate_id: "empty", total_score: 55, interview_score: 56, match_score: 57 })];
    const queue = {
      ready_for_decision: [],
      incomplete: [{ candidate_id: "empty", final_score: 99, step_results: {} }],
    };

    expect(enrichMassRanking(records, queue)[0]).toEqual(
      expect.objectContaining({
        scoring_status: "processing",
        interview_score: undefined,
        total_score: undefined,
        match_score: undefined,
      }),
    );
  });

  it("returns the original candidates when the queue is absent", () => {
    const records = [candidate({ candidate_id: "one" }), candidate({ candidate_id: "two" })];

    expect(enrichMassRanking(records)).toEqual(records);
    expect(enrichMassRanking(records, null)).toEqual(records);
  });

  it("splits monitor buckets with completed and current question precedence", () => {
    const records = [
      candidate({ candidate_id: "done", status: "invited", assessment_completed: true }),
      candidate({ candidate_id: "answering", status: "started", current_question: 1 }),
      candidate({ candidate_id: "opened", status: "started", current_question: 0 }),
      candidate({ candidate_id: "invited", status: "invited" }),
      candidate({ candidate_id: "expired", status: "expired" }),
    ];
    const buckets = splitMonitorRanking(records);

    expect(buckets.completed.map((item) => item.candidate_id)).toEqual(["done"]);
    expect(buckets.answering.map((item) => item.candidate_id)).toEqual(["answering"]);
    expect(buckets.opened.map((item) => item.candidate_id)).toEqual(["opened"]);
    expect(buckets.invited.map((item) => item.candidate_id)).toEqual(["invited"]);
    expect(buckets.expired.map((item) => item.candidate_id)).toEqual(["expired"]);
  });

  it("merges canonical assessment dimensions with report priority", () => {
    const result = fiveDimensionScores(
      {
        candidate_id: "candidate-1",
        candidate_name: "候选人",
        report_status: "succeeded",
        queue_status: "ready",
        is_formal: true,
        score_status: "final",
        score_source_label: "小评",
        recommendation: "recommend",
        dimensions: { 岗位要点匹配: 88, professional_accuracy: 77 },
        strengths: [],
        risks: [],
        questions: [],
        comprehensive_evaluation: "",
        hiring_advice: "",
      },
      {
        candidate_id: "candidate-1",
        step_results: {
          video: {
            evidence: {
              evaluation: {
                dimension_scores: { analytical_logic: 66, solution_feasibility: 55 },
              },
            },
          },
        },
        ready_for_decision: true,
      },
      candidate({ dimension_scores: { 证据与边界: 44 } }),
    );

    expect(result).toEqual([
      ["岗位要点", 88],
      ["专业准确性", 77],
      ["分析逻辑", 66],
      ["方案可执行性", 55],
      ["证据与边界", 44],
    ]);
  });

  it("provides stable status labels, colors, and invalid date fallbacks", () => {
    expect(statusLabel("completed")).toBe("已完成");
    expect(statusLabel("unknown")).toBe("unknown");
    expect(statusColor("in_progress")).toBe("#8b5cf6");
    expect(statusColor("expired")).toBe("#ef4444");
    expect(formatDateTime()).toBe("未知");
    expect(formatDateTime("not-a-date")).toBe("未知");
  });
});
