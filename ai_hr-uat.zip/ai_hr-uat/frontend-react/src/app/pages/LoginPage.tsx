import { type FormEvent, useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';

import { replaceAuthenticatedUser, safeRouteForUser, type AuthUser } from '../auth/AuthContext';
import { routePaths } from '../routes/route-paths';

type LoginForm = {
  username: string;
  password: string;
  agree: boolean;
};

type RegisterForm = LoginForm & {
  display_name: string;
  hr_contact: string;
};

type LoginResponse = {
  user: AuthUser;
};

type WeComStatusResponse = {
  enabled: boolean;
};

const WECOM_ERROR_MESSAGES: Record<string, string> = {
  wecom_disabled: '企业微信登录未启用',
  wecom_denied: '你取消了企业微信授权',
  wecom_state_invalid: '扫码状态已过期，请重新扫码',
  wecom_failed: '企业微信登录失败，请稍后重试',
  wecom_user_disabled: '该账号已被停用，请联系管理员',
};

function startWeComLogin() {
  window.location.href = '/api/auth/wecom/login';
}

export function LoginPage() {
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [wecomEnabled, setWecomEnabled] = useState(false);
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const from = (location.state as { from?: { pathname?: string } } | null)?.from?.pathname;

  // 扫码后策略 C 兜底：回调带 wecom_bind=state 时切换绑定模式
  const wecomBindState = new URLSearchParams(location.search).get('wecom_bind') || '';
  const isWeComBindMode = Boolean(wecomBindState);
  const urlError = new URLSearchParams(location.search).get('error') || '';
  const initialError = urlError ? WECOM_ERROR_MESSAGES[urlError] || '登录失败，请稍后重试' : '';

  useEffect(() => {
    let active = true;
    fetch('/api/auth/wecom/status', { credentials: 'include' })
      .then((response) => (response.ok ? response.json() : { enabled: false }))
      .then((body: WeComStatusResponse) => {
        if (active) setWecomEnabled(Boolean(body.enabled));
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);

  async function handleFinish(values: LoginForm) {
    setErrorMessage('');
    setIsSubmitting(true);

    const endpoint = isRegisterMode ? '/api/auth/wecom/register' : isWeComBindMode ? '/api/auth/wecom/bind' : '/api/auth/login';
    const registerValues = values as RegisterForm;

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(isRegisterMode ? {
          state: wecomBindState,
          username: values.username,
          password: values.password,
          display_name: registerValues.display_name,
          hr_contact: registerValues.hr_contact,
        } : isWeComBindMode ? {
          state: wecomBindState,
          username: values.username,
          password: values.password,
        } : values),
      });

      if (!response.ok) {
        const body = (await response.json()) as { error?: string };
        throw new Error(body.error || '登录失败，请检查账号和密码');
      }

      const body = (await response.json()) as LoginResponse;
      replaceAuthenticatedUser(queryClient, body.user);
      navigate(safeRouteForUser(body.user, from), { replace: true });
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : '登录失败，请稍后重试');
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const values: LoginForm = {
      username: String(formData.get('username') || ''),
      password: String(formData.get('password') || ''),
      agree: formData.get('agree') === 'on',
    };
    if (isRegisterMode) {
      (values as RegisterForm).display_name = String(formData.get('display_name') || '');
      (values as RegisterForm).hr_contact = String(formData.get('hr_contact') || '');
    }

    if (!values.agree) {
      setErrorMessage('请先阅读并同意两项协议');
      return;
    }

    void handleFinish(values);
  }

  return (
    <div className="login-wrap">
      <main className="login-shell">
        {/* 阶段4 ISSUE-4-02：对齐旧版 login.html 双栏品牌布局 */}
        <section className="login-hero" aria-label="智能招聘助手介绍">
          <div className="hero-copy">
            <p className="hero-kicker">AI 招聘助手</p>
            <h1 className="hero-title">
              把招聘交给助手
              <br />
              <em>把判断留给你</em>
            </h1>
            <p className="hero-subtitle">从岗位画像到候选人评估，让智能招聘助手陪你高效推进每一步。</p>
          </div>
          <div className="hero-capabilities" aria-label="招聘能力">
            <span>岗位画像生成</span>
            <span>候选人智能筛选</span>
            <span>面试评估辅助</span>
          </div>
          <p className="hero-footnote">把时间留给更重要的人才决策。</p>
          <picture>
            <source srcSet="/brand/guoquan-mascot-login.webp" type="image/webp" />
            <img className="hero-mascot" src="/brand/guoquan-mascot.png" alt="锅圈小熊" decoding="async" width="443" height="640" />
          </picture>
        </section>
        <section className="login-card" aria-label="登录">
          <h1 className="login-title">登录智能招聘助手</h1>
          <p className="login-intro">
            {isWeComBindMode
              ? isRegisterMode
                ? '首次扫码可直接注册新账号，之后扫码直接进入'
                : '首次扫码请绑定系统账号，之后可直接扫码进入'
              : '进入锅圈食汇招聘协作空间'}
          </p>
          {(errorMessage || initialError) && (
            <div className="login-error" role="alert">{errorMessage || initialError}</div>
          )}
          <form className="login-form" onSubmit={handleSubmit}>
            <div className="login-field">
              <label htmlFor="username">账号</label>
              <input id="username" name="username" autoComplete="username" placeholder="请输入账号" autoFocus required />
            </div>
            {isWeComBindMode && isRegisterMode && (
              <>
                <div className="login-field">
                  <label htmlFor="display_name">姓名</label>
                  <input id="display_name" name="display_name" autoComplete="name" placeholder="请输入姓名" maxLength={50} required />
                </div>
                <div className="login-field">
                  <label htmlFor="hr_contact">HR 联系邮箱</label>
                  <input id="hr_contact" name="hr_contact" type="email" autoComplete="email" placeholder="请输入邮箱" required />
                </div>
              </>
            )}
            <div className="login-field">
              <label htmlFor="password">密码</label>
              <input id="password" name="password" type="password" autoComplete="current-password" placeholder="请输入密码" required />
            </div>
            <label className="login-consent">
              <input name="agree" type="checkbox" />
              <span>
                我已阅读并同意
                <a href={routePaths.privacy} target="_blank" rel="noopener">
                  《招聘产品隐私保护协议》
                </a>
                与
                <a href={routePaths.terms} target="_blank" rel="noopener">
                  《用户服务协议》
                </a>
              </span>
            </label>
            <button type="submit" disabled={isSubmitting} className="login-btn">
              {isSubmitting
                ? '登录中…'
                : isRegisterMode
                  ? '注册并进入工作台'
                  : isWeComBindMode
                    ? '绑定并进入工作台'
                    : '进入工作台'}
            </button>
          </form>
          {isWeComBindMode && (
            <p className="login-switch-mode">
              {isRegisterMode ? '已有系统账号？' : '还没有账号？'}
              <button
                type="button"
                className="login-switch-mode-link"
                onClick={() => {
                  setErrorMessage('');
                  setIsRegisterMode((prev) => !prev);
                }}
              >
                {isRegisterMode ? '绑定已有账号' : '注册新账号'}
              </button>
            </p>
          )}
          {wecomEnabled && !isWeComBindMode && (
            <div className="login-wecom">
              <button type="button" className="login-wecom-btn" onClick={startWeComLogin}>
                企业微信扫码登录
              </button>
            </div>
          )}
          <p className="login-note">仅限授权招聘人员使用，AI 结果请结合专业判断</p>
        </section>
      </main>
      <div className="login-footer">© 2026 锅圈食汇 · 智能招聘助手</div>
    </div>
  );
}
