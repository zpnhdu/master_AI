import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { App as AntdApp } from 'antd';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

import { MassInterviewPage } from './MassInterviewPage';

const originalMediaDevices = Object.getOwnPropertyDescriptor(navigator, 'mediaDevices');

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  if (originalMediaDevices) {
    Object.defineProperty(navigator, 'mediaDevices', originalMediaDevices);
  } else {
    Reflect.deleteProperty(navigator, 'mediaDevices');
  }
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function renderPage() {
  return render(
    <MemoryRouter initialEntries={['/mass-interview/token-1']}>
      <AntdApp>
        <Routes>
          <Route path="/mass-interview/:token" element={<MassInterviewPage />} />
        </Routes>
      </AntdApp>
    </MemoryRouter>,
  );
}

describe('MassInterviewPage privacy consent', () => {
  it('requires explicit consent before entering device check or requesting media access', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        response({
          token: 'token-1',
          candidate_name: '张三',
          role: '门店店长',
          company_name: '锅圈食汇',
          company_logo: '',
          brand_color: '#C41230',
          status: 'invited',
          questions: [{ question: '请介绍一次门店经营改善案例。', time_limit_seconds: 300 }],
          current_question: 0,
          total_questions: 1,
          estimated_minutes: 6,
          expires_at: '2099-08-21T12:00:00',
          tts_urls: [],
        }),
      ),
    );
    const getUserMedia = vi.fn();
    Object.defineProperty(navigator, 'mediaDevices', {
      configurable: true,
      value: { getUserMedia },
    });

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '阅读声明并继续 →' }));

    expect(screen.getByRole('heading', { name: '面试录制与隐私信息采集声明' })).toBeInTheDocument();
    const continueButton = screen.getByRole('button', { name: '同意并进入设备检测' });
    expect(continueButton).toBeDisabled();
    expect(getUserMedia).not.toHaveBeenCalled();

    fireEvent.click(
      screen.getByRole('checkbox', {
        name: /我已阅读并理解以上声明，同意开启摄像头和麦克风/,
      }),
    );
    expect(continueButton).toBeEnabled();
    fireEvent.click(continueButton);

    expect(screen.getByText('面试前请先检测设备，确保摄像头和麦克风正常')).toBeInTheDocument();
    expect(screen.queryByText('跳过检测，直接开始')).not.toBeInTheDocument();
    expect(getUserMedia).not.toHaveBeenCalled();
  });
});
