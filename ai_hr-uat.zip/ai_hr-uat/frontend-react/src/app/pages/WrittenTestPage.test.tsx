import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { App as AntdApp } from 'antd';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

import { appendTranscriptToAnswer, WrittenTestPage } from './WrittenTestPage';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  localStorage.clear();
  sessionStorage.clear();
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function renderPage(token = 'token-1') {
  return render(
    <MemoryRouter initialEntries={[`/written-test/${token}`]}>
      <AntdApp>
        <Routes>
          <Route path="/written-test/:token" element={<WrittenTestPage />} />
        </Routes>
      </AntdApp>
    </MemoryRouter>,
  );
}

describe('WrittenTestPage', () => {
  it('appends confirmed voice transcription after existing text instead of replacing it', () => {
    expect(appendTranscriptToAnswer('第一段文字回答。', '补充的语音回答。')).toBe('第一段文字回答。\n补充的语音回答。');
    expect(appendTranscriptToAnswer('', '语音回答。')).toBe('语音回答。');
  });

  it('completes the text-answer flow from welcome to submission', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/written-test/session/token-1' && !init?.method) {
        return response({
          candidate_name: '张三',
          role: '门店店长',
          company_name: '锅圈食汇',
          questions: [{ id: 'q1', question: '请介绍一次门店经营改善案例。', difficulty: '中等' }],
          time_limit_minutes: 30,
          camera_optional: true,
          expires_at: '2099-08-21 12:00:00',
        });
      }
      if (path.endsWith('/submit')) return response({ status: 'submitted', message: '提交成功' });
      return response({}, 404);
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByRole('heading', { name: '张三，你好！' })).toBeInTheDocument();
    expect(screen.getByText(/笔试链接有效期至/)).toBeInTheDocument();
    expect(screen.queryByText(/允许摄像头录制答题过程/)).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '开始答题' }));
    expect(screen.queryByText('锅圈食汇')).not.toBeInTheDocument();
    fireEvent.change(screen.getByPlaceholderText(/在此输入你的回答/), { target: { value: '我通过调整排班提升了销售。' } });
    fireEvent.click(screen.getByRole('button', { name: '完成作答' }));

    expect(await screen.findByRole('heading', { name: '确认提交' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '确认提交' }));

    expect(await screen.findByRole('heading', { name: '提交成功！' })).toBeInTheDocument();
    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/written-test/session/token-1/submit',
        expect.objectContaining({ method: 'POST' }),
      );
    });
  });

  it('renders an expired link as a terminal state', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(response({ error: 'expired', message: '面试链接已过期' })));

    renderPage('expired');

    expect(await screen.findByRole('heading', { name: '链接已过期' })).toBeInTheDocument();
    expect(screen.getByText('面试链接已过期')).toBeInTheDocument();
  });

  it('does not claim the server session when another tab owns the browser lock', async () => {
    localStorage.setItem(
      'candidate-session-lock:locked-token',
      JSON.stringify({ owner: 'another-tab', ts: Date.now() }),
    );
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);

    renderPage('locked-token');

    expect(await screen.findByRole('heading', { name: '无法打开笔试' })).toBeInTheDocument();
    expect(screen.getByText('该笔试链接已在其他窗口打开，请关闭其他窗口后重试')).toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
