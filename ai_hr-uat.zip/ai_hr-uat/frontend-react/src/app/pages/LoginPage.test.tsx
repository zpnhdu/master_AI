import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';

import { LoginPage } from './LoginPage';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function stubStatusFetch(enabled: boolean) {
  const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
    const path = String(input);
    if (path === '/api/auth/wecom/status') return response({ enabled });
    return response({});
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function renderLoginPage(initialEntry = '/login') {
  return render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <LoginPage />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('LoginPage', () => {
  it('renders the login form without antd runtime markup', () => {
    stubStatusFetch(false);
    renderLoginPage();

    expect(screen.getByRole('heading', { name: '登录智能招聘助手' })).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: '账号' })).toBeInTheDocument();
    expect(screen.getByLabelText('密码')).toHaveAttribute('type', 'password');
    expect(document.querySelector('.ant-form')).toBeNull();
  });

  it('shows the wecom scan button only when the status endpoint enables it', async () => {
    stubStatusFetch(true);
    renderLoginPage();

    expect(await screen.findByRole('button', { name: '企业微信扫码登录' })).toBeInTheDocument();
  });

  it('keeps the wecom scan button hidden when status is disabled', async () => {
    stubStatusFetch(false);
    renderLoginPage();

    await screen.findByRole('button', { name: '进入工作台' });
    expect(screen.queryByRole('button', { name: '企业微信扫码登录' })).not.toBeInTheDocument();
  });

  it('switches to bind mode with dedicated intro and submit label when wecom_bind is present', async () => {
    stubStatusFetch(true);
    renderLoginPage('/login?wecom_bind=state-abc');

    expect(await screen.findByText('首次扫码请绑定系统账号，之后可直接扫码进入')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '绑定并进入工作台' })).toBeInTheDocument();
    // 绑定模式下不再提供整页跳转的扫码入口
    expect(screen.queryByRole('button', { name: '企业微信扫码登录' })).not.toBeInTheDocument();
  });

  it('submits bind credentials to the wecom bind endpoint with the state', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/wecom/status') return response({ enabled: false });
      if (path === '/api/auth/wecom/bind') {
        return response({ error: '账号或密码错误' }, 401);
      }
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);
    renderLoginPage('/login?wecom_bind=state-abc');

    fireEvent.change(screen.getByRole('textbox', { name: '账号' }), { target: { value: 'hr.wang' } });
    fireEvent.change(screen.getByLabelText('密码'), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('checkbox'));
    fireEvent.click(screen.getByRole('button', { name: '绑定并进入工作台' }));

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('账号或密码错误');
    });

    const bindCall = fetchMock.mock.calls.find(([input]) => String(input) === '/api/auth/wecom/bind');
    expect(bindCall).toBeDefined();
    expect(bindCall?.[1]?.method).toBe('POST');
    expect(JSON.parse(String(bindCall?.[1]?.body))).toEqual({
      state: 'state-abc',
      username: 'hr.wang',
      password: 'password123',
    });
  });

  it('maps the wecom_state_invalid error code to a Chinese message', async () => {
    stubStatusFetch(false);
    renderLoginPage('/login?error=wecom_state_invalid');

    expect(await screen.findByRole('alert')).toHaveTextContent('扫码状态已过期，请重新扫码');
  });

  it('falls back to a generic message for unknown wecom error codes', async () => {
    stubStatusFetch(false);
    renderLoginPage('/login?error=wecom_unknown_code');

    expect(await screen.findByRole('alert')).toHaveTextContent('登录失败，请稍后重试');
  });

  it('toggles between bind and register modes in wecom_bind flow', async () => {
    stubStatusFetch(false);
    renderLoginPage('/login?wecom_bind=state-abc');

    // 绑定模式默认：无姓名/邮箱字段，提供注册切换入口
    expect(screen.queryByLabelText('姓名')).not.toBeInTheDocument();
    expect(screen.queryByLabelText('HR 联系邮箱')).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '注册新账号' }));

    // 注册模式：新增字段、切换 intro 与提交按钮文案
    expect(screen.getByText('首次扫码可直接注册新账号，之后扫码直接进入')).toBeInTheDocument();
    expect(screen.getByLabelText('姓名')).toBeInTheDocument();
    expect(screen.getByLabelText('HR 联系邮箱')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '注册并进入工作台' })).toBeInTheDocument();

    // 可切回绑定模式
    fireEvent.click(screen.getByRole('button', { name: '绑定已有账号' }));
    expect(screen.queryByLabelText('姓名')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '绑定并进入工作台' })).toBeInTheDocument();
  });

  it('submits register fields to the wecom register endpoint', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/wecom/status') return response({ enabled: false });
      if (path === '/api/auth/wecom/register') {
        return response({ error: '账号已存在' }, 409);
      }
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);
    renderLoginPage('/login?wecom_bind=state-abc');

    fireEvent.click(screen.getByRole('button', { name: '注册新账号' }));
    fireEvent.change(screen.getByRole('textbox', { name: '账号' }), { target: { value: 'hr.new' } });
    fireEvent.change(screen.getByLabelText('姓名'), { target: { value: '新用户' } });
    fireEvent.change(screen.getByLabelText('HR 联系邮箱'), { target: { value: 'hr.new@test.local' } });
    fireEvent.change(screen.getByLabelText('密码'), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('checkbox'));
    fireEvent.click(screen.getByRole('button', { name: '注册并进入工作台' }));

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('账号已存在');
    });

    const registerCall = fetchMock.mock.calls.find(([input]) => String(input) === '/api/auth/wecom/register');
    expect(registerCall).toBeDefined();
    expect(registerCall?.[1]?.method).toBe('POST');
    expect(JSON.parse(String(registerCall?.[1]?.body))).toEqual({
      state: 'state-abc',
      username: 'hr.new',
      password: 'password123',
      display_name: '新用户',
      hr_contact: 'hr.new@test.local',
    });
  });
});
