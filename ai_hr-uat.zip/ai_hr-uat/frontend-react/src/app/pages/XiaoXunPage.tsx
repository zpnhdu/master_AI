import { Alert, Button, Modal, Spin, message } from 'antd';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';

import type { AgentCandidate, AgentPipeline } from '../../features/agent-workbench/api';
import { AgentArtifactsPanel } from '../../features/agent-workbench/components/AgentArtifactsPanel';
import { AgentTwoColumnLayout } from '../../features/agent-workbench/components/AgentTwoColumnLayout';
import {
  fetchRawResumeFiles,
  fetchTalentPoolSummary,
  passXiaoXunArtifact,
  type ParseResumesResponse,
  type UploadFileResult,
} from '../../features/xiao-xun/api';
import {
  useAcceptTalentRecommendationsMutation,
  useTalentRecommendationsQuery,
  useUploadResumesMutation,
  useXiaoXunInteractionState,
  useXiaoXunPipelineQuery,
  validateResumeFiles,
} from '../../features/xiao-xun/hooks';
import { ResumeUploadCard } from '../../features/xiao-xun/components/ResumeUploadCard';
import { TalentPoolImportCard } from '../../features/xiao-xun/components/TalentPoolImportCard';
import { ResumePreviewModal } from '../../features/talent-pool/components/ResumePreviewModal';
import { AgentTopbar } from '../components/AgentTopbar';
import { routePaths } from '../routes/route-paths';
import { AGENT_ORDER, agentWorkspaceUrl } from '../../shared/agent-config';
import { getErrorMessage as errorMessage } from '../../shared/errors';

export function XiaoXunPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline') ?? '';

  if (!pipelineId) {
    return (
      <div className="xun-app xun-page-status">
        <Alert
          type="warning"
          showIcon
          message="缺少岗位参数"
          description="请从岗位详情页进入小寻工作台。"
          action={<Link to={routePaths.studio}><Button size="small">返回工作台</Button></Link>}
        />
      </div>
    );
  }

  return <XiaoXunWorkspace key={pipelineId} pipelineId={pipelineId} />;
}

function XiaoXunWorkspace({ pipelineId }: { pipelineId: string }) {
  const navigate = useNavigate();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadResults, setUploadResults] = useState<UploadFileResult[]>([]);
  const [parseSummary, setParseSummary] = useState<ParseResumesResponse | null>(null);
  const [parseResults, setParseResults] = useState<ParseResumesResponse['results']>([]);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [importedResumeIds, setImportedResumeIds] = useState<string[]>([]);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [passCompleted, setPassCompleted] = useState(false);
  const [resumeCandidate, setResumeCandidate] = useState<AgentCandidate | null>(null);

  const pipelineQuery = useXiaoXunPipelineQuery(pipelineId);
  const rawFilesQuery = useQuery({
    queryKey: ['xiao-xun', 'raw-files', pipelineId],
    queryFn: () => fetchRawResumeFiles(pipelineId),
  });
  const talentPoolQuery = useQuery({
    queryKey: ['xiao-xun', 'talent-pool-summary'],
    queryFn: fetchTalentPoolSummary,
  });
  const pipeline = pipelineQuery.data;
  const nextAgentId = nextAgentIdForPipeline(pipeline?.agents ?? []);
  const nextAgentUrl = agentWorkspaceUrl(nextAgentId, pipelineId);
  const jdReady = Boolean(
    pipeline?.stages.some((stage) => stage.stageId === 'jd_write' && stage.status === 'done'),
  );
  const interaction = useXiaoXunInteractionState();
  const recommendationsQuery = useTalentRecommendationsQuery(
    pipelineId,
    { limit: 50, scope: 'broad', hardGates: true },
    jdReady,
  );
  const uploadMutation = useUploadResumesMutation(pipelineId);
  const acceptMutation = useAcceptTalentRecommendationsMutation(pipelineId);
  const passMutation = useMutation({
    mutationFn: () => passXiaoXunArtifact(pipelineId, 'next', {
      candidate_count: pipeline?.candidates.length ?? 0,
      candidate_ids: pipeline?.candidates.map((candidate) => candidate.id || candidate.resumeId).filter(Boolean) ?? [],
      selected_resume_ids: interaction.selectedResumeIds,
    }),
    onSuccess: (result) => {
      setPassCompleted(true);
      message.success(`已传递给${result.toName || '下游'}`);
      navigate(result.toAgent === 'next' ? nextAgentUrl : agentWorkspaceUrl(result.toAgent, pipelineId));
    },
  });

  useEffect(() => {
    if (pipeline?.role) document.title = `${pipeline.role} · 小寻`;
    return () => {
      document.title = '锅圈食汇 - 智能招聘平台';
    };
  }, [pipeline?.role]);

  if (pipelineQuery.isPending) {
    return <div className="xun-app xun-page-status"><div className="app-loading"><Spin size="large" tip="加载中" /></div></div>;
  }

  if (pipelineQuery.isError || !pipeline) {
    return (
      <div className="xun-app xun-page-status">
        <Alert
          type="error"
          showIcon
          message="小寻工作台加载失败"
          description={errorMessage(pipelineQuery.error)}
          action={<Button size="small" onClick={() => void pipelineQuery.refetch()}>重试</Button>}
        />
      </div>
    );
  }

  function handleFilesSelected(files: File[]) {
    const validation = validateResumeFiles([...selectedFiles, ...files]);
    setValidationErrors(validation.errors);
    setSelectedFiles(validation.validFiles);
  }

  function handleUpload() {
    if (selectedFiles.length === 0 || uploadMutation.isPending) return;

    uploadMutation.mutate(selectedFiles, {
      onSuccess: async ({ upload, accepted }) => {
        setSelectedFiles([]);
        setUploadResults((current) => [...current, ...upload.files]);
        setParseSummary(null);
        setParseResults([]);
        await Promise.all([pipelineQuery.refetch(), rawFilesQuery.refetch()]);
        if (accepted?.accepted) message.success(`已上传并加入人才库，添加到当前岗位 ${accepted.accepted} 人`);
        else if (upload.uploaded > 0) message.success('已上传到人才库');
        else message.error('没有文件成功上传');
      },
    });
  }

  async function handleImport(resumeIds = interaction.selectedResumeIds) {
    if (resumeIds.length === 0 || acceptMutation.isPending) return;
    try {
      const result = await acceptMutation.mutateAsync(resumeIds);
      setImportedResumeIds((current) => Array.from(new Set([...current, ...resumeIds])));
      interaction.clearSelection();
      message.success(`已导入 ${result.accepted} 人`);
    } catch (error) {
      message.error(`人才库导入失败：${errorMessage(error)}`);
    }
  }

  const auxiliaryError = [
    rawFilesQuery.isError ? '已上传文件' : '',
    talentPoolQuery.isError ? '人才库统计' : '',
  ].filter(Boolean).join('、');
  const existingResumeIds = pipeline.candidates
    .map((candidate) => candidate.resumeId || candidate.id)
    .filter((resumeId): resumeId is string => Boolean(resumeId));
  const artifactsPipeline: AgentPipeline = {
    ...pipeline,
    stages: pipeline.stages.map((stage) => ({
      stage_id: stage.stageId,
      status: stage.status,
      output: stage.output,
    })),
    candidates: pipeline.candidates.map((candidate, index) => ({
      ...candidate,
      id: String(candidate.id || candidate.resumeId || candidate.filename || index),
    })),
  };

  return (
    <div className="xun-app">
      <AgentTopbar
        pipelineId={pipelineId}
        mark="寻"
        title={pipeline.role}
        subtitle="小寻 · 简历获取"
        status={{ label: `${pipeline.candidates.length} 位候选人`, tone: 'neutral' }}
        primaryAction={{
          label: passCompleted ? '已传递' : '传递给下游',
          onClick: () => passMutation.mutate(),
          loading: passMutation.isPending,
          done: passCompleted,
          title: passCompleted ? '数据已传递' : '传递当前候选人并进入下游工作台',
        }}
      />
      <AgentTwoColumnLayout
        asideLabel="当前岗位候选人"
        asideWidth="compact"
        className="xiao-xun-two-column-layout"
        aside={(
          <AgentArtifactsPanel
            agentId="xiao_xun"
            pipeline={artifactsPipeline}
            showStages={false}
            candidateHeading="当前岗位候选人"
            ariaLabel="当前岗位候选人"
            onCandidateSelect={setResumeCandidate}
            selectedCandidateId={resumeCandidate?.id}
          />
        )}
        contentClassName="xun-center-pane"
      >
          {auxiliaryError ? (
            <Alert
              className="xun-card xun-auxiliary-alert"
              type="warning"
              showIcon
              message={`${auxiliaryError}加载失败`}
              description="主流程仍可继续，点击重试获取完整概况。"
              action={
                <Button
                  size="small"
                  onClick={() => {
                    void Promise.all([
                      rawFilesQuery.refetch(),
                      talentPoolQuery.refetch(),
                    ]);
                  }}
                >
                  重试
                </Button>
              }
            />
          ) : null}
          <TalentPoolImportCard
            pipelineId={pipelineId}
            total={talentPoolQuery.data?.total}
            jdReady={jdReady}
            recommendations={recommendationsQuery.data?.results ?? []}
            totalRecommendations={recommendationsQuery.data?.total ?? 0}
            loading={recommendationsQuery.isPending || recommendationsQuery.isFetching}
            error={recommendationsQuery.error ? errorMessage(recommendationsQuery.error) : ''}
            selectedResumeIds={interaction.selectedResumeIds}
            importedResumeIds={importedResumeIds}
            existingResumeIds={existingResumeIds}
            importPending={acceptMutation.isPending}
            hardGateFiltered={recommendationsQuery.data?.hardGateFiltered ?? 0}
            onUpload={() => setUploadModalOpen(true)}
            onToggleResume={interaction.toggleResume}
            onImport={() => void handleImport()}
            onImportIds={handleImport}
          />
      </AgentTwoColumnLayout>
      <Modal
        title="上传新简历"
        open={uploadModalOpen}
        width={760}
        footer={null}
        destroyOnHidden
        onCancel={() => setUploadModalOpen(false)}
      >
        <ResumeUploadCard
          fileResults={uploadResults}
          selectedFiles={selectedFiles}
          parseResults={parseResults}
          parseSummary={parseSummary}
          validationErrors={validationErrors}
          rawFiles={rawFilesQuery.data?.files ?? []}
          rawFilesLoading={rawFilesQuery.isFetching}
          uploadPending={uploadMutation.isPending}
          mutationError={uploadMutation.error ? errorMessage(uploadMutation.error) : ''}
          onFilesSelected={handleFilesSelected}
          onRemoveFile={(index) => setSelectedFiles((current) => current.filter((_, itemIndex) => itemIndex !== index))}
          onClearFiles={() => setSelectedFiles([])}
          onUpload={handleUpload}
          onRefreshRawFiles={() => void rawFilesQuery.refetch()}
        />
      </Modal>
      <ResumePreviewModal pipelineId={pipelineId} candidate={resumeCandidate} onClose={() => setResumeCandidate(null)} />
    </div>
  );
}

function nextAgentIdForPipeline(agents: string[]) {
  const configuredAgents = agents.filter((agent): agent is typeof AGENT_ORDER[number] =>
    AGENT_ORDER.includes(agent as typeof AGENT_ORDER[number]),
  );
  const sequence = configuredAgents.length > 0 ? configuredAgents : AGENT_ORDER;
  const currentIndex = sequence.indexOf('xiao_xun');
  return sequence[currentIndex + 1] ?? sequence[sequence.length - 1];
}