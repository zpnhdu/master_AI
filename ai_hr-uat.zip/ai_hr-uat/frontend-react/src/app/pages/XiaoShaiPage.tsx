import {
  Alert,
  Button,
  Card,
  Empty,
  Form,
  Input,
  InputNumber,
  Modal,
  message,
  Select,
  Space,
  Spin,
  Tag,
  Tooltip,
  Typography,
} from 'antd';
import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';

import type { AgentCandidate } from '../../features/agent-workbench/api';
import type { ScreeningCandidate, ScreeningConfig, ScreeningWorkflow } from '../../features/xiao-shai/api';
import { AgentTwoColumnLayout } from '../../features/agent-workbench/components/AgentTwoColumnLayout';
import { AgentTopbar } from '../components/AgentTopbar';
import { routePaths } from '../routes/route-paths';
import { ResumePreviewModal } from '../../features/talent-pool/components/ResumePreviewModal';
import {
  useExecuteScreeningMutation,
  useFinalizeScreeningMutation,
  usePassScreeningMutation,
  useReviewScreeningMutation,
  useXiaoShaiPipelineQuery,
  useXiaoShaiWorkflowQuery,
} from '../../features/xiao-shai/hooks';
import {
  DEFAULT_SCREENING_CONFIG,
  filterScreeningCandidates,
  mergeScreeningConfig,
  screeningBlocked,
} from '../../features/xiao-shai/selectors';
import { agentWorkspaceUrl } from '../../shared/agent-config';
import { DataTable, DataTableAction } from '../../shared/data-table';
import type { DataTableColumn } from '../../shared/data-table';
import { ListFilterSelect, ListSearch, SelectionActionBar } from '../../shared/list-workbench';

const EMPTY_WORKFLOW: ScreeningWorkflow = { counts: { passed: 0, rejected: 0 }, candidates: [] };

function asWorkflow(value: ScreeningWorkflow | undefined): ScreeningWorkflow {
  return {
    ...EMPTY_WORKFLOW,
    ...(value ?? {}),
    counts: { ...EMPTY_WORKFLOW.counts, ...(value?.counts ?? {}) },
    candidates: value?.candidates ?? [],
  };
}

function statusLabel(status: string) {
  return status === 'passed' ? '通过' : status === 'rejected' ? '淘汰' : '待筛查';
}

function statusColor(status: string) {
  return status === 'passed' ? 'success' : status === 'rejected' ? 'error' : 'default';
}

function canReviewCandidate(candidate: ScreeningCandidate) {
  const status = String(candidate.status || '').trim().toLowerCase();
  const decision = String(candidate.screening_decision || '').trim().toLowerCase();
  return ['passed', 'rejected'].includes(status) && decision !== 'passed';
}

function missingInfoLabel(item: unknown) {
  if (typeof item === 'object' && item !== null && 'label' in item) {
    return String((item as { label?: unknown }).label || '').trim();
  }
  return String(item || '').trim();
}

function informationGapNote(candidate: ScreeningCandidate) {
  const informationGaps = candidate.information_gaps ?? candidate.missing_info ?? [];
  const labels = informationGaps.map(missingInfoLabel).filter(Boolean);
  return labels.length ? `关注信息缺失：${labels.join('、')}` : '';
}

function statusReason(candidate: ScreeningCandidate) {
  const base = candidate.reason || '';
  const gapNote = informationGapNote(candidate);
  if (!base) return gapNote;
  return gapNote && !base.includes(gapNote) ? `${base}；${gapNote}` : base;
}

function scoreEvidence(candidate: ScreeningCandidate) {
  return (
    candidate.dimension_scores?.find((dimension) => dimension.evidence)?.evidence ||
    candidate.summary ||
    candidate.reason ||
    '模型未提供评分依据'
  );
}

export function XiaoShaiPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline') ?? '';

  if (!pipelineId) {
    return <AgentPageStatus type="warning" message="缺少岗位参数" description="请从岗位详情页进入小筛工作台。" />;
  }
  return <XiaoShaiWorkspace key={pipelineId} pipelineId={pipelineId} />;
}

function AgentPageStatus({
  type,
  message,
  description,
}: {
  type: 'warning' | 'error';
  message: string;
  description: string;
}) {
  return (
    <div className="agent-page agent-page--status">
      <Alert
        type={type}
        showIcon
        message={message}
        description={description}
        action={
          <Link to={routePaths.studio}>
            <Button size="small">返回工作室</Button>
          </Link>
        }
      />
    </div>
  );
}

function XiaoShaiWorkspace({ pipelineId }: { pipelineId: string }) {
  const navigate = useNavigate();
  const pipelineQuery = useXiaoShaiPipelineQuery(pipelineId);
  const workflowQuery = useXiaoShaiWorkflowQuery(pipelineId);
  const executeMutation = useExecuteScreeningMutation(pipelineId);
  const reviewMutation = useReviewScreeningMutation(pipelineId);
  const finalizeMutation = useFinalizeScreeningMutation(pipelineId);
  const passMutation = usePassScreeningMutation(pipelineId);
  const [config, setConfig] = useState<ScreeningConfig>(DEFAULT_SCREENING_CONFIG);
  const [configInitialized, setConfigInitialized] = useState(false);
  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');
  const [ascending, setAscending] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [reviewCandidate, setReviewCandidate] = useState<ScreeningCandidate | null>(null);
  const [resumeCandidate, setResumeCandidate] = useState<AgentCandidate | null>(null);
  const [batchReviewOpen, setBatchReviewOpen] = useState(false);
  const [reviewForm] = Form.useForm<{ status: string; score?: number; reason: string }>();
  const [batchReviewForm] = Form.useForm<{ status: string; reason: string }>();
  const [messageApi, messageContextHolder] = message.useMessage();
  const pipeline = pipelineQuery.data;
  const workflow = asWorkflow(workflowQuery.data);
  useEffect(() => {
    if (!pipeline || workflowQuery.isPending || configInitialized) return;
    setConfig(mergeScreeningConfig(DEFAULT_SCREENING_CONFIG, workflow.config ?? {}));
    setConfigInitialized(true);
  }, [configInitialized, pipeline, workflow.config, workflowQuery.isPending]);

  const blocked = pipeline ? screeningBlocked(pipeline) : null;
  const hasWorkflow = Boolean(workflowQuery.data);
  const activeWorkflow = hasWorkflow ? workflow : null;
  const pendingCount = Number(workflow.pending_count ?? 0);
  const reviewEnabled = Boolean(workflow.allowed_actions?.includes('review_candidates'));
  const finalizeEnabled = Boolean(
    hasWorkflow &&
      workflow.workflow_status === 'review_pending' &&
      !Number(workflow.unscored_count ?? 0) &&
      workflow.allowed_actions?.includes('finalize_screening'),
  );
  const screeningComplete =
    hasWorkflow && workflow.workflow_status === 'confirmed' && pendingCount === 0;
  const visibleCandidates = useMemo(
    () => (activeWorkflow ? filterScreeningCandidates(activeWorkflow, filter, query, ascending) : []),
    [activeWorkflow, ascending, filter, query],
  );
  useEffect(() => {
    const visibleIds = new Set(visibleCandidates.map((candidate) => candidate.id));
    setSelected((current) => {
      const next = current.filter((candidateId) => visibleIds.has(candidateId));
      return next.length === current.length ? current : next;
    });
  }, [visibleCandidates]);
  const busy =
    executeMutation.isPending ||
    reviewMutation.isPending ||
    finalizeMutation.isPending ||
    passMutation.isPending;

  if (pipelineQuery.isPending || workflowQuery.isPending)
    return (
      <div className="agent-page agent-page--status">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </div>
    );
  if (pipelineQuery.isError || !pipeline)
    return (
      <AgentPageStatus
        type="error"
        message="小筛工作台加载失败"
        description={pipelineQuery.error instanceof Error ? pipelineQuery.error.message : '岗位数据加载失败'}
      />
    );

  const readyBlocked = screeningBlocked(pipeline);

  function updateConfig(next: Partial<ScreeningConfig>) {
    setConfig((current) => mergeScreeningConfig(current, next));
    setSelected([]);
  }

  async function handleExecute(force = false) {
    try {
      await executeMutation.mutateAsync({ config, force });
      setSelected([]);
      await workflowQuery.refetch();
    } catch (error) {
      messageApi.error(error instanceof Error ? error.message : '筛选执行失败');
    }
  }

  function openReview(candidate: ScreeningCandidate) {
    setReviewCandidate(candidate);
    // 除了淘汰就是通过：淘汰候选人进入人工复核时默认展示“通过”。
    reviewForm.setFieldsValue({ status: 'passed', score: undefined, reason: '' });
  }

  async function submitReview() {
    if (!reviewCandidate) return;
    const values = await reviewForm.validateFields();
    try {
      await reviewMutation.mutateAsync({
        candidateId: reviewCandidate.id,
        status: values.status,
        reason: values.reason.trim(),
        score: values.score ?? undefined,
      });
      setReviewCandidate(null);
      await workflowQuery.refetch();
    } catch (error) {
      messageApi.error(error instanceof Error ? error.message : "人工复核失败");
    }
  }

  async function batchReview(status: string) {
    const reviewableSelected = selected.filter((candidateId) =>
      activeWorkflow?.candidates.some(
        (candidate) => String(candidate.id) === candidateId && canReviewCandidate(candidate),
      ),
    );
    if (!reviewEnabled || !reviewableSelected.length) return;
    setSelected(reviewableSelected);
    batchReviewForm.setFieldsValue({ status, reason: '' });
    setBatchReviewOpen(true);
  }

  async function submitBatchReview() {
    const values = await batchReviewForm.validateFields();
    const reviewableSelected = selected.filter((candidateId) =>
      activeWorkflow?.candidates.some(
        (candidate) => String(candidate.id) === candidateId && canReviewCandidate(candidate),
      ),
    );
    try {
      for (const candidateId of reviewableSelected) {
        await reviewMutation.mutateAsync({ candidateId, status: values.status, reason: values.reason.trim() });
      }
      setBatchReviewOpen(false);
      setSelected([]);
      await workflowQuery.refetch();
    } catch (error) {
      messageApi.error(error instanceof Error ? error.message : '批量复核失败，请稍后重试');
    }
  }

  async function finalizeAndPass() {
    if (!finalizeEnabled || busy) return;
    try {
      const final = await finalizeMutation.mutateAsync();
      const passedIds = final.passed_ids ?? [];
      if (!passedIds.length) {
        messageApi.info('没有候选人通过小筛，不能进入下游');
        await workflowQuery.refetch();
        return;
      }
      const passedIdSet = new Set(passedIds.map((item) => String(typeof item === 'object' ? item.id : item)));
      const handoff = await passMutation.mutateAsync({
        match: { version: final.version, counts: final.counts, shortlisted: passedIds },
        candidates:
          final.candidates?.filter(
            (candidate) => candidate.status === 'passed' && passedIdSet.has(String(candidate.id)),
          ) ?? [],
      });
      messageApi.success(`已传递给${handoff.to_name || '下游'}`);
      if (handoff.to_agent) {
        navigate(agentWorkspaceUrl(handoff.to_agent, pipelineId));
        return;
      }
      await workflowQuery.refetch();
    } catch (error) {
      messageApi.error(error instanceof Error ? error.message : '传递给下游失败，请稍后重试');
    }
  }

  const columns: DataTableColumn<ScreeningCandidate>[] = [
    {
      key: 'name',
      role: 'identity',
      title: '候选人',
      dataIndex: 'name',
      width: 80,
      render: (name: string) => (
        <Typography.Text strong>{name || '未知'}</Typography.Text>
      ),
    },
    {
      key: 'status',
      title: '状态',
      dataIndex: 'status',
      width: 90,
      render: (_status: string, item) => {
        const status = item.status;
        const reason = statusReason(item);
        const tag = (
          <Tag
            color={statusColor(status)}
            aria-label={reason ? `${statusLabel(status)}：${reason}` : statusLabel(status)}
            title={reason || undefined}
          >
            {statusLabel(status)}
          </Tag>
        );
        return reason ? <Tooltip title={reason}>{tag}</Tooltip> : tag;
      },
    },
    {
      key: 'overall_score',
      title: 'AI总分',
      dataIndex: 'overall_score',
      width: 90,
      sorter: (left, right) => left.overall_score - right.overall_score,
      render: (score: number, item) => {
        return (
          <Space size={6}>
            <Typography.Text strong>{score ?? 0} 分</Typography.Text>
            {item.score_source === 'model' ? <Tag color="blue">AI</Tag> : null}
          </Space>
        );
      },
    },
    {
      key: 'dimensions',
      title: '分项',
      render: (_value, item) => (
        item.dimension_scores?.length ? (
          <Space size={[4, 4]} wrap>
            {item.dimension_scores.slice(0, 3).map((dimension) => (
              <Tag key={dimension.key || dimension.label}>
                {dimension.label || '维度'} {dimension.score ?? 0}
              </Tag>
            ))}
          </Space>
        ) : (
          <Typography.Text type="secondary">暂无分项数据</Typography.Text>
        )
      ),
    },
    {
      key: 'evidence',
      title: '评分依据',
      render: (_value, item) => <Typography.Text type="secondary">{scoreEvidence(item)}</Typography.Text>,
    },
    {
      key: 'actions',
      role: 'actions',
      title: '操作',
      render: (_value, item) => (
        <Space size={6} wrap>
          <DataTableAction onClick={() => setResumeCandidate(item)}>
            预览简历
          </DataTableAction>
          <DataTableAction
            tone="warning"
            disabled={!reviewEnabled || !canReviewCandidate(item) || busy}
            title={
              !reviewEnabled
                ? '当前筛选结果暂不可复核'
                : canReviewCandidate(item)
                  ? '打开人工复核'
                  : '该候选人尚未完成 AI 评分或已进入下游'
            }
            onClick={() => openReview(item)}
          >
            人工复核
          </DataTableAction>
        </Space>
      ),
    },
  ];

  return (
    <div
      className="agent-page xun-app agent-page--screening"
      style={{ display: 'flex', flexDirection: 'column', padding: 0, height: '100vh', overflow: 'hidden' }}
    >
      {messageContextHolder}
      <AgentTopbar
        pipelineId={pipelineId}
        mark="筛"
        title={pipeline.role}
        subtitle="小筛 · 简历筛选"
        status={
          !hasWorkflow
            ? { label: '未开始' }
            : workflow.workflow_status === 'confirmed' && pendingCount > 0
              ? { label: `${pendingCount} 人待筛查` }
              : { label: '筛选完成', tone: 'ok' }
        }
        primaryAction={{
          label: !hasWorkflow
            ? '请先执行初筛'
            : workflow.workflow_status === 'confirmed' && pendingCount
              ? '请先筛查新候选人'
              : screeningComplete
                ? '已完成，无待筛候选人'
                : '确认并传递给小面',
          onClick: () => void finalizeAndPass(),
          disabled: !finalizeEnabled || busy,
          loading: finalizeMutation.isPending || passMutation.isPending,
          title: !hasWorkflow
            ? '请先执行初筛，生成筛选结果'
            : workflow.workflow_status === 'confirmed' && pendingCount
              ? '请先执行新候选人的筛选'
              : screeningComplete
                ? '当前候选人均已通过小筛并进入下一节点，无需重复筛选'
                : '完成定版并传递给小面',
        }}
      />
      <AgentTwoColumnLayout
        asideLabel="AI 初筛"
        asideWidth="wide"
        className="agent-page__body xiao-shai-two-column-layout"
        aside={
          <section className="xun-screening-control-pane">
          {readyBlocked.reasons.length ? (
            <Card title="上游数据未完成" className="agent-card">
              {readyBlocked.reasons.map((reason) => (
                <Typography.Paragraph key={reason}>○ {reason}</Typography.Paragraph>
              ))}
              <Space>
                <Link to={agentWorkspaceUrl('xiao_wen', pipelineId)}>
                  <Button>前往小文</Button>
                </Link>
                <Link to={agentWorkspaceUrl('xiao_xun', pipelineId)}>
                  <Button type="primary">前往小寻</Button>
                </Link>
              </Space>
            </Card>
          ) : (
            <>
              <Card
                title={
                  <Space size={4}>
                    <span>AI 初筛</span>
                    <Tooltip
                      placement="right"
                      title={
                        <>
                          1. AI 根据当前 JD 统一评分，HR 只需设置通过分数并启动初筛。
                          <br />
                          2. {config.threshold ?? '—'} 分及以上通过，低于该分数淘汰。
                          <br />
                          3. 缺失信息仅作为评分依据，不额外扣分、也不影响判定
                        </>
                      }
                      overlayInnerStyle={{
                        backgroundColor: '#ffffff',
                        color: '#111827',
                        border: '1px solid #93c5fd',
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(37, 99, 235, 0.12)',
                      }}
                      arrow={false}
                    >
                      <svg
                        viewBox="0 0 1024 1024"
                        width="14"
                        height="14"
                        fill="#6b7280"
                        style={{ cursor: 'help', marginLeft: 2 }}
                      >
                        <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 010-96 48.01 48.01 0 010 96z" />
                      </svg>
                    </Tooltip>
                  </Space>
                }
                className="agent-card xun-ai-control-card"
              >
                <div className="xun-ai-control-card__body">
                  <div className="xun-ai-control-card__row">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%' }}>
                      <Typography.Text>通过阈值</Typography.Text>
                      <InputNumber
                        precision={0}
                        style={{ flex: 1 }}
                        value={config.threshold}
                        status={config.threshold != null && (config.threshold > 100 || config.threshold <= 0) ? 'error' : undefined}
                        onChange={(value) => updateConfig({ threshold: value ?? undefined })}
                        parser={(displayValue) => {
                          if (displayValue === undefined || displayValue === '' || displayValue === null) return undefined as unknown as number;
                          return Math.round(Number(displayValue));
                        }}
                        addonAfter="分"
                      />
                    </div>
                    <div className="xun-ai-control-card__actions">
                      <Button
                        type="primary"
                        disabled={busy || screeningComplete || config.threshold == null || config.threshold > 100 || config.threshold <= 0}
                        loading={executeMutation.isPending}
                        onClick={() => void handleExecute()}
                        title={
                          config.threshold == null
                            ? '请设置通过阈值'
                            : config.threshold > 100
                              ? '阈值不能超过 100 分'
                              : config.threshold <= 0
                                ? '阈值必须大于 0 分'
                                : screeningComplete
                                  ? '当前候选人均已通过小筛并进入下一节点，无需重复筛选'
                                  : '使用 AI 评分，按当前阈值筛选'
                        }
                      >
                        {pendingCount
                          ? `应用阈值（${pendingCount}人）`
                          : activeWorkflow
                            ? screeningComplete
                              ? '已完成，无待筛候选人'
                              : '应用当前阈值'
                            : '开始 AI 评分'}
                      </Button>
                  </div>
                  </div>
                  </div>
              </Card>
            </>
          )}
          </section>
        }
        contentLabel="初筛结果"
        contentClassName="agent-page__main xun-center-pane xun-screening-results-pane"
      >
        {activeWorkflow ? (
          <ScreeningResults
            workflow={activeWorkflow}
            filter={filter}
            query={query}
            ascending={ascending}
            selected={selected}
            setFilter={setFilter}
            setQuery={setQuery}
            setAscending={setAscending}
            setSelected={setSelected}
            candidates={visibleCandidates}
            columns={columns}
            onBatchReview={batchReview}
            reviewEnabled={reviewEnabled}
            busy={busy}
          />
        ) : (
          <Empty description={readyBlocked.reasons.length ? '上游数据完成后即可执行初筛' : '配置规则后执行初筛，也可以先预览影响'} />
        )}
      </AgentTwoColumnLayout>
      <Modal
        title={`人工复核 · ${reviewCandidate?.name || ''}`}
        open={Boolean(reviewCandidate)}
        onCancel={() => setReviewCandidate(null)}
        onOk={() => void submitReview()}
        cancelText="取消"
        okText="确定"
        okButtonProps={{ loading: reviewMutation.isPending }}
      >
        <Form form={reviewForm} layout="vertical">
          <Form.Item name="status" label="复核结果" rules={[{ required: true }]}>
            <Select
              className="xun-review-select"
              options={[
                { value: 'passed', label: '通过' },
                { value: 'rejected', label: '淘汰' },
              ]}
            />
          </Form.Item>
          <Form.Item name="score" label="人工分数">
            <InputNumber min={0} max={100} style={{ width: '100%' }} />
          </Form.Item>
          <Form.Item
            name="reason"
            label="复核理由"
            rules={[{ required: true, whitespace: true, message: '请填写复核理由' }]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
        </Form>
      </Modal>
      <Modal
        title={`批量复核 · 已选择 ${selected.length} 人`}
        open={batchReviewOpen}
        onCancel={() => setBatchReviewOpen(false)}
        onOk={() => void submitBatchReview()}
        cancelText="取消"
        okText="提交复核"
        okButtonProps={{ loading: reviewMutation.isPending }}
      >
        <Form form={batchReviewForm} layout="vertical">
          <Form.Item name="status" label="复核结果" rules={[{ required: true }]}>
            <Select
              className="xun-review-select"
              options={[
                { value: 'passed', label: '通过' },
                { value: 'rejected', label: '淘汰' },
              ]}
            />
          </Form.Item>
          <Form.Item
            name="reason"
            label="统一复核理由"
            rules={[{ required: true, whitespace: true, message: '请填写批量复核理由' }]}
          >
            <Input.TextArea rows={4} placeholder="说明这批候选人的共同判断依据" />
          </Form.Item>
        </Form>
      </Modal>
      <ResumePreviewModal pipelineId={pipelineId} candidate={resumeCandidate} onClose={() => setResumeCandidate(null)} />
    </div>
  );
}

function ScreeningResults({
  workflow,
  filter,
  query,
  ascending,
  selected,
  setFilter,
  setQuery,
  setAscending,
  setSelected,
  candidates,
  columns,
  onBatchReview,
  reviewEnabled,
  busy,
}: {
  workflow: ScreeningWorkflow;
  filter: string;
  query: string;
  ascending: boolean;
  selected: string[];
  setFilter: (value: string) => void;
  setQuery: (value: string) => void;
  setAscending: (value: boolean) => void;
  setSelected: (value: string[]) => void;
  candidates: ScreeningCandidate[];
  columns: DataTableColumn<ScreeningCandidate>[];
  onBatchReview: (status: string) => void;
  reviewEnabled: boolean;
  busy: boolean;
}) {
  return (
    <Card
      title={
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <strong>初筛结果：</strong>
          <Tag color="default" style={{ height: 25, lineHeight: '25px', fontSize: 13, paddingInline: 8 }}>候选人 {workflow.total ?? workflow.candidates.length}</Tag>
          <Tag color="success" style={{ height: 25, lineHeight: '25px', fontSize: 13, paddingInline: 8 }}>通过 {workflow.counts.passed}</Tag>
          <Tag color="error" style={{ height: 25, lineHeight: '25px', fontSize: 13, paddingInline: 8 }}>淘汰 {workflow.counts.rejected}</Tag>
        </span>
      }
      className="agent-card xun-screening-results"
      styles={{ body: { paddingTop: 0 } }}
    >
      <DataTable
        tableId="screening-results"
        rowKey="id"
        rowSelection={
          reviewEnabled
            ? {
                selectedRowKeys: selected,
                onChange: (keys) => setSelected(keys.map(String)),
                getCheckboxProps: (candidate) => ({ disabled: !canReviewCandidate(candidate) }),
              }
            : undefined
        }
        dataSource={candidates}
        columns={columns}
        showSearch={false}
        showResultCount={false}
        showColumnSettings
        filters={
          <>
            <ListSearch
              className="xun-result-search"
              value={query}
              onChange={(value) => setQuery(value)}
              debounceMs={0}
              placeholder="搜索候选人"
            />
            <ListFilterSelect
              className="xun-result-filter-select"
              aria-label="候选人状态"
              value={filter}
              onChange={setFilter}
              options={[
                ['all', '全部'],
                ['passed', '通过'],
                ['rejected', '淘汰'],
              ].map(([value, label]) => ({ value, label }))}
              allowClear={false}
            />
            <ListFilterSelect
              className="xun-result-sort-select"
              aria-label="候选人排序"
              value={ascending ? 'asc' : 'desc'}
              onChange={(value) => setAscending(value === 'asc')}
              options={[
                { value: 'desc', label: '分数从高到低' },
                { value: 'asc', label: '分数从低到高' },
              ]}
              allowClear={false}
            />
          </>
        }
        pagination={{ pageSize: 8 }}
        locale={{ emptyText: '当前分组暂无候选人' }}
      />
      {selected.length ? (
        <SelectionActionBar
          className="xun-result-selection-actions"
          selectedCount={selected.length}
          currentPageCount={candidates.length}
          onClear={() => setSelected([])}
        >
          <Button onClick={() => onBatchReview('passed')} disabled={!reviewEnabled || busy}>
            批量通过
          </Button>
          <Button danger onClick={() => onBatchReview('rejected')} disabled={!reviewEnabled || busy}>
            批量淘汰
          </Button>
        </SelectionActionBar>
      ) : null}
    </Card>
  );
}