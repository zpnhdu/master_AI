import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { App as AntdApp } from "antd";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { MemoryRouter } from "react-router-dom";

import { DashboardPage } from "./DashboardPage";

const rankingQueryMock = vi.fn();
const chartOptionsMock = vi.fn();
let includeDimensionScores = true;
const roleRows = [
  {
    role: "高级前端工程师",
    type_code: "tech",
    type_label: "技术岗",
    candidate_count: 3,
    interview_passed_count: 2,
    pass_rate: 0.6667,
    pipelines: [],
  },
  {
    role: "后端工程师",
    type_code: "tech",
    type_label: "技术岗",
    candidate_count: 2,
    interview_passed_count: 1,
    pass_rate: 0.5,
    pipelines: [],
  },
];

vi.mock("../auth/AuthContext", () => ({
  useAuth: () => ({ user: { role_id: "hr" } }),
}));

vi.mock("../components/PageShell", () => ({
  PageShell: ({
    children,
    className,
    variant,
  }: {
    children: React.ReactNode;
    className?: string;
    variant?: string;
  }) => (
    <div className={[variant === "flex" ? "page-shell--flex" : "", className].filter(Boolean).join(" ")}>
      {children}
    </div>
  ),
}));

vi.mock("../../shared/EChart", () => ({
  EChart: ({ option }: { option: unknown }) => {
    chartOptionsMock(option);
    return <div data-testid="chart" />;
  },
}));

vi.mock("../../features/analytics/components/LeaderCabinView", () => ({
  LeaderCabinView: () => <div />,
}));

vi.mock("../../features/analytics/hooks", () => ({
  useAnalyticsDashboardQuery: () => ({
    data: {
      funnel: {
        total_candidates: 5,
        stages: {
          talent_pool: 5,
          not_applied: 1,
          applied: 4,
          screened: 4,
          interviewed: 2,
          interview_passed: 1,
        },
        pipelines: [],
      },
      summary: {
        daily_trend: {
          days: ["2026-09-02", "2026-09-03"],
          applied: [3, 4],
          screened: [3, 4],
          interviewed: [1, 2],
          interview_passed: [0, 1],
        },
      },
    },
    isPending: false,
    isError: false,
    dataUpdatedAt: 0,
    refetch: vi.fn(),
  }),
  useAnalyticsActivityQuery: () => ({ data: [], isPending: false }),
  useRoleOverviewQuery: () => ({ data: roleRows, isPending: false, isError: false }),
  useCandidateRankingQuery: (params: { detail?: boolean; limit?: number; role?: string }) => rankingQueryMock(params),
  useMonitorUsageQuery: () => ({ data: undefined }),
  useUsageDetailQuery: () => ({ data: undefined }),
}));

function renderDashboard() {
  return render(
    <MemoryRouter>
      <AntdApp>
        <DashboardPage />
      </AntdApp>
    </MemoryRouter>,
  );
}

describe("DashboardPage candidate ranking", () => {
  beforeEach(() => {
    includeDimensionScores = true;
    rankingQueryMock.mockImplementation((params: { detail?: boolean; limit?: number; role?: string }) => {
      const candidates = [
        {
          candidate_id: `${params.role}-candidate-1`,
          name: params.role === "后端工程师" ? "赵六" : "张三",
          years_experience: 6,
          skills: ["React", "TypeScript"],
          score: 95,
          score_source: "small_review",
          dimension_scores: includeDimensionScores
            ? { job_coverage: 96, professional_accuracy: 92, analytical_logic: 88, solution_feasibility: 84, evidence_boundaries: 80 }
            : undefined,
        },
        {
          candidate_id: `${params.role}-candidate-2`,
          name: params.role === "后端工程师" ? "孙七" : "李四",
          years_experience: 4,
          skills: ["Vue", "Pinia"],
          score: 88,
          score_source: "screening_match",
          dimension_scores: includeDimensionScores
            ? { job_coverage: 86, professional_accuracy: 82, analytical_logic: 78, solution_feasibility: 74, evidence_boundaries: 70 }
            : undefined,
        },
        {
          candidate_id: `${params.role}-candidate-3`,
          name: "王五",
          years_experience: 3,
          skills: ["Java", "Spring Boot"],
          score: 82,
          dimension_scores: includeDimensionScores
            ? { job_coverage: 76, professional_accuracy: 72, analytical_logic: 68, solution_feasibility: 64, evidence_boundaries: 60 }
            : undefined,
        },
        {
          candidate_id: `${params.role}-candidate-4`,
          name: "钱八",
          years_experience: 2,
          skills: ["Python", "FastAPI"],
          score: 76,
          dimension_scores: includeDimensionScores
            ? { job_coverage: 66, professional_accuracy: 62, analytical_logic: 58, solution_feasibility: 54, evidence_boundaries: 50 }
            : undefined,
        },
        {
          candidate_id: `${params.role}-candidate-5`,
          name: "周九",
          years_experience: 1,
          skills: ["MySQL"],
          score: 70,
          dimension_scores: includeDimensionScores
            ? { job_coverage: 56, professional_accuracy: 52, analytical_logic: 48, solution_feasibility: 44, evidence_boundaries: 40 }
            : undefined,
        },
      ];
      return {
        data: {
          role: params.role ?? "高级前端工程师",
          type_code: "tech",
          type_label: "技术岗",
          keywords: ["React", "TypeScript"],
          total: candidates.length,
          candidates: params.detail ? candidates : candidates.slice(0, params.limit ?? 4),
        },
        isPending: false,
        isError: false,
      };
    });
  });

  afterEach(() => {
    cleanup();
    chartOptionsMock.mockReset();
    rankingQueryMock.mockReset();
  });

  it("uses a dedicated scroll shell for content below the fold", () => {
    const { container } = renderDashboard();

    const shell = container.querySelector(".dashboard-page-shell");
    expect(shell).toHaveClass("page-shell--flex");
    expect(shell?.querySelector(":scope > .dashboard-page")).not.toBeNull();
  });

  it("uses the cumulative funnel data for the recruitment activity trend", async () => {
    renderDashboard();

    await waitFor(() => {
      const trend = chartOptionsMock.mock.calls
        .map(([option]) => option as { series?: Array<{ name?: string; data?: number[] }> })
        .find((option) => option.series?.some((series) => series.name === "投递"));
      expect(trend?.series?.map((series) => series.name)).toEqual(["投递", "筛选通过", "面试", "录用"]);
      expect(trend?.series?.map((series) => series.data?.at(-1))).toEqual([4, 4, 2, 1]);
    });
  });

  it("expands the selected candidate's skills", () => {
    renderDashboard();

    fireEvent.click(screen.getByText("张三的技能"));

    expect(screen.getByText("React")).toHaveClass("ant-tag-blue");
    expect(screen.getByText("TypeScript")).toBeInTheDocument();
    expect(screen.queryByText("Vue")).not.toBeInTheDocument();
    expect(screen.queryByText("张三的岗位关键词")).not.toBeInTheDocument();
  });

  it("labels formal small-review scores and screening-match fallbacks", () => {
    renderDashboard();

    expect(screen.getByText("正式小评分")).toBeInTheDocument();
    expect(screen.getAllByText("初筛匹配分").length).toBeGreaterThan(0);
  });

  it("opens the full ranking only from the detail button, not from a candidate card", () => {
    const { container } = renderDashboard();

    const candidateCard = container.querySelector(".dashboard-candidate-card");
    expect(candidateCard).not.toBeNull();
    fireEvent.click(candidateCard as HTMLElement);

    expect(screen.queryByText("全部候选人评分—高级前端工程师")).not.toBeInTheDocument();
    expect(rankingQueryMock).not.toHaveBeenCalledWith(expect.objectContaining({ detail: true, enabled: true }));

    fireEvent.click(screen.getByRole("button", { name: "详情" }));

    expect(screen.getByText("全部候选人评分—高级前端工程师")).toBeInTheDocument();
    expect(rankingQueryMock).toHaveBeenCalledWith(expect.objectContaining({ detail: true, enabled: true, limit: 1000 }));
  });

  it("defaults to Top 4, switches roles and opens the full ranking", async () => {
    renderDashboard();

    expect(screen.getByRole("radiogroup")).toBeInTheDocument();
    expect(screen.getByText("Top 4")).toBeInTheDocument();
    expect(rankingQueryMock).toHaveBeenCalledWith(expect.objectContaining({ role: "高级前端工程师", limit: 4 }));

    fireEvent.click(screen.getByRole("radio", { name: "Top 3" }));
    await waitFor(() => {
      expect(rankingQueryMock).toHaveBeenCalledWith(expect.objectContaining({ limit: 3, role: "高级前端工程师" }));
    });

    fireEvent.click(screen.getByRole("button", { name: "后端工程师" }));
    await waitFor(() => {
      expect(rankingQueryMock).toHaveBeenCalledWith(expect.objectContaining({ role: "后端工程师", limit: 3 }));
    });

    fireEvent.click(screen.getByRole("button", { name: "详情" }));
    expect(await screen.findByText("后端工程师 · 全部候选人评分")).toBeInTheDocument();
    expect(screen.getAllByText("孙七").length).toBeGreaterThan(0);
    expect(rankingQueryMock).toHaveBeenCalledWith(
      expect.objectContaining({ detail: true, limit: 1000, role: "后端工程师" }),
    );
  }, 15_000);

  it("renders the completed Top candidates with the five small-review dimensions", async () => {
    renderDashboard();

    await waitFor(() => {
      const radarOption = chartOptionsMock.mock.calls
        .map(([option]) => option as { radar?: { indicator?: Array<{ name: string }> }; series?: unknown[] })
        .find((option) => option.radar);
      expect(radarOption?.radar?.indicator?.map((item) => item.name)).toEqual([
        "岗位要点匹配",
        "专业准确性",
        "分析逻辑",
        "方案可执行性",
        "证据与边界",
      ]);
      expect(radarOption?.series).toHaveLength(3);
    });

    fireEvent.click(screen.getByRole("radio", { name: "Top 3" }));
    await waitFor(() => {
      const radarOptions = chartOptionsMock.mock.calls
        .map(([option]) => option as { radar?: { indicator?: Array<{ name: string }> }; series?: unknown[] })
        .filter((option) => option.radar);
      expect(radarOptions.at(-1)?.series).toHaveLength(3);
    });

    fireEvent.click(screen.getByRole("radio", { name: "Top 5" }));
    await waitFor(() => {
      const radarOptions = chartOptionsMock.mock.calls
        .map(([option]) => option as { radar?: { indicator?: Array<{ name: string }> }; series?: unknown[] })
        .filter((option) => option.radar);
      expect(radarOptions.at(-1)?.series).toHaveLength(5);
    });

    fireEvent.click(screen.getByRole("button", { name: "后端工程师" }));
    await waitFor(() => {
      const radarOptions = chartOptionsMock.mock.calls
        .map(([option]) => option as { legend?: { data?: string[] }; radar?: unknown })
        .filter((option) => option.radar);
      expect(radarOptions.at(-1)?.legend?.data).toEqual(["赵六", "孙七", "王五", "钱八", "周九"]);
    });
  }, 15_000);

  it("shows an explicit empty state when ranked candidates lack completed small reviews", async () => {
    includeDimensionScores = false;
    renderDashboard();

    expect(await screen.findByText("暂无完整评估数据")).toBeInTheDocument();
    expect(chartOptionsMock.mock.calls.some(([option]) => (option as { radar?: unknown }).radar)).toBe(false);
  }, 15_000);
});