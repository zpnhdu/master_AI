import { DeleteOutlined } from '@ant-design/icons';
import {
  Alert,
  Button,
  Card,
  Checkbox,
  DatePicker,
  Empty,
  Form,
  Input,
  Modal,
  Pagination,
  Progress,
  Radio,
  Select,
  Space,
  Tag,
  Typography,
  message,
} from 'antd';
import { useEffect, useMemo } from 'react';
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import { useRef } from 'react';
import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import dayjs, { type Dayjs } from 'dayjs';
import locale from 'antd/es/date-picker/locale/zh_CN';

import { PageShell } from '../components/PageShell';
import { resolveCompanyBrand } from '../components/companyBrand';
import { routePaths } from '../routes/route-paths';
import {
  AgentConfigModal,
  OntologyModal,
} from '../components/StudioConfigModals';
import { useCompanyConfigQuery } from '../../features/config/hooks';
import {
  ApiError,
  getPipelineStats,
  type CreatePipelineRequest,
  type Pipeline,
} from '../../features/pipelines/api';
import { ListFilterSelect, ListSearch, ListToolbar } from '../../shared/list-workbench';
import {
  useCreatePipelineMutation,
  useBatchDeletePipelinesMutation,
  useDeletePipelineMutation,
  usePipelineHrUsersQuery,
  usePipelinesQuery,
  useStartPipelineMutation,
} from '../../features/pipelines/hooks';
import { PipelineListItem, PipelineListSkeleton } from './PipelineListItem';
import {
  JOB_TYPE_OPTIONS,
  PIPELINE_STATUS_FILTER_LABELS,
  STANDARD_AGENTS,
  type JobType,
  type PipelineStatusFilter,
  filterPipelines,
  getPipelineId,
  parsePage,
  parsePipelineSort,
  parseStatusFilter,
  sortPipelines,
} from './StudioPage.selectors';

const PAGE_SIZE = 10;

const DATE_RANGE_PRESETS = [
  { label: '当天', value: () => [dayjs(), dayjs()] as [Dayjs, Dayjs] },
  { label: '近七天', value: () => [dayjs().subtract(6, 'day'), dayjs()] as [Dayjs, Dayjs] },
  { label: '近一个月', value: () => [dayjs().subtract(1, 'month'), dayjs()] as [Dayjs, Dayjs] },
];

type StudioFilterKey = 'q' | 'status' | 'created_at' | 'owner_user_id';

const PIPELINE_PRESETS = {
  quick: ['xiao_wen', 'xiao_xun', 'xiao_shai'],
  standard: STANDARD_AGENTS,
  full: ['xiao_wen', 'xiao_hai', 'xiao_xun', 'xiao_shai', 'xiao_mian', 'xiao_ping'],
  minimal: ['xiao_mian'],
} as const;

const AGENT_BADGES: Record<string, { label: string; color: string }> = {
  xiao_wen: { label: '文', color: '#2563eb' },
  xiao_hai: { label: '海', color: '#8b5cf6' },
  xiao_xun: { label: '寻', color: '#10b981' },
  xiao_shai: { label: '筛', color: '#f59e0b' },
  xiao_mian: { label: '面', color: '#ef4444' },
  xiao_ping: { label: '评', color: '#06b6d4' },
};

const ROLE_PRESETS = [
  { role: '锅圈小炒事业部总经理', hints: '需要餐饮连锁或零售行业管理经验' },
  { role: '锅圈文旅（露营）总经理', hints: '需要文旅、露营或连锁运营经验' },
  { role: '行政助理（前台）', hints: '形象气质佳，熟悉行政接待和办公软件' },
  { role: '锅圈私域运营总监', hints: '需要私域运营、用户增长和团队管理经验' },
  { role: '锅圈三方运营高级经理', hints: '需要平台运营和跨团队协作经验' },
];

type CreatePipelineFormValues = {
  role: string;
  city?: string;
  hints: string;
  type: JobType;
  preset: keyof typeof PIPELINE_PRESETS;
};

const statistics = [
  { key: 'total' as const, filter: null, label: '岗位总数', className: 'is-blue', glyph: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></svg> },
  { key: 'running' as const, filter: 'running' as PipelineStatusFilter, label: '进行中', className: 'is-amber', glyph: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3" /></svg> },
  { key: 'done' as const, filter: 'done' as PipelineStatusFilter, label: '已完成', className: 'is-green', glyph: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 11-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg> },
  { key: 'rate' as const, label: '完成率', suffix: '%', className: 'is-purple', glyph: <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18" /><polyline points="17 6 23 6 23 12" /></svg> },
];

export function StudioPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Pipeline | null>(null);
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false);
  const [agentConfigOpen, setAgentConfigOpen] = useState(false);
  const [ontologyOpen, setOntologyOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set());
  const batchDeleteSubmittingRef = useRef(false);
  const listRef = useRef<HTMLDivElement>(null);
  const [listHeight, setListHeight] = useState<number | undefined>(undefined);
  const [createForm] = Form.useForm<CreatePipelineFormValues>();
  const watchedPreset = Form.useWatch('preset', createForm) as keyof typeof PIPELINE_PRESETS | undefined;
  const selectedPreset = watchedPreset ?? 'standard';
  const searchTerm = searchParams.get('q') ?? '';
  const createdFrom = searchParams.get('created_from') ?? '';
  const createdTo = searchParams.get('created_to') ?? '';
  const ownerUserId = searchParams.get('owner_user_id') ?? '';
  const statusFilter = parseStatusFilter(searchParams.get('status'));
  const [searchInput, setSearchInput] = useState(searchTerm);
  const sort = parsePipelineSort(searchParams.get('sort'));
  const requestedPage = parsePage(searchParams.get('page'));
  const { data: pipelines = [], error, isPending, refetch } = usePipelinesQuery({ q: searchTerm, createdFrom, createdTo, ownerUserId });
  const hrUsersQuery = usePipelineHrUsersQuery();
  const { data: hrUsersData, isPending: isHrUsersPending, isError: isHrUsersError } = hrUsersQuery;
  const hrSelector = hrUsersData ?? { users: [], can_select_all: false };
  const showHrFilter = isHrUsersPending || isHrUsersError || hrSelector.can_select_all;
  const hasActiveFilters = Boolean(searchTerm || createdFrom || createdTo || ownerUserId || statusFilter);
  const { data: companyConfig } = useCompanyConfigQuery(true);
  const companyBrand = resolveCompanyBrand(companyConfig);
  const createMutation = useCreatePipelineMutation();
  const deleteMutation = useDeletePipelineMutation();
  const batchDeleteMutation = useBatchDeletePipelinesMutation();
  const startPipelineMutation = useStartPipelineMutation();
  const isCreateBusy = createMutation.isPending || startPipelineMutation.isPending;
  const stats = getPipelineStats(pipelines);
  const filteredPipelines = useMemo(
    () => filterPipelines(pipelines, searchTerm, statusFilter),
    [pipelines, searchTerm, statusFilter],
  );
  const sortedPipelines = useMemo(
    () => sortPipelines(filteredPipelines, sort),
    [filteredPipelines, sort],
  );
  const totalPages = Math.max(1, Math.ceil(sortedPipelines.length / PAGE_SIZE));
  const currentPage = Math.min(requestedPage, totalPages);
  const visiblePipelines = sortedPipelines.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  );
  const visiblePipelineIds = visiblePipelines
    .map((pipeline) => getPipelineId(pipeline))
    .filter((pipelineId): pipelineId is string => Boolean(pipelineId));
  const selectedVisibleCount = visiblePipelineIds.filter((pipelineId) => selectedIds.has(pipelineId)).length;
  const allVisibleSelected = visiblePipelineIds.length > 0 && selectedVisibleCount === visiblePipelineIds.length;
  const someVisibleSelected = selectedVisibleCount > 0 && !allVisibleSelected;
  const dateRange = useMemo<[Dayjs | null, Dayjs | null]>(() => {
    const from = createdFrom ? dayjs(createdFrom) : null;
    const to = createdTo ? dayjs(createdTo) : null;
    if (from?.isValid() && to?.isValid()) return [from, to];
    if (!createdFrom && !createdTo) return [null, null];
    return [from?.isValid() ? from : null, to?.isValid() ? to : null];
  }, [createdFrom, createdTo]);
  const activeFilterTags = useMemo(() => {
    const tags: Array<{ key: StudioFilterKey; label: string }> = [];
    if (searchTerm) tags.push({ key: 'q', label: `关键词：${searchTerm}` });
    if (statusFilter) tags.push({ key: 'status', label: `状态：${PIPELINE_STATUS_FILTER_LABELS[statusFilter]}` });
    if (createdFrom || createdTo) {
      tags.push({ key: 'created_at', label: `创建时间：${createdFrom || '开始'} → ${createdTo || '结束'}` });
    }
    if (ownerUserId) {
      const owner = hrSelector.users.find((user) => user.id === ownerUserId);
      tags.push({ key: 'owner_user_id', label: `HR：${owner?.display_name || '已选 HR'}` });
    }
    return tags;
  }, [createdFrom, createdTo, hrSelector.users, ownerUserId, searchTerm, statusFilter]);

  useEffect(() => {
    setSearchInput(searchTerm);
  }, [searchTerm]);

  function handleSearch(value: string) {
    const normalizedValue = value.trim();
    const nextParams = new URLSearchParams(searchParams);
    if (normalizedValue) {
      nextParams.set('q', normalizedValue);
    } else {
      nextParams.delete('q');
    }
    nextParams.delete('page');
    setSearchParams(nextParams, { replace: true });
  }

  function handleCreatedRangeChange(dates: [Dayjs | null, Dayjs | null] | null) {
    const nextParams = new URLSearchParams(searchParams);
    if (dates?.[0]) nextParams.set('created_from', dates[0].format('YYYY-MM-DD')); else nextParams.delete('created_from');
    if (dates?.[1]) nextParams.set('created_to', dates[1].format('YYYY-MM-DD')); else nextParams.delete('created_to');
    nextParams.delete('page');
    setSearchParams(nextParams, { replace: true });
  }

  // 按 HR 筛选仅管理员可见，选中某位 HR 后只展示其创建的岗位。
  function handleHrChange(value?: string) {
    const nextParams = new URLSearchParams(searchParams);
    if (value) {
      nextParams.set('owner_user_id', value);
    } else {
      nextParams.delete('owner_user_id');
    }
    nextParams.delete('page');
    setSearchParams(nextParams, { replace: true });
  }

  function handleStatisticClick(filter: PipelineStatusFilter | null) {
    const nextParams = new URLSearchParams(searchParams);
    if (filter) {
      nextParams.set('status', filter);
    } else {
      nextParams.delete('status');
    }
    nextParams.delete('page');
    setSearchParams(nextParams, { replace: true });
  }

  function handleStatisticKeyDown(
    event: ReactKeyboardEvent<HTMLDivElement>,
    filter: PipelineStatusFilter | null,
  ) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleStatisticClick(filter);
    }
  }

  function removeStudioFilter(filterKey: StudioFilterKey) {
    const nextParams = new URLSearchParams(searchParams);
    if (filterKey === 'created_at') {
      nextParams.delete('created_from');
      nextParams.delete('created_to');
    } else {
      nextParams.delete(filterKey);
    }
    nextParams.delete('page');
    setSearchParams(nextParams, { replace: true });
  }

  function clearStudioFilters() {
    const nextParams = new URLSearchParams(searchParams);
    ['q', 'status', 'created_from', 'created_to', 'owner_user_id', 'page'].forEach((key) => {
      nextParams.delete(key);
    });
    setSearchParams(nextParams, { replace: true });
  }

  function handlePageChange(page: number) {
    const nextParams = new URLSearchParams(searchParams);
    if (page <= 1) {
      nextParams.delete('page');
    } else {
      nextParams.set('page', String(page));
    }
    setSearchParams(nextParams, { replace: true });
  }

  function openCreateDialog() {
    createForm.resetFields();
    setCreateOpen(true);
  }

  function closeCreateDialog() {
    if (!isCreateBusy) {
      setCreateOpen(false);
    }
  }

  async function handleCreate(values: CreatePipelineFormValues) {
    if (isCreateBusy) {
      return;
    }

    const city = values.city?.trim() ?? '';
    const hints = values.hints?.trim() ?? '';
    const request: CreatePipelineRequest = {
      role: values.role.trim(),
      // 保留地点提示兼容旧链路，同时单独传递结构化地点供小文使用。
      hints: city ? `工作地点：${city}。${hints ? ' ' + hints : ''}` : hints,
      location: city,
      type: values.type,
      agents: [...PIPELINE_PRESETS[values.preset]],
      enabled_agents: [...PIPELINE_PRESETS[values.preset]],
    };

    try {
      const createdPipeline = await createMutation.mutateAsync(request);
      if (createdPipeline.pipeline_id) {
        try {
          await startPipelineMutation.mutateAsync(createdPipeline.pipeline_id);
        } catch (startError) {
          setCreateOpen(false);
          message.error(
            `岗位已创建，但自动启动失败：${getErrorDescription(startError, '请稍后重试启动。')}`,
          );
          return;
        }
      }
      setCreateOpen(false);
      message.success('岗位创建成功');
      if (createdPipeline.pipeline_id) {
        // 对齐旧版：创建成功后直接跳转详情页实时观察（ISSUE-0-03/1-02）
        navigate(routePaths.pipelineDetail(createdPipeline.pipeline_id));
      }
    } catch {
      // 错误已由全局 mutations.onError 统一展示
    }
  }

  function openDeleteDialog(pipeline: Pipeline) {
    if (!getPipelineId(pipeline)) {
      message.error('岗位删除失败：该岗位缺少有效编号，暂时无法删除。');
      return;
    }

    setDeleteTarget(pipeline);
  }

  function togglePipelineSelection(pipeline: Pipeline, checked: boolean) {
    const pipelineId = getPipelineId(pipeline);
    if (!pipelineId) {
      return;
    }

    setSelectedIds((currentIds) => {
      const nextIds = new Set(currentIds);
      if (checked) {
        nextIds.add(pipelineId);
      } else {
        nextIds.delete(pipelineId);
      }
      return nextIds;
    });
  }

  function clearPipelineSelection() {
    setSelectedIds(new Set());
  }

  function toggleVisiblePipelineSelection(checked: boolean) {
    setSelectedIds((currentIds) => {
      const nextIds = new Set(currentIds);
      visiblePipelineIds.forEach((pipelineId) => {
        if (checked) {
          nextIds.add(pipelineId);
        } else {
          nextIds.delete(pipelineId);
        }
      });
      return nextIds;
    });
  }

  function openBatchDeleteDialog() {
    if (selectedIds.size === 0) {
      return;
    }

    setBatchDeleteOpen(true);
  }

  async function handleBatchDelete() {
    if (
      batchDeleteSubmittingRef.current ||
      batchDeleteMutation.isPending ||
      selectedIds.size === 0
    ) {
      return;
    }

    batchDeleteSubmittingRef.current = true;
    const pipelineIds = [...selectedIds];

    try {
      const result = await batchDeleteMutation.mutateAsync(pipelineIds);
      setBatchDeleteOpen(false);
      clearPipelineSelection();
      if (result.failed.length > 0) {
        message.error(
          `部分岗位删除失败：已删除 ${result.deleted.length} 条，${result.failed.length} 条未删除。`,
        );
      } else {
        message.success(`已批量删除 ${result.deleted.length} 条岗位`);
      }
    } catch {
      // 错误已由全局 mutations.onError 统一展示
    } finally {
      batchDeleteSubmittingRef.current = false;
    }
  }

  async function handleDelete() {
    const pipelineId = deleteTarget && getPipelineId(deleteTarget);
    if (!pipelineId) {
      return;
    }

    try {
      await deleteMutation.mutateAsync(pipelineId);
      setDeleteTarget(null);
      message.success('岗位已删除');
    } catch {
      // 错误已由全局 mutations.onError 统一展示
    }
  }

  const hasList = !isPending && !error && sortedPipelines.length > 0;

  useEffect(() => {
    if (!hasList) {
      return;
    }

    const listEl = listRef.current;
    if (!listEl) {
      return;
    }

    const calculateHeight = () => {
      const currentListEl = listRef.current;
      if (!currentListEl) {
        return;
      }

      const container = currentListEl.closest('.studio-page') as HTMLElement;
      if (!container) {
        return;
      }

      const containerRect = container.getBoundingClientRect();
      const listRect = currentListEl.getBoundingClientRect();

      const pagination = currentListEl.parentElement?.querySelector('.studio-page__pagination') as HTMLElement;
      const paginationHeight = pagination ? pagination.getBoundingClientRect().height : 0;

      const gap = 8;
      const containerStyle = getComputedStyle(container);
      const topPadding = parseFloat(containerStyle.paddingTop) || 0;
      const bottomPadding = parseFloat(containerStyle.paddingBottom) || 0;

      const availableHeight = containerRect.height - topPadding - bottomPadding
        - (listRect.top - containerRect.top)
        - paginationHeight - gap;

      if (availableHeight > 0) {
        setListHeight(availableHeight);
      }
    };

    calculateHeight();

    const container = listEl.closest('.studio-page') as HTMLElement;
    const observer = new ResizeObserver(() => {
      calculateHeight();
    });
    if (container) {
      observer.observe(container);
    }
    observer.observe(listEl);

    window.addEventListener('resize', calculateHeight);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', calculateHeight);
    };
  }, [hasList]);

  return (
    <PageShell
      className="studio-page"
      title="招聘岗位管理"
      titleLevel={1}
      subtitle="管理岗位、跟踪招聘流程进度"
      headerExtra={
        <Space wrap>
          <Button type="primary" aria-label="创建岗位" onClick={openCreateDialog}>
            ＋ 创建岗位
          </Button>
        </Space>
      }
    >
      <div className="studio-page__statistics">
        {statistics.map((statistic) => (
          <Card
            key={statistic.label}
            className={`studio-statistic ${statistic.className}${statistic.filter !== undefined ? ' studio-statistic--interactive' : ''}${statistic.filter === null ? (!statusFilter ? ' studio-statistic--active' : '') : statistic.filter === statusFilter ? ' studio-statistic--active' : ''}`}
            variant="borderless"
            role={statistic.filter !== undefined ? 'button' : undefined}
            tabIndex={statistic.filter !== undefined ? 0 : undefined}
            aria-pressed={statistic.filter !== undefined ? (statistic.filter === null ? !statusFilter : statistic.filter === statusFilter) : undefined}
            aria-label={statistic.filter !== undefined ? (statistic.filter === null ? '查看全部岗位' : `查看${statistic.label}岗位`) : undefined}
            onClick={statistic.filter !== undefined ? () => handleStatisticClick(statistic.filter) : undefined}
            onKeyDown={statistic.filter !== undefined ? (event) => handleStatisticKeyDown(event, statistic.filter) : undefined}
          >
            <div className="studio-statistic__icon" aria-hidden="true">
              {statistic.glyph}
            </div>
            <div>
              <div className="studio-statistic__value">
                {getStatisticValue(statistic.key, stats)}{statistic.suffix ?? ''}
              </div>
              <div className="studio-statistic__label">{statistic.label}</div>
            </div>
          </Card>
        ))}
      </div>
      <ListToolbar
        search={(
          <ListSearch
            aria-label="搜索岗位名称或HR姓名"
            value={searchInput}
            placeholder="搜索岗位名称或HR姓名"
            onChange={(value) => setSearchInput(value)}
            onQueryChange={handleSearch}
          />
        )}
        filters={(
          <>
            {showHrFilter && (
              <div
                className="studio-page__hr-filter"
                data-state={
                  isHrUsersPending
                    ? 'loading'
                    : isHrUsersError
                      ? 'error'
                      : hrSelector.users.length === 0
                        ? 'empty'
                        : 'ready'
                }
              >
                {isHrUsersError ? (
                  <span className="studio-page__hr-state" role="status">
                    HR 筛选暂不可用
                  </span>
                ) : (
                  <ListFilterSelect
                    aria-label="筛选HR"
                    className="studio-page__hr"
                    disabled={isHrUsersPending || hrSelector.users.length === 0}
                    loading={isHrUsersPending}
                    placeholder={hrUsersData && hrSelector.users.length === 0 ? '暂无可选 HR' : '全部 HR'}
                    showSearch={!isHrUsersPending}
                    optionFilterProp="label"
                    value={ownerUserId || undefined}
                    options={hrSelector.users.map((user) => ({ value: user.id, label: user.display_name }))}
                    onChange={handleHrChange}
                  />
                )}
              </div>
            )}
            <DatePicker.RangePicker
              aria-label="创建时间"
              className="studio-page__date-range"
              format="YYYY-MM-DD"
              locale={locale}
              placeholder={['开始日期', '结束日期']}
              presets={DATE_RANGE_PRESETS}
              value={dateRange}
              onChange={handleCreatedRangeChange}
            />
          </>
        )}
        actions={hasActiveFilters ? (
          <Button type="link" size="small" onClick={clearStudioFilters}>
            清除筛选
          </Button>
        ) : undefined}
        count={!isPending && !error ? `共 ${sortedPipelines.length} 个岗位` : undefined}
        />

      {activeFilterTags.length > 0 && (
        <div className="studio-page__active-filters" aria-label="当前筛选条件">
          <span className="studio-page__active-filters-label">已筛选</span>
          {activeFilterTags.map((tag) => (
            <Tag key={tag.key} closable onClose={() => removeStudioFilter(tag.key)}>
              {tag.label}
            </Tag>
          ))}
        </div>
      )}

        <Card
          className="studio-page__pipelines"
          extra={visiblePipelines.length > 0 ? (
            <div className="studio-page__selection-controls" role="group" aria-label="当前页选择与批量操作">
              {selectedIds.size > 0 && (
                <>
                  <span className="studio-page__selection-count" aria-live="polite">
                    已选 {selectedIds.size} 条
                  </span>
                  <Button type="text" onClick={clearPipelineSelection}>
                    清空选择
                  </Button>
                  <Button
                    danger
                    aria-label="批量删除"
                    aria-describedby="studio-batch-delete-description"
                    title="批量删除已选岗位，点击后需再次确认"
                    onClick={openBatchDeleteDialog}
                  >
                    <DeleteOutlined aria-hidden="true" />
                    批量删除
                  </Button>
                  <span id="studio-batch-delete-description" className="studio-page__selection-help">
                    点击后需在确认框中再次确认
                  </span>
                </>
              )}
              <Checkbox
                aria-label={allVisibleSelected ? '取消全选当前页' : '全选当前页'}
                checked={allVisibleSelected}
                indeterminate={someVisibleSelected}
                onChange={(event) => toggleVisiblePipelineSelection(event.target.checked)}
              >
                全选当前页
              </Checkbox>
            </div>
          ) : undefined}
          variant="borderless"
          style={{ border: 0 }}
        >
          {isPending && <PipelineListSkeleton />}
          {!isPending && error && (
            <Alert
              action={<Button onClick={() => refetch()}>重试</Button>}
              description={getErrorDescription(error, '请稍后重试。')}
              title="岗位加载失败"
              type="error"
              showIcon
            />
          )}
          {!isPending && !error && sortedPipelines.length === 0 && (
            <Empty description={hasActiveFilters ? '没有匹配结果' : '暂无岗位'}>
              {hasActiveFilters ? (
                <Button type="primary" ghost onClick={clearStudioFilters}>
                  清除筛选条件
                </Button>
              ) : (
                <Button type="primary" ghost aria-label="立即创建岗位" onClick={openCreateDialog}>
                  立即创建岗位
                </Button>
              )}
            </Empty>
          )}
          {!isPending && !error && sortedPipelines.length > 0 && (
            <div className="pipeline-list" ref={listRef} role="list" style={listHeight !== undefined ? { height: listHeight, overflowY: 'auto', overflowX: 'hidden' } : undefined}>
              {visiblePipelines.map((pipeline) => (
                <PipelineListItem
                  key={pipeline.id || pipeline.pipeline_id}
                  onDelete={openDeleteDialog}
                  onOpen={(item) => {
                    const id = getPipelineId(item);
                    if (id) {
                      navigate(routePaths.pipelineDetail(id));
                    }
                  }}
                  onSelect={togglePipelineSelection}
                  pipeline={pipeline}
                  selected={selectedIds.has(getPipelineId(pipeline) ?? '')}
                />
              ))}
            </div>
          )}
          {!isPending && !error && sortedPipelines.length > 0 && (
            <Pagination
              aria-label="岗位分页"
              className="studio-page__pagination"
              current={currentPage}
              hideOnSinglePage={false}
              pageSize={PAGE_SIZE}
              showSizeChanger={false}
              showTotal={(total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条`}
              total={sortedPipelines.length}
              onChange={handlePageChange}
            />
          )}
        </Card>
      <Modal
        className="studio-create-modal"
        destroyOnHidden
        open={createOpen}
        rootClassName="studio-create-modal-root"
        style={{ top: 16 }}
        title="创建岗位"
        width={600}
        okText="创建并启动"
        cancelText="取消"
        okButtonProps={{ autoInsertSpace: false }}
        cancelButtonProps={{ autoInsertSpace: false, disabled: isCreateBusy }}
        confirmLoading={isCreateBusy}
        mask={{ closable: !isCreateBusy }}
        onCancel={closeCreateDialog}
        onOk={() => createForm.submit()}
      >
        <div className="studio-create-modal__company">
          <img src={companyBrand.logo} alt="" decoding="async" />
          <div>
            <Typography.Text strong>{companyBrand.name}</Typography.Text>
            <Typography.Text type="secondary">
              餐饮/食材零售 · 10000+门店 · JD将自动带入公司信息
            </Typography.Text>
          </div>
        </div>
        <Form
          form={createForm}
          layout="vertical"
          name="create-pipeline"
          initialValues={{ hints: '', preset: 'standard' }}
          onFinish={handleCreate}
        >
          <Form.Item
            htmlFor="create-pipeline_role"
            label={
              <span>
                岗位名称 <span className="studio-create-modal__required">*</span>
              </span>
            }
          >
            <div className="studio-create-modal__field">
              <Typography.Text className="studio-create-modal__field-hint">
                输入新岗位，或从常用岗位中选择
              </Typography.Text>
              <Form.Item
                noStyle
                name="role"
                rules={[{ required: true, whitespace: true, message: '请输入岗位名称' }]}
              >
                <Input
                  id="create-pipeline_role"
                  autoComplete="off"
                  placeholder="例：食材导购 / 店长 / 运营经理"
                />
              </Form.Item>
              <div className="studio-create-modal__role-presets" aria-label="常用岗位">
                {ROLE_PRESETS.map((preset) => (
                  <Button
                    key={preset.role}
                    size="small"
                    onClick={() => {
                      createForm.setFieldsValue({ role: preset.role, hints: preset.hints });
                    }}
                  >
                    {preset.role}
                  </Button>
                ))}
              </div>
              <KgIdentifyCard form={createForm} />
            </div>
          </Form.Item>
          <Form.Item label="工作地点（可选）" name="city">
            <Input autoComplete="off" placeholder="例：上海 / 北京 / 杭州，JD 将带入该城市" />
          </Form.Item>
          <Form.Item
            label={
              <span>
                岗位类型 <span className="studio-create-modal__required">*</span>
              </span>
            }
          >
            <Form.Item
              noStyle
              name="type"
              rules={[{ required: true, message: '请选择岗位类型' }]}
            >
              <Select
                aria-label="岗位类型"
                defaultActiveFirstOption={false}
                options={JOB_TYPE_OPTIONS.map((option) => ({ ...option }))}
                placeholder="请选择岗位类型"
              />
            </Form.Item>
          </Form.Item>
          <Form.Item label="补充要求（可选）" name="hints">
            <div className="studio-create-modal__field">
              <Input.TextArea
                rows={3}
                placeholder="如：需要零售门店经验，能接受轮班，能接受早班，住在闵行区优先"
              />
            </div>
          </Form.Item>
          <Form.Item label="招聘流程">
            <div className="studio-create-modal__flow-field">
              <Typography.Text className="studio-create-modal__field-hint">
                选择流程后可预览本次招聘包含的阶段
              </Typography.Text>
              <Form.Item noStyle name="preset">
                <Radio.Group
                  className="studio-create-modal__presets"
                  optionType="button"
                  buttonStyle="solid"
                  options={[
                    { label: '快速3步', value: 'quick' },
                    { label: '标准4步 推荐', value: 'standard' },
                    { label: '完整6步', value: 'full' },
                  ]}
                />
              </Form.Item>
              <div className="studio-create-modal__flow-preview">
                <Typography.Text className="studio-create-modal__flow-title">
                  流程预览
                </Typography.Text>
                <div className="studio-create-modal__flow-agents">
                  {PIPELINE_PRESETS[selectedPreset].map((agent) => (
                    <span key={agent}>
                      {AGENT_BADGES[agent]?.label ?? agent}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </Form.Item>
        </Form>
      </Modal>
      <Modal
        open={batchDeleteOpen}
        title="批量删除岗位"
        okText="确认删除"
        cancelText="取消"
        okButtonProps={{ autoInsertSpace: false, danger: true }}
        cancelButtonProps={{ autoInsertSpace: false, disabled: batchDeleteMutation.isPending }}
        confirmLoading={batchDeleteMutation.isPending}
        mask={{ closable: false }}
        closable={!batchDeleteMutation.isPending}
        onCancel={() => {
          if (!batchDeleteMutation.isPending) {
            setBatchDeleteOpen(false);
          }
        }}
        onOk={handleBatchDelete}
      >
        <Typography.Paragraph>
          确定删除选中的 {selectedIds.size} 条岗位？此操作不可恢复。
        </Typography.Paragraph>
      </Modal>
      <Modal
        open={Boolean(deleteTarget)}
        title="删除岗位"
        okText="删除"
        cancelText="取消"
        okButtonProps={{ autoInsertSpace: false, danger: true }}
        cancelButtonProps={{ autoInsertSpace: false, disabled: deleteMutation.isPending }}
        confirmLoading={deleteMutation.isPending}
        mask={{ closable: false }}
        closable={!deleteMutation.isPending}
        onCancel={() => {
          if (!deleteMutation.isPending) {
            setDeleteTarget(null);
          }
        }}
        onOk={handleDelete}
      >
        <Typography.Paragraph>
          确定删除此岗位？此操作不可恢复。
        </Typography.Paragraph>
        {deleteTarget && (
          <Typography.Text className="studio-delete-modal__target" type="secondary">
            将删除：{deleteTarget.role || '未命名岗位'}
          </Typography.Text>
        )}
      </Modal>
      <AgentConfigModal open={agentConfigOpen} onClose={() => setAgentConfigOpen(false)} />
      <OntologyModal open={ontologyOpen} onClose={() => setOntologyOpen(false)} />
    </PageShell>
  );
}

function getStatisticValue(key: 'total' | 'running' | 'done' | 'rate', stats: ReturnType<typeof getPipelineStats>) {
  const values = {
    total: stats.total,
    running: stats.running,
    done: stats.done,
    rate: stats.rate,
  };

  return values[key];
}

type KgIdentifyData = {
  scenarios?: Array<{ name?: string }>;
  methods?: Array<{ name?: string }>;
  rules?: Array<{ name?: string }>;
};

/** 对齐旧版 shared.js identifyRole + renderKGIdentifyCard：岗位输入后 debounce 调 KG 识别并展示实体卡。 */
function KgIdentifyCard({
  form,
}: {
  form: ReturnType<typeof Form.useForm<CreatePipelineFormValues>>[0];
}) {
  const role = String(Form.useWatch('role', form) ?? '');
  const [debouncedRole, setDebouncedRole] = useState('');

  useEffect(() => {
    const trimmed = role.trim();
    const timer = setTimeout(() => setDebouncedRole(trimmed.length >= 2 ? trimmed : ''), 300);
    return () => clearTimeout(timer);
  }, [role]);

  const identifyQuery = useQuery({
    queryKey: ['knowledge', 'identify', debouncedRole],
    queryFn: async () => {
      const response = await fetch(`/api/knowledge/identify?role=${encodeURIComponent(debouncedRole)}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('KG 识别请求失败');
      return response.json() as Promise<KgIdentifyData>;
    },
    enabled: Boolean(debouncedRole),
    retry: false,
  });

  const data = identifyQuery.data;
  const scenarios = data?.scenarios ?? [];
  const methods = data?.methods ?? [];
  const rules = data?.rules ?? [];
  if (!data || (!scenarios.length && !methods.length && !rules.length)) return null;

  return (
    <div className="kg-identify-card" style={{ marginTop: 10, padding: '12px 14px', background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: 10, fontSize: 12, lineHeight: 1.6 }}>
      <Typography.Text strong style={{ color: '#0369a1', display: 'block', marginBottom: 6 }}>
        ℹ KG 智能识别
      </Typography.Text>
      {scenarios.length ? (
        <div style={{ marginBottom: 4 }}>
          <Typography.Text type="secondary">场景：</Typography.Text>
          {scenarios.map((item, index) => (
            <Tag key={item.name ?? index} color="blue" style={{ borderRadius: 12 }}>
              {item.name}
            </Tag>
          ))}
        </div>
      ) : null}
      {methods.length ? (
        <div style={{ marginBottom: 4 }}>
          <Typography.Text type="secondary">推荐方法：</Typography.Text>
          {methods.map((item, index) => (
            <Tag key={item.name ?? index} color="green" style={{ borderRadius: 12 }}>
              {item.name}
            </Tag>
          ))}
        </div>
      ) : null}
      {rules.length ? (
        <div>
          <Typography.Text type="secondary">适用规则：</Typography.Text>
          {rules.map((item, index) => (
            <Tag key={item.name ?? index} color="gold" style={{ borderRadius: 12 }}>
              {item.name}
            </Tag>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function getErrorDescription(error: unknown, fallback: string) {
  if (error instanceof ApiError) {
    if (error.status === 401) {
      return '登录状态已失效，请重新登录。';
    }

    if (error.status === 403) {
      return '当前账号无权限查看岗位。';
    }

    if (error.status === 422) {
      return '请求参数不合法，请刷新后重试。';
    }

    if (error.status && error.status >= 500) {
      return '服务暂时不可用，请稍后重试。';
    }

    if (error.kind === 'timeout' || error.kind === 'backend_timeout' || error.kind === 'offline') {
      return error.message;
    }
  }

  return error instanceof Error && error.message ? error.message : fallback;
}