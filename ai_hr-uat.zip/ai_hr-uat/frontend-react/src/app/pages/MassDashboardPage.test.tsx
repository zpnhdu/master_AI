import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, useSearchParams } from 'react-router-dom';

import { AuthProvider } from '../auth/AuthContext';

import { MassDashboardPage } from './MassDashboardPage';

const activeQueryClients: QueryClient[] = [];

// ResizeObserver 需在首个用例渲染前就绪（页面高度计算 effect 会实例化它），
// 且不在 afterEach 中 unstub，避免多用例间的 fetch stub 清理交叉。
vi.stubGlobal(
  'ResizeObserver',
  class ResizeObserverMock {
    observe() {}

    unobserve() {}

    disconnect() {}
  },
);

afterEach(cleanup);
afterEach(() => {
  activeQueryClients.splice(0).forEach((queryClient) => queryClient.clear());
});

function SearchParamsProbe() {
  const [searchParams] = useSearchParams();

  return <output data-testid="location-search">{searchParams.toString()}</output>;
}

function renderMassDashboard(initialEntry = '/mass-dashboard/pipeline-1', withSearchProbe = false) {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  activeQueryClients.push(queryClient);

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntdApp>
          <AuthProvider>
            <MassDashboardPage />
          </AuthProvider>
          {withSearchProbe && <SearchParamsProbe />}
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

describe('MassDashboardPage', () => {
  it('renders the empty interview center when no mass pipelines exist', async () => {
    renderMassDashboard('/mass-dashboard');

    expect(await screen.findByRole('heading', { name: '面试中心' })).toBeInTheDocument();
    expect(await screen.findByText('暂无面试数据')).toBeInTheDocument();
    expect(document.querySelector('.hr-app-shell--studio')).toBeInTheDocument();
  });

  it('renders candidate rows in the table', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
        const path = String(input);
        if (path === '/api/mass-interview/pipelines') {
          return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
        }
        if (path === '/api/mass-interview/pipeline-1/status') {
          return response({
            stats: { total: 1, invited: 1, completed: 1, evaluated: 1 },
            sessions: [],
          });
        }
        if (path === '/api/mass-interview/pipeline-1/streams') {
          return response({ online_count: 0, recorded: 1, streams: [] });
        }
        if (path === '/api/mass-interview/pipeline-1/ranking') {
          return response({
            total: 1,
            ranking: [{
              candidate_id: 'candidate-1',
              candidate_name: '李明',
              status: 'completed',
              match_score: 88,
              total_score: 88,
              interview_score: 90,
              recommendation: 'recommend',
              dimension_scores: { 沟通: 88 },
              answers: [],
            }],
          });
        }
        return response({ last_24h: { total_llm_calls: 3, total_tokens: 1200, total_cost_usd: 0.12 } });
      }),
    );

    renderMassDashboard();

    expect(await screen.findByText('李明')).toBeInTheDocument();
    expect(screen.getByText('90')).toBeInTheDocument();
    expect(screen.getAllByText('已完成').length).toBeGreaterThan(0);
    expect(screen.getByRole('link', { name: '详情' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '简历' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '通过' })).toBeInTheDocument();
  });

  it('filters the table by clicking a KPI stat card', { timeout: 15_000 }, async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
        const path = String(input);
        if (path === '/api/mass-interview/pipelines') {
          return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
        }
        if (path === '/api/mass-interview/pipeline-1/status') {
          return response({ stats: { total: 2 }, sessions: [] });
        }
        if (path === '/api/mass-interview/pipeline-1/streams') {
          return response({ online_count: 0, recorded: 0, streams: [] });
        }
        if (path === '/api/mass-interview/pipeline-1/ranking') {
          return response({
            total: 2,
            ranking: [
              { candidate_id: 'candidate-1', candidate_name: '王芳', status: 'completed', total_score: 88 },
              { candidate_id: 'candidate-2', candidate_name: '李强', status: 'invited' },
            ],
          });
        }
        return response({ last_24h: {} });
      }),
    );

    renderMassDashboard('/mass-dashboard/pipeline-1', true);

    expect(await screen.findByText('王芳')).toBeInTheDocument();
    expect(screen.getByText('李强')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /已完成/ }));

    expect(screen.getByText('王芳')).toBeInTheDocument();
    expect(screen.queryByText('李强')).not.toBeInTheDocument();
    // 筛选状态写入 URL（对齐招聘岗位管理），刷新后筛选不丢。
    expect(screen.getByTestId('location-search')).toHaveTextContent('status=completed');
    // 与招聘岗位管理一致：显示可移除的“已筛选”状态标签。
    expect(screen.getByText('状态：已完成')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /已完成/ }));

    expect(screen.getByText('李强')).toBeInTheDocument();
    expect(screen.getByTestId('location-search')).not.toHaveTextContent('status=');
    expect(screen.queryByText('状态：已完成')).not.toBeInTheDocument();
  });


  it('stops a live stream without opening the candidate detail modal', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/mass-interview/pipelines') {
        return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
      }
      if (path === '/api/mass-interview/pipeline-1/status') {
        return response({ stats: { total: 1, in_progress: 1 }, sessions: [] });
      }
      if (path === '/api/mass-interview/pipeline-1/streams') {
        return response({
          online_count: 1,
          recorded: 0,
          streams: [{
            stream_name: 'stream-1',
            candidate_id: 'candidate-1',
            candidate_name: '王芳',
            is_online: true,
            current_question: 2,
            total_questions: 5,
          }],
        });
      }
      if (path === '/api/mass-interview/pipeline-1/ranking') {
        return response({
          total: 1,
          ranking: [{ candidate_id: 'candidate-1', candidate_name: '王芳', status: 'in_progress' }],
        });
      }
      if (path === '/api/mass-interview/stream/stream-1/kick') {
        return response({ status: 'kicked' });
      }
      return response({ last_24h: {} });
    });
    vi.stubGlobal('fetch', fetchMock);

    renderMassDashboard();

    expect(await screen.findByText('王芳')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('link', { name: '停止直播' }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/mass-interview/stream/stream-1/kick',
        expect.objectContaining({
          credentials: 'include',
          method: 'POST',
        }),
      );
    });
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('shows a written-test completion as completed even when the video invite is pending', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
        const path = String(input);
        if (path === '/api/mass-interview/pipelines') {
          return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
        }
        if (path === '/api/mass-interview/pipeline-1/status') {
          return response({ stats: { total: 1, completed: 1, invited: 0 }, sessions: [] });
        }
        if (path === '/api/mass-interview/pipeline-1/streams') {
          return response({ online_count: 0, recorded: 0, streams: [] });
        }
        if (path === '/api/mass-interview/pipeline-1/ranking') {
          return response({
            total: 1,
            ranking: [{
              candidate_id: 'candidate-1',
              candidate_name: '王芳',
              status: 'invited',
              assessment_completed: true,
              completed_modalities: ['written_test'],
            }],
          });
        }
        return response({ last_24h: {} });
      }),
    );

    renderMassDashboard();

    expect(await screen.findByText('王芳')).toBeInTheDocument();
    expect(screen.getAllByText('已完成').length).toBeGreaterThan(0);
    expect(screen.queryByText('待面试')).not.toBeInTheDocument();
  });

  it('loads the candidate resume when a ranking card opens the preview', { timeout: 15_000 }, async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/mass-interview/pipelines') {
        return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
      }
      if (path === '/api/mass-interview/pipeline-1/status') {
        return response({ stats: { total: 1, completed: 1 }, sessions: [] });
      }
      if (path === '/api/mass-interview/pipeline-1/streams') {
        return response({ online_count: 0, recorded: 0, streams: [] });
      }
      if (path === '/api/mass-interview/pipeline-1/ranking') {
        return response({ total: 1, ranking: [{ candidate_id: 'candidate-1', candidate_name: '王芳', status: 'completed' }] });
      }
      if (path === '/api/pipelines/pipeline-1/candidates/candidate-1/resume') {
        return response({ id: 'candidate-1', name: '王芳', resume_text: '有门店管理经验' });
      }
      return response({ last_24h: {} });
    });
    vi.stubGlobal('fetch', fetchMock);

    renderMassDashboard();

    fireEvent.click(await screen.findByRole('link', { name: '简历' }));

    expect(await screen.findByText('王芳 · 简历详情')).toBeInTheDocument();
    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/pipelines/pipeline-1/candidates/candidate-1/resume',
        expect.objectContaining({ credentials: 'include' }),
      );
    });
  });
});
