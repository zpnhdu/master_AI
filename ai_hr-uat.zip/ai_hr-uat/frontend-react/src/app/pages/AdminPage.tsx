import {
  Button,
  Card,
  Checkbox,
  Col,
  Empty,
  Form,
  Input,
  InputNumber,
  Modal,
  Row,
  Select,
  Space,
  Spin,
  Tag,
  Tooltip,
  Typography,
  Upload,
  message,
} from 'antd';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';

import { hasPermission, useAuth } from '../auth/AuthContext';
import { PageShell } from '../components/PageShell';
import { PageTabs } from '../../shared/components/PageTabs';
import {
  createUser,
  deleteRole,
  deleteUser,
  fetchEmailProviders,
  fetchPermissions,
  fetchRoles,
  fetchUsers,
  updateRole,
  updateUser,
  uploadHrQr,
  type AdminPermission,
  type AdminRole,
  type AdminUser,
  type CreateUserPayload,
  type UpdateRolePayload,
  type UpdateUserPayload,
} from '../../features/admin/api';
import { DataTable, DataTableAction } from '../../shared/data-table';

function formatTime(value?: string) {
  if (!value) return '尚未登录';
  return value.replace('T', ' ').slice(0, 16);
}

export function AdminPage() {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<string>('users');

  const usersQuery = useQuery({
    queryKey: ['admin', 'users'],
    queryFn: () => fetchUsers().then((r) => r.users),
    retry: 1,
  });

  const rolesQuery = useQuery({
    queryKey: ['admin', 'roles'],
    queryFn: () => fetchRoles().then((r) => r.roles),
    retry: 1,
  });

  const permissionsQuery = useQuery({
    queryKey: ['admin', 'permissions'],
    queryFn: () => fetchPermissions().then((r) => r.permissions),
    retry: 1,
  });

  const users = usersQuery.data ?? [];
  const roles = rolesQuery.data ?? [];
  const permissions = permissionsQuery.data ?? [];

  const roleMap = new Map(roles.map((r) => [r.id, r]));
  const permissionMap = new Map(permissions.map((p) => [p.id, p]));

  const createUserMutation = useMutation({
    mutationFn: (payload: CreateUserPayload) => createUser(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      message.success('用户创建成功');
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ userId, payload }: { userId: string; payload: UpdateUserPayload }) =>
      updateUser(userId, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      message.success('用户更新成功');
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: (userId: string) => deleteUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
      message.success('用户已删除');
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: ({ roleId, payload }: { roleId: string; payload: UpdateRolePayload }) =>
      updateRole(roleId, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'roles'] });
      message.success('角色更新成功');
    },
  });

  const deleteRoleMutation = useMutation({
    mutationFn: (roleId: string) => deleteRole(roleId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'roles'] });
      message.success('角色已删除');
    },
  });

  const canManageUsers = hasPermission(currentUser, 'user:manage');

  if (!canManageUsers) {
    return (
      <PageShell title="用户与权限">
        <Empty description="你暂时没有访问权限" />
      </PageShell>
    );
  }

  return (
    <PageShell
      title="用户与权限"
      headerExtra={
        <PageTabs
          value={activeTab}
          onChange={setActiveTab}
          options={[
            { label: '用户账号', value: 'users' },
            { label: '角色定义', value: 'roles' },
          ]}
        />
      }
    >
      <div className="admin-panel">
        {activeTab === 'users' && (
          <UsersPanel
            users={users}
            roles={roles}
            permissions={permissions}
            roleMap={roleMap}
            permissionMap={permissionMap}
            isLoading={usersQuery.isPending}
            onCreateUser={(payload) => createUserMutation.mutateAsync(payload)}
            onUpdateUser={(userId, payload) =>
              updateUserMutation.mutateAsync({ userId, payload })
            }
            onDeleteUser={(userId) => deleteUserMutation.mutateAsync(userId)}
          />
        )}
        {activeTab === 'roles' && (
          <RolesPanel
            roles={roles}
            permissions={permissions}
            permissionMap={permissionMap}
            isLoading={rolesQuery.isPending}
            onUpdateRole={(roleId, payload) =>
              updateRoleMutation.mutateAsync({ roleId, payload })
            }
            onDeleteRole={(roleId) => deleteRoleMutation.mutateAsync(roleId)}
          />
        )}
      </div>
    </PageShell>
  );
}

type UsersPanelProps = {
  users: AdminUser[];
  roles: AdminRole[];
  permissions: AdminPermission[];
  roleMap: Map<string, AdminRole>;
  permissionMap: Map<string, AdminPermission>;
  isLoading: boolean;
  onCreateUser: (payload: CreateUserPayload) => Promise<unknown>;
  onUpdateUser: (userId: string, payload: UpdateUserPayload) => Promise<unknown>;
  onDeleteUser: (userId: string) => Promise<unknown>;
};

function UsersPanel({
  users,
  roles,
  roleMap,
  isLoading,
  onCreateUser,
  onUpdateUser,
  onDeleteUser,
}: UsersPanelProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [form] = Form.useForm();

  const openCreate = () => {
    setEditingUser(null);
    setModalOpen(true);
  };

  const openEdit = (user: AdminUser) => {
    setEditingUser(user);
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    const values = await form.validateFields();
    try {
      if (editingUser) {
        const payload: UpdateUserPayload = {
          display_name: values.display_name,
          role_id: values.role_id,
          is_active: values.is_active,
          hr_contact: values.hr_contact,
          email_provider: values.email_provider,
          hr_qr_code_storage_key: values.hr_qr_code_storage_key ?? '',
        };
        if (values.password) payload.password = values.password;
        if (values.credential) payload.credential = values.credential;
        if (values.email_provider === 'custom') {
          payload.smtp_host = values.smtp_host ?? '';
          payload.smtp_port = values.smtp_port;
          payload.smtp_security = values.smtp_security ?? 'ssl';
          payload.imap_host = values.imap_host ?? '';
          payload.imap_port = values.imap_port;
          payload.imap_security = values.imap_security ?? 'ssl';
        }
        await onUpdateUser(editingUser.id, payload);
      } else {
        await onCreateUser({
          username: values.username,
          display_name: values.display_name,
          password: values.password,
          role_id: values.role_id,
          is_active: values.is_active,
          hr_contact: values.hr_contact,
          email_provider: values.email_provider,
          credential: values.credential ?? '',
          hr_qr_code_storage_key: values.hr_qr_code_storage_key ?? '',
          ...(values.email_provider === 'custom'
            ? {
                smtp_host: values.smtp_host ?? '',
                smtp_port: values.smtp_port,
                smtp_security: values.smtp_security ?? 'ssl',
                imap_host: values.imap_host ?? '',
                imap_port: values.imap_port,
                imap_security: values.imap_security ?? 'ssl',
              }
            : {}),
        });
      }
      setModalOpen(false);
    } catch {
      // Mutation handlers already surface the error; keep the dialog open for retry.
    }
  };

  const handleDelete = (userId: string) => {
    Modal.confirm({
      title: '确认删除',
      content: '删除后该用户将无法登录，确定要删除吗？',
      okText: '删除',
      okType: 'danger',
      cancelText: '取消',
      onOk: () => onDeleteUser(userId),
    });
  };

  const columns = [
    {
      title: '账号',
      dataIndex: 'username',
      key: 'username',
      role: 'identity' as const,
      render: (_: string, record: AdminUser) => (
        <div>
          <strong>{record.display_name || record.username}</strong>
          <br />
          <Typography.Text type="secondary" className="admin-cell__secondary">
            {record.username}
          </Typography.Text>
        </div>
      ),
    },
    {
      title: '角色',
      dataIndex: 'role_id',
      key: 'role_id',
      render: (roleId: string) => {
        const role = roleMap.get(roleId);
        return role?.name ?? roleId;
      },
    },
    {
      title: '联系邮箱',
      dataIndex: 'hr_contact',
      key: 'hr_contact',
      render: (value: string) => value || <Typography.Text type="secondary">未填写</Typography.Text>,
    },
    {
      title: '状态',
      dataIndex: 'is_active',
      key: 'is_active',
      render: (active: boolean) =>
        active ? (
          <Tag color="success">启用</Tag>
        ) : (
          <Tag color="default">已禁用</Tag>
        ),
    },
    {
      title: '最近登录',
      dataIndex: 'last_login_at',
      key: 'last_login_at',
      render: (val: string) => formatTime(val),
    },
    {
      title: '操作',
      key: 'actions',
      role: 'actions' as const,
      align: 'center' as const,
      render: (_: unknown, record: AdminUser) => (
        <Space>
          <DataTableAction onClick={() => openEdit(record)}>
            编辑
          </DataTableAction>
          <DataTableAction tone="danger" onClick={() => handleDelete(record.id)}>
            删除
          </DataTableAction>
        </Space>
      ),
    },

  ];

  return (
    <Card className="agent-card" style={{ paddingLeft: 0, paddingTop: 0 }}>
      <div className="admin-panel__toolbar">
        <div>
          <Typography.Title level={5} className="admin-panel__title">
            用户账号
          </Typography.Title>
          <Typography.Text type="secondary">
            可创建、编辑、禁用账号，并为账号分配角色。
          </Typography.Text>
        </div>
      </div>
      {isLoading ? (
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      ) : (
        <DataTable
          tableId="admin-users"
          initialPageSize={10}
          scroll={{ x: 'max-content' }}
          columns={columns}
          dataSource={users}
          rowKey="id"
          locale={{ emptyText: <Empty description="暂无用户账号" /> }}
          showSearch
          searchPlaceholder="搜索账号 / 姓名 / 角色"
          searchableText={(record) => {
            const roleName = roleMap.get(record.role_id)?.name ?? record.role_id;
            return [record.username, record.display_name, roleName, record.hr_contact].filter(Boolean).join(' ');
          }}
          showColumnSettings
          showResultCount={false}
          filters={<Button type="primary" onClick={openCreate}>＋ 新建用户</Button>}
        />
      )}
      <UserModal
        open={modalOpen}
        editingUser={editingUser}
        roles={roles}
        form={form}
        onCancel={() => setModalOpen(false)}
        onSubmit={handleSubmit}
      />
    </Card>
  );
}

type UserModalProps = {
  open: boolean;
  editingUser: AdminUser | null;
  roles: AdminRole[];
  form: ReturnType<typeof Form.useForm>[0];
  onCancel: () => void;
  onSubmit: () => void | Promise<void>;
};

function securityLabel(security?: string) {
  if (!security) return '';
  return security.toLowerCase() === 'starttls' ? 'STARTTLS' : 'SSL';
}

function UserModal({ open, editingUser, roles, form, onCancel, onSubmit }: UserModalProps) {
  const isEdit = Boolean(editingUser);
  const providerValue = Form.useWatch('email_provider', form) as string | undefined;

  const providersQuery = useQuery({
    queryKey: ['admin', 'email-providers'],
    queryFn: () => fetchEmailProviders().then((r) => r.providers),
    staleTime: Infinity,
    retry: 1,
  });
  const providers = providersQuery.data ?? [];
  const selectedProvider = providers.find((p) => p.key === providerValue);

  const initialValues = editingUser
    ? {
        username: editingUser.username,
        display_name: editingUser.display_name,
        role_id: editingUser.role_id,
        is_active: editingUser.is_active,
        password: undefined,
        hr_contact: editingUser.hr_contact ?? '',
        email_provider: editingUser.email_provider ?? 'custom',
        credential: undefined,
        smtp_host: editingUser.email_smtp_host ?? '',
        smtp_port: editingUser.email_smtp_port ?? 465,
        smtp_security: editingUser.email_smtp_security ?? 'ssl',
        imap_host: editingUser.email_imap_host ?? '',
        imap_port: editingUser.email_imap_port ?? 993,
        imap_security: editingUser.email_imap_security ?? 'ssl',
        hr_qr_code_storage_key: editingUser.hr_qr_code_storage_key ?? '',
      }
    : {
        is_active: true,
        role_id: 'hr_specialist',
        email_provider: 'custom',
        credential: undefined,
        smtp_port: 465,
        smtp_security: 'ssl',
        imap_port: 993,
        imap_security: 'ssl',
      };

  return (
    <Modal
      centered
      className="admin-user-modal"
      title={isEdit ? '编辑用户' : '新建用户'}
      open={open}
      onCancel={onCancel}
      onOk={onSubmit}
      okText="保存用户"
      cancelText="取消"
      width={940}
    >
      <Form
        form={form}
        layout="vertical"
        preserve={false}
        initialValues={initialValues}
        key={editingUser?.id ?? 'new'}
      >
        <Row gutter={32}>
          <Col span={12}>
            <Form.Item
              name="username"
              label="账号"
              rules={[
                { required: true, message: '请输入账号' },
                { pattern: /^[A-Za-z0-9_.-]{3,32}$/, message: '3-32 位字母、数字、点、下划线或连字符' },
              ]}
            >
              <Input disabled={isEdit} maxLength={32} autoComplete="username" />
            </Form.Item>
            <Form.Item
              name="display_name"
              label="姓名"
              rules={[{ required: true, message: '请输入姓名' }]}
            >
              <Input maxLength={50} />
            </Form.Item>
            <Form.Item
              name="role_id"
              label="角色"
              rules={[{ required: true, message: '请选择角色' }]}
            >
              <Select>
                {roles.map((role) => (
                  <Select.Option key={role.id} value={role.id}>
                    {role.name}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
            <Form.Item
              name="password"
              label={
                <Space size={4}>
                  <span>密码</span>
                  <Tooltip
                    placement="right"
                    title={isEdit ? '留空则不修改现有密码' : '不少于 8 位'}
                    overlayInnerStyle={{
                      backgroundColor: '#ffffff',
                      color: '#111827',
                      border: '1px solid #93c5fd',
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(37, 99, 235, 0.12)',
                    }}
                    arrow={false}
                  >
                    <svg
                      viewBox="0 0 1024 1024"
                      width="14"
                      height="14"
                      fill="#6b7280"
                      style={{ cursor: 'help' }}
                    >
                      <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 010-96 48.01 48.01 0 010 96z" />
                    </svg>
                  </Tooltip>
                </Space>
              }
              rules={isEdit ? [] : [{ required: true, message: '请输入密码' }]}
            >
              <Input.Password minLength={8} autoComplete="new-password" />
            </Form.Item>
            <Form.Item name="is_active" label="启用" valuePropName="checked">
              <Checkbox>启用该账号</Checkbox>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="hr_contact"
              label="HR 联系邮箱（收发共用）"
              rules={[
                { required: true, message: '请输入联系邮箱' },
                { type: 'email', message: '邮箱格式不正确' },
              ]}
            >
              <Input placeholder="hr@example.com" autoComplete="email" />
            </Form.Item>
            <Form.Item
              name="email_provider"
              label="邮箱服务商"
              rules={[{ required: true, message: '请选择邮箱服务商' }]}
            >
              <Select placeholder="选择服务商后自动带出服务器与端口">
                {providers.map((p) => (
                  <Select.Option key={p.key} value={p.key}>
                    {p.label}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
            {providerValue !== 'custom' && selectedProvider ? (
              <Form.Item label="收发服务器">
                <Typography.Text type="secondary">
                  SMTP {selectedProvider.smtp.host}:{selectedProvider.smtp.port}（{securityLabel(selectedProvider.smtp.security)}）
                  {' · '}IMAP {selectedProvider.imap.host}:{selectedProvider.imap.port}（{securityLabel(selectedProvider.imap.security)}）
                </Typography.Text>
              </Form.Item>
            ) : null}
            {providerValue === 'custom' ? (
              <>
                <Form.Item
                  label="SMTP 服务器（发信）"
                  required
                >
                  <Space.Compact style={{ width: '100%' }}>
                    <Form.Item name="smtp_host" noStyle rules={[{ required: true, message: '请输入 SMTP 服务器' }]}>
                      <Input placeholder="smtp.example.com" />
                    </Form.Item>
                    <Form.Item name="smtp_port" noStyle rules={[{ required: true, message: '端口' }]}>
                      <InputNumber min={1} max={65535} placeholder="端口" style={{ width: 100 }} />
                    </Form.Item>
                    <Form.Item name="smtp_security" noStyle>
                      <Select style={{ width: 160 }}>
                        <Select.Option value="ssl">SSL</Select.Option>
                        <Select.Option value="starttls">STARTTLS</Select.Option>
                      </Select>
                    </Form.Item>
                  </Space.Compact>
                </Form.Item>
                <Form.Item
                  label="IMAP 服务器（收信/同步）"
                  required
                >
                  <Space.Compact style={{ width: '100%' }}>
                    <Form.Item name="imap_host" noStyle rules={[{ required: true, message: '请输入 IMAP 服务器' }]}>
                      <Input placeholder="imap.example.com" />
                    </Form.Item>
                    <Form.Item name="imap_port" noStyle rules={[{ required: true, message: '端口' }]}>
                      <InputNumber min={1} max={65535} placeholder="端口" style={{ width: 100 }} />
                    </Form.Item>
                    <Form.Item name="imap_security" noStyle>
                      <Select style={{ width: 160 }}>
                        <Select.Option value="ssl">SSL</Select.Option>
                        <Select.Option value="starttls">STARTTLS</Select.Option>
                      </Select>
                    </Form.Item>
                  </Space.Compact>
                </Form.Item>
              </>
            ) : null}
            <Form.Item
              name="credential"
              label={
                <Space size={4}>
                  <span>授权码</span>
                  <Tooltip
                    placement="right"
                    title={isEdit ? '留空则不修改现有授权码（SMTP/IMAP 共用）' : '发信与收信共用同一授权码'}
                    overlayInnerStyle={{
                      backgroundColor: '#ffffff',
                      color: '#111827',
                      border: '1px solid #93c5fd',
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(37, 99, 235, 0.12)',
                    }}
                    arrow={false}
                  >
                    <svg
                      viewBox="0 0 1024 1024"
                      width="14"
                      height="14"
                      fill="#6b7280"
                      style={{ cursor: 'help' }}
                    >
                      <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm-32 232c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V296zm32 440a48.01 48.01 0 010-96 48.01 48.01 0 010 96z" />
                    </svg>
                  </Tooltip>
                </Space>
              }
              rules={isEdit ? [] : [{ required: true, message: '请输入邮箱授权码' }]}
            >
              <Input.Password autoComplete="new-password" />
            </Form.Item>
            <HrQrField form={form} editingUser={editingUser} />
          </Col>
        </Row>
      </Form>
    </Modal>
  );
}

function HrQrField({
  form,
  editingUser,
}: {
  form: ReturnType<typeof Form.useForm>[0];
  editingUser: AdminUser | null;
}) {
  const storageKey = Form.useWatch('hr_qr_code_storage_key', form) as string | undefined;
  const [previewUrl, setPreviewUrl] = useState(editingUser?.hr_qr_code_url ?? '');
  const [uploading, setUploading] = useState(false);

  async function handleUpload(file: File) {
    setUploading(true);
    try {
      const res = await uploadHrQr(file, storageKey || editingUser?.hr_qr_code_storage_key || undefined);
      form.setFieldValue('hr_qr_code_storage_key', res.storage_key);
      setPreviewUrl(res.url);
      message.success('二维码上传成功');
    } catch (error) {
      message.error(error instanceof Error ? error.message : '上传失败');
    } finally {
      setUploading(false);
    }
  }

  return (
    <>
      <Form.Item name="hr_qr_code_storage_key" noStyle>
        <Input type="hidden" />
      </Form.Item>
      <Form.Item label="HR 投递二维码">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Upload
            accept="image/*"
            showUploadList={false}
            beforeUpload={(file) => {
              void handleUpload(file);
              return false;
            }}
          >
            <Button loading={uploading}>{storageKey ? '重新上传' : '上传二维码'}</Button>
          </Upload>
          {previewUrl ? (
            <img
              className="studio-asset-preview"
              src={previewUrl}
              alt="二维码预览"
              loading="lazy"
              decoding="async"
            />
          ) : null}
        </div>
      </Form.Item>
    </>
  );
}

type RolesPanelProps = {
  roles: AdminRole[];
  permissions: AdminPermission[];
  permissionMap: Map<string, AdminPermission>;
  isLoading: boolean;
  onUpdateRole: (roleId: string, payload: UpdateRolePayload) => Promise<unknown>;
  onDeleteRole: (roleId: string) => Promise<unknown>;
};

function RolesPanel({
  roles,
  permissions,
  permissionMap,
  isLoading,
  onUpdateRole,
  onDeleteRole,
}: RolesPanelProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<AdminRole | null>(null);
  const [form] = Form.useForm();

  const openEdit = (role: AdminRole) => {
    setEditingRole(role);
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    if (!editingRole) return;
    const values = await form.validateFields();
    try {
      await onUpdateRole(editingRole.id, {
        description: values.description,
        permissions: values.permissions,
      });
      setModalOpen(false);
    } catch {
      // Mutation handlers already surface the error; keep the dialog open for retry.
    }
  };

  const handleDelete = (roleId: string) => {
    Modal.confirm({
      title: '确认删除',
      content: '删除后该角色将从所有用户中移除，确定要删除吗？',
      okText: '删除',
      okType: 'danger',
      cancelText: '取消',
      onOk: () => onDeleteRole(roleId),
    });
  };

  const columns = [
    {
      title: '角色',
      dataIndex: 'name',
      key: 'name',
      role: 'identity' as const,
      render: (name: string, record: AdminRole) => (
        <div>
          <strong>
            {name}
            {record.is_system && <Tag color="purple" className="admin-tag--system">预设</Tag>}
          </strong>
          <br />
          <Typography.Text type="secondary" className="admin-cell__secondary">
            {record.description || '未填写角色说明'}
          </Typography.Text>
        </div>
      ),
    },
    {
      title: '页面与功能权限',
      dataIndex: 'permissions',
      key: 'permissions',
      render: (perms: string[], record: AdminRole) => {
        if (perms.includes('*')) {
          return <Tag>全部权限</Tag>;
        }
        return (
          <Space wrap size={[4, 4]}>
            {perms.length > 0
              ? perms.map((p) => {
                  const item = permissionMap.get(p);
                  return <Tag key={p}>{item?.label ?? p}</Tag>;
                })
              : <Tag>未授权</Tag>}
          </Space>
        );
      },
    },
    {
      title: '使用人数',
      dataIndex: 'user_count',
      key: 'user_count',
      render: (val: number) => val ?? 0,
    },
    {
      title: '操作',
      key: 'actions',
      role: 'actions' as const,
      align: 'center' as const,
      render: (_: unknown, record: AdminRole) => (
        <Space>
          <DataTableAction onClick={() => openEdit(record)}>
            编辑
          </DataTableAction>
          {/* <Button
            type="link"
            danger
            disabled={record.is_system}
            onClick={() => handleDelete(record.id)}
          >
            删除
          </Button> */}
        </Space>
      ),
    },
  ];

  return (
    <Card className="agent-card" style={{ paddingLeft: 0, paddingTop: 0 }}>
      <div className="admin-panel__toolbar">
        <div>
          <Typography.Title level={5} className="admin-panel__title">
            角色定义
          </Typography.Title>
          <Typography.Text type="secondary">
            当前固定为管理员和 HR 专员，可按需调整各自的权限范围。
          </Typography.Text>
        </div>
      </div>
      {isLoading ? (
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      ) : (
        <DataTable
          tableId="admin-roles"
          initialPageSize={10}
          scroll={{ x: 'max-content' }}
          columns={columns}
          dataSource={roles}
          rowKey="id"
          locale={{ emptyText: <Empty description="暂无角色定义" /> }}
          showColumnSettings
          showResultCount={false}
        />
      )}
      <RoleModal
        open={modalOpen}
        editingRole={editingRole}
        permissions={permissions}
        form={form}
        onCancel={() => setModalOpen(false)}
        onSubmit={handleSubmit}
      />
    </Card>
  );
}

type RoleModalProps = {
  open: boolean;
  editingRole: AdminRole | null;
  permissions: AdminPermission[];
  form: ReturnType<typeof Form.useForm>[0];
  onCancel: () => void;
  onSubmit: () => void;
};

type PermissionCheckboxesProps = {
  permissions: AdminPermission[];
  isAdmin: boolean;
  onChange?: (checked: string[]) => void;
  value?: string[];
};

function PermissionCheckboxes({ permissions, isAdmin, onChange, value }: PermissionCheckboxesProps) {
  const currentValues = value || [];

  const handleCheck = (permId: string, checked: boolean) => {
    const next = new Set(currentValues);
    if (checked) {
      next.add(permId);
    } else {
      next.delete(permId);
    }
    onChange?.(Array.from(next));
  };

  return (
    <div className="admin-perm-grid">
      {permissions.map((p) => (
        <Checkbox
          key={p.id}
          checked={currentValues.includes(p.id)}
          disabled={isAdmin}
          onChange={(e) => handleCheck(p.id, e.target.checked)}
        >
          {p.label}
        </Checkbox>
      ))}
    </div>
  );
}

function RoleModal({ open, editingRole, permissions, form, onCancel, onSubmit }: RoleModalProps) {
  const isAdmin = editingRole?.id === 'admin';
  const initialValues = editingRole
    ? {
        description: editingRole.description ?? '',
        permissions: editingRole.permissions.includes('*')
          ? permissions.map((p) => p.id)
          : editingRole.permissions.filter((permission) => permissions.some((item) => item.id === permission)),
      }
    : {};

  return (
    <Modal
      title="编辑角色"
      open={open}
      onCancel={onCancel}
      onOk={onSubmit}
      okText="保存角色"
      cancelText="取消"
    >
      <Form
        form={form}
        layout="vertical"
        preserve={false}
        initialValues={initialValues}
        key={editingRole?.id ?? 'new'}
      >
        <Form.Item label="角色名称">
          <Input value={editingRole?.name ?? ''} disabled />
        </Form.Item>
        <Form.Item name="description" label="角色说明">
          <Input.TextArea maxLength={200} rows={3} />
        </Form.Item>
        <Form.Item name="permissions" label="权限范围">
          <PermissionCheckboxes
            permissions={permissions}
            isAdmin={isAdmin}
          />
        </Form.Item>
        <Typography.Text type="secondary">
          {isAdmin
            ? '管理员角色固定拥有全部权限。'
            : '选择该角色可见的页面和可执行的业务操作。'}
        </Typography.Text>
      </Form>
    </Modal>
  );
}