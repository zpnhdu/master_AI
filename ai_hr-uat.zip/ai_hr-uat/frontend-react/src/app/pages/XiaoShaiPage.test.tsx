import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';

import type { ScreeningConfig, ScreeningWorkflow } from '../../features/xiao-shai/api';
import { XiaoShaiPage } from './XiaoShaiPage';

const mocks = vi.hoisted(() => {
  const workflow: ScreeningWorkflow = {
    workflow_status: 'review_pending',
    config: { threshold: 70 },
    counts: { passed: 0, rejected: 1 },
    allowed_actions: ['review_candidates', 'finalize_screening'],
    candidates: [
      {
        id: 'candidate-1',
        name: '张三',
        status: 'rejected',
        overall_score: 88,
        summary: '具备招商主管相关经验',
      },
    ],
  };
  const pipeline = {
    id: 'pipeline-1',
    role: '招商主管',
    agents: ['xiao_wen', 'xiao_xun', 'xiao_shai'],
    stages: [
      { stage_id: 'jd_write', status: 'done', output: {} },
      { stage_id: 'crawl', status: 'done', output: {} },
    ],
    candidates: [{ id: 'candidate-1', name: '张三' }],
  };
  const config: ScreeningConfig = {
    threshold: 70,
  };
  const finalizeMutation = vi.fn();
  const passMutation = vi.fn();
  const executeMutation = vi.fn();
  const workflowRefetch = vi.fn();
  const mutation = () => ({ isPending: false, mutateAsync: vi.fn() });
  return {
    config,
    pipeline,
    workflow,
    mutation,
    executeMutation,
    workflowRefetch,
    finalizeMutation,
    passMutation,
  };
});

vi.mock('../../features/xiao-shai/hooks', () => ({
  useXiaoShaiPipelineQuery: () => ({ data: mocks.pipeline, isPending: false, isError: false }),
  useXiaoShaiWorkflowQuery: () => ({
    data: mocks.workflow,
    isPending: false,
    isError: false,
    refetch: mocks.workflowRefetch,
  }),
  usePreviewScreeningMutation: mocks.mutation,
  useExecuteScreeningMutation: () => ({ isPending: false, mutateAsync: mocks.executeMutation }),
  useReviewScreeningMutation: mocks.mutation,
  useFinalizeScreeningMutation: () => ({ isPending: false, mutateAsync: mocks.finalizeMutation }),
  usePassScreeningMutation: () => ({ isPending: false, mutateAsync: mocks.passMutation }),
}));

vi.mock('../../features/talent-pool/components/ResumePreviewModal', () => ({
  ResumePreviewModal: ({ candidate }: { candidate: { name?: string } | null }) =>
    candidate ? <div>{candidate.name} · 简历预览</div> : null,
}));

afterEach(cleanup);

beforeEach(() => {
  vi.clearAllMocks();
  mocks.workflow.workflow_status = 'review_pending';
  mocks.workflow.config = { threshold: 70 };
  mocks.workflow.counts = { passed: 0, rejected: 1 };
  mocks.workflow.allowed_actions = ['review_candidates', 'finalize_screening'];
  mocks.workflow.pending_count = 1;
  mocks.workflow.candidates = [
    {
      id: 'candidate-1',
      name: '张三',
      status: 'rejected',
      overall_score: 88,
      summary: '具备招商主管相关经验',
    },
  ];
});

describe('XiaoShaiPage', () => {
  it('renders the two-column layout with AI screening controls and results table', { timeout: 15000 }, () => {
    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    expect(screen.getByRole('region', { name: 'AI 初筛' })).toBeInTheDocument();
    expect(screen.getByRole('region', { name: 'screening-results 数据表格' })).toBeInTheDocument();
    expect(screen.getByLabelText('初筛结果')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '预览简历' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '确认并传递给小面' })).toBeInTheDocument();
  });

  it('does not loop while pruning selected candidates', () => {
    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    expect(screen.getAllByText('张三').length).toBeGreaterThan(0);
  });

  it('opens the resume preview from the screening result operation', () => {
    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    fireEvent.click(screen.getByRole('link', { name: '预览简历' }));

    expect(screen.getByText('张三 · 简历预览')).toBeInTheDocument();
  });

  it('allows manual review for an AI-rejected candidate', () => {
    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    const reviewLink = screen.getByRole('link', { name: '人工复核' });
    expect(reviewLink).toBeEnabled();
    fireEvent.click(reviewLink);

    expect(screen.getByText('复核结果')).toBeInTheDocument();
  });

  it('keeps unscored candidates out of manual review', () => {
    mocks.workflow.candidates = [
      {
        id: 'candidate-1',
        name: '张三',
        status: 'rejected',
        overall_score: 45,
      },
      {
        id: 'candidate-new',
        name: '新候选人',
        status: 'new',
        overall_score: 0,
      },
    ];
    mocks.workflow.counts = { passed: 0, rejected: 1 };

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    const reviewLinks = screen.getAllByRole('link', { name: '人工复核' });
    expect(reviewLinks[0]).toBeEnabled();
    expect(reviewLinks[1]).toHaveClass('ant-typography-disabled');
    fireEvent.click(reviewLinks[1]);
    expect(screen.queryByText('人工复核 · 新候选人')).not.toBeInTheDocument();
  });

  it('hydrates the saved threshold and submits the latest threshold', async () => {
    mocks.workflow.config = { threshold: 95 };

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    const thresholdInput = await screen.findByRole('spinbutton');
    expect(thresholdInput).toHaveValue('95');

    fireEvent.change(thresholdInput, { target: { value: '90' } });
    fireEvent.click(screen.getByRole('button', { name: '应用阈值（1人）' }));

    await waitFor(() => {
      expect(mocks.executeMutation).toHaveBeenCalledWith({
        config: { threshold: 90 },
        force: false,
      });
    });
    expect(mocks.workflowRefetch).toHaveBeenCalled();
  });

  it('keeps a high-score candidate with missing information passed and shows a context note', () => {
    mocks.workflow.candidates = [
      {
        id: 'candidate-2',
        name: '李四',
        status: 'passed',
        overall_score: 95,
        model_score: 95,
        missing_info: [{ label: '学历信息缺失', severity: 'important', reason: 'JD要求学历' }],
        reason: '具备相关经验',
      },
    ];
    mocks.workflow.counts = { passed: 1, rejected: 0 };

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    expect(screen.getByText('95 分')).toBeInTheDocument();
    expect(screen.queryByText('-5')).not.toBeInTheDocument();
    expect(screen.getByLabelText('通过：具备相关经验；关注信息缺失：学历信息缺失')).toBeInTheDocument();
    expect(screen.getByTitle('具备相关经验；关注信息缺失：学历信息缺失')).toBeInTheDocument();
  });

  it('does not offer another screening run after all candidates enter the next node', () => {
    mocks.workflow.workflow_status = 'confirmed';
    mocks.workflow.pending_count = 0;
    mocks.workflow.counts = { passed: 1, rejected: 0 };
    mocks.workflow.candidates = [
      {
        id: 'candidate-3',
        name: '王五',
        status: 'passed',
        screening_decision: 'passed',
        overall_score: 95,
      },
    ];

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    const executeButtons = screen.getAllByRole('button', { name: '已完成，无待筛候选人' });
    expect(executeButtons).toHaveLength(2);
    expect(executeButtons.every((button) => (button as HTMLButtonElement).disabled)).toBe(true);
    expect(screen.queryByText('王五')).not.toBeInTheDocument();
  });

  it('shows the model dimension evidence as the score evidence', () => {
    const original = mocks.workflow.candidates;
    mocks.workflow.candidates = [
      {
        id: 'candidate-2',
        name: '李四',
        status: 'rejected',
        overall_score: 65,
        dimension_scores: [
          { key: 'role_fit', label: '岗位匹配', score: 85, evidence: '模型给出的维度证据' },
        ],
      },
    ];
    try {
      render(
        <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
          <XiaoShaiPage />
        </MemoryRouter>,
      );

      expect(screen.getByText('模型给出的维度证据')).toBeInTheDocument();
    } finally {
      mocks.workflow.candidates = original;
    }
  });

  it('does not hand off when finalization has no passed candidates', async () => {
    mocks.finalizeMutation.mockResolvedValueOnce({
      version: 2,
      counts: { passed: 0, rejected: 1 },
      passed_ids: [],
      candidates: [{ id: 'candidate-1', status: 'rejected', overall_score: 40 }],
    });

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    fireEvent.click(screen.getByRole('button', { name: '确认并传递给小面' }));

    await waitFor(() => expect(mocks.finalizeMutation).toHaveBeenCalled());
    expect(mocks.passMutation).not.toHaveBeenCalled();
    expect(await screen.findByText('没有候选人通过小筛，不能进入下游')).toBeInTheDocument();
  });

  it('shows a visible error when handing off screening results fails', async () => {
    mocks.finalizeMutation.mockRejectedValueOnce(new Error('筛选结果尚未完成'));

    render(
      <MemoryRouter initialEntries={['/xiao-shai?pipeline=pipeline-1']}>
        <XiaoShaiPage />
      </MemoryRouter>,
    );

    fireEvent.click(screen.getByRole('button', { name: '确认并传递给小面' }));

    expect(await screen.findByText('筛选结果尚未完成')).toBeInTheDocument();
  });
});
