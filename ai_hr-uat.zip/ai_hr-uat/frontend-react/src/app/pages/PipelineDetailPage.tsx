import { useEffect } from 'react';
import { message } from 'antd';
import { Navigate, useParams, useSearchParams } from 'react-router-dom';

import {
  useAutoRunMutation,
  useKGRecommendationsQuery,
  usePipelineDetailQuery,
} from '../../features/pipeline-detail/hooks';
import {
  buildStagesDict,
  computeOverview,
} from '../../features/pipeline-detail/selectors';
import { HeroHeader } from '../../features/pipeline-detail/components/HeroHeader';
import { OverviewKpis } from '../../features/pipeline-detail/components/OverviewKpis';
import { KGRecommend } from '../../features/pipeline-detail/components/KGRecommend';
import { AgentCardList } from '../../features/pipeline-detail/components/AgentCardList';
import { usePipelineSocketSync } from '../../shared/usePipelineSocket';
import { routePaths } from '../routes/route-paths';

/**
 * 流水线详情页（视觉对齐旧版 pipeline-detail.html）：
 * 独立整页布局——sticky 白色 hero + 灰底滚动主区，不使用 AppShell 侧边栏。
 */
export function PipelineDetailPage() {
  const { pipelineId = '' } = useParams();

  const detailQuery = usePipelineDetailQuery(pipelineId);
  const pipeline = detailQuery.data;
  const kgQuery = useKGRecommendationsQuery(pipeline?.role);
  const autoRunMutation = useAutoRunMutation(pipelineId);
  // 实时链路：阶段事件到达后自动刷新详情/候选人缓存（ISSUE-0-01）
  usePipelineSocketSync(pipelineId);

  useEffect(() => {
    document.title = pipeline?.role ? `${pipeline.role} - 锅圈食汇` : '岗位详情 - 锅圈食汇';
    return () => {
      document.title = '锅圈食汇 - 智能招聘平台';
    };
  }, [pipeline?.role]);

  function handleAutoRun() {
    autoRunMutation.mutate(undefined, {
      onSuccess: () => {
        message.success('自动运行已启动');
      },
      onError: (error) => {
        message.error(error instanceof Error ? error.message : '启动失败');
      },
    });
  }

  return (
    <div className="pipeline-detail-page">
      <HeroHeader
        pipeline={pipeline ?? null}
        onAutoRun={handleAutoRun}
        autoRunning={autoRunMutation.isPending}
      />
      <main className="pd-main">
        {detailQuery.isPending ? (
          <div className="pd-loading">
            <div className="icon">◈</div>
            <div>加载中...</div>
          </div>
        ) : detailQuery.isError || !pipeline ? (
          <div className="pd-error">
            <div className="icon">✕</div>
            <div>
              {detailQuery.error instanceof Error
                ? `加载失败: ${detailQuery.error.message}`
                : '岗位数据加载失败'}
            </div>
            <button type="button" className="pd-btn" onClick={() => detailQuery.refetch()}>
              重试
            </button>
          </div>
        ) : (
          <>
            <OverviewKpis overview={computeOverview(pipeline, buildStagesDict(pipeline.stages))} />
            <KGRecommend recommendations={kgQuery.data ?? []} />
            <AgentCardList pipeline={pipeline} />
          </>
        )}
      </main>
    </div>
  );
}

/** 旧版 `/pipeline-detail?id=xxx` 链接的兼容跳转。 */
export function LegacyPipelineDetailRedirect() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('id');

  if (!pipelineId) {
    return <Navigate to={routePaths.studio} replace />;
  }
  return <Navigate to={routePaths.pipelineDetail(pipelineId)} replace />;
}