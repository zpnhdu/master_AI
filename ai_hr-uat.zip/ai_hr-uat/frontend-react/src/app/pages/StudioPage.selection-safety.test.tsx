import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import dayjs from 'dayjs';
import { MemoryRouter, useLocation } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { AuthProvider } from '../auth/AuthContext';
import { StudioPage } from './StudioPage';

const pipelines = [
  {
    id: 'pipeline-1',
    role: '高级前端工程师',
    status: 'running',
    type: 'tech',
    agents: ['xiao_wen'],
    stages: [{ stage_id: 'jd_write', status: 'running' }],
  },
  {
    id: 'pipeline-2',
    role: '产品经理',
    status: 'running',
    type: 'product',
    agents: ['xiao_wen'],
    stages: [{ stage_id: 'jd_write', status: 'running' }],
  },
];

afterEach(cleanup);
afterEach(() => vi.unstubAllGlobals());

beforeEach(() => {
  vi.stubGlobal(
    'ResizeObserver',
    class ResizeObserverMock {
      observe() {}

      unobserve() {}

      disconnect() {}
    },
  );
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(new Response(JSON.stringify(pipelines), { status: 200 })),
  );
});

function LocationProbe() {
  const location = useLocation();

  return <output data-testid="location-search">{location.search}</output>;
}

function renderStudio(initialEntry = '/studio?page=2') {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntdApp>
          <AuthProvider>
            <StudioPage />
          </AuthProvider>
          <LocationProbe />
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('StudioPage date preset and selection safety', () => {
  it('offers a seven-day preset that includes today and clears the page query', async () => {
    renderStudio();

    await screen.findByText('高级前端工程师');
    const startDateInput = screen.getByPlaceholderText('开始日期');
    fireEvent.focus(startDateInput);
    fireEvent.click(startDateInput);
    fireEvent.click(await screen.findByText('近七天'));

    const expectedFrom = dayjs().subtract(6, 'day').format('YYYY-MM-DD');
    const expectedTo = dayjs().format('YYYY-MM-DD');
    await waitFor(() => {
      const query = new URLSearchParams(screen.getByTestId('location-search').textContent ?? '');
      expect(query.get('created_from')).toBe(expectedFrom);
      expect(query.get('created_to')).toBe(expectedTo);
      expect(query.has('page')).toBe(false);
    });
  }, 15000);

  it('keeps selection actions in the card header without inserting a batch bar', async () => {
    renderStudio('/studio');

    fireEvent.click(await screen.findByRole('checkbox', { name: '全选当前页' }));

    expect(document.querySelector('.studio-page__batch-bar')).not.toBeInTheDocument();
    const controls = document.querySelector('.studio-page__selection-controls');
    expect(controls).toHaveTextContent('已选 2 条');
    expect(controls).toContainElement(screen.getByRole('button', { name: '清空选择' }));

    const deleteButton = screen.getByRole('button', { name: /批量删除/ });
    expect(controls).toContainElement(deleteButton);
    expect(deleteButton).not.toHaveClass('ant-btn-primary');
    expect(deleteButton).toHaveAttribute('title', expect.stringContaining('再次确认'));
    expect(deleteButton).toHaveAccessibleDescription('点击后需在确认框中再次确认');

    const fetchMock = vi.mocked(fetch);
    fireEvent.click(deleteButton);
    expect(await screen.findByText('确定删除选中的 2 条岗位？此操作不可恢复。')).toBeInTheDocument();
    expect(fetchMock.mock.calls.some(([, options]) => options?.method === 'DELETE')).toBe(false);
  }, 15000);

  it('clears the current selection from the stable controls', async () => {
    renderStudio('/studio');

    fireEvent.click(await screen.findByRole('checkbox', { name: '全选当前页' }));
    fireEvent.click(screen.getByRole('button', { name: '清空选择' }));

    expect(screen.queryByText('已选 2 条')).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /批量删除/ })).not.toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: '全选当前页' })).not.toBeChecked();
    expect(document.querySelector('.studio-page__selection-controls')).toBeInTheDocument();
  }, 15000);
});
