import {
  Alert,
  Button,
  Card,
  Empty,
  Input,
  List,
  Modal,
  Pagination,
  Popconfirm,
  Space,
  Spin,
  Tag,
  Typography,
  Upload,
  message,
} from 'antd';
import { useIsFetching, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';

import { PageShell } from '../components/PageShell';
import { PageTabs } from '../../shared/components/PageTabs';
import {
  deleteWikiSource,
  fetchWikiGraph,
  fetchWikiPage,
  fetchWikiSources,
  fetchWikiTree,
  reprocessWikiSource,
  streamWikiChat,
  uploadWikiSources,
  type WikiCiteSource,
  type WikiGraph,
  type WikiSource,
  type WikiTree,
} from '../../features/knowledge/api';
import {
  WIKI_TYPE_COLORS,
  WIKI_TYPE_EMOJIS,
  WIKI_TYPE_LABELS,
  WIKI_TYPE_MARKS,
  WIKI_TYPE_USER_LABELS,
  WIKI_VISIBLE_TYPE_ORDER,
} from '../../features/knowledge/wikiGraphConstants';
import { MATERIAL_LIBRARY_QUERY_KEY } from '../../features/material-library/api';
import type { MaterialKind } from '../../features/material-library/api';
import { ListSearch } from '../../shared/list-workbench';

const DEFAULT_PAGE_PATH = 'wiki/index.md';
const WIKI_PAGE_STALE_TIME = 5 * 60 * 1000;
const WIKI_GRAPH_STALE_TIME = 5 * 60 * 1000;
const WIKI_TREE_STALE_TIME = 5 * 60 * 1000;
const WikiGraphCanvas = lazy(() =>
  import('../../features/knowledge/WikiGraphCanvas').then(({ WikiGraphCanvas: Component }) => ({ default: Component })),
);
const WikiPageViewer = lazy(() =>
  import('../../features/knowledge/WikiPageViewer').then(({ WikiPageViewer: Component }) => ({ default: Component })),
);
const MaterialLibrary = lazy(() =>
  import('../../features/material-library/MaterialLibrary').then(({ MaterialLibrary: Component }) => ({ default: Component })),
);

type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
  sources?: WikiCiteSource[];
};

type ViewMode = 'browse' | 'graph';

export function KnowledgePage() {
  return <KnowledgeContent />;
}

function KnowledgeContent() {
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();
  const isMaterialLibrary = searchParams.get('tab') === 'materials';
  const [materialTab, setMaterialTab] = useState<MaterialKind>('backgrounds');
  const materialIsFetching = useIsFetching({ queryKey: MATERIAL_LIBRARY_QUERY_KEY }) > 0;
  const treeQuery = useQuery({
    queryKey: ['wiki', 'tree'],
    queryFn: fetchWikiTree,
    staleTime: WIKI_TREE_STALE_TIME,
    enabled: !isMaterialLibrary,
  });
  const [activePath, setActivePath] = useState<string>(DEFAULT_PAGE_PATH);
  const [viewMode, setViewMode] = useState<ViewMode>('graph');
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [manageOpen, setManageOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailPath, setDetailPath] = useState('');

  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [focusRequestId, setFocusRequestId] = useState(0);
  const [visibleTypes, setVisibleTypes] = useState<Set<string>>(
    () => new Set(WIKI_VISIBLE_TYPE_ORDER.filter((type) => type !== 'source')),
  );

  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const isInput = event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement;
      if ((event.key === 'k' || event.key === 'K') && (event.metaKey || event.ctrlKey) && !isInput) {
        event.preventDefault();
        setChatOpen((value) => !value);
      }
      if (event.key === 'Escape') {
        setChatOpen(false);
        setUploadOpen(false);
        setManageOpen(false);
        setDetailOpen(false);
        setSelectedNodeId(null);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  useEffect(() => {
    return () => {
      if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    };
  }, []);

  useEffect(() => {
    return () => {
      setSelectedNodeId(null);
    };
  }, []);

  const tree = treeQuery.data;

  const allEntries = useMemo(() => {
    const out: Array<{ type: string; slug: string; title: string; path: string }> = [];
    for (const [type, pages] of Object.entries(tree?.tree ?? {})) {
      for (const page of pages) {
        out.push({ type, slug: page.slug, title: page.title, path: page.path });
      }
    }
    return out;
  }, [tree?.tree]);

  const typeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const entry of allEntries) {
      counts[entry.type] = (counts[entry.type] ?? 0) + 1;
    }
    return counts;
  }, [allEntries]);

  const filteredEntries = useMemo(() => {
    const query = search.trim().toLowerCase();
    let result = allEntries;
    if (typeFilter) {
      result = result.filter((entry) => entry.type === typeFilter);
    }
    if (query) {
      result = result.filter((entry) => `${entry.title} ${entry.slug}`.toLowerCase().includes(query));
    }
    return result;
  }, [allEntries, search, typeFilter]);

  const graphQuery = useQuery({
    queryKey: ['wiki', 'graph'],
    queryFn: fetchWikiGraph,
    staleTime: WIKI_GRAPH_STALE_TIME,
    enabled: viewMode === 'graph' && !isMaterialLibrary,
    refetchOnWindowFocus: false,
  });

  const graph = graphQuery.data;

  const handleCardClick = (slug: string) => {
    setDetailPath(`wiki/${slug}.md`);
    setDetailOpen(true);
  };

  const handleGraphSelectNode = (nodeId: string | null) => {
    setSelectedNodeId(nodeId);
    if (nodeId) {
      setDetailPath(`wiki/${nodeId}.md`);
      setDetailOpen(true);
    }
  };

  const handleOpenDocument = (nodeId: string) => {
    setDetailPath(`wiki/${nodeId}.md`);
    setDetailOpen(true);
  };

  const focusNodeInGraph = (nodeId: string) => {
    setViewMode('graph');
    setSelectedNodeId(nodeId);
    setFocusRequestId((current) => current + 1);
  };

  const toggleType = (type: string) => {
    setVisibleTypes((current) => {
      const next = new Set(current);
      if (next.has(type)) {
        next.delete(type);
      } else {
        next.add(type);
      }
      return next;
    });
  };

  const toggleSource = () => {
    setVisibleTypes((current) => {
      const next = new Set(current);
      if (next.has('source')) {
        next.delete('source');
      } else {
        next.add('source');
      }
      return next;
    });
  };

  return (
    <PageShell
      title={isMaterialLibrary ? '素材库' : '知识库'}
      headerExtra={
        isMaterialLibrary ? (
          <Space size={12}>
            <PageTabs
              value={materialTab}
              onChange={(v) => setMaterialTab(v as MaterialKind)}
              options={[
                { label: '背景图', value: 'backgrounds' },
                { label: '装饰元素', value: 'elements' },
              ]}
            />
            <Button
              loading={materialIsFetching}
              onClick={() => void queryClient.refetchQueries({ queryKey: MATERIAL_LIBRARY_QUERY_KEY })}
            >
              刷新素材
            </Button>
          </Space>
        ) : undefined
      }
    >
      {!isMaterialLibrary ? (
        <div className="knowledge-page">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <Space size={14}>
              <ListSearch
                id="wiki-search-input"
                placeholder="搜索知识内容…"
                value={search}
                onChange={(value) => { setSearch(value); setSelectedNodeId(null); }}
                debounceMs={300}
                className="knowledge-page__search"
              />
              <Button type="primary" onClick={() => setUploadOpen(true)}>
                ＋ 上传资料
              </Button>
              <Button onClick={() => setManageOpen(true)}>管理资料</Button>
            </Space>
            <PageTabs
              value={viewMode}
              onChange={(v) => {
              const mode = v as ViewMode;
              setViewMode(mode);
              setSelectedNodeId(null);
            }}
              options={[
                { label: '浏览知识', value: 'browse' },
                { label: '知识图谱', value: 'graph' },
              ]}
            />
          </div>

          {viewMode === 'browse' && (
            <KnowledgeGrid
              tree={tree}
              entries={filteredEntries}
              typeCounts={typeCounts}
              typeFilter={typeFilter}
              onTypeFilter={setTypeFilter}
              search={search}
              onCardClick={handleCardClick}
              totalCount={allEntries.length}
            />
          )}

          {viewMode === 'graph' && (
            <div className="knowledge-page__body knowledge-page__body--graph">
              <GraphView
                graphQuery={graphQuery}
                graph={graph}
                search={search}
                visibleTypes={visibleTypes}
                selectedNodeId={selectedNodeId}
                focusRequestId={focusRequestId}
                onSelectNode={handleGraphSelectNode}
              />
            </div>
          )}
        </div>
      ) : (
        <Suspense fallback={<KnowledgeLazyFallback label="加载中" />}>
          <MaterialLibrary hideHeader activeTab={materialTab} />
        </Suspense>
      )}

      {!isMaterialLibrary ? (
        <KnowledgeChat
          open={chatOpen}
          onToggle={() => setChatOpen((value) => !value)}
          onOpenPage={(slug) => {
            setDetailPath(`wiki/${slug}.md`);
            setDetailOpen(true);
          }}
        />
      ) : null}

      <UploadWikiModal open={uploadOpen} onClose={() => setUploadOpen(false)} />
      <WikiSourceManageModal open={manageOpen} onClose={() => setManageOpen(false)} />
      <KnowledgeDetailModal
        open={detailOpen}
        path={detailPath}
        onClose={() => setDetailOpen(false)}
        onNavigate={(slug) => setDetailPath(`wiki/${slug}.md`)}
        onFocusGraph={(nodeId) => {
          setDetailOpen(false);
          focusNodeInGraph(nodeId);
        }}
      />
    </PageShell>
  );
}

function KnowledgeGrid({
  tree,
  entries,
  typeCounts,
  typeFilter,
  onTypeFilter,
  search,
  onCardClick,
  totalCount,
}: {
  tree?: WikiTree;
  entries: Array<{ type: string; slug: string; title: string; path: string }>;
  typeCounts: Record<string, number>;
  typeFilter: string;
  onTypeFilter: (type: string) => void;
  search: string;
  onCardClick: (slug: string) => void;
  totalCount: number;
}) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(16);

  useEffect(() => {
    setPage(1);
  }, [search, typeFilter]);

  if (!tree) {
    return <div className="knowledge-page__loading"><Spin size="large" description="加载中" /></div>;
  }

  const paginatedEntries = entries.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="knowledge-grid">
      <div className="knowledge-grid__filters">
        <button
          type="button"
          className={`knowledge-grid__filter-btn${!typeFilter ? ' knowledge-grid__filter-btn--active' : ''}`}
          onClick={() => onTypeFilter('')}
        >
          全部 ({totalCount})
        </button>
        {Object.entries(WIKI_TYPE_USER_LABELS).map(([type, label]) => {
          const count = typeCounts[type] ?? 0;
          if (count === 0) return null;
          return (
            <button
              key={type}
              type="button"
              className={`knowledge-grid__filter-btn${typeFilter === type ? ' knowledge-grid__filter-btn--active' : ''}`}
              onClick={() => onTypeFilter(typeFilter === type ? '' : type)}
            >
              <i style={{ background: WIKI_TYPE_COLORS[type] }} />
              {WIKI_TYPE_EMOJIS[type]} {label} ({count})
            </button>
          );
        })}
      </div>

      {entries.length === 0 ? (
        <div className="knowledge-grid__empty">
          <Empty description={search ? '未找到匹配的知识' : '暂无知识内容'} image={Empty.PRESENTED_IMAGE_SIMPLE} />
        </div>
      ) : (
        <>
          <div className="knowledge-grid__cards">
            {paginatedEntries.map((entry) => (
              <Card
                key={entry.slug}
                className="knowledge-card"
                hoverable
                onClick={() => onCardClick(entry.slug)}
              >
                <div className="knowledge-card__type">
                  <Tag color={WIKI_TYPE_COLORS[entry.type] ?? 'default'}>
                    {WIKI_TYPE_EMOJIS[entry.type]} {WIKI_TYPE_USER_LABELS[entry.type] ?? WIKI_TYPE_LABELS[entry.type] ?? entry.type}
                  </Tag>
                </div>
                <Typography.Title level={5} className="knowledge-card__title">
                  {entry.title}
                </Typography.Title>
                <Typography.Text type="secondary" className="knowledge-card__desc">
                  {entry.slug}
                </Typography.Text>
              </Card>
            ))}
          </div>
          <Pagination
            className="knowledge-grid__pagination"
            current={page}
            pageSize={pageSize}
            total={entries.length}
            showSizeChanger
            pageSizeOptions={[16, 32, 48]}
            showTotal={(total) => `共 ${total} 篇`}
            locale={{ items_per_page: '/ 页' }}
            onChange={(p, ps) => { setPage(p); setPageSize(ps); }}
          />
        </>
      )}
    </div>
  );
}

function Sidebar({
  tree,
  activePath,
  onSelect,
  search,
  onSearch,
  visibleTypes,
  onToggleType,
  onToggleSource,
}: {
  tree?: WikiTree;
  activePath: string;
  onSelect: (path: string) => void;
  search: string;
  onSearch: (value: string) => void;
  visibleTypes: Set<string>;
  onToggleType: (type: string) => void;
  onToggleSource: () => void;
}) {
  return (
    <nav className="knowledge-page__filters" aria-label="知识库筛选">
      <Input.Search
        placeholder="搜索知识…"
        allowClear
        value={search}
        onChange={(event) => onSearch(event.target.value)}
        style={{ marginBottom: 12 }}
      />
      <div className="knowledge-page__type-filters">
        <Typography.Text strong style={{ fontSize: 12 }}>类型</Typography.Text>
        {WIKI_VISIBLE_TYPE_ORDER.map((type) => {
          const count = tree?.tree?.[type]?.length ?? 0;
          return (
            <button
              key={type}
              type="button"
              className={`knowledge-filter${visibleTypes.has(type) ? ' knowledge-filter--active' : ''}`}
              onClick={() => onToggleType(type)}
            >
              <i style={{ background: WIKI_TYPE_COLORS[type] }} />
              <span>{WIKI_TYPE_EMOJIS[type] ?? ''} {WIKI_TYPE_USER_LABELS[type] ?? WIKI_TYPE_LABELS[type] ?? type}</span>
              <span className="knowledge-filter__count">{count}</span>
            </button>
          );
        })}
        <button
          type="button"
          className={`knowledge-filter${visibleTypes.has('source') ? ' knowledge-filter--active' : ''}`}
          onClick={onToggleSource}
        >
          <i style={{ background: WIKI_TYPE_COLORS.source }} />
          <span>{WIKI_TYPE_EMOJIS.source ?? ''} {WIKI_TYPE_USER_LABELS.source ?? '来源'}</span>
          <span className="knowledge-filter__count">{tree?.tree?.source?.length ?? 0}</span>
        </button>
      </div>
      <div className="knowledge-page__tree">
        {tree?.tree ? (
          <div className="knowledge-page__tree-scroll">
            {Object.entries(tree.tree).map(([type, pages]) =>
              pages.map((page) => (
                <div
                  key={page.slug}
                  className={`knowledge-page__tree-item${activePath === `wiki/${page.path}` ? ' knowledge-page__tree-item--active' : ''}`}
                  onClick={() => onSelect(`wiki/${page.path}`)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') onSelect(`wiki/${page.path}`);
                  }}
                >
                  <Tag color={WIKI_TYPE_COLORS[type] ?? 'default'}>{WIKI_TYPE_EMOJIS[type] ?? ''}</Tag>
                  <span>{page.title}</span>
                </div>
              )),
            )}
          </div>
        ) : (
          <Spin description="加载知识树" />
        )}
      </div>
    </nav>
  );
}

function GraphView({
  graphQuery,
  graph,
  search,
  visibleTypes,
  selectedNodeId,
  focusRequestId,
  onSelectNode,
}: {
  graphQuery: ReturnType<typeof useQuery<WikiGraph>>;
  graph?: WikiGraph;
  search: string;
  visibleTypes: Set<string>;
  selectedNodeId: string | null;
  focusRequestId: number;
  onSelectNode: (nodeId: string | null) => void;
}) {
  return (
    <div className="knowledge-page__graph">
      {graphQuery.isPending ? (
        <div className="knowledge-page__loading">
          <Spin size="large" description="加载图谱" />
        </div>
      ) : graphQuery.isError || !graph ? (
        <div className="knowledge-page__loading">
          <Alert type="error" showIcon message="图谱加载失败" action={<Button onClick={() => void graphQuery.refetch()}>重试</Button>} />
        </div>
      ) : graph.nodes.length ? (
        <Suspense fallback={<KnowledgeLazyFallback label="加载中" />}>
          <WikiGraphCanvas
            nodes={graph.nodes}
            edges={graph.edges}
            visibleTypes={visibleTypes}
            search={search}
            focusNodeId={selectedNodeId}
            focusRequestId={focusRequestId}
            onSelectNode={onSelectNode}
          />
        </Suspense>
      ) : (
        <div className="knowledge-page__loading">
          <Empty description="暂无页面，先上传资料或导入图谱" />
        </div>
      )}
    </div>
  );
}

function KnowledgeDetails({
  graph,
  selectedNodeId,
  visibleTypes,
  onToggleSource,
  onSelectNode,
  onFocusNode,
  onOpenDocument,
}: {
  graph?: WikiGraph;
  selectedNodeId: string | null;
  visibleTypes: Set<string>;
  onToggleSource: () => void;
  onSelectNode: (nodeId: string | null) => void;
  onFocusNode: (nodeId: string) => void;
  onOpenDocument: (nodeId: string) => void;
}) {
  const node = graph?.nodes.find((item) => item.id === selectedNodeId);

  if (!selectedNodeId || !node) {
    return (
      <aside className="knowledge-page__details" aria-label="知识图谱概览">
        <div className="knowledge-details__overview">
          <Typography.Title level={4} style={{ marginTop: 0 }}>图谱概览</Typography.Title>
          <div className="knowledge-details__metrics">
            <span><strong>{graph?.nodes.length ?? 0}</strong> 个节点</span>
            <span><strong>{graph?.edges.length ?? 0}</strong> 条关系</span>
            <span><strong>{visibleTypes.size}</strong> 类可见</span>
          </div>
          <Typography.Paragraph type="secondary">选择一个节点查看详情，并在右侧快速跳转关联知识。</Typography.Paragraph>
          {!visibleTypes.has('source') ? (
            <Button type="link" className="knowledge-details__source-toggle" onClick={onToggleSource}>
              显示来源节点
            </Button>
          ) : (
            <Typography.Text type="secondary" className="knowledge-details__source-note">来源节点已显示</Typography.Text>
          )}
        </div>
      </aside>
    );
  }

  return (
    <NodeDetails
      key={node.id}
      node={node}
      graph={graph}
      onClose={() => onSelectNode(null)}
      onSelectNode={onSelectNode}
      onFocusNode={onFocusNode}
      onOpenDocument={onOpenDocument}
    />
  );
}

function NodeDetails({
  node,
  graph,
  onClose,
  onSelectNode,
  onFocusNode,
  onOpenDocument,
}: {
  node: NonNullable<WikiGraph>['nodes'][number];
  graph?: WikiGraph;
  onClose: () => void;
  onSelectNode: (nodeId: string | null) => void;
  onFocusNode: (nodeId: string) => void;
  onOpenDocument: (nodeId: string) => void;
}) {
  const pageQuery = useQuery({
    queryKey: ['wiki', 'page', node.id],
    queryFn: () => fetchWikiPage(node.id),
    staleTime: WIKI_PAGE_STALE_TIME,
    refetchOnWindowFocus: false,
  });

  if (pageQuery.isPending) {
    return <aside className="knowledge-page__details knowledge-page__details--drawer" aria-label="节点详情"><div className="knowledge-details__loading"><Spin description="加载节点详情" /></div></aside>;
  }
  if (pageQuery.isError || !pageQuery.data) {
    return (
      <aside className="knowledge-page__details knowledge-page__details--drawer" aria-label="节点详情">
        <div className="knowledge-details__header"><Typography.Title level={4} ellipsis={{ tooltip: node.name }}>{node.name}</Typography.Title><Button type="text" aria-label="关闭节点详情" onClick={onClose}>✕</Button></div>
        <Alert type="error" showIcon message="详情加载失败" action={<Button onClick={() => void pageQuery.refetch()}>重试</Button>} />
      </aside>
    );
  }

  const page = pageQuery.data;
  const frontmatter = page.frontmatter ?? {};
  const title = typeof frontmatter.title === 'string' && frontmatter.title ? frontmatter.title : node.name;
  const type = typeof frontmatter.type === 'string' ? frontmatter.type : node.type;
  const updated = typeof frontmatter.updated === 'string' ? frontmatter.updated : typeof frontmatter.created === 'string' ? frontmatter.created : '';
  const summary = wikiPageSummary(page.body, frontmatter);
  const tags = normalizeStrings(frontmatter.tags);
  const sources = normalizeStrings(frontmatter.sources);
  const coreSections = [
    ['关键规则', normalizeStrings(frontmatter.rules)],
    ['方法步骤', normalizeStrings(frontmatter.methods ?? frontmatter.steps)],
    ['适用场景', normalizeStrings(frontmatter.scenarios ?? frontmatter.scenes)],
  ].filter(([, values]) => values.length > 0) as Array<[string, string[]]>;
  const related = [...new Set([...page.wikilinks, ...page.related, ...page.backlinks.map((item) => item.slug)])]
    .filter((slug) => slug && slug !== node.id)
    .map((slug) => {
      const graphNode = graph?.nodes.find((item) => item.id === slug || item.id.endsWith(`/${slug}`));
      return { id: graphNode?.id ?? slug, name: graphNode?.name ?? slug };
    });

  return (
    <aside className="knowledge-page__details knowledge-page__details--drawer" aria-label="节点详情">
      <div className="knowledge-details__header">
        <div className="knowledge-details__heading">
          <Typography.Title level={4} ellipsis={{ tooltip: title }}>{title}</Typography.Title>
          <Space size={6} wrap>
            <Tag color={WIKI_TYPE_COLORS[type] ?? 'default'}>{WIKI_TYPE_EMOJIS[type]} {WIKI_TYPE_USER_LABELS[type] ?? WIKI_TYPE_LABELS[type] ?? type}</Tag>
            {updated ? <Typography.Text type="secondary">更新于 {updated}</Typography.Text> : null}
          </Space>
        </div>
        <Button type="text" aria-label="关闭节点详情" onClick={onClose}>✕</Button>
      </div>
      <div className="knowledge-details__body">
        <Typography.Paragraph>{summary || '暂无摘要，可打开完整文档查看内容。'}</Typography.Paragraph>
        {tags.length ? <Space wrap size={4}>{tags.map((tag) => <Tag key={tag}>{tag}</Tag>)}</Space> : null}
        {coreSections.map(([label, values]) => (
          <section key={label} className="knowledge-details__section">
            <Typography.Text strong>{label}</Typography.Text>
            <ul>{values.map((value) => <li key={value}>{value}</li>)}</ul>
          </section>
        ))}
        {related.length ? (
          <section className="knowledge-details__section">
            <Typography.Text strong>关联知识</Typography.Text>
            <div className="knowledge-details__related">
              {related.map((item) => <Button key={item.id} type="link" onClick={() => onSelectNode(item.id)}>{item.name}</Button>)}
            </div>
          </section>
        ) : null}
        {sources.length ? (
          <section className="knowledge-details__section">
            <Typography.Text strong>来源</Typography.Text>
            <Typography.Paragraph type="secondary">{sources.join('、')}</Typography.Paragraph>
          </section>
        ) : null}
      </div>
      <div className="knowledge-details__actions">
        <Button title="在图谱中居中并放大当前节点" onClick={() => onFocusNode(node.id)}>在图谱中定位</Button>
        <Button type="primary" onClick={() => onOpenDocument(node.id)}>打开完整文档</Button>
      </div>
    </aside>
  );
}

function normalizeStrings(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === 'string' && item.trim().length > 0);
  if (typeof value === 'string' && value.trim()) return [value];
  return [];
}

function wikiPageSummary(body: string, frontmatter: Record<string, unknown>): string {
  for (const key of ['summary', 'description', 'definition', 'excerpt']) {
    if (typeof frontmatter[key] === 'string' && frontmatter[key].trim()) return frontmatter[key].trim();
  }
  const paragraph = body
    .split(/\n\s*\n/)
    .map((item) => item.replace(/^#+\s*/gm, '').replace(/^[-*]\s+/gm, '').replace(/[`*_]/g, '').trim())
    .find((item) => item.length > 0 && !item.startsWith('---'));
  return paragraph ? paragraph.slice(0, 240) : '';
}

function KnowledgeDetailModal({
  open,
  path,
  onClose,
  onNavigate,
  onFocusGraph,
}: {
  open: boolean;
  path: string;
  onClose: () => void;
  onNavigate: (slug: string) => void;
  onFocusGraph: (nodeId: string) => void;
}) {
  if (!path) return null;

  return (
    <Modal
      title={null}
      open={open}
      onCancel={onClose}
      footer={null}
      width={860}
      destroyOnHidden
      className="knowledge-detail-modal"
      styles={{ body: { maxHeight: '70vh', overflow: 'auto', padding: '32px 40px' } }}
    >
      <PageReaderContent
        path={path}
        onNavigate={onNavigate}
        onFocusGraph={onFocusGraph}
      />
    </Modal>
  );
}

function PageReaderContent({
  path,
  onNavigate,
  onFocusGraph,
}: {
  path: string;
  onNavigate: (slug: string) => void;
  onFocusGraph: (nodeId: string) => void;
}) {
  const pageQuery = useQuery({
    queryKey: ['wiki', 'page', path],
    queryFn: () => fetchWikiPage(path),
    staleTime: WIKI_PAGE_STALE_TIME,
  });
  const page = pageQuery.data;

  if (pageQuery.isPending) {
    return <div className="knowledge-page__loading"><Spin size="large" description="加载中" /></div>;
  }
  if (pageQuery.isError || !page) {
    return (
      <div className="knowledge-page__loading">
        <Alert
          type="error"
          showIcon
          message="页面加载失败"
          description={pageQuery.error instanceof Error ? pageQuery.error.message : '请稍后重试'}
          action={<Button onClick={() => void pageQuery.refetch()}>重试</Button>}
        />
      </div>
    );
  }

  const fm = page.frontmatter ?? {};
  const type = typeof fm.type === 'string' ? fm.type : 'concept';
  const tags = Array.isArray(fm.tags) ? (fm.tags as string[]) : typeof fm.tags === 'string' ? [fm.tags] : [];
  const sources = Array.isArray(fm.sources) ? (fm.sources as string[]) : typeof fm.sources === 'string' ? [fm.sources] : [];

  const title = typeof fm.title === 'string' && fm.title ? fm.title : page.slug;

  return (
    <div className="knowledge-detail">
      <div className="knowledge-detail__header">
        <div className="knowledge-detail__type-row">
          <Tag color={WIKI_TYPE_COLORS[type] ?? 'default'} className="knowledge-detail__type-tag">
            {WIKI_TYPE_EMOJIS[type]} {WIKI_TYPE_USER_LABELS[type] ?? WIKI_TYPE_LABELS[type] ?? type}
          </Tag>
          <Button
            className="knowledge-detail__graph-btn"
            onClick={() => onFocusGraph(page.slug)}
          >
            🔍 查看关联图谱
          </Button>
        </div>
        <Typography.Title level={3} className="knowledge-detail__title">
          {title}
        </Typography.Title>
        {tags.length ? (
          <Space wrap size={4} className="knowledge-detail__tags">
            {tags.map((tag) => (
              <Tag key={tag}>{tag}</Tag>
            ))}
          </Space>
        ) : null}
        {sources.length ? (
          <Typography.Text type="secondary" className="knowledge-detail__source">
            <span className="knowledge-detail__source-icon">📎</span>
            参考来源：{sources.join('、')}
          </Typography.Text>
        ) : null}
      </div>

      <div className="knowledge-detail__body">
        <Suspense fallback={<KnowledgeLazyFallback label="加载中" />}>
          <WikiPageViewer body={page.body} onNavigate={onNavigate} />
        </Suspense>
      </div>

      {(page.wikilinks.length > 0 || page.related.length > 0) ? (
        <div className="knowledge-detail__related">
          <Typography.Text strong className="knowledge-detail__section-title">📖 相关推荐</Typography.Text>
          <Space wrap size={4} style={{ marginTop: 8 }}>
            {[...new Set([...page.wikilinks, ...page.related])].map((slug) => (
              <Tag
                key={slug}
                color="blue"
                className="knowledge-detail__link-tag"
                onClick={() => onNavigate(slug)}
              >
                {slug}
              </Tag>
            ))}
          </Space>
        </div>
      ) : null}

      {page.backlinks.length > 0 ? (
        <div className="knowledge-detail__backlinks">
          <Typography.Text strong className="knowledge-detail__section-title">🔗 引用本文的知识</Typography.Text>
          <Space wrap size={4} style={{ marginTop: 8 }}>
            {page.backlinks.map((backlink) => (
              <Tag
                key={backlink.slug}
                color="geekblue"
                className="knowledge-detail__link-tag"
                onClick={() => onNavigate(backlink.slug)}
              >
                {backlink.title}
              </Tag>
            ))}
          </Space>
        </div>
      ) : null}
    </div>
  );
}

function KnowledgeLazyFallback({ label }: { label: string }) {
  return <div className="knowledge-page__loading"><Spin size="large" description={label} /></div>;
}

function KnowledgeChat({
  open,
  onToggle,
  onOpenPage,
}: {
  open: boolean;
  onToggle: () => void;
  onOpenPage: (slug: string) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
  }, [messages, open]);

  useEffect(() => () => abortRef.current?.abort(), []);

  async function send() {
    const question = input.trim();
    if (!question || streaming) return;
    setInput('');
    setStreaming(true);
    setMessages((current) => [...current, { role: 'user', content: question }, { role: 'assistant', content: '' }]);
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      await streamWikiChat(
        question,
        6,
        (chunk) => {
          if (chunk.type === 'content') {
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last?.role === 'assistant') next[next.length - 1] = { ...last, content: last.content + chunk.content };
              return next;
            });
          } else if (chunk.type === 'sources') {
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last?.role === 'assistant') next[next.length - 1] = { ...last, sources: chunk.sources };
              return next;
            });
          } else if (chunk.type === 'done') {
            setMessages((current) => {
              const next = [...current];
              const last = next[next.length - 1];
              if (last?.role === 'assistant') next[next.length - 1] = { ...last, sources: chunk.sources };
              return next;
            });
          } else if (chunk.type === 'error') {
            message.error(chunk.error);
          }
        },
        controller.signal,
      );
    } catch (error) {
      if (!controller.signal.aborted) {
        message.error(error instanceof Error ? error.message : '知识问答失败');
      }
    } finally {
      setStreaming(false);
    }
  }

  return (
    <>
      <button type="button" className="knowledge-chat__fab" aria-label="知识问答" onClick={onToggle}>
        💬
      </button>
      {open ? (
        <Card
          className="knowledge-chat"
          title="知识库问答"
          size="small"
          extra={
            <Button type="text" size="small" onClick={onToggle}>
              ✕
            </Button>
          }
        >
          <div ref={listRef} className="knowledge-chat__messages">
            {!messages.length ? (
              <Typography.Text type="secondary">向知识库提问，例如「如何设计面试问题？」</Typography.Text>
            ) : null}
            {messages.map((item, index) => (
              <div key={index} className={`knowledge-chat__bubble knowledge-chat__bubble--${item.role}`}>
                <Typography.Paragraph style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{item.content}</Typography.Paragraph>
                {item.sources?.length ? (
                  <Space wrap size={4} style={{ marginTop: 6 }}>
                    {item.sources.map((source) => (
                      <Tag
                        key={source.slug}
                        color="blue"
                        style={{ cursor: 'pointer' }}
                        onClick={() => onOpenPage(source.slug)}
                      >
                        {source.title || source.slug}
                      </Tag>
                    ))}
                  </Space>
                ) : null}
              </div>
            ))}
            {streaming ? <Spin size="small" /> : null}
          </div>
          <Space.Compact style={{ width: '100%' }}>
            <Input
              placeholder="输入问题…"
              value={input}
              onChange={(event) => setInput(event.target.value)}
              onPressEnter={() => void send()}
              disabled={streaming}
            />
            <Button type="primary" onClick={() => void send()} loading={streaming}>
              发送
            </Button>
          </Space.Compact>
        </Card>
      ) : null}
    </>
  );
}

function UploadWikiModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const queryClient = useQueryClient();
  const [files, setFiles] = useState<File[]>([]);

  const uploadMutation = useMutation({
    mutationFn: (fileList: File[]) => uploadWikiSources(fileList),
    onSuccess: (result) => {
      message.success(`已上传 ${result.sources?.length ?? 0} 个资料，解析中`);
      setFiles([]);
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'sources'] });
    },
    onError: (error) => message.error(error instanceof Error ? error.message : '上传失败'),
  });

  return (
    <Modal title="上传资料" open={open} onCancel={onClose} footer={null} width={680}>
      <Typography.Paragraph type="secondary">
        系统会保存你上传的文件并自动读取，解析后的内容会生成知识页面。完成后可在“浏览知识”和“知识图谱”中查看；已上传文件请点击“管理资料”查看、重试或删除。
      </Typography.Paragraph>
      <Upload.Dragger
        multiple
        accept=".pdf,.docx,.txt,.md"
        fileList={files.map((file) => ({ uid: file.name, name: file.name }))}
        beforeUpload={(file) => {
          if (file.size > 20 * 1024 * 1024) {
            message.error(`${file.name} 超过 20MB 限制`);
            return Upload.LIST_IGNORE;
          }
          setFiles((current) => [...current, file]);
          return false;
        }}
        onRemove={(file) => setFiles((current) => current.filter((item) => item.name !== file.name))}
      >
        <p>拖拽或点击上传资料</p>
        <Typography.Text type="secondary">支持 PDF / DOCX / TXT / MD，单个文件不超过 20MB</Typography.Text>
      </Upload.Dragger>
      <Space style={{ margin: '12px 0 16px' }}>
        <Button
          type="primary"
          disabled={!files.length}
          loading={uploadMutation.isPending}
          onClick={() => uploadMutation.mutate(files)}
        >
          上传并解析
        </Button>
      </Space>
    </Modal>
  );
}

function WikiSourceManageModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const queryClient = useQueryClient();
  const previousStatusesRef = useRef<Record<string, string>>({});

  const sourcesQuery = useQuery({
    queryKey: ['wiki', 'sources'],
    queryFn: fetchWikiSources,
    enabled: open,
    staleTime: 30 * 1000,
    refetchOnWindowFocus: false,
    refetchInterval: (query) => {
      const sources = query.state.data?.sources ?? [];
      return sources.some((source) => source.status === 'processing') ? 2000 : false;
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (sourceId: string) => deleteWikiSource(sourceId),
    onSuccess: () => {
      message.success('资料已删除');
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'sources'] });
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'tree'] });
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'graph'] });
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'page'] });
    },
    onError: (error) => message.error(error instanceof Error ? error.message : '删除失败'),
  });

  const reprocessMutation = useMutation({
    mutationFn: (sourceId: string) => reprocessWikiSource(sourceId),
    onSuccess: () => {
      message.success('已重新提交解析');
      void queryClient.invalidateQueries({ queryKey: ['wiki', 'sources'] });
    },
    onError: (error) => message.error(error instanceof Error ? error.message : '重新解析失败'),
  });

  const sources = sourcesQuery.data?.sources ?? [];

  useEffect(() => {
    if (!sources.length) return;
    const previous = previousStatusesRef.current;
    const completed = sources.some((source) => source.status === 'done' && previous[source.source_id] && previous[source.source_id] !== 'done');
    previousStatusesRef.current = Object.fromEntries(sources.map((source) => [source.source_id, source.status]));
    if (!completed) return;
    message.success('资料解析完成，知识树和图谱已更新');
    void queryClient.invalidateQueries({ queryKey: ['wiki', 'tree'] });
    void queryClient.invalidateQueries({ queryKey: ['wiki', 'graph'] });
  }, [queryClient, sources]);

  return (
    <Modal title="管理已上传资料" open={open} onCancel={onClose} footer={null} width={680}>
      <Typography.Paragraph type="secondary">
        这里可以查看已上传文档的处理状态。解析完成后，内容会出现在“浏览知识”和“知识图谱”中；解析失败的文档可以重试，也可以删除。
      </Typography.Paragraph>

      <List
        size="small"
        loading={sourcesQuery.isPending}
        dataSource={sources}
        locale={{ emptyText: '暂无资料，可上传文档或先导入旧图谱' }}
        renderItem={(source: WikiSource) => (
          <List.Item
            actions={[
              source.status === 'failed' ? (
                <Button key="retry" size="small" loading={reprocessMutation.isPending} onClick={() => reprocessMutation.mutate(source.source_id)}>
                  重试
                </Button>
              ) : null,
              <Popconfirm
                key="delete"
                title={`删除资料「${source.filename}」及其生成的页面？此操作不可恢复。`}
                okText="删除"
                cancelText="取消"
                disabled={deleteMutation.isPending}
                onConfirm={() => deleteMutation.mutate(source.source_id)}
              >
                <Button
                  size="small"
                  danger
                  disabled={source.status === 'processing' || deleteMutation.isPending}
                  title={source.status === 'processing' ? '解析完成后再删除' : undefined}
                >
                  删除
                </Button>
              </Popconfirm>,
            ].filter(Boolean) as React.ReactElement[]}
          >
            <List.Item.Meta
              title={source.filename}
              description={
                <Space size={8} wrap>
                  <Typography.Text type="secondary">
                    .{source.ext}
                    {source.progress ? ` · ${source.progress}` : ''}
                  </Typography.Text>
                  <Tag color={source.status === 'done' ? 'success' : source.status === 'processing' ? 'warning' : 'error'}>
                    {source.status === 'done' ? '已完成' : source.status === 'processing' ? '解析中' : '失败'}
                  </Tag>
                  {source.status === 'failed' && source.error_msg ? (
                    <Typography.Text type="danger" style={{ fontSize: 12 }}>
                      {source.error_msg}
                    </Typography.Text>
                  ) : null}
                </Space>
              }
            />
          </List.Item>
        )}
      />
    </Modal>
  );
}
