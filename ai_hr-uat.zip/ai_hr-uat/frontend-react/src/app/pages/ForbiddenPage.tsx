import { Button, Result, Typography } from 'antd';
import { useNavigate } from 'react-router-dom';

import { defaultRouteForUser, useAuth } from '../auth/AuthContext';

export function ForbiddenPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="auth-page">
      <Typography.Title className="visually-hidden" level={1}>
        Forbidden
      </Typography.Title>
      <Result
        status="403"
        title="Forbidden"
        subTitle="当前账号没有访问该页面所需的权限。"
        extra={
          <Button type="primary" onClick={() => navigate(defaultRouteForUser(user), { replace: true })}>
            返回工作台
          </Button>
        }
      />
    </div>
  );
}
