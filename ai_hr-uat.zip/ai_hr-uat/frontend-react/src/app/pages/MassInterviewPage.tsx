/**
 * 候选人自助面试页（/mass-interview/:token）— 免登，移动端优先。
 * 一镜到底录制：landing → consent → device_check → ready → interviewing(4 子状态) → uploading → complete，
 * 另有 expired / error 两个终态。行为与旧版 frontend/mass-interview.html 对齐。
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { message } from 'antd';

import {
  fetchMassInterviewSession,
  heartbeatMassInterviewSession,
  postDeviceCheck,
  releaseMassInterviewSession,
  uploadFullVideo,
  type DeviceCheckResult,
  type MassInterviewSession,
  type QuestionTimestamp,
  type UploadProgress,
} from '../../features/mass-interview/api';
import {
  ContinuousRecorder,
  acquireInterviewStream,
  formatRecTime,
  playQuestionTts,
  recordProbeClip,
  stopAllTts,
  stopStream,
} from '../../features/mass-interview/media';
import {
  AssessmentSessionGuard,
  formatAssessmentDeadline,
} from '../../shared/AssessmentSessionGuard';
import { useSingleTabLock } from '../../shared/useSingleTabLock';

type MiState =
  | 'landing'
  | 'consent'
  | 'device_check'
  | 'ready'
  | 'interviewing'
  | 'uploading'
  | 'complete'
  | 'expired'
  | 'error';

type SubState = 'tts_playing' | 'thinking' | 'answering' | 'transition';

type TtsItemStatus = 'loading' | 'ready' | 'failed' | 'system';

type DeviceCheckState = {
  running: boolean;
  result: DeviceCheckResult | null;
  passed: boolean;
};

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

export function MassInterviewPage() {
  const { token = '' } = useParams();
  const antdMessage = message;

  const [miState, setMiState] = useState<MiState>('landing');
  const [session, setSession] = useState<MassInterviewSession | null>(null);
  const [expiredRole, setExpiredRole] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const tabLockState = useSingleTabLock(token);
  const [privacyConsentChecked, setPrivacyConsentChecked] = useState(false);
  const [privacyConsentGranted, setPrivacyConsentGranted] = useState(false);

  const [deviceCheck, setDeviceCheck] = useState<DeviceCheckState>({ running: false, result: null, passed: false });
  const [ttsStatus, setTtsStatus] = useState<TtsItemStatus[]>([]);
  const [subState, setSubState] = useState<SubState>('tts_playing');
  const [currentQ, setCurrentQ] = useState(0);
  const [recordingSec, setRecordingSec] = useState(0);
  const [questionTimeLeft, setQuestionTimeLeft] = useState(300);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress | null>(null);
  const [uploadFailed, setUploadFailed] = useState(false);

  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<ContinuousRecorder | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const ttsAudioRef = useRef<Array<HTMLAudioElement | null>>([]);
  const resolveThinkingRef = useRef<(() => void) | null>(null);
  const resolveAnsweringRef = useRef<(() => void) | null>(null);
  const recTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const questionTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timestampsRef = useRef<QuestionTimestamp[]>([]);
  const recordedBlobRef = useRef<Blob | null>(null);
  const recordingSecRef = useRef(0);
  const cancelledRef = useRef(false);
  const endingRef = useRef(false);
  const largeFileWarnedRef = useRef(false);
  const subStateRef = useRef<SubState>('tts_playing');
  const ttsAbortRef = useRef<AbortController | null>(null);
  const answerRequestedRef = useRef(false);

  const questions = session?.questions ?? [];
  const total = questions.length;
  const recoveryKey = `mi_oneshot_${token}`;

  const showToast = useCallback(
    (text: string, type: 'info' | 'error' | 'warning' = 'info') => {
      antdMessage[type](text);
    },
    [antdMessage],
  );

  const showError = useCallback((message: string) => {
    setErrorMsg(message);
    setMiState('error');
  }, []);

  // ── 初始化：拉取 session + 崩溃恢复提示 ──
  useEffect(() => {
    if (tabLockState === 'checking') return;
    if (tabLockState === 'locked') {
      showError('该面试链接已在其他窗口打开，请关闭其他窗口后重试');
      return;
    }
    cancelledRef.current = false;
    let disposed = false;
    (async () => {
      const result = await fetchMassInterviewSession(token);
      if (disposed) return;
      if (result.kind === 'expired') {
        setExpiredRole(result.role);
        setMiState('expired');
        return;
      }
      if (result.kind === 'error') {
        showError(result.message);
        return;
      }
      setSession(result.session);
      if (result.session.status === 'completed' || result.session.status === 'evaluated') {
        setMiState('complete');
        return;
      }
      setMiState('landing');
      try {
        const raw = localStorage.getItem(recoveryKey);
        if (raw) {
          const data = JSON.parse(raw) as { ts?: number; state?: string; chunks?: number };
          if (data.ts && Date.now() - data.ts > 3600000) {
            localStorage.removeItem(recoveryKey);
          } else if (data.state === 'interviewing' && (data.chunks ?? 0) > 0) {
            showToast('检测到未完成的面试录像，数据已暂存');
          }
        }
      } catch {
        /* localStorage 不可用时忽略 */
      }
    })();
    return () => {
      disposed = true;
    };
  }, [token, recoveryKey, showError, showToast, tabLockState]);

  // Keep the server-side lease alive while the candidate is active. The lease
  // is deliberately stopped for terminal states and released immediately on
  // successful completion; the unload cleanup is only a best-effort fallback.
  useEffect(() => {
    if (!session || !token || ['complete', 'expired', 'error'].includes(miState)) return;
    const timer = window.setInterval(() => {
      void heartbeatMassInterviewSession(token);
    }, 10_000);
    return () => window.clearInterval(timer);
  }, [miState, session, token]);

  useEffect(() => () => {
    if (token) void releaseMassInterviewSession(token);
  }, [token]);

  // ── READY：预加载 TTS 音频 ──
  useEffect(() => {
    if (miState !== 'ready' || !session) return;
    const urls = session.tts_urls ?? [];
    if (!urls.length) {
      setTtsStatus([]);
      return;
    }
    setTtsStatus(urls.map((url) => (url ? 'loading' : 'system')));
    ttsAudioRef.current = urls.map((url, index) => {
      if (!url) return null;
      const audio = new Audio();
      audio.preload = 'auto';
      audio.src = url;
      audio.onerror = () =>
        setTtsStatus((current) => current.map((item, i) => (i === index ? 'failed' : item)));
      audio.oncanplaythrough = () =>
        setTtsStatus((current) => current.map((item, i) => (i === index ? 'ready' : item)));
      return audio;
    });
  }, [miState, session]);

  // ── INTERVIEWING：挂载摄像头预览 + beforeunload 守卫 ──
  useEffect(() => {
    if (miState !== 'interviewing') return;
    if (videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      void videoRef.current.play().catch(() => undefined);
    }
    const guard = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '面试进行中，离开将丢失录像，确定离开吗？';
    };
    window.addEventListener('beforeunload', guard);
    return () => window.removeEventListener('beforeunload', guard);
  }, [miState]);

  // ── 卸载清理 ──
  useEffect(
    () => () => {
      cancelledRef.current = true;
      endingRef.current = true;
      if (recTimerRef.current) clearInterval(recTimerRef.current);
      if (questionTimerRef.current) clearInterval(questionTimerRef.current);
      ttsAbortRef.current?.abort();
      stopAllTts(ttsAudioRef.current);
      stopStream(streamRef.current);
      resolveThinkingRef.current?.();
      resolveAnsweringRef.current?.();
      void recorderRef.current?.stop();
    },
    [],
  );

  const saveRecovery = useCallback(
    (chunks: number, totalSize: number) => {
      try {
        localStorage.setItem(
          recoveryKey,
          JSON.stringify({ ts: Date.now(), state: 'interviewing', chunks, totalSize }),
        );
      } catch {
        /* 存储不可用时忽略 */
      }
    },
    [recoveryKey],
  );

  const clearRecovery = useCallback(() => {
    try {
      localStorage.removeItem(recoveryKey);
    } catch {
      /* 忽略 */
    }
  }, [recoveryKey]);

  const stopQuestionTimer = useCallback(() => {
    if (questionTimerRef.current) {
      clearInterval(questionTimerRef.current);
      questionTimerRef.current = null;
    }
  }, []);

  const updateSubState = useCallback((next: SubState) => {
    subStateRef.current = next;
    setSubState(next);
  }, []);

  /** 题目总倒计时：思考+答题共用 time_limit_seconds（默认 300s），超时强制推进。 */
  const startQuestionTimer = useCallback(
    (timeLimitSeconds: number) => {
      stopQuestionTimer();
      setQuestionTimeLeft(timeLimitSeconds);
      questionTimerRef.current = setInterval(() => {
        setQuestionTimeLeft((prev) => {
          const next = prev - 1;
          if (next <= 0) {
            if (questionTimerRef.current) clearInterval(questionTimerRef.current);
            questionTimerRef.current = null;
            if (subStateRef.current === 'thinking' && resolveThinkingRef.current) {
              resolveThinkingRef.current();
              resolveThinkingRef.current = null;
            } else if (subStateRef.current === 'answering' && resolveAnsweringRef.current) {
              resolveAnsweringRef.current();
              resolveAnsweringRef.current = null;
            }
            return 0;
          }
          return next;
        });
      }, 1000);
    },
    [stopQuestionTimer],
  );

  const doUpload = useCallback(async () => {
    const blob = recordedBlobRef.current;
    if (!blob) {
      showError('没有录制内容');
      return;
    }
    setUploadFailed(false);
    setUploadProgress({ pct: 0, loadedMB: '0.0', sizeMB: (blob.size / 1024 / 1024).toFixed(1) });
    try {
      await uploadFullVideo(token, blob, timestampsRef.current, setUploadProgress);
      if (cancelledRef.current) return;
      await releaseMassInterviewSession(token).catch(() => undefined);
      setMiState('complete');
    } catch (error) {
      if (cancelledRef.current) return;
      showToast(`上传失败: ${error instanceof Error ? error.message : '未知错误'}`, 'error');
      setUploadFailed(true);
    }
  }, [token, showError, showToast]);

  /** 停止录制并进入上传。 */
  const finishRecording = useCallback(
    async (earlyErrorMsg: string) => {
      stopQuestionTimer();
      if (recTimerRef.current) {
        clearInterval(recTimerRef.current);
        recTimerRef.current = null;
      }
      ttsAbortRef.current?.abort();
      ttsAbortRef.current = null;
      stopAllTts(ttsAudioRef.current);
      const blob = (await recorderRef.current?.stop()) ?? null;
      stopStream(streamRef.current);
      streamRef.current = null;
      clearRecovery();
      if (cancelledRef.current) return;
      if (!blob) {
        showError(earlyErrorMsg);
        return;
      }
      recordedBlobRef.current = blob;
      setMiState('uploading');
      await doUpload();
    },
    [stopQuestionTimer, clearRecovery, showError, doUpload],
  );

  /** 一镜到底主循环。 */
  const startInterview = useCallback(async () => {
    if (!privacyConsentGranted) {
      showToast('请先阅读并同意面试录制与隐私信息采集声明', 'warning');
      setMiState('consent');
      return;
    }
    if (!deviceCheck.passed || !deviceCheck.result?.camera_ok || !deviceCheck.result.audio_ok) {
      showToast('请先完成摄像头和麦克风检测，检测通过后才能开始面试', 'warning');
      setMiState('device_check');
      return;
    }
    let stream: MediaStream;
    try {
      stream = await acquireInterviewStream();
    } catch {
      showToast('无法启动摄像头，请检查权限', 'error');
      return;
    }
    streamRef.current = stream;
    endingRef.current = false;
    largeFileWarnedRef.current = false;
    timestampsRef.current = [];

    recorderRef.current = new ContinuousRecorder();
    recorderRef.current.start(stream, (chunks, totalSize) => saveRecovery(chunks, totalSize));
    recordingSecRef.current = 0;
    setRecordingSec(0);
    recTimerRef.current = setInterval(() => {
      recordingSecRef.current += 1;
      setRecordingSec(recordingSecRef.current);
      // 旧版每秒重复 toast；React 版只在首次超过 20MB 时提示一次
      if (!largeFileWarnedRef.current && (recorderRef.current?.totalSize ?? 0) > 20 * 1024 * 1024) {
        largeFileWarnedRef.current = true;
        showToast('录像文件较大，建议保持网络畅通', 'warning');
      }
    }, 1000);

    setMiState('interviewing');
    answerRequestedRef.current = false;
    await sleep(100);

    try {
      for (let i = 0; i < questions.length; i++) {
        if (cancelledRef.current || endingRef.current) return;
        setCurrentQ(i);
        timestampsRef.current.push({ q: i, start: 0 });
        if (i > 0) answerRequestedRef.current = false;

        startQuestionTimer(questions[i]?.time_limit_seconds || 300);

        if (!answerRequestedRef.current) {
          updateSubState('tts_playing');
          const ttsController = new AbortController();
          ttsAbortRef.current = ttsController;
          await playQuestionTts(questions[i], ttsAudioRef.current[i] ?? null, ttsController.signal);
          if (ttsAbortRef.current === ttsController) ttsAbortRef.current = null;
          if (cancelledRef.current || endingRef.current) return;
        }

        if (!answerRequestedRef.current) {
          updateSubState('thinking');
          await new Promise<void>((resolve) => {
            resolveThinkingRef.current = resolve;
          });
          if (cancelledRef.current || endingRef.current) return;
        }

        answerRequestedRef.current = false;
        timestampsRef.current[i].start = Math.max(0, recordingSecRef.current);
        updateSubState('answering');
        await new Promise<void>((resolve) => {
          resolveAnsweringRef.current = resolve;
        });
        if (cancelledRef.current || endingRef.current) return;

        timestampsRef.current[i].end = Math.max(timestampsRef.current[i].start + 1, recordingSecRef.current);
        stopQuestionTimer();

        if (i < questions.length - 1) {
          updateSubState('transition');
          await sleep(3000);
        }
      }
    } catch (error) {
      console.error('Interview loop error:', error);
      stopAllTts(ttsAudioRef.current);
      stopQuestionTimer();
    }

    await finishRecording('录制失败，请刷新重试');
  }, [
    privacyConsentGranted,
    deviceCheck,
    questions,
    saveRecovery,
    showToast,
    startQuestionTimer,
    stopQuestionTimer,
    updateSubState,
    finishRecording,
  ]);

  /** 提前结束：补记当前题时间戳、解开挂起的阶段等待。 */
  const endInterviewEarly = useCallback(async () => {
    endingRef.current = true;
    if (subStateRef.current === 'answering' && timestampsRef.current.length > 0) {
      const last = timestampsRef.current[timestampsRef.current.length - 1];
      last.end = Math.max(last.start + 1, recordingSecRef.current);
    }
    stopQuestionTimer();
    resolveThinkingRef.current?.();
    resolveThinkingRef.current = null;
    resolveAnsweringRef.current?.();
    resolveAnsweringRef.current = null;
    await finishRecording('录制失败');
  }, [stopQuestionTimer, finishRecording]);

  const startAnswering = useCallback(() => {
    answerRequestedRef.current = true;
    ttsAbortRef.current?.abort();
    ttsAbortRef.current = null;
    stopAllTts(ttsAudioRef.current);
    updateSubState('answering');
    resolveThinkingRef.current?.();
    resolveThinkingRef.current = null;
  }, [updateSubState]);

  const finishAnswering = useCallback(() => {
    resolveAnsweringRef.current?.();
    resolveAnsweringRef.current = null;
  }, []);

  const replayTts = useCallback(() => {
    if (subStateRef.current !== 'thinking') return;
    updateSubState('tts_playing');
    const ttsController = new AbortController();
    ttsAbortRef.current = ttsController;
    void playQuestionTts(questions[currentQ], ttsAudioRef.current[currentQ] ?? null, ttsController.signal).then(() => {
      if (ttsAbortRef.current === ttsController) ttsAbortRef.current = null;
      if (cancelledRef.current || endingRef.current) return;
      if (subStateRef.current === 'answering') return;
      updateSubState('thinking');
    });
  }, [questions, currentQ, updateSubState]);

  const runDeviceCheck = useCallback(async () => {
    if (!privacyConsentGranted) {
      showToast('请先阅读并同意面试录制与隐私信息采集声明', 'warning');
      setMiState('consent');
      return;
    }
    if (deviceCheck.running) return;
    setDeviceCheck({ running: true, result: null, passed: false });
    try {
      const clip = await recordProbeClip();
      const result = await postDeviceCheck(token, clip);
      if (cancelledRef.current) return;
      setDeviceCheck({ running: false, result, passed: Boolean(result.camera_ok && result.audio_ok) });
    } catch (error) {
      if (cancelledRef.current) return;
      const message = error instanceof Error ? error.message : '';
      let suggestion = '无法完成设备检测，请确认已授权摄像头和麦克风权限';
      if (message.includes('NotAllowedError') || message.includes('Permission')) {
        suggestion = '摄像头或麦克风权限被拒绝，请在浏览器设置中允许访问';
      } else if (message.includes('NotFoundError')) {
        suggestion = '未检测到摄像头或麦克风设备';
      }
      setDeviceCheck({
        running: false,
        result: { camera_ok: false, audio_ok: false, lighting_ok: true, face_detected: true, suggestions: [suggestion] },
        passed: false,
      });
    }
  }, [deviceCheck.running, privacyConsentGranted, showToast, token]);

  const expireInterview = useCallback(() => {
    cancelledRef.current = true;
    endingRef.current = true;
    if (recTimerRef.current) clearInterval(recTimerRef.current);
    if (questionTimerRef.current) clearInterval(questionTimerRef.current);
    recTimerRef.current = null;
    questionTimerRef.current = null;
    ttsAbortRef.current?.abort();
    stopAllTts(ttsAudioRef.current);
    stopStream(streamRef.current);
    streamRef.current = null;
    resolveThinkingRef.current?.();
    resolveThinkingRef.current = null;
    resolveAnsweringRef.current?.();
    resolveAnsweringRef.current = null;
    void recorderRef.current?.stop();
    setExpiredRole(session?.role ?? '');
    setMiState((current) => (['complete', 'expired', 'error'].includes(current) ? current : 'expired'));
    if (token) void releaseMassInterviewSession(token).catch(() => undefined);
  }, [session?.role, token]);

  // ── 渲染 ──
  const name = session?.candidate_name || '同学';
  const role = session?.role || '';
  const company = session?.company_name || '';
  const logo = session?.company_logo || '';
  const brandColor = session?.brand_color || '#16A34A';
  const perQMin = Math.round((questions[0]?.time_limit_seconds || 300) / 60);
  const minutes = Math.ceil(total * (perQMin + 1));
  const expiresAt = formatAssessmentDeadline(session?.expires_at);

  const currentQuestion = questions[currentQ];
  const questionTimeTotal = currentQuestion?.time_limit_seconds || 300;
  const questionPct = Math.max(0, (questionTimeLeft / questionTimeTotal) * 100);
  const timerColor =
    questionTimeLeft <= 10 ? 'var(--danger)' : questionTimeLeft <= 30 ? 'var(--warning)' : undefined;
  const progressBackground =
    questionTimeLeft <= 10
      ? 'var(--danger)'
      : questionTimeLeft <= 30
        ? 'var(--warning)'
        : 'var(--primary-grad)';

  return (
    <div className="mi-app">
      {session ? (
        <AssessmentSessionGuard
          active={miState === 'interviewing'}
          expiresAt={session.expires_at}
          assessmentName="面试"
          onExpired={expireInterview}
        />
      ) : null}
      {miState === 'landing' ? (
        <>
          <div className="mi-topbar" style={{ background: `linear-gradient(135deg,${brandColor},${brandColor}dd)` }}>
            <span className="mi-title" style={{ color: '#fff' }}>
              AI面试邀请
            </span>
          </div>
          <div className="mi-content">
            <div style={{ textAlign: 'center', marginBottom: 20 }}>
              {logo ? (
                <img
                  src={logo}
                  style={{ height: 32, marginBottom: 8 }}
                  onError={(event) => {
                    event.currentTarget.style.display = 'none';
                  }}
                  alt=""
                  decoding="async"
                />
              ) : null}
              {company ? <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{company}</div> : null}
              <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 4 }}>{role}</div>
              <div style={{ fontSize: 14, color: 'var(--text2)' }}>AI面试邀请</div>
            </div>

            <div className="mi-info-card" style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 10 }}>你好，{name}</div>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 2 }}>
                恭喜你通过简历筛选，请完成以下AI面试。
              </div>
            </div>

            <div className="mi-info-card" style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 2.2 }}>
                ◈ 共 <b>{total}</b> 道题，预计 <b>{minutes}</b> 分钟<br />
                ◈ 一镜到底录制，无需逐题操作<br />
                ◈ AI面试官会语音读题，想好后点&quot;开始答题&quot;<br />
                {expiresAt ? (
                  <>
                    ◈ 截止时间：<b style={{ color: 'var(--danger)' }}>{expiresAt}</b>
                  </>
                ) : null}
              </div>
            </div>

            <div className="mi-info-card">
              <div style={{ fontSize: 12, color: 'var(--text3)', lineHeight: 2 }}>
                ◈ 请在安静、光线充足的环境中完成<br />
                ◈ 需要摄像头和麦克风权限<br />
                ◈ AI会语音读题，无需一直看屏幕<br />
                ◈ 遇到问题请联系招聘方
              </div>
            </div>
          </div>
          <div className="mi-bottom-bar">
            <button
              type="button"
              className="mi-btn primary"
              onClick={() => {
                setPrivacyConsentChecked(false);
                setPrivacyConsentGranted(false);
                setMiState('consent');
              }}
            >
              阅读声明并继续 →
            </button>
          </div>
        </>
      ) : null}

      {miState === 'consent' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">隐私与录制授权</span>
            <span className="mi-progress">进入面试前</span>
          </div>
          <div className="mi-content">
            <section className="mi-consent-card" aria-labelledby="mi-consent-title">
              <div className="mi-consent-badge">重要提示</div>
              <h1 id="mi-consent-title" className="mi-consent-title">
                面试录制与隐私信息采集声明
              </h1>
              <p className="mi-consent-summary">
                为完成本次视频面试，请在充分阅读以下说明后，自主决定是否授权开启摄像头和麦克风。
              </p>

              <ol className="mi-consent-list">
                <li>
                  <strong>采集内容</strong>
                  <span>面试期间将采集你的音频、视频、答题内容、作答时间及设备检测结果。</span>
                </li>
                <li>
                  <strong>使用目的</strong>
                  <span>相关信息用于设备检测、面试记录、语音转写、AI辅助分析评分及招聘方复核。</span>
                </li>
                <li>
                  <strong>信息处理</strong>
                  <span>面试资料将由招聘方按照其招聘管理和隐私保护要求进行访问、保存与处理。</span>
                </li>
                <li>
                  <strong>你的选择</strong>
                  <span>你可以拒绝授权；拒绝后将无法进入本视频面试，可联系招聘方咨询其他安排。</span>
                </li>
              </ol>

              <div className="mi-consent-note">
                请在安静、独立的环境中完成面试，避免录入与本次招聘无关的个人敏感信息或他人信息。
              </div>

              <label className="mi-consent-check" htmlFor="mi-privacy-consent">
                <input
                  id="mi-privacy-consent"
                  type="checkbox"
                  checked={privacyConsentChecked}
                  onChange={(event) => setPrivacyConsentChecked(event.target.checked)}
                />
                <span>
                  我已阅读并理解以上声明，同意开启摄像头和麦克风，并同意采集及处理本次面试相关的音视频与答题信息。
                </span>
              </label>
            </section>
          </div>
          <div className="mi-bottom-bar mi-consent-actions">
            <button
              type="button"
              className="mi-btn outline"
              onClick={() => {
                setPrivacyConsentChecked(false);
                setPrivacyConsentGranted(false);
                setMiState('landing');
              }}
            >
              暂不同意
            </button>
            <button
              type="button"
              className="mi-btn primary"
              disabled={!privacyConsentChecked}
              onClick={() => {
                setPrivacyConsentGranted(true);
                setMiState('device_check');
              }}
            >
              同意并进入设备检测
            </button>
          </div>
        </>
      ) : null}

      {miState === 'device_check' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">设备检测</span>
            <span className="mi-progress">{total}题</span>
          </div>
          <div className="mi-content">
            <div style={{ textAlign: 'center', marginBottom: 16 }}>
              <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 4 }}>你好，{name}</div>
              <div style={{ fontSize: 13, color: 'var(--text2)' }}>面试前请先检测设备，确保摄像头和麦克风正常</div>
            </div>

            <div className="mi-devcheck">
              <div className="mi-devcheck-title">◈ 设备检测</div>
              {(
                [
                  { key: 'camera_ok', label: '摄像头' },
                  { key: 'audio_ok', label: '麦克风/音频' },
                ] as const
              ).map((item) => {
                const result = deviceCheck.result;
                const icon = !result ? 'wait' : result[item.key] ? 'pass' : 'fail';
                return (
                  <div key={item.key} className="mi-devcheck-row">
                    <span className={`mi-devcheck-icon ${icon}`}>{icon === 'wait' ? '○' : icon === 'pass' ? '✓' : '✕'}</span>
                    <span className="mi-devcheck-label">{item.label}</span>
                  </div>
                );
              })}
              {deviceCheck.result?.suggestions?.length ? (
                <div className="mi-devcheck-tips">
                  {deviceCheck.result.suggestions.map((suggestion, index) => (
                    <div key={index} className="tip-item">
                      ◈ {suggestion}
                    </div>
                  ))}
                </div>
              ) : null}
            </div>

            <button
              type="button"
              className={`mi-devcheck-btn${deviceCheck.running ? ' recording' : ''}`}
              onClick={() => void runDeviceCheck()}
              disabled={deviceCheck.running}
            >
              {deviceCheck.running ? <span className="mi-btn-spinner" /> : '◉'}{' '}
              {deviceCheck.running ? '检测中，请面对摄像头...' : deviceCheck.result ? '重新检测' : '检测我的设备'}
            </button>

            {deviceCheck.passed ? (
              <button
                type="button"
                className="mi-btn primary"
                style={{ marginTop: 10 }}
                onClick={() => setMiState('ready')}
              >
                下一步 →
              </button>
            ) : null}
          </div>
        </>
      ) : null}

      {miState === 'ready' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">面试须知</span>
            <span className="mi-progress">{total}题</span>
          </div>
          <div className="mi-content">
            <div className="mi-info-card" style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>◈ 一镜到底模式</div>
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 2 }}>
                • 全程自动录制，AI面试官会语音读题<br />
                • 每道题有{perQMin}分钟（思考+答题）<br />
                • 想好后再点&quot;开始答题&quot;，说完点&quot;回答完毕&quot;<br />
                • 共{total}题，约{minutes}分钟<br />
                • 中途离开将丢失录像，请确保网络稳定
              </div>
            </div>

            <div className="mi-info-card" style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>音频状态</div>
              {ttsStatus.length ? (
                ttsStatus.map((status, index) => (
                  <div key={index} className="mi-ready-status">
                    {status === 'loading' ? (
                      <>
                        <span className="dot loading" />
                        第{index + 1}题语音加载中...
                      </>
                    ) : status === 'ready' ? (
                      <>
                        <span className="dot done" />
                        已就绪
                      </>
                    ) : status === 'failed' ? (
                      <>
                        <span className="dot" style={{ background: 'var(--danger)' }} />
                        语音加载失败（将使用系统语音）
                      </>
                    ) : (
                      <>
                        <span className="dot loading" />
                        第{index + 1}题语音（将使用系统语音）
                      </>
                    )}
                  </div>
                ))
              ) : (
                <div style={{ fontSize: 12, color: 'var(--text3)' }}>语音播报就绪（系统语音）</div>
              )}
            </div>
          </div>
          <div className="mi-bottom-bar">
            <button type="button" className="mi-btn primary" onClick={() => void startInterview()}>
              开始面试 →
            </button>
          </div>
        </>
      ) : null}

      {miState === 'interviewing' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">
              <span className="mi-rec-badge">
                <span className="mi-rec-dot" />
                REC
              </span>
              <span style={{ fontVariantNumeric: 'tabular-nums', fontSize: 14 }}>{formatRecTime(recordingSec)}</span>
            </span>
            <span className="mi-progress">
              第{currentQ + 1}/{total}题
            </span>
          </div>
          <div className="mi-content" style={{ padding: 8, display: 'flex', flexDirection: 'column', position: 'relative' }}>
            <div className="mi-recording-view">
              <video ref={videoRef} autoPlay muted playsInline />
            </div>

            <div className="mi-q-display" style={{ marginTop: 10 }}>
              <div className={`mi-q-status${subState === 'answering' ? ' answering' : ''}`}>
                {subState === 'tts_playing'
                  ? '◉ 面试官正在读题，可随时开始答题'
                  : subState === 'thinking'
                    ? '◉ 请思考后点击按钮开始答题'
                    : subState === 'answering'
                      ? '● 正在录制中，请回答'
                      : ''}
              </div>
              <div className="mi-q-prefix">{currentQuestion?.tts_prefix || ''}</div>
              <div className="mi-q-text">{currentQuestion?.question || ''}</div>
              <div className="mi-answer-progress">
                <div className="mi-progress-bar">
                  <div
                    className="mi-progress-fill"
                    style={{ width: `${questionPct}%`, background: progressBackground }}
                  />
                </div>
                <div className="mi-progress-text">
                  剩余{' '}
                  <span className={questionTimeLeft <= 10 ? 'mi-timer-pulse' : undefined} style={{ color: timerColor }}>
                    {formatRecTime(Math.max(0, questionTimeLeft))}
                  </span>
                </div>
              </div>
            </div>

            <div style={{ marginTop: 8 }}>
              {subState === 'tts_playing' || subState === 'thinking' ? (
                <>
                  {subState === 'thinking' ? (
                    <button type="button" className="mi-btn outline" style={{ marginBottom: 8 }} onClick={replayTts}>
                      🔊 重听题目
                    </button>
                  ) : null}
                  <button
                    type="button"
                    className="mi-btn primary"
                    style={{ fontSize: 17, padding: 16 }}
                    onClick={startAnswering}
                  >
                    🎤 开始答题
                  </button>
                </>
              ) : null}
              {subState === 'answering' ? (
                <button type="button" className="mi-btn success" onClick={finishAnswering}>
                  ✅ 回答完毕
                </button>
              ) : null}
            </div>

            {subState === 'transition' ? (
              <div className="mi-transition-overlay">
                <div style={{ textAlign: 'center', color: '#fff' }}>
                  <div style={{ fontSize: 28, marginBottom: 12 }}>📋</div>
                  <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>准备下一题...</div>
                  <div style={{ fontSize: 14, opacity: 0.7 }}>
                    第 {currentQ + 1}/{total} 题已完成
                  </div>
                </div>
              </div>
            ) : null}
          </div>
          <div className="mi-bottom-bar">
            <button type="button" className="mi-btn danger" onClick={() => void endInterviewEarly()}>
              ■ 结束面试
            </button>
          </div>
        </>
      ) : null}

      {miState === 'uploading' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">上传中</span>
          </div>
          <div className="mi-content center">
            <div className="mi-upload-progress">
              <div className="spinner" />
              <div style={{ fontSize: 15, fontWeight: 600, marginTop: 12 }}>正在上传面试录像</div>
              <div className="mi-upload-text" style={{ marginTop: 8 }}>
                视频约 {uploadProgress?.sizeMB ?? '--'} MB
              </div>
              <div className="mi-upload-progress" style={{ marginTop: 12 }}>
                <div className="mi-progress-bar">
                  <div className="mi-progress-fill" style={{ width: `${uploadProgress?.pct ?? 0}%` }} />
                </div>
                <div className="mi-progress-text" style={{ marginTop: 4, fontSize: 12, color: 'var(--text2)' }}>
                  {uploadProgress && uploadProgress.pct > 0
                    ? `${uploadProgress.loadedMB}MB / ${uploadProgress.sizeMB}MB (${uploadProgress.pct}%)`
                    : '准备上传...'}
                </div>
              </div>
              <div className="mi-upload-text" style={{ marginTop: 8, fontSize: 12, color: 'var(--text3)' }}>
                上传完成后AI将自动评分，请勿关闭页面
              </div>
            </div>
            {uploadFailed ? (
              <button type="button" className="mi-btn primary" style={{ marginTop: 16 }} onClick={() => void doUpload()}>
                重新上传
              </button>
            ) : null}
          </div>
        </>
      ) : null}

      {miState === 'complete' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">面试完成</span>
          </div>
          <div className="mi-content center">
            <div className="mi-done-icon">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
            </div>
            <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 8 }}>面试完成！</div>
            <div style={{ fontSize: 14, color: 'var(--text2)', marginBottom: 24 }}>感谢你的参与，{name}</div>

            <div className="mi-info-card" style={{ marginBottom: 12 }}>
              <div className="mi-info-row">
                ◈ 已完成 {total} 道题<br />
                ◈ AI正在评分中，完成后将通知招聘方
              </div>
            </div>

            <div className="mi-info-card">
              <div style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.8 }}>
                预计3个工作日内会有后续通知。<br />
                祝你求职顺利！
              </div>
            </div>
          </div>
        </>
      ) : null}

      {miState === 'expired' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">AI面试</span>
          </div>
          <div className="mi-content center">
            <div className="mi-expired-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 6v6l4 2" />
              </svg>
            </div>
            <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 8 }}>面试链接已过期</div>
            <div style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 20 }}>
              {expiredRole ? (
                <>
                  岗位：{expiredRole}
                  <br />
                </>
              ) : null}
              请联系招聘方获取新的面试链接
            </div>
          </div>
        </>
      ) : null}

      {miState === 'error' ? (
        <>
          <div className="mi-topbar">
            <span className="mi-title">AI面试</span>
          </div>
          <div className="mi-content center">
            <div className="mi-error">
              <div className="mi-error-title">出错了</div>
              <div className="mi-error-text">{errorMsg || '未知错误'}</div>
              <button type="button" className="mi-btn outline" onClick={() => window.location.reload()}>
                刷新重试
              </button>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
