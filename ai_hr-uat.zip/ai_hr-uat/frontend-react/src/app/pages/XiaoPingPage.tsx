import {
  Alert,
  App as AntApp,
  Button,
  Card,
  Col,
  Collapse,
  Empty,
  Form,
  Input,
  InputNumber,
  Modal,
  Row,
  Select,
  Space,
  Spin,
 Statistic,
  Table,
 Tag,
  Typography,
} from 'antd';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getErrorMessage as errorMessage } from '../../shared/errors';

import { AgentTopbar } from '../components/AgentTopbar';
import { routePaths } from '../routes/route-paths';
import type { AgentCandidate } from '../../features/agent-workbench/api';
import { fetchAgentPipeline, stageOutput } from '../../features/agent-workbench/api';
import type {
  AssessmentQueue,
  AssessmentQueueItem,
  CandidateAssessmentReport,
  ReportData,
} from '../../features/xiao-ping/api';
import {
  useAssessmentQueueQuery,
  useAggregateReportJobQuery,
  useCandidateReportsQuery,
  useCompletePipelineMutation,
  useGenerateCandidateReportsMutation,
  useReviewAssessmentMutation,
  useStartAggregateReportJobMutation,
} from '../../features/xiao-ping/hooks';
import {
  assessmentQuestionAnalyses,
  assessmentReviewTarget,
  candidateReportActionLabel,
  decisionCandidates,
  decisionOutcome,
  decisionScore,
  decisionScoreSource,
  reportGroups,
} from '../../features/xiao-ping/selectors';
import { agentWorkspaceUrl } from '../../shared/agent-config';
import { DataTable } from '../../shared/data-table';
import type { DataTableColumn } from '../../shared/data-table';
import { fetchMassPipelineForSource, fetchMassStreams } from '../../features/mass-dashboard/api';
import { ResumePreviewModal } from '../../features/talent-pool/components/ResumePreviewModal';
import {
  useMarkMassCandidateMutation,
  useMassRankingQuery,
  useMassSchedulesQuery,
  useSendCandidateOfferMutation,
} from '../../features/mass-dashboard/hooks';

const EMPTY_QUEUE: AssessmentQueue = {
  ready_for_decision: [],
  incomplete: [],
  counts: { ready_for_decision: 0, incomplete: 0 },
};

function normalizeQueue(value: AssessmentQueue | undefined): AssessmentQueue {
  return {
    ...EMPTY_QUEUE,
    ...(value ?? {}),
    counts: { ...EMPTY_QUEUE.counts, ...(value?.counts ?? {}) },
    ready_for_decision: value?.ready_for_decision ?? [],
    incomplete: value?.incomplete ?? [],
  };
}

function escapeHtml(value: unknown) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function printCandidateReports(reports: CandidateAssessmentReport[], role: string) {
  if (!reports.length) return;
  const popup = window.open('', '_blank');
  if (!popup) return;
  popup.opener = null;
  const pages = reports.map((report) => {
    const questions = report.questions.map((item) => `
      <section class="question">
        <h3>${escapeHtml(item.modality_label)} · 第 ${item.question_index + 1} 题</h3>
        <p><b>题目：</b>${escapeHtml(item.question)}</p>
        <p><b>得分：</b>${item.score == null ? '待审核' : `${escapeHtml(item.score)} 分`}</p>
        <p><b>命中：</b>${escapeHtml(item.hit_points.join('；') || '暂无明确命中项')}</p>
        <p><b>遗漏：</b>${escapeHtml(item.missed_points.join('；') || '暂无明确遗漏项')}</p>
        ${item.key_evidence ? `<p><b>证据：</b>${escapeHtml(item.key_evidence)}</p>` : ''}
      </section>`).join('');
    return `<article class="report-page">
      <header><h1>候选人评估报告</h1><p>${escapeHtml(role)} · ${escapeHtml(report.candidate_name)}</p></header>
      <div class="summary">
        <div><span>综合成绩</span><strong>${report.score == null ? '待审核' : `${escapeHtml(report.score)} 分`}</strong></div>
        <div><span>成绩来源</span><strong>${escapeHtml(report.score_source_label)}</strong></div>
        <div><span>录用等级</span><strong>${escapeHtml(report.recommendation)}</strong></div>
      </div>
      ${report.score_status === 'provisional' ? '<p class="notice">当前总分为暂定，失败题目需人工审核。</p>' : ''}
      <h2>综合评价</h2><p>${escapeHtml(report.comprehensive_evaluation)}</p>
      <h2>录用建议</h2><p>${escapeHtml(report.hiring_advice)}</p>
      <h2>关键结论</h2>
      <p><b>优势：</b>${escapeHtml(report.strengths.join('；') || '暂无充分证据')}</p>
      <p><b>风险：</b>${escapeHtml(report.risks.join('；') || '暂无明确风险项')}</p>
      ${questions ? `<h2>逐题分析</h2>${questions}` : ''}
    </article>`;
  }).join('');
  popup.document.write(`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>候选人评估报告</title>
    <style>
      @page { size: A4; margin: 16mm; }
      * { box-sizing: border-box; }
      body { margin: 0; color: #1f2937; font: 13px/1.65 "Microsoft YaHei", sans-serif; }
      .report-page { break-after: page; page-break-after: always; }
      .report-page:last-child { break-after: auto; page-break-after: auto; }
      header { border-bottom: 2px solid #2563eb; margin-bottom: 16px; }
      h1 { margin: 0; font-size: 24px; } header p { color: #6b7280; margin: 4px 0 12px; }
      h2 { font-size: 16px; margin: 18px 0 7px; } h3 { font-size: 14px; margin: 0 0 5px; }
      p { margin: 4px 0; } .summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
      .summary div { border: 1px solid #dbeafe; background: #eff6ff; padding: 10px; }
      .summary span { display: block; color: #6b7280; font-size: 11px; } .summary strong { font-size: 15px; }
      .notice { color: #9a3412; background: #fff7ed; border: 1px solid #fed7aa; padding: 8px; }
      table { width: 100%; border-collapse: collapse; } td { border: 1px solid #e5e7eb; padding: 6px 9px; }
      .question { border-left: 3px solid #bfdbfe; padding: 6px 10px; margin: 9px 0; break-inside: avoid; }
    </style></head><body>${pages}<script>window.onload=()=>{window.print();};<\/script></body></html>`);
  popup.document.close();
}

export function XiaoPingPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline') ?? '';
  if (!pipelineId) {
    return <AgentStatus type="warning" message="缺少岗位参数" description="请从岗位详情页进入小评工作台。" />;
  }
  return <XiaoPingWorkspace key={pipelineId} pipelineId={pipelineId} />;
}

function localDateValue(now = new Date()) {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function nextMinuteValue(now = new Date()) {
  const nextMinute = new Date(now.getTime() + 60_000);
  return `${String(nextMinute.getHours()).padStart(2, '0')}:${String(nextMinute.getMinutes()).padStart(2, '0')}`;
}

function AgentStatus({
  type,
  message,
  description,
}: {
  type: 'warning' | 'error';
  message: string;
  description: string;
}) {
  return (
    <div className="agent-page agent-page--status">
      <Alert
        type={type}
        showIcon
        message={message}
        description={description}
        action={
          <Link to={routePaths.studio}>
            <Button size="small">返回工作室</Button>
          </Link>
        }
      />
    </div>
  );
}

function CandidateRankBadge({ rank }: { rank: number }) {
  const tier = rank <= 3 ? `top-${rank}` : 'standard';
  return (
    <span className={`xiao-ping-rank-badge xiao-ping-rank-badge--${tier}`} aria-label={`第 ${rank} 名`}>
      <span className="xiao-ping-rank-badge__prefix" aria-hidden="true">
        {rank <= 3 ? 'TOP' : 'NO.'}
      </span>
      <span className="xiao-ping-rank-badge__number" aria-hidden="true">{rank}</span>
    </span>
  );
}

type XiaoPingActionIconKind = 'report' | 'resume' | 'replay' | 'retest' | 'review' | 'offer';

type RetestFormValues = {
  date: string;
  time?: string;
  interviewer: string;
  meeting_url?: string;
  note?: string;
  location?: string;
  duration_minutes?: number;
};

function XiaoPingActionIcon({ kind }: { kind: XiaoPingActionIconKind }) {
  const paths: Record<XiaoPingActionIconKind, React.ReactNode> = {
    report: <><path d="M5 3h6l3 3v11H5z" /><path d="M11 3v3h3M8 10h3M8 13h3" /></>,
    resume: <><circle cx="10" cy="7" r="3" /><path d="M4.5 17c.7-3 2.6-4.5 5.5-4.5s4.8 1.5 5.5 4.5" /></>,
    replay: <><circle cx="10" cy="10" r="7" /><path d="m9 7 4 3-4 3z" /></>,
    retest: <><rect x="3.5" y="5" width="13" height="11" rx="2" /><path d="M6.5 3v4M13.5 3v4M3.5 9h13M10 11.5v3M8.5 13h3" /></>,
    review: <><path d="M10 2.5 16 5v4.5c0 3.6-2.2 6.4-6 8-3.8-1.6-6-4.4-6-8V5z" /><path d="m7 10 2 2 4-4" /></>,
    offer: <><rect x="3" y="5" width="14" height="10" rx="2" /><path d="m4 7 6 4 6-4M13.5 3.5v3M12 5h3" /></>,
  };
  return (
    <svg className="xiao-ping-action-icon" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <g stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        {paths[kind]}
      </g>
    </svg>
  );
}

function CandidateIdentity({ name }: { name?: string }) {
  const displayName = name || '未知候选人';
  return (
    <div className="xiao-ping-candidate">
      <span className="xiao-ping-candidate__avatar" aria-hidden="true">{displayName.slice(0, 1)}</span>
      <span className="xiao-ping-candidate__info">
        <Typography.Text strong>{displayName}</Typography.Text>
        <Typography.Text type="secondary">候选人</Typography.Text>
      </span>
    </div>
  );
}

function XiaoPingWorkspace({ pipelineId }: { pipelineId: string }) {
  const { message, modal } = AntApp.useApp();
  const navigate = useNavigate();
  const pipelineQuery = useQuery({
    queryKey: ['xiao-ping', 'pipeline', pipelineId],
    queryFn: () => fetchAgentPipeline(pipelineId),
    enabled: Boolean(pipelineId),
    retry: false,
  });
  const queueQuery = useAssessmentQueueQuery(pipelineId);
  const candidateReportsQuery = useCandidateReportsQuery(pipelineId);
  const candidateReportsMutation = useGenerateCandidateReportsMutation(pipelineId);
  const aggregateReportJobQuery = useAggregateReportJobQuery(pipelineId);
  const aggregateReportMutation = useStartAggregateReportJobMutation(pipelineId);
  const reviewMutation = useReviewAssessmentMutation(pipelineId);
  const rankingQuery = useMassRankingQuery(pipelineId);
  const schedulesQuery = useMassSchedulesQuery(pipelineId);
  const markMutation = useMarkMassCandidateMutation(pipelineId);
  const offerMutation = useSendCandidateOfferMutation(pipelineId);
  const completePipelineMutation = useCompletePipelineMutation(pipelineId);
  const [report, setReport] = useState<ReportData | null>(null);
  const [aggregateReportOpen, setAggregateReportOpen] = useState(false);
  const [reviewCandidate, setReviewCandidate] = useState<AssessmentQueueItem | null>(null);
  const [candidateReport, setCandidateReport] = useState<CandidateAssessmentReport | null>(null);
  const [reportCandidate, setReportCandidate] = useState<AssessmentQueueItem | null>(null);
  const [resumeCandidate, setResumeCandidate] = useState<AgentCandidate | null>(null);
  const [replayOpen, setReplayOpen] = useState(false);
  const [replayUrl, setReplayUrl] = useState('');
  const [replayError, setReplayError] = useState('');
  const [replayLoading, setReplayLoading] = useState(false);
  const [retestCandidate, setRetestCandidate] = useState<AssessmentQueueItem | null>(null);
  const [retestSubmittedCandidateIds, setRetestSubmittedCandidateIds] = useState<Set<string>>(
    () => new Set(),
  );
  const [offerSentCandidateIds, setOfferSentCandidateIds] = useState<Set<string>>(() => new Set());
  const [sendingOfferCandidateId, setSendingOfferCandidateId] = useState('');
  const aggregateReportNotificationRef = useRef('');
  const aggregateReportAppliedRef = useRef('');
  const [reviewForm] = Form.useForm<{ modality: string; reason: string; override_score?: number }>();
  const [retestForm] = Form.useForm<RetestFormValues>();
  const retestDate = Form.useWatch('date', retestForm);
  const queue = normalizeQueue(queueQuery.data);
  const pipeline = pipelineQuery.data;
  const isPipelineCompleted = pipeline?.status === 'completed';
  const groups = useMemo(() => reportGroups(queue), [queue]);
  const aggregateReportJob = aggregateReportJobQuery.data;
  const aggregateReportRunning =
    aggregateReportJob?.status === 'queued' || aggregateReportJob?.status === 'running';
  const ready = decisionCandidates(queue);
  const reviewTarget = assessmentReviewTarget(reviewCandidate);
  const candidateReports = candidateReportsQuery.data?.reports ?? [];
  const generatingReportCandidateIds = useMemo(
    () => new Set(candidateReportsQuery.data?.generating_candidate_ids ?? []),
    [candidateReportsQuery.data?.generating_candidate_ids],
  );
  const candidateReportById = useMemo(
    () => new Map(candidateReports.map((item) => [item.candidate_id, item])),
    [candidateReports],
  );
  const pipelineCandidateById = useMemo(
    () => new Map((pipeline?.candidates ?? []).map((item) => [item.id, item])),
    [pipeline?.candidates],
  );
  const persistedRetestCandidateIds = useMemo(
    () =>
      new Set(
        (schedulesQuery.data?.schedules ?? [])
          .filter((schedule) => schedule.status !== 'cancelled' && schedule.round === '复试')
          .map((schedule) => schedule.candidate_id),
      ),
    [schedulesQuery.data?.schedules],
  );
  const persistedOfferCandidateIds = useMemo(
    () =>
      new Set(
        (pipeline?.candidates ?? [])
          .filter((candidate) => candidate.status === 'offered')
          .map((candidate) => candidate.id),
      ),
    [pipeline?.candidates],
  );
  const videoCandidateIds = useMemo(
    () => new Set(
      (rankingQuery.data?.ranking ?? [])
        .filter((item) => (item.video_paths ?? []).length)
        .map((item) => item.candidate_id),
    ),
    [rankingQuery.data?.ranking],
  );

  useEffect(() => {
    if (!pipeline) return;
    const output = stageOutput(pipeline, 'report');
    const saved = output.report && typeof output.report === 'object' ? output.report : output;
    if (
      saved &&
      Object.keys(saved).length &&
      ('ranking' in saved || 'recommend' in saved) &&
      reportRecord(saved.comparison_matrix).source === 'deterministic_assessment'
    ) {
      setReport(saved as ReportData);
    }
    document.title = `${pipeline.role} · 小评`;
    return () => {
      document.title = '锅圈食汇 - 智能招聘平台';
    };
  }, [pipeline]);

  useEffect(() => {
    if (!aggregateReportJob) return;
    const notificationKey = `${aggregateReportJob.id}:${aggregateReportJob.status}`;
    if (
      (aggregateReportJob.status === 'succeeded' || aggregateReportJob.status === 'failed') &&
      aggregateReportAppliedRef.current === notificationKey
    ) {
      return;
    }
    const startedHere = aggregateReportMutation.data?.id === aggregateReportJob.id;
    if (aggregateReportJob.status === 'succeeded') {
      const generated = aggregateReportJob.result?.report ?? aggregateReportJob.result?.report_data;
      if (generated) {
        setReport(generated);
        void pipelineQuery.refetch();
        if (startedHere && aggregateReportNotificationRef.current !== notificationKey) {
          message.success(`已完成 ${groups.pass.length} 位通过候选人的综合分析`);
        }
      } else if (startedHere && aggregateReportNotificationRef.current !== notificationKey) {
        message.warning(
          aggregateReportJob.message ||
            aggregateReportJob.result?.message ||
            aggregateReportJob.result?.reply ||
            '当前没有可生成综合报告的通过候选人',
        );
      }
    } else if (
      aggregateReportJob.status === 'failed' &&
      startedHere &&
      aggregateReportNotificationRef.current !== notificationKey
    ) {
      message.error(aggregateReportJob.error_message || '综合评估报告生成失败');
    }
    if (aggregateReportJob.status === 'succeeded' || aggregateReportJob.status === 'failed') {
      aggregateReportNotificationRef.current = notificationKey;
      aggregateReportAppliedRef.current = notificationKey;
    }
  }, [aggregateReportJob, aggregateReportMutation.data?.id, groups.pass.length, message, pipelineQuery]);

  if (pipelineQuery.isPending || queueQuery.isPending) {
    return (
      <div className="agent-page agent-page--status">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </div>
    );
  }
  if (pipelineQuery.isError || queueQuery.isError || !pipeline) {
    return (
      <AgentStatus
        type="error"
        message="小评工作台加载失败"
        description={errorMessage(pipelineQuery.error || queueQuery.error)}
      />
    );
  }

  async function submitReview() {
    if (!reviewCandidate) return;
    const values = await reviewForm.validateFields();
    await reviewMutation.mutateAsync({
      candidateId: reviewCandidate.candidate_id,
      body: {
        modality: values.modality,
        reason: values.reason.trim(),
        actor_id: 'hr',
        override_score: values.override_score,
      },
    });
    setReviewCandidate(null);
    await queueQuery.refetch();
  }

  async function completePipeline() {
    if (isPipelineCompleted) return;
    if (!report) {
      message.warning('暂不能完成流水线：请等待所有候选人完成面试，并生成综合评估报告。');
      return;
    }
    if (queue.counts.incomplete > 0) {
      message.warning(`暂不能完成流水线：仍有 ${queue.counts.incomplete} 位候选人评估未完成。`);
      return;
    }
    try {
      await completePipelineMutation.mutateAsync();
      message.success('岗位已完成');
      await pipelineQuery.refetch();
    } catch (error) {
      message.warning(errorMessage(error, '暂不能完成流水线，请确认所有候选人已完成评估。'));
    }
  }

  function openReview(item: AssessmentQueueItem) {
    const target = assessmentReviewTarget(item);
    setReviewCandidate(item);
    reviewForm.setFieldsValue({
      modality: target.modality,
      reason: '',
      override_score: target.score,
    });
  }

  async function openCandidateReport(item: AssessmentQueueItem) {
    setReportCandidate(item);
    const existing = candidateReportById.get(item.candidate_id);
    if (!existing) return;
    if (!existing.is_stale) {
      setCandidateReport(existing);
      return;
    }
    try {
      const result = await candidateReportsMutation.mutateAsync({
        candidateIds: [item.candidate_id],
        force: Boolean(existing?.is_stale),
      });
      if (!result.reports.length) {
        message.warning('该候选人暂时无法生成评估报告');
        return;
      }
      setCandidateReport(result.reports[0]);
      message.success(existing?.is_stale ? '评估报告已重新生成' : '评估报告已生成');
    } catch (error) {
      message.error(errorMessage(error, '评估报告生成失败'));
    }
  }

  async function generateAggregateReport() {
    try {
      const job = await aggregateReportMutation.mutateAsync();
      aggregateReportNotificationRef.current = '';
      if (job.status === 'queued' || job.status === 'running') {
        message.info('综合评估报告已进入后台生成，可继续使用页面');
      }
    } catch (error) {
      message.error(errorMessage(error, '综合评估报告生成失败'));
    }
  }

  function openResume(item: AssessmentQueueItem) {
    setResumeCandidate(
      pipelineCandidateById.get(item.candidate_id) ?? { id: item.candidate_id, name: item.candidate_name },
    );
  }

  async function openReplay(item: AssessmentQueueItem) {
    setReplayOpen(true);
    setReplayUrl('');
    setReplayError('');
    setReplayLoading(true);
    try {
      const resolvedPipelineId = await fetchMassPipelineForSource(pipelineId);
      const candidatePipelineIds = [...new Set([resolvedPipelineId, pipelineId].filter(Boolean))];
      let videoUrl = '';
      let foundCandidateWithoutFullRecording = false;

      for (const candidatePipelineId of candidatePipelineIds) {
        const streams = await fetchMassStreams(candidatePipelineId);
        const exactMatches = streams.streams.filter((stream) => stream.candidate_id === item.candidate_id);
        // The assessment pipeline and interview pipeline can use different
        // candidate IDs.  Name matching remains as a legacy bridge, but only
        // when it is unambiguous so candidates with the same name cannot share
        // a replay by accident.
        const nameMatches = streams.streams.filter((stream) => stream.candidate_name === item.candidate_name);
        const matched =
          exactMatches.find((stream) => stream.video_url) ??
          (exactMatches.length === 0 && nameMatches.length === 1 ? nameMatches[0] : undefined);
        if (matched?.video_url) {
          videoUrl = matched.video_url;
          break;
        }
        if (matched) {
          foundCandidateWithoutFullRecording = true;
        }
      }

      if (foundCandidateWithoutFullRecording) {
        throw new Error('该候选人未找到完整面试录像，不能将逐题录制作为回放。');
      }
      if (!videoUrl) throw new Error('未找到该候选人的面试视频');
      setReplayUrl(videoUrl);
    } catch (error) {
      setReplayError(errorMessage(error, '面试视频加载失败'));
    } finally {
      setReplayLoading(false);
    }
  }

  function openRetest(item: AssessmentQueueItem) {
    setRetestCandidate(item);
    retestForm.setFieldsValue({
      date: localDateValue(),
      time: '14:00',
      interviewer: '',
      meeting_url: '',
      note: '',
      location: '线上面试',
      duration_minutes: 60,
    });
  }

  async function submitRetest() {
    if (!retestCandidate) return;
    try {
      const values = await retestForm.validateFields();
      const { note, ...scheduleValues } = values;
      const result = await markMutation.mutateAsync({
        candidateId: retestCandidate.candidate_id,
        action: 'review',
        schedule: {
          ...scheduleValues,
          candidate_name: retestCandidate.candidate_name ?? retestCandidate.candidate_id,
          notes: note ?? '',
          round: '复试',
          method: 'online',
        },
      });
      setRetestSubmittedCandidateIds((current) => {
        const next = new Set(current);
        next.add(retestCandidate.candidate_id);
        return next;
      });
      setRetestCandidate(null);
      if (result.wecom_schedule?.status === 'failed') {
        message.warning(`复试安排已保存，但企业微信日程创建失败：${result.wecom_schedule.message ?? '未知错误'}`);
      } else if (result.wecom_schedule?.status === 'created') {
        message.success('复试安排已保存，并已同步至企业微信日程');
      } else if (result.wecom_schedule?.status === 'disabled') {
        message.warning('复试安排已保存；企业微信日程同步尚未启用');
      } else {
        message.success('复试安排已保存');
      }
      if (result.email_notification?.status === 'failed') {
        message.warning(`复试安排已保存，但候选人邮件发送失败：${result.email_notification.message ?? '未知错误'}`);
      } else if (result.email_notification?.status === 'skipped') {
        message.info(`复试安排已保存，候选人邮件未发送：${result.email_notification.message ?? '未配置邮箱'}`);
      }
    } catch (error) {
      if (error instanceof Error) message.error(errorMessage(error, '复试安排保存失败'));
    }
  }

  function confirmSendOffer(item: AssessmentQueueItem) {
    const candidateName = item.candidate_name || item.candidate_id;
    modal.confirm({
      title: `确认向 ${candidateName} 发送 Offer？`,
      content: '确认后将立即通过当前 HR 配置的邮箱发送录用通知，请确认候选人及邮箱信息无误。',
      okText: '确认发送',
      cancelText: '取消',
      centered: true,
      onOk: async () => {
        setSendingOfferCandidateId(item.candidate_id);
        try {
          const result = await offerMutation.mutateAsync(item.candidate_id);
          if (result.status !== 'sent') {
            throw new Error(result.message || 'Offer 邮件未发送');
          }
          setOfferSentCandidateIds((current) => {
            const next = new Set(current);
            next.add(item.candidate_id);
            return next;
          });
          message.success(`已向 ${candidateName} 发送 Offer`);
        } catch (error) {
          message.error(errorMessage(error, 'Offer 发送失败'));
          throw error;
        } finally {
          setSendingOfferCandidateId('');
        }
      },
    });
  }

  function candidateActions(item: AssessmentQueueItem) {
    const existingReport = candidateReportById.get(item.candidate_id);
    const reportActionLabel = candidateReportActionLabel(existingReport);
    const reportGenerating = !existingReport || generatingReportCandidateIds.has(item.candidate_id);
    const hasVideo =
      videoCandidateIds.has(item.candidate_id) ||
      Object.values(item.step_results ?? {}).some((result) => result.modality === 'video_interview');
    const hasRetestSchedule =
      retestSubmittedCandidateIds.has(item.candidate_id) || persistedRetestCandidateIds.has(item.candidate_id);
    const offerSent =
      offerSentCandidateIds.has(item.candidate_id) || persistedOfferCandidateIds.has(item.candidate_id);
    return (
      <div className="xiao-ping-table-actions">
        <Button
          size="small"
          icon={<XiaoPingActionIcon kind="report" />}
          className="xiao-ping-table-action xiao-ping-table-action--report"
          disabled={reportGenerating}
          loading={
            reportGenerating ||
            (candidateReportsMutation.isPending && reportCandidate?.candidate_id === item.candidate_id)
          }
          onClick={() => void openCandidateReport(item)}
        >
          {reportActionLabel}
        </Button>
        <Button
          size="small"
          icon={<XiaoPingActionIcon kind="resume" />}
          className="xiao-ping-table-action xiao-ping-table-action--resume"
          onClick={() => openResume(item)}
        >
          预览简历
        </Button>
        {hasVideo ? (
          <Button
            size="small"
            icon={<XiaoPingActionIcon kind="replay" />}
            className="xiao-ping-table-action xiao-ping-table-action--replay"
            onClick={() => void openReplay(item)}
          >
            面试回放
          </Button>
        ) : null}
        <Button
          size="small"
          icon={<XiaoPingActionIcon kind="retest" />}
          className="xiao-ping-table-action xiao-ping-table-action--retest"
          onClick={() => openRetest(item)}
        >
          复试
        </Button>
        <Button
          size="small"
          icon={<XiaoPingActionIcon kind="review" />}
          className="xiao-ping-table-action xiao-ping-table-action--review"
          onClick={() => openReview(item)}
        >
          人工复核
        </Button>
        {hasRetestSchedule ? (
          <Button
            size="small"
            icon={<XiaoPingActionIcon kind="offer" />}
            className="xiao-ping-table-action xiao-ping-table-action--retest-result"
            loading={sendingOfferCandidateId === item.candidate_id}
            disabled={offerSent}
            onClick={() => confirmSendOffer(item)}
          >
            {offerSent ? 'Offer已发送' : '发送offer'}
          </Button>
        ) : null}
      </div>
    );
  }

  const decisionRankByCandidateId = new Map(
    ready.map((item, index) => [item.candidate_id, index + 1]),
  );

  const columns: DataTableColumn<AssessmentQueueItem>[] = [
    {
      key: 'rank',
      title: '候选人排名',
      width: 112,
      align: 'center',
      render: (_value, item) => (
        <CandidateRankBadge rank={decisionRankByCandidateId.get(item.candidate_id) ?? ready.length} />
      ),
    },
    {
      key: 'candidate_name',
      role: 'identity',
      title: '候选人',
      dataIndex: 'candidate_name',
      width: 150,
      render: (name: string) => <CandidateIdentity name={name} />,
    },
    {
      key: 'decision_score',
      title: '综合评分',
      width: 140,
      render: (_value, item) => (
        <div className="xiao-ping-score">
          <strong>{decisionScore(item)}<small>分</small></strong>
          <span className={`xiao-ping-score__source xiao-ping-score__source--${item.decision_score_source || 'default'}`}>
            {decisionScoreSource(item)}
          </span>
        </div>
      ),
      sorter: (left, right) => decisionScore(left) - decisionScore(right),
    },
    {
      key: 'recommendation',
      title: '建议',
      dataIndex: 'recommendation',
      width: 100,
      render: (_value, item) => (
        <span className={`xiao-ping-outcome xiao-ping-outcome--${decisionOutcome(item) === '通过' ? 'pass' : 'reject'}`}>
          {decisionOutcome(item)}
        </span>
      ),
    },
    {
      key: 'actions',
      role: 'actions',
      title: '操作',
      width: 420,
      render: (_value, item) => candidateActions(item),
    },
  ];

  return (
    <div
      className="agent-page xun-app agent-page--decision"
      style={{ display: 'flex', flexDirection: 'column', padding: 0, height: '100vh', overflow: 'hidden' }}
    >
      <AgentTopbar
        pipelineId={pipelineId}
        mark="评"
        title={pipeline.role}
        subtitle="小评 · 录用评估"
        status={
          isPipelineCompleted
            ? { label: '岗位已完成', tone: 'ok' }
            : report
              ? { label: '报告已生成', tone: 'ok' }
              : { label: '报告待生成' }
        }
        secondaryActions={
          isPipelineCompleted ? (
            <button
              className="agent-topbar__primary"
              type="button"
              onClick={() => navigate(routePaths.studio)}
              title="返回招聘岗位管理"
            >
              返回首页
            </button>
          ) : (
            <button
              className="agent-topbar__primary"
              type="button"
              onClick={() => navigate(routePaths.massDashboard(pipelineId))}
              title="返回面试中心"
            >
              返回面试中心
            </button>
          )
        }
        primaryAction={{
          label: isPipelineCompleted ? '已完成' : '完成流水线',
          onClick: () => void completePipeline(),
          disabled: isPipelineCompleted,
          loading: completePipelineMutation.isPending,
          title: isPipelineCompleted
            ? '该流水线已完成'
            : report
              ? '确认所有候选人已完成评估后，完成流水线'
              : '点击后将提示完成流水线所需条件',
        }}
      />
      <main
        className="agent-page__body xun-workspace xun-workspace--xiao-ping"
        style={{ maxWidth: 'none', width: '100%', margin: 0, flex: 1, minHeight: 0, gap: 0 }}
      >
        <section className="agent-page__main xun-center-pane xiao-ping-pane">
          <Row gutter={12} align="stretch" justify="center" className="agent-kpis">
            <Col flex="0 1 432px">
              <Card className="xiao-ping-kpi xiao-ping-kpi--pass">
                <div className="xiao-ping-kpi__metric">
                  <Statistic title="通过" value={groups.pass.length} styles={{ content: { color: '#16a34a' } }} />
                  <span className="xiao-ping-kpi__divider" aria-hidden="true" />
                  <div className="xiao-ping-kpi__hint">
                    <span className="xiao-ping-kpi__hint-title">60 分即通过</span>
                    <span className="xiao-ping-kpi__hint-sub">AI 横向比较通过候选人，给出综合录用建议</span>
                  </div>
                </div>
              </Card>
            </Col>
            <Col flex="0 1 432px">
              <Card className="xiao-ping-kpi xiao-ping-kpi--eliminate">
                <div className="xiao-ping-kpi__metric">
                  <Statistic title="淘汰" value={groups.eliminate.length} styles={{ content: { color: '#dc2626' } }} />
                  <span className="xiao-ping-kpi__divider" aria-hidden="true" />
                  <div className="xiao-ping-kpi__hint">
                    <span className="xiao-ping-kpi__hint-title xiao-ping-kpi__hint-title--eliminate">低于 60 分</span>
                    <span className="xiao-ping-kpi__hint-sub">不满足录用标准，不建议录取</span>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>
          {queue.counts.ready_for_decision + queue.counts.incomplete === 0 ? (
            <Alert
              type="info"
              showIcon
              style={{ marginBottom: 12 }}
              title="评估队列为空，请先完成上游环节"
              description={
                <span>
                  1. 在 <Link to={agentWorkspaceUrl('xiao_xun', pipelineId)}>小寻</Link> 导入简历；2. 在{' '}
                  <Link to={agentWorkspaceUrl('xiao_shai', pipelineId)}>小筛</Link> 完成筛查；3. 在{' '}
                  <Link to={agentWorkspaceUrl('xiao_mian', pipelineId)}>小面</Link>{' '}
                  出题并完成面试评估。候选人才会进入评估队列。
                </span>
              }
            />
          ) : null}
          <Card
            title={
              <Space split={<Typography.Text type="secondary">·</Typography.Text>} size="small">
                <Typography.Text strong>评估队列</Typography.Text>
                <Typography.Text type="secondary">候选人排名与录用建议</Typography.Text>
              </Space>
            }
            extra={
              <Space size="small">
                <Button
                  type="primary"
                  size="small"
                  disabled={!groups.pass.length || aggregateReportMutation.isPending || aggregateReportRunning}
                  loading={aggregateReportMutation.isPending || aggregateReportRunning}
                  onClick={() => void generateAggregateReport()}
                >
                  {aggregateReportRunning
                    ? '综合评估报告生成中'
                    : report
                      ? '重新生成综合评估报告'
                      : '生成综合评估报告'}
                </Button>
                {report ? (
                  <Button size="small" onClick={() => setAggregateReportOpen(true)}>
                    查看综合评估报告
                  </Button>
                ) : null}
              </Space>
            }
            className="agent-card xiao-ping-queue-card"
          >
            {queue.incomplete.length ? (
              <Alert type="info" showIcon title={`${queue.incomplete.length} 位候选人评估未完成`} />
            ) : null}
            <DataTable
              tableId="assessment-ready"
              compact
              className="xiao-ping-evaluation-table"
              rowKey="candidate_id"
              dataSource={ready}
              columns={columns}
              pagination={{ pageSize: 8 }}
              locale={{ emptyText: '暂无可正式决策的候选人' }}
            />
          </Card>
        </section>
      </main>
      <Modal
        title={`综合评估报告 · ${pipeline.role}`}
        open={aggregateReportOpen && Boolean(report)}
        onCancel={() => setAggregateReportOpen(false)}
        width={1000}
        footer={<Button onClick={() => setAggregateReportOpen(false)}>关闭</Button>}
        styles={{ body: { maxHeight: '72vh', overflowY: 'auto' } }}
      >
        {report ? (
          <AggregateReportPreview
            report={report}
            groups={groups}
            candidateReportById={candidateReportById}
          />
        ) : null}
      </Modal>
      <Modal
        title={
          <Space>
            <span>{`候选人评估报告 · ${candidateReport?.candidate_name || ''}`}</span>
            {candidateReport ? (
              <Tag color={candidateReport.is_formal ? 'success' : 'warning'}>
                {candidateReport.is_formal ? '正式报告' : '待复核草稿'}
              </Tag>
            ) : null}
          </Space>
        }
        open={Boolean(candidateReport)}
        onCancel={() => { setCandidateReport(null); setReportCandidate(null); }}
        width={1000}
        footer={
          candidateReport ? (
            <Space>
              <Button onClick={() => { setCandidateReport(null); setReportCandidate(null); }}>关闭</Button>
              <Button
                type="primary"
                onClick={() => printCandidateReports([candidateReport], pipeline.role)}
              >
                导出 PDF
              </Button>
            </Space>
          ) : null
        }
        styles={{ body: { maxHeight: '72vh', overflowY: 'auto' } }}
      >
        {candidateReport ? <CandidateReportPreview report={candidateReport} assessment={reportCandidate} /> : null}
      </Modal>
      <Modal
        title={null}
        open={replayOpen}
        onCancel={() => setReplayOpen(false)}
        footer={null}
        width={960}
        destroyOnHidden
        styles={{ body: { padding: 0 } }}
      >
        {replayLoading ? (
          <div className="app-loading" style={{ minHeight: 360 }}><Spin size="large" /></div>
        ) : replayError ? (
          <Alert type="error" showIcon message={replayError} />
        ) : replayUrl ? (
          <video aria-label="面试回放视频" controls autoPlay playsInline src={replayUrl} style={{ display: 'block', width: '100%' }} />
        ) : null}
      </Modal>
      <Modal
        title={`人工复核 · ${reviewCandidate?.candidate_name || ''}`}
        open={Boolean(reviewCandidate)}
        onCancel={() => setReviewCandidate(null)}
        onOk={() => void submitReview()}
        cancelText="取消"
        okText="确定"
        okButtonProps={{ loading: reviewMutation.isPending }}
      >
        <Form form={reviewForm} layout="vertical">
          <Form.Item name="modality" label="评估环节" rules={[{ required: true }]}>
            <Select
              options={[
                { value: 'manual_interview', label: '人工面试' },
                { value: 'video_interview', label: '视频面试' },
                { value: 'written_test', label: '在线笔试' },
              ]}
            />
          </Form.Item>
          <Form.Item
            name="override_score"
            label="复核分数"
            extra={
              reviewTarget.scoreStatus === 'provisional'
                ? '部分题目识别或评分异常，当前为有效题平均暂定分；请确认或调整后完成复核。'
                : reviewTarget.requiresOverride
                ? '自动评分失败或没有有效分数，必须由人工给出 0–100 分。'
                : '可留空以确认原评分。'
            }
            rules={[
              {
                required: reviewTarget.requiresOverride,
                message: '自动评分无效时必须填写复核分数',
              },
            ]}
          >
            <InputNumber min={0} max={100} style={{ width: '100%' }} />
          </Form.Item>
          <Form.Item
            name="reason"
            label="复核原因"
            rules={[{ required: true, whitespace: true, message: '请填写复核原因' }]}
          >
            <Input.TextArea rows={4} />
          </Form.Item>
        </Form>
      </Modal>
      <Modal
        title={`安排复试 · ${retestCandidate?.candidate_name || ''}`}
        open={Boolean(retestCandidate)}
        onCancel={() => setRetestCandidate(null)}
        onOk={() => void submitRetest()}
        okText="保存安排"
        cancelText="取消"
        okButtonProps={{ loading: markMutation.isPending }}
      >
        <Form form={retestForm} layout="vertical">
          <Form.Item name="date" label="复试日期" rules={[{ required: true, message: '请选择复试日期' }]}>
            <Input type="date" min={localDateValue()} />
          </Form.Item>
          <Form.Item name="time" label="面试时间">
            <Input type="time" min={retestDate === localDateValue() ? nextMinuteValue() : undefined} />
          </Form.Item>
          <Form.Item
            name="interviewer"
            label="面试官"
            rules={[{ required: true, message: '请输入面试官姓名' }]}
            extra="仅用于复试安排展示；企业微信接收人由后端统一配置。"
          >
            <Input placeholder="例如：李经理" />
          </Form.Item>
          <Form.Item
            name="meeting_url"
            label="腾讯会议"
            rules={[{ type: 'url', message: '请输入有效的腾讯会议链接' }]}
            extra="填写后将随复试安排一并推送到企业微信。"
          >
            <Input placeholder="请输入腾讯会议链接" />
          </Form.Item>
          <Form.Item name="note" label="备注">
            <Input.TextArea rows={3} placeholder="复试重点考察方向" />
          </Form.Item>
          <Form.Item name="location" label="地点">
            <Input placeholder="例如：线上面试 / 上海总部 3A" />
          </Form.Item>
          <Form.Item name="duration_minutes" label="时长（分钟）">
            <InputNumber min={1} max={1440} style={{ width: '100%' }} />
          </Form.Item>
        </Form>
      </Modal>
      <ResumePreviewModal pipelineId={pipelineId} candidate={resumeCandidate} onClose={() => setResumeCandidate(null)} />
    </div>
  );
}

function CandidateReportPreview({
  report,
  assessment,
}: {
  report: CandidateAssessmentReport;
  assessment: AssessmentQueueItem | null;
}) {
  const analyses = assessmentQuestionAnalyses(assessment);
  const conclusionTone = candidateReportConclusionTone(report);
  return (
    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
      <Card size="small" title="综合评价">
        <Typography.Paragraph style={{ marginBottom: 0 }}>
          {report.comprehensive_evaluation || '暂无综合评价'}
        </Typography.Paragraph>
      </Card>
      <Card size="small" title="录用建议">
        <Typography.Paragraph style={{ marginBottom: 0 }}>
          {report.hiring_advice || '暂无录用建议'}
        </Typography.Paragraph>
      </Card>
      <Alert
        showIcon
        type={conclusionTone}
        title={report.is_formal ? `正式结论：${report.recommendation}` : report.report_status}
        description={
          report.is_formal
            ? `最终成绩采用${report.score_source_label}。`
            : '当前报告为草稿，不作为正式录用结论。'
        }
      />
      <Row gutter={12}>
        <Col span={8}><Statistic title="成绩" value={report.score ?? '—'} suffix={report.score == null ? '' : '分'} /></Col>
        <Col span={8}><Statistic title="成绩来源" value={report.score_source_label} /></Col>
        <Col span={8}><Statistic title="录用等级" value={report.recommendation} /></Col>
      </Row>
      <Card size="small" title="关键结论">
        <Typography.Paragraph><Typography.Text strong>优势：</Typography.Text>{report.strengths.join('；') || '暂无充分证据'}</Typography.Paragraph>
        <Typography.Paragraph style={{ marginBottom: 0 }}><Typography.Text strong>风险：</Typography.Text>{report.risks.join('；') || '暂无明确风险项'}</Typography.Paragraph>
      </Card>
      <Card size="small" title="逐题分析">
        <QuestionAnalysisList analyses={analyses} />
      </Card>
    </Space>
  );
}

export function candidateReportConclusionTone(report: Pick<CandidateAssessmentReport, 'is_formal' | 'recommendation'>) {
  if (!report.is_formal) return 'warning' as const;
  return report.recommendation === '通过' ? 'success' as const : 'error' as const;
}

function QuestionAnalysisList({ analyses }: { analyses: ReturnType<typeof assessmentQuestionAnalyses> }) {
  if (!analyses.length) return <Empty description="暂无逐题评价数据" />;
  return (
    <Collapse
      items={analyses.map((item) => ({
        key: item.key,
        label: (
          <Space wrap>
            <Typography.Text strong>第 {item.questionIndex + 1} 题</Typography.Text>
            <Tag color={item.modality === 'written_test' ? 'blue' : 'purple'}>
              {item.modality === 'written_test' ? '在线笔试' : '视频面试'}
            </Tag>
            <Tag color={item.technicalFailure ? 'error' : item.reviewRequired ? 'warning' : 'success'}>
              {item.technicalFailure ? '系统异常 · 0 分' : item.reviewRequired ? '待人工审核' : `${item.score} 分`}
            </Tag>
          </Space>
        ),
        children: (
          <Space direction="vertical" size="middle" style={{ width: '100%' }}>
            <div>
              <Typography.Text type="secondary">题目</Typography.Text>
              <Typography.Paragraph style={{ marginBottom: 0 }}>{item.question}</Typography.Paragraph>
            </div>
            <div>
              <Typography.Text type="secondary">候选人作答</Typography.Text>
              <Typography.Paragraph style={{ marginBottom: 0 }}>{item.answer || '未记录到有效作答'}</Typography.Paragraph>
            </div>
            <Alert
              type={item.technicalFailure ? 'error' : item.reviewRequired ? 'warning' : 'info'}
              showIcon
              title={item.technicalFailure ? '系统评分异常，已按 0 分计入总分' : item.reviewRequired ? 'AI 评价未完成，需人工审核' : 'AI 评价'}
              description={item.technicalFailure ? item.failureReason || '自动评分失败' : item.comment || '未返回逐题评价'}
            />
            {item.candidateFeedback ? (
              <Typography.Paragraph><Typography.Text strong>改进建议：</Typography.Text>{item.candidateFeedback}</Typography.Paragraph>
            ) : null}
            {item.hitPoints.length ? (
              <div><Typography.Text type="secondary">命中要点</Typography.Text><div>{item.hitPoints.map((point) => <Tag color="success" key={point}>{point}</Tag>)}</div></div>
            ) : null}
            {item.missedPoints.length ? (
              <div><Typography.Text type="secondary">遗漏要点</Typography.Text><div>{item.missedPoints.map((point) => <Tag color="warning" key={point}>{point}</Tag>)}</div></div>
            ) : null}
            {item.criteria.length ? (
              <Space direction="vertical" size="small" style={{ width: '100%' }}>
                <Typography.Text type="secondary">评分依据</Typography.Text>
                {item.criteria.map((criterion) => (
                  <Card size="small" key={criterion.id}>
                    <Space wrap>
                      <Typography.Text strong>{criterion.name}</Typography.Text>
                      {criterion.score !== undefined ? <Tag>{criterion.score} 分</Tag> : null}
                      {criterion.level !== undefined ? <Tag>等级 {criterion.level}</Tag> : null}
                      {criterion.confidence !== undefined ? <Tag>置信度 {Math.round(criterion.confidence * 100)}%</Tag> : null}
                    </Space>
                    {criterion.evidence ? <Typography.Paragraph type="secondary" style={{ margin: '8px 0 0' }}>{criterion.evidence}</Typography.Paragraph> : null}
                  </Card>
                ))}
              </Space>
            ) : null}
          </Space>
        ),
      }))}
    />
  );
}

function AggregateReportPreview({
  report,
  groups,
  candidateReportById,
}: {
  report: ReportData;
  groups: ReturnType<typeof reportGroups>;
  candidateReportById: Map<string, CandidateAssessmentReport>;
}) {
  const rankedPassed = (report.ranking?.length ? report.ranking : groups.pass)
    .filter((item) => decisionOutcome(item) === '通过')
    .sort((left, right) => decisionScore(right) - decisionScore(left));
  const matrix = reportRecord(report.comparison_matrix);
  const dimensions = reportStringList(matrix.dimensions);
  const matrixRows = (Array.isArray(matrix.candidates) ? matrix.candidates : [])
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .map((item, index) => ({
      key: String(item.candidate_id ?? item.name ?? index),
      name: String(item.candidate_name ?? item.name ?? '未知'),
      scores: Array.isArray(item.scores) ? item.scores : [],
    }));
  const nextSteps = reportStepList(report.next_steps);

  return (
    <Space direction="vertical" size="middle" style={{ width: '100%' }}>
      <Alert
        type="success"
        showIcon
        message={`已完成 ${rankedPassed.length} 位通过候选人的综合分析`}
        description={report.executive_summary || '已对所有通过候选人完成横向分析。'}
      />
      <Card size="small" title="候选人总体评价">
        <Typography.Paragraph>
          <Typography.Text strong>团队匹配：</Typography.Text>
          {String(report.team_fit_analysis || '暂无团队匹配度补充评价')}
        </Typography.Paragraph>
        <Typography.Paragraph>
          <Typography.Text strong>整体风险：</Typography.Text>
          {String(report.risk_assessment || '暂无整体风险补充评价')}
        </Typography.Paragraph>
        {report.market_insights ? (
          <Typography.Paragraph style={{ marginBottom: 0 }}>
            <Typography.Text strong>市场建议：</Typography.Text>
            {String(report.market_insights)}
          </Typography.Paragraph>
        ) : null}
      </Card>
      {dimensions.length && matrixRows.length ? (
        <Card size="small" title="候选人横向对比">
          <Table
            size="small"
            pagination={false}
            rowKey="key"
            dataSource={matrixRows}
            columns={[
              { title: '候选人', dataIndex: 'name', fixed: 'left' },
              ...dimensions.map((dimension, index) => ({
                title: dimension,
                render: (_value: unknown, item: (typeof matrixRows)[number]) => String(item.scores[index] ?? '—'),
              })),
            ]}
            scroll={{ x: 'max-content' }}
          />
        </Card>
      ) : null}
      <Typography.Title level={4} style={{ margin: '8px 0 0' }}>候选人 AI 评价</Typography.Title>
      {rankedPassed.map((item, index) => {
        const saved = candidateReportById.get(item.candidate_id);
        const strengths = reportStringList(item.key_strengths ?? saved?.strengths);
        const risks = reportStringList(item.risks ?? saved?.risks);
        const salary = reportRecord(item.salary_strategy);
        const aiEvaluation = String(
          item.ai_evaluation ||
            item.overall_evaluation ||
            saved?.comprehensive_evaluation ||
            item.reason ||
            item.recommendation ||
            '暂无 AI 综合评价',
        );
        const hiringAdvice = String(
          item.hiring_advice || saved?.hiring_advice || item.recommendation || '暂无录用建议',
        );
        return (
          <Card
            size="small"
            key={item.candidate_id || String(index)}
            title={
              <Space wrap>
                <CandidateRankBadge rank={index + 1} />
                <Typography.Text strong>{String(item.candidate_name || item.name || '未知')}</Typography.Text>
                <Tag color="success">{decisionScore(item)} 分</Tag>
              </Space>
            }
          >
            <Typography.Paragraph>
              <Typography.Text strong>AI 综合评价：</Typography.Text>{aiEvaluation}
            </Typography.Paragraph>
            <Typography.Paragraph>
              <Typography.Text strong>录用建议：</Typography.Text>{hiringAdvice}
            </Typography.Paragraph>
            {strengths.length ? (
              <Typography.Paragraph>
                <Typography.Text strong>核心优势：</Typography.Text>{strengths.join('；')}
              </Typography.Paragraph>
            ) : null}
            {risks.length ? (
              <Typography.Paragraph>
                <Typography.Text strong>风险关注：</Typography.Text>{risks.join('；')}
              </Typography.Paragraph>
            ) : null}
            {salary.suggested || salary.negotiation_tip ? (
              <Typography.Paragraph>
                <Typography.Text strong>薪资建议：</Typography.Text>
                {String(salary.suggested || '待 HR 确认')}
                {salary.negotiation_tip ? `；${String(salary.negotiation_tip)}` : ''}
              </Typography.Paragraph>
            ) : null}
            {item.onboarding_plan ? (
              <Typography.Paragraph style={{ marginBottom: 0 }}>
                <Typography.Text strong>培养建议：</Typography.Text>{String(item.onboarding_plan)}
              </Typography.Paragraph>
            ) : null}
          </Card>
        );
      })}
      {nextSteps.length ? (
        <Card size="small" title="下一步建议">
          <ul style={{ marginBottom: 0, paddingLeft: 20 }}>
            {nextSteps.map((item, index) => <li key={`${item}-${index}`}>{item}</li>)}
          </ul>
        </Card>
      ) : null}
    </Space>
  );
}

function reportRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function reportStringList(value: unknown): string[] {
  if (!Array.isArray(value)) return value ? [String(value)] : [];
  return value.map(String).filter(Boolean);
}

function reportStepList(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    if (!item || typeof item !== 'object') return String(item);
    const step = item as Record<string, unknown>;
    return [step.action, step.owner ? `负责人：${String(step.owner)}` : '', step.deadline_days ? `${String(step.deadline_days)} 天内` : '']
      .filter(Boolean)
      .map(String)
      .join(' · ');
  }).filter(Boolean);
}
