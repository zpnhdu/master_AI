import '@testing-library/jest-dom/vitest';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { AuthProvider } from '../auth/AuthContext';
import { XiaoHaiPage } from './XiaoHaiPage';
import type { PosterJob } from '../../features/xiao-hai/api';

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('XiaoHaiPage persisted jobs', () => {
  function mockWorkspace() {
    const state: { job: PosterJob; offline: boolean } = {
      offline: false,
      job: {
        id: 'job-1', pipeline_id: 'p1', source: 'workspace', status: 'running', phase: 'generating', progress: 38,
        elapsed_seconds: 80, estimated_remaining_seconds: [40, 120], created_at: '2026-08-31T00:00:00Z',
        server_time: '2026-08-31T00:01:20Z', estimate_basis: 'default', estimate_overrun: false, result_version_id: '',
      },
    };
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/xiao-hai/p1/jobs' && init?.method === 'POST') {
        state.job = { ...state.job, id: 'job-retry', status: 'running', phase: 'preparing', progress: 10 };
        return Promise.resolve(jsonResponse({ job: state.job }));
      }
      if (path === '/api/xiao-hai/p1/jobs') {
        return state.offline ? Promise.reject(new TypeError('network offline')) : Promise.resolve(jsonResponse({ jobs: [state.job] }));
      }
      if (path.endsWith('/cancel')) {
        state.job = { ...state.job, status: 'cancel_requested' };
        return Promise.resolve(jsonResponse({ status: 'cancel_requested' }));
      }
      if (path === '/api/xiao-hai/p1/bootstrap') {
        const id = state.job.status === 'succeeded' ? 'v2' : 'v1';
        return Promise.resolve(jsonResponse({
          pipeline_id: 'p1', role: '门店导购', jd_ready: true, fields: { jobTitle: '门店导购' },
          poster: { selected_version_id: id },
          versions: [{ id, image_url: `/poster-${id}.png`, canvas_id: 'long' }],
          canvases: [{ id: 'long', label: '招聘长图' }], default_canvas_id: 'long',
        }));
      }
      if (path === '/api/xiao-hai/elements') return Promise.resolve(jsonResponse({ backgrounds: [], elements: [] }));
      if (path === '/api/pipelines/p1') return Promise.resolve(jsonResponse({ id: 'p1', role: '门店导购', stages: [] }));
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path.includes('/state?')) return Promise.resolve(jsonResponse({ messages: [], recent_commands: [] }));
      return Promise.resolve(jsonResponse({}));
    });
    vi.stubGlobal('fetch', fetchMock);
    const posts = () => fetchMock.mock.calls.filter(([url, init]) => String(url) === '/api/xiao-hai/p1/jobs' && init?.method === 'POST');
    return { state, fetchMock, posts };
  }

  it('restores an active job, keeps history accessible, cancels safely and retries once', async () => {
    const { state, posts } = mockWorkspace();
    const view = renderPage();
    expect(await screen.findByText('已用 1 分 20 秒')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '生成新版本' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '切换到 V1 · 招聘长图' })).not.toBeDisabled();
    expect(posts()).toHaveLength(0);
    fireEvent.click(screen.getByRole('button', { name: '取消生成' }));
    expect(await screen.findByText('正在取消生成')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '取消生成' })).toBeDisabled();
    state.job = { ...state.job, status: 'cancelled' };
    await act(() => view.queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'jobs', 'p1'] }));
    await waitFor(() => expect(screen.getByRole('button', { name: '生成新版本' })).not.toBeDisabled());
    fireEvent.click(screen.getByRole('button', { name: '生成新版本' }));
    fireEvent.click(screen.getByRole('button', { name: '生成新版本' }));
    await waitFor(() => expect(posts()).toHaveLength(1));
    expect(JSON.parse(String(posts()[0][1]?.body)).client_request_id).toBeTruthy();
    expect(await screen.findByText('准备素材')).toBeInTheDocument();
    state.job = { ...state.job, status: 'failed', error_message: '模拟任务失败' };
    await act(() => view.queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'jobs', 'p1'] }));
    fireEvent.click(await screen.findByRole('button', { name: '从当前配置重试' }));
    await waitFor(() => expect(posts()).toHaveLength(2));
  }, 20_000);

  it('reconnects by reading the original job and refreshes the poster only on completion', async () => {
    const { state, fetchMock, posts } = mockWorkspace();
    const view = renderPage();
    await screen.findByText('生成画面');
    const bootstrapCalls = () => fetchMock.mock.calls.filter(([url]) => String(url) === '/api/xiao-hai/p1/bootstrap').length;
    const initial = bootstrapCalls();
    state.job = { ...state.job, elapsed_seconds: 84 };
    await act(() => view.queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'jobs', 'p1'] }));
    expect(bootstrapCalls()).toBe(initial);
    state.offline = true;
    await act(() => view.queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'jobs', 'p1'] }));
    expect(await screen.findByText('连接中断，正在恢复状态')).toBeInTheDocument();
    expect(posts()).toHaveLength(0);
    state.offline = false;
    state.job = { ...state.job, status: 'succeeded', phase: 'completed', progress: 100, result_version_id: 'v2' };
    await act(() => view.queryClient.invalidateQueries({ queryKey: ['xiao-hai', 'jobs', 'p1'] }));
    await waitFor(() => expect(screen.getByRole('img', { name: '门店导购 招聘海报' })).toHaveAttribute('src', '/poster-v2.png'));
    expect(screen.getByText('100%')).toBeInTheDocument();
    expect(posts()).toHaveLength(0);
  }, 20_000);
});

function jsonResponse(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), { status, headers: { 'Content-Type': 'application/json' } });
}

function renderPage() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const rendered = render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={['/xiao-hai?pipeline=p1']}>
        <AntdApp>
          <AuthProvider>
            <XiaoHaiPage />
          </AuthProvider>
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
  return { ...rendered, queryClient };
}

describe('XiaoHaiPage generation failures', () => {
  it('keeps a visible retry action when image generation fails', async () => {
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/xiao-hai/p1/bootstrap') {
        return Promise.resolve(
          jsonResponse({
            pipeline_id: 'p1',
            role: '门店导购',
            jd_ready: true,
            fields: { jobTitle: '门店导购' },
            poster: {},
            versions: [],
            canvases: [{ id: 'long', label: '长图母版' }],
            default_canvas_id: 'long',
          }),
        );
      }
      if (path === '/api/pipelines/p1') {
        return Promise.resolve(
          jsonResponse({
            id: 'p1',
            role: '门店导购',
            agents: ['xiao_hai'],
            candidates: [],
            stages: [{ stage_id: 'jd_write', status: 'done', output: { jd: { title: '门店导购' } } }],
          }),
        );
      }
      if (path === '/api/xiao-hai/elements') return Promise.resolve(jsonResponse({ backgrounds: [], elements: [] }));
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path === '/api/conversations/sessions/session-1/state?limit=100') return Promise.resolve(jsonResponse({ messages: [], recent_commands: [] }));
      if (path === '/api/xiao-hai/p1/jobs' && init?.method === 'POST') {
        return Promise.resolve(jsonResponse({ detail: 'GPT Image 2 curl 命令失败: TLS connection closed（502）' }, 502));
      }
      return Promise.resolve(jsonResponse({}));
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByRole('button', { name: '传递给下游' })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '上传临时参考图' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '导入' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '生成招聘长图' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /生成小红书/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /生成朋友圈/ })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /素材：品牌默认/ })).toBeInTheDocument();

    fireEvent.click(await screen.findByRole('button', { name: '生成新版本' }));

    expect(await screen.findByText('海报生成失败')).toBeInTheDocument();
    const generationErrorAlert = screen
      .getAllByRole('alert')
      .find((alert) => within(alert).queryByText('海报生成失败'));
    expect(generationErrorAlert).toBeDefined();
    expect(
      within(generationErrorAlert!).getByText('连接中断，正在恢复任务状态。请先确认已有任务的结果，再决定是否重试。'),
    ).toBeInTheDocument();
    const retryButton = screen.getByRole('button', { name: '从当前配置重试' });
    expect(retryButton).not.toBeDisabled();
    fireEvent.click(retryButton);
    await waitFor(() => {
      const generateCalls = fetchMock.mock.calls.filter(([url, init]) => String(url) === '/api/xiao-hai/p1/jobs' && init?.method === 'POST');
      expect(generateCalls).toHaveLength(2);
      expect(JSON.parse(String(generateCalls[0]?.[1]?.body))).not.toHaveProperty('mode');
    }, { timeout: 8_000 });
  }, 12_000);
});

describe('XiaoHaiPage poster-first workspace', () => {
  it('keeps the poster primary and makes version/material controls lightweight', async () => {
    const neverResolvingPipeline = new Promise<Response>(() => undefined);
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/xiao-hai/p1/bootstrap') {
        return Promise.resolve(jsonResponse({
          pipeline_id: 'p1',
          role: '门店导购',
          jd_ready: true,
          fields: { jobTitle: '门店导购', salary: '6-8K' },
          poster: { selected_version_id: 'v1', approval_status: 'pending' },
          versions: [{
            id: 'v1',
            image_url: '/poster-v1.png',
            image_asset_id: 'asset-v1',
            canvas_id: 'long',
            fields: { jobTitle: '门店导购', salary: '6-8K' },
            render_data: { raw_image_asset_id: 'raw-v1', background_element_id: 'bg-shop', element_ids: ['element-mascot'] },
          }],
          canvases: [{ id: 'long', label: '招聘长图', width: 1080, height: 2400 }],
          default_canvas_id: 'long',
        }));
      }
      if (path === '/api/pipelines/p1') return neverResolvingPipeline;
      if (path === '/api/xiao-hai/elements') return Promise.resolve(jsonResponse({ backgrounds: [], elements: [] }));
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path === '/api/conversations/sessions/session-1/state?limit=100') {
        return Promise.resolve(jsonResponse({
          messages: [
            { id: 'user-1', role: 'user', content: '把背景改成红色' },
            { id: 'assistant-1', role: 'assistant', content: '暂时无法生成操作预览，请稍后重试或调整描述。' },
          ],
          recent_commands: [{ id: 'command-1', status: 'queued', result: { reply: '已开始生成新版本。' } }],
        }));
      }
      if (path === '/api/conversations/sessions/session-1/messages' && init?.method === 'POST') {
        return Promise.resolve(jsonResponse({}));
      }
      if (path === '/api/xiao-hai/p1/jobs' && init?.method === 'POST') {
        return Promise.resolve(jsonResponse({ job: { id: 'job-2', status: 'queued', source: 'workspace', phase: 'queued', progress: 0, elapsed_seconds: 0 } }));
      }
      return Promise.resolve(jsonResponse({}));
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByRole('button', { name: '切换到 V1 · 招聘长图' })).toBeInTheDocument();
    expect(screen.getByRole('img', { name: '门店导购 招聘海报' })).toHaveAttribute('src', '/poster-v1.png');
    expect(screen.queryByRole('complementary', { name: '版本与海报配置' })).not.toBeInTheDocument();
    const workbench = screen.getByRole('region', { name: '海报工作台' });
    const workspace = screen.getByRole('main');
    expect(workspace).toHaveClass('xhai-workspace--version-sidebar');
    expect(within(workspace).getByRole('region', { name: '海报版本' })).toHaveClass('xhai-version-strip--sidebar');
    expect(within(workspace).getByText('版本记录')).toBeInTheDocument();
    expect(within(workbench).getByRole('button', { name: /素材：/ })).toBeInTheDocument();
    expect(within(workbench).getByText('发布画幅')).toBeInTheDocument();
    expect(within(workbench).getByRole('button', { name: /小红书/ })).toBeInTheDocument();
    expect(within(workbench).getByRole('button', { name: /朋友圈/ })).toBeInTheDocument();
    expect(within(workbench).queryByText('社媒单图')).not.toBeInTheDocument();
    expect(within(workbench).getByRole('region', { name: '海报预览' })).toBeInTheDocument();
    const conversationPane = screen.getByRole('complementary', { name: '与小海对话' });
    expect(conversationPane).toHaveClass('xhai-chat-pane');
    expect(within(conversationPane).queryByRole('button', { name: '上传临时参考图' })).not.toBeInTheDocument();
    const posterToolbar = within(workbench).getByRole('toolbar', { name: '海报操作' });
    expect(within(posterToolbar).queryByRole('button', { name: '编辑文案' })).not.toBeInTheDocument();
    expect(within(posterToolbar).getByRole('button', { name: '下载' })).toBeInTheDocument();
    expect(within(posterToolbar).getByRole('button', { name: '确认海报' })).toHaveClass('ant-btn-default');
    expect(within(posterToolbar).getByRole('button', { name: '生成新版本' })).not.toHaveClass('ant-btn-primary');
    expect(within(posterToolbar).queryByRole('button', { name: '传递给下游' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '传递给下游' })).toBeInTheDocument();
    expect(screen.queryByText('海报制作中')).not.toBeInTheDocument();
    expect(screen.getAllByText('待确认')).toHaveLength(2);
    expect(within(workbench).getByRole('button', { name: '门店导购 招聘海报' })).toHaveClass('xhai-poster-scroll--stage');
    expect(screen.queryByRole('tab', { name: '当前海报' })).not.toBeInTheDocument();
    expect(screen.queryByText('海报修改预览')).not.toBeInTheDocument();
    expect(within(conversationPane).queryByRole('button', { name: '精简职责' })).not.toBeInTheDocument();
    expect(await within(conversationPane).findByRole('button', { name: '换背景色' })).toBeInTheDocument();
    expect(await within(conversationPane).findByRole('button', { name: '调整标题' })).toBeInTheDocument();
    expect(await within(conversationPane).findByRole('button', { name: '换一种风格' })).toBeInTheDocument();
    const retryLastMessage = await within(conversationPane).findByRole('button', { name: '重试上一条' });
    expect(retryLastMessage).toBeInTheDocument();
    fireEvent.click(retryLastMessage);
    await waitFor(() => {
      const retryCall = fetchMock.mock.calls.find(([url, init]) => (
        String(url) === '/api/conversations/sessions/session-1/messages' && init?.method === 'POST'
      ));
      expect(retryCall).toBeDefined();
      expect(JSON.parse(String(retryCall?.[1]?.body))).toMatchObject({ content: '把背景改成红色', base_version_id: 'v1' });
    });

    const chatInput = await within(conversationPane).findByPlaceholderText('告诉小海如何修改当前海报…');
    fireEvent.change(chatInput, { target: { value: '把标题改得更醒目' } });
    fireEvent.click(within(conversationPane).getByRole('button', { name: '发送' }));
    await waitFor(() => {
      const messageCall = fetchMock.mock.calls.find(([url, init]) => (
        String(url) === '/api/conversations/sessions/session-1/messages'
        && init?.method === 'POST'
        && JSON.parse(String(init.body)).content === '把标题改得更醒目'
      ));
      expect(messageCall).toBeDefined();
      expect(JSON.parse(String(messageCall?.[1]?.body))).toMatchObject({
        content: '把标题改得更醒目',
        base_version_id: 'v1',
        background_element_id: 'bg-shop',
        element_ids: ['element-mascot'],
      });
    });

    fireEvent.click(within(posterToolbar).getByRole('button', { name: '生成新版本' }));

    await waitFor(() => {
      const generateCall = fetchMock.mock.calls.find(([url, init]) => (
        String(url) === '/api/xiao-hai/p1/jobs' && init?.method === 'POST'
      ));
      expect(generateCall).toBeDefined();
      expect(JSON.parse(String(generateCall?.[1]?.body))).toMatchObject({
        operation: 'visual',
        generation_mode: 'fresh',
        protected_field_keys: [],
        base_version_id: 'v1',
        canvas_id: 'long',
        fields: { salary: '6-8K' },
      });
    });
  }, 30_000);

  it('switches versions without leaving the poster workspace', async () => {
    const versions = [
      {
        id: 'v1',
        version_number: 1,
        image_url: '/poster-v1.png',
        canvas_id: 'long',
        fields: { jobTitle: '门店导购' },
      },
      {
        id: 'v2',
        version_number: 2,
        image_url: '/poster-v2.png',
        canvas_id: 'long',
        fields: { jobTitle: '门店导购' },
      },
    ];
    let selectedVersionId = 'v2';
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/xiao-hai/p1/bootstrap') {
        return Promise.resolve(jsonResponse({
          pipeline_id: 'p1',
          role: '门店导购',
          jd_ready: true,
          fields: { jobTitle: '门店导购' },
          poster: { selected_version_id: selectedVersionId, approval_status: 'pending' },
          versions,
          canvases: [{ id: 'long', label: '招聘长图', width: 1080, height: 2400 }],
          default_canvas_id: 'long',
        }));
      }
      if (path === '/api/pipelines/p1') {
        return Promise.resolve(jsonResponse({
          id: 'p1',
          role: '门店导购',
          agents: ['xiao_hai'],
          candidates: [],
          stages: [{ stage_id: 'jd_write', status: 'done', output: { jd: { title: '门店导购' } } }],
        }));
      }
      if (path === '/api/xiao-hai/elements') return Promise.resolve(jsonResponse({ backgrounds: [], elements: [] }));
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path === '/api/conversations/sessions/session-1/state?limit=100') return Promise.resolve(jsonResponse({ messages: [], recent_commands: [] }));
      if (path === '/api/xiao-hai/p1/versions/v1/select' && init?.method === 'POST') {
        selectedVersionId = 'v1';
        return Promise.resolve(jsonResponse({ version: versions[0] }));
      }
      return Promise.resolve(jsonResponse({}));
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    const workbench = await screen.findByRole('region', { name: '海报工作台' });
    expect(within(workbench).getByRole('img', { name: '门店导购 招聘海报' })).toHaveAttribute('src', '/poster-v2.png');

    fireEvent.click(screen.getByRole('button', { name: '切换到 V1 · 招聘长图' }));

    await waitFor(() => {
      expect(within(workbench).getByRole('img', { name: '门店导购 招聘海报' })).toHaveAttribute('src', '/poster-v1.png');
    });
    expect(screen.getByRole('button', { name: '切换到 V1 · 招聘长图' })).toHaveAttribute('aria-current', 'true');
  }, 30_000);

  it('keeps creation numbers after generation, canvas filtering, reload and limited history', async () => {
    let versions = [{ id: 'v1', version_number: 1, image_url: '/poster-v1.png', canvas_id: 'xhs' }];
    let selectedVersionId = 'v1';
    vi.stubGlobal('fetch', vi.fn((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/pipelines/p1') return Promise.resolve(jsonResponse({ id: 'p1', role: '门店导购', agents: ['xiao_hai'], stages: [] }));
      if (path === '/api/xiao-hai/p1/bootstrap') {
        return Promise.resolve(jsonResponse({
          pipeline_id: 'p1', role: '门店导购', jd_ready: true, fields: { jobTitle: '门店导购' },
          poster: { selected_version_id: selectedVersionId }, versions, canvases: [], default_canvas_id: 'xhs',
        }));
      }
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path === '/api/conversations/sessions/session-1/state?limit=100') return Promise.resolve(jsonResponse({ messages: [], recent_commands: [] }));
      if (path === '/api/xiao-hai/p1/jobs' && init?.method === 'POST') {
        const number = versions.length + 1;
        const canvasId = JSON.parse(String(init.body)).canvas_id;
        selectedVersionId = `v${number}`;
        versions = [{ id: selectedVersionId, version_number: number, image_url: `/poster-v${number}.png`, canvas_id: canvasId }, ...versions];
        return Promise.resolve(jsonResponse({ job: { id: 'job-' + selectedVersionId, status: 'succeeded', phase: 'completed', progress: 100, elapsed_seconds: 60, result_version_id: selectedVersionId } }));
      }
      if (path === '/api/xiao-hai/p1/jobs') return Promise.resolve(jsonResponse({ jobs: versions.length > 1 ? [{ id: 'job-' + selectedVersionId, status: 'succeeded', phase: 'completed', progress: 100, elapsed_seconds: 60, result_version_id: selectedVersionId }] : [] }));
      return Promise.resolve(jsonResponse({}));
    }));

    renderPage();
    expect(await screen.findByRole('button', { name: '切换到 V1 · 小红书' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '生成新版本' }));
    expect(await screen.findByRole('button', { name: '切换到 V2 · 小红书' })).toBeInTheDocument();
    expect(within(screen.getByRole('button', { name: '切换到 V1 · 小红书' })).getByRole('presentation')).toHaveAttribute('src', '/poster-v1.png');
    const rail = screen.getByRole('region', { name: '海报版本' });
    expect(within(rail).getAllByRole('button', { name: /切换到/ }).map((button) => button.getAttribute('aria-label')))
      .toEqual(['切换到 V2 · 小红书', '切换到 V1 · 小红书']);

    await waitFor(() => expect(screen.getByRole('button', { name: '生成新版本' })).not.toBeDisabled());
    fireEvent.click(screen.getByRole('button', { name: /朋友圈.*1080/ }));
    fireEvent.click(screen.getByRole('button', { name: '生成新版本' }));
    expect(await screen.findByRole('button', { name: '切换到 V3 · 朋友圈' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '查看全部' }));
    expect(screen.getByRole('button', { name: '切换到 V1 · 小红书' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '切换到 V2 · 小红书' })).toBeInTheDocument();
    expect(screen.getByRole('complementary', { name: '与小海对话' })).toHaveTextContent('V3 · 朋友圈');

    cleanup();
    renderPage();
    expect(await screen.findByRole('button', { name: '切换到 V3 · 朋友圈' })).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '查看大图' }));
    expect(await screen.findByText('V3 · 专注预览')).toBeInTheDocument();

    cleanup();
    versions = [{ id: 'v101', version_number: 101, image_url: '/poster-v101.png', canvas_id: 'xhs' }];
    selectedVersionId = '';
    renderPage();
    expect(await screen.findByRole('button', { name: '切换到 V101 · 小红书' })).toBeInTheDocument();
    expect(screen.getByRole('img', { name: '门店导购 招聘海报' })).toHaveAttribute('src', '/poster-v101.png');
  }, 30_000);

  it('uses an in-app confirmation dialog when switching with unapplied visual changes', async () => {
    const versions = [
      { id: 'v1', version_number: 1, image_url: '/poster-v1.png', canvas_id: 'long', fields: { jobTitle: '门店导购' } },
      { id: 'v2', version_number: 2, image_url: '/poster-v2.png', canvas_id: 'long', fields: { jobTitle: '门店导购' } },
    ];
    const fetchMock = vi.fn().mockImplementation((input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return Promise.resolve(jsonResponse({ username: 'admin', permissions: ['pipeline:read'] }));
      if (path === '/api/xiao-hai/p1/bootstrap') {
        return Promise.resolve(jsonResponse({
          pipeline_id: 'p1', role: '门店导购', jd_ready: true, fields: { jobTitle: '门店导购' },
          poster: { selected_version_id: 'v2', approval_status: 'pending' }, versions,
          canvases: [
            { id: 'long', label: '招聘长图', width: 1080, height: 2400 },
            { id: 'xhs', label: '小红书', width: 1242, height: 1660 },
          ], default_canvas_id: 'long',
        }));
      }
      if (path === '/api/pipelines/p1') {
        return Promise.resolve(jsonResponse({
          id: 'p1', role: '门店导购', agents: ['xiao_hai'], candidates: [],
          stages: [{ stage_id: 'jd_write', status: 'done', output: { jd: { title: '门店导购' } } }],
        }));
      }
      if (path === '/api/xiao-hai/elements') return Promise.resolve(jsonResponse({ backgrounds: [], elements: [] }));
      if (path === '/api/conversations/sessions/ensure') return Promise.resolve(jsonResponse({ session: { id: 'session-1' } }));
      if (path === '/api/conversations/sessions/session-1/state?limit=100') return Promise.resolve(jsonResponse({ messages: [], recent_commands: [] }));
      if (path === '/api/xiao-hai/p1/versions/v1/select' && init?.method === 'POST') {
        return Promise.resolve(jsonResponse({ version: versions[0] }));
      }
      return Promise.resolve(jsonResponse({}));
    });
    vi.stubGlobal('fetch', fetchMock);
    const nativeConfirm = vi.spyOn(window, 'confirm').mockReturnValue(true);

    renderPage();

    const workbench = await screen.findByRole('region', { name: '海报工作台' });
    fireEvent.click(within(workbench).getByRole('button', { name: /小红书/ }));
    fireEvent.click(screen.getByRole('button', { name: '查看全部' }));
    fireEvent.click(screen.getByRole('button', { name: '切换到 V1 · 招聘长图' }));

    expect(nativeConfirm).not.toHaveBeenCalled();
    expect(await screen.findByText('当前有未应用的视觉修改，切换版本后这些修改会丢失，是否继续？')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '继续切换' })).toBeInTheDocument();
  }, 30_000);
});
