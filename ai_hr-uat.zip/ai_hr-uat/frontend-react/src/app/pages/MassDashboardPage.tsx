import {
  Alert,
  Avatar,
  Button,
  Card,
  DatePicker,
  Empty,
  Form,
  Input,
  Modal,
  Progress,
  Select,
  Space,
  Spin,
  Tag,
  Typography,
  message,
} from "antd";
import type { MouseEvent as ReactMouseEvent } from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import dayjs from "dayjs";
import locale from "antd/es/date-picker/locale/zh_CN";

import { PageShell } from "../components/PageShell";
import { routePaths } from "../routes/route-paths";
import { ListFilterSelect } from "../../shared/list-workbench";
import { DataTable, DataTableAction } from "../../shared/data-table";
import type { DataTableColumn, DataTableFilterChip } from "../../shared/data-table";
import type { MassRanking, MassStream } from "../../features/mass-dashboard/api";
import {
  invalidateMassDashboardLiveQueries,
  invalidateMassDashboardStatusQueries,
} from "../../features/mass-dashboard/hooks";
import { ResumePreviewModal } from "../../features/talent-pool/components/ResumePreviewModal";
import {
  useKickMassStreamMutation,
  useMarkMassCandidateMutation,
  useMassPipelinesQuery,
  useMassHrUsersQuery,
  useMassRankingQuery,
  useMassStatusQuery,
  useMassStreamsQuery,
  useSendMassInviteMutation,
} from "../../features/mass-dashboard/hooks";
import type { CandidateAssessmentReport, AssessmentQueueItem } from "../../features/xiao-ping/api";
import { useAssessmentQueueQuery, useCandidateReportsQuery } from "../../features/xiao-ping/hooks";
import { decisionScore } from "../../features/xiao-ping/selectors";
import { getErrorMessage } from "../../shared/errors";
import { useAuth } from "../auth/AuthContext";
import { StatsBar } from "./MassDashboardPage.components";
import {
  enrichMassRanking,
  filterRankingByDate,
  fiveDimensionScores,
  formatDateTime,
  formatExpiry,
  hrActionLabel,
  statusColor,
  statusLabel,
  splitMonitorRanking,
  summarizeRankingStats,
} from "./MassDashboardPage.selectors";

type Notice = { type: "success" | "error"; message: string; description?: string };

const DIMENSION_COLORS = ["#2563eb", "#8b5cf6", "#10b981", "#f59e0b", "#ef4444"];
const JOB_TYPE_LABELS: Record<string, string> = {
  tech: "技术岗",
  product: "产品岗",
  operations: "运营岗",
  sales: "销售岗",
  supply_chain: "供应链岗",
  service: "服务岗",
  management: "管理岗",
  function: "职能岗",
  general: "通用岗",
};

function buildInviteUrl(candidate: MassRanking) {
  const path = candidate.invite_type === "written_test" ? "written-test" : "mass-interview";
  return `${window.location.origin}/${path}/${candidate.token}`;
}

const MASS_STATUS_FILTERS = new Set(["started", "in_progress", "completed", "expired"]);

function parseStatusFilter(value: string | null) {
  return value && MASS_STATUS_FILTERS.has(value) ? value : "";
}

export function MassDashboardPage() {
  const navigate = useNavigate();
  const { pipelineId: routePipelineId } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [detailCandidateId, setDetailCandidateId] = useState(() => searchParams.get("candidate") ?? "");
  const [resumeCandidate, setResumeCandidate] = useState<{ id: string; name: string } | null>(null);
  const [reviewCandidateId, setReviewCandidateId] = useState("");
  const [selectedHrId, setSelectedHrId] = useState("");
  const [startDate, setStartDate] = useState(() => dateOffset(-6));
  const [endDate, setEndDate] = useState(() => dateOffset(0));
  const tableCardRef = useRef<HTMLDivElement>(null);
  const [tableScrollY, setTableScrollY] = useState(400);

  // 表格卡片占满剩余高度后，滚动下沉到表格体内（对齐人才库页做法）。
  useEffect(() => {
    const card = tableCardRef.current;
    if (!card) return;
    const cardBody = card.querySelector<HTMLElement>(".ant-card-body");
    if (!cardBody) return;

    const computeHeight = () => {
      const bodyHeight = cardBody.clientHeight;
      const bodyStyle = window.getComputedStyle(cardBody);
      const paddingTop = parseFloat(bodyStyle.paddingTop) || 0;
      const paddingBottom = parseFloat(bodyStyle.paddingBottom) || 0;
      const contentHeight = bodyHeight - paddingTop - paddingBottom;

      const toolbar = cardBody.querySelector<HTMLElement>(".data-table__toolbar");
      const toolbarStyle = toolbar ? window.getComputedStyle(toolbar) : null;
      const toolbarMT = toolbarStyle ? parseFloat(toolbarStyle.marginTop) || 0 : 0;
      const toolbarMB = toolbarStyle ? parseFloat(toolbarStyle.marginBottom) || 0 : 12;
      const toolbarH = toolbar ? toolbar.offsetHeight + toolbarMT + toolbarMB : 58;

      const chips = cardBody.querySelector<HTMLElement>(".data-table__filter-chips");
      const chipsH = chips ? chips.offsetHeight + 8 : 0;

      const thead = cardBody.querySelector<HTMLElement>(".ant-table-thead");
      const headerH = thead ? thead.offsetHeight : 54;

      const pagination = cardBody.querySelector<HTMLElement>(".ant-table-pagination");
      const paginationStyle = pagination ? window.getComputedStyle(pagination) : null;
      const paginationMT = paginationStyle ? parseFloat(paginationStyle.marginTop) || 0 : 0;
      const paginationMB = paginationStyle ? parseFloat(paginationStyle.marginBottom) || 0 : 0;
      const paginationH = pagination ? pagination.offsetHeight + paginationMT + paginationMB : 64;

      const scrollY = contentHeight - toolbarH - chipsH - headerH - paginationH - 8;
      setTableScrollY(Math.max(200, scrollY));
    };

    computeHeight();
    const observer = new ResizeObserver(computeHeight);
    observer.observe(cardBody);
    return () => observer.disconnect();
  }, []);
  const [reviewForm] = Form.useForm();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isAdmin = user?.role_id === "admin";
  const hrUsersQuery = useMassHrUsersQuery();
  // HR defaults to their own account; an administrator starts with the
  // tenant-wide view because the admin account is not an HR owner.
  const effectiveHrId = selectedHrId || (isAdmin ? "__all__" : user?.id || "");

const pipelineQuery = searchParams.get('q') ?? '';
  const startFrom = searchParams.get('start_from') ?? '';
  const startTo = searchParams.get('start_to') ?? '';
  // KPI 点击筛选状态存 URL（对齐招聘岗位管理）：'' 表示全部（“已邀请”卡=总数）。
  const statusFilter = parseStatusFilter(searchParams.get('status'));
  // 后端在未传日期时默认限制最近七天；日期输入变化后在当前监控结果中继续精确过滤。
  const pipelinesQuery = useMassPipelinesQuery({
    q: pipelineQuery,
    ownerUserId: effectiveHrId === "__all__" ? undefined : effectiveHrId,
  });
  // 路由中的 ID 只有在当前筛选结果中仍然可见时才可使用。切换 HR 后，
  // 旧岗位 ID 可能不属于该 HR，不能继续沿用它展示另一位 HR 的数据。
  const routeCandidatePipelineId = routePipelineId || searchParams.get('pid') || "";
  const routePipelineAllowed = (pipelinesQuery.data ?? []).some((item) => item.id === routeCandidatePipelineId);
  const selectedPipelineId = pipelinesQuery.isPending
    ? ""
    : (routePipelineAllowed ? routeCandidatePipelineId : pipelinesQuery.data?.[0]?.id) || "";
  const currentPipeline = pipelinesQuery.data?.find((item) => item.id === selectedPipelineId);
  const pipelineOptions = useMemo(
    () =>
      (pipelinesQuery.data ?? []).map((pipeline) => ({
        label: `${
          String(pipeline.role ?? "")
            .replace(/\*/g, "")
            .trim() || "未命名岗位"
        }-${JOB_TYPE_LABELS[pipeline.job_type ?? "general"] ?? "通用岗"}`,
        value: pipeline.id,
      })),
    [pipelinesQuery.data],
  );

  useEffect(() => {
    if (!selectedHrId && !isAdmin && user?.id) setSelectedHrId(user.id);
  }, [isAdmin, selectedHrId, user?.id]);

  const ownerFilter = effectiveHrId === "__all__" ? "" : effectiveHrId;
  const statusQuery = useMassStatusQuery(selectedPipelineId, ownerFilter);
  const streamsQuery = useMassStreamsQuery(selectedPipelineId, ownerFilter);
  const rankingQuery = useMassRankingQuery(selectedPipelineId, { startFrom, startTo, ownerUserId: ownerFilter });
  const markMutation = useMarkMassCandidateMutation(selectedPipelineId);
  const kickMutation = useKickMassStreamMutation(selectedPipelineId);
  const inviteMutation = useSendMassInviteMutation(selectedPipelineId);
  const rawRanking = rankingQuery.data?.ranking ?? [];
  const assessmentQueueQuery = useAssessmentQueueQuery(selectedPipelineId);
  const candidateReportsQuery = useCandidateReportsQuery(selectedPipelineId);
  const assessmentByCandidateId = useMemo(() => {
    const queue = assessmentQueueQuery.data;
    const items = [...(queue?.ready_for_decision ?? []), ...(queue?.incomplete ?? [])];
    return new Map(items.map((item) => [item.candidate_id, item]));
  }, [assessmentQueueQuery.data]);
  const reportByCandidateId = useMemo(
    () => new Map((candidateReportsQuery.data?.reports ?? []).map((item) => [item.candidate_id, item])),
    [candidateReportsQuery.data?.reports],
  );
  const ranking = useMemo(
    () => enrichMassRanking(rawRanking, assessmentQueueQuery.data),
    [assessmentQueueQuery.data, rawRanking],
  );
  const detailCandidate = ranking.find((item) => item.candidate_id === detailCandidateId);
  const detailAssessment = assessmentByCandidateId.get(detailCandidateId);
  const detailReport = reportByCandidateId.get(detailCandidateId);
  const hasError = statusQuery.error || streamsQuery.error || rankingQuery.error;

  useEffect(() => {
    document.title = currentPipeline?.role ? `${currentPipeline.role} - 面试中心` : "面试中心 - 锅圈食汇";
    return () => {
      document.title = "锅圈食汇 - 智能招聘平台";
    };
  }, [currentPipeline?.role]);

  useEffect(() => {
    if (!selectedPipelineId || typeof WebSocket === "undefined") {
      return;
    }

    let cancelled = false;
    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;

    // 对齐旧版 mass-dashboard.html：断开后 3 秒自动重连
    function connect() {
      if (cancelled) return;
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      socket = new WebSocket(`${protocol}//${window.location.host}/ws/mass-monitor/${selectedPipelineId}`);
      socket.onmessage = (event) => {
        let message: { type?: string } = {};
        try {
          message = JSON.parse(event.data) as { type?: string };
        } catch {
          return;
        }
        const type = message.type;
        if (type === "candidate_online" || type === "candidate_offline") {
          void invalidateMassDashboardStatusQueries(queryClient, selectedPipelineId);
        } else if (type === "candidate_progress") {
          void invalidateMassDashboardStatusQueries(queryClient, selectedPipelineId);
        } else if (type === "score_update" || type === "session_updated") {
          void invalidateMassDashboardLiveQueries(queryClient, selectedPipelineId);
        } else if (type === "initial_state") {
          void invalidateMassDashboardStatusQueries(queryClient, selectedPipelineId);
        }
      };
      socket.onclose = () => {
        if (!cancelled) reconnectTimer = setTimeout(connect, 3000);
      };
    }

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      socket?.close();
    };
  }, [queryClient, selectedPipelineId]);

  function selectPipeline(nextPipelineId: string) {
    navigate(routePaths.massDashboard(nextPipelineId));
  }

  function selectHr(nextHrId: string) {
    // HR 过滤范围变化后，路由里可能仍带着从小面跳转过来的旧 pipeline；
    // 清掉这个占位 ID，让后端筛选结果决定当前岗位，避免短暂展示错岗数据。
    setSelectedHrId(nextHrId);
    navigate(routePaths.massDashboard());
  }

  function handlePipelineSearch(value: string) {
    const nextParams = new URLSearchParams(searchParams);
    if (value.trim()) nextParams.set('q', value); else nextParams.delete('q');
    setSearchParams(nextParams, { replace: true });
  }

  function showNotice(nextNotice: Notice) {
    const content = nextNotice.description ? `${nextNotice.message}：${nextNotice.description}` : nextNotice.message;
    if (nextNotice.type === "success") message.success(content);
    else message.error(content);
  }

  function openCandidate(candidate: MassRanking) {
    setDetailCandidateId(candidate.candidate_id);
  }

  function openResume(candidate: MassRanking) {
    setResumeCandidate({ id: candidate.candidate_id, name: candidate.candidate_name });
  }

  function runMark(candidateId: string, action: "pass" | "review" | "reject", schedule?: Record<string, string>) {
    const normalizedSchedule = schedule ? { ...schedule, notes: schedule.note ?? "" } : undefined;
    markMutation.mutate(
      { candidateId, action, schedule: normalizedSchedule },
      {
        onSuccess: () => {
          setReviewCandidateId("");
          setDetailCandidateId("");
          showNotice({ type: "success", message: actionLabel(action) + "操作已保存" });
        },
        onError: (error) => showNotice({ type: "error", message: getErrorMessage(error) }),
      },
    );
  }

  function markCandidate(candidate: MassRanking, action: "pass" | "review" | "reject") {
    if (action === "review") {
      reviewForm.resetFields();
      reviewForm.setFieldsValue({ date: getToday(), time: "14:00" });
      setReviewCandidateId(candidate.candidate_id);
      return;
    }

    if (action === "reject") {
      Modal.confirm({
        title: "确认淘汰",
        content: `确定淘汰 ${candidate.candidate_name}？此操作可在后续撤销。`,
        okText: "确认淘汰",
        cancelText: "取消",
        okButtonProps: { danger: true },
        onOk: () => runMark(candidate.candidate_id, action),
      });
      return;
    }

    runMark(candidate.candidate_id, action);
  }

  function sendEmail(candidate?: MassRanking, selectedIds?: string[]) {
    const targets = candidate
      ? [candidate]
      : ranking.filter((item) => ["invited", "expired"].includes(item.status) && selectedIds?.includes(item.candidate_id));
    const invites = targets
      .filter((item) => item.token)
      .map((item) => ({ candidate_id: item.candidate_id, token: item.token as string }));
    if (invites.length === 0) {
      showNotice({ type: "error", message: "没有可发送的邀请链接" });
      return;
    }
    inviteMutation.mutate(invites, {
      onSuccess: (result) =>
        showNotice({
          type: (result.sent ?? 0) > 0 ? "success" : "error",
          message:
            (result.sent ?? 0) > 0
              ? candidate
                ? `已为 ${candidate.candidate_name} 发送邮件`
                : `已发送 ${result.sent ?? 0} 封邮件`
              : (result.warning ?? "邮件发送失败"),
          description:
            (result.skipped_no_email ?? 0) > 0
              ? `${result.skipped_no_email} 人没有邮箱地址${result.warning ? `；${result.warning}` : ""}`
              : result.warning || undefined,
        }),
      // 全局 QueryClient 会显示具体错误原因；这里不再重复弹出一条提示。
    });
  }

  function copyInvite(candidate: MassRanking) {
    if (!candidate.token) {
      showNotice({ type: "error", message: "该候选人缺少有效面试链接" });
      return;
    }
    const url = buildInviteUrl(candidate);
    void copyText(url).then(() => showNotice({ type: "success", message: "面试链接已复制" }));
  }

  function kickStream(stream: MassStream) {
    if (!stream.stream_name) {
      return;
    }
    kickMutation.mutate(stream.stream_name, {
      onSuccess: () => showNotice({ type: "success", message: `已停止 ${stream.candidate_name} 的直播流` }),
      onError: (error) => showNotice({ type: "error", message: getErrorMessage(error) }),
    });
  }

  function handleStatSelect(key: string) {
    // invited 卡 = 总数（清除筛选）；其余卡按状态筛选；再点当前选中卡 = 取消。
    const target = key === "invited" ? "" : key;
    const nextParams = new URLSearchParams(searchParams);
    if (target && target !== statusFilter) nextParams.set("status", target);
    else nextParams.delete("status");
    setSearchParams(nextParams, { replace: true });
  }

  function clearStatusFilter() {
    const nextParams = new URLSearchParams(searchParams);
    if (nextParams.has("status")) {
      nextParams.delete("status");
      setSearchParams(nextParams, { replace: true });
    }
  }

  const visibleRanking = useMemo(
    () => filterRankingByDate(ranking, startDate, endDate),
    [ranking, startDate, endDate],
  );
  // KPI 计数与表格筛选用同一分桶口径，保证卡片数字 = 筛选后行数；
  // 后端 status 接口返回的是整条流水线统计，不能直接拿来当 KPI。
  const monitorBuckets = useMemo(() => splitMonitorRanking(visibleRanking), [visibleRanking]);
  const stats = useMemo(() => summarizeRankingStats(visibleRanking, monitorBuckets), [visibleRanking, monitorBuckets]);
  const tableRanking = useMemo(() => {
    if (!statusFilter) return visibleRanking;
    // started/in_progress 两卡都对应答题中+已打开两桶，与停止直播按钮口径一致。
    if (statusFilter === "started" || statusFilter === "in_progress") {
      return [...monitorBuckets.answering, ...monitorBuckets.opened];
    }
    if (statusFilter === "completed") return monitorBuckets.completed;
    if (statusFilter === "expired") return monitorBuckets.expired;
    return visibleRanking;
  }, [statusFilter, visibleRanking, monitorBuckets]);
  const selectedStatKey = statusFilter === "" ? "invited" : statusFilter;
  const loading =
    pipelinesQuery.isPending ||
    Boolean(
      selectedPipelineId && (statusQuery.isPending || streamsQuery.isPending || rankingQuery.isPending),
    );

  return (
    <PageShell
      title="面试中心"
      variant="flex"
      headerExtra={
        <Button
          type="primary"
          disabled={!selectedPipelineId}
          onClick={() => navigate(routePaths.agentWorkspace("xiao_ping", selectedPipelineId))}
        >
          去小评查看综合报告
        </Button>
      }
    >
      <div className="mass-dashboard__panel">
        <div className="mass-dashboard__filters">
        <ListFilterSelect
          aria-label="筛选HR"
          className="mass-dashboard__hr"
          loading={hrUsersQuery.isPending}
          placeholder="全部 HR"
          showSearch
          optionFilterProp="label"
          options={(hrUsersQuery.data?.users ?? []).map((hr) => ({
            label: hr.display_name,
            value: hr.id,
          }))}
          value={effectiveHrId === "__all__" ? undefined : effectiveHrId || undefined}
          onChange={selectHr}
        />
        <Select
          aria-label="选择面试岗位"
          className="mass-dashboard__pipeline-select"
          loading={pipelinesQuery.isPending}
          showSearch
          filterOption={false}
          allowClear
          options={pipelineOptions}
          placeholder="选择面试岗位"
          value={selectedPipelineId || undefined}
          onChange={selectPipeline}
          onSearch={handlePipelineSearch}
          onClear={() => handlePipelineSearch('')}
        />
        <DatePicker.RangePicker
          aria-label="面试日期"
          className="mass-dashboard__date-range"
          format="YYYY-MM-DD"
          locale={locale}
          placeholder={["开始日期", "结束日期"]}
          value={[startDate ? dayjs(startDate, "YYYY-MM-DD") : null, endDate ? dayjs(endDate, "YYYY-MM-DD") : null]}
          onChange={(dates) => {
            setStartDate(dates?.[0]?.format("YYYY-MM-DD") ?? "");
            setEndDate(dates?.[1]?.format("YYYY-MM-DD") ?? "");
          }}
        />
      </div>
      <StatsBar
        stats={stats}
        selectedKey={selectedStatKey}
        onSelect={handleStatSelect}
      />
        <main className="mass-dashboard__content">
          {!selectedPipelineId ? (
            <Empty description="暂无面试数据" />
          ) : loading ? (
            <div className="app-loading">
              <Spin size="large" tip="加载中" />
            </div>
          ) : hasError ? (
            <Alert
              type="error"
              showIcon
              message="面试数据加载失败"
              description="请稍后重试。"
              action={
                <Button
                  onClick={() => {
                    void statusQuery.refetch();
                    void streamsQuery.refetch();
                    void rankingQuery.refetch();
                  }}
                >
                  重试
                </Button>
              }
            />
          ) : (
            <Card className="mass-dashboard__table-card" ref={tableCardRef}>
              <CandidateTable
                ranking={tableRanking}
                streams={streamsQuery.data?.streams ?? []}
                pipelineId={selectedPipelineId}
                scrollY={tableScrollY}
                filterChips={
                  statusFilter
                    ? [
                        {
                          key: "status",
                          label: `状态：${statusLabel(statusFilter)}`,
                          onRemove: clearStatusFilter,
                        },
                      ]
                    : []
                }
                onOpen={openCandidate}
                onResume={openResume}
                onMark={markCandidate}
                onCopy={copyInvite}
                onEmail={(candidate) => sendEmail(candidate)}
                onKick={kickStream}
                onClearFilters={clearStatusFilter}
              />
            </Card>
          )}
        </main>
      </div>

      <Modal
        className="mass-dashboard__detail-modal"
        footer={null}
        open={Boolean(detailCandidate)}
        title={detailCandidate ? `${detailCandidate.candidate_name} · 候选人详情` : "候选人详情"}
        width={760}
        onCancel={() => setDetailCandidateId("")}
      >
        {detailCandidate ? (
          <CandidateDetail
            candidate={detailCandidate}
            assessment={detailAssessment}
            report={detailReport}
            isAssessmentLoading={assessmentQueueQuery.isFetching || candidateReportsQuery.isFetching}
            streams={streamsQuery.data?.streams ?? []}
            onCopy={() => copyInvite(detailCandidate)}
            onResume={() => openResume(detailCandidate)}
          />
        ) : null}
      </Modal>
      <ResumePreviewModal
        pipelineId={selectedPipelineId}
        candidate={resumeCandidate}
        onClose={() => setResumeCandidate(null)}
      />

      <Modal
        open={Boolean(reviewCandidateId)}
        title={`安排复试 · ${ranking.find((item) => item.candidate_id === reviewCandidateId)?.candidate_name ?? ""}`}
        okText="保存安排"
        cancelText="稍后安排"
        confirmLoading={markMutation.isPending}
        onCancel={() => setReviewCandidateId("")}
        onOk={() => {
          void reviewForm.validateFields().then((values) => {
            runMark(reviewCandidateId, "review", values);
          });
        }}
      >
        <Form form={reviewForm} layout="vertical">
          <Form.Item label="复试日期" name="date" rules={[{ required: true, message: "请选择复试日期" }]}>
            <Input type="date" />
          </Form.Item>
          <Form.Item label="面试时间" name="time">
            <Input type="time" />
          </Form.Item>
          <Form.Item
            label="面试官"
            name="interviewer"
            rules={[{ required: true, message: "请输入面试官姓名" }]}
            extra="仅用于复试安排展示；企业微信接收人由后端统一配置。"
          >
            <Input placeholder="例如：李经理" />
          </Form.Item>
          <Form.Item label="备注" name="note">
            <Input.TextArea autoSize={{ minRows: 2, maxRows: 4 }} placeholder="复试重点考察方向..." />
          </Form.Item>
        </Form>
      </Modal>
    </PageShell>
  );
}

type CandidateTableProps = {
  ranking: MassRanking[];
  streams: MassStream[];
  pipelineId: string;
  scrollY: number;
  filterChips: DataTableFilterChip[];
  onOpen: (candidate: MassRanking) => void;
  onResume: (candidate: MassRanking) => void;
  onMark: (candidate: MassRanking, action: "pass" | "review" | "reject") => void;
  onCopy: (candidate: MassRanking) => void;
  onEmail: (candidate: MassRanking) => void;
  onKick: (stream: MassStream) => void;
  onClearFilters: () => void;
};

function CandidateTable({
  ranking,
  streams,
  scrollY,
  filterChips,
  onOpen,
  onResume,
  onMark,
  onCopy,
  onEmail,
  onKick,
  onClearFilters,
}: CandidateTableProps) {
  const { answering, opened, invited, expired: expiredCandidates } = splitMonitorRanking(ranking);
  // “停止直播”只在答题中/已打开且有直播流时可用，与 KPI 分桶口径一致。
  const liveIds = new Set([...answering, ...opened].map((item) => item.candidate_id));
  const pendingIds = new Set([...invited, ...expiredCandidates].map((item) => item.candidate_id));
  const streamByCandidateId = useMemo(
    () => new Map(streams.map((stream) => [stream.candidate_id, stream])),
    [streams],
  );

  const columns: DataTableColumn<MassRanking>[] = [
    {
      key: "name",
      role: "identity",
      title: "姓名",
      dataIndex: "candidate_name",
      render: (name: string) => <Typography.Text strong>{name}</Typography.Text>,
    },
    {
      key: "status",
      title: "状态",
      dataIndex: "status",
      width: 100,
      render: (status: string, candidate) => (
        <Tag color={candidate.assessment_completed ? statusColor("completed") : statusColor(status)}>
          {candidate.assessment_completed ? "已完成" : statusLabel(status)}
        </Tag>
      ),
    },
    {
      key: "score",
      title: "小评评分",
      width: 110,
      sorter: (left, right) =>
        (left.interview_score ?? left.total_score ?? left.match_score ?? 0) -
        (right.interview_score ?? right.total_score ?? right.match_score ?? 0),
      render: (_value: unknown, candidate) => {
        const score = candidate.interview_score ?? candidate.total_score ?? candidate.match_score;
        return typeof score === "number" ? <b>{score}</b> : <Typography.Text type="secondary">—</Typography.Text>;
      },
    },
    {
      key: "started_at",
      title: "开始时间",
      dataIndex: "started_at",
      width: 120,
      render: (value: string) => (value ? formatDateTime(value) : "—"),
    },
    {
      key: "expires_at",
      title: "有效期",
      dataIndex: "expires_at",
      width: 200,
      render: (value: string) => (value ? formatExpiry(value) : "—"),
    },
    {
      key: "actions",
      role: "actions",
      title: "操作",
      width: 300,
      fixed: "right" as const,
      onCell: () => ({
        style: { cursor: "default" },
        // 行点击会打开详情弹窗；操作列内点击不冒泡到行。
        onClick: (event: ReactMouseEvent<HTMLElement>) => event.stopPropagation(),
      }),
      render: (_value: unknown, candidate) => {
        const stream = streamByCandidateId.get(candidate.candidate_id);
        return (
          <Space size={4} wrap>
            <DataTableAction onClick={() => onOpen(candidate)}>详情</DataTableAction>
            <DataTableAction onClick={() => onResume(candidate)}>简历</DataTableAction>
            <DataTableAction onClick={() => onMark(candidate, "pass")}>通过</DataTableAction>
            <DataTableAction onClick={() => onMark(candidate, "review")}>复试</DataTableAction>
            <DataTableAction tone="danger" onClick={() => onMark(candidate, "reject")}>淘汰</DataTableAction>
            {pendingIds.has(candidate.candidate_id) ? (
              <>
                <DataTableAction onClick={() => onCopy(candidate)}>复制链接</DataTableAction>
                <DataTableAction onClick={() => onEmail(candidate)}>发邮件</DataTableAction>
              </>
            ) : null}
            {liveIds.has(candidate.candidate_id) && stream ? (
              <DataTableAction tone="danger" onClick={() => onKick(stream)}>停止直播</DataTableAction>
            ) : null}
          </Space>
        );
      },
    },
  ];

  return (
    <DataTable
      tableId="mass-candidates"
      rowKey="candidate_id"
      columns={columns}
      dataSource={ranking}
      filterChips={filterChips}
      searchableText={(record) => record.candidate_name}
      searchPlaceholder="搜索候选人姓名"
      scroll={{ x: "max-content", y: scrollY }}
      onRow={(record) => ({
        onClick: () => onOpen(record),
        style: { cursor: "pointer" },
      })}
      onClearFilters={onClearFilters}
    />
  );
}

function CandidateDetail({
  candidate,
  assessment,
  report,
  isAssessmentLoading,
  streams,
  onCopy,
  onResume,
}: {
  candidate: MassRanking;
  assessment?: AssessmentQueueItem;
  report?: CandidateAssessmentReport;
  isAssessmentLoading: boolean;
  streams: MassStream[];
  onCopy: () => void;
  onResume: () => void;
}) {
  const stream = streams.find((item) => item.candidate_id === candidate.candidate_id);
  const videoUrl = stream?.video_url || stream?.hls_url;

  return (
    <div className="mass-detail">
      <div className="mass-detail__hero">
        <Avatar size={54}>{candidate.candidate_name.slice(0, 1)}</Avatar>
        <div>
          <Typography.Title level={4}>{candidate.candidate_name}</Typography.Title>
          <Space>
            <Tag color={candidate.assessment_completed ? statusColor("completed") : statusColor(candidate.status)}>
              {candidate.assessment_completed ? "已完成" : statusLabel(candidate.status)}
            </Tag>
          </Space>
        </div>
        <Space className="mass-detail__hero-actions">
          <Button onClick={onResume}>简历</Button>
        </Space>
      </div>
      <EvaluationPanel
        candidate={candidate}
        videoUrl={videoUrl}
        assessment={assessment}
        report={report}
        isReportLoading={isAssessmentLoading}
      />
    </div>
  );
}
function EvaluationPanel({
  candidate,
  videoUrl,
  assessment,
  report,
  isReportLoading,
}: {
  candidate: MassRanking;
  videoUrl?: string;
  assessment?: AssessmentQueueItem;
  report?: CandidateAssessmentReport;
  isReportLoading: boolean;
}) {
  const assessmentSteps = Object.values(assessment?.step_results ?? {});
  const scoringStatus = candidate.scoring_status || assessmentSteps.find((step) => step.scoring_status)?.scoring_status;
  const isScoring = scoringStatus === "processing" || scoringStatus === "pending";
  const isScoringFailed = scoringStatus === "failed";
  const isScoringSucceeded = scoringStatus === "succeeded";
  const dimensions = fiveDimensionScores(report, assessment, candidate);
  const [replayIndex, setReplayIndex] = useState(0);
  // 对齐旧版 playRecording：video_paths 转为 /api/mass-interview/video/{parts} 逐题回放
  const replayVideos = (candidate.video_paths ?? []).filter(Boolean).map((path) => {
    const parts = path.split("/");
    const filename = parts[parts.length - 1];
    const qNum = filename.match(/q(\d+)/)?.[1];
    const qIndex = qNum != null ? parseInt(qNum, 10) : 0;
    return {
      url: `/api/mass-interview/video/${parts[0]}/${parts[2]}/${filename}`,
      label: `Q${qIndex + 1}`,
      qIndex,
    };
  });
  const safeReplayIndex = Math.min(replayIndex, Math.max(0, replayVideos.length - 1));
  const currentReplay = replayVideos[safeReplayIndex];
  const displayedScore = isScoringSucceeded
    ? assessment
      ? decisionScore(assessment)
      : (candidate.match_score ?? 0)
    : null;
  return (
    <div className="mass-detail__evaluation">
      {isScoring ? (
        <Alert type="info" showIcon message="小面模型正在分析面试内容，请稍候刷新查看完整结果。" />
      ) : isScoringFailed ? (
        <Alert type="warning" showIcon message="小面模型评估未完成，请稍后重试。" />
      ) : null}
      {isReportLoading && !report ? <Spin tip="正在加载小评报告" /> : null}
      {isScoringSucceeded && report?.comprehensive_evaluation ? (
        <div className="mass-detail__section">
          <Typography.Text strong>AI综合评价</Typography.Text>
          <Typography.Paragraph style={{ marginTop: 8, marginBottom: 0 }}>
            {report.comprehensive_evaluation}
          </Typography.Paragraph>
        </div>
      ) : null}
      {candidate.red_flags?.length ? (
        <div className="mass-detail__section">
          <Typography.Text strong>风险提示</Typography.Text>
          {candidate.red_flags.map((flag, index) => (
            <div key={`${String(flag)}-${index}`} className="mass-detail__flag">
              ▲ {String(flag)}
            </div>
          ))}
        </div>
      ) : null}
      {videoUrl ? (
        <video className="mass-detail__video" controls playsInline src={videoUrl} />
      ) : replayVideos.length ? (
        <div className="mass-detail__section">
          <Typography.Text strong>面试回放</Typography.Text>
          <video
            className="mass-detail__video"
            controls
            playsInline
            src={currentReplay?.url}
            key={currentReplay?.url}
          />
          <Space wrap style={{ marginTop: 8 }}>
            {replayVideos.map((video, index) => (
              <Button
                key={video.url}
                size="small"
                type={index === safeReplayIndex ? "primary" : "default"}
                onClick={() => setReplayIndex(index)}
              >
                {video.label}
              </Button>
            ))}
          </Space>
        </div>
      ) : null}
      {isScoringSucceeded && displayedScore !== null ? (
        <>
          <div className="mass-detail__score-box">
            <Typography.Text strong>小评评分</Typography.Text>
            <span>
              {displayedScore}
              <small>/100</small>
            </span>
          </div>
          <div className="mass-detail__section">
            <Typography.Text strong>维度评分</Typography.Text>
            {dimensions.length > 0 ? (
              dimensions.map(([name, value], index) => (
                <div key={name} className="mass-detail__dimension">
                  <span>{name}</span>
                  <Progress
                    percent={Math.min(value, 100)}
                    strokeColor={DIMENSION_COLORS[index % DIMENSION_COLORS.length]}
                  />
                  <b>{value}</b>
                </div>
              ))
            ) : (
              <Typography.Text type="secondary">暂无维度评分</Typography.Text>
            )}
          </div>
        </>
      ) : null}
    </div>
  );
}

function actionLabel(action: "pass" | "review" | "reject") {
  return { pass: "进入录用评估", review: "选择复试", reject: "淘汰" }[action];
}

function getToday() {
  return new Date().toISOString().slice(0, 10);
}

function dateOffset(days: number) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

async function copyText(value: string) {
  if (navigator.clipboard) {
    await navigator.clipboard.writeText(value);
    return;
  }
  const textarea = document.createElement("textarea");
  textarea.value = value;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  textarea.remove();
}