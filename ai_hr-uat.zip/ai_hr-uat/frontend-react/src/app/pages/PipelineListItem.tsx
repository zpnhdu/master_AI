import { DeleteOutlined } from '@ant-design/icons';
import { Button, Checkbox, Skeleton, Typography } from 'antd';

import type { Pipeline } from '../../features/pipelines/api';
import { getPipelineStatus } from '../../features/pipelines/api';
import {
  formatCreatedAt,
  getPipelineId,
  getPipelineProgress,
  getPipelineType,
  getPipelineTypeClass,
} from './StudioPage.selectors';

export interface PipelineListItemProps {
  pipeline: Pipeline;
  onDelete: (pipeline: Pipeline) => void;
  onOpen: (pipeline: Pipeline) => void;
  onSelect: (pipeline: Pipeline, checked: boolean) => void;
  selected: boolean;
}

export function PipelineListItem({
  pipeline,
  onDelete,
  onOpen,
  onSelect,
  selected,
}: PipelineListItemProps) {
  const status = getPipelineStatus(pipeline);
  const isDone = status === '已完成';
  const isRunning = status === '进行中';
  const badgeClass = isDone ? 'done' : isRunning ? 'running' : 'pending';
  const role = pipeline.role || '未命名岗位';
  const progress = getPipelineProgress(pipeline);
  const pipelineType = getPipelineType(pipeline);
  const pipelineId = getPipelineId(pipeline);

  const handleOpen = () => {
    if (pipelineId) {
      onOpen(pipeline);
    }
  };

  return (
    <div
      className={`pipeline-list-item${selected ? ' pipeline-list-item--selected' : ''}`}
      role="listitem"
      aria-label={`查看${role}详情`}
      tabIndex={0}
      onClick={handleOpen}
      onKeyDown={(event) => {
        if (event.key === 'Enter' && event.target === event.currentTarget) {
          handleOpen();
        }
      }}
    >
      <span
        className="pipeline-list-item__select"
        onClick={(event) => event.stopPropagation()}
      >
        <Checkbox
          aria-label={`选择${role}`}
          checked={selected}
          disabled={!pipelineId}
          onChange={(event) => onSelect(pipeline, event.target.checked)}
        />
      </span>
      <div className="pipeline-list-item__main">
        <div className="pipeline-list-item__title">
          <Typography.Text strong>{role}</Typography.Text>
        </div>
        <div className="pipeline-list-item__meta">
          {pipelineType && (
            <span className={`pipeline-list-item__type pipeline-list-item__type--${getPipelineTypeClass(pipeline)}`}>
              {pipelineType}
            </span>
          )}
          <span className="pipeline-list-item__meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="12" height="12">
              <rect x="3" y="4" width="18" height="18" rx="2" />
              <path d="M16 2v4M8 2v4M3 10h18" />
            </svg>
            {formatCreatedAt(pipeline.created_at)}
          </span>
          {pipeline.hr_name && (
            <span className="pipeline-list-item__meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="12" height="12">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
              HR {pipeline.hr_name}
            </span>
          )}
          <span className="pipeline-list-item__meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="12" height="12">
              <path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
            </svg>
            {pipeline.candidate_count ?? 0} 候选人
          </span>
        </div>
      </div>
      <div className="pipeline-list-item__status">
        <div className="pipeline-list-item__status-head">
          <span className={`pipeline-list-item__badge pipeline-list-item__badge--${badgeClass}`}>
            <span className="pipeline-list-item__badge-dot" />
            {status}
          </span>
          <Typography.Text type="secondary">{progress}%</Typography.Text>
        </div>
        <div
          className="pipeline-list-item__progress"
          role="progressbar"
          aria-label={`${role}招聘进度`}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={progress}
          aria-valuetext={`${progress}%`}
        >
          <div
            className={`pipeline-list-item__progress-bar${isRunning ? ' pipeline-list-item__progress-bar--running' : ''}`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      <button
        type="button"
        className="pipeline-list-item__detail-link"
        aria-label={`查看${role}详情`}
        disabled={!pipelineId}
        onClick={(event) => {
          event.stopPropagation();
          handleOpen();
        }}
      >
        查看详情 <span>→</span>
      </button>
      <Button
        type="text"
        danger
        className="pipeline-list-item__delete"
        aria-label={`删除${role}`}
        title={`删除${role}`}
        disabled={!pipelineId}
        onClick={(event) => {
          event.stopPropagation();
          onDelete(pipeline);
        }}
      >
        <DeleteOutlined aria-hidden="true" />
      </Button>
    </div>
  );
}

export function PipelineListSkeleton() {
  return (
    <div className="pipeline-list pipeline-list--loading" role="status" aria-label="岗位列表加载中">
      {Array.from({ length: 6 }, (_, index) => (
        <div className="pipeline-list-item pipeline-list-item--skeleton" key={index}>
          <Skeleton active title={{ width: '46%' }} paragraph={{ rows: 2 }} />
        </div>
      ))}
    </div>
  );
}
