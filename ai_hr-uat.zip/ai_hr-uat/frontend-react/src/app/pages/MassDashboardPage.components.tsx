import { Card, Progress } from "antd";
import type { KeyboardEvent } from "react";

import type { MassInterviewStats } from "../../features/mass-dashboard/api";

// 视觉对齐“招聘岗位管理”的 studio-statistic：左侧彩色竖条 + 图标块 + 大数字，
// 百分比小字 + 底部进度条展示该状态占当前范围内候选人总数的比例。
const STAT_CARDS = [
  {
    key: "invited",
    label: "已邀请",
    // “已邀请”是当前筛选后的候选人总数；其余卡片展示状态分布。
    getValue: (stats: MassInterviewStats) => stats.total,
    className: "is-blue",
    gradient: { "0%": "#6366f1", "100%": "#818cf8" },
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <line x1="22" y1="2" x2="11" y2="13" />
        <polygon points="22 2 15 22 11 13 2 9 22 2" />
      </svg>
    ),
  },
  {
    key: "started",
    label: "已打开",
    getValue: (stats: MassInterviewStats) => stats.started,
    className: "is-amber",
    gradient: { "0%": "#0ea5e9", "100%": "#38bdf8" },
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
        <circle cx="12" cy="12" r="3" />
      </svg>
    ),
  },
  {
    key: "in_progress",
    label: "答题中",
    getValue: (stats: MassInterviewStats) => stats.in_progress,
    className: "is-purple",
    gradient: { "0%": "#2563eb", "100%": "#60a5fa" },
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
      </svg>
    ),
  },
  {
    key: "completed",
    label: "已完成",
    getValue: (stats: MassInterviewStats) => stats.completed + stats.evaluated,
    className: "is-green",
    gradient: { "0%": "#059669", "100%": "#34d399" },
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
      </svg>
    ),
  },
  {
    key: "expired",
    label: "已过期",
    getValue: (stats: MassInterviewStats) => stats.expired,
    className: "is-red",
    gradient: { "0%": "#dc2626", "100%": "#f87171" },
    icon: (
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="12" cy="12" r="10" />
        <polyline points="12 6 12 12 16 14" />
      </svg>
    ),
  },
] as const;

export function StatsBar({
  stats,
  selectedKey,
  onSelect,
}: {
  stats: MassInterviewStats;
  selectedKey?: string;
  onSelect?: (key: string) => void;
}) {
  const total = stats.total || 1;

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>, key: string) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onSelect?.(key);
    }
  }

  return (
    <div className="mass-dashboard__kpis" aria-label="面试统计">
      {STAT_CARDS.map((card) => {
        const value = card.getValue(stats);
        const percentage = Math.round((value / total) * 100);
        const selected = selectedKey === card.key;
        return (
          <Card
            key={card.key}
            className={`mass-stat ${card.className}${onSelect ? " mass-stat--interactive" : ""}${selected ? " mass-stat--active" : ""}`}
            variant="borderless"
            role={onSelect ? "button" : undefined}
            tabIndex={onSelect ? 0 : undefined}
            aria-pressed={onSelect ? selected : undefined}
            aria-label={`查看${card.label}候选人`}
            onClick={onSelect ? () => onSelect(card.key) : undefined}
            onKeyDown={onSelect ? (event) => handleKeyDown(event, card.key) : undefined}
          >
            <div className="mass-stat__row">
              <div className="mass-stat__icon" aria-hidden="true">
                {card.icon}
              </div>
              <div>
                <div className="mass-stat__value">{value}</div>
                <div className="mass-stat__label">{card.label}</div>
                <div className="mass-stat__percentage">{percentage}%</div>
              </div>
            </div>
            <Progress
              percent={Math.min(percentage, 100)}
              showInfo={false}
              size="small"
              strokeColor={card.gradient}
            />
          </Card>
        );
      })}
    </div>
  );
}
