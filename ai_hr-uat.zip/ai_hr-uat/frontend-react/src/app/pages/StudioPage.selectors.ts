import { AGENT_CONFIG, type AgentId } from '../../shared/agent-config';

import { getPipelineStatus, type Pipeline } from '../../features/pipelines/api';

export const STANDARD_AGENTS = ['xiao_wen', 'xiao_xun', 'xiao_shai', 'xiao_mian'];
export const DEFAULT_PIPELINE_SORT = 'created_desc' as const;
export const PIPELINE_SORT_OPTIONS = [
  { label: '最新创建', value: 'created_desc' },
  { label: '最早创建', value: 'created_asc' },
  { label: '岗位名称 A-Z', value: 'role_asc' },
  { label: '岗位名称 Z-A', value: 'role_desc' },
] as const;

export const JOB_TYPE_OPTIONS = [
  { label: '技术岗', value: 'tech' },
  { label: '产品岗', value: 'product' },
  { label: '运营岗', value: 'operations' },
  { label: '销售岗', value: 'sales' },
  { label: '供应链岗', value: 'supply_chain' },
  { label: '服务岗', value: 'service' },
  { label: '管理岗', value: 'management' },
  { label: '职能岗', value: 'function' },
  { label: '通用岗', value: 'general' },
] as const;

export type PipelineSort = (typeof PIPELINE_SORT_OPTIONS)[number]['value'];
export type JobType = (typeof JOB_TYPE_OPTIONS)[number]['value'];
export type PipelineStatusFilter = 'running' | 'done';

export const PIPELINE_STATUS_FILTER_LABELS: Record<PipelineStatusFilter, string> = {
  running: '进行中',
  done: '已完成',
};

export function filterPipelines(
  pipelines: Pipeline[],
  searchTerm: string,
  statusFilter: PipelineStatusFilter | '',
) {
  const normalizedTerm = searchTerm.trim().toLowerCase();

  return pipelines.filter((pipeline) => {
    const matchesSearch = !normalizedTerm || [pipeline.role, getPipelineType(pipeline)]
      .filter(Boolean)
      .some((value) => value!.toLowerCase().includes(normalizedTerm));
    const matchesStatus = !statusFilter || getPipelineStatus(pipeline) === PIPELINE_STATUS_FILTER_LABELS[statusFilter];
    return matchesSearch && matchesStatus;
  });
}

export function parseStatusFilter(value: string | null): PipelineStatusFilter | '' {
  return value === 'running' || value === 'done' ? value : '';
}

export function parsePipelineSort(value: string | null): PipelineSort {
  return PIPELINE_SORT_OPTIONS.some((option) => option.value === value)
    ? (value as PipelineSort)
    : DEFAULT_PIPELINE_SORT;
}

export function parsePage(value: string | null) {
  const page = Number(value);
  return Number.isInteger(page) && page > 0 ? page : 1;
}

export function sortPipelines(pipelines: Pipeline[], sort: PipelineSort) {
  return [...pipelines].sort((left, right) => {
    if (sort === 'role_asc' || sort === 'role_desc') {
      const roleOrder = (left.role ?? '').localeCompare(right.role ?? '', 'zh-CN');
      if (roleOrder !== 0) {
        return sort === 'role_asc' ? roleOrder : -roleOrder;
      }
    } else {
      const leftCreatedAt = parseCreatedAt(left.created_at);
      const rightCreatedAt = parseCreatedAt(right.created_at);
      if (leftCreatedAt !== rightCreatedAt) {
        return sort === 'created_asc'
          ? leftCreatedAt - rightCreatedAt
          : rightCreatedAt - leftCreatedAt;
      }
    }

    return (left.id ?? left.pipeline_id ?? '').localeCompare(
      right.id ?? right.pipeline_id ?? '',
    );
  });
}

export function parseCreatedAt(value: string | undefined) {
  const timestamp = value ? Date.parse(value) : 0;
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

export function getPipelineProgress(pipeline: Pipeline) {
  if (getPipelineStatus(pipeline) === '已完成') {
    return 100;
  }

  const agents = pipeline.agents?.length ? pipeline.agents : STANDARD_AGENTS;
  const stages = pipeline.stages ?? [];
  const stageStatuses: Record<string, string> = {};
  stages.forEach((stage) => {
    if (stage.stage_id) stageStatuses[stage.stage_id] = stage.status ?? '';
  });

  let doneCount = 0;
  for (const agentId of agents) {
    const config = AGENT_CONFIG[agentId as AgentId];
    if (!config) continue;
    const allDone = config.stages.length > 0 && config.stages.every((stageId) => stageStatuses[stageId] === 'done');
    if (allDone) doneCount++;
  }

  return Math.round((doneCount / agents.length) * 100);
}

export function formatCreatedAt(value: string | undefined) {
  if (!value) {
    return '刚刚创建';
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '刚刚创建' : date.toLocaleDateString('zh-CN');
}

export function getPipelineId(pipeline: Pipeline) {
  return pipeline.id || pipeline.pipeline_id;
}

export function getPipelineType(pipeline: Pipeline) {
  const raw = pipeline.type || pipeline.pipeline_type;
  if (!raw) return '';
  const option = JOB_TYPE_OPTIONS.find((item) => item.value === raw);
  return option ? option.label : raw;
}

export function getPipelineTypeClass(pipeline: Pipeline) {
  const raw = pipeline.type || pipeline.pipeline_type;
  return JOB_TYPE_OPTIONS.some((option) => option.value === raw) ? raw : 'default';
}
