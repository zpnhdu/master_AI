import { Alert, Button, Card, Col, Empty, Progress, Row, Space, Spin, Statistic, Steps, Tag, Typography } from 'antd';
import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import type { EChartsOption } from 'echarts';

import { fetchCandidateProfile, fetchProfilePipeline, type CandidateProfile } from '../../features/profile/api';
import { DIM_LABELS, PROFILE_GROUPS, formatRecommended } from '../../features/profile/constants';
import { EChart } from '../../shared/EChart';
import { STAGE_NAMES } from '../../shared/agent-config';
import { routePaths } from '../routes/route-paths';

const STAGE_ORDER = ['jd_write', 'profile_build', 'poster_gen', 'crawl', 'match', 'interview_gen', 'video_assess', 'report'];

function weightLevel(weight: number) {
  if (weight >= 0.7) return { label: '高优', color: '#16a34a' };
  if (weight >= 0.4) return { label: '中优', color: '#2563eb' };
  return { label: '常规', color: '#64748b' };
}

export function ProfilePage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline_id') ?? searchParams.get('pipeline') ?? '';

  if (!pipelineId) {
    return (
      <div className="agent-page agent-page--status">
        <Alert
          type="warning"
          showIcon
          message="缺少岗位参数"
          description="请从岗位详情页进入候选人画像。"
          action={
            <Link to={routePaths.studio}>
              <Button size="small">返回工作室</Button>
            </Link>
          }
        />
      </div>
    );
  }
  return <ProfileContent key={pipelineId} pipelineId={pipelineId} />;
}

function ProfileContent({ pipelineId }: { pipelineId: string }) {
  const [activeDim, setActiveDim] = useState<string | null>(null);
  const profileQuery = useQuery({
    queryKey: ['profile', pipelineId],
    queryFn: () => fetchCandidateProfile(pipelineId),
    retry: 1,
  });
  const pipelineQuery = useQuery({
    queryKey: ['profile-pipeline', pipelineId],
    queryFn: () => fetchProfilePipeline(pipelineId),
    retry: 1,
  });

  const profile: CandidateProfile | null = profileQuery.data?.profile ?? null;
  const pipeline = pipelineQuery.data;

  const dims = profile?.dimensions ?? {};
  const activeKeys = useMemo(
    () => Object.keys(dims).filter((key) => typeof dims[key]?.weight === 'number' && (dims[key].weight ?? 0) > 0),
    [dims],
  );

  const radarOption: EChartsOption = useMemo(() => {
    return {
      radar: {
        indicator: activeKeys.map((key) => ({ name: DIM_LABELS[key] ?? key, max: 1 })),
        radius: '62%',
        shape: 'polygon',
        splitNumber: 4,
        axisName: { color: '#475569', fontSize: 12 },
        splitArea: { areaStyle: { color: ['#ffffff', '#f8fafc'] } },
      },
      series: [
        {
          type: 'radar',
          data: [
            {
              value: activeKeys.map((key) => dims[key]?.weight ?? 0),
              name: profile?.role ?? '候选人画像',
              areaStyle: { color: 'rgba(37, 99, 235, 0.18)' },
              lineStyle: { color: '#2563eb', width: 2 },
              itemStyle: {
                color: '#2563eb',
              },
            },
          ],
        },
      ],
      tooltip: {
        formatter: () => '',
      },
      // 分组着色标记在 tooltip 中展示
      color: PROFILE_GROUPS.map((group) => group.color),
      legend: { show: false },
      graphic: [],
      // 轴标签点击由 onEvents 处理
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any;
  }, [activeKeys, dims, profile?.role]);

  // 对齐旧版 profile.html：点击雷达轴标签高亮对应维度卡片
  const radarEvents = useMemo(
    () => ({
      click: (params: unknown) => {
        const event = params as { componentType?: string; targetType?: string; name?: string };
        if (event.componentType === 'radar' && event.targetType !== 'axisName') return;
        const clickedKey = Object.keys(DIM_LABELS).find((key) => DIM_LABELS[key] === event.name);
        if (clickedKey && activeKeys.includes(clickedKey)) {
          setActiveDim((current) => (current === clickedKey ? null : clickedKey));
        }
      },
    }),
    [activeKeys],
  );

  if (profileQuery.isPending || pipelineQuery.isPending) {
    return (
      <div className="agent-page">
        <div className="app-loading"><Spin size="large" tip="加载中" /></div>
      </div>
    );
  }

  if (profileQuery.isError || !profile) {
    return (
      <div className="agent-page agent-page--status">
        <Alert
          type="error"
          showIcon
          message="画像数据加载失败"
          description={profileQuery.error instanceof Error ? profileQuery.error.message : '该岗位暂无画像数据'}
          action={
            <Space>
              <Button onClick={() => void profileQuery.refetch()}>重新加载</Button>
              <Link to={routePaths.pipelineDetail(pipelineId)}>
                <Button type="primary">返回岗位详情</Button>
              </Link>
            </Space>
          }
        />
      </div>
    );
  }

  if (!activeKeys.length) {
    return (
      <div className="agent-page agent-page--status">
        <Empty description="暂无画像数据">
          <Link to={routePaths.studio}>
            <Button type="primary">前往工作台</Button>
          </Link>
        </Empty>
      </div>
    );
  }

  const weights = activeKeys.map((key) => dims[key]?.weight ?? 0);
  const avgWeight = Math.round((weights.reduce((sum, value) => sum + value, 0) / weights.length) * 100);
  const highCount = weights.filter((value) => value >= 0.7).length;
  const midCount = weights.filter((value) => value >= 0.4 && value < 0.7).length;

  const stages = (pipeline?.stages ?? []).slice().sort(
    (left, right) => STAGE_ORDER.indexOf(left.stage_id) - STAGE_ORDER.indexOf(right.stage_id),
  );

  return (
    <div className="agent-page profile-page">
      <header className="profile-page__header">
        <Space size={16} wrap>
              <Link to={routePaths.pipelineDetail(pipelineId)}>
            <Button>← 返回岗位</Button>
          </Link>
          <div>
            <Typography.Title level={3} style={{ margin: 0 }}>
              {pipeline?.role ?? profile.role ?? '候选人画像'}
            </Typography.Title>
            <Space size={8}>
              <Tag>Pipeline {pipelineId}</Tag>
              <Tag color={pipeline?.status === 'completed' ? 'success' : 'processing'}>
                {pipeline?.status === 'completed' ? '已完成' : '进行中'}
              </Tag>
            </Space>
          </div>
        </Space>
      </header>

      <Row gutter={[20, 20]} className="profile-page__body">
        <Col xs={24} xl={14}>
          <Card title="22 维能力雷达" className="agent-card">
            <EChart option={radarOption} height={520} onEvents={radarEvents} />
            <Row gutter={12} style={{ marginTop: 8 }}>
              <Col span={6}>
                <Statistic title="画像维度" value={activeKeys.length} suffix="维" />
              </Col>
              <Col span={6}>
                <Statistic title="平均权重" value={avgWeight} suffix="%" />
              </Col>
              <Col span={6}>
                <Statistic title="高优维度" value={highCount} suffix="个" valueStyle={{ color: '#16a34a' }} />
              </Col>
              <Col span={6}>
                <Statistic title="中优维度" value={midCount} suffix="个" valueStyle={{ color: '#2563eb' }} />
              </Col>
            </Row>
          </Card>
        </Col>
        <Col xs={24} xl={10}>
          {PROFILE_GROUPS.map((group) => {
            const groupDims = group.keys.filter((key) => activeKeys.includes(key));
            if (!groupDims.length) return null;
            return (
              <Card
                key={group.key}
                className="agent-card"
                title={
                  <span style={{ color: group.color }}>
                    {group.icon} {group.name}
                  </span>
                }
                size="small"
              >
                {groupDims.map((key) => {
                  const dim = dims[key];
                  const weight = dim?.weight ?? 0;
                  const pct = Math.round(weight * 100);
                  const level = weightLevel(weight);
                  return (
                    <button
                      key={key}
                      type="button"
                      className={`profile-dim-card${activeDim === key ? ' profile-dim-card--active' : ''}`}
                      onClick={() => setActiveDim((current) => (current === key ? null : key))}
                    >
                      <div className="profile-dim-card__head">
                        <Typography.Text strong>{DIM_LABELS[key] ?? key}</Typography.Text>
                        <Tag color={level.color}>{`${pct}% · ${level.label}`}</Tag>
                      </div>
                      <Typography.Paragraph style={{ margin: '4px 0' }}>
                        推荐：{formatRecommended(dim?.recommended)}
                      </Typography.Paragraph>
                      {dim?.reasoning ? (
                        <Typography.Paragraph type="secondary" style={{ margin: '0 0 8px' }} ellipsis={{ rows: 2 }}>
                          {dim.reasoning}
                        </Typography.Paragraph>
                      ) : null}
                      <Progress
                        percent={pct}
                        showInfo={false}
                        strokeColor={group.color}
                        size="small"
                      />
                    </button>
                  );
                })}
              </Card>
            );
          })}
        </Col>
      </Row>

      {stages.length ? (
        <Card title="岗位进度" className="agent-card" style={{ maxWidth: 1400, margin: '0 auto' }}>
          <Steps
            size="small"
            items={stages.map((stage) => ({
              title: STAGE_NAMES[stage.stage_id] ?? stage.stage_id,
              status:
                stage.status === 'completed' || stage.status === 'done'
                  ? 'finish'
                  : stage.status === 'running'
                    ? 'process'
                    : 'wait',
            }))}
          />
        </Card>
      ) : null}
    </div>
  );
}