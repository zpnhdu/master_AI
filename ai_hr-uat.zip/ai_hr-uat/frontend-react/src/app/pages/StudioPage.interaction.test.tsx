import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { MemoryRouter, useLocation } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { AuthProvider } from '../auth/AuthContext';
import { StudioPage } from './StudioPage';

afterEach(cleanup);
afterEach(() => {
  vi.unstubAllGlobals();
  vi.stubGlobal(
    'ResizeObserver',
    class ResizeObserverMock {
      observe() {}

      unobserve() {}

      disconnect() {}
    },
  );
});

beforeEach(() => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify([
          {
            id: 'pipeline-1',
            role: 'Java 后端工程师',
            status: 'running',
            type: 'tech',
            agents: ['xiao_wen', 'xiao_xun'],
            stages: [
              { stage_id: 'jd_write', status: 'done' },
              { stage_id: 'profile_build', status: 'done' },
              { stage_id: 'crawl', status: 'running' },
            ],
          },
        ]),
        { status: 200 },
      ),
    ),
  );
});

function renderStudio() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={['/studio']}>
        <AntdApp>
          <AuthProvider>
            <StudioPage />
          </AuthProvider>
          <LocationProbe />
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

function LocationProbe() {
  const location = useLocation();

  return <output data-testid="location-path">{location.pathname}</output>;
}

describe('StudioPage interaction affordances', () => {
  it('keeps the list focused and makes delete action explicit without opening the card', async () => {
    renderStudio();

    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    expect(screen.queryByText('岗位列表', { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByLabelText('Java 后端工程师招聘阶段')).not.toBeInTheDocument();
    expect(screen.queryByRole('region', { name: '批量操作' })).not.toBeInTheDocument();
    expect(screen.getByText('技术岗')).toHaveClass('pipeline-list-item__type--tech');
    expect(document.querySelector('.pipeline-list-item__progress-bar--running')).toBeInTheDocument();
    expect(screen.getByRole('progressbar', { name: 'Java 后端工程师招聘进度' })).toHaveAttribute(
      'aria-valuenow',
    );
    expect(screen.getByRole('button', { name: '查看Java 后端工程师详情' })).toBeInTheDocument();

    const deleteButton = screen.getByRole('button', { name: '删除Java 后端工程师' });
    expect(deleteButton).toHaveAttribute('title', '删除Java 后端工程师');
    expect(deleteButton.querySelector('svg')).toBeInTheDocument();

    fireEvent.click(deleteButton);
    expect(screen.getByTestId('location-path')).toHaveTextContent('/studio');
    expect(screen.getByText('将删除：Java 后端工程师')).toBeInTheDocument();
  });

  it('allows selecting the current page from the selection bar', async () => {
    renderStudio();

    fireEvent.click(await screen.findByRole('checkbox', { name: '全选当前页' }));

    expect(screen.getByRole('checkbox', { name: '选择Java 后端工程师' })).toBeChecked();
    expect(screen.getByText('已选 1 条')).toBeInTheDocument();
    expect(screen.queryByText('已选 1 条（1 项）')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '批量删除' })).toBeInTheDocument();
  });

  it('keeps the date filter on other by default and shows pagination for one page', async () => {
    renderStudio();

    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    expect(screen.queryByText('最新创建')).not.toBeInTheDocument();
    const dateRange = document.querySelector('.studio-page__date-range');
    expect(dateRange).toBeInTheDocument();
    expect([...dateRange!.querySelectorAll('input')].every((input) => !input.value)).toBe(true);
    expect(document.querySelector('.studio-page__pagination')).toBeInTheDocument();
  });

  it('filters from statistic cards and clears the empty state', async () => {
    renderStudio();

    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '查看已完成岗位' }));

    expect(await screen.findByText('没有匹配结果')).toBeInTheDocument();
    expect(screen.getByText('状态：已完成')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '清除筛选条件' }));

    expect(await screen.findByText('Java 后端工程师')).toBeInTheDocument();
    expect(screen.queryByText('状态：已完成')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '查看全部岗位' })).toHaveAttribute('aria-pressed', 'true');
  }, 15000);
});
