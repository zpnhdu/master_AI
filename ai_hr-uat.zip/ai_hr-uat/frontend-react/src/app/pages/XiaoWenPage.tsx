import { Alert, Button, Spin } from 'antd';
import { useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';

import { ChatPane } from '../../features/xiao-wen/components/ChatPane';
import { DocumentPane } from '../../features/xiao-wen/components/DocumentPane';
import { PreviewModal } from '../../features/xiao-wen/components/PreviewModal';
import { XiaoWenTopbar } from '../../features/xiao-wen/components/XiaoWenTopbar';
import { jdWorkspaceQueryKey } from '../../features/xiao-wen/hooks';
import { useVoiceRecorder } from '../../features/xiao-wen/useVoiceRecorder';
import { useXiaoWenController } from '../../features/xiao-wen/useXiaoWenController';
import { agentWorkspaceUrl } from '../../shared/agent-config';
import { routePaths } from '../routes/route-paths';
import { usePipelineSocketSync } from '../../shared/usePipelineSocket';
import '../../features/xiao-wen/xiao-wen.css';

/**
 * 小文 · JD 工作台（/xiao-wen?pipeline=<id>）。
 * 从 frontend/xiao_wen.html 迁移，全屏三栏布局，不使用 AppShell。
 */
export function XiaoWenPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get('pipeline') ?? '';

  if (!pipelineId) {
    return (
      <div className="xw-app">
        <div className="xw-page-status">
          <Alert
            type="warning"
            showIcon
            message="缺少岗位参数"
            description="请从岗位详情页进入小文工作台。"
            action={
              <Link to={routePaths.studio}>
                <Button size="small">返回工作台</Button>
              </Link>
            }
          />
        </div>
      </div>
    );
  }
  // key 保证切换流水线时整体重置控制器状态。
  return <XiaoWenWorkspace key={pipelineId} pipelineId={pipelineId} />;
}

function XiaoWenWorkspace({ pipelineId }: { pipelineId: string }) {
  const navigate = useNavigate();
  const controller = useXiaoWenController(pipelineId);
  // 实时链路：JD 生成/修改事件到达后自动刷新工作区（轮询保留作降级）
  usePipelineSocketSync(pipelineId, [jdWorkspaceQueryKey(pipelineId)]);
  const { workspace, workspaceQuery } = controller;

  const voice = useVoiceRecorder({
    onTranscript: (text) => {
      const current = controller.composerValue.trim();
      controller.setComposerValue(current ? `${current}\n${text}` : text);
    },
    disabled: controller.busy || controller.autoDraftBusy || controller.jdLocked,
  });

  useEffect(() => {
    if (workspace?.role) {
      document.title = `${workspace.role} · 小文`;
    }
    return () => {
      document.title = '锅圈食汇 - 智能招聘平台';
    };
  }, [workspace?.role]);

  if (workspaceQuery.isPending) {
    return (
      <div className="xw-app">
        <div className="xw-page-status">
          <div className="app-loading"><Spin size="large" /></div>
        </div>
      </div>
    );
  }

  if (workspaceQuery.isError || !workspace) {
    return (
      <div className="xw-app">
        <div className="xw-page-status">
          <Alert
            type="error"
            showIcon
            message="小文工作台加载失败"
            description={
              workspaceQuery.error instanceof Error
                ? workspaceQuery.error.message
                : '工作台数据加载失败'
            }
            action={
              <Button size="small" onClick={() => void workspaceQuery.refetch()}>
                重试
              </Button>
            }
          />
        </div>
      </div>
    );
  }

  const role = workspace.role || '未命名岗位';
  const voiceBusy = controller.busy || controller.autoDraftBusy;
  const composerLocked =
    controller.jdLocked || voiceBusy || voice.status === 'recording' || voice.status === 'transcribing';

  const openAgent = (agentId: string) => {
    navigate(agentWorkspaceUrl(agentId, pipelineId));
  };

  const downstream = workspace.downstream;
  const canEnterDownstream = Boolean(
    downstream &&
      controller.approved &&
      workspace.profile_is_current &&
      !controller.dirty &&
      !controller.saving &&
      !controller.preview,
  );
  const downstreamTitle = !downstream
    ? '当前流程没有配置下游'
    : controller.dirty || controller.saving
      ? '请等待当前 JD 保存完成'
      : controller.preview
        ? '请先应用或放弃当前 AI 修改建议'
        : !controller.approved || !workspace.profile_is_current
          ? '请先确认 JD 并生成候选人画像'
          : downstream.passed
            ? `进入已接收当前 JD 和候选人画像的${downstream.name}工作台`
            : `先传递当前 JD 和候选人画像，再进入${downstream.name}工作台`;

  const enterDownstream = async () => {
    if (!downstream || !canEnterDownstream || controller.busy) {
      return;
    }
    if (await controller.passDownstream()) {
      openAgent(downstream.agent_id);
    }
  };

  return (
    <div className="xw-app">
      <XiaoWenTopbar
        role={role}
        approved={controller.approved}
        pipelineId={pipelineId}
        downstreamPassed={Boolean(downstream?.passed)}
        canPass={canEnterDownstream}
        passDisabledReason={downstreamTitle}
        passLoading={controller.busy}
        onPassDownstream={() => void enterDownstream()}
        canApprove={controller.canApprove}
        approveLabel={controller.approveLabel}
        approveTitle={controller.approveTitle}
        onApprove={() => void controller.approve()}
        locked={controller.jdLocked}
      />
      <nav className="xw-mobile-switch" aria-label="移动端视图切换">
        <button
          className={controller.mobileView === 'chat' ? 'active' : ''}
          type="button"
          onClick={() => controller.setMobileView('chat')}
        >
          对话
        </button>
        <button
          className={controller.mobileView === 'document' ? 'active' : ''}
          type="button"
          onClick={() => controller.setMobileView('document')}
        >
          JD 文档
        </button>
      </nav>
      <main className="xw-workspace" data-mobile-view={controller.mobileView}>
        <ChatPane
          role={role}
          messages={controller.messages}
          typing={controller.typing}
          autoDraftBusy={controller.autoDraftBusy}
          hasJd={controller.jdReady}
          quickPrompts={controller.quickPrompts}
          composerValue={controller.composerValue}
          composerDisabled={composerLocked}
          activePreviewId={controller.preview?.id ?? null}
          voiceSupported={voice.supported}
          voiceStatus={voice.status}
          voiceSeconds={voice.seconds}
          voiceNotice={voice.notice}
          voiceNoticeType={voice.noticeType}
          voiceBusy={voiceBusy || controller.jdLocked}
          onComposerChange={controller.setComposerValue}
          onSend={() => void controller.sendMessage()}
          onToggleVoice={voice.toggle}
          onApplyPreview={() => void controller.applyPreview()}
          onDiscardPreview={controller.discardPreview}
          onOpenProfile={() => controller.openDocumentSection('profile')}
          onOpenAgent={openAgent}
          jdLocked={controller.jdLocked}
        />
        <DocumentPane
          activeSection={controller.activeSection}
          onSectionChange={controller.setActiveSection}
          role={role}
          draft={controller.draft}
          changedFields={controller.preview?.changed_fields ?? []}
          autoDraftStatus={controller.autoDraft.status}
          autoDraftError={controller.autoDraft.error}
          qualityChecks={workspace.quality_checks}
          profile={workspace.profile}
          approved={controller.approved}
          saveState={controller.saveState}
          previewDisabled={!controller.jdReady}
          focusRequest={controller.focusRequest}
          onOpenPreview={() => controller.setPreviewOpen(true)}
          onCopy={() => void controller.copyJd()}
          onRetryAutoDraft={controller.retryAutoDraft}
          onFixField={controller.requestFieldFocus}
          onUpdateField={controller.updateDraftField}
          onUpdateListItem={controller.updateDraftListItem}
          onRemoveListItem={controller.removeDraftListItem}
          locked={controller.jdLocked}
        />
      </main>
      <PreviewModal
        open={controller.previewOpen}
        draft={controller.draft}
        onClose={() => controller.setPreviewOpen(false)}
      />
    </div>
  );
}