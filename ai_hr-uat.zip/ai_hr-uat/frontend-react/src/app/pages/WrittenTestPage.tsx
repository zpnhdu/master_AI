import {
  Alert,
  Button,
  Card,
  Input,
  Progress,
  Space,
  Spin,
  Tag,
  Typography,
  message,
} from 'antd';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';

import {
  fetchWrittenTestSession,
  heartbeatWrittenTestSession,
  releaseWrittenTestSession,
  submitWrittenTestAnswers,
  transcribeWrittenAnswer,
  uploadWrittenTestVideo,
  type WrittenTestSession,
} from '../../features/written-test/api';
import { getErrorMessage } from '../../shared/errors';
import {
  AssessmentSessionGuard,
  formatAssessmentDeadline,
} from '../../shared/AssessmentSessionGuard';
import { useSingleTabLock } from '../../shared/useSingleTabLock';

type PageState =
  | 'loading'
  | 'welcome'
  | 'answering'
  | 'confirming'
  | 'submitting'
  | 'complete'
  | 'expired'
  | 'submitted'
  | 'error';

export function appendTranscriptToAnswer(answer: string, transcript: string) {
  const normalizedTranscript = transcript.trim();
  if (!normalizedTranscript) return answer;
  return answer.trim() ? `${answer}\n${normalizedTranscript}` : normalizedTranscript;
}

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach((track) => track.stop());
}

function preferredMimeType(kind: 'audio' | 'video') {
  if (typeof MediaRecorder === 'undefined') return '';
  const candidates = kind === 'video'
    ? ['video/webm;codecs=vp8,opus', 'video/webm']
    : ['audio/webm;codecs=opus', 'audio/webm'];
  return candidates.find((type) => MediaRecorder.isTypeSupported(type)) ?? '';
}

export function WrittenTestPage() {
  const { token = '' } = useParams();
  const [pageState, setPageState] = useState<PageState>('loading');
  const [session, setSession] = useState<WrittenTestSession | null>(null);
  const [errorText, setErrorText] = useState('');
  const tabLockState = useSingleTabLock(token);
  const [answers, setAnswers] = useState<string[]>([]);
  const answersRef = useRef<string[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(0);
  // 在线笔试当前只允许文字与语音转写作答；保留前端录制分支及后端上传逻辑，
  // 以兼容历史视频会话并便于后续按业务需要重新开放。
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [voiceRecording, setVoiceRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [transcriptQuestion, setTranscriptQuestion] = useState<number | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const cameraRecorderRef = useRef<MediaRecorder | null>(null);
  const cameraChunksRef = useRef<Blob[]>([]);
  const voiceStreamRef = useRef<MediaStream | null>(null);
  const voiceRecorderRef = useRef<MediaRecorder | null>(null);
  const voiceChunksRef = useRef<Blob[]>([]);
  const voiceQuestionRef = useRef(0);
  const submittingRef = useRef(false);

  const expireSession = useCallback(() => {
    stopStream(cameraStreamRef.current);
    stopStream(voiceStreamRef.current);
    cameraStreamRef.current = null;
    voiceStreamRef.current = null;
    if (cameraRecorderRef.current?.state === 'recording') cameraRecorderRef.current.stop();
    if (voiceRecorderRef.current?.state === 'recording') voiceRecorderRef.current.stop();
    cameraRecorderRef.current = null;
    voiceRecorderRef.current = null;
    setCameraActive(false);
    setVoiceRecording(false);
    setErrorText('笔试链接已达到数据库设置的截止时间，请联系招聘人员');
    setPageState((current) => (['complete', 'submitted'].includes(current) ? current : 'expired'));
    if (token) void releaseWrittenTestSession(token).catch(() => undefined);
  }, [token]);

  const sessionGuard = session ? (
    <AssessmentSessionGuard
      active={pageState === 'answering' || pageState === 'confirming'}
      expiresAt={session.expires_at}
      assessmentName="笔试"
      onExpired={expireSession}
    />
  ) : null;

  useEffect(() => {
    if (tabLockState === 'checking') return;
    if (tabLockState === 'locked') {
      setErrorText('该笔试链接已在其他窗口打开，请关闭其他窗口后重试');
      setPageState('error');
      return;
    }
    let disposed = false;
    void fetchWrittenTestSession(token).then((result) => {
      if (disposed) return;
      if (result.kind === 'expired') {
        setErrorText(result.message);
        setPageState('expired');
        return;
      }
      if (result.kind === 'submitted') {
        setErrorText(result.message);
        setPageState('submitted');
        return;
      }
      if (result.kind === 'error') {
        setErrorText(result.message);
        setPageState('error');
        return;
      }
      const initialAnswers = result.session.questions.map(() => '');
      setSession(result.session);
      setAnswers(initialAnswers);
      answersRef.current = initialAnswers;
      setSecondsLeft(Math.max(1, result.session.time_limit_minutes) * 60);
      setPageState('welcome');
    }).catch((error) => {
      if (disposed) return;
      setErrorText(getErrorMessage(error, '该考试已在其他设备或窗口答题'));
      setPageState('error');
    });
    return () => {
      disposed = true;
    };
  }, [token, tabLockState]);

  // The browser lock is only a UX guard. Keep a server-side lease alive so
  // another device cannot submit, transcribe, or upload against this session.
  useEffect(() => {
    if (!session || pageState === 'loading' || pageState === 'error' || pageState === 'expired' || pageState === 'submitted' || pageState === 'complete') return;
    const heartbeat = window.setInterval(() => {
      void heartbeatWrittenTestSession(token);
    }, 10_000);
    return () => window.clearInterval(heartbeat);
  }, [pageState, session, token]);

  useEffect(() => () => {
    if (token) void releaseWrittenTestSession(token);
  }, [token]);

  useEffect(() => {
    if (videoRef.current && cameraStreamRef.current) {
      videoRef.current.srcObject = cameraStreamRef.current;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [cameraActive]);

  const stopVoice = useCallback(async () => {
    const recorder = voiceRecorderRef.current;
    if (!recorder || recorder.state === 'inactive') return;
    const questionIndex = voiceQuestionRef.current;
    await new Promise<void>((resolve) => {
      recorder.addEventListener('stop', () => resolve(), { once: true });
      recorder.stop();
    });
    stopStream(voiceStreamRef.current);
    voiceStreamRef.current = null;
    voiceRecorderRef.current = null;
    setVoiceRecording(false);
    const blob = new Blob(voiceChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
    if (!blob.size) return;
    setTranscribing(true);
    try {
      const transcript = await transcribeWrittenAnswer(token, questionIndex, blob);
      setVoiceTranscript(transcript);
      setTranscriptQuestion(questionIndex);
      message.success('语音已转成文字，请确认后应用到答案');
    } catch (error) {
      message.error(getErrorMessage(error, '语音转写失败'));
    } finally {
      setTranscribing(false);
    }
  }, [message, token]);

  const stopCamera = useCallback(async () => {
    const recorder = cameraRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      await new Promise<void>((resolve) => {
        recorder.addEventListener('stop', () => resolve(), { once: true });
        recorder.stop();
      });
    }
    stopStream(cameraStreamRef.current);
    cameraStreamRef.current = null;
    cameraRecorderRef.current = null;
    setCameraActive(false);
    if (!cameraChunksRef.current.length) return;
    const video = new Blob(cameraChunksRef.current, { type: recorder?.mimeType || 'video/webm' });
    cameraChunksRef.current = [];
    if (!video.size) return;
    try {
      await uploadWrittenTestVideo(token, video);
    } catch (error) {
      message.warning(`${getErrorMessage(error, '录像上传失败')}，文字答案仍会正常提交`);
    }
  }, [message, token]);

  const submitAnswers = useCallback(async () => {
    if (!session || submittingRef.current) return;
    submittingRef.current = true;
    setErrorText('');
    setPageState('submitting');
    try {
      if (voiceRecorderRef.current?.state === 'recording') await stopVoice();
      await stopCamera();
      await submitWrittenTestAnswers(
        token,
        answersRef.current.map((answerText, questionIndex) => ({
          question_index: questionIndex,
          answer_text: answerText.trim(),
        })),
      );
      // Stop renewing immediately and release the lease as soon as submission succeeds.
      await releaseWrittenTestSession(token).catch(() => undefined);
      setPageState('complete');
    } catch (error) {
      setErrorText(getErrorMessage(error, '答案提交失败，请重试'));
      setPageState('confirming');
      message.error(getErrorMessage(error, '答案提交失败，请重试'));
    } finally {
      submittingRef.current = false;
    }
  }, [message, session, stopCamera, stopVoice, token]);

  useEffect(() => {
    if (pageState !== 'answering' && pageState !== 'confirming') return;
    const timer = window.setInterval(() => {
      setSecondsLeft((current) => {
        if (current > 1) return current - 1;
        window.clearInterval(timer);
        message.warning('答题时间已到，系统正在自动提交');
        queueMicrotask(() => void submitAnswers());
        return 0;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [message, pageState, submitAnswers]);

  useEffect(
    () => () => {
      stopStream(cameraStreamRef.current);
      stopStream(voiceStreamRef.current);
      if (cameraRecorderRef.current?.state === 'recording') cameraRecorderRef.current.stop();
      if (voiceRecorderRef.current?.state === 'recording') voiceRecorderRef.current.stop();
    },
    [],
  );

  async function startTest() {
    if (!session?.questions.length) {
      setErrorText('本次笔试暂时没有可作答题目，请联系招聘人员');
      setPageState('error');
      return;
    }
    if (cameraEnabled) {
      try {
        if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
          throw new Error('当前浏览器不支持摄像头录制');
        }
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        const mimeType = preferredMimeType('video');
        const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
        cameraChunksRef.current = [];
        recorder.ondataavailable = (event) => {
          if (event.data.size) cameraChunksRef.current.push(event.data);
        };
        recorder.start(1000);
        cameraStreamRef.current = stream;
        cameraRecorderRef.current = recorder;
        setCameraActive(true);
      } catch (error) {
        setCameraEnabled(false);
        message.warning(`${getErrorMessage(error, '无法启用摄像头')}，将继续文字答题`);
      }
    }
    setPageState('answering');
  }

  async function toggleVoiceRecording() {
    if (voiceRecording) {
      await stopVoice();
      return;
    }
    try {
      if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
        throw new Error('当前浏览器不支持语音录制');
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = preferredMimeType('audio');
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      voiceChunksRef.current = [];
      voiceQuestionRef.current = currentQuestion;
      recorder.ondataavailable = (event) => {
        if (event.data.size) voiceChunksRef.current.push(event.data);
      };
      voiceStreamRef.current = stream;
      voiceRecorderRef.current = recorder;
      recorder.start();
      setVoiceRecording(true);
    } catch (error) {
      message.error(getErrorMessage(error, '无法使用麦克风'));
    }
  }

  function updateAnswer(value: string) {
    setAnswers((current) => {
      const next = current.map((answer, index) => (index === currentQuestion ? value : answer));
      answersRef.current = next;
      return next;
    });
  }

  function applyTranscript() {
    if (transcriptQuestion !== currentQuestion || !voiceTranscript.trim()) return;
    updateAnswer(appendTranscriptToAnswer(answersRef.current[currentQuestion] ?? '', voiceTranscript));
    setVoiceTranscript('');
    setTranscriptQuestion(null);
    message.success('语音文字已追加到当前答案');
  }

  if (pageState === 'loading') {
    return <TerminalPanel loading title="正在加载笔试" description="正在校验链接并准备题目…" />;
  }
  if (pageState === 'expired') return <TerminalPanel title="链接已过期" description={errorText} tone="warning" />;
  if (pageState === 'submitted') return <TerminalPanel title="答案已提交" description={errorText} tone="success" />;
  if (pageState === 'error' || !session) {
    return <TerminalPanel title="无法打开笔试" description={errorText || '笔试链接无效'} tone="error" />;
  }
  if (pageState === 'complete') {
    return <TerminalPanel title="提交成功！" description="感谢完成本次在线笔试，招聘人员会尽快与您联系。" tone="success" />;
  }
  if (pageState === 'submitting') {
    return <TerminalPanel loading title="正在保存答案" description="正在安全保存文字答案。保存成功后即可关闭页面，AI 评分会在后台继续。" />;
  }

  if (pageState === 'welcome') {
    return (
      <>
        {sessionGuard}
        <main className="wt-page wt-page--center">
          <Card className="wt-card wt-welcome-card">
            <div className="wt-brand">{session.company_name || '在线笔试'}</div>
            <Typography.Title level={2}>{session.candidate_name}，你好！</Typography.Title>
            <Typography.Paragraph type="secondary">
              欢迎参加 <strong>{session.role || '应聘岗位'}</strong>{' '}
              在线笔试。开始后请独立完成，倒计时结束将自动提交。
            </Typography.Paragraph>
            <div className="wt-meta-grid">
              <div><span>题目数量</span><strong>{session.questions.length} 题</strong></div>
              <div><span>答题时间</span><strong>{session.time_limit_minutes} 分钟</strong></div>
            </div>
            {session.expires_at ? (
              <Alert
                type="info"
                showIcon
                title={`笔试链接有效期至 ${formatAssessmentDeadline(session.expires_at)}`}
              />
            ) : null}
            <Button type="primary" size="large" block onClick={() => void startTest()}>
              开始答题
            </Button>
          </Card>
        </main>
      </>
    );
  }

  if (pageState === 'confirming') {
    const answeredCount = answers.filter((answer) => answer.trim()).length;
    return (
      <>
        {sessionGuard}
        <main className="wt-page wt-page--center">
          <Card className="wt-card wt-confirm-card">
            <Typography.Title level={2}>确认提交</Typography.Title>
            <Alert
              type={answeredCount === answers.length ? 'success' : 'warning'}
              showIcon
              title={`已作答 ${answeredCount}/${answers.length} 题`}
              description={answeredCount === answers.length ? '请确认答案无误后提交。' : '仍有题目未作答，您也可以返回继续填写。'}
            />
            <div className="wt-confirm-list">
              {session.questions.map((question, index) => (
                <button
                  type="button"
                  key={question.id ?? index}
                  className="wt-confirm-item"
                  onClick={() => {
                    setCurrentQuestion(index);
                    setPageState('answering');
                  }}
                >
                  <span>第 {index + 1} 题</span>
                  <Tag color={answers[index]?.trim() ? 'success' : 'warning'}>
                    {answers[index]?.trim() ? '已作答' : '未作答'}
                  </Tag>
                </button>
              ))}
            </div>
            {errorText ? <Alert type="error" showIcon title={errorText} /> : null}
            <Space className="wt-confirm-actions">
              <Button onClick={() => setPageState('answering')}>返回修改</Button>
              <Button type="primary" onClick={() => void submitAnswers()}>确认提交</Button>
            </Space>
          </Card>
        </main>
      </>
    );
  }

  const question = session.questions[currentQuestion];
  const answeredCount = answers.filter((answer) => answer.trim()).length;
  const progress = Math.round((answeredCount / session.questions.length) * 100);
  return (
    <>
      {sessionGuard}
      <main className="wt-page">
        <header className="wt-header">
        <div>
          <span>{session.role}</span>
        </div>
        <div className={secondsLeft <= 300 ? 'wt-timer wt-timer--urgent' : 'wt-timer'}>{formatTime(secondsLeft)}</div>
        </header>
        <div className="wt-shell">
        <aside className="wt-sidebar">
          <Typography.Text type="secondary">答题进度</Typography.Text>
          <Progress percent={progress} size="small" />
          <div className="wt-question-nav">
            {session.questions.map((item, index) => (
              <Button
                key={item.id ?? index}
                type={index === currentQuestion ? 'primary' : 'default'}
                className={answers[index]?.trim() ? 'wt-question-nav__answered' : ''}
                disabled={voiceRecording || transcribing}
                onClick={() => setCurrentQuestion(index)}
              >
                {index + 1}
              </Button>
            ))}
          </div>
          {cameraActive ? <video className="wt-camera-preview" ref={videoRef} autoPlay muted playsInline /> : null}
        </aside>
        <Card className="wt-card wt-question-card">
          <div className="wt-question-heading">
            <div>
              <Typography.Text type="secondary">第 {currentQuestion + 1} / {session.questions.length} 题</Typography.Text>
              {question.difficulty ? <Tag>{question.difficulty}</Tag> : null}
            </div>
            <Typography.Title level={3}>{question.question || '请回答本题'}</Typography.Title>
          </div>
          <Input.TextArea
            value={answers[currentQuestion]}
            rows={10}
            maxLength={10000}
            showCount
            placeholder="在此输入你的回答，也可以使用下方语音转文字…"
            onChange={(event) => updateAnswer(event.target.value)}
          />
          <div className="wt-voice-panel">
            <Button
              danger={voiceRecording}
              loading={transcribing}
              disabled={transcribing}
              onClick={() => void toggleVoiceRecording()}
            >
              {voiceRecording ? '停止录音并转写' : transcribing ? '正在转写…' : '语音回答'}
            </Button>
            {transcriptQuestion === currentQuestion ? (
              <div className="wt-transcript">
                <Input.TextArea value={voiceTranscript} rows={3} onChange={(event) => setVoiceTranscript(event.target.value)} />
                <Button size="small" type="primary" onClick={applyTranscript}>应用到答案</Button>
              </div>
            ) : null}
          </div>
          <div className="wt-question-actions">
            <Button
              disabled={currentQuestion === 0 || voiceRecording || transcribing}
              onClick={() => setCurrentQuestion((index) => index - 1)}
            >
              上一题
            </Button>
            {currentQuestion < session.questions.length - 1 ? (
              <Button
                type="primary"
                disabled={voiceRecording || transcribing}
                onClick={() => setCurrentQuestion((index) => index + 1)}
              >
                下一题
              </Button>
            ) : (
              <Button
                type="primary"
                disabled={voiceRecording || transcribing}
                onClick={() => setPageState('confirming')}
              >
                完成作答
              </Button>
            )}
          </div>
        </Card>
        </div>
      </main>
    </>
  );
}

function TerminalPanel({
  title,
  description,
  tone = 'info',
  loading = false,
}: {
  title: string;
  description: string;
  tone?: 'info' | 'warning' | 'success' | 'error';
  loading?: boolean;
}) {
  return (
    <main className="wt-page wt-page--center">
      <Card className="wt-card wt-terminal-card">
        {loading ? <Spin size="large" tip="加载中" /> : <div className={`wt-terminal-icon wt-terminal-icon--${tone}`}>✓</div>}
        <Typography.Title level={2}>{title}</Typography.Title>
        <Typography.Paragraph type="secondary">{description}</Typography.Paragraph>
      </Card>
    </main>
  );
}
