import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntApp } from 'antd';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { KnowledgePage } from './KnowledgePage';

vi.mock('../components/AppShell', () => ({
  AppShell: ({ children }: { children: ReactNode }) => children,
}));

vi.mock('../../features/material-library/MaterialLibrary', () => ({
  MaterialLibrary: ({ activeTab = 'backgrounds' }: { activeTab?: 'backgrounds' | 'elements' }) => {
    useEffect(() => {
      void fetch('/api/xiao-hai/elements', {});
    }, []);

    return (
      <section>
        <h2>{activeTab === 'backgrounds' ? '背景图' : '装饰元素'}</h2>
        {activeTab === 'backgrounds' && <img src="/bg.png" alt="门店背景" />}
      </section>
    );
  },
}));

function jsonResponse(body: unknown, status = 200) {
  return Promise.resolve({
    ok: status >= 200 && status < 300,
    status,
    json: async () => body,
    text: async () => JSON.stringify(body),
  } as Response);
}

function renderPage(initialEntry = '/knowledge') {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntApp>
          <KnowledgePage />
        </AntApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('KnowledgePage material library destination', () => {
  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
  });

  it('renders the material library when opened from its sidebar destination', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
      const url = String(input);
      if (url === '/api/xiao-hai/elements') {
        return jsonResponse({
          backgrounds: [{ id: 'bg-1', label: '门店背景', url: '/bg.png' }],
          elements: [{ id: 'el-1', label: '品牌贴纸', url: '/sticker.png' }],
        });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge?tab=materials');

    expect(await screen.findByRole('heading', { name: '素材库' })).toBeInTheDocument();
    expect(await screen.findByAltText('门店背景')).toBeInTheDocument();
    expect(screen.queryByAltText('品牌贴纸')).not.toBeInTheDocument();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledWith('/api/xiao-hai/elements', expect.anything()));
  });

  it('renders graph mode by default with search and page tabs', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
      const url = String(input);
      if (url === '/api/knowledge/wiki/tree') {
        return jsonResponse({
          tree: {
            concept: [
              { slug: 'demand-planning', path: 'wiki/concepts/demand-planning.md', title: '需求计划' },
              { slug: 'supply-planning', path: 'wiki/concepts/supply-planning.md', title: '供应计划' },
            ],
            source: [{ slug: 'source-1', path: 'wiki/sources/source-1.md', title: '源文档' }],
          },
          stats: { pages: 3, types: { concept: 2, source: 1 } },
        });
      }
      if (url === '/api/knowledge/wiki/graph') {
        return jsonResponse({ nodes: [], edges: [], missing_links: [] });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge');

    expect(await screen.findByRole('heading', { name: '知识库' })).toBeInTheDocument();
    expect(screen.getByPlaceholderText('搜索知识内容…')).toBeInTheDocument();
    expect(screen.getByText('浏览知识')).toBeInTheDocument();
    expect(screen.getByText('知识图谱')).toBeInTheDocument();
    expect(await screen.findByText('暂无页面，先上传资料或导入图谱')).toBeInTheDocument();
  });

  it('switches to browse mode from graph mode', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
      const url = String(input);
      if (url === '/api/knowledge/wiki/tree') {
        return jsonResponse({
          tree: {
            concept: [
              { slug: 'demand-planning', path: 'wiki/concepts/demand-planning.md', title: '需求计划' },
              { slug: 'supply-planning', path: 'wiki/concepts/supply-planning.md', title: '供应计划' },
            ],
            source: [{ slug: 'source-1', path: 'wiki/sources/source-1.md', title: '源文档' }],
          },
          stats: { pages: 3, types: { concept: 2, source: 1 } },
        });
      }
      if (url === '/api/knowledge/wiki/graph') {
        return jsonResponse({
          nodes: [
            { id: 'concepts/demand-planning', name: '需求计划', type: 'concept' },
            { id: 'concepts/supply-planning', name: '供应计划', type: 'concept' },
            { id: 'sources/source-1', name: '源文档', type: 'source' },
          ],
          edges: [
            { source: 'concepts/demand-planning', target: 'concepts/supply-planning' },
            { source: 'concepts/demand-planning', target: 'sources/source-1' },
          ],
          missing_links: [],
        });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge');
    expect(await screen.findByText('知识图谱')).toBeInTheDocument();

    fireEvent.click(screen.getByText('浏览知识'));

    expect(await screen.findByText('需求计划')).toBeInTheDocument();
  });

  it('uses a plain-language upload dialog and keeps document management separate', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
      const url = String(input);
      if (url === '/api/knowledge/wiki/tree') {
        return jsonResponse({ tree: {}, stats: { pages: 0, types: {} } });
      }
      if (url === '/api/knowledge/wiki/graph') {
        return jsonResponse({ nodes: [], edges: [], missing_links: [] });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge');
    fireEvent.click(screen.getByRole('button', { name: '＋ 上传资料' }));

    expect(await screen.findByText('上传资料', { exact: true })).toBeInTheDocument();
    expect(screen.getByText(/系统会保存你上传的文件并自动读取/)).toBeInTheDocument();
    expect(screen.queryByText('存储链路')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: '管理资料' })).toBeInTheDocument();
    fireEvent.keyDown(window, { key: 'Escape' });
  });

  it('opens detail modal when clicking a graph node', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation((input) => {
      const url = String(input);
      if (url === '/api/knowledge/wiki/tree') {
        return jsonResponse({
          tree: { concept: [{ slug: 'interview-design', path: 'wiki/concepts/interview-design.md', title: '面试设计' }] },
          stats: { pages: 1, types: { concept: 1 } },
        });
      }
      if (url === '/api/knowledge/wiki/graph') {
        return jsonResponse({
          nodes: [{ id: 'concepts/interview-design', name: '面试设计', type: 'concept' }],
          edges: [],
          missing_links: [],
        });
      }
      if (url.includes('/api/knowledge/wiki/page/')) {
        return jsonResponse({
          slug: 'concepts/interview-design',
          frontmatter: { title: '面试设计', type: 'concept', tags: ['结构化面试'], updated: '2026-08-27' },
          body: '# 面试设计\n\n先定义目标。',
          wikilinks: [],
          related: [],
          backlinks: [],
        });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge');
    expect(await screen.findByText('知识图谱')).toBeInTheDocument();
    fireEvent.click(await screen.findByRole('button', { name: /面试设计/ }));
    expect(await screen.findByText('先定义目标。')).toBeInTheDocument();
  });

  it('refreshes an opened page after deleting its source', async () => {
    const pageFetches: string[] = [];
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockImplementation((input, init) => {
      const url = String(input);
      if (url === '/api/knowledge/wiki/tree') {
        return jsonResponse({
          tree: { concept: [{ slug: 'interview-design', path: 'wiki/concepts/interview-design.md', title: '面试设计' }] },
          stats: { pages: 1, types: { concept: 1 } },
          recent_log: '',
        });
      }
      if (url.includes('/api/knowledge/wiki/page/')) {
        pageFetches.push(url);
        return jsonResponse({
          path: 'wiki/concepts/interview-design.md',
          slug: 'concepts/interview-design',
          frontmatter: { title: '面试设计', type: 'concept' },
          body: '# 面试设计\n\n先定义目标。',
          wikilinks: [],
          related: [],
          backlinks: [],
        });
      }
      if (url === '/api/knowledge/wiki/sources') {
        return jsonResponse({
          sources: [{ source_id: 'source-1', filename: '招聘知识.txt', ext: 'txt', status: 'done' }],
        });
      }
      if (init?.method === 'DELETE' && url === '/api/knowledge/wiki/sources/source-1') {
        return jsonResponse({ deleted: true, id: 'source-1', pages_removed: 1 });
      }
      return jsonResponse({}, 404);
    });

    renderPage('/knowledge');
    fireEvent.click(screen.getByText('浏览知识'));
    fireEvent.click(await screen.findByText('面试设计'));
    expect(await screen.findByText('先定义目标。')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '管理资料' }));
    expect(await screen.findByText('招聘知识.txt')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /删\s*除/ }));
    await waitFor(() => expect(screen.getAllByRole('button', { name: /删\s*除/ })).toHaveLength(2));
    const confirmButtons = screen.getAllByRole('button', { name: /删\s*除/ });
    fireEvent.click(confirmButtons[confirmButtons.length - 1]);

    await waitFor(() => expect(fetchMock).toHaveBeenCalledWith('/api/knowledge/wiki/sources/source-1', expect.objectContaining({ method: 'DELETE' })));
    await waitFor(() => expect(pageFetches.length).toBeGreaterThan(1));
  }, 30000);
});
