// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter } from 'react-router-dom';

import { AuthProvider } from '../auth/AuthContext';
import { candidateReportConclusionTone, XiaoPingPage } from './XiaoPingPage';

vi.mock('../../features/talent-pool/components/ResumePreviewModal', () => ({
  ResumePreviewModal: () => null,
}));

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

beforeEach(() => {
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: vi.fn().mockImplementation(() => ({
      matches: false,
      media: '',
      onchange: null,
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })),
  });
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function renderPage() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={['/xiao-ping?pipeline=p1']}>
        <AntdApp>
          <AuthProvider>
            <XiaoPingPage />
          </AuthProvider>
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('XiaoPingPage replay', () => {
  it('uses an error tone for a formal rejection conclusion', () => {
    expect(candidateReportConclusionTone({ is_formal: true, recommendation: '通过' })).toBe('success');
    expect(candidateReportConclusionTone({ is_formal: true, recommendation: '淘汰' })).toBe('error');
    expect(candidateReportConclusionTone({ is_formal: false, recommendation: '评估未完成' })).toBe('warning');
  });

  it('keeps the completion button available and explains why completion is blocked before a report exists', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') return response({ id: 'p1', role: '店长', candidates: [], stages: [] });
      if (path === '/api/assessment-flow/p1/queue') {
        return response({ ready_for_decision: [], incomplete: [], counts: { ready_for_decision: 0, incomplete: 0 } });
      }
      if (path === '/api/assessment-flow/p1/reports') return response({ reports: [], generating_candidate_ids: [] });
      if (path === '/api/mass-interview/p1/ranking') return response({ ranking: [] });
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    const button = await screen.findByRole('button', { name: '完成流水线' });
    expect(button).toBeEnabled();
    fireEvent.click(button);

    expect(await screen.findByText('暂不能完成流水线：请等待所有候选人完成面试，并生成综合评估报告。')).toBeInTheDocument();
    expect(fetchMock.mock.calls.filter(([input]) => String(input) === '/api/pipelines/p1/complete')).toHaveLength(0);
  });

  it('starts aggregate report generation as a background job', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') {
        return response({ id: 'p1', role: '店长', candidates: [{ id: 'c1', name: '张三' }], stages: [] });
      }
      if (path === '/api/assessment-flow/p1/queue') {
        return response({
          ready_for_decision: [{ candidate_id: 'c1', candidate_name: '张三', overall_score: 80 }],
          incomplete: [],
          counts: { ready_for_decision: 1, incomplete: 0 },
        });
      }
      if (path === '/api/assessment-flow/p1/reports') return response({ reports: [], generating_candidate_ids: [] });
      if (path === '/api/assessment-flow/p1/aggregate-report/jobs/latest') return response({ job: null });
      if (path === '/api/assessment-flow/p1/aggregate-report/jobs' && init?.method === 'POST') {
        return response({
          job: { id: 'job-1', pipeline_id: 'p1', status: 'queued', passed_only: true, progress: 5 },
        });
      }
      if (path === '/api/mass-interview/p1/ranking') return response({ ranking: [] });
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '生成综合评估报告' }));

    expect(await screen.findByRole('button', { name: '综合评估报告生成中' })).toBeDisabled();
    expect(
      fetchMock.mock.calls.some(
        ([input, init]) =>
          String(input) === '/api/assessment-flow/p1/aggregate-report/jobs' && init?.method === 'POST',
      ),
    ).toBe(true);
  });

  it('shows the completed state and offers a return to recruitment management', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') {
        return response({ id: 'p1', role: '店长', status: 'completed', candidates: [], stages: [] });
      }
      if (path === '/api/assessment-flow/p1/queue') {
        return response({ ready_for_decision: [], incomplete: [], counts: { ready_for_decision: 0, incomplete: 0 } });
      }
      if (path === '/api/assessment-flow/p1/reports') return response({ reports: [], generating_candidate_ids: [] });
      if (path === '/api/mass-interview/p1/ranking') return response({ ranking: [] });
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByRole('button', { name: '已完成' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '返回首页' })).toBeEnabled();
    expect(screen.queryByRole('button', { name: '返回面试中心' })).not.toBeInTheDocument();
  });

  it('plays only the selected candidate video in the current page', async () => {
    const open = vi.spyOn(window, 'open');
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'shanghai', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') {
        return response({ id: 'p1', role: '店长', candidates: [{ id: 'c1', name: '张三' }], stages: [] });
      }
      if (path === '/api/assessment-flow/p1/queue') {
        return response({
          ready_for_decision: [
            {
              candidate_id: 'c1',
              candidate_name: '张三',
              overall_score: 80,
              step_results: { video: { modality: 'video_interview' } },
            },
          ],
          incomplete: [],
          counts: { ready_for_decision: 1, incomplete: 0 },
        });
      }
      if (path === '/api/assessment-flow/p1/reports') return response({ reports: [], generating_candidate_ids: [] });
      if (path === '/api/mass-interview/p1/ranking') return response({ ranking: [] });
      if (path === '/api/mass-interview/pipeline-for/p1') return response({ pipeline_id: 'p2' });
      if (path === '/api/mass-interview/p2/streams') {
        return response({
          streams: [
            { candidate_id: 'c1', candidate_name: '张三', video_url: '/api/mass-interview/video/p2/c1/full.webm' },
          ],
        });
      }
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '面试回放' }));

    const video = await screen.findByLabelText('面试回放视频');
    expect(video.getAttribute('src')).toBe('/api/mass-interview/video/p2/c1/full.webm');
    expect(open).not.toHaveBeenCalled();
  });

  it('restores offer actions from persisted schedules and candidate status after refresh', async () => {
    const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/auth/me') return response({ username: 'hr1', permissions: ['pipeline:read'] });
      if (path === '/api/pipelines/p1') {
        return response({
          id: 'p1',
          role: '店长',
          candidates: [
            { id: 'c1', name: '张三', status: 'review' },
            { id: 'c2', name: '李四', status: 'offered' },
          ],
          stages: [],
        });
      }
      if (path === '/api/assessment-flow/p1/queue') {
        return response({
          ready_for_decision: [
            { candidate_id: 'c1', candidate_name: '张三', overall_score: 88 },
            { candidate_id: 'c2', candidate_name: '李四', overall_score: 86 },
          ],
          incomplete: [],
          counts: { ready_for_decision: 2, incomplete: 0 },
        });
      }
      if (path === '/api/assessment-flow/p1/reports') return response({ reports: [], generating_candidate_ids: [] });
      if (path === '/api/assessment-flow/p1/aggregate-report/jobs/latest') return response({ job: null });
      if (path === '/api/mass-interview/p1/ranking') return response({ ranking: [] });
      if (path === '/api/mass-interview/p1/schedules') {
        return response({
          pipeline_id: 'p1',
          schedules: [
            { id: 's1', pipeline_id: 'p1', candidate_id: 'c1', date: '2026-09-10', round: '复试', status: 'scheduled' },
            { id: 's2', pipeline_id: 'p1', candidate_id: 'c2', date: '2026-09-10', round: '复试', status: 'scheduled' },
          ],
        });
      }
      return response({});
    });
    vi.stubGlobal('fetch', fetchMock);

    renderPage();

    expect(await screen.findByRole('button', { name: '发送offer' })).toBeEnabled();
    expect(await screen.findByRole('button', { name: 'Offer已发送' })).toBeDisabled();
  }, 10_000);
});
