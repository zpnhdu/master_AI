import { describe, expect, it } from 'vitest';

import type { Pipeline } from '../../features/pipelines/api';
import {
  filterPipelines,
  formatCreatedAt,
  getPipelineId,
  getPipelineProgress,
  getPipelineType,
  getPipelineTypeClass,
  parsePage,
  parsePipelineSort,
  parseStatusFilter,
  sortPipelines,
} from './StudioPage.selectors';

const pipelines: Pipeline[] = [
  {
    id: 'pipeline-b',
    role: '后端工程师',
    type: 'tech',
    status: 'pending',
    created_at: '2026-09-02T00:00:00Z',
  },
  {
    pipeline_id: 'pipeline-a',
    role: '产品经理',
    type: 'product',
    status: 'running',
    created_at: '2026-09-01T00:00:00Z',
  },
  {
    id: 'pipeline-c',
    role: '前端工程师',
    type: 'unknown',
    status: 'completed',
    created_at: '2026-09-01T00:00:00Z',
  },
];

describe('StudioPage selectors', () => {
  it('filters by trimmed case-insensitive role or type and status', () => {
    expect(filterPipelines(pipelines, '  前端  ', '')).toEqual([pipelines[2]]);
    expect(filterPipelines(pipelines, '技术', '')).toEqual([pipelines[0]]);
    expect(filterPipelines(pipelines, '', 'running')).toEqual([pipelines[1]]);
    expect(filterPipelines(pipelines, '', 'done')).toEqual([pipelines[2]]);
    expect(filterPipelines(pipelines, '工程师', 'running')).toEqual([]);
  });

  it('parses supported filters, sort values, and positive pages', () => {
    expect(parseStatusFilter('running')).toBe('running');
    expect(parseStatusFilter('done')).toBe('done');
    expect(parseStatusFilter('pending')).toBe('');
    expect(parsePipelineSort('role_asc')).toBe('role_asc');
    expect(parsePipelineSort('invalid')).toBe('created_desc');
    expect(parsePage('3')).toBe(3);
    expect(parsePage('0')).toBe(1);
    expect(parsePage('-1')).toBe(1);
    expect(parsePage('1.5')).toBe(1);
    expect(parsePage('not-a-number')).toBe(1);
  });

  it('sorts without mutating the input and uses ids as a stable tie breaker', () => {
    const original = [...pipelines];
    expect(sortPipelines(pipelines, 'created_asc').map(getPipelineId)).toEqual([
      'pipeline-a',
      'pipeline-c',
      'pipeline-b',
    ]);
    expect(sortPipelines(pipelines, 'created_desc').map(getPipelineId)).toEqual([
      'pipeline-b',
      'pipeline-a',
      'pipeline-c',
    ]);
    expect(sortPipelines(pipelines, 'role_asc').map((pipeline) => pipeline.role)).toEqual([
      '产品经理',
      '后端工程师',
      '前端工程师',
    ]);
    expect(sortPipelines(pipelines, 'role_desc').map((pipeline) => pipeline.role)).toEqual([
      '前端工程师',
      '后端工程师',
      '产品经理',
    ]);
    expect(pipelines).toEqual(original);
  });

  it('calculates progress and handles pipeline field fallbacks', () => {
    expect(getPipelineProgress({ ...pipelines[2], status: 'completed' })).toBe(100);
    expect(getPipelineProgress({
      id: 'pipeline-running',
      status: 'running',
      agents: ['xiao_wen'],
      stages: [
        { stage_id: 'jd_write', status: 'done' },
        { stage_id: 'profile_build', status: 'done' },
      ],
    })).toBe(100);
    expect(getPipelineProgress({
      id: 'pipeline-partial',
      status: 'running',
      agents: ['xiao_wen', 'not-real'],
      stages: [{ stage_id: 'jd_write', status: 'done' }],
    })).toBe(0);
    expect(getPipelineId({ pipeline_id: 'fallback-id' })).toBe('fallback-id');
    expect(getPipelineType({ pipeline_type: 'tech' })).toBe('技术岗');
    expect(getPipelineType({ type: 'custom' })).toBe('custom');
    expect(getPipelineTypeClass({ pipeline_type: 'tech' })).toBe('tech');
    expect(getPipelineTypeClass({ type: 'custom' })).toBe('default');
  });

  it('formats missing and invalid dates with the creation fallback', () => {
    expect(formatCreatedAt(undefined)).toBe('刚刚创建');
    expect(formatCreatedAt('invalid-date')).toBe('刚刚创建');
    expect(formatCreatedAt('2026-09-02T00:00:00Z')).not.toBe('刚刚创建');
  });
});
