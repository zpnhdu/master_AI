import type { MassInterviewStats, MassRanking } from "../../features/mass-dashboard/api";
import type { AssessmentQueue, CandidateAssessmentReport, AssessmentQueueItem } from "../../features/xiao-ping/api";
import { decisionScore } from "../../features/xiao-ping/selectors";

export const EMPTY_MASS_STATS: MassInterviewStats = {
  total: 0,
  invited: 0,
  started: 0,
  in_progress: 0,
  completed: 0,
  evaluated: 0,
  expired: 0,
  recorded: 0,
};

export const FIVE_ASSESSMENT_DIMENSIONS = ["岗位要点", "专业准确性", "分析逻辑", "方案可执行性", "证据与边界"] as const;

const DIMENSION_ALIASES: Record<string, (typeof FIVE_ASSESSMENT_DIMENSIONS)[number]> = {
  岗位要点: "岗位要点",
  岗位要点匹配: "岗位要点",
  job_coverage: "岗位要点",
  专业准确性: "专业准确性",
  professional_accuracy: "专业准确性",
  分析逻辑: "分析逻辑",
  analytical_logic: "分析逻辑",
  方案可执行性: "方案可执行性",
  solution_feasibility: "方案可执行性",
  证据与边界: "证据与边界",
  evidence_boundaries: "证据与边界",
};

export type MonitorRankingBuckets = {
  completed: MassRanking[];
  answering: MassRanking[];
  opened: MassRanking[];
  invited: MassRanking[];
  expired: MassRanking[];
};

export function filterRankingByDate(ranking: MassRanking[], startDate: string, endDate: string) {
  return ranking.filter((item) => {
    // 有效期是未来时间，不能用它筛选“近七天”的候选人；按实际创建/开始/完成时间筛选。
    const stamp = item.completed_at || item.started_at || item.created_at;
    if (!stamp) return true;
    const day = String(stamp).slice(0, 10);
    return (!startDate || day >= startDate) && (!endDate || day <= endDate);
  });
}

export function summarizeRankingStats(ranking: MassRanking[], buckets?: MonitorRankingBuckets): MassInterviewStats {
  const next: MassInterviewStats = { ...EMPTY_MASS_STATS, total: ranking.length };
  if (buckets) {
    // KPI 与表格筛选共用 splitMonitorRanking 分桶，保证卡片数字 = 筛选后行数。
    next.invited = buckets.invited.length;
    next.started = buckets.opened.length;
    next.in_progress = buckets.answering.length;
    next.completed = buckets.completed.length;
    next.evaluated = 0;
    next.expired = buckets.expired.length;
    for (const candidate of ranking) {
      if (candidate.video_paths?.length) next.recorded += 1;
    }
    return next;
  }
  for (const candidate of ranking) {
    const status = String(candidate.status || "");
    if (status === "invited") next.invited += 1;
    else if (status === "started") next.started += 1;
    else if (status === "in_progress" || status === "streaming") next.in_progress += 1;
    else if (status === "completed") next.completed += 1;
    else if (status === "evaluated") next.evaluated += 1;
    else if (status === "expired") next.expired += 1;
    if (candidate.video_paths?.length) next.recorded += 1;
  }
  return next;
}

export function splitMonitorRanking(ranking: MassRanking[]): MonitorRankingBuckets {
  return {
    completed: ranking.filter((item) => item.assessment_completed || ["completed", "evaluated"].includes(item.status)),
    answering: ranking.filter(
      (item) =>
        !item.assessment_completed &&
        (item.status === "in_progress" || (item.status === "started" && (item.current_question ?? 0) > 0)),
    ),
    opened: ranking.filter(
      (item) => !item.assessment_completed && item.status === "started" && (item.current_question ?? 0) <= 0,
    ),
    invited: ranking.filter((item) => !item.assessment_completed && item.status === "invited"),
    expired: ranking.filter((item) => !item.assessment_completed && item.status === "expired"),
  };
}

export function enrichMassRanking(
  ranking: readonly MassRanking[],
  queue?: Pick<AssessmentQueue, "ready_for_decision" | "incomplete"> | null,
): MassRanking[] {
  const assessments = [...(queue?.ready_for_decision ?? []), ...(queue?.incomplete ?? [])];
  const assessmentByCandidateId = new Map(assessments.map((item) => [item.candidate_id, item]));

  return ranking.map((candidate) => {
    const assessment = assessmentByCandidateId.get(candidate.candidate_id);
    if (!assessment) return candidate;

    // 评估尚未完成时，不能用评估队列里的临时/旧分数覆盖卡片状态。
    if (
      assessment.step_results &&
      !Object.values(assessment.step_results).some((step) => step.scoring_status === "succeeded")
    ) {
      return {
        ...candidate,
        scoring_status: "processing",
        interview_score: undefined,
        total_score: undefined,
        match_score: undefined,
      };
    }

    const score = decisionScore(assessment);
    return {
      ...candidate,
      interview_score: score,
      total_score: score,
      match_score: score,
      recommendation: assessment.recommendation || candidate.recommendation,
    };
  });
}

export function fiveDimensionScores(
  report: CandidateAssessmentReport | undefined,
  assessment: AssessmentQueueItem | undefined,
  candidate: MassRanking,
) {
  const scores = new Map<string, number>();
  const addScores = (value: unknown, overwrite = true) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return;
    for (const [rawName, rawScore] of Object.entries(value as Record<string, unknown>)) {
      const score = typeof rawScore === "number" && Number.isFinite(rawScore) ? rawScore : Number(rawScore);
      if (!Number.isFinite(score)) continue;
      const name = rawName.split(" · ").at(-1)?.trim() ?? rawName.trim();
      const canonicalName = DIMENSION_ALIASES[name];
      if (canonicalName && (overwrite || !scores.has(canonicalName))) scores.set(canonicalName, score);
    }
  };

  addScores(report?.dimensions);
  addScores(
    (report as (CandidateAssessmentReport & { comparison_dimensions?: unknown }) | undefined)?.comparison_dimensions,
  );
  for (const step of Object.values(assessment?.step_results ?? {})) {
    const evidence = step.evidence;
    if (!evidence || typeof evidence !== "object" || Array.isArray(evidence)) continue;
    const evaluation = (evidence as Record<string, unknown>).evaluation;
    if (!evaluation || typeof evaluation !== "object" || Array.isArray(evaluation)) continue;
    const evaluationRecord = evaluation as Record<string, unknown>;
    addScores(evaluationRecord.dimension_scores);
    addScores(evaluationRecord.comparison_dimensions);
  }
  addScores(candidate.dimension_scores, false);

  return FIVE_ASSESSMENT_DIMENSIONS.map((name) => [name, scores.get(name) ?? 0] as [string, number]);
}

export function statusLabel(status: string) {
  return (
    ({
      completed: "已完成",
      evaluated: "已完成",
      in_progress: "答题中",
      started: "已打开",
      invited: "已邀请",
      expired: "已过期",
    }[status] ??
      status) ||
    "已邀请"
  );
}

// 与 KPI 卡片的配色一一对应（竖条/图标同色），保证状态色上下一致。
const STATUS_COLORS: Record<string, string> = {
  invited: "#2563eb",
  started: "#0ea5e9",
  in_progress: "#8b5cf6",
  streaming: "#8b5cf6",
  completed: "#10b981",
  evaluated: "#10b981",
  expired: "#ef4444",
};

export function statusColor(status: string) {
  return STATUS_COLORS[status] ?? "#2563eb";
}

export function hrActionLabel(action: string) {
  return { pass: "录用评估", review: "复试", reject: "已淘汰" }[action] ?? action;
}

export function formatExpiry(value?: string) {
  if (!value) return "无截止时间";
  const date = parseDashboardDate(value);
  return Number.isNaN(date.getTime())
    ? "无截止时间"
    : `截止 ${date.toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" })}`;
}

export function formatDateTime(value?: string) {
  if (!value) return "未知";
  const date = parseDashboardDate(value);
  return Number.isNaN(date.getTime())
    ? "未知"
    : date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Shanghai" });
}

export function parseDashboardDate(value: string) {
  // DB timestamps are local, timezone-less MySQL strings. Replacing the space
  // with `T` keeps parsing deterministic across browsers without shifting the
  // value. ISO timestamps with an explicit timezone continue to work normally.
  const normalized = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/.test(value) ? `${value.replace(" ", "T")}+08:00` : value;
  return new Date(normalized);
}
