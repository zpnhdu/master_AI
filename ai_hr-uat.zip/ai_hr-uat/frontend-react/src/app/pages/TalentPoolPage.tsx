import {
  Alert,
  Button,
  Card,
  Col,
  Empty,
  Form,
  Input,
  InputNumber,
  Modal,
  Popconfirm,
  Row,
  Space,
  Spin,
  Tabs,
  Tag,
  Typography,
  Upload,
  message,
} from 'antd';
import { useEffect, useMemo, useRef, useState } from 'react';

import { PageShell } from '../components/PageShell';
import { ResumePreviewModal, type ResumeDetailCandidate } from '../../features/talent-pool/components/ResumePreviewModal';
import type { EmailSyncRun, TalentResume, UploadResult } from '../../features/talent-pool/api';
import { fetchEmailSyncRuns, talentResumeOriginalUrl } from '../../features/talent-pool/api';
import { ApiError } from '../../features/pipelines/api';
import {
  useAddTalentResumeMutation,
  useDeleteTalentResumeMutation,
  useTalentResumesQuery,
  useTriggerSyncAllEmailAccountsMutation,
  useUploadTalentResumesMutation,
} from '../../features/talent-pool/hooks';
import { DataTable, DataTableAction } from '../../shared/data-table';
import type { DataTableColumn } from '../../shared/data-table';
import { ListSearch } from '../../shared/list-workbench';

const PAGE_SIZE = 10;

function sourceLabel(source?: string) {
  if (!source) return '手动添加';
  if (source.startsWith('file:')) return '文件上传';
  if (source === 'paste') return '文本粘贴';
  if (source === 'manual') return '手动添加';
  if (source.startsWith('email')) return '邮箱同步';
  return source;
}

function sourceColor(source?: string) {
  if (!source || source === 'manual') return 'blue';
  if (source.startsWith('file:')) return 'purple';
  if (source === 'paste') return 'cyan';
  if (source.startsWith('email')) return 'green';
  return 'default';
}

export function TalentPoolPage() {
  return <TalentPoolContent />;
}

function TalentPoolContent() {
  const [searchInput, setSearchInput] = useState('');
  const [query, setQuery] = useState('');
  const [minYears, setMinYears] = useState(0);
  const [minYearsInput, setMinYearsInput] = useState<number | undefined>(undefined);
  const [addOpen, setAddOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);
  const [sortBy, setSortBy] = useState<'name' | 'title' | 'current_company' | 'years_experience' | 'location' | 'created_at' | 'updated_at'>();
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>();
  const [detailResume, setDetailResume] = useState<TalentResume | null>(null);

  const params = useMemo(() => ({ q: query, min_years: minYears, page, page_size: pageSize, sort_by: sortBy, sort_order: sortOrder }), [minYears, query, page, pageSize, sortBy, sortOrder]);
  const resumesQuery = useTalentResumesQuery(params);
  const deleteMutation = useDeleteTalentResumeMutation();
  const syncAllMutation = useTriggerSyncAllEmailAccountsMutation();

  useEffect(() => {
    const timer = window.setTimeout(() => setMinYears(minYearsInput ?? 0), 300);
    return () => window.clearTimeout(timer);
  }, [minYearsInput]);

  useEffect(() => {
    setPage(1);
  }, [query, minYears]);

  const data = resumesQuery.data;
  const linkedCount = (data?.results ?? []).filter((item) => item.linked_resume_id).length;

const tableCardRef = useRef<HTMLDivElement>(null);
  const syncPollStopped = useRef(false);
  useEffect(() => {
    syncPollStopped.current = false;
    return () => {
      syncPollStopped.current = true;
    };
  }, []);
  const [tableScrollY, setTableScrollY] = useState(400);

  useEffect(() => {
    const card = tableCardRef.current;
    if (!card) return;
    const cardBody = card.querySelector<HTMLElement>('.ant-card-body');
    if (!cardBody) return;

    const computeHeight = () => {
      const bodyHeight = cardBody.clientHeight;
      const bodyStyle = window.getComputedStyle(cardBody);
      const paddingTop = parseFloat(bodyStyle.paddingTop) || 0;
      const paddingBottom = parseFloat(bodyStyle.paddingBottom) || 0;
      const contentHeight = bodyHeight - paddingTop - paddingBottom;

      const toolbar = cardBody.querySelector<HTMLElement>('.data-table__toolbar');
      const toolbarStyle = toolbar ? window.getComputedStyle(toolbar) : null;
      const toolbarMT = toolbarStyle ? parseFloat(toolbarStyle.marginTop) || 0 : 0;
      const toolbarMB = toolbarStyle ? parseFloat(toolbarStyle.marginBottom) || 0 : 12;
      const toolbarH = toolbar ? toolbar.offsetHeight + toolbarMT + toolbarMB : 58;

      const thead = cardBody.querySelector<HTMLElement>('.ant-table-thead');
      const headerH = thead ? thead.offsetHeight : 54;

      const pagination = cardBody.querySelector<HTMLElement>('.ant-table-pagination');
      const paginationStyle = pagination ? window.getComputedStyle(pagination) : null;
      const paginationMT = paginationStyle ? parseFloat(paginationStyle.marginTop) || 0 : 0;
      const paginationMB = paginationStyle ? parseFloat(paginationStyle.marginBottom) || 0 : 0;
      const paginationH = pagination ? pagination.offsetHeight + paginationMT + paginationMB : 64;

      const scrollY = contentHeight - toolbarH - headerH - paginationH - 8;
      setTableScrollY(Math.max(200, scrollY));
    };

    computeHeight();
    const observer = new ResizeObserver(computeHeight);
    observer.observe(cardBody);
    return () => observer.disconnect();
  }, []);

  function collectApiMessage(error: unknown, fallback: string) {
    const payload = error instanceof ApiError ? error.data : undefined;
    if (payload && typeof payload === "object") {
      const detail = (payload as Record<string, unknown>).detail;
      if (detail && typeof detail === "object" && typeof (detail as Record<string, unknown>).message === "string") {
        return (detail as Record<string, unknown>).message as string;
      }
    }
    return error instanceof Error && error.message ? error.message : fallback;
  }

  async function handleSyncAll() {
    try {
      const result = await syncAllMutation.mutateAsync();
      message.success(`已触发 ${result.triggered} 个邮箱开始同步`);
      pollSyncRuns(result.run_ids);
    } catch (error) {
      message.error(collectApiMessage(error, "触发邮箱同步失败"));
    }
  }

  function reportSyncRuns(runs: EmailSyncRun[]) {
    const done = runs.filter((run) => run.status !== "queued" && run.status !== "running");
    if (done.length !== runs.length) return false;
    const failed = done.filter((run) => run.status === "failed" || run.status === "partial_success");
    if (!failed.length) {
      message.success(`${done.length} 个邮箱同步完成`);
      return true;
    }
    const lines = failed.map((run) => {
      const label = run.email_address || run.account_name || run.email_account_id;
      const detail = run.error_message || "同步失败";
      return `${label}：${detail}`;
    });
    const okCount = done.length - failed.length;
    message.error({
      content: [okCount > 0 ? `${okCount} 个邮箱同步成功` : null, ...lines].filter(Boolean).join("\n"),
      duration: 10,
    });
    return true;
  }

  function pollSyncRuns(runIds: string[]) {
    if (!runIds.length) return;
    const POLL_INTERVAL = 3000;
    const MAX_WAIT = 120000;
    const deadline = Date.now() + MAX_WAIT;
    const tick = async () => {
      if (Date.now() > deadline || syncPollStopped.current) return;
      try {
        const { items } = await fetchEmailSyncRuns(runIds);
        if (syncPollStopped.current) return;
        if (items.length === runIds.length && reportSyncRuns(items)) return;
      } catch {
        // 轮询失败不打扰用户，下一轮再试
      }
      window.setTimeout(() => void tick(), POLL_INTERVAL);
    };
    void tick();
  }

  async function handleBackfill() {
    try {
      const result = await syncAllMutation.mutateAsync();
      message.success(`已触发 ${result.triggered} 个邮箱开始同步`);
    } catch (error) {
      message.error(collectApiMessage(error, "触发邮箱同步失败"));
    }
  }

  const columns: DataTableColumn<TalentResume>[] = [
    {
      key: 'name',
      role: 'identity',
      title: '姓名',
      dataIndex: 'name',
      render: (name: string, item) => (
        <Space>
          <Typography.Text strong>{name || '未知'}</Typography.Text>
          {(item.fingerprint_confidence ?? 1) < 0.6 ? <Tag color="warning">低置信</Tag> : null}
        </Space>
      ),
    },
    { key: 'gender', title: '性别', dataIndex: 'gender', width: 70, render: (value: string) => value || '—' },
    { key: 'education', title: '学历', dataIndex: 'education', width: 90, render: (value: string) => value || '—' },
    { key: 'title', title: '当前职位', dataIndex: 'title', sorter: true, render: (value: string) => value || '—' },
    { key: 'current_company', title: '公司', dataIndex: 'current_company', sorter: true, render: (value: string) => value || '—' },
    { key: 'phone', title: '手机号', dataIndex: 'phone', width: 130, render: (value: string) => value || '—' },
    { key: 'email', title: '邮箱', dataIndex: 'email', width: 190, render: (value: string) => value || '—' },
    {
      key: 'years_experience',
      title: '经验',
      dataIndex: 'years_experience',
      width: 90,
      render: (value: number) => (value ? `${value} 年` : '—'),
    },
    {
      key: 'skills',
      title: '技能',
      dataIndex: 'skills',
      render: (skills: string[]) => (
        <Space size={4} wrap>
          {(skills ?? []).slice(0, 4).map((skill) => (
            <Tag key={skill} color="blue">
              {skill}
            </Tag>
          ))}
        </Space>
      ),
    },
    { key: 'location', title: '城市', dataIndex: 'location', width: 100, render: (value: string) => value || '—' },
    {
      key: 'source',
      title: '来源',
      dataIndex: 'source',
      width: 110,
      render: (source: string) => <Tag color={sourceColor(source)}>{sourceLabel(source)}</Tag>,
    },
    {
      key: 'actions',
      role: 'actions',
      title: '操作',
      width: 190,
      fixed: 'right' as const,
      render: (_value, item) => (
        <Space size={4}>
          <DataTableAction onClick={() => setDetailResume(item)}>查看</DataTableAction>
          <Button
            size="small"
            type="link"
            href={talentResumeOriginalUrl(item.id, { download: true })}
            target="_blank"
            rel="noreferrer"
          >
            下载附件
          </Button>
          <Popconfirm
            title={`确认删除「${item.name || '未命名'}」？`}
            description="删除后无法恢复"
            okText="删除"
            cancelText="取消"
            okButtonProps={{ danger: true }}
            onConfirm={() => void deleteMutation
              .mutateAsync({ resumeId: item.id })
              .then(() => message.success('已删除'))
              .catch((error: unknown) => message.error(error instanceof Error ? error.message : '删除失败'))}
          >
            <DataTableAction tone="danger">删除</DataTableAction>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
<PageShell
      title="人才库"
      variant="flex"
    >
      <div className="talent-pool-page__panel">
          <div className="talent-pool-page__kpis">
            <Card className="talent-kpi talent-kpi--blue">
              <div className="talent-kpi__label">总简历数</div>
              <div className="talent-kpi__value">{data?.total ?? 0}</div>
            </Card>
            <Card className="talent-kpi talent-kpi--amber">
              <div className="talent-kpi__label">疑似关联</div>
              <div className="talent-kpi__value">{linkedCount}</div>
            </Card>
          </div>

          <Card className="agent-card talent-pool-page__table-card" ref={tableCardRef}>
            {resumesQuery.isPending ? (
              <div className="app-loading"><Spin size="large" tip="加载中" /></div>
            ) : resumesQuery.isError ? (
              <Alert
                type="error"
                showIcon
                message="人才库加载失败"
                description={resumesQuery.error instanceof Error ? resumesQuery.error.message : '请稍后重试'}
                action={
                  <Button size="small" onClick={() => void resumesQuery.refetch()}>
                    重试
                  </Button>
                }
              />
            ) : (
              <DataTable
                tableId="talent-resumes"
                mode="remote"
                rowKey="id"
                scroll={{ x: 'max-content', y: tableScrollY }}
                columns={columns}
                dataSource={data?.results ?? []}
                total={data?.total ?? 0}
                showSearch={false}
                showResultCount={false}
                showColumnSettings
                filters={
                  <>
                    <div className="list-workbench-toolbar-search">
                      <ListSearch
                        value={searchInput}
                        placeholder="搜索姓名 / 技能 / 公司 / 城市"
                        onChange={(value) => setSearchInput(value)}
                        onQueryChange={(value) => {
                          setQuery(value.trim());
                          setPage(1);
                        }}
                      />
                    </div>
                    <InputNumber
                      aria-label="最低工作年限"
                      min={0}
                      max={30}
                      value={minYearsInput}
                      onChange={(value) => setMinYearsInput(value ?? undefined)}
                      addonAfter="年经验以上"
                    />
                    <Space>
                      <Button onClick={() => void handleSyncAll()} loading={syncAllMutation.isPending}>同步邮箱</Button>
                      <Button type="primary" onClick={() => setAddOpen(true)}>＋ 添加简历</Button>
                    </Space>
                  </>
                }
                pagination={{ current: page, pageSize: pageSize, total: data?.total ?? 0, showSizeChanger: true, pageSizeOptions: [10, 20, 50], showTotal: (total) => `共 ${total} 条记录`, onChange: (p, ps) => { setPage(p); setPageSize(ps); } }}
                onChange={(_pagination, _filters, sorter) => {
                  const activeSorter = Array.isArray(sorter) ? sorter[0] : sorter;
                  const field = String(activeSorter?.columnKey ?? activeSorter?.field ?? '');
                  if (field && ['name', 'created_at', 'updated_at'].includes(field)) {
                    setSortBy(field as typeof sortBy);
                    setSortOrder(activeSorter?.order === 'ascend' ? 'asc' : activeSorter?.order === 'descend' ? 'desc' : undefined);
                    setPage(1);
                  } else if (!activeSorter?.order) {
                    setSortBy(undefined);
                    setSortOrder(undefined);
                  }
                }}
                locale={{ emptyText: <Empty description="暂无简历，点击右上角添加" /> }}
              />
            )}
          </Card>
        </div>

      <AddResumeModal open={addOpen} onClose={() => setAddOpen(false)} />
      <ResumePreviewModal
        pipelineId=""
        resumeId={detailResume?.id}
        candidate={detailResume as ResumeDetailCandidate | null}
        onClose={() => setDetailResume(null)}
      />
    </PageShell>
  );
}

function AddResumeModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const addMutation = useAddTalentResumeMutation();
  const uploadMutation = useUploadTalentResumesMutation();
  const [form] = Form.useForm();
  const [files, setFiles] = useState<File[]>([]);
  const [uploadResults, setUploadResults] = useState<UploadResult[]>([]);

  async function submitManual() {
    const values = await form.validateFields();
    try {
      await addMutation.mutateAsync({
        name: values.name,
        title: values.title,
        current_company: values.current_company,
        skills: String(values.skills ?? '')
          .split(/[、,，]/)
          .map((item: string) => item.trim())
          .filter(Boolean),
        years_experience: values.years_experience ?? 0,
        location: values.location,
        resume_text: values.resume_text,
      });
      message.success('简历已添加');
      form.resetFields();
      onClose();
    } catch (error) {
      message.error(error instanceof Error ? error.message : '添加简历失败');
    }
  }

  async function submitUpload() {
    if (!files.length) {
      message.warning('请先选择简历文件');
      return;
    }
    try {
      const result = await uploadMutation.mutateAsync({ files });
      setUploadResults(result.results ?? []);
      const failed = (result.results ?? []).filter((item) => item.skipped).length;
      const created = (result.results ?? []).filter((item) => !item.skipped && !item.duplicate).length;
      if (failed) {
        message.warning(`处理完成：新增 ${created} 份，失败 ${failed} 份`);
      } else {
        message.success(`处理完成，新增 ${created} 份简历`);
        setFiles([]);
        onClose();
      }
    } catch (error) {
      message.error(error instanceof Error ? error.message : '上传失败');
    }
  }

  return (
    <Modal title="添加简历" open={open} onCancel={onClose} footer={null} width={640} destroyOnHidden>
      <Tabs
        items={[
          {
            key: 'upload',
            label: '上传文件',
            children: (
              <>
                <Upload.Dragger
                  multiple
                  accept=".pdf,.docx,.doc,.md,.txt"
                  beforeUpload={(file) => {
                    setFiles((current) => [...current, file]);
                    return false;
                  }}
                  onRemove={(file) => {
                    setFiles((current) => current.filter((item) => item.name !== file.name));
                  }}
                  fileList={files.map((file) => ({ uid: file.name, name: file.name }))}
                >
                  <p>拖拽或点击选择简历文件</p>
                  <Typography.Text type="secondary">支持 PDF / DOCX / DOC / MD / TXT</Typography.Text>
                </Upload.Dragger>
                {uploadResults.length ? (
                  <Alert
                    style={{ marginTop: 12 }}
                    type="info"
                    showIcon
                    message="上传结果"
                    description={
                      <ul style={{ margin: 0, paddingInlineStart: 18 }}>
                        {uploadResults.filter((item) => !item.duplicate).map((item) => (
                          <li key={item.filename}>
                            {item.filename}：{item.skipped ? `跳过（${item.reason ?? '未知原因'}）` : '已入库'}
                          </li>
                        ))}
                      </ul>
                    }
                  />
                ) : null}
                <Space style={{ marginTop: 16 }}>
                  <Button type="primary" onClick={() => void submitUpload()} loading={uploadMutation.isPending}>
                    开始上传
                  </Button>
                  <Button onClick={onClose}>取消</Button>
                </Space>
              </>
            ),
          },
          {
            key: 'manual',
            label: '手动输入',
            children: (
              <Form form={form} layout="vertical">
                <Form.Item name="name" label="姓名" rules={[{ required: true, message: '请填写姓名' }]}>
                  <Input />
                </Form.Item>
                <Row gutter={12}>
                  <Col span={12}>
                    <Form.Item name="title" label="当前职位">
                      <Input />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item name="current_company" label="当前公司">
                      <Input />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item name="skills" label="技能（顿号分隔）">
                      <Input />
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Form.Item name="years_experience" label="工作年限">
                      <InputNumber min={0} max={40} style={{ width: '100%' }} />
                    </Form.Item>
                  </Col>
                  <Col span={6}>
                    <Form.Item name="location" label="城市">
                      <Input />
                    </Form.Item>
                  </Col>
                </Row>
                <Form.Item name="resume_text" label="简历摘要">
                  <Input.TextArea rows={4} />
                </Form.Item>
                <Space>
                  <Button type="primary" onClick={() => void submitManual()} loading={addMutation.isPending}>
                    保存
                  </Button>
                  <Button onClick={onClose}>取消</Button>
                </Space>
              </Form>
            ),
          },
        ]}
      />
    </Modal>
  );
}