import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

import type { Pipeline } from '../../features/pipelines/api';
import { PipelineListItem } from './PipelineListItem';

afterEach(cleanup);

const pipeline: Pipeline = {
  id: 'pipeline-1',
  role: '高级前端工程师',
  type: 'tech',
  status: 'running',
  candidate_count: 6,
  created_at: '2026-09-01T00:00:00Z',
  hr_name: '系统管理员',
  agents: ['xiao_wen', 'xiao_xun'],
  stages: [
    { stage_id: 'jd_write', status: 'done' },
    { stage_id: 'profile_build', status: 'running' },
  ],
};

function renderItem(overrides: Partial<React.ComponentProps<typeof PipelineListItem>> = {}) {
  const props = {
    pipeline,
    onDelete: vi.fn(),
    onOpen: vi.fn(),
    onSelect: vi.fn(),
    selected: false,
    ...overrides,
  };

  return { ...render(<PipelineListItem {...props} />), props };
}

describe('PipelineListItem', () => {
  it('opens from the card and detail link without changing the DOM contract', () => {
    const { props } = renderItem();
    const item = screen.getByRole('listitem', { name: '查看高级前端工程师详情' });

    expect(item.children[0]).toHaveClass('pipeline-list-item__select');
    expect(item.children[1]).toHaveClass('pipeline-list-item__main');
    expect(item.children[2]).toHaveClass('pipeline-list-item__status');
    expect(item.children[3]).toHaveClass('pipeline-list-item__detail-link');
    expect(screen.getByRole('progressbar', { name: '高级前端工程师招聘进度' })).toHaveAttribute(
      'aria-valuenow',
      '0',
    );

    fireEvent.click(item);
    expect(props.onOpen).toHaveBeenCalledWith(pipeline);

    fireEvent.click(screen.getByRole('button', { name: '查看高级前端工程师详情' }));
    expect(props.onOpen).toHaveBeenCalledTimes(2);
    expect(props.onDelete).not.toHaveBeenCalled();
  });

  it('stops delete and checkbox actions from opening the card', () => {
    const { props } = renderItem({ selected: true });

    fireEvent.click(screen.getByRole('button', { name: '删除高级前端工程师' }));
    expect(props.onDelete).toHaveBeenCalledWith(pipeline);
    expect(props.onOpen).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole('checkbox', { name: '选择高级前端工程师' }));
    expect(props.onSelect).toHaveBeenCalledWith(pipeline, false);
    expect(props.onOpen).not.toHaveBeenCalled();
  });

  it('disables actions when the pipeline has no usable id', () => {
    renderItem({ pipeline: { ...pipeline, id: undefined, pipeline_id: undefined } });

    expect(screen.getByRole('checkbox', { name: '选择高级前端工程师' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '查看高级前端工程师详情' })).toBeDisabled();
    expect(screen.getByRole('button', { name: '删除高级前端工程师' })).toBeDisabled();
  });
});
