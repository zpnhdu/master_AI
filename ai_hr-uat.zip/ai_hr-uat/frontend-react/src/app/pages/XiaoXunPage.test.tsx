import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryRouter, useLocation } from 'react-router-dom';

import { XiaoXunPage } from './XiaoXunPage';

vi.mock('../../features/talent-pool/components/ResumePreviewModal', () => ({
  ResumePreviewModal: ({ candidate }: { candidate: { name?: string } | null }) =>
    candidate ? <div>{candidate.name} · 简历详情</div> : null,
}));

const queryClients: QueryClient[] = [];

afterEach(() => {
  cleanup();
  queryClients.splice(0).forEach((queryClient) => queryClient.clear());
  vi.unstubAllGlobals();
});

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function pipelineResponse() {
  return {
    id: 'pipeline-1',
    role: '招商主管',
    agents: ['xiao_wen', 'xiao_xun', 'xiao_shai'],
    stages: [
      { stage_id: 'jd_write', status: 'done', output: {} },
      {
        stage_id: 'crawl',
        status: 'done',
        output: { resume_count: 2, parsed_count: 1, file_upload_count: 1 },
      },
    ],
    candidates: [
      {
        id: 'candidate-1',
        resume_id: 'resume-candidate-1',
        name: '张三',
        source: 'local_import',
        location: '上海',
        years_experience: 5,
      },
    ],
  };
}

function recommendationResponse() {
  return {
    results: [
      {
        id: 'resume-1',
        resume_id: 'resume-1',
        name: '李四',
        source: 'talent_pool',
        relevance_level: 'high',
        location: '上海',
        matched_terms: ['招商主管'],
      },
    ],
    total: 1,
    pool_total: 12,
    pipeline_id: 'pipeline-1',
    reason: '基于岗位条件匹配',
    scope: 'balanced',
    level_counts: { high: 1 },
  };
}

function renderPage(initialEntry = '/xiao-xun?pipeline=pipeline-1') {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  queryClients.push(queryClient);

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <AntdApp>
          <XiaoXunPage />
        </AntdApp>
        <LocationProbe />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

function LocationProbe() {
  const location = useLocation();
  return <output data-testid="location">{location.pathname}{location.search}</output>;
}

function installApiMock() {
  const fetchMock = vi.fn().mockImplementation(async (input: RequestInfo | URL, init?: RequestInit) => {
    const path = String(input);
    if (path === '/api/pipelines/pipeline-1') return response(pipelineResponse());
    if (path === '/api/pipelines/pipeline-1/raw-files') {
      return response({ files: [{ name: '张三.pdf', ext: '.pdf', size_kb: 120 }], count: 1 });
    }
    if (path === '/api/talent-pool/resumes?limit=1') return response({ total: 12 });
    if (path.startsWith('/api/talent-pool/resumes?page=1&page_size=10')) {
      return response({
        total: 12,
        results: [{ id: 'resume-2', name: '王五', title: '餐饮运营总监', current_company: '连锁企业' }],
      });
    }
    if (path === '/api/pipelines/pipeline-1/candidates/candidate-1/resume') {
      return response({
        id: 'resume-candidate-1',
        name: '张三',
        title: '招商主管',
        current_company: '锅圈食汇',
        location: '上海',
        resume_text: '五年招商与渠道管理经验',
        email: 'zhang@example.com',
        original_filename: '张三.pdf',
        storage_backend: 'oss',
        storage_key: 'ai-hr/resume/talent-pool/tenant-default/zhang.pdf',
      });
    }
    if (path.startsWith('/api/talent-pool/recommend/pipeline-1')) {
      if (init?.method === 'POST') return response({ accepted: 1, candidates: [] });
      return response(recommendationResponse());
    }
    if (path === '/api/talent-pool/upload?pipeline_id=pipeline-1') {
      return response({ count: 1, results: [{ id: 'resume-uploaded', filename: '王五.pdf' }] });
    }
    if (path === '/api/pipelines/pipeline-1/pass-artifact') {
      return response({ success: true, from_agent: 'xiao_xun', to_agent: 'xiao_shai', to_name: '小筛' });
    }
    return response({}, 404);
  });
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
}

function installResizeObserverMock() {
  vi.stubGlobal('ResizeObserver', class {
    observe() {}
    unobserve() {}
    disconnect() {}
  });
}

describe('XiaoXunPage', () => {
  beforeEach(() => {
    installResizeObserverMock();
    installApiMock();
  });

  it('shows a Studio return when pipeline is missing', () => {
    renderPage('/xiao-xun');

    expect(screen.getByText('缺少岗位参数')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '返回工作台' })).toHaveAttribute('href', '/studio');
  });

  it('loads the two-pane Xiao Xun workspace', async () => {
    renderPage();

    expect(await screen.findByRole('heading', { name: '招商主管' })).toBeInTheDocument();
    expect(screen.getByText('小寻 · 简历获取')).toBeInTheDocument();
    const currentCandidates = screen.getByRole('complementary', { name: '当前岗位候选人' });
    expect(within(currentCandidates).getByText('张三')).toBeInTheDocument();
    expect(screen.queryByText('处理概况')).not.toBeInTheDocument();
    expect(await screen.findByText('李四')).toBeInTheDocument();
  });

  it('previews a matched resume from the table operation', async () => {
    renderPage();

    const matchingCandidates = await screen.findByRole('region', { name: '人才库匹配' });
    expect(await within(matchingCandidates).findByText('李四')).toBeInTheDocument();
    fireEvent.click(within(matchingCandidates).getByRole('link', { name: '预览简历' }));

    expect(await screen.findByText('李四 · 简历详情')).toBeInTheDocument();
  });

  it('exposes the upload entry and legacy file limits', async () => {
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '上传新简历' }));
    expect(await screen.findByLabelText('上传简历文件')).toBeInTheDocument();
    expect(screen.getByText(/支持 PDF、DOC、DOCX、MD/)).toBeInTheDocument();
    expect(screen.getByText(/最多 50 份/)).toBeInTheDocument();
    expect(screen.getByText(/单个文件不超过 10MB/)).toBeInTheDocument();
  });

  it('uploads a file to the talent pool and adds it to the current pipeline', async () => {
    const fetchMock = installApiMock();
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '上传新简历' }));
    const file = new File(['resume'], '王五.pdf', { type: 'application/pdf' });
    fireEvent.change(await screen.findByLabelText('上传简历文件'), { target: { files: [file] } });
    expect(await screen.findByText('王五.pdf')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: '上传全部' }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/talent-pool/upload?pipeline_id=pipeline-1',
        expect.objectContaining({ method: 'POST' }),
      );
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/talent-pool/recommend/pipeline-1/accept',
        expect.objectContaining({ method: 'POST' }),
      );
    });
    expect(await screen.findByText(/已上传并加入人才库/)).toBeInTheDocument();
    expect(screen.getAllByText('王五.pdf').length).toBeGreaterThan(0);
  });

  it('matches talent-pool candidates, imports selected results, and passes downstream', async () => {
    const fetchMock = installApiMock();
    renderPage();

    expect(await screen.findByText('人才库匹配')).toBeInTheDocument();
    expect(await screen.findByRole('checkbox', { name: /李四/ })).toBeInTheDocument();

    fireEvent.click(screen.getByRole('checkbox', { name: /李四/ }));
    const selectedCandidates = await screen.findByRole('region', { name: '已选择候选人' });
    expect(within(selectedCandidates).getByText('李四')).toBeInTheDocument();
    expect(within(selectedCandidates).getByRole('table')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /批量导入/ }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/talent-pool/recommend/pipeline-1/accept',
        expect.objectContaining({ method: 'POST' }),
      );
    });
    expect(await screen.findByText(/已导入 1 人/)).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '传递给下游' }));
    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/pipelines/pipeline-1/pass-artifact',
        expect.objectContaining({ method: 'POST' }),
      );
    });
    await waitFor(() => {
      expect(screen.getByTestId('location')).toHaveTextContent('/xiao-shai?pipeline=pipeline-1');
    });
  }, 10000);

  it('shows a simple match table with manual talent-pool selection and upload entry', async () => {
    renderPage();

    expect(await screen.findByRole('button', { name: '从人才库添加' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '上传新简历' })).toBeInTheDocument();
    expect(screen.queryByText('召回范围')).not.toBeInTheDocument();
    expect(screen.queryByPlaceholderText('添加技能、行业或经历关键词')).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: '从人才库添加' }));

    expect(await screen.findByText('选择人才库简历')).toBeInTheDocument();
    expect(await screen.findByText('王五')).toBeInTheDocument();
  });

  it('adds a manually selected talent-pool resume to the current pipeline', async () => {
    const fetchMock = installApiMock();
    renderPage();

    fireEvent.click(await screen.findByRole('button', { name: '从人才库添加' }));
    const resumeRow = (await screen.findByText('王五')).closest('tr');
    expect(resumeRow).not.toBeNull();
    fireEvent.click(within(resumeRow as HTMLElement).getByRole('checkbox'));
    fireEvent.click(screen.getByRole('button', { name: /添加到当前岗位/ }));

    await waitFor(() => {
      expect(fetchMock).toHaveBeenCalledWith(
        '/api/talent-pool/recommend/pipeline-1/accept',
        expect.objectContaining({ method: 'POST' }),
      );
    });
    expect(await screen.findByText(/已导入 1 人/)).toBeInTheDocument();
  }, 10000);
});