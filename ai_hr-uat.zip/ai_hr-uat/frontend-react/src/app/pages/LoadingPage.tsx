import { Spin } from 'antd';

export function LoadingPage() {
  return (
    <div className="auth-page auth-page--loading" aria-label="正在加载" aria-busy="true">
      <Spin size="large" description="加载中" />
    </div>
  );
}
