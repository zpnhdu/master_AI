import { cleanup, render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntdApp } from 'antd';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { AuthProvider } from '../auth/AuthContext';
import { StudioPage } from './StudioPage';

afterEach(cleanup);
afterEach(() => vi.unstubAllGlobals());

beforeEach(() => {
  vi.stubGlobal(
    'ResizeObserver',
    class ResizeObserverMock {
      observe() {}

      unobserve() {}

      disconnect() {}
    },
  );
  vi.stubGlobal(
    'fetch',
    vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify([
          {
            id: 'pipeline-1',
            role: '高级前端工程师',
            status: 'running',
            type: 'tech',
            candidate_count: 6,
            created_at: '2026-09-01T00:00:00Z',
            hr_name: '系统管理员',
            agents: ['xiao_wen', 'xiao_xun'],
            stages: [
              { stage_id: 'jd_write', status: 'done' },
              { stage_id: 'profile_build', status: 'running' },
            ],
          },
        ]),
        { status: 200 },
      ),
    ),
  );
});

function renderStudio() {
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });

  return render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={['/studio']}>
        <AntdApp>
          <AuthProvider>
            <StudioPage />
          </AuthProvider>
        </AntdApp>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('StudioPage card layout', () => {
  it('keeps the job card in select, information, progress and action regions', async () => {
    renderStudio();

    expect(await screen.findByText('高级前端工程师')).toBeInTheDocument();
    const card = document.querySelector('.pipeline-list-item');
    const directRegions = [...card!.children].slice(0, 4).map((element) => element.className);

    expect(directRegions).toEqual([
      'pipeline-list-item__select',
      'pipeline-list-item__main',
      'pipeline-list-item__status',
      'pipeline-list-item__detail-link',
    ]);
    expect(card!.querySelector('.pipeline-list-item__meta .pipeline-list-item__type')).toHaveTextContent('技术岗');
    expect(card!.querySelector('.pipeline-list-item__status-head .pipeline-list-item__badge')).toHaveTextContent('进行中');
    expect(card!.querySelector('.pipeline-list-item__status-head')).toHaveTextContent('%');
  });

  it('keeps the four summary cards in one visual system', () => {
    renderStudio();

    const summaryCards = document.querySelectorAll('.studio-page__statistics .studio-statistic');
    expect(summaryCards).toHaveLength(4);
    ['is-blue', 'is-amber', 'is-green', 'is-purple'].forEach((className, index) => {
      expect(summaryCards[index]).toHaveClass(className);
    });
    expect(document.querySelector('.studio-statistic__accent')).not.toBeInTheDocument();
  });
});
