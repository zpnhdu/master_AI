import {
  Alert,
  Button,
  Card,
  Empty,
  Input,
  InputNumber,
  List,
  Modal,
  Progress,
  Select,
  Space,
  Spin,
  Tag,
  Typography,
  message,
} from "antd";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";

import type { AgentCandidate } from "../../features/agent-workbench/api";
import { AgentTopbar } from "../components/AgentTopbar";
import { routePaths } from "../routes/route-paths";
import { ConversationPanel } from "../../features/conversations/ConversationPanel";
import type { ConversationCommand, ConversationLatestData } from "../../features/conversations/api";
import { XiaoMianCommandCard } from "../../features/xiao-mian/XiaoMianCommandCard";
import type {
  InterviewQuestion,
  InterviewReview,
  MassInviteSession,
  WrittenInviteSession,
} from "../../features/xiao-mian/api";
import {
  useConfirmReviewMutation,
  useGenerationTaskQuery,
  useGenerateQuestionsMutation,
  useLaunchMassInterviewMutation,
  useLockQuestionBatchMutation,
  useLaunchWrittenTestMutation,
  useQuestionCountMutation,
  useSaveQuestionsMutation,
  useSendInvitesMutation,
  useWrittenTestStatusQuery,
  useXiaoMianPipelineQuery,
  useXiaoMianReviewQuery,
} from "../../features/xiao-mian/hooks";
import { useMassStatusQuery } from "../../features/mass-dashboard/hooks";
import {
  allInterviewsReviewed,
  isConversationBlockedByDraft,
  isReviewReady,
  normalizeQuestion,
  reviewByCandidate,
  shortlistedCandidates,
} from "../../features/xiao-mian/selectors";
import { xiaoMianKeys } from "../../features/xiao-mian/hooks";
import { usePipelineSocketSync } from "../../shared/usePipelineSocket";
import { getErrorMessage as errorMessage } from "../../shared/errors";
import { useQueryClient } from "@tanstack/react-query";
import { ResumePreviewModal } from "../../features/talent-pool/components/ResumePreviewModal";

function estimateInterviewGenerationSeconds(candidateCount: number, questionCount: number) {
  const workload = Math.max(1, questionCount);
  // Local completed jobs show a much wider LLM latency than the coarse API
  // milestones suggest. Use a conservative 5-12 minute visual window so the
  // bar does not reach its cap while normal generation is still running.
  return Math.min(120, Math.max(10, 16 + workload * 0.6));
}

export function XiaoMianPage() {
  const [searchParams] = useSearchParams();
  const pipelineId = searchParams.get("pipeline") ?? "";
  if (!pipelineId)
    return <AgentStatus type="warning" message="缺少岗位参数" description="请从岗位详情页进入小面工作台。" />;
  return <XiaoMianWorkspace key={pipelineId} pipelineId={pipelineId} />;
}

function AgentStatus({
  type,
  message,
  description,
}: {
  type: "warning" | "error";
  message: string;
  description: string;
}) {
  return (
    <div className="agent-page agent-page--status">
      <Alert
        type={type}
        showIcon
        message={message}
        description={description}
        action={
          <Link to={routePaths.studio}>
            <Button size="small">返回工作室</Button>
          </Link>
        }
      />
    </div>
  );
}

function XiaoMianWorkspace({ pipelineId }: { pipelineId: string }) {
  const navigate = useNavigate();
  const pipelineQuery = useXiaoMianPipelineQuery(pipelineId);
  const reviewQuery = useXiaoMianReviewQuery(pipelineId);
  // 实时链路：出题/审核事件到达后自动刷新（轮询保留作降级）
  usePipelineSocketSync(pipelineId, [xiaoMianKeys.pipeline(pipelineId), xiaoMianKeys.review(pipelineId)]);
  const generateMutation = useGenerateQuestionsMutation(pipelineId);
  const countMutation = useQuestionCountMutation(pipelineId);
  const saveMutation = useSaveQuestionsMutation(pipelineId);
  const confirmMutation = useConfirmReviewMutation(pipelineId);
  const launchMutation = useLaunchMassInterviewMutation(pipelineId);
  const lockQuestionBatchMutation = useLockQuestionBatchMutation(pipelineId);
  const inviteMutation = useSendInvitesMutation(pipelineId);
  const writtenTestMutation = useLaunchWrittenTestMutation(pipelineId);
  const writtenStatusQuery = useWrittenTestStatusQuery(pipelineId);
  const [questionCount, setQuestionCount] = useState<number | null>(5);
  const [selectedCandidateId, setSelectedCandidateId] = useState("");
  const [draftQuestions, setDraftQuestions] = useState<InterviewQuestion[]>([]);
  const [draftQuestionsDirty, setDraftQuestionsDirty] = useState(false);
  const [generationTaskId, setGenerationTaskId] = useState("");
  const [animatedGenerationProgress, setAnimatedGenerationProgress] = useState(0);
  const generationAnimationRef = useRef({
    taskId: "",
    status: "",
    actual: 0,
    visual: 0,
    phaseStartedAt: 0,
    estimateSeconds: 60,
  });
  const generationTerminalTaskRef = useRef("");
  const [expiresHours, setExpiresHours] = useState(48);
  const [interviewMode, setInterviewMode] = useState<"video" | "written">("video");
  const [sendingInviteKey, setSendingInviteKey] = useState<string | null>(null);
  // 小面需要显示已生成但尚未发邮件的链接；面试中心仍使用默认的已发送筛选。
  const massStatusQuery = useMassStatusQuery(pipelineId, "", true);
  const [videoSessions, setVideoSessions] = useState<MassInviteSession[]>([]);
  const [writtenSessions, setWrittenSessions] = useState<WrittenInviteSession[]>([]);
  const [resumeCandidate, setResumeCandidate] = useState<AgentCandidate | null>(null);
  const [chatDraft, setChatDraft] = useState("");
  const [flashArmed, setFlashArmed] = useState(false);
  const [questionFlashTick, setQuestionFlashTick] = useState(0);
  const [conversationActivity, setConversationActivity] = useState({ pendingCount: 0, busy: false });
  const [mobilePane, setMobilePane] = useState<"candidates" | "conversation" | "questions">("conversation");
  const queryClient = useQueryClient();
  const taskQuery = useGenerationTaskQuery(pipelineId, generationTaskId);
  const generationActualProgress = Math.max(0, Math.min(100, Number(taskQuery.data?.progress ?? 0)));
  const generationStatus = taskQuery.data?.status ?? taskQuery.data?.generation_status ?? "queued";
  const generationCandidateCount = Math.max(0, Number(taskQuery.data?.candidate_count ?? 0));
  const generationQuestionCount = Math.max(1, Number(taskQuery.data?.question_count ?? questionCount ?? 5));
  const generationEstimateSeconds = estimateInterviewGenerationSeconds(
    generationCandidateCount,
    generationQuestionCount,
  );
  useEffect(() => {
    const state = generationAnimationRef.current;
    if (!generationTaskId) {
      state.taskId = "";
      state.status = "";
      state.actual = 0;
      state.visual = 0;
      state.phaseStartedAt = 0;
      state.estimateSeconds = 60;
      generationTerminalTaskRef.current = "";
      setAnimatedGenerationProgress(0);
      return;
    }
    if (state.taskId !== generationTaskId) {
      state.taskId = generationTaskId;
      state.status = generationStatus;
      generationTerminalTaskRef.current = "";
      const initialProgress = generationStatus === "done" ? 100 : generationActualProgress;
      const startedAt = performance.now();
      state.actual = initialProgress;
      state.visual = initialProgress;
      state.phaseStartedAt = startedAt;
      state.estimateSeconds = generationEstimateSeconds;
      setAnimatedGenerationProgress(initialProgress);
      return;
    }
    // Poll responses can arrive out of order. Keep the visual target
    // monotonic while the task is running, then accept the terminal value.
    const previousStatus = state.status;
    const previousActual = state.actual;
    const nextActual = generationStatus === "done"
      ? 100
      : generationStatus === "failed"
        ? generationActualProgress
        : Math.max(state.actual, generationActualProgress);
    state.status = generationStatus;
    state.actual = nextActual;
    state.estimateSeconds = generationEstimateSeconds;
    if (previousStatus !== generationStatus || previousActual !== nextActual) {
      state.phaseStartedAt = performance.now();
    }
  }, [generationActualProgress, generationEstimateSeconds, generationStatus, generationTaskId]);
  useEffect(() => {
    if (!generationTaskId) return;
    let frame = 0;
    let lastPaintAt = 0;
    let previousTimestamp = 0;
    const useAnimationFrame =
      typeof window.requestAnimationFrame === "function" && typeof window.cancelAnimationFrame === "function";
    const scheduleFrame = (callback: FrameRequestCallback) =>
      useAnimationFrame
        ? window.requestAnimationFrame(callback)
        : window.setTimeout(() => callback(performance.now()), 80);
    const cancelFrame = (frameId: number) => {
      if (useAnimationFrame) window.cancelAnimationFrame(frameId);
      else window.clearTimeout(frameId);
    };
    const tick = (timestamp: number) => {
      const state = generationAnimationRef.current;
      const terminal = state.status === "done" || state.status === "failed";
      const elapsedSeconds = state.phaseStartedAt ? Math.max(0, (timestamp - state.phaseStartedAt) / 1000) : 0;
      const frameDelta = previousTimestamp ? Math.min(250, timestamp - previousTimestamp) : 16;
      previousTimestamp = timestamp;
      // The API exposes coarse milestones (0/5/10/100). Ease through each
      // phase independently, using workload to estimate the one-shot LLM
      // phase. A long-running task settles near 92% until the server finishes.
      const phaseDurationSeconds = state.actual >= 10 ? state.estimateSeconds : state.actual >= 5 ? 8 : 3;
      const phaseRatio = Math.min(0.97, elapsedSeconds / phaseDurationSeconds);
      const easedPhaseRatio = 1 - (1 - phaseRatio) ** 2;
      const target = state.actual >= 10
        ? Math.max(state.actual, Math.min(92, state.actual + (92 - state.actual) * easedPhaseRatio))
        : state.actual >= 5
          ? Math.min(9, state.actual + (9 - state.actual) * easedPhaseRatio)
          : Math.min(4, state.actual + (4 - state.actual) * easedPhaseRatio);
      const smoothing = 1 - Math.exp(-frameDelta / 180);
      state.visual = terminal ? state.actual : state.visual + (target - state.visual) * smoothing;
      if (terminal || timestamp - lastPaintAt >= 80) {
        setAnimatedGenerationProgress(state.visual);
        lastPaintAt = timestamp;
      }
      if (!terminal) frame = scheduleFrame(tick);
    };
    frame = scheduleFrame(tick);
    return () => cancelFrame(frame);
  }, [generationTaskId]);
  const pipeline = pipelineQuery.data;
  const reviewState = reviewQuery.data ?? { interviews: [], generated_count: questionCount ?? 5 };
  const candidates = pipeline ? shortlistedCandidates(pipeline) : [];
  const reviewMap = useMemo(() => {
    const map = reviewByCandidate(reviewState);
    // Written-test attempts are stored separately from video sessions. Merge
    // their live status into the review model so the candidate card, editor,
    // and conversation composer all apply the same lock behavior.
    for (const session of writtenSessions) {
      const candidateId = String(session.candidate_id || "");
      if (!candidateId) continue;
      const status = String(session.status || "").toLowerCase();
      const started = Boolean(session.started_at);
      const lockedStatuses = ["in_progress", "started", "answering", "active", "completed", "evaluated", "submitted", "expired"];
      if (!started && !lockedStatuses.includes(status)) continue;
      const review = map.get(candidateId);
      if (!review) continue;
      map.set(candidateId, {
        ...review,
        question_edit_locked: true,
        question_edit_lock_status: status || "in_progress",
        interview_status: status || "in_progress",
      });
    }
    return map;
  }, [reviewState, writtenSessions]);
  const missingQuestionCount = useMemo(
    () => candidates.filter((candidate) => !(reviewMap.get(candidate.id)?.questions?.length)).length,
    [candidates, reviewMap],
  );
  const selectedReview = selectedCandidateId ? reviewMap.get(selectedCandidateId) : undefined;
  const selectedCandidateName =
    candidates.find((candidate) => candidate.id === selectedCandidateId)?.name || "未选择候选人";
  const allReviewed = allInterviewsReviewed(
    reviewState,
    candidates.map((candidate) => candidate.id),
  );
  const generationBusy = generateMutation.isPending || countMutation.isPending || taskQuery.isFetching;
  // Existing invite links must remain visible, while newly added candidates
  // can still be submitted later. Only lock controls during the request.
  const submissionLocked = launchMutation.isPending || writtenTestMutation.isPending;
  const isQuestionCountValid =
    typeof questionCount === "number" && Number.isInteger(questionCount) && questionCount >= 1 && questionCount <= 20;

  useEffect(() => {
    if (massStatusQuery.data?.sessions) {
      setVideoSessions(massStatusQuery.data.sessions as MassInviteSession[]);
    }
    if (writtenStatusQuery.data?.sessions) {
      setWrittenSessions(writtenStatusQuery.data.sessions as unknown as WrittenInviteSession[]);
    }
  }, [massStatusQuery.data, writtenStatusQuery.data]);

  // 面试方式按流水线锁定：首批生成哪一种链接，后续批次只能沿用该方式。
  const establishedMode: "video" | "written" | "" = writtenSessions.length
    ? "written"
    : videoSessions.length
      ? "video"
      : "";
  useEffect(() => {
    if (establishedMode) setInterviewMode(establishedMode);
  }, [establishedMode]);

  // 首次拿到后端 generated_count 时回填题数输入框，避免本地默认值与实际不符。
  const countInitializedRef = useRef(false);
  useEffect(() => {
    const count = reviewQuery.data?.generated_count;
    if (countInitializedRef.current || !count) return;
    countInitializedRef.current = true;
    setQuestionCount(count);
  }, [reviewQuery.data]);

  useEffect(() => {
    if (!selectedCandidateId && candidates.length) setSelectedCandidateId(candidates[0].id);
  }, [candidates, selectedCandidateId]);
  useEffect(() => {
    if (selectedReview) {
      setDraftQuestions(selectedReview.questions.map((question) => normalizeQuestion(question)));
      setDraftQuestionsDirty(false);
    } else if (selectedCandidateId) {
      setDraftQuestions([]);
      setDraftQuestionsDirty(false);
    }
  }, [selectedCandidateId, selectedReview]);
  useEffect(() => {
    const taskStatus = generationStatus;
    if (!generationTaskId || generationTerminalTaskRef.current === generationTaskId) return;
    if (taskStatus === "done") {
      generationTerminalTaskRef.current = generationTaskId;
      message.success("面试题生成完成，请进入审核。");
      const completedTaskId = generationTaskId;
      window.setTimeout(() => {
        setGenerationTaskId((currentTaskId) => (currentTaskId === completedTaskId ? "" : currentTaskId));
      }, 600);
      // 生成完成后自动定位到第一位待审核候选人，减少手动切换。
      void reviewQuery.refetch().then((result) => {
        const byCandidate = reviewByCandidate(result.data ?? reviewState);
        const next = candidates.find((candidate) => !isReviewReady(byCandidate.get(candidate.id)));
        if (next) setSelectedCandidateId(next.id);
      });
    }
    if (taskStatus === "failed") message.error(taskQuery.data?.error || "面试题生成失败");
  }, [generationStatus, generationTaskId, message, reviewQuery, taskQuery.data]);

  useEffect(() => {
    if (generationStatus !== "failed" || !generationTaskId) return;
    if (generationTerminalTaskRef.current === generationTaskId) return;
    generationTerminalTaskRef.current = generationTaskId;
    const failedTaskId = generationTaskId;
    window.setTimeout(() => {
      setGenerationTaskId((currentTaskId) => (currentTaskId === failedTaskId ? "" : currentTaskId));
    }, 600);
  }, [generationStatus, generationTaskId]);

  // 对话命令执行后刷新数据 → 题目编辑区闪烁高亮，提示“改的是哪一题”。
  useEffect(() => {
    if (!flashArmed || !selectedReview) return;
    setQuestionFlashTick((tick) => tick + 1);
    setFlashArmed(false);
  }, [flashArmed, selectedReview]);

  if (pipelineQuery.isPending)
    return (
      <div className="agent-page agent-page--status">
        <div className="app-loading">
          <Spin size="large" />
        </div>
      </div>
    );
  if (pipelineQuery.isError || !pipeline)
    return <AgentStatus type="error" message="小面工作台加载失败" description={errorMessage(pipelineQuery.error)} />;

  async function generate(candidateId?: string) {
    try {
      const result = await generateMutation.mutateAsync(candidateId);
      const taskId = result.generation_job_id || result.id;
      if (result.status === "error") throw new Error(result.message || "面试题生成失败");
      if (taskId) setGenerationTaskId(taskId);
      else {
        await reviewQuery.refetch();
        const resultMessage = result.message || "面试题已生成，请进入审核。";
        if (resultMessage.includes("请先") || resultMessage.includes("没有入围")) message.error(resultMessage);
        else message.success(resultMessage);
      }
    } catch (error) {
      message.error(error instanceof Error ? error.message : "面试题生成失败");
    }
  }

  async function generateBatch() {
    if (questionCount === null) return;
    try {
      await countMutation.mutateAsync(questionCount);
      await generate();
    } catch (error) {
      message.error(errorMessage(error, "面试题生成失败"));
    }
  }

  async function saveCurrentQuestions() {
    if (!selectedCandidateId) return;
    try {
      await saveMutation.mutateAsync({ candidateId: selectedCandidateId, questions: draftQuestions });
      setDraftQuestionsDirty(false);
      await confirmMutation.mutateAsync([selectedCandidateId]);
      const refreshed = await reviewQuery.refetch();
      // 审核通过后自动跳到下一位待审核候选人，形成连续审核流。
      const byCandidate = reviewByCandidate(refreshed.data ?? reviewState);
      const next = candidates.find(
        (candidate) => candidate.id !== selectedCandidateId && !isReviewReady(byCandidate.get(candidate.id)),
      );
      if (next) {
        setSelectedCandidateId(next.id);
        message.success("题目修改已保存");
      } else {
        message.success("题目修改已保存");
      }
    } catch (error) {
      const text = errorMessage(error, "题目审核失败");
      if (text.includes("不能") || text.includes("不允许") || text.includes("已开始") || text.includes("答题")) {
        Modal.warning({ title: "无法修改面试题", content: text });
      } else message.error(text);
    }
  }

  async function launchInterview() {
    try {
      const result = await launchMutation.mutateAsync({
        expiresHours,
        candidateIds: candidates.map((candidate) => candidate.id),
      });
      const sessions = result.sessions ?? [];
      setVideoSessions(sessions);
      void massStatusQuery.refetch();
      const createdCount = result.total ?? 0;
      const skippedCount = result.skipped ?? 0;
      if (result.status === "existing" || (createdCount === 0 && skippedCount > 0)) {
        message.warning(`所有候选人已有面试链接，已加载 ${sessions.length || skippedCount} 条现有链接`);
      } else if (skippedCount > 0) {
        message.success(`已为 ${createdCount} 位候选人创建面试链接，有效期 ${expiresHours} 小时，${skippedCount} 人已有链接已跳过`);
      } else {
        message.success(`已为 ${createdCount} 位候选人创建面试链接，有效期 ${expiresHours} 小时`);
      }
    } catch (error) {
      message.error(errorMessage(error, "发起视频面试失败"));
    }
  }

  async function launchWrittenTestForCandidates() {
    try {
      const result = await writtenTestMutation.mutateAsync({
        candidateIds: candidates.map((candidate) => candidate.id),
        expiresHours,
      });
      const launched = result.sessions ?? [];
      // The API returns only newly-created sessions when some candidates
      // already have valid links. Keep those existing links visible instead
      // of replacing the list with the partial response.
      setWrittenSessions((current) => {
        const byCandidate = new Map(current.map((session) => [String(session.candidate_id), session]));
        for (const session of launched) byCandidate.set(String(session.candidate_id), session);
        return Array.from(byCandidate.values());
      });
      void writtenStatusQuery.refetch();
      if (launched.length) {
        message.success(`笔试链接已生成，共 ${launched.length} 位候选人，有效期 ${expiresHours} 小时`);
      }
      else message.warning("没有生成笔试链接，请确认候选人已有审核通过的题目");
    } catch (error) {
      message.error(errorMessage(error, "在线笔试发起失败"));
    }
  }

  async function sendInvites(tokens: string[], key: string, successMessage: string) {
    if (!tokens.length || sendingInviteKey) return;
    setSendingInviteKey(key);
    try {
      await inviteMutation.mutateAsync(tokens);
      await Promise.allSettled([massStatusQuery.refetch(), writtenStatusQuery.refetch()]);
      message.success(successMessage);
    } catch {
      // 邮件 mutation 的全局错误处理器已展示后端返回的具体原因，避免重复弹窗。
    } finally {
      setSendingInviteKey(null);
    }
  }

  /** 会话 latest_data 携带面试题/排期资源时刷新审核数据（对齐旧版 onConversationLatestData）。 */
  function handleConversationLatestData(data: ConversationLatestData) {
    const keys = (data.resources ?? []).map((resource) => resource.key);
    if (keys.some((key) => key === "interview_questions" || key === "interview_schedules")) {
      void queryClient.invalidateQueries({ queryKey: xiaoMianKeys.review(pipelineId) });
      void queryClient.invalidateQueries({ queryKey: xiaoMianKeys.pipeline(pipelineId) });
    }
  }

  function handleSelectCandidate(candidateId: string, nextPane: "conversation" | "questions" = "questions") {
    if (conversationActivity.pendingCount || conversationActivity.busy) {
      message.warning("请先完成当前对话操作");
      return;
    }
    if (draftQuestionsDirty) {
      message.warning("请先保存当前题目修改");
      setMobilePane("questions");
      return;
    }
    setSelectedCandidateId(candidateId);
    setMobilePane(nextPane);
  }

  function handleDraftQuestionsChange(nextQuestions: InterviewQuestion[]) {
    setDraftQuestions(nextQuestions);
    setDraftQuestionsDirty(true);
  }

  function handleConversationUpdated(
    command: ConversationCommand,
    action: "confirm" | "cancel" | "repreview" | "undo",
  ) {
    if (action !== "confirm") return;
    const candidateId = typeof command.preview?.candidate_id === "string" ? command.preview.candidate_id : "";
    if (!candidateId) return;
    setSelectedCandidateId(candidateId);
    setMobilePane("questions");
    // 改题只影响当前候选人的面试题；确认后刷新 review 即可，避免再次拉取整条 pipeline。
    void reviewQuery.refetch();
    setFlashArmed(true);
  }

function renderWorkflowActions() {
    return (
      <div className="xiao-mian-conversation-actions">
        <Card size="small" className="agent-card xiao-mian-next-step-card">
          <Space wrap className="agent-card__actions xiao-mian-next-step-actions">
            <Select
              value={expiresHours}
              disabled={submissionLocked}
              onChange={setExpiresHours}
              options={[24, 48, 72].map((value) => ({ value, label: `${value} 小时有效` }))}
            />
            <Select
              value={interviewMode}
              disabled={submissionLocked || Boolean(establishedMode)}
              onChange={setInterviewMode}
              options={[
                { value: "video", label: "视频面试" },
                { value: "written", label: "在线笔试" },
              ]}
            />
            <Button
              type="primary"
              disabled={!allReviewed || submissionLocked || launchMutation.isPending || writtenTestMutation.isPending}
              loading={launchMutation.isPending || writtenTestMutation.isPending}
              onClick={() => void (interviewMode === "video" ? launchInterview() : launchWrittenTestForCandidates())}
            >
              提交
            </Button>
          </Space>
          {interviewMode === "video" && videoSessions.length ? (
            <List
              className="invite-list"
              header={
                <div className="invite-list__header">
                  <Typography.Text strong>视频面试邀请</Typography.Text>
                  <Button
                    size="small"
                    loading={sendingInviteKey === "video-all"}
                    disabled={Boolean(sendingInviteKey)}
                    onClick={() => void sendInvites(
                      videoSessions.map((session) => session.token ?? "").filter(Boolean),
                      "video-all",
                      "邀请邮件已全部发送",
                    )}
                  >
                    全部发送邮件
                  </Button>
                </div>
              }
              dataSource={videoSessions}
              renderItem={(session) => (
                <List.Item
                  actions={[
                    <Button
                      key="copy"
                      size="small"
                      onClick={() =>
                        void copyText(absoluteInviteUrl(session.invite_url || `/mass-interview/${session.token || ''}`))
                      }
                    >
                      复制链接
                    </Button>,
                    <Button
                      key="mail"
                      size="small"
                      loading={sendingInviteKey === `video:${session.token}`}
                      disabled={!session.token || Boolean(sendingInviteKey)}
                      onClick={() => session.token && void sendInvites([session.token], `video:${session.token}`, "邀请邮件已发送")}
                    >
                      {session.invite_sent_at ? "再次发送" : "发送邮件"}
                    </Button>,
                  ]}
                >
                  <List.Item.Meta
                    title={
                      <Space size={6}>
                        <span>{String(session.candidate_name ?? "候选人")}</span>
                        {session.invite_sent_at ? (
                          <Tag className="invite-list__sent-tag" color="green">
                            已发送
                          </Tag>
                        ) : null}
                      </Space>
                    }
                  />
                </List.Item>
              )}
            />
          ) : null}
          {interviewMode === "written" && writtenSessions.length ? (
            <List
              className="invite-list invite-list--written"
              header={
                <div className="invite-list__header">
                  <Typography.Text strong>在线笔试邀请</Typography.Text>
                  <Space wrap>
                    <Button
                      size="small"
                      loading={sendingInviteKey === "written-all"}
                      disabled={Boolean(sendingInviteKey)}
                      onClick={() => void sendInvites(
                        writtenSessions.map((session) => session.token ?? "").filter(Boolean),
                        "written-all",
                        "笔试邀请邮件已全部发送",
                      )}
                    >
                      全部发送邮件
                    </Button>
                  </Space>
                </div>
              }
              dataSource={writtenSessions}
              renderItem={(session) => (
                <List.Item
                  actions={[
                    <Button
                      key="copy"
                      size="small"
                      onClick={() =>
                        void copyText(
                          absoluteInviteUrl(session.invite_url || (session.token ? `/written-test/${session.token}` : "")),
                        )
                      }
                    >
                      复制链接
                    </Button>,
                    <Button
                      key="email"
                      size="small"
                      loading={sendingInviteKey === `written:${session.token}`}
                      disabled={!session.token || Boolean(sendingInviteKey)}
                      onClick={() => session.token && void sendInvites([session.token], `written:${session.token}`, "笔试邀请邮件已发送")}
                    >
                      {session.invite_sent_at ? "再次发送" : "发送邮件"}
                    </Button>,
                  ]}
                >
                  <List.Item.Meta
                    title={
                      <Space size={6}>
                        <span>{session.candidate_name || "候选人"}</span>
                        {session.invite_sent_at ? (
                          <Tag className="invite-list__sent-tag" color="green">
                            已发送
                          </Tag>
                        ) : null}
                      </Space>
                    }
                  />
                </List.Item>
              )}
            />
          ) : null}
        </Card>
      </div>
    );
  }

  return (
    <div
      className="agent-page xun-app agent-page--interview"
      style={{ display: "flex", flexDirection: "column", padding: 0, height: "100vh", overflow: "hidden" }}
    >
      <AgentTopbar
        pipelineId={pipelineId}
        mark="面"
        title={pipeline.role}
        subtitle="小面 · 面试出题"
        status={allReviewed ? { label: "题目已生成", tone: "ok" } : { label: "题目未生成" }}
        primaryAction={{
          label: "进入面试中心",
          onClick: () => {
            Modal.confirm({
              title: "确认进入面试中心",
              content: "请确认题目已完成修改，后续将进入面试中心发送面试链接。",
              okText: "确认进入",
              cancelText: "继续修改",
              onOk: async () => {
                try {
                  await lockQuestionBatchMutation.mutateAsync(candidates.map((candidate) => candidate.id));
                  // 小面与面试中心使用同一条流水线，必须原样传递稳定的 pipeline_id，
                  // 禁止按候选人姓名映射到其他历史流水线。
                  navigate(routePaths.massDashboard(pipelineId));
                } catch (error) {
                  message.error(errorMessage(error, "进入面试中心失败，题目暂未锁定"));
                }
              },
            });
          },
          loading: pipelineQuery.isFetching || lockQuestionBatchMutation.isPending,
          title: pipelineQuery.data ? '进入当前岗位对应的面试中心' : '进入当前岗位的面试中心',
        }}
      />
      <nav className="xiao-mian-mobile-tabs" aria-label="小面工作区切换">
        {(
          [
            ["candidates", "候选人"],
            ["conversation", "对话"],
            ["questions", "题目"],
          ] as const
        ).map(([key, label]) => (
          <button
            className={mobilePane === key ? "active" : ""}
            type="button"
            key={key}
            onClick={() => setMobilePane(key)}
          >
            {label}
            {key === "questions" && draftQuestionsDirty ? <span className="xiao-mian-tab-dot" /> : null}
          </button>
        ))}
      </nav>
      <main className="xun-workspace xiao-mian-workspace" data-mobile-pane={mobilePane}>
        <aside className="xiao-mian-candidate-pane" aria-label="候选人列表" role="region">
          <Card size="small" title="出题任务" className="xiao-mian-generation-card">
            <div className="xiao-mian-generation-field">
              <Typography.Text type="secondary">每位候选人题目数</Typography.Text>
              <InputNumber
                min={1}
                max={20}
                value={questionCount}
                onChange={(value) => setQuestionCount(typeof value === "number" ? value : null)}
                aria-label="每位候选人题目数"
              />
            </div>
            <Button
              block
              type="primary"
              loading={generationBusy}
              disabled={!candidates.length || generationBusy || !isQuestionCountValid}
              title={candidates.length ? "为全部入围候选人生成面试题" : "请先在小筛确认入围名单"}
              onClick={() => void generateBatch()}
            >
              批量生成面试题
            </Button>
            {generationTaskId ? (
              <div className="agent-generation-progress">
                <Typography.Text>{taskQuery.data?.message || "面试题生成中…"}</Typography.Text>
                <Progress
                  className={
                    generationStatus === "done" || generationStatus === "failed"
                      ? "agent-generation-progress__bar"
                      : "agent-generation-progress__bar agent-generation-progress__bar--active"
                  }
                  percent={animatedGenerationProgress}
                  status={
                    generationStatus === "failed"
                      ? "exception"
                      : generationStatus === "done"
                        ? "success"
                        : "active"
                  }
                  format={(value) => `${Math.round(value ?? 0)}%`}
                />
              </div>
            ) : null}
          </Card>
          <section className="xiao-mian-candidate-section">
            <div className="xiao-mian-pane-heading">
              <div>
                <Typography.Text strong>候选人</Typography.Text>
                <Typography.Text type="secondary">
                  {candidates.length} 位入围{missingQuestionCount ? `（${missingQuestionCount} 人未生成题目）` : ""}
                </Typography.Text>
              </div>
              <Tag>{conversationActivity.pendingCount ? "操作处理中" : "可切换"}</Tag>
            </div>
            <CandidateList
              candidates={candidates}
              reviewMap={reviewMap}
              selectedId={selectedCandidateId}
              disabled={Boolean(conversationActivity.pendingCount || conversationActivity.busy || draftQuestionsDirty)}
              onSelect={handleSelectCandidate}
              onPreview={setResumeCandidate}
            />
          </section>
        </aside>
        <section className="xiao-mian-conversation-pane" aria-label="与小面对话">
          <div className="xiao-mian-pane-heading xiao-mian-pane-heading--conversation">
            <div>
              <Typography.Text strong>与小面对话</Typography.Text>
              <Typography.Text type="secondary">先预览，再确认执行</Typography.Text>
            </div>
            <Space size={6} wrap className="xiao-mian-conversation-header-actions">
              {conversationActivity.pendingCount ? (
                <Tag color="orange">{conversationActivity.pendingCount} 项待处理</Tag>
              ) : null}
            </Space>
          </div>
          <ConversationPanel
            pipelineId={pipelineId}
            agentId="xiao_mian"
            avatar="面"
            placeholder="例如：把当前候选人的第2题改难；或安排明天14:00线上面试"
            emptyContent={
              <div className="convo-panel__welcome">
                <Typography.Title level={4}>一起完善面试题</Typography.Title>
                <Typography.Paragraph>
                  围绕「{pipeline.role}
                  」的岗位要求，用自然语言告诉小面要修改什么。每次操作都会先生成预览，确认后才会执行。
                </Typography.Paragraph>
              </div>
            }
            conversationCard={renderWorkflowActions()}
            quickPrompts={[
              { label: "提升当前题目区分度", value: "提升当前候选人面试题的区分度，保留岗位重点" },
              { label: "增加一道业务场景题", value: "给当前候选人增加一道业务场景题" },
              { label: "让题目更有挑战", value: "把当前候选人的面试题整体提高一个难度等级" },
            ]}
            sendButtonText="↑"
            supportVoice
            draft={chatDraft}
            onDraftChange={setChatDraft}
            onLatestData={handleConversationLatestData}
            contextCandidateId={selectedCandidateId}
            senderName={selectedCandidateName}
            candidateNames={Object.fromEntries(candidates.map((candidate) => [candidate.id, candidate.name || "未知候选人"]))}
            composerDisabled={Boolean(selectedReview?.question_edit_locked)}
            beforeSend={() => {
              if (selectedReview?.question_edit_locked) {
                Modal.warning({
                  title: "无法修改面试题",
                  content: ["started", "in_progress", "answering", "active"].includes(
                    typeof selectedReview.question_edit_lock_status === "string" ? selectedReview.question_edit_lock_status : "",
                  )
                    ? "该候选人正在答题，不能通过对话修改面试题。"
                    : "该候选人的面试已结束，不能修改面试题。",
                });
                return false;
              }
              const blocked = isConversationBlockedByDraft({
                hasUnsavedDraft: draftQuestionsDirty,
                targetsCurrentQuestions: true,
              });
              if (blocked) {
                message.warning("请先保存当前题目修改，再发起对话操作");
                setMobilePane("questions");
                return false;
              }
              return true;
            }}
            onActivityChange={setConversationActivity}
            onCommandUpdated={handleConversationUpdated}
            renderCommand={(command, actions) => (
              <XiaoMianCommandCard
                command={command}
                actions={actions}
                onRefreshData={() => {
                  void reviewQuery.refetch();
                  void pipelineQuery.refetch();
                  setFlashArmed(true);
                }}
                disabled={Boolean(selectedReview?.question_edit_locked)}
              />
            )}
          />
        </section>
        <aside className="xiao-mian-question-pane" aria-label="当前候选人题目" role="region">
          <div className="xiao-mian-question-header">
            <div>
              <Typography.Text strong>题目修改</Typography.Text>
              <Typography.Text type="secondary">
                {selectedCandidateName} · {selectedReview?.questions?.length ?? 0} 道题
              </Typography.Text>
            </div>
            <div className="xiao-mian-conversation-candidate-picker">
              <Typography.Text type="secondary">当前候选人</Typography.Text>
              <Select
                className="xiao-mian-conversation-candidate-select"
                size="small"
                value={selectedCandidateId || undefined}
                placeholder="选择候选人"
                disabled={Boolean(
                  conversationActivity.pendingCount || conversationActivity.busy || draftQuestionsDirty,
                )}
                onChange={(candidateId) => handleSelectCandidate(candidateId, "questions")}
                options={candidates.map((candidate) => ({
                  value: candidate.id,
                  label: candidate.name || "未知候选人",
                }))}
              />
            </div>
          </div>
          <div className="xiao-mian-question-scroll">
            <QuestionEditor
              questions={draftQuestions}
              onChange={handleDraftQuestionsChange}
              onSaveReviewed={() => void saveCurrentQuestions()}
              locked={Boolean(selectedReview?.question_edit_locked)}
              lockReason={typeof selectedReview?.question_edit_lock_status === "string" ? selectedReview.question_edit_lock_status : undefined}
              busy={
                saveMutation.isPending ||
                confirmMutation.isPending ||
                Boolean(conversationActivity.pendingCount || conversationActivity.busy)
              }
              reviewed={isReviewReady(selectedReview)}
              flashTick={questionFlashTick}
            />
          </div>
        </aside>
      </main>
      <ResumePreviewModal
        pipelineId={pipelineId}
        candidate={resumeCandidate}
        onClose={() => setResumeCandidate(null)}
      />
    </div>
  );
}

function CandidateList({
  candidates,
  reviewMap,
  selectedId,
  disabled = false,
  onSelect,
  onPreview,
}: {
  candidates: AgentCandidate[];
  reviewMap: Map<string, InterviewReview>;
  selectedId: string;
  disabled?: boolean;
  onSelect: (id: string) => void;
  onPreview: (candidate: AgentCandidate) => void;
}) {
  return (
    <div className="candidate-list">
      {candidates.length ? (
        candidates.map((candidate) => {
          const review = reviewMap.get(candidate.id);
          const lockStatus = String(review?.question_edit_lock_status || "").toLowerCase();
          const interviewEnded = ["completed", "evaluated", "submitted", "expired", "interviewed", "interview_completed", "interview_ended"].includes(lockStatus);
          const interviewActive = ["started", "in_progress", "answering", "active"].includes(lockStatus);
          return (
            <div
              role="button"
              tabIndex={0}
              aria-disabled={disabled}
              className={`candidate-list__item ${candidate.id === selectedId ? "active" : ""} ${review?.question_edit_locked ? "is-interviewing" : ""}`}
              key={candidate.id}
              onClick={() => {
                if (!disabled) onSelect(candidate.id);
              }}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  if (!disabled) onSelect(candidate.id);
                }
              }}
            >
              <div className="candidate-list__identity">
                {!review?.questions?.length ? <Tag color="blue">NEW</Tag> : null}
                <div className="candidate-list__name">
                  <Typography.Text strong>{candidate.name || "未知候选人"}</Typography.Text>
                  {review?.question_edit_locked ? (
                    <Tag color={interviewEnded ? "default" : "blue"}>
                      {interviewEnded ? "面试结束" : interviewActive ? "面试中" : "已锁定"}
                    </Tag>
                  ) : null}
                </div>
                <div className="candidate-list__meta">
                  <Typography.Text type="secondary">匹配度 {candidate.overall_score ?? 0} 分</Typography.Text>
                  <Typography.Text type="secondary">{review?.questions?.length ?? 0} 道题</Typography.Text>
                </div>
              </div>
              <div className="candidate-list__actions">
                <Button
                  size="small"
                  className="candidate-list__action"
                  disabled={disabled}
                  title="查看该候选人的完整简历"
                  onClick={(event) => {
                    event.stopPropagation();
                    onPreview(candidate);
                  }}
                >
                  预览简历
                </Button>
              </div>
            </div>
          );
        })
      ) : (
        <Empty description="暂无通过筛查的候选人" />
      )}
    </div>
  );
}

function QuestionEditor({
  questions,
  onChange,
  onSaveReviewed,
  busy,
  reviewed,
  locked = false,
  lockReason,
  flashTick = 0,
}: {
  questions: InterviewQuestion[];
  onChange: (questions: InterviewQuestion[]) => void;
  onSaveReviewed: () => void;
  busy: boolean;
  reviewed: boolean;
  locked?: boolean;
  lockReason?: string;
  flashTick?: number;
}) {
  return (
    <Card size="small" title="题目修改">
      {locked ? (
        <Alert
          type="warning"
          showIcon
          message={lockReason === "started" || lockReason === "in_progress" ? "面试正在进行，不能修改面试题" : "面试已结束，不能修改面试题"}
          style={{ marginBottom: 12 }}
        />
      ) : null}
      <Space wrap className="agent-card__actions question-editor-actions">
        <Button type="primary" disabled={!questions.length || busy || locked} onClick={onSaveReviewed}>
          保存
        </Button>
      </Space>
      {questions.length ? (
        <div
          key={flashTick}
          className={flashTick ? "question-editor-list question-editor-list--flash" : "question-editor-list"}
        >
          {questions.map((question, index) => (
            <Card size="small" className="question-editor" title={`第 ${index + 1} 题`} key={index}>
              <Input.TextArea
                className="question-editor__prompt"
                value={String(question.question ?? "")}
                onChange={(event) =>
                  onChange(
                    questions.map((item, currentIndex) =>
                      currentIndex === index ? { ...item, question: event.target.value } : item,
                    ),
                  )
                }
                disabled={locked}
                placeholder="输入面试题"
                autoSize={{ minRows: 3 }}
              />
            </Card>
          ))}
        </div>
      ) : (
        <Empty description="请选择候选人或先生成题目" />
      )}
    </Card>
  );
}

function absoluteInviteUrl(value?: string) {
  if (!value) return "";
  return new URL(value, window.location.origin).toString();
}

async function copyText(value: string) {
  if (!value) {
    message.error('没有可复制的链接');
    return;
  }
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = value;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      if (!document.execCommand('copy')) throw new Error('copy failed');
      textarea.remove();
    }
    message.success('链接已复制');
  } catch {
    message.error('复制失败，请检查浏览器剪贴板权限');
  }
}
