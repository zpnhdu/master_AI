import { expect, test } from "@playwright/test";

test("FastAPI protects the React root and redirects the legacy Studio entry", async ({ context, page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole("heading", { name: "登录智能招聘助手" })).toBeVisible();

  await context.addCookies([
    {
      name: "aihr_session",
      value: "authenticated",
      domain: "127.0.0.1",
      path: "/",
    },
  ]);
  await page.goto("/");

  await expect(page).toHaveURL(/\/studio$/);
  await expect(page.getByRole("heading", { name: "流水线管理" })).toBeVisible();

  const legacyResponse = await page.goto("/frontend/studio.html?q=Java%20%E5%90%8E%E7%AB%AF&sort=created_at");
  expect(legacyResponse?.ok()).toBeTruthy();
  await expect(page).toHaveURL(/\/studio\?/);

  const finalUrl = new URL(page.url());
  expect(finalUrl.pathname).toBe("/studio");
  expect(finalUrl.searchParams.get("q")).toBe("Java 后端");
  expect(finalUrl.searchParams.get("sort")).toBe("created_at");
});

test("invalid session cookies return protected Studio requests to login", async ({ context, page }) => {
  await context.addCookies([
    {
      name: "aihr_session",
      value: "expired-session",
      domain: "127.0.0.1",
      path: "/",
    },
  ]);

  await page.goto("/studio");

  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole("heading", { name: "登录智能招聘助手" })).toBeVisible();
});

test("renders the Studio shell at desktop and narrow viewport sizes", async ({ context, page }) => {
  await context.addCookies([
    {
      name: "aihr_session",
      value: "authenticated",
      domain: "127.0.0.1",
      path: "/",
    },
  ]);

  for (const viewport of [
    { width: 1440, height: 900 },
    { width: 390, height: 844 },
  ]) {
    await page.setViewportSize(viewport);
    await page.goto("/studio");
    await expect(page.getByRole("heading", { name: "流水线管理" })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(viewport.width + 1);
  }
});
