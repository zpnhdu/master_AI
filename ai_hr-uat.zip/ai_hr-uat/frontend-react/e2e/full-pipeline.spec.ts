import { expect, test } from "@playwright/test";

import { collectPageErrors, loginViaForm } from "./helpers";

/**
 * 阶段 5：核心业务链路 E2E（登录 → 创建流水线 → JD 生成 → 简历 → 筛查 → 出题 → 小评）。
 * UI 层验证前端链路可走通；依赖 LLM 的深层生成逻辑由后端 pytest
 * （tests/test_assessment_flow.py、test_assessment_dispatch.py）覆盖。
 */

const PIPELINE_ID = process.env.E2E_PIPELINE_ID || "p_1f205b35";

test.describe.configure({ mode: "serial" });

let page: import("@playwright/test").Page;

test.beforeAll(async ({ browser }) => {
  page = await browser.newPage();
  await loginViaForm(page);
});

test.afterAll(async () => {
  await page.close();
});

test("步骤1：创建流水线 → 自动启动 → 跳转详情页（ISSUE-0-03/1-02）", async () => {
  const errors = collectPageErrors(page);
  await page.goto("/studio");
  await page.getByRole("button", { name: "侧栏创建流水线" }).click();
  await page.getByPlaceholder("例：食材导购 / 店长 / 运营经理").fill("E2E 验收岗位");
  // 默认选中"标准4步 推荐"，直接提交
  await page.getByRole("button", { name: "创建并启动" }).click();
  await expect(page).toHaveURL(/\/pipelines\/p_/, { timeout: 120_000 });
  expect(errors).toEqual([]);
});

test("步骤2：详情页阶段卡片与实时更新就绪（WS 链路）", async () => {
  await expect(page.getByText(/JD|筛选|面试|评估/).first()).toBeVisible({ timeout: 30_000 });
  // JD 生成进行中/完成态文案其一可见
  await expect(page.getByText(/JD|jd_write|岗位描述/i).first()).toBeVisible({ timeout: 30_000 });
});

test("步骤3：小文 JD 工作台可从详情页到达且会话可用", async () => {
  const pipelineId = decodeURIComponent(page.url().split("/pipelines/")[1] ?? PIPELINE_ID);
  await page.goto(`/xiao-wen?pipeline=${pipelineId}`);
  await expect(page.getByText("小文").first()).toBeVisible({ timeout: 15_000 });
  // API 层：会话初始化可用（对齐旧版 sendAgentConversation 链路）
  const sessionResponse = await page.context().request.post("/api/conversations/sessions/ensure", {
    data: { pipeline_id: pipelineId, agent_id: "xiao_wen" },
  });
  expect(sessionResponse.ok()).toBeTruthy();
});

test("步骤4：小寻简历导入入口与候选人接口可用", async () => {
  const response = await page.context().request.get(`/api/pipelines/${PIPELINE_ID}/candidates`);
  expect(response.ok()).toBeTruthy();
  await page.goto(`/xiao-xun?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText(/简历|候选人|上传/).first()).toBeVisible({ timeout: 15_000 });
});

test("步骤5：小筛规则与执行入口可用", async () => {
  await page.goto(`/xiao-shai?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小筛").first()).toBeVisible({ timeout: 15_000 });
  const configResponse = await page.context().request.get(`/api/pipelines/${PIPELINE_ID}/screening-workflow`);
  expect(configResponse.ok()).toBeTruthy();
});

test("步骤6：小面出题与审核入口可用", async () => {
  await page.goto(`/xiao-mian?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小面").first()).toBeVisible({ timeout: 15_000 });
  const questionsResponse = await page.context().request.get(`/api/interview/${PIPELINE_ID}/review`);
  expect(questionsResponse.ok()).toBeTruthy();
});

test("步骤7：小评评估队列与报告链路可用", async () => {
  await page.goto(`/xiao-ping?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小评").first()).toBeVisible({ timeout: 15_000 });
  const queueResponse = await page.context().request.get(`/api/assessment-flow/${PIPELINE_ID}/queue`);
  expect(queueResponse.ok()).toBeTruthy();
});
