import { expect, test } from "@playwright/test";

import { loginViaForm } from "./helpers";

const VIEWPORTS = [
  { name: "mobile", width: 390, height: 844 },
  { name: "tablet", width: 768, height: 1024 },
  { name: "desktop", width: 1366, height: 768 },
] as const;

for (const viewport of VIEWPORTS) {
  test(`/studio 响应式布局在 ${viewport.name} 视口可用`, async ({ page }) => {
    await page.setViewportSize({ width: viewport.width, height: viewport.height });
    await loginViaForm(page);

    await expect(page).toHaveURL(/\/studio$/);
    await expect(page.getByRole("heading", { name: "招聘岗位管理" })).toBeVisible();

    await expect
      .poll(() => page.evaluate(() => document.documentElement.scrollWidth))
      .toBeLessThanOrEqual(viewport.width);

    const isMobile = viewport.width <= 991;
    const navToggle = page.getByRole("button", { name: isMobile ? "展开导航" : "收起导航" });
    await expect(navToggle).toBeVisible();
    await expect(page.locator(".ant-layout-sider-zero-width-trigger")).toHaveCount(0);

    const sider = page.locator(".hr-app-shell--studio .hr-app-shell__sider");
    await expect(sider).toBeVisible();
    const siderWidth = await sider.evaluate((element) => element.getBoundingClientRect().width);

    if (isMobile) {
      expect(siderWidth).toBeLessThanOrEqual(1);
      await navToggle.click();
      await expect(page.getByRole("button", { name: "关闭导航" })).toBeVisible();
      await expect(sider).toHaveCSS("position", "fixed");
      await page.getByRole("button", { name: "关闭导航" }).click();
      await expect(page.getByRole("button", { name: "展开导航" })).toBeVisible();
    }
  });
}
