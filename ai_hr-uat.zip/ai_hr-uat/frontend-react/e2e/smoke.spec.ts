import { expect, test } from "@playwright/test";

test("serves the React shell and same-origin API proxy", async ({ page, request }) => {
  const apiRequests: string[] = [];
  page.on("request", (request) => {
    if (request.url().includes("/api/")) {
      apiRequests.push(request.url());
    }
  });

  const healthResponse = await request.get("/api/health");
  expect(healthResponse.ok()).toBeTruthy();

  await page.goto("/");

  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByRole("heading", { name: "登录智能招聘助手" })).toBeVisible();
  expect(apiRequests.every((url) => new URL(url).port === "5173")).toBeTruthy();
});
