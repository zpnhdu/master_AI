import { expect, test } from "@playwright/test";

import { collectPageErrors, loginViaForm } from "./helpers";

/**
 * 阶段 5：20 个路由页面逐一冒烟。
 * 断言：无 JS 报错、关键元素可见（与计划文档验证清单对应）。
 */

const PIPELINE_ID = process.env.E2E_PIPELINE_ID || "p_1f205b35";

test.beforeEach(async ({ page }) => {
  await loginViaForm(page);
});

test("1 /login 登录页：智能招聘助手登录入口可见", async ({ page }) => {
  await page.goto("/login");
  await expect(page.getByRole("heading", { name: "登录智能招聘助手" })).toBeVisible();
});

test("2 /forbidden 无权限页正确展示", async ({ page }) => {
  await page.goto("/forbidden");
  await expect(page.getByText("当前账号没有招聘流水线的访问权限。")).toBeVisible();
});

test("3 /studio 流水线管理：列表与统计可见", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/studio");
  await expect(page.getByRole("heading", { name: "流水线管理" })).toBeVisible();
  await expect(page.getByText("创建新流水线").first()).toBeVisible();
  expect(errors).toEqual([]);
});

test("4 /pipelines/:id 详情页：阶段卡片可见", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/pipelines/${PIPELINE_ID}`);
  await expect(page.getByText(/JD|筛选|面试|评估|进行中|已完成/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("5 /xiao-wen 小文工作台渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-wen?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小文").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("6 /xiao-xun 小寻简历获取渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-xun?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小寻").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("7 /xiao-shai 小筛筛查渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-shai?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小筛").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("8 /xiao-mian 小面出题渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-mian?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小面").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("9 /xiao-ping 小评评估渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-ping?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小评").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("10 /xiao-hai 小海海报渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/xiao-hai?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText("小海").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("11 /mass-dashboard 面试中心渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/mass-dashboard");
  await expect(page.getByText("面试中心").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("12 /mass-interview/:token 无效 token 有失效态", async ({ page }) => {
  await page.goto("/mass-interview/invalid-token-e2e");
  await expect(page.getByText(/无效|失效|不存在|过期|加载失败/).first()).toBeVisible({ timeout: 15_000 });
});

test("13 /written-test/:token 候选人可完成答题并提交", async ({ page }) => {
  await page.route("**/api/written-test/session/e2e-written-token**", async (route) => {
    if (route.request().method() === "POST") {
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ status: "submitted" }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        candidate_name: "E2E 候选人",
        role: "门店店长",
        company_name: "测试企业",
        questions: [{ id: "q1", question: "请介绍一次经营改善案例。", difficulty: "中等" }],
        time_limit_minutes: 30,
        camera_optional: true,
      }),
    });
  });
  await page.goto("/written-test/e2e-written-token");
  await expect(page.getByRole("heading", { name: "E2E 候选人，你好！" })).toBeVisible();
  await page.getByRole("button", { name: "开始答题" }).click();
  await page.getByPlaceholder(/在此输入你的回答/).fill("我通过优化排班和陈列提升了门店销售。");
  await page.getByRole("button", { name: "完成作答" }).click();
  await page.getByRole("button", { name: "确认提交" }).click();
  await expect(page.getByRole("heading", { name: "提交成功！" })).toBeVisible();
});

test("14 /talent-pool 人才库渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/talent-pool");
  await expect(page.getByText("人才库").first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("15 /profile 人才画像渲染（雷达或空态）", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto(`/profile?pipeline=${PIPELINE_ID}`);
  await expect(page.getByText(/21 维能力雷达|暂无画像数据|画像数据加载失败/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("16 /dashboard 数据看板渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/dashboard");
  await expect(page.getByText(/数据看板|招聘作战室/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("17 /monitor 系统监控渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/monitor");
  await expect(page.getByText(/监控/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("18 /knowledge 知识图谱渲染", async ({ page }) => {
  const errors = collectPageErrors(page);
  await page.goto("/knowledge");
  await expect(page.getByText(/知识/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("19 /roles/:roleId 角色页渲染", async ({ page }) => {
  const rolesResponse = await page.context().request.get("/api/roles");
  const body = (await rolesResponse.json()) as
    { roles?: Array<{ id?: string; role_id?: string }> } | Array<{ id?: string; role_id?: string }>;
  const roles = Array.isArray(body) ? body : (body.roles ?? []);
  const roleId = roles[0]?.id ?? roles[0]?.role_id ?? "";
  test.skip(!roleId, "环境中无角色数据");
  const errors = collectPageErrors(page);
  await page.goto(`/roles/${roleId}`);
  await expect(page.getByText(/Agent|角色|配置/).first()).toBeVisible({ timeout: 15_000 });
  expect(errors).toEqual([]);
});

test("20 / 与 /pipeline-detail 入口重定向", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/studio$/);
  await page.goto("/pipeline-detail");
  await expect(page).toHaveURL(/\/studio$/);
});
