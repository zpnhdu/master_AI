import { expect, type Page } from "@playwright/test";

/** 通过登录表单完成真实登录（含隐私勾选校验），登录成功后跳转目标页。 */
export async function loginViaForm(page: Page, username = "shanghai", password = "shanghai123") {
  await page.goto("/login");
  await page.getByPlaceholder("请输入账号").fill(username);
  await page.getByPlaceholder("请输入密码").fill(password);
  await page.locator('.login-consent input[name="agree"]').check();
  await page.getByRole("button", { name: "进入工作台" }).click();
  await expect(page).toHaveURL(/\/studio$/, { timeout: 15_000 });
}

/** 收集页面 JS 错误（排除 antd 弃用警告与资源 404 类非致命项）。 */
export function collectPageErrors(page: Page): string[] {
  const errors: string[] = [];
  page.on("pageerror", (error) => {
    const message = error.message ?? String(error);
    if (message.includes("ResizeObserver")) return;
    errors.push(message);
  });
  return errors;
}
