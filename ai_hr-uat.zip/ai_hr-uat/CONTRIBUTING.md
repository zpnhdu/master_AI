# 代码规范与提交规范

## 一、代码格式化

格式化工具已配置好，**不需要手动操作**。每次 `git commit` 时自动运行：

- Python 文件 → `ruff format`（自动格式化）
- HTML/JS/JSON/CSS → `prettier --write`（自动格式化）

### 手动格式化（可选）

```bash
# 全量格式化
pnpm format

# 只检查不修改
pnpm format:check
```

### 编辑器

不限制编辑器。VSCode、WebStorm、Vim 都可以。
格式化靠工具链自动跑，不靠编辑器配置。

`.editorconfig` 只统一基础项：UTF-8、LF 换行、去尾部空格。

---

## 二、Git 提交规范

### 格式

```
<type>(<scope>): <subject>
```

### type 类型

| type     | 含义                     |
|----------|--------------------------|
| feat     | 新功能                   |
| fix      | 修 bug                   |
| docs     | 文档变更                 |
| style    | 格式调整（不影响逻辑）   |
| refactor | 重构（非新功能非修复）   |
| perf     | 性能优化                 |
| test     | 测试相关                 |
| chore    | 构建/工具/依赖变动       |

### scope 范围

| scope    | 模块             |
|----------|------------------|
| pipeline | 招聘流水线       |
| interview| 面试模块         |
| agent    | hr_harness/agents|
| kg       | 知识图谱         |
| frontend | 前端页面         |
| api      | 后端接口         |
| feishu   | 飞书集成         |
| rpa      | RPA 爬虫         |
| infra    | 部署/配置/CI     |

### 好的例子

```
feat(pipeline): 增加简历解析断点续传
fix(interview): ASR超时未重试
refactor(agent): 拆分BaseAgent.run接口
chore(infra): 云效流水线加缓存层
docs(frontend): 更新README部署说明
```

### 禁止

```
fix
update
改了点东西
test
```

> commitlint 钩子会自动校验，不合规的提交直接拒绝。

---

## 三、分支策略

| 分支     | 用途           |
|----------|----------------|
| main     | 稳定版，只接受 merge |
| dev      | 日常开发       |
| feat/*   | 新功能         |
| fix/*    | 修复           |

### 合并规则

- `feat/fix → dev`：squash merge（压成一条规范提交）
- `dev → main`：merge commit（保留完整历史）

---

## 四、新成员上手

```bash
# 安装依赖
pnpm install
pip install ruff

# 钩子自动生效，无需额外配置
```
