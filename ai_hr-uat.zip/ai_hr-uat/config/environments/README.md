# AIHR 运行配置

项目按 `APP_ENV` 选择 `config/environments/.env.<环境名>`。未指定时默认使用本地开发配置
`.env.local`。

## 加载规则

```text
系统环境变量 > config/environments/.env.<环境名> > 代码默认值
```

直接启动：

```bash
python -m uvicorn app.main:app --port 8888
```

也可以通过启动脚本的第一个参数切换环境：

```bash
./run.sh local
./run.sh dev
./start_server.sh uat
start_server.bat prod
```

不传参数时使用已有的 `APP_ENV`；两者都未指定时默认使用 `local`。切换环境需要重启后端进程。

本地开发直接启动项目，不使用 Docker；默认使用 `.env.local`，其中 MySQL、Redis 均指向本机。
开发服务器、UAT、生产分别设置 `APP_ENV=dev|uat|prod`，对应使用 `.env.dev`、`.env.uat`、
`.env.prod`。容器或 CI 可以用系统环境变量覆盖单个值。

四份环境文件必须拥有相同配置项；当前 `.env.dev`、`.env.uat`、`.env.prod` 配置值保持一致。
环境文件由仓库统一维护，修改密钥后应同步检查四套配置，并限制仓库和服务器访问权限。
