# 基础镜像优先从 ACR 拉取（ci-build.sh 会自动初始化）
ARG NODE_IMAGE=shanghai-registry.cn-hangzhou.cr.aliyuncs.com/dev/base:node-22-alpine
ARG NGINX_IMAGE=shanghai-registry.cn-hangzhou.cr.aliyuncs.com/dev/base:nginx-1.27-alpine
ARG FRONTEND_PORT=80

FROM ${NODE_IMAGE} AS builder

WORKDIR /app

RUN corepack enable \
    && COREPACK_NPM_REGISTRY=https://registry.npmmirror.com corepack prepare pnpm@9.15.9 --activate

COPY frontend-react/package.json frontend-react/pnpm-lock.yaml ./
RUN pnpm config set registry https://registry.npmmirror.com \
    && pnpm install --frozen-lockfile

COPY frontend-react/ ./
RUN pnpm run build


FROM ${NGINX_IMAGE}

# ARG 需要在 FROM 之后重新声明才能在构建阶段使用
ARG FRONTEND_PORT
ENV FRONTEND_PORT=${FRONTEND_PORT}

# 删除 nginx 官方镜像默认的 symlink（access.log → /dev/stdout, error.log → /dev/stderr）
# 改为真实文件写入（双写由 frontend.conf 控制：同时写 /dev/stdout + /var/log/nginx/）
RUN rm -f /var/log/nginx/access.log /var/log/nginx/error.log \
    && mkdir -p /var/log/nginx

COPY deploy/nginx/frontend.conf /etc/nginx/conf.d/default.conf
COPY --from=builder /app/dist /usr/share/nginx/html

EXPOSE ${FRONTEND_PORT}

HEALTHCHECK --interval=30s --timeout=3s --retries=3 \
    CMD wget -q --spider http://127.0.0.1/healthz || exit 1
