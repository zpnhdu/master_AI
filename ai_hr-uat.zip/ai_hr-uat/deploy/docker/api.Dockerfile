# ---- 后端运行时镜像（纯后端，前端由 frontend.Dockerfile 单独构建） ----
# 依赖（apt 系统包 + pip 包）已预装在 base:api-deps 中（ci-build.sh 自动维护）
ARG BASE_IMAGE=shanghai-registry.cn-hangzhou.cr.aliyuncs.com/dev/base:api-deps
ARG API_PORT=8888
FROM ${BASE_IMAGE}

# ARG 需要在 FROM 之后重新声明才能在构建阶段使用
ARG API_PORT
ENV API_PORT=${API_PORT}

# Poster delivery text is rendered by Pillow. Install a deterministic CJK font
# in the final image instead of relying on the host OS or Pillow's tiny bitmap
# fallback. Keep the file checks here so a package/layout change fails the image
# build rather than publishing unreadable contact details.
RUN apt-get update \
    && apt-get install -y --no-install-recommends fonts-noto-cjk \
    && test -r /usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc \
    && test -r /usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

COPY . .

EXPOSE ${API_PORT}

HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
    CMD curl --fail http://127.0.0.1:8888/api/health/live || exit 1

CMD ["sh", "-c", "uvicorn app.main:app --host 0.0.0.0 --port 8888 --log-config config/logging.yaml"]
