#!/bin/bash
# ai-review.sh — 云效 Flow AI Code Review（两阶段自适应 + 飞书通知）
#
# Stage 1: AI 根据 diff + 项目文件树，自主选择需要查看的文件
# Stage 2: 带补充文件内容做正式 Code Review（大 diff 自动分块，失败降级不阻塞流水线）
#
# 所需云效变量：
#   - CI_COMMIT_SHA          （云效内置，本次触发的 commit）
#   - CI_COMMIT_BEFORE_SHA   （云效内置，上次流水线跑完后的 commit）
#   - CI_COMMIT_REF_NAME     （云效内置，当前分支名）
#   - CI_SOURCE_NAME         （云效内置，代码库名称）
#   - BUILD_EXECUTOR         （云效内置，流水线触发人）
#   - DATETIME               （云效内置，流水线触发时间）
#   - DASHSCOPE_API_KEY      （变量组配置，百炼 API Key）
#   - FEISHU_WEBHOOK_URL     （变量组配置，飞书机器人 webhook，可选）
#   - FEISHU_KEYWORD         （变量组配置，飞书关键词，默认 CodeReview）
set -euo pipefail

# ── 从云效内置变量拿元信息 ──
CURRENT_SHA="${CI_COMMIT_SHA:?CI_COMMIT_SHA must be set}"
BEFORE_SHA="${CI_COMMIT_BEFORE_SHA:-}"
BRANCH="${CI_COMMIT_REF_NAME:-unknown}"
REPO="${CI_SOURCE_NAME:-unknown}"
COMMITTER="${BUILD_EXECUTOR:-${EXECUTOR_NAME:-unknown}}"
COMMIT_TIME="${DATETIME:-$(date +%Y-%m-%d\ %H:%M:%S)}"
SHORT_SHA="${CURRENT_SHA:0:8}"
KEYWORD="${FEISHU_KEYWORD:-CodeReview}"

echo "=== AI Code Review（两阶段自适应） ==="
echo "代码库: $REPO"
echo "分支: $BRANCH"
echo "提交人: $COMMITTER"
echo "时间: $COMMIT_TIME"
echo "本次 commit: $CURRENT_SHA"
echo "上次 commit: $BEFORE_SHA"

# ── 检查 DASHSCOPE_API_KEY ──
if [[ -z "${DASHSCOPE_API_KEY:-}" ]]; then
    echo "⚠️ DASHSCOPE_API_KEY 未设置，跳过 AI 审查"
    exit 0
fi

# ── 获取 diff ──
if [[ -n "$BEFORE_SHA" && "$BEFORE_SHA" != "0000000000000000000000000000000000000000" ]]; then
    echo "=== 对比范围: $BEFORE_SHA → $CURRENT_SHA ==="
    DIFF=$(git diff "${BEFORE_SHA}...${CURRENT_SHA}" \
        -- '*.py' '*.js' '*.ts' '*.go' '*.sh' '*.yaml' '*.yml' \
        2>/dev/null || true)
else
    echo "=== BEFORE_SHA 不可用，对比最近一次 commit ==="
    DIFF=$(git diff "HEAD~1...HEAD" \
        -- '*.py' '*.js' '*.ts' '*.go' '*.sh' '*.yaml' '*.yml' \
        2>/dev/null || true)
fi

# ── 无变更直接跳过 ──
if [[ -z "$DIFF" ]]; then
    echo "✅ 本次无代码变更，跳过 AI 审查"
    exit 0
fi

DIFF_LINES=$(echo "$DIFF" | wc -l)
echo "=== 变更行数: $DIFF_LINES ==="

# diff 太长时截断（避免超 token 限制）
if [[ $DIFF_LINES -gt 8000 ]]; then
    echo "⚠️ diff 超过 8000 行，截取前 8000 行"
    DIFF=$(echo "$DIFF" | awk 'NR<=8000')
fi

# ── 生成项目文件树（带简要描述） ──
echo "=== 生成项目文件树 ==="
FILE_TREE=$(python3 -c "
import os, re

SKIP_DIRS = {'.venv', 'venv', 'node_modules', '__pycache__', '.git', 'dist', 'build', '.next'}
SKIP_FILES = {'pnpm-lock.yaml', 'package-lock.json', 'yarn.lock'}
EXTS = {'.py', '.js', '.ts', '.go', '.sh', '.yaml', '.yml'}

lines = []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
    for f in sorted(files):
        if f in SKIP_FILES:
            continue
        ext = os.path.splitext(f)[1]
        if ext not in EXTS:
            continue
        path = os.path.join(root, f)
        desc = ''
        try:
            with open(path, 'r', errors='ignore') as fh:
                for i, line in enumerate(fh):
                    if i > 20:
                        break
                    line = line.strip()
                    # python docstring or comment
                    if line.startswith('\"\"\"') or line.startswith(\"'''\"):
                        desc = line.strip('\"').strip(\"'\").strip()
                        if not desc:
                            continue
                        break
                    if line.startswith('#') and len(line) > 2 and not line.startswith('#!'):
                        desc = line.lstrip('#').strip()
                        break
                    # js/ts comment
                    if line.startswith('//') and len(line) > 3:
                        desc = line.lstrip('/').strip()
                        break
        except Exception:
            pass
        if desc and len(desc) > 60:
            desc = desc[:60] + '…'
        lines.append(f'{path}  # {desc}' if desc else path)
print('\n'.join(lines))
" 2>/dev/null || find . -type f \( -name '*.py' -o -name '*.js' -o -name '*.ts' -o -name '*.go' -o -name '*.sh' -o -name '*.yaml' -o -name '*.yml' \) \
    ! -path '*/.venv/*' ! -path '*/venv/*' ! -path '*/node_modules/*' ! -path '*/__pycache__/*' ! -path '*/.git/*' \
    | sort)

FILE_TREE_LINES=$(echo "$FILE_TREE" | wc -l)
echo "文件树: $FILE_TREE_LINES 个文件"

# 文件树截断
if [[ $FILE_TREE_LINES -gt 500 ]]; then
    FILE_TREE=$(echo "$FILE_TREE" | head -500)
fi

# ── 判断是否走两阶段 ──
# diff 很小（<80行）时跳过 Stage 1，直接单阶段 review，省一次 API 调用
SKIP_STAGE1=false
if [[ $DIFF_LINES -lt 80 ]]; then
    echo "=== diff 较小（${DIFF_LINES}行），跳过 Stage 1，直接单阶段审查 ==="
    SKIP_STAGE1=true
fi

# ── Stage 1：AI 选择需要查看的文件 ──
SUPPLEMENT=""
if [[ "$SKIP_STAGE1" == "false" ]]; then
    echo "=== Stage 1：AI 选择补充文件 ==="

    STAGE1_PROMPT="你是一个资深代码审查工程师。你需要审查一次代码变更，但首先需要查看一些相关文件才能做出准确判断。

以下是项目的文件清单（含简要描述）：
$FILE_TREE

以下是本次代码变更的 diff：
$DIFF

请告诉我，为了准确审查这段 diff，你需要查看哪些文件的完整内容？

规则：
1. 最多 5 个文件
2. 只能从上面文件清单中选择已存在的文件
3. 优先选择：diff 中 import 的文件、被修改文件的依赖、相关 model/schema 定义
4. 不要选 diff 里已经包含完整内容的文件
5. 仅返回 JSON 数组，不要其他任何文字

示例输出：[\"app/models/candidate.py\", \"app/db.py\"]"

    STAGE1_RESPONSE=$(python3 -c "
import json, sys
prompt = sys.stdin.read()
print(json.dumps({
    'model': 'deepseek-v4-pro',
    'messages': [{'role': 'user', 'content': prompt}],
    'temperature': 0.1
}))
" <<< "$STAGE1_PROMPT" | curl -s --max-time 900 --connect-timeout 20 -X POST \
        "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions" \
        -H "Authorization: Bearer ${DASHSCOPE_API_KEY}" \
        -H "Content-Type: application/json" \
        --data-binary @- 2>/dev/null || echo "")

    # 解析 Stage 1 返回的文件列表
    STAGE1_FILES=$(echo "$STAGE1_RESPONSE" | python3 -c "
import json, sys, re

try:
    data = json.load(sys.stdin)
    content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
    if not content:
        print('')
        sys.exit(0)
    # 提取 JSON 数组（AI 可能包裹在 \`\`\`json 里）
    match = re.search(r'\[.*?\]', content, re.DOTALL)
    if not match:
        print('')
        sys.exit(0)
    files = json.loads(match.group(0))
    if not isinstance(files, list):
        print('')
        sys.exit(0)
    # 安全校验：最多5个，路径不能穿越
    safe = []
    for f in files[:5]:
        if not isinstance(f, str):
            continue
        if '..' in f or f.startswith('/'):
            continue
        # 去掉开头的 ./
        f = f.lstrip('./')
        safe.append(f)
    print('\n'.join(safe))
except Exception:
    print('')
" 2>/dev/null || echo "")

    # 读取补充文件内容
    if [[ -n "$STAGE1_FILES" ]]; then
        SUPPLEMENT=""
        SUPPLEMENT_LOG=""
        while IFS= read -r filepath; do
            if [[ -z "$filepath" ]]; then
                continue
            fi
            if [[ ! -f "$filepath" ]]; then
                SUPPLEMENT_LOG+="  ⚠️ 文件不存在，跳过: $filepath\n"
                continue
            fi
            FILE_LINES=$(wc -l < "$filepath" 2>/dev/null || echo 0)
            SUPPLEMENT_LOG+="  📄 $filepath ($FILE_LINES 行)\n"
            SUPPLEMENT+="### FILE: $filepath
\`\`\`
"
            if [[ $FILE_LINES -gt 500 ]]; then
                SUPPLEMENT+="$(head -500 "$filepath")
... (truncated, $FILE_LINES total lines)"
            else
                SUPPLEMENT+="$(cat "$filepath")"
            fi
            SUPPLEMENT+="
\`\`\`

"
        done <<< "$STAGE1_FILES"

        echo "=== Stage 1 选中文件：==="
        echo -e "$SUPPLEMENT_LOG"
    else
        echo "⚠️ Stage 1 未返回有效文件，降级为单阶段审查"
        SKIP_STAGE1=true
    fi
fi

# ── Stage 2：正式 Code Review ──
echo "=== Stage 2：正式审查 ==="

# 单次流式审查调用（prompt 通过 $1 传入；失败返回非 0 并把错误打到 stderr，不中断脚本）
call_review() {
    python3 -c "
import json, sys
prompt = sys.stdin.read()
print(json.dumps({
    'model': 'deepseek-v4-pro',
    'messages': [{'role': 'user', 'content': prompt}],
    'temperature': 0.3,
    'stream': True
}))
" <<< "$1" | curl -sN --max-time 900 --connect-timeout 20 -X POST \
        "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions" \
        -H "Authorization: Bearer ${DASHSCOPE_API_KEY}" \
        -H "Content-Type: application/json" \
        --data-binary @- | python3 -c "
import json, sys
buf = []
got_error = None
for line in sys.stdin:
    line = line.strip()
    if not line.startswith('data:'):
        continue
    payload = line[5:].strip()
    if payload == '[DONE]':
        break
    try:
        chunk = json.loads(payload)
    except Exception:
        continue
    if chunk.get('error'):
        got_error = chunk['error'].get('message', '未知错误')
        continue
    delta = chunk.get('choices', [{}])[0].get('delta', {}).get('content', '')
    if delta:
        buf.append(delta)
content = ''.join(buf)
if not content:
    print(f'❌ AI 调用失败: {got_error or \"无内容返回\"}', file=sys.stderr)
    sys.exit(1)
print(content)
"
}

if [[ "$SKIP_STAGE1" == "false" && -n "$SUPPLEMENT" ]]; then
    REVIEW_PROMPT="你是一个资深代码审查工程师。请对以下代码变更进行 Code Review。

## 本次代码变更 diff
$DIFF

## 相关文件的完整内容（用于理解上下文）
$SUPPLEMENT

审查维度（按优先级排序）：
1. 🔴 严重：安全漏洞（SQL注入、XSS、硬编码密钥、权限绕过）
2. 🟠 高：潜在 bug（空指针、并发问题、资源泄漏、类型错误）
3. 🟡 中：性能问题（N+1查询、不必要的循环、大对象拷贝）
4. 🟢 低：代码质量（命名、可读性、重复代码）

特别注意：
- 对比 diff 和补充文件，检查跨文件问题（接口不匹配、参数错误、遗漏的联动修改）
- 如果 diff 修改了 model/schema，检查所有引用方是否需要同步修改

输出要求：
- 用中文回答
- 按严重程度排序
- 给出具体文件名和行号
- 如果代码质量良好，简要说明即可

当前分支: $BRANCH"
else
    # 单阶段降级：和原来一样的 prompt
    REVIEW_PROMPT="你是一个资深代码审查工程师。请对以下代码变更进行 Code Review。

审查维度（按优先级排序）：
1. 🔴 严重：安全漏洞（SQL注入、XSS、硬编码密钥、权限绕过）
2. 🟠 高：潜在 bug（空指针、并发问题、资源泄漏）
3. 🟡 中：性能问题（N+1查询、不必要的循环、大对象拷贝）
4. 🟢 低：代码质量（命名、可读性、重复代码）

输出要求：
- 用中文回答
- 按严重程度排序
- 给出具体文件名和问题描述
- 如果代码质量良好，简要说明即可

当前分支: $BRANCH
代码变更 diff：
$DIFF"
fi

# ── 大 diff 分块审查：单次请求体积/时长过大（本次 17k 行曾触发 300s 超时）──
CHUNKED_COUNT=""
if [[ "$DIFF_LINES" -gt 4000 ]]; then
    echo "⚠️ diff 较大（${DIFF_LINES}行），按约 4000 行分块审查"
    CHUNK_DIR=$(mktemp -d)
    CHUNK_COUNT=$(python3 -c "
import os, sys
limit = int(sys.argv[1])
outdir = sys.argv[2]
blocks, cur = [], []
for line in sys.stdin:
    if line.startswith('diff --git ') and cur:
        blocks.append(''.join(cur))
        cur = []
    cur.append(line)
if cur:
    blocks.append(''.join(cur))
chunks, buf = [], []
for blk in blocks:
    if buf and sum(len(x.split(chr(10))) for x in buf) + 1 + blk.count(chr(10)) + 1 > limit:
        chunks.append(''.join(buf))
        buf = []
    buf.append(blk)
if buf:
    chunks.append(''.join(buf))
os.makedirs(outdir, exist_ok=True)
for i, c in enumerate(chunks):
    with open(os.path.join(outdir, 'chunk_%d.diff' % i), 'w', encoding='utf-8') as f:
        f.write(c)
print(len(chunks))
" 4000 "$CHUNK_DIR" <<< "$DIFF" || echo 0)

    if [[ "$CHUNK_COUNT" =~ ^[0-9]+$ ]] && (( CHUNK_COUNT > 1 )); then
        REVIEW_CONTENT=""
        CHUNK_IDX=0
        for CHUNK_FILE in "$CHUNK_DIR"/chunk_*.diff; do
            [[ -f "$CHUNK_FILE" ]] || continue
            CHUNK_IDX=$((CHUNK_IDX + 1))
            echo "── 审查第 ${CHUNK_IDX}/${CHUNK_COUNT} 块 ──"
            CHUNK_PROMPT="你是一个资深代码审查工程师。请对以下代码变更进行 Code Review。
本次变更内容较多，已拆分为 ${CHUNK_COUNT} 块，这是第 ${CHUNK_IDX} 块，请只审查本块内容。

## 本次代码变更 diff（第 ${CHUNK_IDX}/${CHUNK_COUNT} 块）
$(cat "$CHUNK_FILE")

## 相关文件的完整内容（用于理解上下文）
$SUPPLEMENT

审查维度（按优先级排序）：
1. 🔴 严重：安全漏洞（SQL注入、XSS、硬编码密钥、权限绕过）
2. 🟠 高：潜在 bug（空指针、并发问题、资源泄漏、类型错误）
3. 🟡 中：性能问题（N+1查询、不必要的循环、大对象拷贝）
4. 🟢 低：代码质量（命名、可读性、重复代码）

特别注意：
- 对比 diff 和补充文件，检查跨文件问题（接口不匹配、参数错误、遗漏的联动修改）
- 如果 diff 修改了 model/schema，检查所有引用方是否需要同步修改

输出要求：
- 用中文回答
- 按严重程度排序
- 给出具体文件名和行号
- 如果代码质量良好，简要说明即可

当前分支: $BRANCH"
            CHUNK_PART=$(call_review "$CHUNK_PROMPT" || echo "")
            if [[ -z "$CHUNK_PART" ]]; then
                REVIEW_CONTENT+="❌ 第 ${CHUNK_IDX}/${CHUNK_COUNT} 块审查失败（超时或接口异常）

"
            else
                REVIEW_CONTENT+="### 第 ${CHUNK_IDX}/${CHUNK_COUNT} 块

$CHUNK_PART

"
            fi
        done
        CHUNKED_COUNT="$CHUNK_COUNT"
        rm -rf "$CHUNK_DIR"
    else
        rm -rf "$CHUNK_DIR"
    fi
fi

# ── 非分块路径：整体单次调用（失败降级为警告，不阻塞流水线）──
if [[ -z "$CHUNKED_COUNT" ]]; then
    echo "=== 调用 AI 审查（流式）==="
    REVIEW_CONTENT=$(call_review "$REVIEW_PROMPT" || echo "")
    if [[ -z "$REVIEW_CONTENT" ]]; then
        REVIEW_CONTENT="❌ AI 审查未完成（接口超时或异常），请本地检查 diff"
    fi
fi

# ── 打印到流水线日志 ──
echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
echo "  ${KEYWORD} 报告"
echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
echo "📦 代码库: ${REPO}"
echo "🌿 分支: ${BRANCH}"
echo "👤 提交人: ${COMMITTER}"
echo "⏰ 时间: ${COMMIT_TIME}"
echo "🔗 Commit: ${SHORT_SHA}"
if [[ -n "$CHUNKED_COUNT" ]]; then
    echo "🔍 审查模式: 两阶段 · 分块审查（${CHUNKED_COUNT} 块）"
elif [[ "$SKIP_STAGE1" == "false" && -n "$SUPPLEMENT" ]]; then
    echo "🔍 审查模式: 两阶段（含补充文件上下文）"
else
    echo "🔍 审查模式: 单阶段（仅 diff）"
fi
echo '────────────────────────────────────'
echo "$REVIEW_CONTENT"
echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

# ── 发送到飞书机器人（可选）──
if [[ -n "${FEISHU_WEBHOOK_URL:-}" ]]; then
    echo "=== 发送飞书通知 ==="
    
    REVIEW_MODE="两阶段自适应"
    if [[ -n "$CHUNKED_COUNT" ]]; then
        REVIEW_MODE="两阶段 · 分块审查（${CHUNKED_COUNT} 块）"
    elif [[ "$SKIP_STAGE1" == "true" || -z "$SUPPLEMENT" ]]; then
        REVIEW_MODE="单阶段（diff 较小或 Stage 1 降级）"
    fi

    # 组装飞书 Markdown 消息
    FEISHU_MSG="**${KEYWORD} 报告**

📦 **代码库**: ${REPO}
🌿 **分支**: ${BRANCH}
👤 **提交人**: ${COMMITTER}
⏰ **时间**: ${COMMIT_TIME}
🔗 **Commit**: ${SHORT_SHA}
🔍 **审查模式**: ${REVIEW_MODE}

---

${REVIEW_CONTENT}"
    
    # 调用飞书 webhook（消息卡片格式）
    FEISHU_RESP=$(curl -s --max-time 30 -X POST "${FEISHU_WEBHOOK_URL}" \
        -H "Content-Type: application/json" \
        -d "$(python3 -c "
import json, sys
msg = sys.stdin.read()
print(json.dumps({
    'msg_type': 'interactive',
    'card': {
        'header': {
            'title': {'tag': 'plain_text', 'content': '🤖 ${KEYWORD}'},
            'template': 'blue'
        },
        'elements': [{'tag': 'markdown', 'content': msg}]
    }
}))
" <<< "$FEISHU_MSG")" 2>&1 || echo "curl 调用失败")
    
    # 检查飞书返回
    FEISHU_CODE=$(echo "$FEISHU_RESP" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get('code', 'unknown'))
except Exception:
    print('parse_error')
" 2>/dev/null || echo "unknown")
    
    if [[ "$FEISHU_CODE" == "0" ]]; then
        echo "✅ 飞书通知发送成功"
    else
        echo "⚠️ 飞书通知发送失败 (code=$FEISHU_CODE): $FEISHU_RESP"
    fi
else
    echo "ℹ️ FEISHU_WEBHOOK_URL 未配置，跳过飞书通知"
fi

echo "✅ AI 审查完成（仅报告，不阻塞流水线）"
