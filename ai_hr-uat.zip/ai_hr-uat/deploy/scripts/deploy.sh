#!/usr/bin/env bash
# ============================================================
# 统一部署脚本 — 云效主机部署阶段调用（零参数，全部读环境变量）
#
# 用法（云效部署步骤里只需一行）：
#   bash deploy/scripts/deploy.sh
#
# 所需环境变量（云效变量组配置，新项目只需改 APP_NAME/DEPLOY_ENV）：
#   ACR_REGISTRY_VPC  ACR_NAMESPACE  ACR_USERNAME  ACR_PASSWORD
#   APP_NAME          DEPLOY_ENV
#   API_PORT(可选,默认8888)  FRONTEND_PORT(可选,默认80)
#
# 约定（新项目必须遵守）：
#   - 服务器部署目录: /home/shanghai/<APP_NAME>/
#   - 环境变量文件:   /home/shanghai/<APP_NAME>/.env.<DEPLOY_ENV>（首次部署前预置）
#   - 镜像内固定端口: api=8888, frontend=80（映射端口由变量控制）
#   - 额外 volume:    /home/shanghai/<APP_NAME>/compose.override.yml（自动合并）
#   - 后端容器网络别名固定为 api（对应前端 nginx upstream "api:8888"，勿改名）
# ============================================================
set -Eeuo pipefail

# ---- 必填校验 ----
: "${ACR_REGISTRY_VPC:?ACR_REGISTRY_VPC must be set}"
: "${ACR_NAMESPACE:?ACR_NAMESPACE must be set}"
: "${ACR_USERNAME:?ACR_USERNAME must be set}"
: "${ACR_PASSWORD:?ACR_PASSWORD must be set}"
: "${APP_NAME:?APP_NAME must be set}"

DEPLOY_ENV="${1:?用法: bash $0 <env>  (dev/uat/prod)}"
case "$DEPLOY_ENV" in
    dev|uat|prod) ;;
    *) echo "❌ 不支持的环境: ${DEPLOY_ENV}（只支持 dev/uat/prod）" >&2; exit 1 ;;
esac

# ---- 推导（全部来自变量，无写死）----
REG="${ACR_REGISTRY_VPC%/}/${ACR_NAMESPACE#/}"
COMMIT_SHA="${CI_COMMIT_SHA:?CI_COMMIT_SHA must be set (云效内置变量)}"
TAG="${DEPLOY_ENV}-${COMMIT_SHA:0:8}"
API_IMAGE="${REG}/${APP_NAME}-api:${TAG}"
FRONTEND_IMAGE="${REG}/${APP_NAME}-frontend:${TAG}"
API_PORT="${API_PORT:-8888}"
FRONTEND_PORT="${FRONTEND_PORT:-80}"
DEPLOY_DIR="/home/shanghai/${APP_NAME}"
ENV_FILE="${DEPLOY_DIR}/.env.${DEPLOY_ENV}"
LOG_DIR="/home/shanghai/logs"

echo "=== 部署 ${APP_NAME} (${DEPLOY_ENV}) ${TAG} ==="

# ---- 确保全局 autoheal 存在（幂等：已存在则跳过/确保运行）----
ensure_autoheal() {
    if docker ps -a --format '{{.Names}}' | grep -q '^autoheal$'; then
        docker start autoheal >/dev/null 2>&1 || true
        echo "autoheal 已存在"
        return 0
    fi
    echo "=== 首次部署：拉起全局 autoheal（容器 unhealthy 自动重启）==="
    docker pull docker.m.daocloud.io/willfarrell/autoheal || \
        docker pull willfarrell/autoheal
    docker run -d --name autoheal \
        --restart unless-stopped \
        -e AUTOHEAL_INTERVAL=10 \
        -e AUTOHEAL_START_PERIOD=60 \
        -v /var/run/docker.sock:/var/run/docker.sock \
        docker.m.daocloud.io/willfarrell/autoheal
}

# ---- 登录 + 拉镜像（VPC 内网地址，快且免流量费）----
printf '%s' "${ACR_PASSWORD}" | docker login \
    --username="${ACR_USERNAME}" --password-stdin "${ACR_REGISTRY_VPC}"
ensure_autoheal
docker pull "${API_IMAGE}"
docker pull "${FRONTEND_IMAGE}"

# ---- 目录与 env 文件检查 ----
mkdir -p "${DEPLOY_DIR}" "${LOG_DIR}"
if [[ ! -f "${ENV_FILE}" ]]; then
    echo "❌ 缺少环境文件: ${ENV_FILE}（首次部署前需预置）" >&2
    exit 1
fi

read_env_value() {
    local key="$1"
    awk -F= -v key="${key}" '
        $1 == key {
            sub(/^[^=]*=/, "")
            value = $0
        }
        END { print value }
    ' "${ENV_FILE}"
}

OSS_ENDPOINT_VALUE="$(read_env_value ALICLOUD_OSS_ENDPOINT)"
OSS_PUBLIC_ENDPOINT_VALUE="$(read_env_value ALICLOUD_OSS_PUBLIC_ENDPOINT)"
if [[ "${OSS_ENDPOINT_VALUE}" == *-internal.* ]]; then
    if [[ -z "${OSS_PUBLIC_ENDPOINT_VALUE}" ]]; then
        OSS_PUBLIC_ENDPOINT_VALUE="${OSS_ENDPOINT_VALUE/-internal/}"
        echo "⚠️ ${ENV_FILE} 未配置 ALICLOUD_OSS_PUBLIC_ENDPOINT，自动使用 ${OSS_PUBLIC_ENDPOINT_VALUE}"
    elif [[ "${OSS_PUBLIC_ENDPOINT_VALUE}" == *-internal.* ]]; then
        echo "❌ ${ENV_FILE} 的 ALICLOUD_OSS_PUBLIC_ENDPOINT 不能使用内网地址" >&2
        exit 1
    fi
fi
if [[ -z "${OSS_PUBLIC_ENDPOINT_VALUE}" ]]; then
    OSS_PUBLIC_ENDPOINT_VALUE="${OSS_ENDPOINT_VALUE}"
fi

# ---- 生成 compose（每次部署重写，变量全来自环境）----
cat > "${DEPLOY_DIR}/docker-compose.yml" <<YAML
services:
  ${APP_NAME}-api:
    image: ${API_IMAGE}
    container_name: ${APP_NAME}-api
    env_file: ${ENV_FILE}
    environment:
      APP_LOG_DIR: /app/logs
      ALICLOUD_OSS_PUBLIC_ENDPOINT: "${OSS_PUBLIC_ENDPOINT_VALUE}"
    ports: ["0.0.0.0:${API_PORT}:8888"]
    restart: unless-stopped
    volumes:
      - ${LOG_DIR}:/app/logs
    logging:
      driver: json-file
      options:
        max-size: "100m"
        max-file: "10"
    networks:
      default:
        aliases:
          - api
  ${APP_NAME}-frontend:
    image: ${FRONTEND_IMAGE}
    container_name: ${APP_NAME}-frontend
    ports: ["${FRONTEND_PORT}:80"]
    depends_on:
      - ${APP_NAME}-api
    restart: unless-stopped
    volumes:
      - ${LOG_DIR}/nginx:/var/log/nginx
    logging:
      driver: json-file
      options:
        max-size: "100m"
        max-file: "10"
YAML

# ---- 额外 volume / 配置覆盖（可选，自动合并）----
OVERRIDE="${DEPLOY_DIR}/compose.override.yml"
COMPOSE_ARGS=(-f "${DEPLOY_DIR}/docker-compose.yml")
if [[ -f "${OVERRIDE}" ]]; then
    echo "检测到 override: ${OVERRIDE}"
    COMPOSE_ARGS+=(-f "${OVERRIDE}")
fi

# ---- 启动 + 健康检查（compose 的项目名=应用名，容器不冲突）----
# ---- 清理可能存在的旧容器（docker run 启动的也会清理）----
#docker rm -f ${APP_NAME}-api ${APP_NAME}-frontend 2>/dev/null || true

cd "${DEPLOY_DIR}"
docker compose "${COMPOSE_ARGS[@]}" up -d --pull always

sleep 12
curl -sf "http://127.0.0.1:${API_PORT}/api/health/live" > /dev/null || { echo "❌ API 健康检查失败"; exit 1; }
curl -sf -o /dev/null "http://127.0.0.1:${FRONTEND_PORT}/" || { echo "❌ 前端健康检查失败"; exit 1; }

echo "✅ deploy ok: ${APP_NAME} (${DEPLOY_ENV}) ${TAG}"
