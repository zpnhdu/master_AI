#!/usr/bin/env bash

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
COMPOSE_FILE="${COMPOSE_FILE:-${PROJECT_DIR}/deploy/compose/production.yml}"
DEPLOY_ENV_FILE="${DEPLOY_ENV_FILE:-${PROJECT_DIR}/deploy/images.env}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:8080/healthz}"
FRONTEND_IMAGE="${FRONTEND_IMAGE:?FRONTEND_IMAGE must be set}"

run_compose() {
    local image="$1"
    shift
    env FRONTEND_IMAGE="$image" docker compose --env-file "$DEPLOY_ENV_FILE" -f "$COMPOSE_FILE" "$@"
}

wait_for_frontend() {
    local attempt
    for attempt in $(seq 1 30); do
        if curl --fail --silent --show-error "$HEALTH_URL" >/dev/null; then
            return 0
        fi
        sleep 2
    done
    return 1
}

persist_frontend_image() {
    local image="$1"
    local temp_file
    temp_file="$(mktemp "${DEPLOY_ENV_FILE}.XXXXXX")"

    awk -v image="$image" '
        BEGIN { updated = 0 }
        /^FRONTEND_IMAGE=/ {
            if (!updated) print "FRONTEND_IMAGE=" image
            updated = 1
            next
        }
        { print }
        END {
            if (!updated) print "FRONTEND_IMAGE=" image
        }
    ' "$DEPLOY_ENV_FILE" > "$temp_file"

    chmod 600 "$temp_file"
    mv "$temp_file" "$DEPLOY_ENV_FILE"
}

if [[ "$FRONTEND_IMAGE" == *[$' \t\r\n']* ]]; then
    echo "FRONTEND_IMAGE 不能包含空白字符" >&2
    exit 1
fi

if [[ ! -f "$COMPOSE_FILE" || ! -f "$DEPLOY_ENV_FILE" ]]; then
    echo "缺少 Compose 文件或镜像变量文件" >&2
    exit 1
fi

if ! grep -q '^BACKEND_IMAGE=' "$DEPLOY_ENV_FILE"; then
    echo "${DEPLOY_ENV_FILE} 缺少 BACKEND_IMAGE" >&2
    exit 1
fi

if [[ "$(docker inspect --format '{{.State.Running}}' ai-hr-api 2>/dev/null || true)" != "true" ]]; then
    echo "后端容器 ai-hr-api 未运行，停止前端单独发布" >&2
    exit 1
fi

previous_image="$(docker inspect --format '{{.Config.Image}}' ai-hr-frontend 2>/dev/null || true)"

echo "拉取前端镜像：${FRONTEND_IMAGE}"
run_compose "$FRONTEND_IMAGE" pull frontend
run_compose "$FRONTEND_IMAGE" up -d --no-deps frontend

if wait_for_frontend; then
    persist_frontend_image "$FRONTEND_IMAGE"
    echo "前端发布成功：${FRONTEND_IMAGE}"
    exit 0
fi

echo "前端健康检查失败" >&2
run_compose "$FRONTEND_IMAGE" logs --tail=100 frontend >&2 || true

if [[ -n "$previous_image" && "$previous_image" != "$FRONTEND_IMAGE" ]]; then
    echo "回滚前端镜像：${previous_image}" >&2
    run_compose "$previous_image" up -d --no-deps frontend
    if wait_for_frontend; then
        echo "已回滚到：${previous_image}" >&2
    else
        echo "回滚后健康检查仍未通过" >&2
    fi
fi

exit 1
