# 部署说明

生产环境只发布 `frontend-react/` 构建出的 React 前端，旧版 HTML/JS 页面不再随镜像发布。
旧目录仅用于本地迁移；API 镜像只保留品牌图、小海模板等后端运行所需素材。

## 目录结构

```text
deploy/
├── compose/
│   ├── infrastructure.yml  # 本地 MySQL、Redis 和 API
│   ├── development.yml     # 服务器开发环境（加载 .env.local）
│   └── production.yml      # 生产前后端容器
├── docker/
│   ├── api.Dockerfile
│   ├── frontend.Dockerfile
│   └── frontend.Dockerfile.dockerignore
├── nginx/
│   ├── frontend.conf       # 前端容器 Nginx
│   └── host.conf           # 宿主机 HTTP/HTTPS 入口
├── scripts/
│   ├── deploy-frontend.sh  # 前端单独更新和失败回滚
│   └── deploy.sh           # ⭐ 统一部署脚本：云效主机部署调用（compose 版，零参数读云效变量）
└── images.env.example      # 后端和前端镜像地址模板
```

## 云效统一部署（deploy/scripts/deploy.sh）

**用途**：云效流水线"主机部署"阶段调用，一个新项目只改少数云效变量即可复用。API + 前端两个容器以 compose 方式启动，API 绑定 0.0.0.0（对外可访问，注意用安全组控制 8888 的入方向），前端绑 FRONTEND_PORT。

### 用法（云效部署步骤里一行）

```bash
bash deploy/scripts/deploy.sh
```

### 所需云效变量（变量组配置）

| 变量 | 必填 | 说明 |
|------|------|------|
| `ACR_REGISTRY_VPC` | ✅ | ACR VPC 内网地址（拉镜像快、免流量费） |
| `ACR_NAMESPACE` | ✅ | ACR 命名空间 |
| `ACR_USERNAME` / `ACR_PASSWORD` | ✅ | ACR 登录凭证（密码加密存储） |
| `APP_NAME` | ✅ | 应用名，推导镜像仓库/容器名/部署目录 |
| `DEPLOY_ENV` | ✅ | 环境名（dev/uat/prod），推导 tag 和 .env 文件 |
| `API_PORT` | 否 | 后端映射端口，默认 8888 |
| `FRONTEND_PORT` | 否 | 前端映射端口，默认 80 |
| `DATETIME` | 否 | 云效内置，tag 后缀；缺省用本地时间 |

> `ACR_REGISTRY`（公网）是构建阶段用的，部署阶段用 `ACR_REGISTRY_VPC`。

### 约定（新项目必须遵守）

- 服务器部署目录：`/home/shanghai/<APP_NAME>/`
- 环境变量文件：`/home/shanghai/<APP_NAME>/.env.<DEPLOY_ENV>`（**首次部署前预置**，含真实 DB/密钥）
- 镜像内固定端口：api=8888, frontend=80（映射端口由变量控制）
- 后端容器网络别名固定为 `api`（对应前端 nginx upstream `api:8888`，勿改名）
- 额外 volume/配置：`/home/shanghai/<APP_NAME>/compose.override.yml`（脚本自动合并）

### 新项目接入 3 步

1. 云效变量组：复制现有变量组，改 `APP_NAME`（+ 按环境改 `DEPLOY_ENV`）
2. 服务器预置：`mkdir -p /home/shanghai/<APP_NAME> && 放 .env.<DEPLOY_ENV>`
3. 流水线主机部署步骤：`bash deploy/scripts/deploy.sh`

### 容器自愈（autoheal，脚本自动处理，无需配置）

deploy.sh 内置 `ensure_autoheal()`：服务器首次部署时自动拉起全局 autoheal 容器（监控所有容器的健康状态，unhealthy 自动重启），之后每次部署幂等检查跳过。前提是镜像自带 HEALTHCHECK（api/frontend 都已具备）。详见 `deploy/scripts/deploy.sh` 顶部注释。

服务器需要 Docker Compose v2，建议版本不低于 2.20。以下命令均在项目根目录执行。

## 构建镜像

镜像标签应使用 Git 提交号，生产部署禁止使用 `latest`：

```bash
IMAGE_TAG="$(git rev-parse --short HEAD)"

docker build \
  -f deploy/docker/api.Dockerfile \
  -t "ai-hr-api:${IMAGE_TAG}" \
  .

docker build \
  -f deploy/docker/frontend.Dockerfile \
  -t "ai-hr-frontend:${IMAGE_TAG}" \
  .
```

前端镜像使用 Node.js 22 构建，并依次执行类型检查、测试和 Vite 构建。运行阶段仅包含
Nginx 和 React 静态产物。API 镜像使用 Python 3.11，不包含 React 工具链或旧版页面。

## 首次部署

```bash
# 1. 检查生产运行配置。数据库和 Redis 地址不能使用 127.0.0.1 或 localhost
# 编辑 config/environments/.env.prod，确认服务地址与凭证正确
chmod 600 config/environments/.env.prod

# 2. 配置不可变镜像地址
cp deploy/images.env.example deploy/images.env
# 编辑 deploy/images.env，填写 BACKEND_IMAGE 和 FRONTEND_IMAGE
chmod 600 deploy/images.env

# 3. 启动前后端
docker compose \
  --env-file deploy/images.env \
  -f deploy/compose/production.yml \
  up -d
```

`deploy/compose/production.yml` 加载 `config/environments/.env.prod`，并注入 `APP_ENV=prod`。
该文件以只读方式挂载到 API 容器，并通过 `.dockerignore` 排除在镜像构建上下文之外。
生产前端开关固定为：

- `FRONTEND_APP_ENABLED=1`：React 是当前产品前端。
- `REACT_FRONTEND_EXTERNAL=1`：React 由独立的 Nginx 前端容器托管，API 镜像无需包含 `dist`。
- 旧版 `/frontend/*.html` 只保留 React 路由兼容重定向，不再挂载旧目录或返回旧 HTML。

这三个开关含义独立，不能再通过 `FRONTEND_APP_ENABLED=0` 表示“React 在另一个容器”。生产
Compose 不创建 MySQL 和 Redis；生产地址必须可从 API 容器访问。本地基础设施可以使用：

```bash
docker compose \
  --env-file config/environments/.env.local \
  -f deploy/compose/infrastructure.yml \
  up -d mysql redis
```

## 开发服务器 Docker 部署

开发服务器使用 `development.yml`，它直接加载 `config/environments/.env.dev` 并固定向 API
容器注入 `APP_ENV=dev`。容器内的 `127.0.0.1` 仅指当前容器，MySQL、Redis、ES 和 OSS 必须使用
容器可访问的远程地址或 Compose 服务名。

```bash
# 编辑 .env.dev，填写开发服务器使用的服务地址与凭证。
cp deploy/images.env.example deploy/images.env
# 编辑 deploy/images.env，填写开发环境的后端与前端镜像标签。
docker compose \
  --env-file deploy/images.env \
  -f deploy/compose/development.yml \
  up -d
```

启动后先在服务器验证 `http://127.0.0.1:8080/healthz`，再由宿主机 Nginx 使用开发域名反向代理。

OSS 上传和下载使用不同入口：`OSS_ENDPOINT` 可配置阿里云内网 endpoint，`OSS_PUBLIC_BASE_URL`
必须配置浏览器可访问的 bucket 公网域名或已绑定的自定义域名。视频和简历对象分别写入
`OSS_VIDEO_PREFIX`、`OSS_RESUME_PREFIX`。若启用阿里云直播录制，还需在直播控制台的录制存储
模板中将 OSS 路径设置为 `ai-hr/video/live/{StreamName}/`，与应用查询前缀保持一致。

## 流量路径

```text
浏览器
  → 宿主机 Nginx :80/:443
  → 前端容器 127.0.0.1:8080
      ├─ React 页面、/assets、/brand
      └─ /api、/ws、/uploads → api:8888
```

旧版 `/frontend/*.html` 链接不再由 Nginx 跳转；`/frontend` 和 `/frontend/` 请求均直接
返回 404。旧版 HTML 只允许在本地环境中用于迁移参考。

公司 Logo、HR 二维码和小海素材统一保存在 OSS，API 只保存对象 key 并按请求生成签名 URL。

先确认 `http://127.0.0.1:8080/healthz` 正常，再安装宿主机 Nginx 配置：

```bash
sudo cp deploy/nginx/host.conf /etc/nginx/conf.d/ai-hr-os.conf
sudo nginx -t
sudo nginx -s reload
```

## 更新前端

前端单独发布要求 `ai-hr-api` 已经运行。脚本会拉取指定镜像、重建前端容器并执行健康检查；
失败时自动恢复之前运行的前端镜像。

```bash
FRONTEND_IMAGE='<镜像仓库>/ai-hr-frontend:<commit-id>' \
  ./deploy/scripts/deploy-frontend.sh
```

## 验证与日志

```bash
curl --fail http://127.0.0.1:8080/healthz
curl --fail http://127.0.0.1:8080/api/health/live
curl --head http://127.0.0.1:8080/login

docker compose \
  --env-file deploy/images.env \
  -f deploy/compose/production.yml \
  ps
```

## 云效接入约定

本次不添加云效流水线文件。后续接入时，两个镜像任务都以仓库根目录为构建上下文，并分别指定：

- 后端 Dockerfile：`deploy/docker/api.Dockerfile`
- 前端 Dockerfile：`deploy/docker/frontend.Dockerfile`
- 镜像标签：提交 SHA 或云效构建号，不使用 `latest`
- 部署命令：`docker compose --env-file deploy/images.env -f deploy/compose/production.yml up -d`

镜像仓库凭证和服务器凭证应使用云效密钥变量，不写入仓库。云效部署机可以在执行 Compose
前生成权限为 `600` 的对应环境文件，部署完成后保留在服务器而非构建产物中。
