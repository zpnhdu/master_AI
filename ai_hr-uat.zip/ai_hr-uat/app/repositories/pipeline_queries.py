"""Read-only pipeline query repository.

The legacy ``app.db`` module delegates these functions for import compatibility.
This module owns no writes, transactions, access-control decisions outside the
SQL scope arguments, or application state.
"""

from __future__ import annotations

import json


def _db_facade():
    from app import db

    return db


def get_db():
    return _db_facade().get_db()


def _decode_enabled_agents(data: dict) -> dict:
    enabled_agents = data.get("enabled_agents", "")
    if isinstance(enabled_agents, str) and enabled_agents:
        try:
            data["enabled_agents"] = json.loads(enabled_agents)
        except (json.JSONDecodeError, TypeError):
            data["enabled_agents"] = []
    elif not enabled_agents:
        data["enabled_agents"] = []
    return data


def get_pipeline(pipeline_id: str) -> dict | None:
    conn = get_db()
    row = conn.execute("SELECT * FROM pipelines WHERE id=%s", (pipeline_id,)).fetchone()
    return _decode_enabled_agents(dict(row)) if row else None


def list_pipelines_for_user(
    user_id: str,
    tenant_id: str = "tenant_default",
    include_all: bool = False,
    q: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    owner_user_id: str | None = None,
) -> list[dict]:
    """List pipelines within a tenant and the caller's owner scope."""
    conn = get_db()
    if created_from and len(created_from) == 10:
        created_from = f"{created_from} 00:00:00"
    if created_to and len(created_to) == 10:
        created_to = f"{created_to} 23:59:59"
    conditions = ["p.tenant_id=%s"]
    parameters: list[str] = [tenant_id]
    if owner_user_id:
        conditions.append("p.owner_user_id=%s")
        parameters.append(owner_user_id)
    elif not include_all:
        conditions.append("p.owner_user_id=%s")
        parameters.append(user_id)
    if q:
        conditions.append("(p.role LIKE %s OR p.type LIKE %s OR u.display_name LIKE %s OR u.username LIKE %s)")
        pattern = f"%{q}%"
        parameters.extend([pattern, pattern, pattern, pattern])
    if created_from and created_to:
        conditions.append("p.created_at BETWEEN %s AND %s")
        parameters.extend([created_from, created_to])
    elif created_from:
        conditions.append("p.created_at >= %s")
        parameters.append(created_from)
    elif created_to:
        conditions.append("p.created_at <= %s")
        parameters.append(created_to)

    rows = conn.execute(
        f"""SELECT p.*, u.display_name AS hr_name
            FROM pipelines p
            LEFT JOIN auth_users u ON u.id = p.owner_user_id
            WHERE {" AND ".join(conditions)}
            ORDER BY p.created_at DESC, p.id ASC""",
        parameters,
    ).fetchall()
    return [_decode_enabled_agents(dict(row)) for row in rows]


def get_pipeline_for_user(
    pipeline_id: str, user_id: str, tenant_id: str = "tenant_default", include_all: bool = False
) -> dict | None:
    """Return a pipeline only when it belongs to the requested user/tenant."""
    conn = get_db()
    if include_all:
        row = conn.execute("SELECT * FROM pipelines WHERE id=%s AND tenant_id=%s", (pipeline_id, tenant_id)).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM pipelines WHERE id=%s AND tenant_id=%s AND owner_user_id=%s",
            (pipeline_id, tenant_id, user_id),
        ).fetchone()
    return _decode_enabled_agents(dict(row)) if row else None


def get_stages(pipeline_id: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute("SELECT * FROM pipeline_stages WHERE pipeline_id=%s ORDER BY id", (pipeline_id,)).fetchall()
    result = []
    for row in rows:
        data = dict(row)
        if isinstance(data.get("output"), str) and data["output"]:
            try:
                parsed = json.loads(data["output"])
                if isinstance(parsed, str):
                    try:
                        parsed = json.loads(parsed)
                    except (json.JSONDecodeError, TypeError):
                        pass
                data["output"] = parsed
            except (json.JSONDecodeError, TypeError):
                pass
        result.append(data)
    return result


def get_candidates(pipeline_id: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM candidates WHERE pipeline_id=%s ORDER BY overall_score DESC", (pipeline_id,)
    ).fetchall()
    result = []
    for row in rows:
        data = dict(row)
        data["skills"] = json.loads(data["skills"]) if isinstance(data["skills"], str) else data["skills"]
        data["video_assessment"] = (
            json.loads(data["video_assessment"])
            if isinstance(data["video_assessment"], str)
            else data["video_assessment"]
        )
        result.append(data)
    return result


def get_messages(pipeline_id: str = None, limit: int = 100) -> list[dict]:
    conn = get_db()
    if pipeline_id:
        rows = conn.execute(
            "SELECT * FROM messages WHERE pipeline_id=%s ORDER BY id DESC LIMIT %s", (pipeline_id, limit)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM messages ORDER BY id DESC LIMIT %s", (limit,)).fetchall()
    result = []
    for row in rows:
        data = dict(row)
        data["card_data"] = json.loads(data["card_data"]) if data["card_data"] else {}
        result.append(data)
    return list(reversed(result))


def get_interview_schedules(pipeline_id: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM interview_schedules WHERE pipeline_id=%s ORDER BY date, time", (pipeline_id,)
    ).fetchall()
    return [dict(row) for row in rows]


def get_elimination_records(pipeline_id: str) -> list[dict]:
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM elimination_records WHERE pipeline_id=%s ORDER BY eliminated_at DESC", (pipeline_id,)
    ).fetchall()
    result = []
    for row in rows:
        data = dict(row)
        data["details"] = json.loads(data["details"]) if isinstance(data["details"], str) and data["details"] else {}
        result.append(data)
    return result
