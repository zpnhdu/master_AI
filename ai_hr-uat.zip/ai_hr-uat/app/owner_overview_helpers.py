"""Pure aggregation helpers for owner overview analytics."""


def candidate_count_map(candidate_rows) -> dict[str, dict]:
    """Map pipeline id -> candidate/hire counts from a GROUP BY result."""
    return {
        str(row["pipeline_id"]): {
            "candidate_count": int(row["candidate_count"] or 0),
            "hire_count": int(row["hire_count"] or 0),
        }
        for row in candidate_rows
    }


def owner_name_map(owner_rows) -> dict[str, str]:
    """Map auth user id -> display name, falling back to username then id."""
    return {str(row["id"]): str(row["display_name"] or row["username"] or row["id"]) for row in owner_rows}


def aggregate_owner_overview(
    pipelines: list[dict],
    candidate_rows: list,
    owner_rows: list,
) -> list[dict]:
    """Group visible pipelines into per-owner hiring outcome cards."""
    candidate_map = candidate_count_map(candidate_rows)
    owner_names = owner_name_map(owner_rows)

    grouped: dict[str, dict] = {}
    for pipeline in pipelines:
        owner_id = str(pipeline.get("owner_user_id") or "")
        stats = candidate_map.get(pipeline["id"], {"candidate_count": 0, "hire_count": 0})
        item = grouped.setdefault(
            owner_id,
            {
                "owner_id": owner_id,
                "owner_name": owner_names.get(owner_id, owner_id or "未知 HR"),
                "pipeline_count": 0,
                "candidate_count": 0,
                "hire_count": 0,
            },
        )
        item["pipeline_count"] += 1
        item["candidate_count"] += stats["candidate_count"]
        item["hire_count"] += stats["hire_count"]

    result = list(grouped.values())
    for item in result:
        candidates = item["candidate_count"]
        item["conversion_rate"] = round(item["hire_count"] / candidates * 100, 1) if candidates else 0
    result.sort(key=lambda item: (-item["conversion_rate"], -item["hire_count"], item["owner_name"]))
    return result
