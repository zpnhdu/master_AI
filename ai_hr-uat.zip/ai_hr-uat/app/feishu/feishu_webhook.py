"""Feishu bidirectional interaction — webhook receiver and command parser.

Receives Feishu message callbacks, parses HR intents, and returns
interactive cards with action buttons.
"""

import json
from typing import Optional

# ── 意图解析器 ──────────────────────────────────────────────

INTENT_PATTERNS = [
    # （关键词、意图类型、响应模板）
    (["查询候选人", "搜索候选人", "找候选人", "候选人"], "search_candidate", None),
    (["推荐", "Java岗位", "前端岗位", "Python岗位", "岗位"], "recommend_job", None),
    (["流水线状态", "进度", "招聘进度", "pipeline"], "pipeline_status", None),
    (["面试安排", "安排面试", "约面"], "schedule_interview", None),
    (["人才库", "简历库", "人才池"], "talent_pool_stats", None),
    (["数据概览", "仪表盘", "统计", "dashboard"], "dashboard_summary", None),
    (["帮助", "help", "功能", "能做什么"], "help", None),
]


def parse_intent(text: str) -> tuple[str, Optional[str]]:
    """Parse user message to determine intent and extract keyword.

    Returns (intent_type, keyword_or_None).
    """
    text_lower = text.lower().strip()

    for keywords, intent, _ in INTENT_PATTERNS:
        for kw in keywords:
            if kw in text_lower:
                # 提取匹配模式后的关键词
                keyword = text_lower.replace(kw, "").strip()
                return intent, keyword if keyword else None

    return "unknown", None


# ── 卡片构建函数 ────────────────────────────────────────────


def build_help_card() -> dict:
    """Build a help card listing available commands."""
    return {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": "🤖 锅圈招聘助手 - 功能列表"},
            "template": "blue",
        },
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": "支持以下指令：\n• **查询候选人** [关键词] — 搜索人才库\n• **推荐** [岗位] 岗位 — AI推荐匹配候选人\n• **流水线状态** — 查看招聘流水线进度\n• **面试安排** — 查看待安排面试\n• **人才库** — 人才库数据统计\n• **数据概览** — 招聘全局仪表盘\n• **帮助** — 显示此帮助信息",
                },
            },
            {"tag": "hr"},
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📊 数据概览"},
                        "value": "dashboard_summary",
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📋 流水线状态"},
                        "value": "pipeline_status",
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "👥 人才库"},
                        "value": "talent_pool_stats",
                        "type": "default",
                    },
                ],
            },
        ],
    }


def build_pipeline_status_card(pipelines: list[dict]) -> dict:
    """Build a card showing pipeline statuses."""
    elements = [
        {
            "tag": "div",
            "text": {"tag": "lark_md", "content": f"**当前活跃流水线: {len(pipelines)} 个**\n"},
        }
    ]

    for p in pipelines[:10]:
        status_emoji = {"running": "🟢", "waiting_for_resumes": "🟡", "completed": "✅"}.get(p.get("status"), "⚪")
        elements.append(
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f"{status_emoji} **{p.get('role', '未知')}** — {p.get('candidate_count', 0)}位候选人 — {p.get('status', 'unknown')}",
                },
            }
        )
        elements.append(
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📋 查看详情"},
                        "value": json.dumps({"action": "view_pipeline", "pipeline_id": p["id"]}),
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "👤 候选人"},
                        "value": json.dumps({"action": "view_candidates", "pipeline_id": p["id"]}),
                        "type": "default",
                    },
                ],
            }
        )
        elements.append({"tag": "hr"})

    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "📋 招聘流水线状态"}, "template": "blue"},
        "elements": elements[:50],  # 飞书卡片元素数量限制
    }


def build_candidate_search_card(candidates: list[dict], keyword: str = "") -> dict:
    """Build a card showing candidate search results."""
    elements = [
        {
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"**搜索结果: {len(candidates)} 位候选人**" + (f' (关键词: "{keyword}")' if keyword else ""),
            },
        }
    ]

    for c in candidates[:10]:
        name = c.get("name", "未知")
        title = c.get("title", c.get("current_position", ""))
        skills = ", ".join(c.get("skills", [])[:5]) if isinstance(c.get("skills"), list) else c.get("skills", "")
        score = c.get("score", c.get("overall_score", 0))

        elements.append(
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f"**{name}** ⭐{score}\n{title}\n{skills}"
                    if title
                    else f"**{name}** ⭐{score}\n{skills}",
                },
            }
        )
        elements.append(
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📋 查看详情"},
                        "value": json.dumps({"action": "view_candidate", "candidate_id": c.get("id", "")}),
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📅 安排面试"},
                        "value": json.dumps({"action": "schedule", "candidate_id": c.get("id", "")}),
                        "type": "primary",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "❌ 淘汰"},
                        "value": json.dumps({"action": "reject", "candidate_id": c.get("id", "")}),
                        "type": "danger",
                    },
                ],
            }
        )
        elements.append({"tag": "hr"})

    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "👤 候选人搜索结果"}, "template": "blue"},
        "elements": elements[:50],
    }


def build_talent_pool_stats_card(stats: dict) -> dict:
    """Build a card showing talent pool statistics."""
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "👥 人才库数据统计"}, "template": "blue"},
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": (
                        f"**总简历数**: {stats.get('total_resumes', 0)}\n"
                        f"**活跃简历**: {stats.get('active_resumes', 0)}\n"
                        f"**平均评分**: {stats.get('avg_score', 0):.1f}\n"
                        f"**本周新增**: {stats.get('weekly_new', 0)}\n"
                        f"**本周面试**: {stats.get('weekly_interviews', 0)}\n"
                        f"**本周录用**: {stats.get('weekly_hires', 0)}"
                    ),
                },
            },
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "🔍 搜索人才库"},
                        "value": "search_candidate",
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📊 查看仪表盘"},
                        "value": "dashboard_summary",
                        "type": "default",
                    },
                ],
            },
        ],
    }


def build_dashboard_summary_card(summary: dict) -> dict:
    """Build a card showing dashboard summary."""
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "📊 招聘数据概览"}, "template": "blue"},
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": (
                        f"**活跃岗位**: {summary.get('total_pipelines', 0)}\n"
                        f"**候选人总数**: {summary.get('total_candidates', 0)}\n"
                        f"**本周新增简历**: {summary.get('weekly_new', 0)}\n"
                        f"**本周面试**: {summary.get('weekly_interviews', 0)}\n"
                        f"**本周录用**: {summary.get('weekly_hires', 0)}"
                    ),
                },
            },
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "📋 查看流水线"},
                        "value": "pipeline_status",
                        "type": "default",
                    },
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "👥 查看人才库"},
                        "value": "talent_pool_stats",
                        "type": "default",
                    },
                ],
            },
        ],
    }


def build_unknown_intent_card() -> dict:
    """Build a card for unrecognized commands."""
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "❓ 无法识别指令"}, "template": "yellow"},
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": "抱歉，无法识别你的指令。请尝试以下：\n• **查询候选人** [关键词]\n• **推荐** [岗位]\n• **流水线状态**\n• **数据概览**\n• **帮助**",
                },
            },
        ],
    }


def build_error_card(error_msg: str) -> dict:
    """Build an error card."""
    return {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": "⚠️ 处理出错"}, "template": "red"},
        "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": f"错误信息: {error_msg}"}}],
    }


# ── 验证（飞书事件订阅 URL 验证）─────────────────────────────


def verify_url(challenge: str, token: str = "") -> dict:
    """Handle Feishu URL verification challenge."""
    return {"challenge": challenge}
