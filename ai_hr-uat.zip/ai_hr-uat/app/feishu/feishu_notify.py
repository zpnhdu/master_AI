"""Feishu Notification — send structured card messages to Feishu.

Provides card-sending primitives used by the notification flows (e.g. mass
interview invitations), including candidate info, interview time, questions and
action buttons rendered into a Feishu interactive card.
"""

import json
import logging
import urllib.request

logger = logging.getLogger("app.feishu_notify")

BASE_URL = "https://open.feishu.cn/open-apis"


def _get_token() -> str:
    """Get tenant access token."""
    from app.feishu_sync import get_feishu_sync

    sync = get_feishu_sync()
    return sync._get_token()


def _send_card(chat_id: str, card: dict) -> dict:
    """Send interactive card message to chat."""
    token = _get_token()
    url = f"{BASE_URL}/im/v1/messages?receive_id_type=chat_id"

    payload = {
        "receive_id": chat_id,
        "msg_type": "interactive",
        "content": json.dumps(card, ensure_ascii=False),
    }

    req = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=utf-8",
        },
    )

    with urllib.request.urlopen(req, timeout=30) as response:
        result = json.loads(response.read().decode("utf-8"))

    if result.get("code") not in (None, 0):
        raise RuntimeError(f"Failed to send card: {result}")

    return result


# ── 百人面试邀请卡片 ────────────────────────────────────────


def send_mass_interview_invite(
    chat_id: str, candidate_name: str, role: str, interview_url: str, expires_at: str = "", company_name: str = ""
) -> dict:
    """Send mass interview invitation card to Feishu.

    Args:
        chat_id: Feishu chat ID (can be empty string for link-only mode)
        candidate_name: Candidate's name
        role: Job role name
        interview_url: Full URL to the interview page
        expires_at: Expiration time string
    """
    if not chat_id:
        return {"status": "skipped", "reason": "no_chat_id"}

    co_name = company_name or "锅圈食汇"
    card = {
        "config": {"wide_screen_mode": True},
        "header": {
            "title": {"tag": "plain_text", "content": f"📋 {co_name}面试邀请 — {role}"},
            "template": "blue",
        },
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": (
                        f"**{candidate_name}** 你好，\n\n"
                        f"恭喜你通过简历筛选！请点击下方按钮完成AI面试。\n\n"
                        f"**岗位**：{role}\n"
                        f"**时长**：约15分钟\n"
                        f"**截止时间**：{expires_at}\n\n"
                        f"💡 建议在安静的环境中完成面试，用手机即可。"
                    ),
                },
            },
            {
                "tag": "action",
                "actions": [
                    {
                        "tag": "button",
                        "text": {"tag": "plain_text", "content": "🎙️ 开始面试"},
                        "url": interview_url,
                        "type": "primary",
                    }
                ],
            },
        ],
    }

    return _send_card(chat_id, card)
