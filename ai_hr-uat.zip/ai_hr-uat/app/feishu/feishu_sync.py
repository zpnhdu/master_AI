"""Feishu OpenAPI client — token 获取与鉴权请求。

仅保留被 feishu_notify 复用的 token 缓存与请求封装；文档/wiki 抓取同步方法
从未接入生产链路（无调用方），已移除，历史实现见 git 历史。

Requires:
- FEISHU_APP_ID and FEISHU_APP_SECRET in config/environments/.env.{APP_ENV}
"""

import json
import logging
import os
import time
import urllib.parse
import urllib.request
from typing import Optional

logger = logging.getLogger("app.feishu_sync")

BASE_URL = "https://open.feishu.cn/open-apis"


class FeishuSync:
    """Feishu tenant token 缓存与鉴权请求封装。"""

    def __init__(self):
        self.app_id = os.getenv("FEISHU_APP_ID", "")
        self.app_secret = os.getenv("FEISHU_APP_SECRET", "")
        self._token: str = ""
        self._token_expires: float = 0.0

        if not self.app_id or not self.app_secret:
            logger.warning("FEISHU_APP_ID/FEISHU_APP_SECRET not configured")

    def _get_token(self) -> str:
        """Get or refresh tenant access token."""
        if self._token and time.time() < self._token_expires - 120:
            return self._token

        if not self.app_id or not self.app_secret:
            raise RuntimeError("Feishu credentials not configured")

        req = urllib.request.Request(
            f"{BASE_URL}/auth/v3/tenant_access_token/internal",
            data=json.dumps(
                {
                    "app_id": self.app_id,
                    "app_secret": self.app_secret,
                }
            ).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json; charset=utf-8"},
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))

        if result.get("code") != 0:
            raise RuntimeError(f"Failed to get Feishu token: {result}")

        self._token = result["tenant_access_token"]
        self._token_expires = time.time() + int(result.get("expire", 7200))
        return self._token

    def _api_get(self, path: str, params: Optional[dict] = None) -> dict:
        """Authenticated GET request."""
        token = self._get_token()
        url = f"{BASE_URL}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params)

        req = urllib.request.Request(
            url,
            method="GET",
            headers={"Authorization": f"Bearer {token}"},
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))

        if result.get("code") not in (None, 0):
            raise RuntimeError(f"Feishu API error: {path} -> {result}")
        return result

    def is_configured(self) -> bool:
        """Check if Feishu credentials are configured."""
        return bool(self.app_id and self.app_secret)


# 单例实例
_sync_instance: Optional[FeishuSync] = None


def get_feishu_sync() -> FeishuSync:
    """Get global FeishuSync instance."""
    global _sync_instance
    if _sync_instance is None:
        _sync_instance = FeishuSync()
    return _sync_instance
