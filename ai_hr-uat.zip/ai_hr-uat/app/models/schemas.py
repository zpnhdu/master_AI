"""Pydantic request/response models shared across interview routes."""

from pydantic import BaseModel
from typing import Optional


class PipelineRequest(BaseModel):
    role: str
    hints: str = ""
    quiz_answers: list = []
    type: str = "tech"
    enabled_agents: list = []
    agents: list = []
    screen_template_id: str = ""


class JDEditRequest(BaseModel):
    pipeline_id: str
    jd: dict


class CandidateActionRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    action: str  # 操作：shortlist、reject、interview
    reason: str = ""


class AssessmentRequest(BaseModel):
    candidate_id: str
    candidate_name: str = ""
    dimensions: dict[str, int] = {}
    highlights: str = ""
    concerns: str = ""
    recommendation: str = ""


class InterviewAnswerRequest(BaseModel):
    candidate_id: str
    candidate_name: str = ""
    interviewer: str = ""
    interview_date: str = ""
    answers: list[dict] = []


class QuizRequest(BaseModel):
    role: str
    hints: str = ""
    mock: bool = False


class UpdateAgentsRequest(BaseModel):
    enabled_agents: list  # stage_id 字符串列表


class PassArtifactRequest(BaseModel):
    from_agent: str = ""
    to_agent: str = ""
    artifacts: dict = {}


class BatchResumeImportRequest(BaseModel):
    resumes: list[dict]  # 解析后的简历字典列表


class SubmitAnswersRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    answers: list


class ReevaluateRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    previous_score: float = 0.0


class QuickEvaluateRequest(BaseModel):
    pipeline_id: str
    candidate_id: str


class ActionRequest(BaseModel):
    type: str
    pipeline_id: str = ""
    data: dict = {}


class ResumeImportRequest(BaseModel):
    pipeline_id: str
    candidates: list  # Chrome 扩展传入的候选人字典列表
    source: str = "chrome_extension"


class BatchDeleteRequest(BaseModel):
    pipeline_ids: list[str]


class InterviewScheduleRequest(BaseModel):
    candidate_id: str
    candidate_name: str = ""
    date: str
    time: str
    interviewer: str = ""
    method: str = "online"
    round: str = "一面"
    notes: str = ""


class GenerateCommRequest(BaseModel):
    pipeline_id: str
    candidate_id: str = ""
    step: str = "initial"


class OntologyRuleUpdate(BaseModel):
    pipeline_id: str = ""
    node_id: str
    rule_id: str
    updates: dict


class OntologyWeightsUpdate(BaseModel):
    pipeline_id: str = ""
    weights: dict


class MemoryToggleRequest(BaseModel):
    memory_id: str
    is_active: bool


class MemoryResetRequest(BaseModel):
    pipeline_id: str = ""
    scope: str = "pipeline"  # 范围：pipeline / all


class AgentConfigUpdateRequest(BaseModel):
    model: Optional[str] = None
    complexity: Optional[str] = None
    temperature: Optional[float] = None
    timeout: Optional[int] = None
    retry_count: Optional[int] = None
    enabled: Optional[bool] = None
    human_approval: Optional[bool] = None
