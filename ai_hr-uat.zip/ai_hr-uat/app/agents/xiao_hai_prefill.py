"""Map pipeline JD / company config into Xiao Hai studio fields."""

from __future__ import annotations

from typing import Any

DEFAULT_COMPANY_NAME = "锅圈食汇"


def _as_list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        # 简单支持换行符以及中英文分隔符
        if "\n" in text:
            return [line.strip("- •\t ") for line in text.splitlines() if line.strip()]
        return [text]
    return [str(value)]


def map_studio_fields(
    *,
    pipeline: dict | None,
    jd: dict | None,
    company: dict | None = None,
    poster_data: dict | None = None,
) -> dict:
    """Build studio field payload from upstream stages.

    - Missing pipeline raises ValueError
    - Missing/empty JD still returns editable fields with jd_ready=False
    """
    if not pipeline:
        raise ValueError("pipeline is required")

    jd = jd or {}
    company = company or {}
    poster_data = poster_data or {}

    responsibilities = _as_list(jd.get("responsibilities"))
    requirements = _as_list(jd.get("requirements"))
    highlights = _as_list(jd.get("highlights") or jd.get("selling_points"))
    benefits = _as_list(jd.get("benefits"))

    job_title = (jd.get("title") or pipeline.get("role") or "").strip()
    company_name = (
        (jd.get("company_name") or "").strip() or (company.get("company_name") or "").strip() or DEFAULT_COMPANY_NAME
    )

    # 存在标题或任意有效 JD 内容时视为 jd_ready
    jd_ready = bool(
        (jd.get("title") or "").strip()
        or responsibilities
        or requirements
        or highlights
        or benefits
        or (jd.get("salary_range") or "").strip()
        or (jd.get("location") or "").strip()
    )

    fields = {
        "jobTitle": job_title,
        "companyName": company_name,
        "salary": (jd.get("salary_range") or poster_data.get("salary") or "").strip(),
        "location": (jd.get("location") or poster_data.get("location") or "").strip(),
        "deliveryLink": (poster_data.get("delivery_link") or poster_data.get("deliveryLink") or "").strip(),
        "responsibilities": responsibilities,
        "requirements": requirements,
        "highlights": highlights,
        "benefits": benefits,
        "career_growth": (jd.get("career_growth") or jd.get("careerGrowth") or "").strip(),
        "headline": (poster_data.get("headline") or "").strip(),
        "subheadline": (poster_data.get("subheadline") or "").strip(),
        "experience": (jd.get("experience") or poster_data.get("experience") or "").strip(),
        "education": (jd.get("education") or poster_data.get("education") or "").strip(),
        "employmentType": (jd.get("employment_type") or poster_data.get("employmentType") or "").strip(),
        "contactText": (poster_data.get("contactText") or "扫码投递").strip() or "扫码投递",
        "teamIntro": (jd.get("team_intro") or "").strip(),
    }

    return {
        "jd_ready": jd_ready,
        "fields": fields,
        "role": pipeline.get("role") or job_title,
        "company": {
            "company_name": company_name,
            "brand_color": company.get("brand_color") or "",
        },
    }
