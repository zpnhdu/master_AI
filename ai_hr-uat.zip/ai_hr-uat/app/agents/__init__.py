"""``app/poster_service.py``、``app/poster_progress.py``、``app/poster_generation.py``、``app/xiao_hai_branding.py``、``app/poster_delivery.py``、``app/poster_jobs.py``、``app/xiao_hai_image.py``、``app/xiao_hai_generation_jobs.py``、``app/xiao_hai_prefill.py``、``app/xiao_hai_conversation.py``、``app/xiao_mian_conversation.py``、``app/xiao_wen_context.py``、``app/xiao_wen_startup.py``、``app/screening_model.py``、``app/screening_workflow.py``（目录整理）。

原 ``app/``app/poster_service.py``, ``app/poster_progress.py``, ``app/poster_generation.py``, ``app/xiao_hai_branding.py``, ``app/poster_delivery.py``, ``app/poster_jobs.py``, ``app/xiao_hai_image.py``, ``app/xiao_hai_generation_jobs.py``, ``app/xiao_hai_prefill.py``, ``app/xiao_hai_conversation.py``, ``app/xiao_mian_conversation.py``, ``app/xiao_wen_context.py``, ``app/xiao_wen_startup.py``, ``app/screening_model.py``, ``app/screening_workflow.py```` 按 ``docs/directory-reorganization-plan.md`` 归入本包，
实现原样保留。旧导入路径 ``from app.X import y`` / ``from app import X`` /
``import app.X`` 经 sys.modules 别名与 app 包属性注册保持兼容。
"""

import importlib
import sys

_MODULES = (
    # 注册顺序按包内依赖拓扑：
    # 叶子层：poster_service / poster_progress / xiao_hai_branding（无包内依赖）
    "poster_service",
    "poster_progress",
    "xiao_hai_branding",
    # poster_delivery 依赖 xiao_hai_branding
    "poster_delivery",
    # xiao_hai_image 依赖 xiao_hai_branding；poster_generation 依赖它（pil_to_png_bytes）
    "xiao_hai_image",
    # poster_generation 依赖 poster_delivery + xiao_hai_image
    "poster_generation",
    # poster_jobs 依赖 delivery / generation / progress / service / branding
    "poster_jobs",
    "xiao_hai_generation_jobs",
    "xiao_hai_prefill",
    # xiao_hai_conversation 依赖 poster_jobs / poster_service
    "xiao_hai_conversation",
    "xiao_mian_conversation",
    "xiao_wen_context",
    "xiao_wen_startup",
    # screening_workflow 依赖 screening_model
    "screening_model",
    "screening_workflow",
)

import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    _mod = importlib.import_module("app.agents." + _name)
    # app.X 旧路径别名：指向同一模块对象，monkeypatch / 属性访问语义不变
    sys.modules.setdefault("app." + _name, _mod)
    setattr(sys.modules[__name__], _name, _mod)
    setattr(_app_pkg, _name, _mod)

__all__ = list(_MODULES)
