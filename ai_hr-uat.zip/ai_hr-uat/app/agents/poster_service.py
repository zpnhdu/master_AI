"""小海海报资产、不可变版本及阶段写回服务。"""

from __future__ import annotations

import hashlib
import io
import json
import uuid
from contextlib import nullcontext
from pathlib import Path

from PIL import Image

from app.db import create_stage, get_db, get_pipeline, get_stages, transaction, update_stage
from app.media_storage import MediaStorage, get_media_storage
from app.utils import parse_stage_output

MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_IMAGE_EDGE = 8192
ALLOWED_IMAGE_FORMATS = {"PNG", "JPEG", "WEBP"}


class PosterServiceError(ValueError):
    pass


def _json(value, fallback):
    if not isinstance(value, str):
        return value
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return fallback


class PosterService:
    def __init__(self, storage: MediaStorage | None = None):
        self.storage = storage or get_media_storage()
        self._storage_override = storage

    def create_image_asset(self, pipeline_id: str, data: bytes, *, filename: str, kind: str) -> dict:
        self._require_pipeline(pipeline_id)
        normalized, width, height = self._normalize_image(data)
        extension, mime_type = "png", "image/png"
        if kind == "brand_source":
            # Validation above is shared; snapshots retain the original bytes
            # so the source digest can be reproduced after configuration changes.
            with Image.open(io.BytesIO(data)) as source:
                extension = {"PNG": "png", "JPEG": "jpg", "WEBP": "webp"}[source.format]
            mime_type = {"png": "image/png", "jpg": "image/jpeg", "webp": "image/webp"}[extension]
            normalized = bytes(data)
            filename = str(Path(filename or "source").with_suffix(f".{extension}"))
        asset_id = f"asset_{uuid.uuid4().hex}"
        key = f"xiao-hai/{pipeline_id}/{asset_id}.{extension}"
        self.storage.write(key, normalized, mime_type)
        get_db().execute(
            """INSERT INTO media_assets
               (id, pipeline_id, kind, storage_backend, storage_key, filename, mime_type,
                byte_size, width, height, sha256, metadata)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, '{}')""",
            (
                asset_id,
                pipeline_id,
                kind,
                self.storage.backend,
                key,
                Path(filename or "image.png").name,
                mime_type,
                len(normalized),
                width,
                height,
                hashlib.sha256(normalized).hexdigest(),
            ),
        )
        get_db().commit()
        return self.get_asset(pipeline_id, asset_id)

    def get_asset(self, pipeline_id: str, asset_id: str) -> dict:
        row = (
            get_db()
            .execute(
                "SELECT * FROM media_assets WHERE id=%s AND pipeline_id=%s",
                (asset_id, pipeline_id),
            )
            .fetchone()
        )
        if not row:
            raise PosterServiceError("媒体资产不存在")
        asset = dict(row)
        asset["metadata"] = _json(asset.get("metadata"), {})
        asset["url"] = f"/api/xiao-hai/{pipeline_id}/assets/{asset_id}"
        return asset

    def read_asset(self, pipeline_id: str, asset_id: str) -> tuple[dict, bytes]:
        asset = self.get_asset(pipeline_id, asset_id)
        storage = self._storage_override or get_media_storage(asset["storage_backend"])
        if not storage.exists(asset["storage_key"]):
            raise PosterServiceError("媒体文件不存在")
        return asset, storage.read(asset["storage_key"])

    def create_version(
        self,
        pipeline_id: str,
        *,
        image_asset_id: str = "",
        canvas_id: str,
        parent_version_id: str = "",
        reference_asset_ids: list[str] | None = None,
        reference_usage: str = "",
        fields: dict | None = None,
        instruction: str = "",
        source: str = "generated",
        provider: str = "",
        model: str = "",
        render_data: dict | None = None,
        generation_job_id: str | None = None,
        on_saved=None,
    ) -> dict:
        self._require_pipeline(pipeline_id)
        image_asset = self.get_asset(pipeline_id, image_asset_id) if image_asset_id else None
        parent = self.get_version(pipeline_id, parent_version_id) if parent_version_id else None
        references = reference_asset_ids or []
        for reference_id in references:
            self.get_asset(pipeline_id, reference_id)
        version_id = f"poster_version_{uuid.uuid4().hex}"
        with transaction() as conn:
            # Serialize numbering per pipeline, including simultaneous generations.
            conn.execute("SELECT id FROM pipelines WHERE id=%s FOR UPDATE", (pipeline_id,)).fetchone()
            if generation_job_id:
                from app.poster_progress import require_running

                job = require_running(generation_job_id, conn)
                if job["pipeline_id"] != pipeline_id:
                    raise PosterServiceError("生成任务不属于当前流程")
            version_number = conn.execute(
                "SELECT COALESCE(MAX(version_number), 0) + 1 AS n FROM poster_versions WHERE pipeline_id=%s",
                (pipeline_id,),
            ).fetchone()["n"]
            conn.execute(
                """INSERT INTO poster_versions
                   (id, pipeline_id, version_number, parent_version_id, image_asset_id, source, canvas_id, width, height,
                    fields, instruction, reference_asset_ids, reference_usage, provider, model, render_data)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (
                    version_id,
                    pipeline_id,
                    version_number,
                    parent["id"] if parent else None,
                    image_asset["id"] if image_asset else None,
                    source,
                    canvas_id,
                    image_asset["width"] if image_asset else 0,
                    image_asset["height"] if image_asset else 0,
                    json.dumps(fields or {}, ensure_ascii=False),
                    instruction,
                    json.dumps(references, ensure_ascii=False),
                    reference_usage,
                    provider,
                    model,
                    json.dumps(render_data or {}, ensure_ascii=False),
                ),
            )
            if generation_job_id:
                from app.poster_progress import complete_in_transaction

                if on_saved:
                    on_saved(conn, self.get_version(pipeline_id, version_id))
                complete_in_transaction(conn, generation_job_id, pipeline_id, version_id)
        return self.get_version(pipeline_id, version_id)

    def get_version(self, pipeline_id: str, version_id: str) -> dict:
        row = (
            get_db()
            .execute(
                "SELECT * FROM poster_versions WHERE id=%s AND pipeline_id=%s",
                (version_id, pipeline_id),
            )
            .fetchone()
        )
        if not row:
            raise PosterServiceError("海报版本不存在")
        return self._parse_version(dict(row))

    def list_versions(self, pipeline_id: str, limit: int = 100) -> list[dict]:
        rows = (
            get_db()
            .execute(
                """SELECT * FROM poster_versions WHERE pipeline_id=%s
               ORDER BY version_number DESC LIMIT %s""",
                (pipeline_id, max(1, min(limit, 200))),
            )
            .fetchall()
        )
        return [self._parse_version(dict(row)) for row in rows]

    def select_version(self, pipeline_id: str, version_id: str, *, conn=None) -> dict:
        self.get_version(pipeline_id, version_id)
        with nullcontext(conn) if conn else transaction() as db:
            db.execute(
                "UPDATE poster_versions SET status='draft', selected_at=NULL WHERE pipeline_id=%s AND status='selected'",
                (pipeline_id,),
            )
            db.execute(
                "UPDATE poster_versions SET status='selected', selected_at=NOW() WHERE id=%s",
                (version_id,),
            )
        selected = self.get_version(pipeline_id, version_id)
        self._write_stage_selection(pipeline_id, selected, conn=conn)
        return selected

    def approve_version(self, pipeline_id: str, version_id: str) -> dict:
        version = self.get_version(pipeline_id, version_id)
        if not version.get("image_asset_id"):
            raise PosterServiceError("当前海报版本缺少图片资产")
        selected = self.select_version(pipeline_id, version_id)
        get_db().execute(
            "UPDATE poster_versions SET approved_at=NOW() WHERE id=%s AND pipeline_id=%s",
            (selected["id"], pipeline_id),
        )
        get_db().commit()
        approved = self.get_version(pipeline_id, version_id)
        self._write_stage_selection(pipeline_id, approved)
        return approved

    def _write_stage_selection(self, pipeline_id: str, version: dict, *, conn=None) -> None:
        stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "poster_gen"), None)
        output = parse_stage_output(stage)
        output.update(
            {
                "status": "approved" if version.get("approved_at") else "generated",
                "selected_version_id": version["id"],
                "selected_image_id": version.get("image_asset_id") or output.get("selected_image_id", ""),
                "approval_status": "approved" if version.get("approved_at") else "pending",
                "approved_version_id": version["id"] if version.get("approved_at") else "",
                "version": version,
            }
        )
        if not stage:
            create_stage(pipeline_id, "poster_gen", "招聘海报", conn=conn)
        stage_status = "done" if version.get("approved_at") else "waiting_human"
        update_stage(pipeline_id, "poster_gen", stage_status, output, conn=conn)

    def _parse_version(self, version: dict) -> dict:
        version["fields"] = _json(version.get("fields"), {})
        version["reference_asset_ids"] = _json(version.get("reference_asset_ids"), [])
        version["render_data"] = _json(version.get("render_data"), {})
        # 向前兼容：旧版本无 mode/version 字段时自动补全
        rd = version["render_data"]
        if "mode" not in rd:
            rd["mode"] = "layered" if rd.get("background_asset_id") else "flattened"
        if "version" not in rd:
            rd["version"] = 1
        if version.get("image_asset_id"):
            version["image_url"] = f"/api/xiao-hai/{version['pipeline_id']}/assets/{version['image_asset_id']}"
        else:
            version["image_url"] = ""
        return version

    @staticmethod
    def _normalize_image(data: bytes) -> tuple[bytes, int, int]:
        if not data or len(data) > MAX_IMAGE_BYTES:
            raise PosterServiceError("图片为空或超过10MB")
        try:
            with Image.open(io.BytesIO(data)) as image:
                image.load()
                if image.format not in ALLOWED_IMAGE_FORMATS:
                    raise PosterServiceError("仅支持 PNG、JPEG、WebP")
                width, height = image.size
                if width <= 0 or height <= 0 or max(width, height) > MAX_IMAGE_EDGE:
                    raise PosterServiceError("图片尺寸无效或超过8192像素")
                normalized = image.convert("RGBA")
                output = io.BytesIO()
                normalized.save(output, format="PNG", optimize=True)
                return output.getvalue(), width, height
        except PosterServiceError:
            raise
        except Exception as exc:
            raise PosterServiceError("无法解析图片") from exc

    @staticmethod
    def _require_pipeline(pipeline_id: str) -> None:
        if not get_pipeline(pipeline_id):
            raise PosterServiceError("流水线不存在")
