"""小海直接生成任务的持久化、状态查询与后台执行。"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid

from app.db import get_db
from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline, get_poster_generation_timeout

logger = logging.getLogger(__name__)

TERMINAL_STATUSES = {"succeeded", "failed", "cancelled"}
ACTIVE_STATUSES = {"queued", "running", "cancel_requested"}
_ACTIVE_TASKS: set[asyncio.Task] = set()


def _decode_json(value: str | dict | None, fallback):
    if isinstance(value, dict):
        return value
    try:
        decoded = json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return fallback
    return decoded if isinstance(decoded, type(fallback)) else fallback


def _public_job(job: dict) -> dict:
    return {
        key: job.get(key)
        for key in (
            "id",
            "pipeline_id",
            "client_request_id",
            "status",
            "stage",
            "progress",
            "result_version_id",
            "result_payload",
            "error_code",
            "error_message",
            "created_at",
            "started_at",
            "updated_at",
            "completed_at",
        )
    }


def _row_to_job(row) -> dict | None:
    if not row:
        return None
    job = dict(row)
    job["request_payload"] = _decode_json(job.get("request_payload"), {})
    job["result_payload"] = _decode_json(job.get("result_payload"), {})
    return job


def create_generation_job(pipeline_id: str, client_request_id: str, payload: dict) -> tuple[dict, bool]:
    """Create one idempotent direct-generation job for a pipeline/request pair."""
    normalized_request_id = str(client_request_id or uuid.uuid4().hex).strip()[:191]
    conn = get_db()
    existing = conn.execute(
        "SELECT * FROM xiao_hai_generation_jobs WHERE pipeline_id=%s AND client_request_id=%s",
        (pipeline_id, normalized_request_id),
    ).fetchone()
    if existing:
        return _row_to_job(existing), False

    job_id = f"xiao_hai_job_{uuid.uuid4().hex}"
    conn.execute(
        """INSERT IGNORE INTO xiao_hai_generation_jobs
           (id, pipeline_id, client_request_id, request_payload, result_payload)
           VALUES (%s, %s, %s, %s, %s)""",
        (job_id, pipeline_id, normalized_request_id, json.dumps(payload, ensure_ascii=False), "{}"),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM xiao_hai_generation_jobs WHERE id=%s", (job_id,)).fetchone()
    if not row:
        row = conn.execute(
            "SELECT * FROM xiao_hai_generation_jobs WHERE pipeline_id=%s AND client_request_id=%s",
            (pipeline_id, normalized_request_id),
        ).fetchone()
        return _row_to_job(row), False
    return _row_to_job(row), bool(row and row["id"] == job_id)


def get_generation_job(pipeline_id: str, job_id: str) -> dict | None:
    row = (
        get_db()
        .execute(
            "SELECT * FROM xiao_hai_generation_jobs WHERE pipeline_id=%s AND id=%s",
            (pipeline_id, job_id),
        )
        .fetchone()
    )
    return _row_to_job(row)


def list_generation_jobs(pipeline_id: str, limit: int = 10) -> list[dict]:
    rows = (
        get_db()
        .execute(
            "SELECT * FROM xiao_hai_generation_jobs WHERE pipeline_id=%s ORDER BY created_at DESC, id DESC LIMIT %s",
            (pipeline_id, max(1, min(limit, 50))),
        )
        .fetchall()
    )
    return [_row_to_job(row) for row in rows]


def update_generation_job(job_id: str, **updates) -> dict | None:
    allowed = {
        "status",
        "stage",
        "progress",
        "result_version_id",
        "result_payload",
        "error_code",
        "error_message",
    }
    assignments = []
    values = []
    for key, value in updates.items():
        if key not in allowed:
            continue
        assignments.append(f"{key}=%s")
        values.append(json.dumps(value, ensure_ascii=False) if key == "result_payload" else value)
    if not assignments:
        return get_generation_job_by_id(job_id)
    if updates.get("status") == "running":
        assignments.append("started_at=NOW()")
    if updates.get("status") in TERMINAL_STATUSES:
        assignments.append("completed_at=NOW()")
    assignments.append("updated_at=NOW()")
    values.append(job_id)
    conn = get_db()
    conn.execute(f"UPDATE xiao_hai_generation_jobs SET {', '.join(assignments)} WHERE id=%s", values)
    conn.commit()
    return get_generation_job_by_id(job_id)


def get_generation_job_by_id(job_id: str) -> dict | None:
    row = get_db().execute("SELECT * FROM xiao_hai_generation_jobs WHERE id=%s", (job_id,)).fetchone()
    return _row_to_job(row)


def cancel_generation_job(pipeline_id: str, job_id: str) -> bool:
    conn = get_db()
    cursor = conn.execute(
        """UPDATE xiao_hai_generation_jobs
           SET status=CASE WHEN status='queued' THEN 'cancelled' ELSE 'cancel_requested' END,
               stage=CASE WHEN status='queued' THEN 'cancelled' ELSE stage END,
               error_code='cancelled_by_user',
               error_message='任务已取消',
               completed_at=CASE WHEN status='queued' THEN NOW() ELSE completed_at END,
               updated_at=NOW()
           WHERE pipeline_id=%s AND id=%s AND status IN ('queued', 'running')""",
        (pipeline_id, job_id),
    )
    conn.commit()
    return cursor.rowcount == 1


def _claim_generation_job(job_id: str) -> bool:
    conn = get_db()
    cursor = conn.execute(
        """UPDATE xiao_hai_generation_jobs
           SET status='running', stage='preparing', progress=5,
               started_at=NOW(), updated_at=NOW()
           WHERE id=%s AND status='queued'""",
        (job_id,),
    )
    conn.commit()
    return cursor.rowcount == 1


def _update_progress(job_id: str, progress: int, stage: str) -> None:
    update_generation_job(job_id, progress=max(0, min(progress, 99)), stage=stage)


def run_generation_job(job_id: str) -> None:
    """Run a persisted job outside the request event loop."""
    job = get_generation_job_by_id(job_id)
    if not job or not _claim_generation_job(job_id):
        return

    deadline = TimeoutDeadline(get_poster_generation_timeout(), agent_id="poster_gen")

    def progress_callback(progress: int, stage: str) -> None:
        _update_progress(job_id, progress, stage)

    from app.audit.llm_trace import llm_trace_context, record_trace_step
    from app.routers.xiao_hai import _run_unified_generation_payload

    async def execute():
        return await asyncio.wait_for(
            _run_unified_generation_payload(
                job["pipeline_id"],
                job["request_payload"],
                deadline=deadline,
                progress_callback=progress_callback,
            ),
            timeout=deadline.require_remaining(),
        )

    started_at = time.monotonic()
    with llm_trace_context("poster_generate", pipeline_id=job["pipeline_id"]):
        try:
            result = asyncio.run(execute())
            current = get_generation_job_by_id(job_id)
            if current and current["status"] == "cancel_requested":
                record_trace_step(
                    "generate_poster",
                    model="gpt-image-2",
                    status="cancelled",
                    latency_ms=int((time.monotonic() - started_at) * 1000),
                )
                update_generation_job(
                    job_id,
                    status="cancelled",
                    stage="cancelled",
                    error_code="cancelled_by_user",
                    error_message="任务已取消",
                )
                return
            record_trace_step(
                "generate_poster",
                model="gpt-image-2",
                latency_ms=int((time.monotonic() - started_at) * 1000),
            )
            update_generation_job(
                job_id,
                status="succeeded",
                stage="completed",
                progress=100,
                result_version_id=result.get("version_id", ""),
                result_payload=result,
                error_code="",
                error_message="",
            )
        except (asyncio.TimeoutError, BusinessTimeoutError) as error:
            record_trace_step(
                "generate_poster",
                model="gpt-image-2",
                status=f"error: {str(error)[:200]}",
                latency_ms=int((time.monotonic() - started_at) * 1000),
            )
            update_generation_job(
                job_id,
                status="failed",
                stage="failed",
                error_code="backend_timeout",
                error_message=str(error) or "任务执行超时",
            )
            from app.routers.xiao_hai import _mark_poster_timeout

            _mark_poster_timeout(job["pipeline_id"], deadline)
        except Exception as error:  # noqa: BLE001
            from fastapi import HTTPException

            code = "generation_failed"
            message = str(error)[:500]
            if isinstance(error, HTTPException):
                code = f"http_{error.status_code}"
                message = str(error.detail)[:500]
            logger.exception("Xiao Hai generation job failed: %s", job_id)
            record_trace_step(
                "generate_poster",
                model="gpt-image-2",
                status=f"error: {str(error)[:200]}",
                latency_ms=int((time.monotonic() - started_at) * 1000),
            )
            update_generation_job(
                job_id,
                status="failed",
                stage="failed",
                error_code=code,
                error_message=message,
            )


def schedule_generation_job(job_id: str) -> None:
    task = asyncio.create_task(asyncio.to_thread(run_generation_job, job_id))
    _ACTIVE_TASKS.add(task)
    task.add_done_callback(_ACTIVE_TASKS.discard)


def public_generation_job(job: dict) -> dict:
    return _public_job(job)
