"""Shared runtime context for Xiao Wen's JD and profile workflows."""

from __future__ import annotations

from typing import Any

RUNTIME_CONTEXT_KEYS = {"kg_context", "company_config"}
XIAO_WEN_MODEL = "qwen-plus"
XIAO_WEN_STAGE_IDS = {"jd_write", "jd_writer", "profile_build"}


def merge_runtime_context(base: dict[str, Any], runtime_values: dict[str, Any] | None) -> dict[str, Any]:
    """Merge only runtime-only values into an Agent context."""
    values = runtime_values or {}
    return {
        **base,
        **{key: value for key, value in values.items() if key in RUNTIME_CONTEXT_KEYS},
    }


def _load_kg_context(role: str) -> dict:
    try:
        from kg.core import get_knowledge_graph

        return get_knowledge_graph().traverse_for_role(role, depth=2, max_tokens=500)
    except Exception:
        return {}


def build_xiao_wen_context(
    pipeline_id: str,
    role: str,
    pipeline_type: str = "general",
    user_hints: str = "",
    location_hint: str = "",
    quiz_answers: list | None = None,
    memory_context: str = "",
    runtime_values: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the common context used by every Xiao Wen entry point."""
    values = dict(runtime_values or {})
    if "company_config" not in values:
        from app.db import get_company_config

        values["company_config"] = get_company_config()
    if "kg_context" not in values:
        values["kg_context"] = _load_kg_context(role)

    base = {
        "role": role,
        "pipeline_type": pipeline_type or "general",
        "user_hints": user_hints,
        "location_hint": location_hint,
        "quiz_answers": quiz_answers or [],
        "memory_context": memory_context,
        "pipeline_id": pipeline_id,
        "profile_id": pipeline_id,
    }
    return merge_runtime_context(base, values)


def attach_agent_runtime_config(context: dict[str, Any], agent_id: str) -> dict[str, Any]:
    """Apply the database Agent configuration to a direct Agent invocation."""
    from app.db import get_agent_config

    config = get_agent_config(agent_id) or {}
    configured = dict(context)
    if agent_id in XIAO_WEN_STAGE_IDS:
        configured["model"] = XIAO_WEN_MODEL
    for key in ("complexity", "temperature"):
        if config.get(key) is not None:
            configured[key] = config[key]
    configured["llm_max_retries"] = min(int(config.get("retry_count", 1) or 0), 1)
    return configured
