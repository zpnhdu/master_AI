"""Compose a model-owned body and a program-owned, verified application footer.

QR pixels always come from the uploaded asset. Decoder output is used for
validation and geometry only; it is never used to generate a replacement code.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import asdict, dataclass, field

import numpy as np
from PIL import Image, ImageDraw

from app.template_compositor import load_font
from app.xiao_hai_branding import (
    STOCK_CODE,
    PosterBrandAssets,
    PosterBrandingError,
    _brand_boxes,
    _canvas_config,
    _open_raw_image,
    _paste_logo,
    validate_brand_image,
)

LAYOUT_VERSION = 5
FOOTER_COLOR = (11, 143, 54)
QR_RATIOS = (0.18, 0.20, 0.22, 0.24)
EMAIL_FONT_RATIO = 0.038
EMAIL_MIN_FONT_RATIO = 0.030
CONTACT_FONT_RATIO = 0.78


@dataclass(frozen=True)
class Box:
    x: int
    y: int
    w: int
    h: int

    @property
    def bounds(self) -> tuple[int, int, int, int]:
        return self.x, self.y, self.x + self.w, self.y + self.h


@dataclass(frozen=True)
class VerifiedQr:
    core: Image.Image = field(repr=False)
    payload: str = field(repr=False)
    modules: int
    source_sha256: str

    def tile(self, desired_size: int) -> Image.Image:
        # Integer module pitches avoid alternating widths and unnecessary mats.
        pitch = max(1, round(desired_size / (self.modules + 8)))
        size = (self.modules + 8) * pitch
        tile = Image.new("RGB", (size, size), "white")
        code_size = self.modules * pitch
        core = self.core.resize((code_size, code_size), Image.Resampling.NEAREST)
        tile.paste(core, (4 * pitch, 4 * pitch))
        return tile


def _decode(image: Image.Image) -> tuple[list[str], object, object]:
    try:
        import cv2
    except ImportError as exc:
        raise PosterBrandingError("二维码识别依赖未安装，请安装 opencv-python-headless") from exc

    pixels = cv2.cvtColor(np.asarray(image.convert("RGB")), cv2.COLOR_RGB2BGR)
    detector = cv2.QRCodeDetector()
    try:
        _, values, points, straight = detector.detectAndDecodeMulti(pixels)
        if points is not None and len(points):
            return list(values), points, straight
        value, points, straight = detector.detectAndDecode(pixels)
        if points is not None:
            return [value], points, [straight]
    except (cv2.error, UnicodeError):
        pass
    return [], None, None


def verify_source_qr(data: bytes) -> VerifiedQr:
    original = validate_brand_image(data, label="HR 二维码")
    if original.width * original.height > 16_000_000:
        raise PosterBrandingError("HR 二维码图片过大，请上传清晰的单个二维码原图")
    white = Image.new("RGBA", original.size, "white")
    white.alpha_composite(original)
    original = white.convert("RGB")
    # A missing outer quiet zone must not prevent detecting an otherwise intact
    # code. This temporary border does not change any original code pixels.
    guard = max(32, round(min(original.size) * 0.05))
    padded = Image.new("RGB", (original.width + 2 * guard, original.height + 2 * guard), "white")
    padded.paste(original, (guard, guard))
    values, points, straight = _decode(padded)
    if points is None or len(points) != 1 or len(values) != 1 or not values[0]:
        raise PosterBrandingError("无法验证唯一的 HR 二维码，请上传清晰的单个二维码原图")
    grid = straight[0] if straight is not None and len(straight) else None
    if grid is None or grid.ndim != 2 or grid.shape[0] != grid.shape[1]:
        raise PosterBrandingError("无法确认 HR 二维码模块，请上传标准二维码原图")
    modules = grid.shape[0]
    if modules < 21 or modules > 177 or (modules - 21) % 4:
        raise PosterBrandingError("暂不支持此码制，请上传标准 QR 二维码")
    corners = np.asarray(points[0], dtype=float) - guard
    pixels = np.asarray(original)
    rows, columns = np.where(np.any(pixels < 235, axis=2))
    if not len(rows):
        raise PosterBrandingError("二维码码点不可辨认，请上传清晰原图")
    # Refine decoder corners against original pixels, never against its
    # rectified/binarized output. Dense codes can have imprecise decoded corners.
    left, top = int(columns.min()), int(rows.min())
    right, bottom = int(columns.max()) + 1, int(rows.max()) + 1
    width, height = right - left, bottom - top
    expected = np.array([[left, top], [right - 1, top], [right - 1, bottom - 1], [left, bottom - 1]])
    # Do not rectify photographs: interpolation would change uploaded modules.
    tolerance = max(2, min(width, height) / modules)
    if (
        left < 0
        or top < 0
        or right > original.width
        or bottom > original.height
        or abs(width - height) > 1
        or np.max(np.abs(corners - expected)) > tolerance
    ):
        raise PosterBrandingError("二维码有倾斜或变形，请上传正向、未裁切的二维码原图")
    outside = np.ones(pixels.shape[:2], dtype=bool)
    outside[top:bottom, left:right] = False
    if np.any(pixels[outside] < 235):
        raise PosterBrandingError("二维码外含文字或装饰，无法安全裁边，请上传仅含二维码的原图")
    core = original.crop((left, top, right, bottom))
    verified = VerifiedQr(core, values[0], int(modules), hashlib.sha256(data).hexdigest())
    normalized_values, _, _ = _decode(verified.tile(max(width, height) + math.ceil(width / modules) * 8))
    if normalized_values != values:
        raise PosterBrandingError("二维码无法安全裁边，请上传清晰的二维码原图")
    return verified


@dataclass(frozen=True)
class DeliveryLayout:
    canvas_id: str
    width: int
    height: int
    body: Box
    footer: Box
    qr: Box
    text: Box
    icon: Box
    logo: Box
    email_lines: tuple[str, ...]
    contact_lines: tuple[str, ...]
    email_font_size: int
    contact_font_size: int
    line_gap: int
    group_gap: int
    ratio: float

    @property
    def model_canvas(self) -> dict:
        return {"id": self.canvas_id, "width": self.body.w, "height": self.body.h, "body_only": True}

    def metadata(self) -> dict:
        # Do not serialize text, decoder payload or image buffers to diagnostics.
        boxes = {key: asdict(getattr(self, key)) for key in ("body", "footer", "qr", "text", "icon", "logo")}
        boxes["qr"]["size"] = self.qr.w
        return {
            "canvas": {"width": self.width, "height": self.height},
            **boxes,
            "qr_ratio": self.ratio,
        }


def _wrap(value: str, font, width: int) -> tuple[str, ...]:
    draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    lines = []
    remaining = value
    while remaining:
        fit = 0
        for index in range(1, len(remaining) + 1):
            if draw.textlength(remaining[:index], font=font) > width:
                break
            fit = index
        if not fit:
            raise PosterBrandingError("投递文案无法放入安全区域，请缩短文案")
        if fit < len(remaining):
            preferred = max((i + 1 for i, char in enumerate(remaining[:fit]) if char in "@. -_"), default=0)
            if preferred:
                fit = preferred
        lines.append(remaining[:fit])
        remaining = remaining[fit:]
    return tuple(lines)


def _line_height(font) -> int:
    ascent, descent = font.getmetrics()
    return ascent + descent


def _scaled_canvas_config(canvas_id: str, width: int | None, height: int | None) -> dict:
    base = _canvas_config(canvas_id)
    if not width or not height or (width == base["width"] and height == base["height"]):
        return base

    scale_x = width / base["width"]
    scale_y = height / base["height"]
    scaled_layout = {}
    for name, box in base["layout"].items():
        scaled_box = {}
        for key, value in box.items():
            if isinstance(value, (int, float)):
                axis_scale = scale_x if key in {"x", "w", "cx"} else scale_y
                scaled_box[key] = round(value * axis_scale)
            else:
                scaled_box[key] = value
        scaled_layout[name] = scaled_box
    return {
        **base,
        "width": width,
        "height": height,
        "scale_x": width / 768,
        "scale_y": height / 1024,
        "layout": scaled_layout,
    }


def _layout(
    canvas_id: str,
    fields: dict,
    qr: VerifiedQr,
    ratio: float,
    config: dict | None = None,
) -> DeliveryLayout:
    config = config or _canvas_config(canvas_id)
    width, height = config["width"], config["height"]
    short = min(width, height)
    pad_x, pad_y, gap = round(width * 0.05), round(short * 0.025), round(short * 0.03)
    qr_size = qr.tile(round(short * ratio)).width
    icon_size = round(short * 0.04)
    text_x = pad_x + icon_size + round(short * 0.015)
    qr_x = width - pad_x - qr_size
    text_w = qr_x - gap - text_x
    email = str(fields.get("email") or "").strip()
    if not email:
        raise PosterBrandingError("投递区缺少归属 HR 联系邮箱，请先到「用户与权限」配置")
    contact = str(fields.get("contactText") or fields.get("contact_text") or "扫码投递").strip()
    if any("\n" in value or "\r" in value for value in (email, contact)) or max(len(email), len(contact)) > 1000:
        raise PosterBrandingError("投递文案过长或包含换行，请提供单行邮箱和投递提示")
    line_gap, group_gap = max(2, round(short * 0.004)), round(short * 0.01)
    for email_size in range(round(short * EMAIL_FONT_RATIO), max(15, round(short * EMAIL_MIN_FONT_RATIO)) - 1, -1):
        contact_size = max(16, round(email_size * CONTACT_FONT_RATIO))
        try:
            email_font, contact_font = load_font("bold", email_size), load_font("regular", contact_size)
        except RuntimeError as exc:
            raise PosterBrandingError("海报中文字体不可用，请安装 Noto Sans CJK 或配置项目字体") from exc
        if not hasattr(email_font, "getmetrics") or not hasattr(contact_font, "getmetrics"):
            raise PosterBrandingError("海报中文字体不可用，请配置思源黑体或系统中文字体")
        email_lines = _wrap(email, email_font, text_w)
        contact_lines = _wrap(contact, contact_font, text_w)
        text_h = (
            len(email_lines) * (_line_height(email_font) + line_gap)
            + len(contact_lines) * (_line_height(contact_font) + line_gap)
            - 2 * line_gap
            + group_gap
        )
        footer_h = max(qr_size, text_h, icon_size) + 2 * pad_y
        if footer_h <= math.floor(height * 0.28):
            body_h = height - footer_h
            logo, _ = _brand_boxes(config)
            center_y = body_h + footer_h // 2
            return DeliveryLayout(
                canvas_id,
                width,
                height,
                Box(0, 0, width, body_h),
                Box(0, body_h, width, footer_h),
                Box(qr_x, center_y - qr_size // 2, qr_size, qr_size),
                Box(text_x, center_y - text_h // 2, text_w, text_h),
                Box(pad_x, center_y - icon_size // 2, icon_size, icon_size),
                Box(**logo),
                email_lines,
                contact_lines,
                email_size,
                contact_size,
                line_gap,
                group_gap,
                ratio,
            )
    raise PosterBrandingError("投递区超过画布高度的 28%，请缩短邮箱或投递提示，或选择更大的画幅")


def _draw_footer(canvas: Image.Image, layout: DeliveryLayout, qr: VerifiedQr) -> None:
    draw = ImageDraw.Draw(canvas)
    x, y, right, bottom = layout.footer.bounds
    draw.rectangle((x, y, right - 1, bottom - 1), fill=FOOTER_COLOR)
    icon = layout.icon
    stroke = max(2, round(icon.w * 0.06))
    envelope = (icon.x, icon.y + icon.h // 6, icon.x + icon.w, icon.y + icon.h * 5 // 6)
    draw.rounded_rectangle(envelope, radius=stroke * 2, outline="white", width=stroke)
    draw.line(
        [(envelope[0], envelope[1]), (icon.x + icon.w // 2, icon.y + icon.h // 2), (envelope[2], envelope[1])],
        fill="white",
        width=stroke,
    )
    text_y = layout.text.y
    for lines, weight, size in (
        (layout.email_lines, "bold", layout.email_font_size),
        (layout.contact_lines, "regular", layout.contact_font_size),
    ):
        font = load_font(weight, size)
        for line in lines:
            draw.text((layout.text.x, text_y), line, font=font, fill="white", anchor="lt")
            text_y += _line_height(font) + layout.line_gap
        text_y += layout.group_gap - layout.line_gap
    canvas.paste(qr.tile(layout.qr.w), (layout.qr.x, layout.qr.y))


def _valid_output(image: Image.Image, qr: VerifiedQr) -> bool:
    for sample in (image, image.resize((720, round(image.height * 720 / image.width)), Image.Resampling.LANCZOS)):
        values, points, _ = _decode(sample)
        if points is None or len(points) != 1 or values != [qr.payload]:
            return False
    return True


@dataclass(frozen=True)
class PosterComposition:
    assets: PosterBrandAssets = field(repr=False)
    qr: VerifiedQr = field(repr=False)
    layouts: tuple[DeliveryLayout, ...]

    @property
    def layout(self) -> DeliveryLayout:
        return self.layouts[0]


def prepare_composition(
    assets: PosterBrandAssets,
    canvas_id: str,
    fields: dict,
    *,
    width: int | None = None,
    height: int | None = None,
) -> PosterComposition:
    qr = verify_source_qr(assets.qr_bytes)
    config = _scaled_canvas_config(canvas_id, width, height)
    layouts = []
    for ratio in QR_RATIOS:
        try:
            layout = _layout(canvas_id, fields, qr, ratio, config=config)
        except PosterBrandingError:
            if not layouts:
                raise
            break
        sample = Image.new("RGB", (layout.width, layout.height), FOOTER_COLOR)
        _draw_footer(sample, layout, qr)
        if _valid_output(sample, qr):
            layouts.append(layout)
    if not layouts:
        raise PosterBrandingError("二维码在当前画幅及 720px 预览中无法可靠识别，请换清晰原图或更大画幅")
    return PosterComposition(assets, qr, tuple(layouts))


def body_brand_prompt(layout: DeliveryLayout) -> str:
    logo = layout.logo
    _, stock = _brand_boxes(_canvas_config(layout.canvas_id))
    stock["x"] = layout.body.w - max(24, logo.x) - stock["w"]
    return f"""BODY-ONLY LAYOUT: {layout.body.w} x {layout.body.h} px; origin at top-left.
The model owns only the recruitment body. The program appends the entire application footer separately.
Do not draw contact text, email, QR codes, QR placeholders, blank QR cards or a delivery bar anywhere.
The reference is a style guide; remove any old footer, QR or contact details and reflow the body.
The reference Logo is a placement guide only: do not redraw, recolor or duplicate it.
Do not retype, stretch, rotate, outline or shadow it. In your OUTPUT, remove the reference Logo;
the program restores the original colors and lettering after generation. Do not add a background card.
Reserve natural continuous background at x={logo.x}, y={logo.y}, width={logo.w}, height={logo.h} px
({logo.x / layout.body.w:.2%} left, {logo.y / layout.body.h:.2%} top).
Keep headlines, letters, signage and decoration at least 12 px clear of the Logo area.
These bounds take priority over old reference layouts and instructions to preserve their text positions.
Reflow any conflicting content around the Logo area instead of shrinking the reserved area.
Render exactly once at x={stock["x"]}, y={stock["y"]}, width={stock["w"]}, height={stock["h"]} px:
股票代码：{STOCK_CODE}
Only the original Logo will be restored inside the body after generation.
"""


def compose_poster_body(raw_image: Image.Image | bytes, composition: PosterComposition) -> tuple[Image.Image, dict]:
    raw = _open_raw_image(raw_image).convert("RGB")
    for layout in composition.layouts:
        # Contain, never cover/crop. Footer is appended outside the fitted body.
        scale = min(layout.body.w / raw.width, layout.body.h / raw.height)
        fitted = raw.resize(
            (max(1, round(raw.width * scale)), max(1, round(raw.height * scale))), Image.Resampling.LANCZOS
        )
        offset_x, offset_y = (layout.body.w - fitted.width) // 2, (layout.body.h - fitted.height) // 2
        color = raw.getpixel((0, 0))
        canvas = Image.new("RGB", (layout.width, layout.height), color)
        canvas.paste(fitted, (offset_x, offset_y))
        requested = composition.layout
        sx, sy = fitted.width / requested.body.w, fitted.height / requested.body.h
        logo = requested.logo
        logo_box = Box(
            round(offset_x + logo.x * sx),
            round(offset_y + logo.y * sy),
            max(1, round(logo.w * sx)),
            max(1, round(logo.h * sy)),
        )
        rgba = canvas.convert("RGBA")
        _paste_logo(rgba, validate_brand_image(composition.assets.logo_bytes, label="Logo"), asdict(logo_box))
        canvas = rgba.convert("RGB")
        _draw_footer(canvas, layout, composition.qr)
        if _valid_output(canvas, composition.qr):
            geometry = layout.metadata()
            geometry["logo"] = asdict(logo_box)
            geometry["body_image"] = asdict(Box(offset_x, offset_y, fitted.width, fitted.height))
            return canvas, {
                "composition_mode": "body_with_delivery",
                "brand_layout_version": LAYOUT_VERSION,
                "delivery_layout": geometry,
                "qr_validation": {"source": True, "native": True, "preview_720": True},
                "qr_source_sha256": composition.qr.source_sha256,
                "logo_source_sha256": hashlib.sha256(composition.assets.logo_bytes).hexdigest(),
                "brand_overlays": ["company_logo", "delivery_footer", "hr_qr_code"],
                "contact_rendered_by_program": True,
            }
    raise PosterBrandingError("海报二维码校验失败（可能含额外二维码或预览不可识别），未保存为成功版本")


def save_brand_snapshots(service, pipeline_id: str, assets: PosterBrandAssets) -> dict:
    """Persist immutable bytes before the provider call, not mutable config URLs."""
    result = {}
    for name, data in (("logo", assets.logo_bytes), ("qr", assets.qr_bytes)):
        asset = service.create_image_asset(pipeline_id, data, filename=f"source-{name}.png", kind="brand_source")
        result[f"{name}_source_asset_id"] = asset["id"]
    return result


def body_reference(data: bytes, version: dict) -> bytes:
    """New raw assets already contain a body. Legacy assets are style-only."""
    metadata = version.get("render_data") or {}
    if metadata.get("composition_mode") == "body_with_delivery" and metadata.get("raw_image_asset_id"):
        return data
    from app.xiao_hai_image import blur_material_reference

    # Blur the whole legacy reference, without guessing where its text ends.
    return blur_material_reference(data)
