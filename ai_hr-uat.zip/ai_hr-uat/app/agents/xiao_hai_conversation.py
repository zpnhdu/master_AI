"""小海自然语言海报修改解析与任务入队。"""

from __future__ import annotations

import hashlib
import json
import re

from app.conversation_capabilities import ConversationCapability
from app.poster_jobs import enqueue_generation_job, list_pipeline_jobs
from app.poster_service import PosterService, PosterServiceError


def _revision(data) -> str:
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def read_latest(pipeline_id: str) -> dict:
    versions = PosterService().list_versions(pipeline_id)
    selected = next((version for version in versions if version["status"] == "selected"), None)
    jobs = list_pipeline_jobs(pipeline_id)
    data = {"versions": versions, "selected_version": selected or {}, "jobs": jobs}
    return {
        "jobs": jobs,
        "resources": [
            {
                "key": "poster_workspace",
                "revision": _revision({"versions": versions, "selected": selected}),
                "data": data,
            }
        ],
        "revision_map": {"poster_workspace": _revision(data)},
    }


def _usage(content: str) -> str:
    if _mascot_replacement_requested(content):
        return "mascot"
    if any(word in content for word in ("背景", "门店", "场景")):
        return "background"
    if any(word in content for word in ("构图", "布局", "排版")):
        return "composition"
    if any(word in content for word in ("风格", "配色", "色调")):
        return "style"
    return ""


def _target_canvas(content: str) -> str:
    mappings = (
        (("抖音横版", "横版抖音", "16:9"), "dy_h"),
        (("抖音竖版", "竖版抖音", "9:16"), "dy_v"),
        (("小红书",), "xhs"),
        (("朋友圈",), "moments"),
        (("招聘长图", "长图"), "long"),
    )
    return next((canvas_id for words, canvas_id in mappings if any(word in content for word in words)), "")


def _mascot_replacement_requested(content: str) -> bool:
    """Only explicit mascot replacement language may override the company IP."""
    text = content.replace("吉祥物", "小熊")
    return bool(
        re.search(r"(?:替换|换掉|移除|不要).{0,6}小熊", text) or re.search(r"小熊.{0,6}(?:替换|换成|移除|不要)", text)
    )


_TEXT_FIELD_LABELS = {
    "标题": "hero_title",
    "顶部主标题": "hero_kicker",
    "顶部标题": "hero_kicker",
    "顶部副标题": "hero_title",
    "副标题": "hero_title",
    "培养口号": "slogan",
    "口号": "slogan",
    "岗位名称": "jobTitle",
    "岗位": "jobTitle",
    "薪资": "salary",
    "工资": "salary",
    "工作地点": "location",
    "地点": "location",
    "公司名称": "companyName",
    "公司": "companyName",
}
_TEXT_ASSIGNMENT_PATTERN = re.compile(
    r"(?:将|把)?\s*(标题|顶部主标题|顶部标题|顶部副标题|副标题|培养口号|口号|岗位名称|岗位|薪资|工资|工作地点|地点|公司名称|公司)"
    r"\s*(?:改为|改成|修改为|调整为|换成|设置为|设为|变为)\s*"
    r"[「『“\"']?(.+?)[」』”\"']?(?=$|[，,、；;。])"
)
# 文案修改意图关键词：用户提到这些词时大概率想改文字而非重新生图
_TEXT_INTENT_KEYWORDS = (
    "文案",
    "文字",
    "内容",
    "措辞",
    "说法",
    "用语",
    "话术",
    "标题",
    "口号",
    "标语",
    "副标题",
    "主标题",
    "培养口号",
    "岗位名",
    "薪资",
    "工资",
    "地点",
    "公司名",
    "改一下",
    "换个说法",
    "优化",
    "调整",
    "缩短",
    "加长",
    "精简",
    "改短",
    "改长",
    "润色",
    "重写",
    "改写",
    "修改文案",
)


def _is_text_intent(content: str) -> bool:
    """检测用户是否在表达文案修改意图（但未给出具体赋值）。"""
    text = content.strip()
    return any(kw in text for kw in _TEXT_INTENT_KEYWORDS)


def _is_copy_refine_request(content: str) -> bool:
    text = content.strip()
    return any(keyword in text for keyword in ("精简职责", "精简岗位职责", "压缩职责", "缩短职责", "优化招聘文案"))


def _parse_text_field_patch(content: str) -> dict[str, str]:
    """Parse explicit copy assignments before handing the edit to the image model."""
    patch: dict[str, str] = {}
    for label, raw_value in _TEXT_ASSIGNMENT_PATTERN.findall(content):
        key = _TEXT_FIELD_LABELS[label]
        value = raw_value.strip().strip("「」『』“”\"'")
        value = re.sub(r"\s+", " ", value)
        if value:
            # 不在预览阶段静默截断，交由后续文案精炼保留完整用户意图。
            patch[key] = value
    return patch


def _material_context(context: dict) -> dict:
    return {
        "background_element_id": str(context.get("background_element_id") or ""),
        "element_ids": [str(item) for item in context.get("element_ids") or [] if item],
        "use_default_materials": bool(context.get("use_default_materials")),
    }


async def build_preview(
    pipeline_id: str, content: str, source: str, previous_command: dict | None, default_candidate_id: str = ""
) -> dict:
    # default_candidate_id 为小面排期/改题场景的默认上下文，小海不使用。
    previous_payload = (previous_command or {}).get("payload") or {}
    context = previous_payload.get("request_context") or previous_payload
    reference_ids = context.get("attachment_ids") or []
    service = PosterService()
    versions = service.list_versions(pipeline_id)
    selected = next((version for version in versions if version["status"] == "selected"), None)
    base_version_id = context.get("base_version_id") or (selected or {}).get("id", "")
    if not base_version_id:
        return {
            "intent": "poster_edit",
            "status": "clarifying",
            "payload": context,
            "preview": {},
            "reply": "当前没有可修改的海报，请先生成或选择一个基础版本。",
        }
    try:
        base = service.get_version(pipeline_id, base_version_id)
        for asset_id in reference_ids:
            service.get_asset(pipeline_id, asset_id)
    except PosterServiceError as error:
        raise ValueError(str(error)) from error

    fields_patch = _parse_text_field_patch(content)
    copy_refine_requested = _is_copy_refine_request(content)
    usage = _usage(content)
    target_canvas_id = _target_canvas(content)
    canvas_changed = bool(target_canvas_id and target_canvas_id != base.get("canvas_id"))
    if (fields_patch or copy_refine_requested) and not reference_ids:
        payload = {
            **_material_context(context),
            "base_version_id": base_version_id,
            "base_revision": _revision(base),
            "reference_asset_ids": [],
            "reference_usage": "text",
            "instruction": content,
            "mode": "text",
            "fields_patch": fields_patch,
            "preserve": ["brand", "layout", "qr_code"],
        }
        return {
            "intent": "poster_text_edit",
            "status": "awaiting_confirm",
            "payload": payload,
            "preview": {
                "kind": "poster_text_edit",
                "operation": "text",
                "base_version_id": base_version_id,
                "fields_patch": fields_patch,
                "instruction": content,
                "preserve": payload["preserve"],
            },
            "reply": "已识别为文字修改，正在生成新版本。",
        }

    if fields_patch and reference_ids and not usage:
        return {
            "intent": "poster_edit",
            "status": "clarifying",
            "payload": {**_material_context(context), "base_version_id": base_version_id, "fields_patch": fields_patch},
            "preview": {},
            "reply": "已识别文字修改，请再说明参考图用于替换背景、参考风格还是参考构图。",
        }

    if reference_ids and not usage:
        return {
            "intent": "poster_edit",
            "status": "clarifying",
            "payload": {**_material_context(context), "base_version_id": base_version_id},
            "preview": {},
            "reply": "请说明上传图片用于替换背景、参考风格还是参考构图。",
        }

    # 文案修改意图识别：用户想改文字但没给出具体赋值，追问引导
    # 排除已明确是背景/构图/风格修改的情况（_usage 已识别）
    if not fields_patch and not reference_ids and not usage and _is_text_intent(content):
        return {
            "intent": "poster_text_edit",
            "status": "clarifying",
            "payload": {**_material_context(context), "base_version_id": base_version_id},
            "preview": {},
            "reply": (
                "已识别为文案修改意图。请告诉我具体修改内容，例如：\n"
                "· 将顶部主标题改为「夏日薪机会」\n"
                "· 将培养口号改为「从一线到区域，晋升不绕路」\n"
                "· 将薪资改为15-20K\n"
                "请直接告诉我想修改的具体内容。"
            ),
        }

    is_mixed_edit = bool(fields_patch and reference_ids)
    mascot_policy = "replace" if usage == "mascot" else "preserve"
    preserve = ["brand", "layout", "copy", "qr_code"]
    if mascot_policy == "preserve":
        preserve.append("mascot")
    payload = {
        **_material_context(context),
        "base_version_id": base_version_id,
        "base_revision": _revision(base),
        "reference_asset_ids": reference_ids,
        "reference_usage": usage or "base",
        "instruction": content,
        "mode": "direct" if mascot_policy == "replace" else ("mixed" if is_mixed_edit else "image"),
        "fields_patch": fields_patch,
        "mascot_policy": mascot_policy,
        "preserve": preserve,
        "canvas_id": target_canvas_id or base.get("canvas_id") or "long",
    }
    return {
        "intent": "poster_mixed_edit" if is_mixed_edit else "poster_edit",
        "status": "awaiting_confirm",
        "payload": payload,
        "preview": {
            "kind": "poster_mixed_edit" if is_mixed_edit else "poster_image_edit",
            "operation": "mixed" if is_mixed_edit else "image",
            "base_version_id": base_version_id,
            "reference_asset_ids": reference_ids,
            "reference_usage": payload["reference_usage"],
            "mascot_policy": mascot_policy,
            "instruction": content,
            "preserve": payload["preserve"],
            "target_canvas_id": payload["canvas_id"],
        },
        "reply": (
            "已识别为渠道适配，正在生成目标画幅的新版本。"
            if canvas_changed
            else "已识别为背景/元素修改和文字修改，正在生成新版本。"
            if is_mixed_edit
            else "已收到修改要求，正在生成新版本。"
        ),
    }


def execute(conn, command: dict) -> tuple[bool, dict, str]:
    current = PosterService().get_version(command["pipeline_id"], command["payload"]["base_version_id"])
    if _revision(current) != command["payload"]["base_revision"]:
        return False, {}, "基础版本已变化，请重新生成预览。"
    job = enqueue_generation_job(conn, command)
    return True, {"job_id": job["id"]}, "任务已进入队列，完成后会生成新的海报版本。"


CAPABILITY = ConversationCapability(
    agent_id="xiao_hai",
    build_preview=build_preview,
    read_latest=read_latest,
    execute=execute,
)
