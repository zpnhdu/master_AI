"""Reviewable screening workflow used by the Xiao Shai workspace."""

import hashlib
import json
from contextlib import contextmanager
from datetime import datetime
from threading import Lock

from app.db import (
    create_stage,
    get_candidates,
    get_pipeline,
    get_stages,
    save_message,
    update_candidate,
    update_stage,
)
from app.screening_model import DEFAULT_SCREENING_MODEL, build_rubric, score_candidates
from app.utils import parse_stage_output

VALID_REVIEW_STATUSES = {"passed", "rejected"}
SCREENING_CACHE_VERSION = "screening-model-v3-binary-status"
_SCREENING_FIELDS = (
    "id",
    "name",
    "title",
    "current_position",
    "company",
    "current_company",
    "skills",
    "years_experience",
    "education",
    "location",
    "current_salary",
    "resume_text",
)
_SCREENING_IN_FLIGHT: set[str] = set()
_SCREENING_IN_FLIGHT_LOCK = Lock()


@contextmanager
def _screening_execution_guard(pipeline_id: str):
    with _SCREENING_IN_FLIGHT_LOCK:
        if pipeline_id in _SCREENING_IN_FLIGHT:
            raise ValueError("已有评分任务进行中")
        _SCREENING_IN_FLIGHT.add(pipeline_id)
    try:
        yield
    finally:
        with _SCREENING_IN_FLIGHT_LOCK:
            _SCREENING_IN_FLIGHT.discard(pipeline_id)


def _match_stage(pipeline_id: str):
    """Return the newest match stage when historical duplicates exist."""
    return next((stage for stage in reversed(get_stages(pipeline_id)) if stage["stage_id"] == "match"), None)


def _stage_output(stage) -> dict:
    if not stage:
        return {}
    output = stage.get("output") or {}
    if isinstance(output, dict):
        return output
    try:
        return json.loads(output)
    except (json.JSONDecodeError, TypeError):
        return {}


def _reviewable_ids(result: dict) -> set[str]:
    """Return scored candidates that have not been finally passed downstream."""
    candidates = result.get("candidates")
    if not isinstance(candidates, list):
        return set()
    confirmed_ids = set()
    for field in ("passed_ids", "shortlisted"):
        values = result.get(field)
        if not isinstance(values, list):
            continue
        confirmed_ids.update(str(item.get("id") if isinstance(item, dict) else item).strip() for item in values if item)
    return {
        str(candidate.get("id") or "").strip()
        for candidate in candidates
        if isinstance(candidate, dict)
        and candidate.get("id")
        and str(candidate.get("status") or "").strip().lower() in VALID_REVIEW_STATUSES
        and str(candidate.get("screening_decision") or "").strip().lower() != "passed"
        and str(candidate.get("id") or "").strip() not in confirmed_ids
    }


def _reviewable_count(result: dict) -> int:
    return len(_reviewable_ids(result))


def screening_contract(output: dict = None) -> dict:
    """Attach server-owned action gates to a screening response."""
    result = dict(output or {})
    status = result.get("workflow_status")
    counts = result.get("counts") if isinstance(result.get("counts"), dict) else {}
    blocking_reasons = []
    allowed_actions = []

    pending_count = int(result.get("pending_count") or 0)
    reviewable_count = _reviewable_count(result)
    result["reviewable_count"] = reviewable_count
    has_confirmed_passed = bool(
        any(isinstance(result.get(field), list) and result.get(field) for field in ("passed_ids", "shortlisted"))
    )
    if status == "confirmed":
        if has_confirmed_passed:
            allowed_actions.append("open_interview")
        else:
            blocking_reasons.append("没有确认通过筛选的候选人")
        if pending_count:
            allowed_actions.append("execute_screening")
            blocking_reasons.append(f"仍有{pending_count}位新候选人待筛查")
        if reviewable_count:
            allowed_actions.append("review_candidates")
    elif status != "review_pending":
        allowed_actions.append("execute_screening")
        blocking_reasons.append("请先执行筛选并生成结果")
    elif result.get("unscored_count"):
        allowed_actions.append("execute_screening")
        blocking_reasons.append(f"仍有{result['unscored_count']}位新候选人待筛查")
        if reviewable_count:
            allowed_actions.append("review_candidates")
    else:
        if reviewable_count:
            allowed_actions.append("review_candidates")
        allowed_actions.append("finalize_screening")

    result["allowed_actions"] = allowed_actions
    result["blocking_reasons"] = blocking_reasons
    result["next_required_action"] = allowed_actions[0] if allowed_actions else ""
    return result


def _load_inputs(pipeline_id: str) -> tuple[dict, list[dict], list[dict]]:
    if not get_pipeline(pipeline_id):
        raise ValueError("流水线不存在")
    stages = get_stages(pipeline_id)
    jd_stage = next((stage for stage in stages if stage["stage_id"] == "jd_write"), None)
    if not jd_stage or jd_stage.get("status") != "done":
        raise ValueError("请先完成并确认JD")
    jd = parse_stage_output(jd_stage).get("jd", {})
    if not jd:
        raise ValueError("JD内容为空，请返回小文确认")
    candidates = get_candidates(pipeline_id)
    if not candidates:
        raise ValueError("没有候选人，请先从小寻导入")
    # 仅“通过”的候选人离开待筛名单；未通过（含淘汰）的候选人可再次进入评选。
    pending = [
        candidate for candidate in candidates if str(candidate.get("screening_decision") or "").strip() != "passed"
    ]
    return jd, candidates, pending


def _normalize_config(config: dict = None) -> dict:
    """小筛只保留 AI 模型评分：HR 仅需设置通过阈值。"""
    raw = config or {}
    return {"threshold": min(max(int(raw.get("threshold", 70)), 0), 100)}


def classify_screening_status(
    overall_score: float,
    threshold: int,
    review_band: int | None = None,
    information_gaps: list[str] | list[dict] | None = None,
) -> str:
    return "passed" if overall_score >= threshold else "rejected"


def _counts(results: list[dict]) -> dict:
    return {status: sum(item.get("status") == status for item in results) for status in ("passed", "rejected")}


def _screening_payload(jd: dict, candidate: dict) -> dict:
    return {
        "cache_version": SCREENING_CACHE_VERSION,
        "model": DEFAULT_SCREENING_MODEL,
        "jd": jd,
        "candidate": {key: candidate.get(key) for key in _SCREENING_FIELDS},
    }


def _candidate_input_signature(jd: dict, candidate: dict) -> str:
    encoded = json.dumps(_screening_payload(jd, candidate), ensure_ascii=False, sort_keys=True, default=str).encode(
        "utf-8"
    )
    return hashlib.sha256(encoded).hexdigest()


def _screening_input_signature(jd: dict, candidates: list[dict]) -> str:
    """Keep a batch signature for stage compatibility; reuse is candidate-scoped."""
    signatures = [
        {"id": str(candidate.get("id") or ""), "signature": _candidate_input_signature(jd, candidate)}
        for candidate in sorted(candidates, key=lambda item: str(item.get("id") or ""))
    ]
    encoded = json.dumps(signatures, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _information_gaps(candidate: dict) -> list[dict]:
    values = []
    for field in ("missing_info", "information_gaps"):
        raw = candidate.get(field) or []
        if isinstance(raw, (str, int, float)):
            raw = [raw]
        if not isinstance(raw, list):
            continue
        for item in raw:
            if isinstance(item, dict):
                label = str(item.get("label") or item.get("name") or item.get("field") or "").strip()
                reason = str(item.get("reason") or item.get("evidence") or "").strip()
                severity = str(item.get("severity") or "important").strip().lower()
            else:
                label = str(item).strip()
                reason = ""
                severity = "important"
            if not label or any(existing["label"] == label for existing in values):
                continue
            if severity not in {"critical", "important", "minor"}:
                severity = "important"
            values.append({"label": label, "severity": severity, "reason": reason})
    return values


def _apply_missing_info_penalty(candidate: dict) -> dict:
    """Keep missing information as context; it does not alter the AI score."""
    try:
        model_score = float(candidate.get("model_score", candidate.get("overall_score") or 0))
    except (TypeError, ValueError):
        model_score = 0
    model_score = min(max(model_score, 0), 100)
    rounded_score = round(model_score)
    return {
        **candidate,
        "model_score": rounded_score,
        "overall_score": rounded_score,
        "adjusted_score": rounded_score,
        "penalty_total": 0,
        "penalties": [],
        "information_gaps": _information_gaps(candidate),
    }


def _model_candidate_with_status(candidate: dict, config: dict) -> dict:
    candidate = _apply_missing_info_penalty(candidate)
    information_gaps = candidate["information_gaps"]
    overall_score = candidate["adjusted_score"]
    status = classify_screening_status(overall_score, config["threshold"], information_gaps=information_gaps)
    reason = str(
        candidate.get("summary") or "模型评分失败，请人工复核"
        if candidate.get("score_source") == "model_failed"
        else "模型未提供评分总结"
    )
    if information_gaps and candidate.get("score_source") != "model_failed":
        reason = f"{reason}；关注信息缺失：{'、'.join(item['label'] for item in information_gaps)}"
    return {
        **candidate,
        "status": status,
        "review_reason": "",
        "reason": reason,
    }


def _with_screening_metadata(candidate: dict, jd: dict, rubric: dict | None = None) -> dict:
    result = {**candidate, "screening_input_signature": _candidate_input_signature(jd, candidate)}
    result["screening_cache_version"] = SCREENING_CACHE_VERSION
    result["screening_model"] = DEFAULT_SCREENING_MODEL
    if rubric is not None:
        result["rubric_signature"] = hashlib.sha256(
            json.dumps(rubric, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
    return result


def _rubric_input_signature(jd: dict) -> str:
    encoded = json.dumps(
        {"cache_version": SCREENING_CACHE_VERSION, "model": DEFAULT_SCREENING_MODEL, "jd": jd},
        ensure_ascii=False,
        sort_keys=True,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _cache_reusable(candidate: dict, previous: dict | None, signature: str, force: bool) -> bool:
    if force or not previous:
        return False
    if previous.get("screening_input_signature") != signature:
        return False
    if previous.get("screening_cache_version") != SCREENING_CACHE_VERSION:
        return False
    if previous.get("screening_model") != DEFAULT_SCREENING_MODEL:
        return False
    if previous.get("score_source") not in {"model", "model_failed", "manual_override"}:
        return False
    # A rejected manual decision is explicitly eligible for another screening run.
    if (
        previous.get("score_source") == "manual_override"
        and str(candidate.get("screening_decision") or "").strip() == "rejected"
    ):
        return False
    return True


def _cached_candidate(live: dict, cached: dict) -> dict:
    result = dict(cached)
    for field in (*_SCREENING_FIELDS, "status", "screening_decision", "screening_decision_at"):
        if field in live:
            result[field] = live.get(field)
    result["id"] = live.get("id") or cached.get("id")
    return result


def _reclassify_model_results(candidates: list[dict], config: dict) -> list[dict]:
    results = []
    for candidate in candidates:
        if candidate.get("score_source") == "manual_override":
            results.append(candidate)
            continue
        results.append(_model_candidate_with_status(candidate, config))
    return sorted(results, key=lambda item: -float(item.get("overall_score") or 0))


async def preview_model_screening(
    pipeline_id: str,
    raw_config: dict,
    force: bool = False,
) -> dict:
    with _screening_execution_guard(pipeline_id):
        return await _preview_model_screening(pipeline_id, raw_config, force=force)


async def _preview_model_screening(
    pipeline_id: str,
    raw_config: dict,
    force: bool = False,
) -> dict:
    jd, candidates, pending = _load_inputs(pipeline_id)
    scoring_candidates = candidates if force else pending
    if not scoring_candidates:
        raise ValueError("没有待筛查的新候选人")
    config = _normalize_config(raw_config)
    input_signature = _screening_input_signature(jd, scoring_candidates)
    stage = _match_stage(pipeline_id)
    previous = _stage_output(stage)
    previous_candidates = {
        str(item.get("id")): item
        for item in previous.get("candidates", [])
        if isinstance(item, dict) and item.get("id")
    }

    cached_results = []
    candidates_to_score = []
    for candidate in scoring_candidates:
        candidate_id = str(candidate.get("id") or "")
        cached = previous_candidates.get(candidate_id)
        signature = _candidate_input_signature(jd, candidate)
        if _cache_reusable(candidate, cached, signature, force):
            cached_results.append(_cached_candidate(candidate, cached))
        else:
            candidates_to_score.append(candidate)

    rubric = previous.get("rubric") if isinstance(previous.get("rubric"), dict) else None
    rubric_signature = previous.get("rubric_signature")
    if candidates_to_score or force:
        if not rubric or rubric_signature != _rubric_input_signature(jd) or force:
            rubric = await build_rubric(pipeline_id, jd)
        rubric_signature = _rubric_input_signature(jd)

    model_results = []
    if candidates_to_score:
        model_results = await score_candidates(pipeline_id, jd, rubric or {}, candidates_to_score)
        model_results = [_with_screening_metadata(item, jd, rubric or {}) for item in model_results]

    results = _reclassify_model_results([*cached_results, *model_results], config)
    return {
        "config": config,
        "rubric": rubric or {},
        "rubric_signature": rubric_signature or _rubric_input_signature(jd),
        "input_signature": input_signature,
        "scoring_mode": "model",
        "candidates": results,
        "counts": _counts(results),
        "total": len(results),
    }


def _persist_screening(pipeline_id: str, preview: dict, force: bool = False) -> dict:
    stage = _match_stage(pipeline_id)
    previous = _stage_output(stage)
    version = int(previous.get("version") or 0) + 1
    versions = list(previous.get("versions") or [])[-4:]
    if previous.get("version"):
        versions.append(
            {
                "version": previous["version"],
                "counts": previous.get("counts", {}),
                "created_at": previous.get("created_at", ""),
            }
        )
    previous_candidates = previous.get("candidates") if isinstance(previous.get("candidates"), list) else []
    preview_candidates = preview.get("candidates") if isinstance(preview.get("candidates"), list) else []
    merged_candidates = {
        str(item.get("id")): item for item in previous_candidates if isinstance(item, dict) and item.get("id")
    }
    for item in preview_candidates:
        if item.get("id"):
            merged_candidates[str(item["id"])] = item
    merged_list = sorted(merged_candidates.values(), key=lambda item: -float(item.get("overall_score") or 0))
    output = {
        **preview,
        "candidates": merged_list,
        "counts": _counts(merged_list),
        "version": version,
        "versions": versions,
        "workflow_status": "review_pending",
        "created_at": datetime.now().isoformat(),
        "manual_adjustments": int(previous.get("manual_adjustments") or 0),
        "shortlisted": list(previous.get("shortlisted") or []),
        "passed_ids": list(previous.get("passed_ids") or previous.get("shortlisted") or []),
        "rejected": [item["id"] for item in merged_list if item.get("status") == "rejected"],
        "pending_count": 0,
    }
    if not stage:
        create_stage(pipeline_id, "match", "简历筛查")
    update_stage(pipeline_id, "match", "running", output)
    for candidate in preview_candidates:
        candidate_updates = {
            "overall_score": candidate.get("overall_score", 0),
            "status": candidate.get("status", "rejected"),
            "reason": candidate.get("reason", ""),
        }
        if force or str(candidate.get("screening_decision") or "").strip() == "rejected":
            # 强制重评 / 淘汰候选人重新评选：清空旧结论，等待本轮再次确认。
            candidate_updates.update({"screening_decision": "", "screening_decision_at": ""})
        update_candidate(candidate["id"], candidate_updates)
    output["pending_count"] = sum(
        str(candidate.get("screening_decision") or "").strip() != "passed" for candidate in get_candidates(pipeline_id)
    )
    save_message(
        pipeline_id,
        "assistant",
        f"初筛V{version}完成：{output['counts']['passed']}人通过，{output['counts']['rejected']}人淘汰",
    )
    return output


SCREENING_WORKFLOW_STATUSES = {"review_pending", "confirmed"}


def _normalized_decision(candidate: dict) -> str:
    return str(candidate.get("screening_decision") or "").strip().lower()


def get_screening_context(pipeline_id: str) -> dict:
    """Return the latest screening stage and whether it uses the new workflow contract."""
    stage = _match_stage(pipeline_id)
    output = _stage_output(stage)
    workflow_status = str(output.get("workflow_status") or "").strip().lower()
    return {
        "stage": stage,
        "output": output,
        "workflow_status": workflow_status,
        "is_modern": workflow_status in SCREENING_WORKFLOW_STATUSES,
    }


def confirmed_screening_candidates(
    pipeline_id: str, candidates: list[dict] | None = None
) -> tuple[list[dict] | None, dict]:
    """Return candidates eligible for downstream steps, or a legacy marker.

    ``None`` means the pipeline has no new screening workflow marker and callers
    may apply their explicitly scoped legacy compatibility rules. A modern
    workflow returns an empty list until it is confirmed, and only candidates
    with a final ``passed`` decision after confirmation.
    """
    context = get_screening_context(pipeline_id)
    if not context["is_modern"]:
        return None, context
    if context["workflow_status"] != "confirmed":
        return [], context
    source = candidates if candidates is not None else get_candidates(pipeline_id)
    return [candidate for candidate in source if _normalized_decision(candidate) == "passed"], context


def _ids_from_output(value) -> set[str]:
    if not isinstance(value, list):
        return set()
    return {str(item.get("id") if isinstance(item, dict) else item).strip() for item in value if item}


def _candidate_with_live_status(candidate: dict) -> dict:
    item = dict(candidate)
    decision = _normalized_decision(item)
    if decision == "review":
        decision = "rejected"
    if decision in VALID_REVIEW_STATUSES:
        item["screening_decision"] = decision
        item["status"] = decision
    elif str(item.get("status") or "").strip().lower() == "review":
        item["status"] = "rejected"
    elif item.get("status") not in VALID_REVIEW_STATUSES:
        item["status"] = "new"
    return item


def canonical_screening_workflow(pipeline_id: str) -> dict:
    """Build one screening response from the latest stage and live candidate rows."""
    stage = _match_stage(pipeline_id)
    stage_output = dict(_stage_output(stage))
    historical = [
        dict(item) for item in stage_output.get("candidates", []) if isinstance(item, dict) and item.get("id")
    ]
    live_candidates = get_candidates(pipeline_id)
    live_by_id = {str(item.get("id")): item for item in live_candidates if item.get("id")}

    workflow_confirmed = stage_output.get("workflow_status") == "confirmed"
    confirmed_ids = set()
    if workflow_confirmed:
        confirmed_ids.update(
            str(candidate.get("id"))
            for candidate in live_candidates
            if _normalized_decision(candidate) == "passed" and candidate.get("id")
        )
        confirmed_ids.update(_ids_from_output(stage_output.get("passed_ids")))
        confirmed_ids.update(_ids_from_output(stage_output.get("shortlisted")))

    merged = []
    historical_ids = set()
    for historical_item in historical:
        candidate_id = str(historical_item["id"])
        historical_ids.add(candidate_id)
        live = live_by_id.get(candidate_id)
        item = dict(historical_item)
        if live:
            for field in ("overall_score", "status", "reason", "screening_decision", "screening_decision_at"):
                if field in live:
                    item[field] = live.get(field)
            item.update({key: live[key] for key in ("name", "resume_text", "email", "phone") if key in live})
            item = _candidate_with_live_status(item)
        merged.append(item)

    # 候选人表可能在上一次评分后新增；保留为“待筛查”，不能伪装成模型结果。
    for candidate in live_candidates:
        candidate_id = str(candidate.get("id") or "")
        if candidate_id and candidate_id not in historical_ids:
            merged.append(_candidate_with_live_status(candidate))

    all_passed_ids = []
    for item in merged:
        candidate_id = str(item["id"])
        if candidate_id in confirmed_ids or _normalized_decision(item) == "passed":
            if candidate_id not in all_passed_ids:
                all_passed_ids.append(candidate_id)
    visible = [
        item
        for item in merged
        if not workflow_confirmed
        or (str(item.get("id")) not in confirmed_ids and _normalized_decision(item) != "passed")
    ]
    rejected_ids = [str(item["id"]) for item in merged if item.get("status") == "rejected"]
    pending_count = sum(
        1
        for candidate in live_candidates
        if not workflow_confirmed
        or (str(candidate.get("id")) not in confirmed_ids and _normalized_decision(candidate) != "passed")
    )

    stage_output.update(
        {
            "candidates": visible,
            "counts": _counts(merged),
            "total": len(merged),
            "shortlisted": all_passed_ids,
            "passed_ids": all_passed_ids,
            "rejected": rejected_ids,
            "pending_count": pending_count,
            "unscored_count": sum(1 for candidate in live_candidates if str(candidate.get("id")) not in historical_ids),
        }
    )
    return screening_contract(stage_output)


async def execute_model_screening(
    pipeline_id: str,
    raw_config: dict,
    force: bool = False,
) -> dict:
    with _screening_execution_guard(pipeline_id):
        return _persist_screening(
            pipeline_id,
            await _preview_model_screening(pipeline_id, raw_config, force=force),
            force=force,
        )


def review_candidate(pipeline_id: str, candidate_id: str, status: str, reason: str, override_score=None) -> dict:
    if status not in VALID_REVIEW_STATUSES:
        raise ValueError("不支持的复核结果")
    if not reason.strip():
        raise ValueError("人工复核必须填写复核理由")
    stage = _match_stage(pipeline_id)
    output = _stage_output(stage)
    if output.get("workflow_status") not in {"review_pending", "confirmed"}:
        raise ValueError("当前没有可复核的筛选结果")
    candidate = next(
        (item for item in output.get("candidates", []) if str(item.get("id")) == str(candidate_id)),
        None,
    )
    if not candidate:
        raise ValueError("候选人不在当前筛选结果中")
    live_candidate = next(
        (item for item in get_candidates(pipeline_id) if str(item.get("id")) == str(candidate_id)),
        None,
    )
    if not live_candidate:
        raise ValueError("候选人不属于当前流水线")
    if str(candidate.get("status") or "").strip().lower() not in VALID_REVIEW_STATUSES:
        raise ValueError("候选人尚未完成AI评分，请先执行筛选")
    if _normalized_decision(live_candidate) == "passed":
        raise ValueError("已进入下游的候选人不可再次复核")
    if output.get("workflow_status") == "confirmed":
        confirmed_ids = _ids_from_output(output.get("passed_ids")) | _ids_from_output(output.get("shortlisted"))
        if candidate_id in confirmed_ids or candidate.get("status") == "passed":
            raise ValueError("已进入下游的候选人不可再次复核")
    if output.get("workflow_status") == "confirmed":
        # 可重新筛选的历史淘汰者一旦被人工修改，必须重新定版后才能进入下游。
        output["workflow_status"] = "review_pending"
    candidate["status"] = status
    candidate["review_reason"] = reason.strip()
    candidate["reviewed_at"] = datetime.now().isoformat()
    candidate["score_source"] = "manual_override"
    if override_score is not None:
        score = float(override_score)
        if not 0 <= score <= 100:
            raise ValueError("人工分数必须在0到100之间")
        candidate["overall_score"] = score
    output["counts"] = _counts(output["candidates"])
    output["manual_adjustments"] = int(output.get("manual_adjustments") or 0) + 1
    stage_status = "done" if output.get("workflow_status") == "confirmed" else "running"
    update_stage(pipeline_id, "match", stage_status, output)
    update_candidate(
        candidate_id,
        {
            "status": status,
            "overall_score": candidate["overall_score"],
            "reason": reason.strip(),
            # 最终筛选决策在 finalize 时写入；人工复核阶段不能提前冻结候选人。
            "screening_decision": "",
            "screening_decision_at": "",
        },
    )
    save_message(
        pipeline_id, "system", f"人工复核：{candidate.get('name', candidate_id)} → {status}（{reason.strip()}）"
    )
    return output


def finalize_screening(pipeline_id: str) -> dict:
    stage = _match_stage(pipeline_id)
    output = _stage_output(stage)
    if output.get("workflow_status") != "review_pending":
        raise ValueError("当前没有可确认的筛选结果")
    scored_ids = {
        str(candidate.get("id"))
        for candidate in output.get("candidates", [])
        if isinstance(candidate, dict) and candidate.get("id")
    }
    if any(str(candidate.get("id")) not in scored_ids for candidate in get_candidates(pipeline_id)):
        raise ValueError("有新候选人待筛查，请先执行筛选")
    counts = _counts(output.get("candidates", []))
    output["workflow_status"] = "confirmed"
    output["confirmed_at"] = datetime.now().isoformat()
    output["counts"] = counts
    output["shortlisted"] = [item["id"] for item in output["candidates"] if item["status"] == "passed"]
    output["passed_ids"] = list(output["shortlisted"])
    output["rejected"] = [item["id"] for item in output["candidates"] if item["status"] == "rejected"]
    decision_at = datetime.now().isoformat()
    stored_candidates = {str(candidate.get("id")): candidate for candidate in get_candidates(pipeline_id)}
    for item in output["candidates"]:
        stored = stored_candidates.get(str(item["id"])) or {}
        if str(stored.get("screening_decision") or "").strip() in {"passed", "rejected"}:
            continue
        update_candidate(
            item["id"],
            {"screening_decision": item["status"], "screening_decision_at": decision_at},
        )
        item["screening_decision"] = item["status"]
        item["screening_decision_at"] = decision_at
    output["pending_count"] = 0
    update_stage(pipeline_id, "match", "done", output)
    save_message(pipeline_id, "assistant", f"筛选结果已确认：{counts['passed']}人通过，{counts['rejected']}人淘汰")
    return screening_contract(
        {
            "passed_ids": output["shortlisted"],
            "counts": counts,
            "version": output.get("version", 1),
            "candidates": output["candidates"],
            "workflow_status": output["workflow_status"],
        }
    )
