"""Shared model/body-composition service, independent of HTTP requests."""

from __future__ import annotations

from collections.abc import Callable

from app.poster_delivery import PosterComposition
from app.xiao_hai_image import pil_to_png_bytes


def render_poster(
    *,
    prompt: str,
    reference_board: bytes,
    composition: PosterComposition,
    generate: Callable,
    save_raw: Callable,
    compose: Callable,
    on_phase: Callable[[str], None] = lambda _: None,
) -> tuple[bytes, bytes, dict, dict]:
    """A single model call; the same original assets survive every stage."""
    on_phase("generating")
    raw = generate(prompt=prompt, reference_board=reference_board, canvas=composition.layout.model_canvas)
    on_phase("composing")
    raw_asset = save_raw(raw)
    image, metadata = compose(raw, composition)
    final = pil_to_png_bytes(image)
    on_phase("saving")
    return raw, final, raw_asset, metadata
