"""小海对话图生图持久化任务。"""

from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import logging
import threading
import uuid
from datetime import timedelta

from app.conversation_store import get_command, update_command
from app.db import get_company_config, get_db, get_pipeline, get_stages, transaction
from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline, get_poster_generation_timeout
from app.poster_delivery import (
    LAYOUT_VERSION,
    body_reference,
    compose_poster_body,
    prepare_composition,
    save_brand_snapshots,
)
from app.poster_generation import render_poster
from app.poster_progress import (
    ACTIVE,
    PROGRESS,
    PosterJobConflictError,
    PosterJobStoppedError,
    estimate_snapshot,
    expire_jobs,
    public_job,
    set_phase,
    stamp,
    utcnow,
)
from app.poster_service import PosterService
from app.utils import parse_stage_output
from app.user_mailbox import PipelineHrNotConfiguredError, hr_brand_config, require_pipeline_hr
from app.xiao_hai_branding import PosterBrandingError, load_company_brand_assets
from app.xiao_hai_image import (
    ImageGenerationRateLimitError,
    build_element_board,
    build_full_poster_prompt,
    call_image_generate,
    get_canvas_preset,
    resolve_image_api_config,
)

IMAGE_EDIT_MODEL = "gpt-image-2"
POSTER_TEXT_MODEL = "qwen3.6-flash"
_POSTER_SUMMARY_KEYS = {
    "hero_kicker",
    "hero_title",
    "slogan",
    "jobTitle",
    "salary",
    "location",
    "experience",
    "responsibilities",
    "requirements",
    "highlights",
    "benefits",
    "career_growth",
}
_POSTER_SUMMARY_LIST_KEYS = {"responsibilities", "requirements", "highlights", "benefits"}

# 用户在前端手动填写的营销文案 key：已填过则优先保留，LLM 不覆盖。
_USER_PRIORITY_KEYS = {"hero_kicker", "hero_title", "slogan", "apply_title"}
_POSTER_COPY_CACHE: dict[str, dict] = {}
_POSTER_COPY_CACHE_LIMIT = 64


class PosterRevisionConflictError(RuntimeError):
    """The selected base version changed after the user confirmed the edit."""


def _revision(data: dict) -> str:
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _merge_fields(base_fields: dict, fields_patch: dict) -> dict:
    fields = dict(base_fields or {})
    for key, value in (fields_patch or {}).items():
        if value not in (None, "", []):
            fields[key] = value
    return fields


def load_pipeline_jd(pipeline_id: str) -> dict:
    """读取当前 JD，作为海报动态文案的唯一事实来源。"""
    stages = get_stages(pipeline_id)
    jd_stage = next((stage for stage in stages if stage["stage_id"] == "jd_write"), None)
    if not jd_stage:
        return {}
    jd_output = parse_stage_output(jd_stage)
    jd_data = jd_output.get("jd") or jd_output
    return jd_data if isinstance(jd_data, dict) else {}


def _backfill_fields_from_pipeline(pipeline_id: str, fields: dict) -> dict:
    """只从当前 JD 回补招聘文案字段，禁止历史海报正文污染新版本。"""
    body_keys = ["responsibilities", "requirements", "highlights", "benefits", "career_growth"]
    filled = []
    jd_data = load_pipeline_jd(pipeline_id)
    for key in body_keys:
        if not fields.get(key) and jd_data.get(key):
            fields[key] = jd_data[key]
            filled.append(key)
    if not fields.get("salary") and jd_data.get("salary_range"):
        fields["salary"] = jd_data["salary_range"]
        filled.append("salary")

    if filled:
        import logging

        logging.getLogger(__name__).info("[backfill] pipeline=%s filled=%s", pipeline_id, filled)
    return fields


async def _call_poster_jd_summary(
    jd: dict,
    canvas_id: str,
    deadline: TimeoutDeadline | None = None,
) -> dict:
    from hermes_wrapper.client import get_client
    from hermes_wrapper.models import LLMRequest

    model = POSTER_TEXT_MODEL
    cache_input = json.dumps({"canvas_id": canvas_id, "jd": jd, "model": model}, ensure_ascii=False, sort_keys=True)
    cache_key = hashlib.sha256(cache_input.encode("utf-8")).hexdigest()
    cached = _POSTER_COPY_CACHE.get(cache_key)
    if cached is not None:
        return copy.deepcopy(cached)

    max_items = 4 if canvas_id == "long" else 3
    request = LLMRequest(
        prompt=(
            "将以下招聘 JD 压缩成适合招聘海报的结构化文案。只能摘录或压缩 JD 明确写出的事实，"
            "不得推断、补充、编造、夸大或发散。JD 未提供或为空的字段必须返回空值，禁止用常识补齐。"
            f"职责、要求、亮点和福利每条尽量控制在 24 个汉字以内，最多各 {max_items} 条；"
            "职业成长只能在 JD 明确写出时压缩，不能根据职责或职位自行推导。"
            "不要遗漏 JD 中已有的职责、要求、亮点和福利，也不要新增 JD 没有的模块内容。"
            "只返回 JSON，不要 Markdown："
            '{"poster_data":{"hero_kicker":"","hero_title":"","slogan":"",'
            '"jobTitle":"","salary":"","location":"","experience":"",'
            '"responsibilities":[],"requirements":[],"highlights":[],"benefits":[],"career_growth":""}}'
            f"\n画幅：{canvas_id}\nJD：{json.dumps(jd, ensure_ascii=False)}"
        ),
        system="你是招聘海报文案策划。只基于 JD 事实写出具体、有画面感且适合海报阅读的短文案，只返回有效 JSON。",
        model=model,
        complexity="flash",
        temperature=0.2,
        timeout=60,
    )
    if deadline is not None:
        request.timeout = min(float(request.timeout), deadline.require_remaining())
    if deadline is None:
        result = await get_client().chat_json(request)
    else:
        result = await get_client().chat_json(request, deadline=deadline)
    normalized = result if isinstance(result, dict) else {}
    if len(_POSTER_COPY_CACHE) >= _POSTER_COPY_CACHE_LIMIT:
        _POSTER_COPY_CACHE.pop(next(iter(_POSTER_COPY_CACHE)))
    _POSTER_COPY_CACHE[cache_key] = copy.deepcopy(normalized)
    return normalized


def _is_filled(value) -> bool:
    """判断用户侧字段是否已填了有效内容（非空字符串或非空列表）。"""
    if isinstance(value, list):
        return bool(value)
    return bool(str(value or "").strip())


def _jd_value(jd: dict, key: str):
    """读取 JD 字段并兼容当前 JD schema 的别名。"""
    if key == "highlights":
        return jd.get("highlights") or jd.get("selling_points")
    if key == "career_growth":
        return jd.get("career_growth") or jd.get("careerGrowth")
    return jd.get(key)


async def refine_poster_fields_llm(
    fields: dict,
    canvas_id: str,
    *,
    protected_fields: set[str] | None = None,
    jd: dict | None = None,
    deadline: TimeoutDeadline | None = None,
) -> dict:
    """用文本 LLM 精炼 JD 长文本为海报短文案（唯一的精炼实现）。

    默认从当前 fields 组装 JD 事实块（含回填与手改结果）；也可通过 ``jd`` 参数
    显式传入 JD。调用文本模型压缩 responsibilities/requirements 与
    营销文案（hero_kicker/hero_title/slogan）。

    - protected_fields 中的 key 永远不会被覆盖（用于锁住岗位、薪资、地点等事实字段）。
    - 用户已手动填过的营销文案（_USER_PRIORITY_KEYS）也不会被 LLM 覆盖：只有字段为空时
      才用 LLM 生成，即「前端填了 → 优先用前端的」。
    任何异常都原样返回，绝不阻断生图。
    """
    protected = set(protected_fields or ())

    if jd is None:

        def _pick(*keys):
            for key in keys:
                value = fields.get(key)
                if isinstance(value, list) and value:
                    return value
                if isinstance(value, str) and value.strip():
                    return value
            return None

        jd = {
            "title": _pick("jobTitle", "title") or "",
            "salary": _pick("salary") or "",
            "location": _pick("location") or "",
            "responsibilities": _pick("responsibilities") or [],
            "requirements": _pick("requirements") or [],
            "highlights": _pick("highlights") or [],
            "benefits": _pick("benefits") or [],
            "career_growth": _pick("career_growth", "careerGrowth") or "",
        }

    if not (
        jd.get("title")
        or jd.get("responsibilities")
        or jd.get("requirements")
        or jd.get("highlights")
        or jd.get("benefits")
        or jd.get("career_growth")
    ):
        return dict(fields)

    try:
        result = await _call_poster_jd_summary(jd, canvas_id, deadline=deadline)
    except BusinessTimeoutError as error:
        logging.getLogger(__name__).warning("JD 海报文案精炼超时，使用原始字段: %s", error)
        return dict(fields)
    except Exception as error:  # noqa: BLE001
        logging.getLogger(__name__).warning("JD 海报文案精炼失败，使用原始字段: %s", error)
        return dict(fields)

    summary = result.get("poster_data") or result
    if not isinstance(summary, dict):
        return dict(fields)

    updated = dict(fields)
    # 没有 JD 事实支撑的动态文案一律清掉，避免历史版本或模型自由发挥继续污染新版本。
    # 用户在 fields_patch / protected_fields 中明确填写的内容仍然保留。
    for key in (*_POSTER_SUMMARY_LIST_KEYS, "career_growth", "hero_kicker", "hero_title", "slogan"):
        source_value = _jd_value(jd, key)
        if key not in protected and not _is_filled(source_value):
            updated.pop(key, None)

    for key in _POSTER_SUMMARY_KEYS:
        if key in protected or not summary.get(key):
            continue
        if key in _POSTER_SUMMARY_LIST_KEYS:
            source_value = _jd_value(jd, key)
        elif key in {"career_growth", "hero_kicker", "hero_title", "slogan"}:
            source_value = _jd_value(jd, key)
        else:
            source_value = True
        if key in (
            *_POSTER_SUMMARY_LIST_KEYS,
            "career_growth",
            "hero_kicker",
            "hero_title",
            "slogan",
        ) and not _is_filled(source_value):
            continue
        # 用户已手动填写的营销文案优先：不覆盖，仅当字段为空时才用 LLM 生成。
        if key in _USER_PRIORITY_KEYS and _is_filled(fields.get(key)):
            continue
        value = summary[key]
        if key in _POSTER_SUMMARY_LIST_KEYS:
            value = [str(item).strip() for item in value if str(item).strip()] if isinstance(value, list) else []
        else:
            value = str(value).strip()
        if value:
            updated[key] = value
    return updated


def _enqueue(
    conn, pipeline_id: str, payload: dict, *, source: str, request_id: str, session_id=None, command_id=None
) -> tuple[dict, bool]:
    if not conn.execute("SELECT id FROM pipelines WHERE id=%s FOR UPDATE", (pipeline_id,)).fetchone():
        raise ValueError("pipeline not found")
    existing = conn.execute(
        "SELECT * FROM poster_generation_jobs WHERE pipeline_id=%s AND client_request_id=%s",
        (pipeline_id, request_id),
    ).fetchone()
    if existing:
        return dict(existing), False
    active = conn.execute(
        "SELECT id FROM poster_generation_jobs WHERE pipeline_id=%s AND status IN ('queued','running','cancel_requested') LIMIT 1",
        (pipeline_id,),
    ).fetchone()
    if active:
        raise PosterJobConflictError(active["id"])
    base_id = payload.get("base_version_id") or None
    if base_id:
        base = PosterService().get_version(pipeline_id, base_id)
        payload = {"canvas_id": base.get("canvas_id") or "long", **payload}
    payload = {**payload, "canvas_id": (payload.get("canvas") or {}).get("id") or payload.get("canvas_id") or "long"}
    get_canvas_preset(payload["canvas_id"])
    job_id = f"poster_job_{uuid.uuid4().hex}"
    conn.execute(
        "INSERT INTO poster_generation_jobs (id,pipeline_id,session_id,command_id,base_version_id,request_payload,error_message,source,client_request_id,progress_details) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (
            job_id,
            pipeline_id,
            session_id,
            command_id,
            base_id,
            json.dumps(payload, ensure_ascii=False),
            "",
            source,
            request_id,
            "{}",
        ),
    )
    return dict(conn.execute("SELECT * FROM poster_generation_jobs WHERE id=%s", (job_id,)).fetchone()), True


def enqueue_generation_job(conn, command: dict) -> dict:
    existing = conn.execute("SELECT * FROM poster_generation_jobs WHERE command_id=%s", (command["id"],)).fetchone()
    if existing:
        return dict(existing)
    job, _ = _enqueue(
        conn,
        command["pipeline_id"],
        command.get("payload") or {},
        source="conversation",
        request_id=command["id"],
        session_id=command["session_id"],
        command_id=command["id"],
    )
    return job


def create_workspace_job(pipeline_id: str, payload: dict, request_id: str) -> tuple[dict, bool]:
    if not request_id or len(request_id) > 150:
        raise ValueError("client_request_id is required and must be at most 150 characters")
    expire_jobs()
    with transaction() as conn:
        return _enqueue(conn, pipeline_id, payload, source="workspace", request_id=request_id)


def get_job(job_id: str) -> dict | None:
    row = get_db().execute("SELECT * FROM poster_generation_jobs WHERE id=%s", (job_id,)).fetchone()
    if not row:
        return None
    job = dict(row)
    raw = job.get("request_payload") or "{}"
    job["request_payload"] = json.loads(raw) if isinstance(raw, str) else raw
    return job


def list_pipeline_jobs(pipeline_id: str) -> list[dict]:
    expire_jobs()
    rows = (
        get_db()
        .execute(
            "SELECT * FROM poster_generation_jobs WHERE pipeline_id=%s ORDER BY created_at DESC, id DESC LIMIT 30",
            (pipeline_id,),
        )
        .fetchall()
    )
    return [public_job(dict(row)) for row in rows]


def list_recoverable_job_ids() -> list[str]:
    expire_jobs()
    return [
        row["id"]
        for row in get_db()
        .execute("SELECT id FROM poster_generation_jobs WHERE status='queued' ORDER BY created_at,id")
        .fetchall()
    ]


def cancel_generation_job(job_id: str, pipeline_id: str | None = None) -> bool:
    job = get_job(job_id)
    if not job or (pipeline_id is not None and job["pipeline_id"] != pipeline_id):
        return False
    cursor = get_db().execute(
        "UPDATE poster_generation_jobs SET status=CASE WHEN status='queued' THEN 'cancelled' ELSE 'cancel_requested' END, completed_at=CASE WHEN status='queued' THEN %s ELSE completed_at END,error_code='cancelled_by_user' WHERE id=%s AND status IN ('queued','running')",
        (stamp(), job_id),
    )
    get_db().commit()
    current = get_job(job_id)
    if current and current["status"] == "cancelled":
        _sync_command(current, "cancelled", "生成已取消。")
    return cursor.rowcount == 1


def _is_cancelled(job_id: str) -> bool:
    """检查任务是否已被请求取消。"""
    row = (
        get_db()
        .execute("SELECT status FROM poster_generation_jobs WHERE id=%s AND status='cancel_requested'", (job_id,))
        .fetchone()
    )
    return row is not None


def cleanup_stale_jobs():
    expire_jobs()


def _claim_job(job_id: str) -> bool:
    job = get_job(job_id)
    if not job or job["status"] != "queued":
        return False
    payload = job["request_payload"]
    canvas_id = payload.get("canvas_id") or (payload.get("canvas") or {}).get("id") or "long"
    now = utcnow()
    estimate = estimate_snapshot(canvas_id)
    info = {"estimate": estimate, "canvas_id": canvas_id, "phase_started_at": stamp(now), "timings": {}}
    cursor = get_db().execute(
        "UPDATE poster_generation_jobs SET status='running',phase='preparing',progress=10,started_at=%s, heartbeat_at=%s,deadline_at=%s,progress_details=%s,provider='gpt-image-2',model='gpt-image-2' WHERE id=%s AND status='queued'",
        (
            stamp(now),
            stamp(now),
            stamp(now + timedelta(seconds=get_poster_generation_timeout())),
            json.dumps(info),
            job_id,
        ),
    )
    get_db().commit()
    return cursor.rowcount == 1


def _update_job(job_id: str, **updates) -> None:
    progress = updates.pop("progress", None)
    if progress in PROGRESS.values():
        set_phase(job_id, next(p for p, v in PROGRESS.items() if v == progress))
    if updates.get("status") == "succeeded":
        # Success is published exclusively in the version transaction.
        return
    with transaction() as conn:
        row = conn.execute("SELECT * FROM poster_generation_jobs WHERE id=%s FOR UPDATE", (job_id,)).fetchone()
        if not row or row["status"] not in ACTIVE:
            return
        if row["status"] == "cancel_requested" and updates.get("status") == "failed":
            updates = {"status": "cancelled", "error_code": "cancelled_by_user", "error_message": "生成已取消。"}
        allowed = {"status", "provider", "model", "error_code", "error_message"}
        changes = {k: v for k, v in updates.items() if k in allowed}
        if changes.get("status") in {"failed", "cancelled"}:
            changes["completed_at"] = stamp()
        if changes:
            assignments = ", ".join(f"{key}=%s" for key in changes)
            conn.execute(f"UPDATE poster_generation_jobs SET {assignments} WHERE id=%s", (*changes.values(), job_id))


def _sync_command(job: dict, status: str, reply: str) -> None:
    command = get_command(job["command_id"]) if job.get("command_id") else None
    if command:
        update_command(
            command["id"],
            status=status,
            outcome_code=job.get("error_code") or "success",
            result={**(command.get("result") or {}), "reply": reply, "version_id": job.get("result_version_id") or ""},
        )


def _mark_cancelled_job(job: dict) -> None:
    _update_job(job["id"], status="cancelled")
    command = get_command(job["command_id"])
    if command:
        update_command(
            job["command_id"],
            status="cancelled",
            outcome_code="cancelled_by_user",
            result={**(command.get("result") or {}), "reply": "生成已取消。"},
        )


def _refine_job_fields(
    fields: dict,
    payload: dict,
    canvas_id: str,
    deadline: TimeoutDeadline,
    pipeline_id: str,
) -> dict:
    protected = {
        "jobTitle",
        "title",
        "companyName",
        "company_name",
        "salary",
        "location",
        "deliveryLink",
        "delivery_link",
        "qr_code",
        "hr_qr_code",
        "email",
        "contactText",
        "contact_text",
    }
    protected.update((payload.get("fields_patch") or {}).keys())
    jd = load_pipeline_jd(pipeline_id)
    refine_kwargs = {"protected_fields": protected, "deadline": deadline}
    if jd:
        refine_kwargs["jd"] = jd
    return asyncio.run(
        refine_poster_fields_llm(
            fields,
            canvas_id,
            **refine_kwargs,
        )
    )


def _generate_job_poster(
    *,
    prompt: str,
    reference_board: bytes,
    canvas: dict,
    deadline: TimeoutDeadline,
):
    return call_image_generate(
        prompt=prompt,
        width=canvas["width"],
        height=canvas["height"],
        timeout=180,
        reference_image_bytes=reference_board,
        canvas_id=canvas["id"],
        model=IMAGE_EDIT_MODEL,
        use_edit_endpoint=True,
        force_gpt_image2=True,
        deadline=deadline,
        body_only=bool(canvas.get("body_only")),
    )


def _load_selected_materials(payload: dict) -> tuple[bytes | None, list[bytes]]:
    """读取左侧素材选择，供对话触发的生图任务复用。"""
    background_id = str(payload.get("background_element_id") or "")
    element_ids = [str(item) for item in payload.get("element_ids") or [] if item]
    if not background_id and not element_ids:
        return None, []

    from app.routers.xiao_hai import _load_element_manifest, _read_material_entry

    manifest = _load_element_manifest()
    backgrounds = {item["id"]: item for item in manifest.get("backgrounds") or []}
    elements = {item["id"]: item for item in manifest.get("elements") or []}
    background_bytes = None
    if background_id:
        _, background_bytes = _read_material_entry(background_id, backgrounds, "backgrounds")
    element_bytes = [_read_material_entry(item_id, elements, "elements")[1] for item_id in element_ids[:2]]
    return background_bytes, element_bytes


def _run_conversation_job(job_id: str) -> None:
    job = get_job(job_id)
    if not job:
        return
    if _is_cancelled(job_id):
        _mark_cancelled_job(job)
        return

    service = PosterService()
    payload = job["request_payload"]
    deadline = TimeoutDeadline(get_poster_generation_timeout(), agent_id="poster_gen")
    try:
        pipeline = get_pipeline(job["pipeline_id"])
        hr_user = require_pipeline_hr(pipeline)
        config = resolve_image_api_config(require_gpt_image2=True)
        if config.get("provider") != "gpt-image-2":
            raise RuntimeError("小海视觉生成服务未正确配置")
        brand_assets = load_company_brand_assets(hr_brand_config(get_company_config() or {}, hr_user))
        _update_job(
            job_id,
            provider="gpt-image-2",
            model=IMAGE_EDIT_MODEL,
            progress=15,
        )
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="running",
            result={
                **(command.get("result") or {}),
                "reply": "正在生成新版本。",
            },
        )

        base_version = service.get_version(job["pipeline_id"], job["base_version_id"])
        expected_revision = payload.get("base_revision") or ""
        if expected_revision and _revision(base_version) != expected_revision:
            raise PosterRevisionConflictError("基础版本已变化，请重新生成预览。")
        render_data = base_version.get("render_data") or {}
        raw_asset_id = render_data.get("raw_image_asset_id") or base_version["image_asset_id"]
        _, base_data = service.read_asset(job["pipeline_id"], raw_asset_id)
        canvas_id = payload.get("canvas_id") or base_version.get("canvas_id") or "long"
        canvas = get_canvas_preset(canvas_id)
        selected_background_bytes, selected_element_bytes = _load_selected_materials(payload)

        fields = _merge_fields(base_version.get("fields") or {}, payload.get("fields_patch") or {})
        fields = _backfill_fields_from_pipeline(job["pipeline_id"], fields)
        fields["email"] = (hr_user.get("hr_contact") or "").strip()
        _update_job(job_id, progress=25)
        fields = _refine_job_fields(fields, payload, canvas_id, deadline, job["pipeline_id"])

        composition = prepare_composition(brand_assets, canvas_id, fields)
        layout = composition.layout
        snapshot_metadata = save_brand_snapshots(service, job["pipeline_id"], brand_assets)

        references = [str(asset_id) for asset_id in payload.get("reference_asset_ids") or [] if asset_id]
        reference_elements = []
        for asset_id in references[:3]:
            _, uploaded = service.read_asset(job["pipeline_id"], asset_id)
            reference_elements.append(uploaded)
        material_elements = selected_element_bytes + reference_elements
        material_background = selected_background_bytes or body_reference(base_data, base_version)
        reference_board = build_element_board(
            material_elements,
            background_bytes=material_background,
            size=(layout.body.w, layout.body.h),
            logo_bytes=brand_assets.logo_bytes,
            canvas_id=canvas_id,
            body_layout=layout,
        )
        reference_context = (
            "The base is the current raw model poster; additional panels are user attachments."
            if references
            else "The base is the current raw model poster. Apply only the requested changes."
        )
        user_instruction = str(payload.get("instruction") or "").strip()
        if payload.get("mode") == "text":
            user_instruction = (
                "Only update the recruitment copy to the supplied exact text. Preserve the current poster's visual "
                f"style, mascot, composition and color system as closely as possible. {user_instruction}"
            ).strip()
        prompt = build_full_poster_prompt(
            fields=fields,
            canvas=canvas,
            instruction=user_instruction,
            has_ip_image=True,
            reference_context=reference_context,
            body_layout=layout,
        )
        _update_job(job_id, progress=38)
        if _is_cancelled(job_id):
            _mark_cancelled_job(job)
            return

        raw_bytes, final_bytes, raw_asset, composition_metadata = render_poster(
            prompt=prompt,
            reference_board=reference_board,
            composition=composition,
            generate=lambda **kwargs: _generate_job_poster(**kwargs, deadline=deadline),
            save_raw=lambda raw: service.create_image_asset(
                job["pipeline_id"], raw, filename=f"{job_id}-model-output.png", kind="model_output"
            ),
            compose=compose_poster_body,
            on_phase=lambda phase: set_phase(job_id, phase),
        )
        asset = service.create_image_asset(job["pipeline_id"], final_bytes, filename=f"{job_id}.png", kind="generated")
        version = service.create_version(
            job["pipeline_id"],
            image_asset_id=asset["id"],
            canvas_id=canvas_id,
            parent_version_id=base_version["id"],
            reference_asset_ids=references,
            reference_usage=payload.get("reference_usage", ""),
            fields=fields,
            instruction=str(payload.get("instruction") or ""),
            source="conversation_image_edit",
            generation_job_id=job_id,
            provider="gpt-image-2",
            model=IMAGE_EDIT_MODEL,
            render_data={
                "mode": "image2_edits_full_poster",
                "version": 5,
                "job_id": job_id,
                "job_mode": payload.get("mode") or "image",
                "raw_image_asset_id": raw_asset["id"],
                "background_asset_id": raw_asset["id"],
                "text_rendered": True,
                "text_rendered_by_model": True,
                "brand_overlays": ["company_logo", "hr_qr_code"],
                "stock_code_rendered_by_model": True,
                "logo_reference_used": True,
                "brand_layout_version": LAYOUT_VERSION,
                "qr_mode": "hr_qr",
                "mascot_policy": payload.get("mascot_policy") or "preserve",
                "background_element_id": payload.get("background_element_id") or "",
                "element_ids": payload.get("element_ids") or [],
                **composition_metadata,
                **snapshot_metadata,
            },
        )
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="succeeded",
            outcome_code="success",
            result={
                **(command.get("result") or {}),
                "version_id": version["id"],
                "reply": "海报新版本已生成。",
            },
        )
    except PosterJobStoppedError:
        current = get_job(job_id)
        if current and current["status"] == "cancel_requested":
            _mark_cancelled_job(current)
        return
    except BusinessTimeoutError as error:
        _update_job(job_id, status="failed", error_code="backend_timeout", error_message=str(error)[:500])
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="failed",
            outcome_code="backend_timeout",
            result={**(command.get("result") or {}), "reply": "海报生成超时，请稍后重试。"},
        )
    except PosterRevisionConflictError as error:
        _update_job(job_id, status="failed", error_code="revision_conflict", error_message=str(error)[:500])
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="failed",
            outcome_code="revision_conflict",
            result={**(command.get("result") or {}), "reply": str(error)},
        )
    except ImageGenerationRateLimitError as error:
        reply = "生图服务当前触发限流，请等待约 60 秒后再重试，不要连续提交。"
        _update_job(job_id, status="failed", error_code="rate_limited", error_message=str(error)[:500])
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="failed",
            outcome_code="rate_limited",
            result={**(command.get("result") or {}), "reply": reply},
        )
    except PipelineHrNotConfiguredError as error:
        reply = f"{error}，请先到「用户与权限」配置后重试。"
        _update_job(job_id, status="failed", error_code="hr_contact_missing", error_message=reply)
        command = get_command(job["command_id"])
        if command:
            update_command(
                job["command_id"],
                status="failed",
                outcome_code="hr_contact_missing",
                result={**(command.get("result") or {}), "reply": reply},
            )
    except PosterBrandingError as error:
        _update_job(job_id, status="failed", error_code="poster_validation_failed", error_message=str(error))
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="failed",
            outcome_code="poster_validation_failed",
            result={**(command.get("result") or {}), "reply": str(error)},
        )
    except Exception:
        logging.getLogger(__name__).exception("Poster conversation job failed: %s", job_id)
        _update_job(job_id, status="failed", error_code="generation_failed", error_message="海报生成失败，请重试。")
        command = get_command(job["command_id"])
        update_command(
            job["command_id"],
            status="failed",
            outcome_code="generation_failed",
            result={**(command.get("result") or {}), "reply": "海报生成失败，请重试。"},
        )


_RUNNING_TASKS: dict[str, asyncio.Task] = {}


def run_generation_job(job_id: str) -> None:
    if not _claim_job(job_id):
        return
    stop = threading.Event()

    def heartbeat():
        while not stop.wait(10):
            try:
                expire_jobs()
                get_db().execute(
                    "UPDATE poster_generation_jobs SET heartbeat_at=%s WHERE id=%s AND status IN ('running','cancel_requested')",
                    (stamp(), job_id),
                )
                get_db().commit()
            except Exception:
                logging.getLogger(__name__).exception("Poster heartbeat failed for %s", job_id)
        get_db().close()

    keeper = threading.Thread(target=heartbeat, daemon=True)
    keeper.start()
    try:
        job = get_job(job_id)
        if job.get("source") != "workspace":
            _run_conversation_job(job_id)
        else:
            from app.routers.xiao_hai import _generate_from_payload

            asyncio.run(
                _generate_from_payload(
                    job["pipeline_id"],
                    job["request_payload"],
                    TimeoutDeadline(get_poster_generation_timeout(), agent_id="poster_gen"),
                    job_id=job_id,
                )
            )
    except PosterJobStoppedError:
        current = get_job(job_id)
        if current and current["status"] == "cancel_requested":
            _update_job(job_id, status="cancelled")
        expire_jobs()
    except Exception as exc:
        from fastapi import HTTPException

        code = "backend_timeout" if isinstance(exc, BusinessTimeoutError) else "generation_failed"
        message = "海报生成超时，请重试" if code == "backend_timeout" else "海报生成失败，请重试"
        if isinstance(exc, HTTPException):
            code = f"http_{exc.status_code}"
            message = str(exc.detail)
        _update_job(job_id, status="failed", error_code=code, error_message=message)
    finally:
        stop.set()
        keeper.join(timeout=2)
        current = get_job(job_id)
        if current and current["status"] not in ACTIVE:
            _sync_command(
                current,
                current["status"],
                current.get("error_message")
                or ("海报新版本已生成。" if current["status"] == "succeeded" else "生成已取消。"),
            )


def schedule_job(job_id: str) -> None:
    task = _RUNNING_TASKS.get(job_id)
    if task and not task.done():
        return
    task = asyncio.create_task(asyncio.to_thread(run_generation_job, job_id))
    _RUNNING_TASKS[job_id] = task
    task.add_done_callback(lambda _: _RUNNING_TASKS.pop(job_id, None))
