"""小文运行时依赖的后台预热。"""

from app.kb_tokenizer import tokenize
from kg import get_knowledge_graph
from knowledge import get_knowledge_base


def warm_xiao_wen_runtime() -> None:
    """Warm the tokenizer and shared knowledge sources before the first JD call."""
    tokenize("岗位职责 任职要求 薪资")
    get_knowledge_base()
    get_knowledge_graph()
