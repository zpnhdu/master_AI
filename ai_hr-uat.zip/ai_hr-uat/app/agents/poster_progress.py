"""Persisted poster phases and conservative, snapshot-based time estimates."""

from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone

from app.db import get_db, transaction

ACTIVE = ("queued", "running", "cancel_requested")
PHASES = ("preparing", "refining", "generating", "composing", "saving")
PROGRESS = dict(zip(PHASES, (10, 25, 38, 84, 95)))
DEFAULTS = dict(zip(PHASES, ((5, 15), (15, 40), (90, 160), (5, 15), (5, 10))))


class PosterJobConflictError(ValueError):
    def __init__(self, job_id: str):
        self.job_id = job_id
        super().__init__("当前流程已有海报生成中，请等待完成或取消后再试")


class PosterJobStoppedError(RuntimeError):
    pass


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def stamp(value: datetime | None = None) -> str:
    return (value or utcnow()).isoformat(timespec="milliseconds")


def parse_time(value) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        result = value
    else:
        try:
            result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
    return result.astimezone(timezone.utc).replace(tzinfo=None) if result.tzinfo else result


def details(job: dict) -> dict:
    value = job.get("progress_details")
    if isinstance(value, dict):
        return value
    try:
        return json.loads(value or "{}")
    except (ValueError, TypeError):
        return {}


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    left, right = math.floor(position), math.ceil(position)
    return ordered[left] + (ordered[right] - ordered[left]) * (position - left)


def estimate_snapshot(canvas_id: str, model: str = "gpt-image-2") -> dict:
    def history(same_canvas: bool) -> list[dict]:
        condition = (
            " AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(progress_details,'$.canvas_id')), JSON_UNQUOTE(JSON_EXTRACT(request_payload,'$.canvas_id')), 'long')=%s"
            if same_canvas
            else ""
        )
        paths = ",".join(f"'$.timings.{phase}'" for phase in PHASES)
        rows = (
            get_db()
            .execute(
                f"SELECT progress_details FROM poster_generation_jobs WHERE status='succeeded' AND model=%s "
                f"AND JSON_CONTAINS_PATH(progress_details,'all',{paths})=1{condition} "
                "ORDER BY completed_at DESC, id DESC LIMIT 20",
                (model, canvas_id) if same_canvas else (model,),
            )
            .fetchall()
        )
        timings = [details(dict(row)).get("timings", {}) for row in rows]
        return [s for s in timings if all(isinstance(s.get(p), (float, int)) and s[p] >= 0 for p in PHASES)]

    selected = history(True)
    basis = "canvas_history"
    if len(selected) < 5:
        selected = history(False)
        basis = "model_history"
    if len(selected) < 5:
        return {"basis": "default", "sample_count": 0, "phases": DEFAULTS}
    return {
        "basis": basis,
        "sample_count": len(selected),
        "phases": {p: [max(1, _quantile([s[p] for s in selected], q)) for q in (0.5, 0.9)] for p in PHASES},
    }


def public_job(job: dict, now: datetime | None = None) -> dict:
    now = now or utcnow()
    info = details(job)
    status = job["status"]
    started = parse_time(job.get("started_at"))
    created = parse_time(job.get("created_at")) or now
    completed = parse_time(job.get("completed_at"))
    end = completed or now
    phase = job.get("phase") or "queued"
    if phase == "queued" and status == "running":
        phase = next((p for p in reversed(PHASES) if (job.get("progress") or 0) >= PROGRESS[p]), "preparing")
    remaining = None
    overrun = False
    snapshot = info.get("estimate", {"basis": "default", "phases": DEFAULTS})
    if status == "running" and phase in PHASES:
        elapsed = max(0, (now - (parse_time(info.get("phase_started_at")) or started or now)).total_seconds())
        budgets = snapshot.get("phases", DEFAULTS)
        current = budgets.get(phase, DEFAULTS[phase])
        overrun = elapsed > current[1]
        if not overrun:
            later = PHASES[PHASES.index(phase) + 1 :]
            remaining = [
                math.ceil(max(0, current[i] - elapsed) + sum(budgets.get(p, DEFAULTS[p])[i] for p in later))
                for i in (0, 1)
            ]
    return {
        "id": job["id"],
        "pipeline_id": job["pipeline_id"],
        "source": job.get("source") or "conversation",
        "command_id": job.get("command_id"),
        "status": status,
        "phase": "completed" if status == "succeeded" else phase,
        "progress": 100 if status == "succeeded" else min(95, max(0, job.get("progress") or 0)),
        "created_at": stamp(created) + "Z",
        "started_at": stamp(started) + "Z" if started else None,
        "completed_at": stamp(completed) + "Z" if completed else None,
        "server_time": stamp(now) + "Z",
        "elapsed_seconds": max(0, int((end - (started or created)).total_seconds())),
        "estimated_remaining_seconds": remaining,
        "estimate_basis": snapshot["basis"],
        "estimate_overrun": overrun,
        "result_version_id": job.get("result_version_id") or "",
        "error_code": job.get("error_code") or "",
        "error_message": job.get("error_message") or "",
    }


def require_running(job_id: str, conn=None) -> dict:
    db = conn or get_db()
    row = db.execute(
        "SELECT * FROM poster_generation_jobs WHERE id=%s" + (" FOR UPDATE" if conn else ""), (job_id,)
    ).fetchone()
    if not row or row["status"] != "running":
        raise PosterJobStoppedError("任务已取消或结束")
    job = dict(row)
    if parse_time(job.get("deadline_at")) and utcnow() >= parse_time(job["deadline_at"]):
        raise PosterJobStoppedError("海报生成超时")
    heartbeat = parse_time(job.get("heartbeat_at")) or parse_time(job.get("started_at"))
    if heartbeat and utcnow() - heartbeat >= timedelta(seconds=60):
        raise PosterJobStoppedError("任务心跳中断")
    return job


def set_phase(job_id: str, phase: str) -> None:
    with transaction() as conn:
        job = require_running(job_id, conn)
        info = details(job)
        now = utcnow()
        previous = job.get("phase")
        if previous == phase:
            return
        if previous in PHASES:
            started = parse_time(info.get("phase_started_at")) or now
            info.setdefault("timings", {})[previous] = max(0, (now - started).total_seconds())
        info["phase_started_at"] = stamp(now)
        conn.execute(
            "UPDATE poster_generation_jobs SET phase=%s, progress=%s, progress_details=%s, heartbeat_at=%s WHERE id=%s",
            (phase, PROGRESS[phase], json.dumps(info), stamp(now), job_id),
        )


def complete_in_transaction(conn, job_id: str, pipeline_id: str, version_id: str) -> None:
    job = require_running(job_id, conn)
    if job["pipeline_id"] != pipeline_id:
        raise PosterJobStoppedError("任务与海报流程不匹配")
    info = details(job)
    now = utcnow()
    info.setdefault("timings", {})[job.get("phase") or "saving"] = max(
        0,
        (now - (parse_time(info.get("phase_started_at")) or now)).total_seconds(),
    )
    conn.execute(
        "UPDATE poster_generation_jobs SET status='succeeded', phase='completed', progress=100, result_version_id=%s, completed_at=%s, heartbeat_at=%s, progress_details=%s WHERE id=%s",
        (version_id, stamp(now), stamp(now), json.dumps(info), job_id),
    )


def expire_jobs() -> None:
    from app.conversation_store import get_command, update_command

    now = utcnow()
    rows = (
        get_db()
        .execute("SELECT * FROM poster_generation_jobs WHERE status IN ('running','cancel_requested')")
        .fetchall()
    )
    for row in rows:
        job = dict(row)
        heartbeat = parse_time(job.get("heartbeat_at")) or parse_time(job.get("started_at"))
        deadline = parse_time(job.get("deadline_at"))
        timed_out = deadline and now >= deadline
        if not timed_out and heartbeat and heartbeat > now - timedelta(seconds=60):
            continue
        cancelled = job["status"] == "cancel_requested"
        code = "cancelled_by_user" if cancelled else "backend_timeout" if timed_out else "worker_interrupted"
        message = "生成已取消。" if cancelled else "海报生成超时，请重试" if timed_out else "生成任务已中断，请重新提交"
        terminal_status = "cancelled" if cancelled else "failed"
        cursor = get_db().execute(
            "UPDATE poster_generation_jobs SET status=%s, completed_at=%s, error_code=%s, error_message=%s WHERE id=%s AND status IN ('running','cancel_requested') AND (COALESCE(heartbeat_at,started_at,'')<=%s OR (deadline_at IS NOT NULL AND deadline_at<=%s))",
            (terminal_status, stamp(now), code, message, job["id"], stamp(now - timedelta(seconds=60)), stamp(now)),
        )
        get_db().commit()
        if cursor.rowcount and job.get("command_id"):
            command = get_command(job["command_id"])
            if command:
                update_command(
                    job["command_id"],
                    status=terminal_status,
                    outcome_code=code,
                    result={**(command.get("result") or {}), "reply": message},
                )
