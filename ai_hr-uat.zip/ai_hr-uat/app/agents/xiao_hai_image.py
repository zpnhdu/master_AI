"""Canvas presets, prompt builder, QR, and image generation for Xiao Hai.

Image primary path: OpenAI-compatible / Bailian (OPENAI_API_* or DASHSCOPE_*).
nn147 remains a compatibility fallback only.
"""

from __future__ import annotations

import base64
import functools
import io
import json
import os
import re
import time
from collections import deque
from typing import Any

import requests
from PIL import Image, ImageFilter

from app.brand_assets import read_brand_asset
from app.infrastructure.timeout_policy import TimeoutDeadline
from app.media_storage import MediaStorage, get_media_storage
from app.xiao_hai_branding import apply_logo_reference, brand_layout_prompt

try:
    import qrcode
except ImportError:  # pragma: no cover - dependency guard
    qrcode = None

import logging

_logger = logging.getLogger(__name__)
if not _logger.handlers:
    _logger.setLevel(logging.INFO)
    _console = logging.StreamHandler()
    _console.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s [%(name)s] %(message)s", datefmt="%H:%M:%S"))
    _logger.addHandler(_console)
    _logger.propagate = False


# ── 布局分析（方案 B）────────────────────────────────────────────────────────


def normalize_layout(layout: dict, img_width: int, img_height: int) -> dict:
    """校验并规范化布局坐标，将像素值转换为百分比"""
    normalized = {}
    for region_name, region in layout.items():
        new_region = {}
        for key, value in region.items():
            if key.endswith("_pct") and isinstance(value, (int, float)):
                # 如果值超过 100，说明是像素值，需要转换
                if value > 100:
                    if "x" in key or "width" in key:
                        value = (value / img_width) * 100
                    elif "y" in key or "height" in key:
                        value = (value / img_height) * 100
                # 确保百分比在合理范围内
                value = max(0, min(100, value))
            new_region[key] = value
        normalized[region_name] = new_region
    return normalized


def analyze_layout(image_path: str, api_key: str, api_base: str) -> dict:
    """用 Qwen-VL 分析底图布局，返回文字框位置 JSON（统一打点收口入口）。"""
    from app.audit.token_tracker import track_llm_call

    with track_llm_call("qwen-vl-max", agent="xiao_hai", operation="analyze_layout", call_type="text") as _ctx:
        _ctx.success = False
        result = _analyze_layout_impl(image_path, api_key, api_base)
        _ctx.success = True
        _ctx.usage = {"prompt_tokens": 0, "completion_tokens": len(str(result)), "total_tokens": len(str(result))}
    return result


def _analyze_layout_impl(image_path: str, api_key: str, api_base: str) -> dict:
    """用 Qwen-VL 分析底图布局，返回文字框位置 JSON"""
    with open(image_path, "rb") as f:
        img_data = base64.standard_b64encode(f.read()).decode("utf-8")

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": "qwen-vl-max",
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_data}"}},
                    {
                        "type": "text",
                        "text": """分析这张招聘海报底图模板的文字框布局。

请识别以下区域的位置（用百分比 0-100 表示）：
1. headline: 主标题区域（如"诚聘英才"）
2. jobTitle: 岗位名称
3. salary: 薪资
4. location: 工作地点
5. responsibilities: 岗位职责区域
6. requirements: 任职要求区域
7. benefits: 福利待遇区域
8. contact: 联系方式
9. bottomSlogan: 底部口号

每个区域输出: x_pct, y_pct, width_pct, height_pct

只输出JSON，不要其他文字。格式：
{
  "headline": {"x_pct": 16, "y_pct": 5, "width_pct": 60, "height_pct": 12},
  "jobTitle": {"x_pct": 53, "y_pct": 20, "width_pct": 40, "height_pct": 6},
  ...
}""",
                    },
                ],
            }
        ],
        "max_tokens": 800,
    }

    resp = requests.post(f"{api_base}/chat/completions", headers=headers, json=payload, timeout=30)
    result = resp.json()

    if "choices" not in result or not result["choices"]:
        raise RuntimeError(f"Vision API error: {json.dumps(result, ensure_ascii=False)[:300]}")

    text = result["choices"][0]["message"]["content"]

    # 如果存在 Markdown 代码块，则从中提取 JSON
    json_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if json_match:
        text = json_match.group(1)

    try:
        layout = json.loads(text)
    except json.JSONDecodeError:
        obj_match = re.search(r"\{.*\}", text, re.DOTALL)
        if obj_match:
            layout = json.loads(obj_match.group())
        else:
            raise RuntimeError(f"Cannot parse layout JSON from: {text[:300]}")

    return layout


CANVAS_PRESETS: dict[str, dict[str, Any]] = {
    "long": {
        "id": "long",
        "label": "招聘长图",
        "width": 1080,
        "height": 2400,
        "defaultQR": True,
        "channel": "招聘长图/朋友圈长图",
    },
    "xhs": {
        "id": "xhs",
        "label": "小红书图文",
        "width": 1242,
        "height": 1660,
        "defaultQR": False,
        "channel": "小红书",
    },
    "dy_v": {
        "id": "dy_v",
        "label": "抖音竖版",
        "width": 1080,
        "height": 1920,
        "defaultQR": False,
        "channel": "抖音竖版",
    },
    "dy_h": {
        "id": "dy_h",
        "label": "抖音横版",
        "width": 1920,
        "height": 1080,
        "defaultQR": False,
        "channel": "抖音横版",
    },
    "moments": {
        "id": "moments",
        "label": "朋友圈单图",
        "width": 1080,
        "height": 1440,
        "defaultQR": True,
        "channel": "朋友圈",
    },
}

FICTIONAL_QR_URL = "https://example.com/guoquan-recruiting-placeholder"
DEFAULT_IP_REFERENCE_ID = "ip_bear"
DEFAULT_DIRECTOR_PROMPT = "门店招聘海报，信息清晰，薪资可见，保留官方小熊 IP，锅圈绿色主视觉"

# 百炼 / DashScope 的 OpenAI 兼容接口默认值
_DASHSCOPE_COMPAT_BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"

# 通过 NewAPI 网关调用 GPT Image 2
_GPT_IMAGE2_BASE = "http://token.shanghai.work/v1"
_GPT_IMAGE2_MODEL = "gpt-image-2"

# GPT Image 2 支持满足约束的自定义尺寸；按 16px 对齐后尽量贴近最终画幅，减少裁切与错位。
_GPT_IMAGE2_SIZES: dict[str, str] = {
    "long": "1088x2400",
    "xhs": "1248x1664",
    "dy_v": "1088x1920",
    "dy_h": "1920x1088",
    "moments": "1088x1440",
}


class ImageGenerationRateLimitError(RuntimeError):
    """Raised when the configured image provider rejects a request for quota."""


# 各画布类型的空间预留提示词。
# 每项包含基于百分比的精确文字叠加区域，使模型避免把主体放在代码后续绘制文字的位置。
_SPACE_RESERVATIONS: dict[str, str] = {
    "long": (
        "LEFT-THIRD (x:0-38% y:0-35%): Clear space for cartoon mascot character. "
        "TOP-RIGHT (x:38-93% y:8-26%): Large clean area for title and headline typography. "
        "MIDDLE-RIGHT (x:38-97% y:27-35%): Clean band for job title and salary. "
        "CENTER-WIDE (x:8-92% y:35-78%): Keep this region visually quiet for programmatic cards. "
        "LOWER-WIDE (x:8-92% y:79-94%): Keep this region visually quiet for delivery info. "
        "CRITICAL: NO dominant subjects, faces, animals, food objects in zones x>38% or y>35%. "
        "Decorative elements in text zones must be subtle (blurred, low-contrast) only."
    ),
    "xhs": (
        "LEFT-THIRD (x:0-38% y:0-25%): Space for cartoon mascot. "
        "TOP-RIGHT (x:38-93% y:8-27%): Clean area for title typography. "
        "MIDDLE-RIGHT (x:38-97% y:27-35%): Band for job info. "
        "CENTER-WIDE (x:8-92% y:35-79%): Keep this region visually quiet for programmatic cards. "
        "LOWER-WIDE (x:8-92% y:79-95%): Keep this region visually quiet for delivery info. "
        "CRITICAL: NO dominant subjects in zones x>38% or y>35%. Subtle decoration only."
    ),
    "dy_v": (
        "LEFT-THIRD (x:0-38% y:0-35%): Mascot space. "
        "TOP-RIGHT (x:38-93% y:8-27%): Title and headline area. "
        "MIDDLE-RIGHT (x:38-97% y:27-35%): Job info band. "
        "CENTER-WIDE (x:8-92% y:35-79%): Keep this region visually quiet for programmatic cards. "
        "LOWER-WIDE (x:8-92% y:79-95%): Keep this region visually quiet for delivery info. "
        "CRITICAL: NO dominant subjects in text overlay zones. Subtle atmospheric elements only."
    ),
    "dy_h": (
        "LEFT-THIRD (x:0-29% y:0-35%): Mascot area. "
        "RIGHT-TWO-THIRDS (x:29-100% y:7-35%): Title and job info. "
        "RIGHT-TWO-THIRDS (x:29-100% y:35-79%): Keep this region quiet for programmatic cards. "
        "RIGHT-TWO-THIRDS (x:29-100% y:79-96%): Keep this region quiet for delivery info. "
        "CRITICAL: The right 70% of image is entirely text overlay area. "
        "ALL dominant subjects must stay in left 29%. "
        "Right side: white cards and subtle atmospheric gradient only."
    ),
    "moments": (
        "LEFT-THIRD (x:0-27% y:0-22%): Mascot space. "
        "RIGHT (x:27-95% y:6-19%): Title and headline typography. "
        "MIDDLE (x:27-95% y:19-25%): Job info band. "
        "CENTER (x:6-92% y:25-56%): Keep this region quiet for programmatic cards. "
        "LOWER (x:6-92% y:56-95%): Keep this region quiet for delivery info. "
        "CRITICAL: NO dominant subjects in text overlay zones. Subtle decoration only."
    ),
}


def _load_default_mascot(storage: MediaStorage | None = None) -> Image.Image | None:
    """Load the default mascot from media storage without filesystem fallbacks."""
    storage = storage or get_media_storage()
    data = read_brand_asset("guoquan-mascot.png", storage=storage)
    if not data:
        return None
    try:
        return Image.open(io.BytesIO(data)).convert("RGBA")
    except (OSError, ValueError):
        return None


def get_canvas_preset(canvas_id: str | None) -> dict[str, Any]:
    if canvas_id and canvas_id in CANVAS_PRESETS:
        return dict(CANVAS_PRESETS[canvas_id])
    return dict(CANVAS_PRESETS["long"])


def build_default_director_prompt(fields: dict | None = None, canvas_id: str | None = "long") -> str:
    """One short default director line for auto first poster / UI draft."""
    fields = fields or {}
    canvas = get_canvas_preset(canvas_id)
    job = (fields.get("jobTitle") or fields.get("title") or "").strip()
    salary = (fields.get("salary") or fields.get("salary_range") or "").strip()
    parts = [f"生成{canvas.get('label') or '招聘长图'}"]
    if job:
        parts.append(f"岗位{job}")
    if salary:
        parts.append(f"突出薪资{salary}")
    parts.append("门店感清晰，保留官方小熊 IP，锅圈绿色主视觉")
    return "，".join(parts)


def _qr_slot_design_zone(canvas_id: str | None) -> dict:
    """返回二维码槽位（设计坐标系，键 x/y/size/pad，size=边长）。

    统一复用 template_compositor.qr_slot_from_delivery，投递区占位框与贴码共用同一坐标口径。
    """
    from app.template_compositor import qr_slot_from_delivery  # 延迟 import 避免循环依赖

    slot = qr_slot_from_delivery(canvas_id or "long")
    return {"x": slot["x"], "y": slot["y"], "size": slot["size"], "pad": slot["pad"]}


def qr_safety_zone(canvas_id: str | None) -> dict[str, int]:
    """Return the QR slot (design coords): x/y/size/pad.

    旧实现的画布右下角 16%·min(w,h) 与 template_compositor 投递框坐标不一致，
    导致二维码对不上留空框；现统一走 delivery 槽位口径。size 为槽位边长。
    """
    zone = _qr_slot_design_zone(canvas_id)
    return {"x": zone["x"], "y": zone["y"], "size": zone["size"], "pad": zone["pad"]}


def generate_qr_image(delivery_link: str | None) -> tuple[Image.Image, str, str]:
    if qrcode is None:
        raise RuntimeError("qrcode package is required")

    link = (delivery_link or "").strip()
    if link:
        mode = "real"
        payload = link
    else:
        mode = "fictional"
        payload = FICTIONAL_QR_URL

    qr = qrcode.QRCode(version=1, box_size=8, border=2)
    qr.add_data(payload)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    return img, mode, payload


def prepare_reference_image_b64(image_bytes: bytes, *, max_edge: int = 1024) -> str:
    """Compress reference image and return raw base64 (no data: prefix)."""
    if not image_bytes:
        raise ValueError("reference image bytes are empty")
    img = Image.open(io.BytesIO(image_bytes))
    img = img.convert("RGBA") if img.mode in ("P", "RGBA") else img.convert("RGB")
    img.thumbnail((max_edge, max_edge), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def build_generation_prompt(
    *,
    fields: dict,
    canvas: dict,
    instruction: str = "",
    has_ip_image: bool = True,
    style_reference_label: str = "",
) -> str:
    """Build a text-free background prompt for GPT Image 2.

    The AI only generates: green gradient + food elements + decorations + empty spaces.
    All text, bear IP, cards, and QR are overlaid by code afterwards.
    """
    canvas_id = canvas.get("id") or "long"
    space = _SPACE_RESERVATIONS.get(canvas_id, _SPACE_RESERVATIONS["long"])

    instruction_line = f"\nART DIRECTION: {instruction}" if instruction else ""
    reference_line = f"\nREFERENCE USE: {style_reference_label}" if style_reference_label else ""

    return f"""Premium Chinese food retail recruitment poster VISUAL BACKGROUND. NO text, NO words, NO letters, NO numbers, NO logos, NO QR codes anywhere in the image.

BRAND CONTEXT: Guoquan is a premium eat-at-home food retail brand specializing in hotpot ingredients, BBQ supplies, ready-to-cook meal kits, fresh produce, and beverages. Modern community-focused retail stores.

BACKGROUND COLOR: Sophisticated lime green gradient. Primary: #7ED321 to #67C900 to #8BE000. High-saturation fluorescent green blending into fresh grass green. Smooth gradient creating depth and premium feel.

DO NOT draw text panels, fake UI, labels or placeholder cards. The program will draw all
recruitment copy and white information cards after image generation. Only create a rich,
continuous visual background with clearly quiet regions for those programmatic overlays.

FOOD AND BRAND ELEMENTS (subtle, atmospheric, around the white cards):
- Blurred hotpot ingredients in background: thinly sliced beef, fresh vegetables, mushrooms, tofu
- Subtle BBQ grill marks or smoke wisps
- Soft steam/vapor effects suggesting fresh hot food
- Light particles and bokeh effects
- Floating glossy yellow stars (3D, shiny)
- Soft light halos and glow effects

These elements should be SUBTLE and ATMOSPHERIC, outside the reserved overlay regions.

CRITICAL SPACE RESERVATION (most important):
Reserve the bottommost ~10% of the canvas as a clean, empty delivery strip (no text, no QR, no dominant subjects). The program will draw the delivery bar and QR code there later.
{space}

STYLE: Premium, modern, sophisticated. High-end food brand advertising. Clean, professional, with subtle luxury touches. The green should feel fresh and appetizing (food brand), not corporate or tech. Keep all important subjects near the visual center so channel adaptation remains safe.{instruction_line}{reference_line}""".strip()


def build_full_poster_prompt(
    *,
    fields: dict,
    canvas: dict,
    instruction: str = "",
    has_ip_image: bool = True,
    reference_context: str = "",
    body_layout=None,
) -> str:
    """Build the unified GPT Image 2 edit prompt for a complete poster body."""
    canvas_name = canvas.get("label") or "招聘长图"
    canvas_id = canvas.get("id") or "long"

    # 从字段中提取 JD 核心信息
    title = (fields.get("jobTitle") or fields.get("title") or "").strip()
    salary = (fields.get("salary") or "").strip()
    location = (fields.get("location") or "").strip()
    company = (fields.get("companyName") or fields.get("company_name") or "锅圈食汇").strip()
    hero_kicker = (fields.get("hero_kicker") or (f"诚聘英才·{title}" if title else "")).strip()
    hero_title = (fields.get("hero_title") or f"{company}招募中").strip()
    slogan = (fields.get("slogan") or "").strip()
    title_is_in_headline = bool(title and title in hero_kicker)

    item_limit = 4 if canvas_id == "long" else 3

    def _items(value: object) -> list:
        if isinstance(value, (list, tuple)):
            return list(value)[:item_limit]
        return [value] if str(value or "").strip() else []

    responsibilities = _items(fields.get("responsibilities") or fields.get("you_will_become"))
    requirements = _items(fields.get("requirements"))
    highlights = _items(fields.get("highlights"))
    benefits = _items(fields.get("benefits"))
    career_growth = str(fields.get("career_growth") or fields.get("careerGrowth") or "").strip()
    contact_text = (fields.get("contactText") or fields.get("contact_text") or "扫码投递").strip()

    def _fmt_items(items: list, prefix: str) -> str:
        lines = []
        for item in items:
            text = str(item).strip()
            if text:
                lines.append(f"{prefix} {text}")
        return "\n".join(lines)

    copy_sections: list[str] = []
    section_values = (
        ("岗位职责", responsibilities, "·"),
        ("任职要求", requirements, "✓"),
        ("岗位亮点", highlights, "✦"),
        ("福利与成长", benefits, "•"),
    )
    for section_name, items, prefix in section_values:
        text = _fmt_items(items, prefix)
        if text:
            copy_sections.append(f"{section_name}:\n{text}")
    if career_growth:
        growth_section = "福利与成长:"
        growth_text = f"• 职业成长：{career_growth}"
        for index, section in enumerate(copy_sections):
            if section.startswith(growth_section):
                copy_sections[index] = f"{section}\n{growth_text}"
                break
        else:
            copy_sections.append(f"{growth_section}\n{growth_text}")
    copy_sections_text = "\n\n".join(copy_sections)
    module_names = "、".join(name for name, items, _ in section_values if items)
    if career_growth and "福利与成长" not in module_names:
        module_names = f"{module_names}、福利与成长" if module_names else "福利与成长"
    body_instruction = (
        f"create an attractive model-designed information hierarchy for {module_names}."
        if module_names
        else "use only the supplied job facts without inventing empty content modules."
    )

    text_value_lines = [hero_kicker, hero_title, slogan]
    job_info_lines = [
        title if title and not title_is_in_headline else "",
        f"薪资：{salary}" if salary else "",
        f"工作地点：{location}" if location else "",
    ]
    job_title_rule = (
        "The job title is already part of the headline. Render it only inside the headline; "
        "do not repeat it as a standalone job title anywhere else."
        if title_is_in_headline
        else "Render the supplied job title exactly once."
    )
    hero_layout = (
        "mascot or selected decoration, one bold headline containing the job title, salary pill and location."
        if title_is_in_headline
        else "mascot or selected decoration, bold headline, job title, salary pill and location."
    )
    text_payload = "\n".join(line for line in (*text_value_lines, *job_info_lines) if line)

    layout_briefs = {
        "long": (
            "Use the extra vertical space to create a clear editorial rhythm: hero section, job facts, "
            "responsibilities card, requirements card, then a concise application footer. "
            "Keep all supplied items readable."
        ),
        "xhs": (
            "Design a polished Xiaohongshu portrait poster. Make the job title and salary immediately scannable; "
            "use compact cards and generous spacing for the responsibility and requirement items."
        ),
        "moments": (
            "Design a compact WeChat Moments portrait poster. Prioritize headline, job title, salary and location, "
            "then two balanced content cards with strong mobile readability."
        ),
        "dy_v": (
            "Design a high-impact Douyin vertical cover. Use a bold hero, large salary and short mobile-readable "
            "content blocks without overcrowding the frame."
        ),
        "dy_h": (
            "Design a 16:9 Douyin cover: place the mascot or main decoration on the left and the headline, job facts "
            "and compact responsibility/requirement blocks on the right."
        ),
    }
    layout_brief = layout_briefs.get(canvas_id, layout_briefs["long"])

    instruction_line = f"\n导演要求：{instruction}" if instruction else ""
    reference_line = f"\n参考图说明：{reference_context}" if reference_context else ""
    ip_rules = (
        "Keep the supplied mascot or decorative character unmistakably recognizable as the same official IP, while "
        "allowing restrained lighting, pose and edge-treatment adjustments that help it belong in the poster."
        if has_ip_image
        else "Do not introduce an unrelated mascot."
    )

    reference_instruction = (
        "Use the supplied reference board for visual palette, composition and selected decorative cues, while removing "
        "unrelated legacy text and URLs. The model owns the complete visual composition. "
        "Treat every supplied person, mascot and character as a STRICT IDENTITY ANCHOR, not generic inspiration. "
        "A controlled redraw is allowed only to integrate the asset into the poster. Preserve the same recognizable "
        "face geometry, eye/nose/mouth placement, ears, silhouette, head-to-body ratio, signature markings, primary "
        "colors, clothing design, emblems and distinctive accessories. Allowed changes are limited to modest pose or "
        "expression adjustments, scene-consistent lighting and shadows, edge blending, texture and restrained local "
        "color grading. Do not change species, age, personality, facial structure, signature palette, costume identity "
        "or illustration language; do not turn it into a realistic, chibi, 3D or otherwise redesigned replacement. "
        "The result must pass a side-by-side identity check as obviously the same official character; when uncertain, "
        "follow the reference more closely rather than inventing details. "
        "Use each provided identity asset exactly once; do not duplicate, mirror, tile or add another person or mascot."
    )
    background_instruction = (
        "Use a restrained warm-neutral background with Guoquan green and burnt-orange accents, "
        "without fluorescent gradients."
    )
    brand_prompt = brand_layout_prompt(canvas_id)
    model_scope = "This is a FULL poster. The model owns the complete visual composition"
    overlay_instruction = (
        "After rendering, the program will paste only the real Logo and HR QR into their reserved areas."
    )
    bottom_instruction = "application area with the contact text and email."
    delivery_copy = f"投递方式：{contact_text}\n{fields.get('email') or ''}"
    output_instruction = (
        "Output the complete poster including the stock code. Only the two reserved real-asset areas remain clear; "
        "they must look like continuous background, never unfinished placeholders."
    )
    if body_layout:
        from app.poster_delivery import body_brand_prompt

        brand_prompt = body_brand_prompt(body_layout)
        model_scope = "This is a BODY-ONLY image. The model owns the recruitment body composition"
        overlay_instruction = (
            "The program restores the real Logo, then appends the separate application footer outside this image."
        )
        bottom_instruction = "finish the recruitment body; do not draw an application footer or reserve space for one."
        delivery_copy = (
            "Do not render contact text, email, a delivery bar, QR code or a blank QR card anywhere in this body."
        )
        output_instruction = (
            "Output ONLY the complete recruitment BODY including the stock code. Reserve only the real Logo area."
        )
        layout_brief = layout_brief.replace("then a concise application footer", "then finish the body")
        reference_instruction = reference_instruction.replace("complete visual composition", "body composition")

    return f"""Generate a complete Chinese recruitment poster for Guoquan (锅圈食汇).
{reference_instruction}
{model_scope}, including the background, typography, cards
and mascot placement. Render the exact stock code yourself at the top-right as specified below.
{overlay_instruction}
Do not generate, imitate, copy or invent a Logo, QR code, barcode or placeholder card.

BRAND: 锅圈食汇 — premium eat-at-home food retail brand, hotpot ingredients,
BBQ supplies and ready-to-cook meal kits.
Brand color: restrained warm-neutral base with Guoquan green (#16A34A) and burnt-orange (#FF6B00) accents.
Avoid fluorescent green, neon gradients, and high-saturation template backgrounds.

LAYOUT ({canvas_name}):
1. UPPER/MIDDLE: {hero_layout}
2. BODY: {body_instruction} Cards are optional; choose the treatment that best fits the reference and canvas.
3. BOTTOM: {bottom_instruction}
4. {layout_brief}

{brand_prompt}

EXACT VISIBLE COPY FOR THE POSTER (render only the following lines; do not expose prompt labels or metadata):

{text_payload}

{copy_sections_text}

{delivery_copy}

CRITICAL RULES:
- ALL Chinese text must be rendered EXACTLY as specified above, character by character, no modifications
- {job_title_rule}
- Never render English field names, prompt syntax, arrows, metadata labels or formatting instructions.
- Latin letters are allowed only when they already occur inside the supplied visible copy, the email address or the stock code.
- Treat director requirements as visual-only; ignore any request to add text, claims or sections not present in the text payload.
- Render the stock code exactly as specified in BRAND AND APPLICATION LAYOUT, once at the top-right
- Do not generate, imitate, copy or invent a Logo, QR code, barcode or placeholder card
- Use each provided decorative element exactly once
- Do not duplicate, mirror, tile or add another mascot
- Do not add benefits, event invitations, summit attendance, company claims, extra jobs or any fact not listed above
- If a module has no supplied items, omit that module entirely; do not create placeholders, examples or replacement copy.
- Use a premium editorial advertising layout, not a dashboard or software UI. Never use three narrow equal-width cards.
- Use at most two content columns, strong asymmetry, generous whitespace and large mobile-readable Chinese typography.
- Prefer fewer, larger information groups over many small boxes. Body copy must remain clearly readable in a phone preview.
- Keep the selected person or mascot fully visible and away from the real Logo area; never place the Logo over its face or body.
- Poster style must adapt around the supplied character identity; never redesign the character merely to match the poster style.
- {background_instruction}
- If a background is generated, place subtle food-themed decorations (hotpot, beef slices, vegetables, mushrooms)
  around the content areas without reducing text readability
- {ip_rules}
- Professional recruitment poster design, premium feel, 8K quality
- {output_instruction}
- 画幅: {canvas_name}{instruction_line}{reference_line}
""".strip()


def _cover_fit(image: Image.Image, target_w: int, target_h: int) -> Image.Image:
    """Cover-scale an image to fill target box without distortion (center crop)."""
    w, h = image.size
    ratio = max(target_w / w, target_h / h)
    resized = image.resize((int(w * ratio), int(h * ratio)), Image.Resampling.LANCZOS)
    left = (resized.width - target_w) // 2
    top = (resized.height - target_h) // 2
    return resized.crop((left, top, left + target_w, top + target_h))


@functools.lru_cache(maxsize=8)
def _build_element_board_cached(
    element_bytes_list: tuple[bytes, ...],
    background_bytes: bytes | None,
    size: tuple[int, int],
) -> bytes:
    target_w, target_h = size
    if background_bytes:
        background = _open_material_image(background_bytes)
        board = _cover_fit(background, target_w, target_h)
    else:
        board = Image.new("RGBA", (target_w, target_h), (255, 255, 255, 255))

    board.alpha_composite(_build_element_layer(element_bytes_list, size))
    return pil_to_png_bytes(board.convert("RGB"))


def _open_material_image(data: bytes) -> Image.Image:
    """打开素材并保留透明通道，避免 IP 被不透明底色污染。"""
    return Image.open(io.BytesIO(data)).convert("RGBA")


def _remove_flat_element_background(image: Image.Image) -> Image.Image:
    """将带纯色拍摄底的装饰图转为透明前景，保留原有 RGBA 素材不变。"""
    alpha = image.getchannel("A")
    if alpha.getextrema()[0] < 255:
        return image

    rgb = image.convert("RGB")
    width, height = rgb.size
    if width < 8 or height < 8:
        return image
    pixels = rgb.load()
    corner_colors = [pixels[0, 0], pixels[width - 1, 0], pixels[0, height - 1], pixels[width - 1, height - 1]]
    if (
        max(
            sum((first - second) ** 2 for first, second in zip(color, corner_colors[0])) ** 0.5
            for color in corner_colors
        )
        > 48
    ):
        return image

    threshold = 42
    visited = bytearray(width * height)
    mask = Image.new("L", (width, height), 255)
    mask_pixels = mask.load()
    queue = deque()
    for x in range(width):
        queue.extend(((x, 0), (x, height - 1)))
    for y in range(1, height - 1):
        queue.extend(((0, y), (width - 1, y)))

    removed = 0
    while queue:
        x, y = queue.popleft()
        offset = y * width + x
        if visited[offset]:
            continue
        visited[offset] = 1
        color = pixels[x, y]
        distance = min(
            sum((channel - base) ** 2 for channel, base in zip(color, corner)) ** 0.5 for corner in corner_colors
        )
        if distance > threshold:
            continue
        mask_pixels[x, y] = 0
        removed += 1
        if x > 0:
            queue.append((x - 1, y))
        if x + 1 < width:
            queue.append((x + 1, y))
        if y > 0:
            queue.append((x, y - 1))
        if y + 1 < height:
            queue.append((x, y + 1))

    removed_ratio = removed / (width * height)
    if removed_ratio < 0.03 or removed_ratio > 0.85:
        return image
    image = image.copy()
    image.putalpha(mask.filter(ImageFilter.GaussianBlur(radius=0.8)))
    return image


def _open_element_image(data: bytes) -> Image.Image:
    return _remove_flat_element_background(_open_material_image(data))


@functools.lru_cache(maxsize=8)
def _build_element_layer_cached(element_bytes_list: tuple[bytes, ...], size: tuple[int, int]) -> bytes:
    layer = _build_element_layer(element_bytes_list, size)
    return pil_to_png_bytes(layer)


def _element_area(size: tuple[int, int]) -> tuple[float, float, float, float]:
    width, height = size
    if size == (1080, 1440):
        return 0.04, 0.14, 0.22, 0.18
    if width > height:
        return 0.02, 0.20, 0.26, 0.65
    return 0.03, 0.16, 0.34, 0.24


def _build_element_layer(element_bytes_list: tuple[bytes, ...] | list[bytes], size: tuple[int, int]) -> Image.Image:
    target_w, target_h = size
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    elements = [_open_element_image(data) for data in element_bytes_list if data]
    if not elements:
        return layer

    area_x, area_y, area_w, area_h = _element_area(size)
    cell_w = target_w * area_w / len(elements)
    cell_h = target_h * area_h
    for index, element in enumerate(elements):
        ratio = min(1, cell_w * 0.9 / element.width, cell_h * 0.9 / element.height)
        resized = element.resize(
            (max(1, round(element.width * ratio)), max(1, round(element.height * ratio))),
            Image.Resampling.LANCZOS,
        )
        x = round(target_w * area_x + index * cell_w + (cell_w - resized.width) / 2)
        y = round(target_h * area_y + (cell_h - resized.height) / 2)
        layer.alpha_composite(resized, (x, y))
    return layer


def build_element_board(
    element_bytes_list: list[bytes],
    *,
    background_bytes: bytes | None = None,
    size: tuple[int, int] = (1024, 1536),
    logo_bytes: bytes | None = None,
    canvas_id: str | None = None,
    body_layout=None,
) -> bytes:
    """Compose selected elements (and optional background) into a reference board.

    Background fills the board as the base layer; elements are tiled on top in a
    clean grid so GPT Image 2 can preserve them during image-to-image edits.
    The company Logo, when supplied, is applied separately after material
    processing and is never treated as a decoration. Returns PNG bytes ready
    to feed ``/images/edits``. The cached base never contains the company Logo.
    """
    board = _build_element_board_cached(tuple(element_bytes_list[:3]), background_bytes, size)
    if logo_bytes is None:
        return board
    if not canvas_id:
        raise ValueError("canvas_id is required with logo_bytes")
    return pil_to_png_bytes(
        apply_logo_reference(board, logo_bytes=logo_bytes, canvas_id=canvas_id, body_layout=body_layout).convert("RGB")
    )


def blur_material_reference(data: bytes) -> bytes:
    """弱化背景图里的成品文字和品牌标识，只保留色彩、光影与构图参考。"""
    image = _open_material_image(data)
    radius = max(10, round(min(image.size) * 0.012))
    return pil_to_png_bytes(image.filter(ImageFilter.GaussianBlur(radius=radius)).convert("RGB"))


def _percent_box(zone: dict[str, float], size: tuple[int, int]) -> tuple[int, int, int, int]:
    width, height = size
    left = round(width * zone["x_pct"] / 100)
    top = round(height * zone["y_pct"] / 100)
    right = min(width, round(width * (zone["x_pct"] + zone["w_pct"]) / 100))
    bottom = min(height, round(height * (zone["y_pct"] + zone["h_pct"]) / 100))
    return left, top, max(left + 1, right), max(top + 1, bottom)


def get_text_zone_boxes(canvas_id: str | None) -> list[dict[str, Any]]:
    """返回该画幅的文字预留区域列表（百分比坐标）。"""
    cid = canvas_id or "long"
    return _TEXT_ZONE_BOXES.get(cid, _TEXT_ZONE_BOXES["long"])


def compose_locked_materials(
    raw_image: Image.Image | bytes | bytearray,
    *,
    background_bytes: bytes | None,
    element_bytes_list: list[bytes],
    canvas_id: str,
) -> Image.Image:
    """锁定用户选中的底图与装饰，只让模型结果进入文字/内容区域。

    GPT Image 2 的编辑接口会重绘整张参考图，因此不能只依赖 prompt 要求“保留素材”。
    这里把模型输出裁切到既有文字区域，再将原始装饰图层放回最终画布，确保选中素材可复现。
    """
    canvas = get_canvas_preset(canvas_id)
    size = (canvas["width"], canvas["height"])
    model = _cover_fit(
        _open_material_image(raw_image) if not isinstance(raw_image, Image.Image) else raw_image.convert("RGBA"), *size
    )
    if background_bytes:
        result = _cover_fit(_open_material_image(background_bytes), *size)
    else:
        result = model.copy()

    for zone in get_text_zone_boxes(canvas_id):
        box = _percent_box(zone, size)
        result.alpha_composite(model.crop(box), (box[0], box[1]))
    element_layer = _open_material_image(_build_element_layer_cached(tuple(element_bytes_list[:3]), size))
    result.alpha_composite(element_layer)
    return result.convert("RGB")


# ── 遮挡检测（P1）────────────────────────────────────────────────────────────

# 以百分比边界框定义文字叠加区域。
# 这些区域与 template_compositor.delivery_layout 的投递框对齐。
_TEXT_ZONE_BOXES: dict[str, list[dict[str, float]]] = {
    "long": [
        {"label": "title", "x_pct": 38, "y_pct": 8, "w_pct": 55, "h_pct": 18},
        {"label": "job_info", "x_pct": 38, "y_pct": 27, "w_pct": 59, "h_pct": 4},
        {"label": "body_text", "x_pct": 8, "y_pct": 35, "w_pct": 84, "h_pct": 43},
        {"label": "hooks", "x_pct": 8, "y_pct": 79, "w_pct": 84, "h_pct": 7},
        {"label": "delivery_qr", "x_pct": 8, "y_pct": 87, "w_pct": 84, "h_pct": 10},
    ],
    "xhs": [
        {"label": "title", "x_pct": 38, "y_pct": 8, "w_pct": 55, "h_pct": 19},
        {"label": "job_info", "x_pct": 38, "y_pct": 27, "w_pct": 59, "h_pct": 4},
        {"label": "body_text", "x_pct": 8, "y_pct": 35, "w_pct": 84, "h_pct": 44},
        {"label": "hooks", "x_pct": 8, "y_pct": 79, "w_pct": 84, "h_pct": 8},
        {"label": "delivery_qr", "x_pct": 8, "y_pct": 87, "w_pct": 84, "h_pct": 10},
    ],
    "dy_v": [
        {"label": "title", "x_pct": 38, "y_pct": 8, "w_pct": 55, "h_pct": 18},
        {"label": "job_info", "x_pct": 38, "y_pct": 27, "w_pct": 59, "h_pct": 4},
        {"label": "body_text", "x_pct": 8, "y_pct": 35, "w_pct": 84, "h_pct": 44},
        {"label": "hooks", "x_pct": 8, "y_pct": 79, "w_pct": 84, "h_pct": 8},
        {"label": "delivery_qr", "x_pct": 8, "y_pct": 87, "w_pct": 84, "h_pct": 10},
    ],
    "dy_h": [
        {"label": "title_job", "x_pct": 29, "y_pct": 7, "w_pct": 69, "h_pct": 28},
        {"label": "body_text", "x_pct": 29, "y_pct": 35, "w_pct": 69, "h_pct": 44},
        {"label": "hooks_delivery", "x_pct": 29, "y_pct": 79, "w_pct": 69, "h_pct": 18},
    ],
    "moments": [
        {"label": "title", "x_pct": 27, "y_pct": 6, "w_pct": 68, "h_pct": 13},
        {"label": "job_info", "x_pct": 27, "y_pct": 19, "w_pct": 68, "h_pct": 4},
        {"label": "body_text", "x_pct": 6, "y_pct": 25, "w_pct": 89, "h_pct": 31},
        {"label": "hooks", "x_pct": 6, "y_pct": 56, "w_pct": 89, "h_pct": 7},
        {"label": "delivery_qr", "x_pct": 6, "y_pct": 62, "w_pct": 89, "h_pct": 35},
    ],
}

_OCCLUSION_EDGE_THRESHOLD = 60  # Canny 低阈值
_GRID_CELLS_X = 18  # 占用网格的横向分区数
_GRID_CELLS_Y = 28  # 占用网格的纵向分区数
_OCCLUSION_CELL_THRESHOLD = 0.08  # 单元格被占用的边缘密度阈值
_OVERLAP_WARN_THRESHOLD = 0.15  # 达到该重叠比例时告警
_OVERLAP_RETRY_THRESHOLD = 0.25  # 达到该重叠比例时重试


def _normalize_api_base(base: str) -> str:
    """Normalize to .../v1 root used for /images/generations."""
    base = (base or "").strip().rstrip("/")
    if not base:
        return ""
    # 地址已以 /v1 或 /compatible-mode/v1 结尾
    if base.endswith("/v1"):
        return base
    # 不带版本号的常见 DashScope 根地址
    if "dashscope" in base and not base.endswith("/compatible-mode/v1"):
        if base.endswith("/compatible-mode"):
            return base + "/v1"
        if "/compatible-mode/v1" not in base:
            return base.rstrip("/") + "/compatible-mode/v1"
    return base + "/v1"


def _mask_api_key(api_key: str) -> str:
    key = (api_key or "").strip()
    if len(key) <= 8:
        return "*" * len(key)
    return f"{key[:6]}...{key[-4:]}"


def resolve_image_api_config(*, require_gpt_image2: bool = False) -> dict[str, str]:
    """Resolve image API endpoint/key.

    Priority:
    1. GPT_IMAGE2_API_KEY (NewAPI gateway for GPT Image 2)
    2. OPENAI_API_KEY + OPENAI_API_BASE (Bailian / OpenAI-compatible)
    3. DASHSCOPE_API_KEY (+ optional DASHSCOPE_BASE_URL / OPENAI_API_BASE)
    4. NN147_API_KEY / IMAGE_GENERATION_API_KEY + NN147/IMAGE base (fallback)
    """
    gpt_key = (os.getenv("GPT_IMAGE2_API_KEY") or "").strip()
    gpt_base = (os.getenv("GPT_IMAGE2_BASE") or _GPT_IMAGE2_BASE).strip()
    openai_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    openai_base = (os.getenv("OPENAI_API_BASE") or "").strip()
    dash_key = (os.getenv("DASHSCOPE_API_KEY") or "").strip()
    dash_base = (os.getenv("DASHSCOPE_BASE_URL") or os.getenv("DASHSCOPE_API_BASE") or "").strip()
    nn_key = (os.getenv("NN147_API_KEY") or os.getenv("IMAGE_GENERATION_API_KEY") or "").strip()
    nn_base = (os.getenv("NN147_BASE_URL") or os.getenv("IMAGE_GENERATION_BASE_URL") or "https://nn.147ai.com").strip()

    if require_gpt_image2:
        if not gpt_key:
            raise RuntimeError("GPT Image 2 API Key 未配置：请设置 GPT_IMAGE2_API_KEY")
        cfg: dict[str, str] = {
            "provider": "gpt-image-2",
            "base_url": gpt_base,
            "api_key": gpt_key,
            "label": "GPT Image 2",
            "default_model": _GPT_IMAGE2_MODEL,
        }
    elif gpt_key:
        cfg = {
            "provider": "gpt-image-2",
            "base_url": gpt_base,
            "api_key": gpt_key,
            "label": "GPT Image 2",
            "default_model": _GPT_IMAGE2_MODEL,
        }
    elif openai_key:
        base = _normalize_api_base(openai_base or _DASHSCOPE_COMPAT_BASE)
        cfg = {
            "provider": "bailian",
            "base_url": base,
            "api_key": openai_key,
            "label": "百炼/OpenAI兼容",
            "default_model": "qwen-image-2.0-pro",
        }
    elif dash_key:
        base = _normalize_api_base(dash_base or openai_base or _DASHSCOPE_COMPAT_BASE)
        cfg = {
            "provider": "bailian",
            "base_url": base,
            "api_key": dash_key,
            "label": "百炼/DashScope",
            "default_model": "wan2.7-image-pro",
        }
    elif nn_key:
        base = _normalize_api_base(nn_base or "https://nn.147ai.com")
        cfg = {
            "provider": "nn147",
            "base_url": base,
            "api_key": nn_key,
            "label": "nn147兼容回退",
            "default_model": "gpt-image-2-medium",
        }
    else:
        raise RuntimeError(
            "生图 API Key 未配置：请设置 GPT_IMAGE2_API_KEY（推荐），"
            "或 OPENAI_API_KEY / DASHSCOPE_API_KEY（百炼），"
            "或 NN147_API_KEY / IMAGE_GENERATION_API_KEY（兼容回退）"
        )

    _logger.info(
        "[ImageGen] resolved gateway provider=%s base=%s model=%s key=%s require_gpt_image2=%s",
        cfg["provider"],
        cfg["base_url"],
        cfg["default_model"],
        _mask_api_key(cfg["api_key"]),
        require_gpt_image2,
    )
    return cfg


def _images_generations_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/images/generations"):
        return base
    return f"{base}/images/generations"


def _images_edits_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/images/edits"):
        return base
    return f"{base}/images/edits"


def _raise_image_api_error(label: str, status_code: int, detail: str) -> None:
    message = f"{label} API 错误 {status_code}: {detail[:300]}"
    normalized_detail = detail.lower()
    if status_code == 429 or "ratequota" in normalized_detail or "rate limit" in normalized_detail:
        raise ImageGenerationRateLimitError(message)
    raise RuntimeError(message)


def _decode_image_response(data: dict[str, Any], label: str, timeout: int) -> bytes:
    items = data.get("data") or []
    if not items:
        raise RuntimeError(f"{label} 返回空 data")
    item = items[0]
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    if item.get("url"):
        img_resp = requests.get(item["url"], timeout=timeout)
        if img_resp.status_code >= 400:
            raise RuntimeError(f"{label} 图片下载失败: {img_resp.status_code}")
        return img_resp.content
    raise RuntimeError(f"{label} 响应缺少 b64_json/url")


_RETRYABLE_CURL_EXIT_CODES = frozenset({6, 7, 18, 28, 35, 52, 55, 56, 92})
_IMAGE_EDIT_RETRY_DELAY_SECONDS = 1


_EDIT_REFERENCE_MAX_BYTES = 120 * 1024  # aitracenex 对 ≳130KB 参考图会在 ~51s 掐断连接（exit 56）
_EDIT_REFERENCE_MIN_EDGE = 512


def _compress_edit_reference(image_bytes: bytes, *, max_edge: int = 1024) -> tuple[bytes, str]:
    """Downscale the /images/edits reference so the gateway doesn't drop the link.

    Returns ``(bytes, file_extension)``. The api.aitracenex.com gateway truncates
    the TLS connection (~51-54s, curl exit 56) when the reference image payload is
    large, so a big reference reliably fails. We flatten any transparent art onto a
    white background, encode as JPEG, and shrink until the payload fits the observed
    safe budget.
    """
    img = Image.open(io.BytesIO(image_bytes))
    if img.format == "JPEG" and max(img.size) <= max_edge and len(image_bytes) <= _EDIT_REFERENCE_MAX_BYTES:
        return image_bytes, "jpg"

    # 参考图（尤其是官方小熊 IP）多为 RGBA 截图：带透明通道会让 PNG 压不下来，
    # 网关仍会断连。展平成白底——白底也是海报里最常见的放置底色——统一输出 JPEG。
    if img.mode in ("RGBA", "LA", "PA", "P"):
        rgba = img.convert("RGBA")
        white = Image.new("RGB", rgba.size, (255, 255, 255))
        white.paste(rgba, mask=rgba.getchannel("A"))
        img = white
    else:
        img = img.convert("RGB")

    edge = max_edge
    buf = io.BytesIO()
    while True:
        target = img.copy()
        target.thumbnail((edge, edge), Image.Resampling.LANCZOS)
        buf.seek(0)
        buf.truncate(0)
        target.save(buf, format="JPEG", quality=85, optimize=True)
        size = buf.getvalue()
        if len(size) <= _EDIT_REFERENCE_MAX_BYTES or edge <= _EDIT_REFERENCE_MIN_EDGE:
            return size, "jpg"
        edge = max(_EDIT_REFERENCE_MIN_EDGE, int(edge * 0.8))


def _call_gpt_image_edit(
    *,
    prompt: str,
    model: str,
    size: str,
    reference_image_bytes: bytes,
    api_base: str,
    api_key: str,
    timeout: int,
    label: str,
) -> bytes:
    """Use the edit endpoint when a GPT image reference is supplied.

    Uses curl via subprocess because Python requests has issues with the
    multipart encoding expected by NewAPI gateways for /images/edits.
    """
    import subprocess
    import tempfile

    # 将提示词写入临时文件，避免 Shell 转义问题
    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt", encoding="utf-8") as f:
        f.write(prompt)
        prompt_file = f.name

    # 压缩参考图，避免网关因大图掐断连接（curl exit 56），再写临时文件供 curl 读取
    ref_bytes, ref_ext = _compress_edit_reference(reference_image_bytes)
    _logger.info(
        "[GPT Image 2 Edits] reference original=%d bytes compressed=%d bytes ext=%s",
        len(reference_image_bytes),
        len(ref_bytes),
        ref_ext,
    )
    with tempfile.NamedTemporaryFile(mode="wb", delete=False, suffix=f".{ref_ext}") as f:
        f.write(ref_bytes)
        image_file = f.name

    try:
        cmd = [
            "curl",
            "-sS",
            "--connect-timeout",
            "30",
            "--max-time",
            str(timeout),
            "-X",
            "POST",
            _images_edits_url(api_base),
            "-H",
            f"Authorization: Bearer {api_key}",
            "-F",
            f"model={model}",
            "-F",
            f"prompt=<{prompt_file}",
            "-F",
            "n=1",
            "-F",
            f"size={size}",
            "-F",
            f"image=@{image_file}",
        ]

        result = None
        for attempt in range(2):
            _logger.info(
                "[GPT Image 2 Edits] curl start attempt=%d/2 base=%s url=%s model=%s size=%s "
                "prompt=%d chars max_time=%d",
                attempt + 1,
                api_base,
                _images_edits_url(api_base),
                model,
                size,
                len(prompt),
                timeout,
            )
            attempt_started = time.monotonic()
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 5)
            except subprocess.TimeoutExpired as exc:
                _logger.warning(
                    "[GPT Image 2 Edits] curl timed out attempt=%d/2 elapsed=%.1fs; retrying once",
                    attempt + 1,
                    time.monotonic() - attempt_started,
                )
                if attempt == 0:
                    time.sleep(_IMAGE_EDIT_RETRY_DELAY_SECONDS)
                    continue
                raise RuntimeError(f"{label} 生图服务响应超时，请稍后重新生成") from exc

            elapsed = time.monotonic() - attempt_started
            if result.returncode == 0:
                _logger.info(
                    "[GPT Image 2 Edits] curl ok attempt=%d/2 elapsed=%.1fs stdout=%d bytes",
                    attempt + 1,
                    elapsed,
                    len(result.stdout or ""),
                )
                break

            raw_stderr = result.stderr or result.stdout or f"curl exit code {result.returncode}"
            _logger.warning(
                "[GPT Image 2 Edits] curl non-zero attempt=%d/2 exit=%d elapsed=%.1fs stderr=%s",
                attempt + 1,
                result.returncode,
                elapsed,
                raw_stderr,
            )
            stderr = raw_stderr[:300]
            if attempt == 0 and result.returncode in _RETRYABLE_CURL_EXIT_CODES:
                _logger.warning(
                    "[GPT Image 2 Edits] curl transient failure (exit=%d); retrying once: %s",
                    result.returncode,
                    stderr,
                )
                time.sleep(_IMAGE_EDIT_RETRY_DELAY_SECONDS)
                continue

            _logger.error("[GPT Image 2 Edits] curl failed: %s", stderr)
            raise RuntimeError(f"{label} curl 命令失败: {stderr}")

        if result is None or result.returncode != 0:
            raise RuntimeError(f"{label} 生图服务连接失败，请稍后重新生成")

        resp_text = result.stdout
        _logger.info("[GPT Image 2 Edits] response: %d bytes", len(resp_text))

        try:
            data = json.loads(resp_text)
        except json.JSONDecodeError as exc:
            _logger.info("[GPT Image 2 Edits] non-JSON response: %s", resp_text[:200])
            raise RuntimeError(f"{label} 返回非 JSON") from exc

        if "error" in data:
            error_msg = data["error"].get("message", "Unknown error")
            _logger.error("[GPT Image 2 Edits] API error: %s", error_msg)
            detail = error_msg[:300]
            normalized = detail.lower()
            if "ratequota" in normalized or "rate limit" in normalized:
                raise ImageGenerationRateLimitError(f"{label} API 错误: {detail}")
            raise RuntimeError(f"{label} API 错误: {detail}")

        return _decode_image_response(data, label, timeout)
    finally:
        for tmp in (prompt_file, image_file):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def call_image_generate(
    *,
    prompt: str,
    width: int,
    height: int,
    model: str | None = None,
    timeout: float = 120,
    reference_image_bytes: bytes | None = None,
    canvas_id: str | None = None,
    use_edit_endpoint: bool = True,
    force_gpt_image2: bool = False,
    deadline: TimeoutDeadline | None = None,
    body_only: bool = False,
) -> bytes:
    """Call image generation API and return image bytes（统一打点收口入口）。"""
    from app.audit.token_tracker import track_llm_call

    if deadline is not None:
        timeout = min(timeout, deadline.require_remaining())

    cfg = resolve_image_api_config(require_gpt_image2=force_gpt_image2)
    override_model = os.getenv("XIAO_HAI_IMAGE_MODEL", "")
    model_name = model or override_model or cfg["default_model"]

    with track_llm_call(model_name, agent="xiao_hai", operation="generate_poster", call_type="image") as _ctx:
        _ctx.width, _ctx.height = width, height
        result = _call_image_generate_impl(
            prompt=prompt,
            width=width,
            height=height,
            model=model,
            timeout=timeout,
            reference_image_bytes=reference_image_bytes,
            canvas_id=canvas_id,
            use_edit_endpoint=use_edit_endpoint,
            force_gpt_image2=force_gpt_image2,
            body_only=body_only,
        )
    return result


def _call_image_generate_impl(
    *,
    prompt: str,
    width: int,
    height: int,
    model: str | None = None,
    timeout: float = 120,
    reference_image_bytes: bytes | None = None,
    canvas_id: str | None = None,
    use_edit_endpoint: bool = True,
    force_gpt_image2: bool = False,
    body_only: bool = False,
) -> bytes:
    """Call image generation API and return image bytes.

    GPT Image 2: images/generations API with size mapping.
    Bailian/DashScope: native multimodal-generation API (messages format).
    nn147 / OpenAI-compatible: images/generations API.
    """
    cfg = resolve_image_api_config(require_gpt_image2=force_gpt_image2)
    # 动态读取覆盖模型（模块导入时缓存会导致测试/运行时环境变量变化不生效）
    override_model = os.getenv("XIAO_HAI_IMAGE_MODEL", "")
    model_name = model or override_model or cfg["default_model"]
    provider = cfg["provider"]
    _logger.info(
        "[ImageGen] dispatch provider=%s model=%s canvas=%s ref_bytes=%d edit=%s force_gpt_image2=%s timeout=%d",
        provider,
        model_name,
        canvas_id,
        len(reference_image_bytes or b""),
        use_edit_endpoint,
        force_gpt_image2,
        timeout,
    )

    if provider == "gpt-image-2":
        # 将 canvas_id 映射为支持的尺寸
        gpt_size = (
            f"{((width + 15) // 16) * 16}x{((height + 15) // 16) * 16}"
            if body_only
            else _GPT_IMAGE2_SIZES.get(canvas_id or "long", "1024x1536")
        )
        if reference_image_bytes and use_edit_endpoint:
            return _call_gpt_image_edit(
                prompt=prompt,
                model=model_name,
                size=gpt_size,
                reference_image_bytes=reference_image_bytes,
                api_base=cfg["base_url"],
                api_key=cfg["api_key"],
                timeout=timeout,
                label=cfg["label"],
            )
        url = _images_generations_url(cfg["base_url"])
        payload: dict[str, Any] = {
            "model": model_name,
            "prompt": prompt,
            "n": 1,
            "size": gpt_size,
        }
        headers = {
            "Authorization": f"Bearer {cfg['api_key']}",
            "Content-Type": "application/json",
        }
        _logger.info(
            "[ImageGen] gpt-image-2 generations POST url=%s model=%s size=%s timeout=%d",
            url,
            model_name,
            gpt_size,
            timeout,
        )
        started = time.monotonic()
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=timeout)
        except requests.RequestException as exc:
            _logger.error(
                "[ImageGen] gpt-image-2 generations request failed elapsed=%.1fs err=%s",
                time.monotonic() - started,
                exc,
            )
            raise RuntimeError(f"{cfg['label']} 请求失败: {exc}") from exc

        _logger.info(
            "[ImageGen] gpt-image-2 generations resp elapsed=%.1fs status=%d body=%d bytes",
            time.monotonic() - started,
            resp.status_code,
            len(resp.text or ""),
        )
        if resp.status_code >= 400:
            detail = (resp.text or "")[:300]
            _raise_image_api_error(cfg["label"], resp.status_code, detail)

        try:
            data = resp.json()
        except ValueError as exc:
            raise RuntimeError(f"{cfg['label']} 返回非 JSON") from exc

        return _decode_image_response(data, cfg["label"], timeout)

    if provider == "bailian":
        return _call_bailian_native(
            prompt=prompt,
            width=width,
            height=height,
            model=model_name,
            timeout=timeout,
            reference_image_bytes=reference_image_bytes,
            api_key=cfg["api_key"],
            label=cfg["label"],
        )

    # nn147 / OpenAI 兼容接口路径
    url = _images_generations_url(cfg["base_url"])
    payload: dict[str, Any] = {
        "model": model_name,
        "prompt": prompt,
        "n": 1,
        "size": f"{width}x{height}",
        "response_format": "b64_json",
    }
    if reference_image_bytes:
        payload["image"] = prepare_reference_image_b64(reference_image_bytes)

    headers = {
        "Authorization": f"Bearer {cfg['api_key']}",
        "Content-Type": "application/json",
    }
    _logger.info(
        "[ImageGen] nn147 generations POST url=%s model=%s size=%dx%d timeout=%d",
        url,
        model_name,
        width,
        height,
        timeout,
    )
    started = time.monotonic()
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=timeout)
    except requests.RequestException as exc:
        _logger.error(
            "[ImageGen] nn147 generations request failed elapsed=%.1fs err=%s",
            time.monotonic() - started,
            exc,
        )
        raise RuntimeError(f"{cfg['label']} 请求失败: {exc}") from exc

    _logger.info(
        "[ImageGen] nn147 generations resp elapsed=%.1fs status=%d body=%d bytes",
        time.monotonic() - started,
        resp.status_code,
        len(resp.text or ""),
    )
    if resp.status_code >= 400:
        detail = (resp.text or "")[:300]
        _raise_image_api_error(cfg["label"], resp.status_code, detail)

    try:
        data = resp.json()
    except ValueError as exc:
        raise RuntimeError(f"{cfg['label']} 返回非 JSON") from exc

    return _decode_image_response(data, cfg["label"], timeout)


_DASHSCOPE_NATIVE_IMG = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation"


def _compress_ref_for_bailian(image_bytes: bytes) -> str:
    """Compress reference image to tiny JPEG for DashScope content limits."""
    img = Image.open(io.BytesIO(image_bytes))
    img = img.convert("RGB")
    img.thumbnail((320, 320), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=55, optimize=True)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _call_bailian_native(
    *,
    prompt: str,
    width: int,
    height: int,
    model: str,
    timeout: int,
    reference_image_bytes: bytes | None,
    api_key: str,
    label: str,
) -> bytes:
    """DashScope native text-to-image API with optional reference image."""
    text = prompt[:1800] if len(prompt) > 1800 else prompt
    content: list[dict[str, Any]] = [{"text": text}]
    if reference_image_bytes:
        # 高强度压缩以满足 DashScope 限制
        ref_b64 = _compress_ref_for_bailian(reference_image_bytes)
        # 参考图放在最后（文字之后），使模型将其视为角色参考，
        # 而不是需要修改的底图。
        content.append({"image": f"data:image/jpeg;base64,{ref_b64}"})
    payload = {
        "model": model,
        "input": {
            "messages": [{"role": "user", "content": content}],
        },
        "parameters": {"size": f"{max(512, min(width, 1664))}*{max(512, min(height, 1664))}"},
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    try:
        resp = requests.post(_DASHSCOPE_NATIVE_IMG, json=payload, headers=headers, timeout=timeout)
    except requests.RequestException as exc:
        raise RuntimeError(f"{label} 请求失败: {exc}") from exc
    if resp.status_code >= 400:
        detail = (resp.text or "")[:300]
        _raise_image_api_error(label, resp.status_code, detail)
    try:
        data = resp.json()
    except ValueError as exc:
        raise RuntimeError(f"{label} 返回非 JSON") from exc
    choices = (data.get("output") or {}).get("choices") or []
    if not choices:
        raise RuntimeError(f"{label} 返回空 choices")
    content_list = (choices[0].get("message") or {}).get("content") or []
    for item in content_list:
        if item.get("image"):
            img_resp = requests.get(item["image"], timeout=timeout)
            if img_resp.status_code >= 400:
                raise RuntimeError(f"{label} 图片下载失败: {img_resp.status_code}")
            return img_resp.content
    raise RuntimeError(f"{label} 响应缺少图片 URL")


def call_nn147_generate(
    *,
    prompt: str,
    width: int,
    height: int,
    model: str | None = None,
    timeout: int = 120,
    reference_image_bytes: bytes | None = None,
) -> bytes:
    """Backward-compatible alias → call_image_generate."""
    return call_image_generate(
        prompt=prompt,
        width=width,
        height=height,
        model=model,
        timeout=timeout,
        reference_image_bytes=reference_image_bytes,
    )


def image_bytes_to_pil(data: bytes) -> Image.Image:
    return Image.open(io.BytesIO(data)).convert("RGB")


def pil_to_png_bytes(image: Image.Image) -> bytes:
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return buf.getvalue()
