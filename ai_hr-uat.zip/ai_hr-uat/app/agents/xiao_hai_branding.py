"""小海海报的确定性品牌素材读取与最终覆盖。"""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import BinaryIO
from urllib.parse import unquote, urlsplit

from PIL import Image

from app.config import REACT_PUBLIC_DIR
from app.media_storage import get_media_storage
from app.template_compositor import CANVAS_CONFIGS, CANVAS_ID_MAP, delivery_layout

STOCK_CODE = "02517.HK"
_LOGO_VISIBLE_RATIO = 0.12
_LOGO_INNER_PADDING_RATIO = 0.06
_VERTICAL_MASTER = "poster/green-master-vertical.png"
_HORIZONTAL_MASTER = "poster/green-master-horizontal.png"


class PosterBrandingError(ValueError):
    """品牌素材缺失或无法用于海报合成。"""


@dataclass(frozen=True)
class PosterBrandAssets:
    """生成前必须就绪的公司品牌素材。"""

    logo_bytes: bytes
    qr_bytes: bytes


def default_master_filename(canvas_id: str) -> str:
    """根据画幅方向返回项目内置绿色品牌母版。"""
    return _HORIZONTAL_MASTER if canvas_id == "dy_h" else _VERTICAL_MASTER


def validate_brand_image(
    image_bytes: bytes | bytearray | BinaryIO | None,
    *,
    label: str,
) -> Image.Image:
    """打开并验证品牌图片，失败时返回可直接展示给用户的错误。"""
    if not image_bytes:
        raise PosterBrandingError(f"{label}未配置或文件为空")
    try:
        image = Image.open(BytesIO(bytes(image_bytes))).convert("RGBA")
        image.load()
    except Exception as exc:
        raise PosterBrandingError(f"{label}不是有效图片") from exc
    if image.width < 2 or image.height < 2:
        raise PosterBrandingError(f"{label}尺寸无效")
    return image


def _local_brand_path(value: str) -> Path | None:
    path = unquote(urlsplit(value).path).replace("\\", "/")
    marker = "/brand/"
    if marker not in path:
        return None
    relative = path.split(marker, 1)[1]
    if not relative or ".." in Path(relative).parts:
        return None
    brand_root = (Path(REACT_PUBLIC_DIR) / "brand").resolve()
    candidate = (brand_root / relative).resolve()
    return candidate if candidate.is_relative_to(brand_root) else None


def _read_config_image(config: dict, field: str, key_field: str) -> bytes | None:
    storage_key = str(config.get(key_field) or "").strip()
    if storage_key:
        storage = get_media_storage()
        if storage.exists(storage_key):
            return storage.read(storage_key)
        return None
    path = _local_brand_path(str(config.get(field) or ""))
    if not path:
        return None
    if path.suffix.lower() == ".svg":
        raster_path = path.with_suffix(".png")
        if raster_path.is_file():
            return raster_path.read_bytes()
    return path.read_bytes() if path.is_file() else None


def load_company_brand_assets(config: dict) -> PosterBrandAssets:
    """从公司配置读取真实 Logo 与 HR 二维码。"""
    logo_bytes = _read_config_image(config, "company_logo", "company_logo_storage_key")
    qr_bytes = _read_config_image(config, "hr_qr_code", "hr_qr_code_storage_key")
    validate_brand_image(logo_bytes, label="Logo")
    validate_brand_image(qr_bytes, label="HR 二维码")
    return PosterBrandAssets(logo_bytes=logo_bytes or b"", qr_bytes=qr_bytes or b"")


def read_default_master(canvas_id: str) -> bytes:
    """读取并验证当前画幅的本地绿色默认母版。"""
    relative = default_master_filename(canvas_id)
    path = Path(REACT_PUBLIC_DIR) / "brand" / relative
    data = path.read_bytes() if path.is_file() else None
    validate_brand_image(data, label="默认品牌母版")
    return data or b""


def read_default_element() -> bytes:
    """读取未选择装饰元素时使用的默认品牌 IP 素材。"""
    path = Path(REACT_PUBLIC_DIR) / "brand" / "guoquan-mascot.png"
    data = path.read_bytes() if path.is_file() else None
    validate_brand_image(data, label="默认装饰元素")
    return data or b""


def _canvas_config(canvas_id: str) -> dict:
    template_id = CANVAS_ID_MAP.get(canvas_id, "recruit_long")
    return CANVAS_CONFIGS.get(template_id, CANVAS_CONFIGS["recruit_long"])


def _brand_boxes(config: dict) -> tuple[dict, dict]:
    layout = config["layout"]
    logo_layout = layout["logo"]
    title_layout = layout["title"]
    safe_gap = 8
    # Reserve the same visual weight across formats. Legacy title coordinates
    # are not collision bounds for the AI layout and must not shrink the Logo.
    short_side = min(config["width"], config["height"])
    logo_size = round(short_side * _LOGO_VISIBLE_RATIO / (1 - 2 * _LOGO_INNER_PADDING_RATIO))
    logo = {
        "x": logo_layout["x"],
        "y": logo_layout["y"],
        "w": logo_size,
        "h": logo_size,
    }
    stock_layout = layout["stock"]
    stock_height = max(stock_layout["h"], title_layout["y"] - stock_layout["y"] - safe_gap)
    stock = {
        "x": stock_layout["x"],
        "y": stock_layout["y"],
        "w": stock_layout["w"],
        "h": stock_height,
    }
    return logo, stock


def brand_layout_prompt(canvas_id: str) -> str:
    """Give the model the same layout used to paste the real brand assets."""
    config = _canvas_config(canvas_id)
    width, height = config["width"], config["height"]
    logo, stock = _brand_boxes(config)
    # Some legacy layouts (notably Moments) use a narrower content column.
    # The AI stock label should still sit at the actual canvas's top-right.
    stock = {**stock, "x": width - max(24, logo["x"]) - stock["w"]}
    delivery = delivery_layout(canvas_id)
    qr = delivery["qr_slot"]

    def region(box: dict) -> str:
        x, y = box["x"], box["y"]
        w, h = box.get("w", box.get("size")), box.get("h", box.get("size"))
        return (
            f"x={x}, y={y}, width={w}, height={h} px "
            f"(left={x / width:.1%}, top={y / height:.1%}, "
            f"right={(x + w) / width:.1%}, bottom={(y + h) / height:.1%})"
        )

    return f"""BRAND AND APPLICATION LAYOUT (final canvas {width} x {height}; origin at top-left):
- The company Logo shown at the top-left of the reference is a BRAND AND PLACEMENT GUIDE ONLY,
  not a decorative element. Use its real shape, aspect ratio and footprint to design the surrounding layout.
  Do not redraw, recolor, retype, stretch, rotate, outline, shadow or duplicate this Logo anywhere.
  In your OUTPUT, remove the reference Logo and leave natural continuous background in its reserved area.
  The program will restore the original Logo there with its original colors and lettering after generation.
- Real Logo reserved area: {region(logo)}. Leave only a calm continuous background here.
  Keep the headline, letters, mascot, storefront signage and all important details outside this area,
  with at least 12 px clearance. Do not draw a Logo, placeholder, frame or background card here.
- Stock code text area at the top-right: {region(stock)}.
  Render exactly once: 股票代码：{STOCK_CODE}
  Draw it yourself as small, legible typography integrated with the poster, with sufficient contrast.
  Do not place it over shop signage or other text. Do not enclose it in a white badge or bordered card.
  The program will NOT draw or replace this stock code after generation.
- Real HR QR reserved square: {region(qr)}. Leave this exact square free of text and illustrations.
  Continue the surrounding application-area background naturally; do not draw a fake QR, phone icon,
  barcode, placeholder, frame, shadow or an oversized blank card. The real QR with its white quiet zone
  will be pasted inside this square only. Keep at least 12 px clearance around it.
- Contact text and the COMPLETE email belong inside: {region(delivery["email_box"])}.
  Align them vertically with the QR square. Reduce their font size or wrap them inside this text area;
  never extend the email, icons or CTA into the QR square.
These reserved areas take priority over the reference image and requests to preserve an old layout.
If the reference has text or a brand asset in these areas, reflow the content and rebuild the background
there naturally. Keep the two reserved areas visually integrated, not as visible placeholder panels."""


def _open_raw_image(raw_image: Image.Image | bytes | bytearray) -> Image.Image:
    if isinstance(raw_image, Image.Image):
        return raw_image.convert("RGBA")
    return validate_brand_image(raw_image, label="模型原图")


def _cover_canvas(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    target_width, target_height = size
    scale = max(target_width / image.width, target_height / image.height)
    resized = image.resize(
        (round(image.width * scale), round(image.height * scale)),
        Image.Resampling.LANCZOS,
    )
    left = (resized.width - target_width) // 2
    top = (resized.height - target_height) // 2
    return resized.crop((left, top, left + target_width, top + target_height))


def _adapt_canvas(image: Image.Image, size: tuple[int, int], canvas_id: str) -> Image.Image:
    """按比例铺满并裁切，避免把模型内容拉伸到目标画幅。"""
    return _cover_canvas(image, size)


def _fit_image(image: Image.Image, width: int, height: int) -> Image.Image:
    scale = min(width / image.width, height / image.height)
    return image.resize(
        (max(1, round(image.width * scale)), max(1, round(image.height * scale))),
        Image.Resampling.LANCZOS,
    )


def _paste_logo(canvas: Image.Image, logo: Image.Image, box: dict) -> None:
    inner_padding = max(4, round(min(box["w"], box["h"]) * _LOGO_INNER_PADDING_RATIO))
    alpha_bbox = logo.getchannel("A").getbbox()
    if alpha_bbox:
        logo = logo.crop(alpha_bbox)
    fitted = _fit_image(
        logo,
        max(1, box["w"] - inner_padding * 2),
        max(1, box["h"] - inner_padding * 2),
    )
    x = box["x"] + (box["w"] - fitted.width) // 2
    y = box["y"] + (box["h"] - fitted.height) // 2
    canvas.alpha_composite(fitted, (x, y))


def apply_logo_reference(
    reference_image: Image.Image | bytes,
    *,
    logo_bytes: bytes,
    canvas_id: str,
    body_layout=None,
) -> Image.Image:
    """Place the original Logo after all background/decoration processing.

    Share the final compositor's placement and alpha handling, without matte
    removal, recoloring or any mutation of the cached reference board.
    """
    canvas = _open_raw_image(reference_image).copy()
    config = _canvas_config(canvas_id)
    expected_size = (body_layout.body.w, body_layout.body.h) if body_layout else (config["width"], config["height"])
    if canvas.size != expected_size:
        raise PosterBrandingError("Logo 参考图尺寸必须与目标画幅一致")
    logo = validate_brand_image(logo_bytes, label="Logo")
    logo_box, _ = _brand_boxes(config)
    if body_layout:
        from dataclasses import asdict

        logo_box = asdict(body_layout.logo)
    _paste_logo(canvas, logo, logo_box)
    return canvas


def _qr_box(canvas: Image.Image, canvas_id: str) -> tuple[int, int, int, int]:
    """按投递区设计坐标返回真实二维码的方形槽位。"""
    from app.template_compositor import qr_slot_from_delivery

    design = qr_slot_from_delivery(canvas_id)
    scale_x = canvas.width / design["canvas_w"]
    scale_y = canvas.height / design["canvas_h"]
    scale = min(scale_x, scale_y)
    size = max(1, round(design["size"] * scale))
    left = round(design["x"] * scale_x)
    bottom = round((design["y"] + design["size"]) * scale_y)
    top = bottom - size
    return left, top, left + size, bottom


def _paste_qr(canvas: Image.Image, qr: Image.Image, box: tuple[int, int, int, int]) -> None:
    """按固定投递区坐标仅贴入真实二维码及其必要静区。"""
    left, top, right, bottom = box
    slot_size = min(right - left, bottom - top)
    qr_inner = max(1, round(slot_size * 0.9))
    scale = min(qr_inner / qr.width, qr_inner / qr.height)
    fitted = qr.resize(
        (max(1, round(qr.width * scale)), max(1, round(qr.height * scale))),
        Image.Resampling.NEAREST,
    ).convert("RGBA")
    # A compact white quiet zone belongs to the QR itself, not a blurred footer
    # patch. Preserve the source's aspect ratio and transparent/light margins.
    tile = Image.new("RGBA", (slot_size, slot_size), "white")
    tile.alpha_composite(fitted, ((slot_size - fitted.width) // 2, (slot_size - fitted.height) // 2))
    canvas.alpha_composite(tile, (left, top))


def apply_poster_branding(
    raw_image: Image.Image | bytes | bytearray,
    *,
    logo_bytes: bytes | bytearray | None,
    qr_bytes: bytes | bytearray | None,
    canvas_id: str,
    background_bytes: bytes | bytearray | None = None,
) -> Image.Image:
    """仅在预留区贴入真实 Logo 和二维码；股票代码由模型排版绘制。

    ``background_bytes`` 仅为兼容旧调用保留，不能用于覆盖模型主体画面。
    """
    config = _canvas_config(canvas_id)
    canvas = _adapt_canvas(_open_raw_image(raw_image), (config["width"], config["height"]), canvas_id)
    logo = validate_brand_image(logo_bytes, label="Logo")
    qr = validate_brand_image(qr_bytes, label="HR 二维码")
    logo_box, _ = _brand_boxes(config)
    qr_box = _qr_box(canvas, canvas_id)
    # Never erase model pixels around a fixed slot: that can destroy headlines,
    # signage or email text. The generation prompt reserves these exact areas.
    _paste_logo(canvas, logo, logo_box)
    _paste_qr(canvas, qr, qr_box)
    return canvas.convert("RGB")
