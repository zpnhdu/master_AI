"""Model-based scoring for the Xiao Shai screening workflow."""

import asyncio
import os
from typing import Any

from hermes_wrapper.models import LLMRequest

DEFAULT_SCREENING_MODEL = os.getenv("SCREENING_MODEL", "qwen-plus")
DEFAULT_RUBRIC = {
    "dimensions": [
        {"key": "role_fit", "label": "岗位职责匹配", "weight": 30},
        {"key": "industry_experience", "label": "行业与业务经验", "weight": 25},
        {"key": "management_scope", "label": "管理范围与复杂度", "weight": 20},
        {"key": "achievement_evidence", "label": "业绩成果证据", "weight": 20},
        {"key": "basic_requirements", "label": "基础条件", "weight": 5},
    ],
    "source": "default",
}


def _score(value: Any, fallback: int = 0) -> int:
    try:
        return min(max(round(float(value)), 0), 100)
    except (TypeError, ValueError):
        return fallback


def _confidence(value: Any) -> float:
    try:
        return min(max(float(value), 0.0), 1.0)
    except (TypeError, ValueError):
        return 0.0


MISSING_INFO_SEVERITIES = {"critical", "important", "minor"}


def _text_items(value: Any, limit: int = 5) -> list[str]:
    if isinstance(value, (str, int, float)):
        value = [value]
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()][:limit]


def _normalize_missing_info(value: Any, limit: int = 8) -> list[dict]:
    if isinstance(value, (str, int, float)):
        value = [value]
    if not isinstance(value, list):
        return []
    normalized = []
    seen = set()
    for item in value[:limit]:
        if isinstance(item, dict):
            label = str(item.get("label") or item.get("name") or item.get("field") or "").strip()
            reason = str(item.get("reason") or item.get("evidence") or "").strip()
            severity = str(item.get("severity") or "important").strip().lower()
        else:
            label = str(item).strip()
            reason = ""
            severity = "important"
        if not label or label in seen:
            continue
        if severity not in MISSING_INFO_SEVERITIES:
            severity = "important"
        normalized.append({"label": label, "severity": severity, "reason": reason})
        seen.add(label)
    return normalized


def _normalize_rubric(payload: Any) -> dict:
    dimensions = payload.get("dimensions") if isinstance(payload, dict) else None
    normalized = []
    if isinstance(dimensions, list):
        for index, item in enumerate(dimensions[:6]):
            if not isinstance(item, dict):
                continue
            label = str(item.get("label") or item.get("name") or "").strip()
            if not label:
                continue
            key = str(item.get("key") or f"dimension_{index + 1}").strip()
            normalized.append({"key": key, "label": label, "weight": _score(item.get("weight"))})
    if not normalized:
        return dict(DEFAULT_RUBRIC)
    total = sum(item["weight"] for item in normalized)
    if total <= 0:
        return dict(DEFAULT_RUBRIC)
    normalized[-1]["weight"] += 100 - total
    if normalized[-1]["weight"] < 0:
        return dict(DEFAULT_RUBRIC)
    return {"dimensions": normalized, "source": "model"}


def _candidate_payload(candidate: dict) -> dict:
    return {
        key: candidate.get(key)
        for key in (
            "id",
            "name",
            "title",
            "current_position",
            "company",
            "current_company",
            "skills",
            "years_experience",
            "education",
            "location",
            "current_salary",
            "resume_text",
        )
        if candidate.get(key) not in (None, "", [])
    }


async def _chat_json(client, request: LLMRequest, *, pipeline_id: str, operation: str) -> dict:
    result = await client.chat_json(
        request,
        agent="xiao_shai",
        operation=operation,
        pipeline_id=pipeline_id,
        json_mode=True,
    )
    if not isinstance(result, dict) or result.get("error"):
        raise RuntimeError("模型未返回有效的结构化评分结果")
    return result


async def build_rubric(pipeline_id: str, jd: dict, client=None) -> dict:
    if client is None:
        from hermes_wrapper.client import get_client

        client = get_client()
    request = LLMRequest(
        model=DEFAULT_SCREENING_MODEL,
        complexity="plus",
        temperature=0.1,
        timeout=120,
        max_tokens=1200,
        system="你是招聘筛选标准设计专家，只输出合法JSON。",
        prompt=(
            "请根据以下岗位JD生成统一的候选人评分标准。最多5个评分维度，权重合计100，"
            "维度必须能从简历中找到证据。只返回："
            '{"dimensions":[{"key":"英文key","label":"中文名称","weight":整数}]}\n'
            f"岗位JD：{jd}"
        ),
    )
    try:
        return _normalize_rubric(
            await _chat_json(client, request, pipeline_id=pipeline_id, operation="screening_rubric")
        )
    except Exception:
        return dict(DEFAULT_RUBRIC)


async def score_candidate(pipeline_id: str, jd: dict, rubric: dict, candidate: dict, client=None) -> dict:
    if client is None:
        from hermes_wrapper.client import get_client

        client = get_client()
    request = LLMRequest(
        model=DEFAULT_SCREENING_MODEL,
        complexity="plus",
        temperature=0.1,
        timeout=120,
        max_tokens=1800,
        system="你是资深招聘评估专家。严格依据JD和评分标准评分，只输出合法JSON，不得臆造简历中不存在的经历。",
        prompt=(
            "请独立评估这一名候选人。总分必须是各维度按权重加权后的0到100整数。"
            "每个维度都要给出简短证据。对缺失的岗位相关信息单独列出，并标注严重度："
            "critical（关键）、important（重要）或minor（一般）；缺失信息只表示简历未提供，"
            "不要把不满足条件写成缺失。只返回："
            '{"overall_score":整数,"dimension_scores":[{"key":"英文key","label":"中文名称",'
            '"score":整数,"evidence":"证据或未找到"}],"strengths":[""],"concerns":[""],'
            '"missing_info":[{"label":"信息名称","severity":"critical|important|minor",'
            '"reason":"简历中未找到的依据"}],"confidence":0到1的小数,"summary":"一句话总结"}\n'
            f"JD：{jd}\n评分标准：{rubric}\n候选人简历：{_candidate_payload(candidate)}"
        ),
    )
    payload = await _chat_json(client, request, pipeline_id=pipeline_id, operation="screening_score")
    raw_overall_score = payload.get("overall_score")
    if raw_overall_score is None:
        raise RuntimeError("模型未返回综合评分")
    dimensions = payload.get("dimension_scores") or payload.get("dimensions") or []
    normalized_dimensions = []
    for item in dimensions[:8] if isinstance(dimensions, list) else []:
        if not isinstance(item, dict):
            continue
        normalized_dimensions.append(
            {
                "key": str(item.get("key") or "dimension").strip(),
                "label": str(item.get("label") or item.get("name") or "评分维度").strip(),
                "score": _score(item.get("score")),
                "evidence": str(item.get("evidence") or item.get("reason") or "未提供").strip(),
            }
        )
    return {
        "overall_score": _score(raw_overall_score),
        "model_score": _score(raw_overall_score),
        "dimension_scores": normalized_dimensions,
        "strengths": _text_items(payload.get("strengths")),
        "concerns": _text_items(payload.get("concerns")),
        "missing_info": _normalize_missing_info(payload.get("missing_info")),
        "confidence": _confidence(payload.get("confidence")),
        "summary": str(payload.get("summary") or "模型未提供评分总结").strip(),
        "score_source": "model",
    }


async def score_candidates(pipeline_id: str, jd: dict, rubric: dict, candidates: list[dict], client=None) -> list[dict]:
    if client is None:
        from hermes_wrapper.client import get_client

        client = get_client()
    semaphore = asyncio.Semaphore(4)

    async def score_one(candidate: dict) -> dict:
        async with semaphore:
            try:
                return {**candidate, **await score_candidate(pipeline_id, jd, rubric, candidate, client=client)}
            except Exception:
                return {
                    **candidate,
                    "overall_score": 0,
                    "model_score": 0,
                    "score_source": "model_failed",
                    "confidence": 0,
                    "dimension_scores": [],
                    "strengths": [],
                    "concerns": [],
                    "missing_info": ["模型评分失败"],
                    "summary": "模型评分失败，请人工复核",
                }

    return list(await asyncio.gather(*(score_one(candidate) for candidate in candidates)))
