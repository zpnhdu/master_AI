"""小面的自然语言预览、执行与权威数据回读。"""

from __future__ import annotations

import hashlib
import json
import logging
from copy import deepcopy

from app import assessment_flow
from app.conversation_capabilities import ConversationCapability
from app.db import get_interview_schedules, get_stages, update_stage
from app.interview_conversation import preview_message

logger = logging.getLogger(__name__)


def _revision(data) -> str:
    serialized = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _interview_data(pipeline_id: str) -> dict:
    stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "interview_gen"), None)
    output = (stage or {}).get("output") or {}
    return output if isinstance(output, dict) else {}


def _schedule_revision_data(schedules: list[dict]) -> list[dict]:
    fields = ("id", "candidate_id", "date", "time", "interviewer", "method", "round", "status", "notes")
    return [{field: schedule.get(field, "") for field in fields} for schedule in schedules]


def read_latest(pipeline_id: str) -> dict:
    questions = _interview_data(pipeline_id)
    schedules = get_interview_schedules(pipeline_id)
    assessment_plan = assessment_flow.get_active_plan(pipeline_id)
    assessment_queue = assessment_flow.list_decision_queue(pipeline_id)
    question_revision = _revision(questions)
    schedule_revision = _revision(_schedule_revision_data(schedules))
    plan_revision = _revision(assessment_plan or {})
    return {
        "resources": [
            {"key": "interview_questions", "revision": question_revision, "data": questions},
            {"key": "interview_schedules", "revision": schedule_revision, "data": schedules},
            {"key": "assessment_plan", "revision": plan_revision, "data": assessment_plan or {}},
            {"key": "assessment_queue", "revision": _revision(assessment_queue), "data": assessment_queue},
        ],
        "revision_map": {
            "interview_questions": question_revision,
            "interview_schedules": schedule_revision,
            "assessment_plan": plan_revision,
        },
    }


async def build_preview(
    pipeline_id: str, content: str, source: str, previous_command: dict | None, default_candidate_id: str = ""
) -> dict:
    result = await preview_message(pipeline_id, content, source, previous_command, default_candidate_id)
    if result["intent"] in {"schedule_interview", "reschedule_interview", "cancel_interview"} and result["preview"]:
        schedules = get_interview_schedules(pipeline_id)
        result["preview"]["schedules_version"] = _revision(_schedule_revision_data(schedules))
    if result["status"] == "clarifying":
        result["reply"] = result.get("message", "请补充必要信息。")
    elif result["intent"] == "configure_assessment_plan":
        result["reply"] = "已生成评估方案预览，确认后才会启用自动流转。"
    elif result["intent"] == "modify_questions":
        result["reply"] = "已生成面试题修改预览，确认后才会写入。"
    elif result["intent"] == "reschedule_interview":
        result["reply"] = "已生成面试改期预览，确认后才会写入。"
    elif result["intent"] == "cancel_interview":
        result["reply"] = "已生成取消面试预览，确认后才会写入。"
    else:
        result["reply"] = "已生成面试安排预览，确认后才会写入。"
    return result


def _load_interview_output(conn, pipeline_id: str) -> dict:
    row = conn.execute(
        """SELECT output FROM pipeline_stages
           WHERE pipeline_id=%s AND stage_id='interview_gen' ORDER BY id LIMIT 1""",
        (pipeline_id,),
    ).fetchone()
    if not row:
        raise ValueError("当前流水线没有面试题")
    output = row[0] or "{}"
    try:
        output = json.loads(output) if isinstance(output, str) else output
        output = json.loads(output) if isinstance(output, str) else output
    except (json.JSONDecodeError, TypeError):
        output = {}
    return output if isinstance(output, dict) else {}


def _rebuild_video_questions(reviewed_questions: list[dict], old_video_questions: list[dict]) -> list[dict]:
    """以改后的权威题为基准，重建视频面试题。

    视频 session 是发起时生成的快照。旧实现只在权威题带 ``follow_up`` 时
    更新视频题干，否则沿用旧快照中的 ``question``，导致“笔试已更新、视频
    仍是旧题”。现在没有追问时直接使用最新权威题干，并记录来源题干，后续
    再次同步也不会丢失修改。
    """
    video_questions = []
    for index, reviewed in enumerate(reviewed_questions):
        old = old_video_questions[index] if index < len(old_video_questions) else {}
        focus = reviewed.get("competency_ref") or reviewed.get("type") or old.get("focus") or "岗位核心能力"
        # 视频与笔试严格使用同一权威题干；follow_up 仅作为评分/追问元数据，
        # 不能替换候选人实际看到的题目。
        question_text = reviewed.get("question")
        if not question_text:
            question_text = old.get("question") or (
                f"请结合一个真实经历，说明你在{focus}方面遇到的关键挑战、采取的具体行动、最终结果和复盘。"
            )
        video_questions.append(
            {
                "type": reviewed.get("type") or old.get("type", "行为面试"),
                "question": question_text,
                "source_question": reviewed.get("question", ""),
                "tts_prefix": old.get("tts_prefix", ""),
                "focus": focus,
                "expected_points": reviewed.get("expected_points") or old.get("expected_points", []),
                "scoring_rubric": reviewed.get("scoring_rubric", {}),
                "difficulty": reviewed.get("difficulty", "中"),
                "time_limit_seconds": old.get("time_limit_seconds", 180),
                "answer_mode": "video",
                "assessment_modality": "video_interview",
            }
        )
    return video_questions


def _sync_downstream_questions(conn, pipeline_id: str, candidate_id: str, questions: list[dict]) -> None:
    """改题 / 撤销后，把权威题同步到已生成但尚未开始的下游快照。

    仅同步"未开始"的下游（候选人已作答 / 评分后题面对不上，不能动）：
    - 笔试 written_test_sessions：status='pending'
    - 视频面试 interview_sessions：status='invited'（题目为口述题，需重新组装）
    - 候选人录制 record_tokens：uploaded 为空
    笔试和视频面试属于关键下游，任一同步失败都会阻断并回滚改题主流程；
    录制中的内存快照属于非关键下游，失败只记录日志。
    """
    try:
        from app.written_scoring import build_written_rubric

        written_questions = []
        for raw_question in questions:
            if isinstance(raw_question, dict):
                question = dict(raw_question)
                question["written_scoring_rubric"] = build_written_rubric(question)
                written_questions.append(question)
        conn.execute(
            """UPDATE written_test_sessions
               SET questions=%s
               WHERE pipeline_id=%s AND candidate_id=%s
                 AND status IN ('pending','invited')
                 AND (started_at IS NULL OR started_at='')""",
            (json.dumps(written_questions, ensure_ascii=False), pipeline_id, candidate_id),
        )
    except Exception as error:
        logger.exception("written-test question sync failed pipeline=%s candidate=%s", pipeline_id, candidate_id)
        raise RuntimeError("在线笔试题目同步失败") from error

    try:
        rows = conn.execute(
            "SELECT token, questions FROM interview_sessions WHERE pipeline_id=%s AND candidate_id=%s AND status='invited' AND (started_at IS NULL OR started_at='')",
            (pipeline_id, candidate_id),
        ).fetchall()
        for row in rows:
            raw = row["questions"]
            old = raw if isinstance(raw, list) else json.loads(raw or "[]")
            video_questions = _rebuild_video_questions(questions, old if isinstance(old, list) else [])
            conn.execute(
                "UPDATE interview_sessions SET questions=%s, total_questions=%s WHERE token=%s",
                (json.dumps(video_questions, ensure_ascii=False), len(video_questions), row["token"]),
            )
    except Exception as error:
        logger.exception("video-interview question sync failed pipeline=%s candidate=%s", pipeline_id, candidate_id)
        raise RuntimeError("视频面试题目同步失败") from error

    try:
        from app import state

        for sess in state.record_tokens.values():
            if sess.get("pipeline_id") != pipeline_id or sess.get("candidate_id") != candidate_id:
                continue
            if sess.get("uploaded"):
                continue
            sess["questions"] = deepcopy(questions[:5])
    except Exception:
        logger.exception("recording question snapshot sync failed pipeline=%s candidate=%s", pipeline_id, candidate_id)


def _apply_question_change(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    from app.question_review import ensure_questions_editable

    ensure_questions_editable(command["pipeline_id"], preview["candidate_id"])
    output = _load_interview_output(conn, command["pipeline_id"])
    interview = next(
        (item for item in output.get("interviews", []) if item.get("candidate_id") == preview["candidate_id"]),
        None,
    )
    if not interview:
        raise ValueError("候选人面试题不存在")
    if _revision(interview.get("questions", [])) != preview["questions_version"]:
        return False, {}, "数据已被其他操作修改，请基于最新数据重新发起。"
    interview["questions"] = deepcopy(preview["after_questions"])
    # 审核通过后的任何改题都必须重新审核，避免下游使用未经确认的新题。
    interview["review_status"] = "pending"
    output["review_status"] = "pending"
    update_stage(command["pipeline_id"], "interview_gen", "done", output, conn=conn)
    _sync_downstream_questions(conn, command["pipeline_id"], preview["candidate_id"], preview["after_questions"])
    return True, {"candidate_id": preview["candidate_id"]}, "面试题已修改，并已读取最新数据。"


def _current_schedule_version(conn, pipeline_id: str) -> str:
    rows = conn.execute(
        "SELECT * FROM interview_schedules WHERE pipeline_id=%s ORDER BY date, time", (pipeline_id,)
    ).fetchall()
    return _revision(_schedule_revision_data([dict(row) for row in rows]))


def _apply_schedule(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    if _current_schedule_version(conn, command["pipeline_id"]) != preview["schedules_version"]:
        return False, {}, "数据已被其他操作修改，请基于最新数据重新发起。"
    schedule_id = f"schedule_{command['id']}"
    payload = command["payload"]
    conn.execute(
        """INSERT INTO interview_schedules
           (id, pipeline_id, candidate_id, date, time, interviewer, method, round, status, notes)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'scheduled', %s)""",
        (
            schedule_id,
            command["pipeline_id"],
            payload["candidate_id"],
            payload["date"],
            payload["time"],
            payload["interviewer"],
            payload["method"],
            payload.get("round", ""),
            payload.get("notes", ""),
        ),
    )
    return True, {"schedule_id": schedule_id}, "面试已安排，并已读取最新数据。"


def _apply_schedule_change(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    if _current_schedule_version(conn, command["pipeline_id"]) != preview["schedules_version"]:
        return False, {}, "数据已被其他操作修改，请基于最新数据重新预览。"
    schedule_id = preview["schedule_id"]
    current = conn.execute("SELECT * FROM interview_schedules WHERE id=%s", (schedule_id,)).fetchone()
    if not current or current["status"] == "cancelled":
        return False, {}, "该排期已不存在或已取消，请基于最新数据重新预览。"
    after = preview["after_schedule"]
    conn.execute(
        """UPDATE interview_schedules
           SET date=%s, time=%s, interviewer=%s, method=%s, round=%s, status=%s, notes=%s
           WHERE id=%s""",
        (
            after.get("date", ""),
            after.get("time", ""),
            after.get("interviewer", ""),
            after.get("method", ""),
            after.get("round", ""),
            after.get("status", "scheduled"),
            after.get("notes", ""),
            schedule_id,
        ),
    )
    action = preview["action"]
    reply = "面试已取消，并已读取最新数据。" if action == "cancel" else "面试时间已修改，并已读取最新数据。"
    return True, {"schedule_id": schedule_id, "action": action}, reply


def _apply_assessment_plan(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    active = assessment_flow.get_active_plan(command["pipeline_id"], conn)
    if (active or {}).get("id", "") != preview.get("before_plan_id", ""):
        return False, {}, "评估方案已被其他操作修改，请基于最新方案重新预览。"
    draft = assessment_flow.save_plan_draft(
        command["pipeline_id"],
        preview["after_config"],
        actor_id="conversation",
        conn=conn,
    )
    plan = assessment_flow.activate_plan(
        command["pipeline_id"],
        draft["id"],
        actor_id="conversation",
        conn=conn,
    )
    return (
        True,
        {"plan_id": plan["id"], "plan_version": plan["version"]},
        "评估方案已启用，后续将按规则自动流转到小评。",
    )


def execute(conn, command: dict) -> tuple[bool, dict, str]:
    if command["intent"] == "configure_assessment_plan":
        return _apply_assessment_plan(conn, command)
    if command["intent"] == "modify_questions":
        return _apply_question_change(conn, command)
    if command["intent"] == "schedule_interview":
        return _apply_schedule(conn, command)
    if command["intent"] in {"reschedule_interview", "cancel_interview"}:
        return _apply_schedule_change(conn, command)
    raise ValueError("该指令不能执行")


def _undo_question_change(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    output = _load_interview_output(conn, command["pipeline_id"])
    interview = next(
        (item for item in output.get("interviews", []) if item.get("candidate_id") == preview["candidate_id"]),
        None,
    )
    if not interview or _revision(interview.get("questions", [])) != _revision(preview["after_questions"]):
        return False, {}, "面试题已再次变化，不能自动撤销。"
    interview["questions"] = deepcopy(preview["before_questions"])
    interview["review_status"] = preview.get("before_review_status", "reviewed")
    output["review_status"] = "reviewed" if interview["review_status"] == "reviewed" else "pending"
    update_stage(command["pipeline_id"], "interview_gen", "done", output, conn=conn)
    _sync_downstream_questions(conn, command["pipeline_id"], preview["candidate_id"], preview["before_questions"])
    return True, {"candidate_id": preview["candidate_id"]}, "已撤销本次面试题修改。"


def _undo_schedule_change(conn, command: dict) -> tuple[bool, dict, str]:
    preview = command["preview"]
    schedule_id = (command.get("result") or {}).get("schedule_id") or preview.get("schedule_id", "")
    current_row = conn.execute("SELECT * FROM interview_schedules WHERE id=%s", (schedule_id,)).fetchone()
    if not current_row:
        return False, {}, "排期已不存在，不能自动撤销。"
    current = dict(current_row)
    if command["intent"] == "schedule_interview":
        expected = {**(command.get("payload") or {}), "status": "scheduled"}
        comparable = ("date", "time", "interviewer", "method", "round", "status", "notes")
        if any(current.get(field, "") != expected.get(field, "") for field in comparable):
            return False, {}, "排期已再次变化，不能自动撤销。"
        conn.execute("UPDATE interview_schedules SET status='cancelled' WHERE id=%s", (schedule_id,))
    else:
        after = preview["after_schedule"]
        comparable = ("date", "time", "interviewer", "method", "round", "status", "notes")
        if any(current.get(field, "") != after.get(field, "") for field in comparable):
            return False, {}, "排期已再次变化，不能自动撤销。"
        before = preview["before_schedule"]
        conn.execute(
            """UPDATE interview_schedules
               SET date=%s, time=%s, interviewer=%s, method=%s, round=%s, status=%s, notes=%s WHERE id=%s""",
            tuple(before.get(field, "") for field in comparable) + (schedule_id,),
        )
    return True, {"schedule_id": schedule_id}, "已撤销本次排期操作。"


def undo(conn, command: dict) -> tuple[bool, dict, str]:
    if command["intent"] == "configure_assessment_plan":
        preview = command["preview"]
        current = assessment_flow.get_active_plan(command["pipeline_id"], conn)
        if not current or current.get("id") != (command.get("result") or {}).get("plan_id"):
            return False, {}, "评估方案已再次变化，不能自动撤销。"
        before_plan_id = preview.get("before_plan_id", "")
        if before_plan_id:
            restored = assessment_flow.activate_plan(
                command["pipeline_id"], before_plan_id, actor_id="conversation_undo", conn=conn
            )
            return True, {"plan_id": restored["id"], "plan_version": restored["version"]}, "已恢复上一版评估方案。"
        conn.execute("UPDATE assessment_plans SET status='superseded' WHERE id=%s", (current["id"],))
        return True, {"plan_id": ""}, "已撤销评估方案启用。"
    if command["intent"] == "modify_questions":
        return _undo_question_change(conn, command)
    if command["intent"] in {"schedule_interview", "reschedule_interview", "cancel_interview"}:
        return _undo_schedule_change(conn, command)
    raise ValueError("该操作不支持撤销")


CAPABILITY = ConversationCapability(
    agent_id="xiao_mian",
    build_preview=build_preview,
    read_latest=read_latest,
    execute=execute,
    undo=undo,
)
