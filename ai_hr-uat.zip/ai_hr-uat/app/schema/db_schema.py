"""Database schema initialization and idempotent migrations.

The public ``app.db`` module remains the compatibility facade.  This module
keeps schema ownership separate while resolving runtime connections and
legacy helpers lazily through that facade, avoiding import cycles.
"""

import json

GUOQUAN_DEFAULT_BRAND_COLOR = "#16A34A"
LEGACY_GUOQUAN_BRAND_COLOR = "#E60012"

_MYSQL_LONG_TEXT_COLUMNS = {
    "context",
    "output",
    "skills",
    "resume_text",
    "reason",
    "video_assessment",
    "content",
    "card_data",
    "value",
    "rule_data",
    "preference_value",
    "data_json",
    "error",
    "error_message",
    "rules",
    "notes",
    "tags",
    "source_text",
    "payload",
    "preview",
    "result",
    "latest_data",
    "transcript",
    "questions",
    "answers",
    "dimension_scores",
    "video_paths",
    "snapshots",
    "message",
    "extra",
    "fields",
    "request_payload",
    "render_data",
    "package",
    "step_results",
    "evaluation",
    "config",
    "recording_url",
    "voice_answers",
    "response_text",
    "response_chart",
    "error_message_internal",
    "public_error_message",
    "tool_calls",
    "tool_results",
    "chart_spec",
}

_MYSQL_LONG_TEXT_COLUMNS_BY_TABLE: dict[str, set[str]] = {
    "candidate_assessment_reports": {"report_json"},
    "llm_trace": {"status"},
    "wiki_pages": {"sources", "embedding"},
    "wiki_ingest": {"error_msg", "pages_written"},
}


def _db_facade():
    """Resolve app.db only when schema work is invoked."""
    from app import db

    return db


def _parse_role_permissions(raw_value) -> list[str]:
    """Parse the persisted role permission JSON into a de-duplicated list."""
    if isinstance(raw_value, list):
        values = raw_value
    else:
        try:
            parsed = json.loads(raw_value or "[]")
            values = parsed if isinstance(parsed, list) else []
        except (TypeError, json.JSONDecodeError):
            values = []
    normalized = []
    for value in values:
        permission = str(value).strip()
        if permission and permission not in normalized:
            normalized.append(permission)
    return normalized


def get_db():
    return _db_facade().get_db()


def transaction():
    return _db_facade().transaction()


def _ensure_access_control_schema(conn):
    """创建 RBAC 表结构并写入预设角色。"""
    conn.executescript(
        """CREATE TABLE IF NOT EXISTS auth_roles (
            id VARCHAR(191) PRIMARY KEY,
            name VARCHAR(191) NOT NULL UNIQUE,
            description VARCHAR(191) NOT NULL DEFAULT '',
            permissions VARCHAR(191) NOT NULL DEFAULT '[]',
            is_system INTEGER NOT NULL DEFAULT 0,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS auth_users (
            id VARCHAR(191) PRIMARY KEY,
            username VARCHAR(191) NOT NULL UNIQUE ,
            display_name VARCHAR(191) NOT NULL DEFAULT '',
            password_hash VARCHAR(191) NOT NULL,
            role_id VARCHAR(191) NOT NULL,
            tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default',
            is_active INTEGER NOT NULL DEFAULT 1,
            last_login_at VARCHAR(191),
            hr_contact VARCHAR(191) NULL DEFAULT NULL,
            hr_qr_code_storage_key VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (role_id) REFERENCES auth_roles(id)
        );
CREATE TABLE IF NOT EXISTS auth_sessions (
            token_hash VARCHAR(191) PRIMARY KEY,
            user_id VARCHAR(191) NOT NULL,
            expires_at VARCHAR(191) NOT NULL,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (user_id) REFERENCES auth_users(id)
        );
CREATE INDEX idx_auth_users_role ON auth_users(role_id);
CREATE INDEX idx_auth_sessions_user ON auth_sessions(user_id);
CREATE INDEX idx_auth_sessions_expires ON auth_sessions(expires_at)"""
    )
    _seed_auth_defaults(conn)
    # 用户级招聘邮箱与投递二维码（从公司级配置下沉为 HR 个人配置；幂等补列）。
    # hr_contact 允许 NULL：唯一索引 uk_auth_users_hr_contact 依赖 NULL 不参与
    # 去重的语义，多个"未配置邮箱"的用户才可共存（旧列为 NOT NULL DEFAULT ''）。
    for column in ("hr_qr_code_storage_key", "wecom_userid"):
        try:
            conn.execute(f"ALTER TABLE auth_users ADD COLUMN {column} VARCHAR(191) NOT NULL DEFAULT ''")
        except Exception:
            pass
    try:
        conn.execute("ALTER TABLE auth_users ADD COLUMN hr_contact VARCHAR(191) NULL DEFAULT NULL")
    except Exception:
        pass
    _ensure_wecom_schema(conn)


def _ensure_wecom_schema(conn):
    """企业微信扫码登录：OAuth state 一次性凭据与通讯录同步快照。

    过期判断基于 created_at（数据库时钟）+ TTL，expires_at 列仅保留
    兼容旧数据，不再写入。
    """
    conn.executescript(
        """CREATE TABLE IF NOT EXISTS wecom_oauth_states (
            state VARCHAR(191) PRIMARY KEY,
            wecom_userid VARCHAR(191) NOT NULL DEFAULT '',
            bind_error_count INTEGER NOT NULL DEFAULT 0,
            expires_at VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW())
        );
CREATE INDEX idx_wecom_oauth_states_created ON wecom_oauth_states(created_at);
CREATE TABLE IF NOT EXISTS wecom_contacts (
            userid VARCHAR(191) PRIMARY KEY,
            name VARCHAR(191) NOT NULL DEFAULT '',
            department VARCHAR(191) NOT NULL DEFAULT '',
            synced_at VARCHAR(191) NOT NULL DEFAULT (NOW())
        )"""
    )
    # 旧表 expires_at 无默认值，幂等修正
    try:
        conn.execute("ALTER TABLE wecom_oauth_states MODIFY expires_at VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass


def _seed_auth_defaults(conn):
    """写入两种预设角色，并保留原有管理员账号作为升级兼容入口。"""
    defaults = [
        (
            "admin",
            "管理员",
            "拥有全部系统配置、用户、角色和招聘业务权限。",
            ["*"],
        ),
        (
            "hr_specialist",
            "HR专员",
            "负责招聘业务和 Agent 系统的日常操作。",
            [
                "pipeline:read",
                "talent:read",
                "interview:read",
                "analytics:read",
                "knowledge:read",
                "materials:read",
                "system:manage",
            ],
        ),
    ]
    for role_id, name, description, permissions in defaults:
        conn.execute(
            """
            INSERT INTO auth_roles (id, name, description, permissions, is_system)
            VALUES (%s, %s, %s, %s, 1)
            ON DUPLICATE KEY UPDATE
                name=VALUES(name), is_system=1, updated_at=NOW()
            """,
            (role_id, name, description, json.dumps(permissions, ensure_ascii=False)),
        )

    # 历史版本可能保存过不完整的 HR 权限集合；补齐导航权限。
    hr_role = conn.execute("SELECT permissions FROM auth_roles WHERE id='hr_specialist'").fetchone()
    if hr_role:
        current_permissions = _parse_role_permissions(hr_role["permissions"])
        required_permissions = {
            "pipeline:read",
            "interview:read",
            "talent:read",
            "analytics:read",
            "knowledge:read",
            "materials:read",
            "system:manage",
        }
        merged_permissions = list(dict.fromkeys([*current_permissions, *sorted(required_permissions)]))
        if merged_permissions != current_permissions or str(hr_role["permissions"] or "") != json.dumps(
            current_permissions, ensure_ascii=False
        ):
            conn.execute(
                "UPDATE auth_roles SET permissions=%s, updated_at=NOW() WHERE id='hr_specialist'",
                (json.dumps(merged_permissions, ensure_ascii=False),),
            )

    # 当前产品只保留管理员和 HR 专员。历史“面试官”及其他自定义角色账号统一归入 HR 专员，
    # 再清理多余角色，避免 auth_users.role_id 指向已删除的角色。
    conn.execute(
        """
        UPDATE auth_users
        SET role_id='hr_specialist', updated_at=NOW()
        WHERE role_id NOT IN ('admin', 'hr_specialist')
        """
    )
    conn.execute("DELETE FROM auth_roles WHERE id NOT IN ('admin', 'hr_specialist')")

    # 开发阶段放宽 HR 专员的业务权限，确保调试 Agent 和系统配置时不会被权限拦截；
    # 用户与角色管理仍由管理员专属，避免普通账号修改账号体系。
    role_row = conn.execute("SELECT permissions FROM auth_roles WHERE id='hr_specialist'").fetchone()
    if role_row:
        try:
            hr_permissions = json.loads(role_row["permissions"] or "[]")
        except (TypeError, json.JSONDecodeError):
            hr_permissions = []
        if "system:manage" not in hr_permissions:
            hr_permissions.append("system:manage")
            conn.execute(
                "UPDATE auth_roles SET permissions=%s, updated_at=NOW() WHERE id='hr_specialist'",
                (json.dumps(hr_permissions, ensure_ascii=False),),
            )

    existing = conn.execute("SELECT 1 FROM auth_users LIMIT 1").fetchone()
    if existing:
        return

    # 种子用 ON DUPLICATE KEY 幂等写入：测试库重建流程偶发"建表成功但
    # conftest 判定失败重试"，残留的种子行会让二次 INSERT 撞主键。
    from app.security import hash_password

    conn.execute(
        """
        INSERT INTO auth_users (id, username, display_name, password_hash, role_id, is_active)
        VALUES (%s, %s, %s, %s, %s, 1)
        ON DUPLICATE KEY UPDATE updated_at=NOW()
        """,
        ("user_shanghai", "shanghai", "系统管理员", hash_password("shanghai123"), "admin"),
    )


def _table_columns(conn, table_name: str) -> list[str]:
    """Return column names for a MySQL table."""
    rows = conn.execute(f"SHOW COLUMNS FROM `{table_name}`").fetchall()
    return [row["Field"] if isinstance(row, dict) else row[0] for row in rows]


def _ensure_index(conn, sql: str, index_name: str) -> None:
    """Create an index idempotently on MySQL."""
    try:
        conn.execute(sql.replace(" IF NOT EXISTS", ""))
    except Exception as exc:
        # MySQL 不支持 CREATE INDEX IF NOT EXISTS。索引已存在时视为成功，
        # 但仍需抛出真正的 DDL 错误。
        if "duplicate key name" not in str(exc).lower() and "already exists" not in str(exc).lower():
            raise


def _ensure_mysql_long_text_columns(conn) -> None:
    """Widen long-text columns on schemas created by older migrations."""
    tables = conn.execute("SHOW TABLES").fetchall()
    for table_row in tables:
        table = next(iter(table_row.values())) if isinstance(table_row, dict) else table_row[0]
        wanted = set(_MYSQL_LONG_TEXT_COLUMNS)
        wanted.update(_MYSQL_LONG_TEXT_COLUMNS_BY_TABLE.get(str(table).lower(), set()))
        try:
            rows = conn.execute(f"SHOW COLUMNS FROM `{table}`").fetchall()
        except Exception:
            continue
        for row in rows:
            name = row["Field"] if isinstance(row, dict) else row[0]
            if name not in wanted:
                continue
            col_type = (row["Type"] if isinstance(row, dict) else row[1]).lower()
            if col_type.startswith("longtext"):
                continue
            nullable = row["Null"] if isinstance(row, dict) else row[2]
            null_sql = "NOT NULL" if str(nullable).upper() == "NO" else "NULL"
            conn.execute(f"ALTER TABLE `{table}` MODIFY COLUMN `{name}` LONGTEXT {null_sql}")


def _migrate_poster_job_progress(conn):
    """Extend existing jobs without rewriting poster versions or replaying calls."""
    columns = {
        "source": "VARCHAR(32) NOT NULL DEFAULT 'conversation'",
        "client_request_id": "VARCHAR(160) DEFAULT NULL",
        "phase": "VARCHAR(32) NOT NULL DEFAULT 'queued'",
        "progress_details": "LONGTEXT NULL",
        "heartbeat_at": "VARCHAR(40) DEFAULT NULL",
        "deadline_at": "VARCHAR(40) DEFAULT NULL",
    }
    for name, definition in columns.items():
        if not conn.execute(f"SHOW COLUMNS FROM poster_generation_jobs LIKE '{name}'").fetchone():
            try:
                conn.execute(f"ALTER TABLE poster_generation_jobs ADD COLUMN {name} {definition}")
            except Exception:
                if not conn.execute(f"SHOW COLUMNS FROM poster_generation_jobs LIKE '{name}'").fetchone():
                    raise
    for name in ("session_id", "command_id", "base_version_id"):
        column = conn.execute(f"SHOW COLUMNS FROM poster_generation_jobs LIKE '{name}'").fetchone()
        if column and column["Null"] == "NO":
            conn.execute(f"ALTER TABLE poster_generation_jobs MODIFY COLUMN {name} {column['Type']} NULL")
    conn.execute("CREATE UNIQUE INDEX idx_poster_job_request ON poster_generation_jobs(pipeline_id, client_request_id)")
    conn.commit()


def _migrate_poster_version_numbers(conn):
    """Backfill immutable, pipeline-wide poster numbers for existing installations."""
    if not conn.execute("SHOW COLUMNS FROM poster_versions LIKE 'version_number'").fetchone():
        try:
            conn.execute("ALTER TABLE poster_versions ADD COLUMN version_number INTEGER DEFAULT NULL")
        except Exception:
            # Another worker may have added the column during startup.
            if not conn.execute("SHOW COLUMNS FROM poster_versions LIKE 'version_number'").fetchone():
                raise
    pipelines = conn.execute("SELECT DISTINCT pipeline_id FROM poster_versions WHERE version_number IS NULL").fetchall()
    for pipeline in pipelines:
        pipeline_id = pipeline["pipeline_id"]
        with transaction() as locked:
            locked.execute("SELECT id FROM pipelines WHERE id=%s FOR UPDATE", (pipeline_id,)).fetchone()
            last_number = locked.execute(
                "SELECT COALESCE(MAX(version_number), 0) AS n FROM poster_versions WHERE pipeline_id=%s",
                (pipeline_id,),
            ).fetchone()["n"]
            legacy_versions = locked.execute(
                """SELECT id FROM poster_versions WHERE pipeline_id=%s AND version_number IS NULL
                   ORDER BY created_at ASC, id ASC""",
                (pipeline_id,),
            ).fetchall()
            for number, version in enumerate(legacy_versions, start=last_number + 1):
                locked.execute(
                    "UPDATE poster_versions SET version_number=%s WHERE id=%s AND version_number IS NULL",
                    (number, version["id"]),
                )
    conn.execute("CREATE UNIQUE INDEX idx_poster_versions_number ON poster_versions(pipeline_id, version_number)")


def init_db():
    """Initialize database tables"""
    conn = get_db()
    conn.executescript("""CREATE TABLE IF NOT EXISTS pipelines (
            id VARCHAR(191) PRIMARY KEY,
            role VARCHAR(191) NOT NULL,
            tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default',
            owner_user_id VARCHAR(191) NOT NULL DEFAULT 'user_shanghai',
            status VARCHAR(191) DEFAULT 'running',
            context LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS pipeline_stages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            stage_id VARCHAR(191) NOT NULL,
            stage_name VARCHAR(191) NOT NULL,
            status VARCHAR(191) DEFAULT 'pending',
            output LONGTEXT,
            started_at VARCHAR(191),
            completed_at VARCHAR(191),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE TABLE IF NOT EXISTS candidates (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default',
            name VARCHAR(191) NOT NULL,
            source VARCHAR(191),
            years_experience INTEGER,
            current_company VARCHAR(191),
            current_salary VARCHAR(191),
            skills LONGTEXT,
            resume_text LONGTEXT,
            tech_score INTEGER DEFAULT 0,
            experience_score INTEGER DEFAULT 0,
            education_score INTEGER DEFAULT 0,
            major_match_score INTEGER DEFAULT 0,
            culture_score INTEGER DEFAULT 0,
            salary_risk INTEGER DEFAULT 0,
            overall_score INTEGER DEFAULT 0,
            reason LONGTEXT,
            video_assessment LONGTEXT,
            resume_id VARCHAR(191) DEFAULT NULL,
            status VARCHAR(191) DEFAULT 'new',
            offered_at VARCHAR(191) DEFAULT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE TABLE IF NOT EXISTS messages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191),
            role VARCHAR(191) NOT NULL,
            content LONGTEXT NOT NULL,
            card_type VARCHAR(191),
            card_data LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS learnings (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            category VARCHAR(191) NOT NULL,
            `key` VARCHAR(191) NOT NULL,
            value LONGTEXT NOT NULL,
            confidence REAL DEFAULT 0.5,
            usage_count INTEGER DEFAULT 0,
            pipeline_id VARCHAR(191) DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS hr_preferences (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            preference_key VARCHAR(191) UNIQUE NOT NULL,
            preference_value LONGTEXT NOT NULL,
            learned_from VARCHAR(191),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS ontology_rules (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            node_id VARCHAR(191) NOT NULL,
            rule_id VARCHAR(191) NOT NULL,
            rule_data LONGTEXT NOT NULL,
            pipeline_id VARCHAR(191) DEFAULT '',
            source VARCHAR(191) DEFAULT 'hr_custom',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            UNIQUE(rule_id, pipeline_id)
        );
CREATE TABLE IF NOT EXISTS memory_rules (
            id VARCHAR(191) PRIMARY KEY,
            ontology_node_id VARCHAR(191),
            rule_type VARCHAR(191) NOT NULL DEFAULT 'preference',
            content LONGTEXT NOT NULL,
            source VARCHAR(191) NOT NULL DEFAULT 'unknown',
            source_detail VARCHAR(191) DEFAULT '',
            confidence REAL DEFAULT 0.5,
            usage_count INTEGER DEFAULT 0,
            growth_stage VARCHAR(191) DEFAULT 'short',
            pipeline_id VARCHAR(191) DEFAULT '',
            actor_user_id VARCHAR(191) DEFAULT '',
            is_active INTEGER DEFAULT 1,
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS talent_pool (
            id VARCHAR(191) PRIMARY KEY,
            name VARCHAR(191) NOT NULL,
            skills LONGTEXT,
            years_experience INTEGER DEFAULT 0,
            current_company VARCHAR(191) DEFAULT '',
            current_salary VARCHAR(191) DEFAULT '',
            education VARCHAR(191) DEFAULT '',
            major VARCHAR(191) DEFAULT '',
            best_score INTEGER DEFAULT 0,
            best_role VARCHAR(191) DEFAULT '',
            source_pipeline VARCHAR(191) DEFAULT '',
            outcome VARCHAR(191) DEFAULT 'pooled',
            tags LONGTEXT,
            notes LONGTEXT,
            resume_text LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS outreach_events (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191) DEFAULT '',
            candidate_id VARCHAR(191) DEFAULT '',
            candidate_name VARCHAR(191) DEFAULT '',
            channel VARCHAR(191) DEFAULT 'feishu',
            event_type VARCHAR(191) NOT NULL,
            content LONGTEXT,
            status VARCHAR(191) DEFAULT 'sent',
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS resumes (
            id VARCHAR(191) PRIMARY KEY,
            fingerprint VARCHAR(191),
            fingerprint_confidence VARCHAR(191) DEFAULT 'high',
            name VARCHAR(191) NOT NULL,
            source VARCHAR(191),
            source_channel VARCHAR(191),
            years_experience INTEGER,
            current_company VARCHAR(191),
            current_salary VARCHAR(191),
            skills LONGTEXT,
            resume_text LONGTEXT,
            education VARCHAR(191),
            location VARCHAR(191),
            title VARCHAR(191),
            tags LONGTEXT,
            email VARCHAR(191) DEFAULT '',
            storage_backend VARCHAR(191) DEFAULT '',
            storage_key VARCHAR(191) DEFAULT '',
            original_filename VARCHAR(191) DEFAULT '',
            linked_resume_id VARCHAR(191),
            tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE INDEX idx_resumes_name ON resumes(name);
CREATE INDEX idx_pipeline_status ON pipelines(status);
CREATE TABLE IF NOT EXISTS pending_data (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            data_type VARCHAR(191) NOT NULL,
            data_json LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS agent_call_logs (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL DEFAULT '',
            stage_id VARCHAR(191) NOT NULL DEFAULT '',
            agent_id VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'running',
            duration_ms INTEGER NOT NULL DEFAULT 0,
            tokens_used INTEGER NOT NULL DEFAULT 0,
            error LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS agent_configs (
            agent_id VARCHAR(191) PRIMARY KEY,
            agent_name VARCHAR(191) NOT NULL DEFAULT '',
            display_name VARCHAR(191) NOT NULL DEFAULT '',
            model VARCHAR(191) NOT NULL DEFAULT 'qwen3.6-flash',
            complexity VARCHAR(191) NOT NULL DEFAULT 'plus',
            temperature REAL NOT NULL DEFAULT 0.7,
            timeout INTEGER NOT NULL DEFAULT 120,
            retry_count INTEGER NOT NULL DEFAULT 2,
            enabled INTEGER NOT NULL DEFAULT 1,
            human_approval INTEGER NOT NULL DEFAULT 0,
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS rpa_tasks (
            id VARCHAR(191) PRIMARY KEY,
            platform VARCHAR(191) NOT NULL DEFAULT 'liepin',
            keywords VARCHAR(191) NOT NULL DEFAULT '',
            target_count INTEGER NOT NULL DEFAULT 10,
            status VARCHAR(191) NOT NULL DEFAULT 'pending',
            fetched_count INTEGER DEFAULT 0,
            pipeline_id VARCHAR(191) DEFAULT '',
            error_message LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            completed_at VARCHAR(191) DEFAULT ''
        );
CREATE TABLE IF NOT EXISTS interview_schedules (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) DEFAULT '',
            date VARCHAR(191) DEFAULT '',
            time VARCHAR(191) DEFAULT '',
            interviewer VARCHAR(191) DEFAULT '',
            method VARCHAR(191) DEFAULT '',
            round VARCHAR(191) DEFAULT '',
            status VARCHAR(191) DEFAULT 'scheduled',
            notes LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS interview_commands (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            source VARCHAR(191) NOT NULL DEFAULT 'text',
            source_text LONGTEXT NOT NULL,
            intent VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'draft',
            payload LONGTEXT NOT NULL,
            preview LONGTEXT NOT NULL,
            result LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            executed_at VARCHAR(191)
        );
CREATE INDEX idx_interview_commands_pipeline
            ON interview_commands(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS conversation_sessions (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            agent_id VARCHAR(191) NOT NULL,
            actor_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'active',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            archived_at VARCHAR(191),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE TABLE IF NOT EXISTS active_conversation_sessions (
            pipeline_id VARCHAR(191) NOT NULL,
            agent_id VARCHAR(191) NOT NULL,
            actor_id VARCHAR(191) NOT NULL,
            session_id VARCHAR(191) NOT NULL UNIQUE,
            PRIMARY KEY (pipeline_id, agent_id, actor_id),
            FOREIGN KEY (session_id) REFERENCES conversation_sessions(id)
        );
CREATE TABLE IF NOT EXISTS conversation_commands (
            id VARCHAR(191) PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            pipeline_id VARCHAR(191) NOT NULL,
            agent_id VARCHAR(191) NOT NULL,
            client_request_id VARCHAR(191) NOT NULL,
            source VARCHAR(191) NOT NULL DEFAULT 'text',
            source_text LONGTEXT NOT NULL,
            intent VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'parsing',
            payload LONGTEXT NOT NULL,
            preview LONGTEXT NOT NULL,
            preview_hash VARCHAR(191) NOT NULL DEFAULT '',
            result LONGTEXT NOT NULL,
            latest_data LONGTEXT NOT NULL,
            outcome_code VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            executed_at VARCHAR(191),
            UNIQUE (session_id, client_request_id),
            FOREIGN KEY (session_id) REFERENCES conversation_sessions(id)
        );
CREATE INDEX idx_conversation_commands_session
            ON conversation_commands(session_id, created_at);
CREATE TABLE IF NOT EXISTS conversation_messages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            command_id VARCHAR(191),
            role VARCHAR(191) NOT NULL,
            content LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (session_id) REFERENCES conversation_sessions(id),
            FOREIGN KEY (command_id) REFERENCES conversation_commands(id)
        );
CREATE INDEX idx_conversation_messages_session
            ON conversation_messages(session_id, id);
CREATE TABLE IF NOT EXISTS leader_chat_sessions (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            actor_user_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'active',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            archived_at VARCHAR(191)
        );
CREATE INDEX idx_leader_chat_sessions_actor
            ON leader_chat_sessions(tenant_id, actor_user_id, status, updated_at);
CREATE TABLE IF NOT EXISTS leader_chat_requests (
            id VARCHAR(191) PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            client_request_id VARCHAR(191) NOT NULL,
            message LONGTEXT NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'pending',
            response_text LONGTEXT NOT NULL,
            response_chart LONGTEXT NOT NULL,
            error_code_internal VARCHAR(191) NOT NULL DEFAULT '',
            error_message_internal LONGTEXT NOT NULL,
            public_error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            lease_token VARCHAR(191) NOT NULL DEFAULT '',
            lease_expires_at VARCHAR(191),
            completed_at VARCHAR(191),
            UNIQUE (session_id, client_request_id),
            FOREIGN KEY (session_id) REFERENCES leader_chat_sessions(id)
        );
CREATE INDEX idx_leader_chat_requests_session
            ON leader_chat_requests(session_id, created_at);
CREATE TABLE IF NOT EXISTS leader_chat_messages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            request_id VARCHAR(191) NOT NULL,
            role VARCHAR(191) NOT NULL,
            content LONGTEXT NOT NULL,
            tool_calls LONGTEXT NOT NULL,
            tool_results LONGTEXT NOT NULL,
            chart_spec LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (session_id) REFERENCES leader_chat_sessions(id),
            FOREIGN KEY (request_id) REFERENCES leader_chat_requests(id)
        );
CREATE INDEX idx_leader_chat_messages_session
            ON leader_chat_messages(session_id, id);
CREATE TABLE IF NOT EXISTS media_assets (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            kind VARCHAR(191) NOT NULL DEFAULT 'reference',
            storage_backend VARCHAR(191) NOT NULL DEFAULT 'local',
            storage_key VARCHAR(191) NOT NULL,
            filename VARCHAR(191) NOT NULL DEFAULT '',
            mime_type VARCHAR(191) NOT NULL,
            byte_size INTEGER NOT NULL DEFAULT 0,
            width INTEGER NOT NULL DEFAULT 0,
            height INTEGER NOT NULL DEFAULT 0,
            sha256 VARCHAR(191) NOT NULL DEFAULT '',
            metadata VARCHAR(191) NOT NULL DEFAULT '{}',
            created_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE INDEX idx_media_assets_pipeline
            ON media_assets(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS conversation_message_attachments (
            message_id BIGINT NOT NULL,
            asset_id VARCHAR(191) NOT NULL,
            `usage` VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW()),
            PRIMARY KEY (message_id, asset_id),
            FOREIGN KEY (message_id) REFERENCES conversation_messages(id),
            FOREIGN KEY (asset_id) REFERENCES media_assets(id)
        );
CREATE TABLE IF NOT EXISTS poster_versions (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            version_number INTEGER DEFAULT NULL,
            parent_version_id VARCHAR(191),
            image_asset_id VARCHAR(191),
            source VARCHAR(191) NOT NULL DEFAULT 'generated',
            canvas_id VARCHAR(191) NOT NULL DEFAULT 'long',
            width INTEGER NOT NULL DEFAULT 0,
            height INTEGER NOT NULL DEFAULT 0,
            status VARCHAR(191) NOT NULL DEFAULT 'draft',
            fields LONGTEXT NOT NULL,
            instruction VARCHAR(191) NOT NULL DEFAULT '',
            reference_asset_ids VARCHAR(191) NOT NULL DEFAULT '[]',
            reference_usage VARCHAR(191) NOT NULL DEFAULT '',
            provider VARCHAR(191) NOT NULL DEFAULT '',
            model VARCHAR(191) NOT NULL DEFAULT '',
            render_data LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            selected_at VARCHAR(191),
            approved_at VARCHAR(191),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id),
            FOREIGN KEY (parent_version_id) REFERENCES poster_versions(id),
            FOREIGN KEY (image_asset_id) REFERENCES media_assets(id)
        );
CREATE INDEX idx_poster_versions_pipeline
            ON poster_versions(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS poster_generation_jobs (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            session_id VARCHAR(191) NOT NULL,
            command_id VARCHAR(191) NOT NULL UNIQUE,
            base_version_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'queued',
            request_payload LONGTEXT NOT NULL,
            provider VARCHAR(191) NOT NULL DEFAULT '',
            model VARCHAR(191) NOT NULL DEFAULT '',
            progress INTEGER NOT NULL DEFAULT 0,
            result_version_id VARCHAR(191) NOT NULL DEFAULT '',
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            completed_at VARCHAR(191),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id),
            FOREIGN KEY (session_id) REFERENCES conversation_sessions(id),
            FOREIGN KEY (command_id) REFERENCES conversation_commands(id),
            FOREIGN KEY (base_version_id) REFERENCES poster_versions(id)
        );
CREATE INDEX idx_poster_generation_jobs_pipeline
            ON poster_generation_jobs(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS xiao_hai_generation_jobs (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            client_request_id VARCHAR(191) NOT NULL,
            request_payload LONGTEXT NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'queued',
            stage VARCHAR(191) NOT NULL DEFAULT 'queued',
            progress INTEGER NOT NULL DEFAULT 0,
            result_version_id VARCHAR(191) NOT NULL DEFAULT '',
            result_payload LONGTEXT NOT NULL,
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            completed_at VARCHAR(191),
            UNIQUE (pipeline_id, client_request_id),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE INDEX idx_xiao_hai_generation_jobs_pipeline
            ON xiao_hai_generation_jobs(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS aggregate_report_jobs (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'queued',
            passed_only INTEGER NOT NULL DEFAULT 1,
            progress INTEGER NOT NULL DEFAULT 0,
            result_json LONGTEXT NOT NULL,
            message LONGTEXT NOT NULL,
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            completed_at VARCHAR(191),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE INDEX idx_aggregate_report_jobs_pipeline
            ON aggregate_report_jobs(pipeline_id, created_at);
CREATE TABLE IF NOT EXISTS elimination_records (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) DEFAULT '',
            candidate_name VARCHAR(191) DEFAULT '',
            score REAL DEFAULT 0,
            reason LONGTEXT,
            details VARCHAR(191) DEFAULT '{}',
            eliminated_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS interview_sessions (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            token VARCHAR(191) UNIQUE NOT NULL,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL,
            candidate_name VARCHAR(191) DEFAULT '',
            status VARCHAR(191) DEFAULT 'invited',
            questions LONGTEXT,
            answers LONGTEXT,
            current_question INTEGER DEFAULT 0,
            total_questions INTEGER DEFAULT 5,
            interview_score INTEGER DEFAULT 0,
            dimension_scores LONGTEXT,
            video_paths LONGTEXT,
            oss_object_key VARCHAR(191) DEFAULT '',
            recommendation VARCHAR(191) DEFAULT '',
            started_at VARCHAR(191),
            completed_at VARCHAR(191),
            evaluated_at VARCHAR(191),
            expires_at VARCHAR(191),
            device_info VARCHAR(191) DEFAULT '{}',
            active_client_id VARCHAR(191) DEFAULT '',
            lease_expires_at VARCHAR(191) DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        );
CREATE INDEX idx_sessions_token ON interview_sessions(token);
CREATE INDEX idx_sessions_pipeline ON interview_sessions(pipeline_id);
CREATE INDEX idx_sessions_status ON interview_sessions(pipeline_id, status);
CREATE TABLE IF NOT EXISTS written_test_sessions (
            token VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL,
            candidate_name VARCHAR(191) DEFAULT '',
            questions LONGTEXT,
            answers LONGTEXT,
            status VARCHAR(191) DEFAULT 'pending',
            camera_enabled INTEGER DEFAULT 0,
            video_filename VARCHAR(191) DEFAULT '',
            oss_object_key VARCHAR(191) DEFAULT '',
            video_storage_key VARCHAR(191) DEFAULT '',
            started_at VARCHAR(191) DEFAULT '',
            submitted_at VARCHAR(191) DEFAULT '',
            expires_at VARCHAR(191) DEFAULT '',
            invite_sent_at VARCHAR(191) DEFAULT '',
            score INTEGER DEFAULT 0,
            evaluation LONGTEXT,
            scoring_status VARCHAR(191) DEFAULT '',
            scoring_error VARCHAR(191) DEFAULT '',
            scoring_owner VARCHAR(191) DEFAULT '',
            scoring_started_at VARCHAR(191) DEFAULT '',
            scoring_completed_at VARCHAR(191) DEFAULT '',
            scoring_attempts INTEGER DEFAULT 0,
            voice_answers LONGTEXT,
            active_client_id VARCHAR(191) DEFAULT '',
            lease_expires_at VARCHAR(191) DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE INDEX idx_written_sessions_pipeline_candidate_status
            ON written_test_sessions(pipeline_id, candidate_id, status);
CREATE INDEX idx_written_sessions_invite_expiry
            ON written_test_sessions(pipeline_id, invite_sent_at, expires_at);
CREATE TABLE IF NOT EXISTS communication_templates (
            id VARCHAR(191) PRIMARY KEY,
            name VARCHAR(191) NOT NULL,
            type VARCHAR(191) NOT NULL DEFAULT 'interview_invite',
            template VARCHAR(191) DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW())
        );
CREATE TABLE IF NOT EXISTS company_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            company_name VARCHAR(191) DEFAULT '锅圈食汇',
            company_short VARCHAR(191) DEFAULT '锅圈食汇',
            company_en VARCHAR(191) DEFAULT 'GUOQUAN',
            company_logo VARCHAR(191) DEFAULT '/brand/guoquan-logo.svg',
            company_logo_storage_key VARCHAR(191) DEFAULT '',
            industry VARCHAR(191) DEFAULT '餐饮/食材零售',
            company_size VARCHAR(191) DEFAULT '10000+门店',
            company_website VARCHAR(191) DEFAULT 'https://www.guoquanshihui.com',
            company_address VARCHAR(191) DEFAULT '郑州市金水区',
            default_benefits VARCHAR(191) DEFAULT '[]',
            company_intro VARCHAR(191) DEFAULT '',
            brand_color VARCHAR(191) DEFAULT '#16A34A',
            brand_color_secondary VARCHAR(191) DEFAULT '#FF6B00',
            poster_template VARCHAR(191) DEFAULT 'guoquan_red',
            poster_bg_image VARCHAR(191) DEFAULT '/brand/guoquan-poster-bg.svg',
            poster_bg_image_storage_key VARCHAR(191) DEFAULT '',
            updated_at VARCHAR(191) DEFAULT (NOW())
        )""")
    _migrate_poster_version_numbers(conn)
    _migrate_poster_job_progress(conn)
    _ensure_access_control_schema(conn)
    # 为 pipelines 添加 engine_version（列已存在时跳过）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN engine_version INTEGER NOT NULL DEFAULT 1")
    except Exception:
        pass

    # 流水线所有者是用户级数据隔离的基础。历史数据默认归系统管理员，
    # 新创建的业务流水线由 API 层写入真实登录用户 ID。
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN owner_user_id VARCHAR(191) NOT NULL DEFAULT 'user_shanghai'")
    except Exception:
        pass
    legacy_owner_row = conn.execute(
        "SELECT id FROM auth_users WHERE role_id='admin' ORDER BY created_at LIMIT 1"
    ).fetchone()
    legacy_owner_id = legacy_owner_row["id"] if legacy_owner_row else "user_shanghai"
    conn.execute(
        "UPDATE pipelines SET owner_user_id=%s WHERE owner_user_id IS NULL OR owner_user_id='' OR NOT EXISTS (SELECT 1 FROM auth_users users WHERE users.id=pipelines.owner_user_id)",
        (legacy_owner_id,),
    )

    # 岗位类型使用稳定代码存储，显示名称由应用层映射。
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN type VARCHAR(191) NOT NULL DEFAULT 'tech'")
    except Exception:
        pass
    from app.pipeline.job_types import JOB_TYPE_OPTIONS

    for normalized_type, label in JOB_TYPE_OPTIONS:
        conn.execute("UPDATE pipelines SET type=%s WHERE type=%s", (normalized_type, label))
    conn.execute("UPDATE pipelines SET type='operations' WHERE type='ops'")

    # 为 pipelines 添加 enabled_agents（已启用 Agent role_id 的 JSON 数组）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN enabled_agents VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass

    # 为 messages 添加 stage_id（关联到具体 Agent/阶段）
    try:
        conn.execute("ALTER TABLE messages ADD COLUMN stage_id VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass

    # 为 pipelines 添加 agents（Agent ID 的 JSON 数组，例如 ['xiao_wen','xiao_xun','xiao_shai']）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN agents VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass

    # 为 pipelines 添加 screen_template_id
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN screen_template_id VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass

    # 为 pipelines 添加 auto_pass（例如 {"xiao_wen":true} 的 JSON 对象）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN auto_pass VARCHAR(191) NOT NULL DEFAULT ''")
    except Exception:
        pass

    # 为 pipelines 添加 import_mode（full/simple）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN import_mode VARCHAR(191) NOT NULL DEFAULT 'full'")
    except Exception:
        pass

    # 为 pipelines 添加 tts_urls（预生成的 TTS 音频 URL）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN tts_urls VARCHAR(191) DEFAULT ''")
    except Exception:
        pass

    # JD 交接后锁定，复制岗位时记录来源流水线（历史库默认未锁定）
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN jd_locked_at VARCHAR(191) DEFAULT NULL")
    except Exception:
        pass
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN jd_locked_by_stage VARCHAR(191) DEFAULT ''")
    except Exception:
        pass
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN cloned_from_pipeline_id VARCHAR(191) DEFAULT ''")
    except Exception:
        pass

    # 为 interview_sessions 添加 timestamps
    try:
        conn.execute("ALTER TABLE interview_sessions ADD COLUMN timestamps LONGTEXT")
    except Exception:
        pass

    # 为 candidates 添加 resume_id（人才库链接功能：标记候选人来自哪份简历）
    try:
        conn.execute("ALTER TABLE candidates ADD COLUMN resume_id VARCHAR(191) DEFAULT ''")
    except Exception:
        pass

    # 写入默认 Agent 配置（INSERT IGNORE，支持幂等执行）
    _seed_agent_configs(conn)

    # 写入默认沟通模板
    _seed_communication_templates(conn)

    # 写入默认公司配置
    _seed_company_config(conn)
    # 迁移历史旧品牌配置到锅圈食汇（幂等）
    _migrate_company_config(conn)
    _migrate_guoquan_brand_color(conn)
    # 公司级 HR 邮箱/二维码已下沉为「用户与权限」的用户级配置：
    # 旧库残留的公司级三列在此彻底移除（新库建表已不含这些列）。
    try:
        present_columns = _table_columns(conn, "company_config")
        for column in ("hr_contact", "hr_qr_code", "hr_qr_code_storage_key"):
            if column in present_columns:
                conn.execute(f"ALTER TABLE company_config DROP COLUMN {column}")
    except Exception:
        pass
    for column in (
        "company_logo_storage_key",
        "poster_bg_image_storage_key",
    ):
        try:
            conn.execute(f"ALTER TABLE company_config ADD COLUMN {column} VARCHAR(191) DEFAULT ''")
        except Exception:
            pass

    # 确保 llm_usage.call_type 列存在（旧库补列，幂等；历史记录默认归为 text）
    try:
        conn.execute("ALTER TABLE llm_usage ADD COLUMN call_type VARCHAR(191) NOT NULL DEFAULT 'text'")
    except Exception:
        pass

    conn.execute(
        """CREATE TABLE IF NOT EXISTS email_sync_log (
            uid VARCHAR(191) PRIMARY KEY,
            subject VARCHAR(191) DEFAULT '',
            sender VARCHAR(191) DEFAULT '',
            received_at VARCHAR(191) DEFAULT '',
            status VARCHAR(191) DEFAULT 'processed',
            resume_id VARCHAR(191) DEFAULT '',
            filename VARCHAR(191) DEFAULT '',
            error LONGTEXT,
            created_at VARCHAR(191) DEFAULT (NOW())
        )"""
    )

    _ensure_email_domain_schema(conn)

    conn.commit()


def _ensure_email_domain_schema(conn):
    """Create the multi-account email sync domain tables."""
    conn.executescript(
        """CREATE TABLE IF NOT EXISTS email_accounts (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            owner_user_id VARCHAR(191) NOT NULL,
            name VARCHAR(191) NOT NULL,
            email_address VARCHAR(191) NOT NULL,
            provider VARCHAR(191) NOT NULL DEFAULT 'custom',
            imap_host VARCHAR(191) NOT NULL,
            smtp_host VARCHAR(191) NOT NULL DEFAULT '',
            smtp_port INTEGER NOT NULL DEFAULT 465,
            smtp_security VARCHAR(191) NOT NULL DEFAULT 'ssl',
            imap_port INTEGER NOT NULL DEFAULT 993,
            security_mode VARCHAR(191) NOT NULL DEFAULT 'ssl',
            username VARCHAR(191) NOT NULL,
            credential_ciphertext VARCHAR(191) NOT NULL DEFAULT '',
            credential_key_version INTEGER NOT NULL DEFAULT 1,
            enabled INTEGER NOT NULL DEFAULT 1,
            schedule_type VARCHAR(191) NOT NULL DEFAULT 'interval',
            interval_minutes INTEGER NOT NULL DEFAULT 30,
            cron_expression VARCHAR(191) NOT NULL DEFAULT '',
            timezone VARCHAR(191) NOT NULL DEFAULT 'Asia/Shanghai',
            last_sync_at VARCHAR(191),
            created_by VARCHAR(191) NOT NULL,
            updated_by VARCHAR(191) NOT NULL,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            UNIQUE (tenant_id, email_address),
            FOREIGN KEY (owner_user_id) REFERENCES auth_users(id)
        );
CREATE TABLE IF NOT EXISTS email_account_grants (
            email_account_id VARCHAR(191) NOT NULL,
            user_id VARCHAR(191) NOT NULL,
            permission VARCHAR(191) NOT NULL DEFAULT 'read',
            granted_by VARCHAR(191) NOT NULL,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            PRIMARY KEY (email_account_id, user_id),
            FOREIGN KEY (email_account_id) REFERENCES email_accounts(id),
            FOREIGN KEY (user_id) REFERENCES auth_users(id)
        );
CREATE TABLE IF NOT EXISTS email_sync_runs (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            email_account_id VARCHAR(191) NOT NULL,
            trigger_type VARCHAR(191) NOT NULL,
            triggered_by VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'queued',
            started_at VARCHAR(191),
            finished_at VARCHAR(191),
            message_total INTEGER NOT NULL DEFAULT 0,
            message_new INTEGER NOT NULL DEFAULT 0,
            attachment_total INTEGER NOT NULL DEFAULT 0,
            imported_count INTEGER NOT NULL DEFAULT 0,
            deduped_count INTEGER NOT NULL DEFAULT 0,
            suspect_count INTEGER NOT NULL DEFAULT 0,
            skipped_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            retry_of_run_id VARCHAR(191),
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (email_account_id) REFERENCES email_accounts(id)
        );
CREATE TABLE IF NOT EXISTS email_sync_leases (
            email_account_id VARCHAR(191) PRIMARY KEY,
            run_id VARCHAR(191) NOT NULL,
            expires_at VARCHAR(191) NOT NULL,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (email_account_id) REFERENCES email_accounts(id)
        );
CREATE TABLE IF NOT EXISTS email_sync_messages (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            run_id VARCHAR(191) NOT NULL,
            email_account_id VARCHAR(191) NOT NULL,
            folder VARCHAR(191) NOT NULL,
            uid_validity VARCHAR(191) NOT NULL DEFAULT 'unknown',
            uid VARCHAR(191) NOT NULL,
            message_id VARCHAR(191) NOT NULL DEFAULT '',
            subject VARCHAR(191) NOT NULL DEFAULT '',
            sender_name VARCHAR(191) NOT NULL DEFAULT '',
            sender_email VARCHAR(191) NOT NULL DEFAULT '',
            received_at VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'discovered',
            skip_reason VARCHAR(191) NOT NULL DEFAULT '',
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            UNIQUE (email_account_id, folder, uid_validity, uid),
            FOREIGN KEY (run_id) REFERENCES email_sync_runs(id)
        );
CREATE TABLE IF NOT EXISTS email_sync_attachments (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            message_record_id VARCHAR(191) NOT NULL,
            filename VARCHAR(191) NOT NULL DEFAULT '',
            extension VARCHAR(191) NOT NULL DEFAULT '',
            mime_type VARCHAR(191) NOT NULL DEFAULT '',
            size_bytes INTEGER NOT NULL DEFAULT 0,
            sha256 VARCHAR(191) NOT NULL DEFAULT '',
            storage_key VARCHAR(191) NOT NULL DEFAULT '',
            status VARCHAR(191) NOT NULL DEFAULT 'discovered',
            resume_id VARCHAR(191) NOT NULL DEFAULT '',
            duplicate_resume_id VARCHAR(191) NOT NULL DEFAULT '',
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            processed_at VARCHAR(191),
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (message_record_id) REFERENCES email_sync_messages(id)
        );
CREATE TABLE IF NOT EXISTS email_sync_recoveries (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            email_account_id VARCHAR(191) NOT NULL,
            run_id VARCHAR(191) NOT NULL,
            original_message_id VARCHAR(191) NOT NULL,
            recovery_message_id VARCHAR(191) NOT NULL,
            uid_validity VARCHAR(191) NOT NULL DEFAULT 'unknown',
            uid VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'processing',
            recovered_resume_id VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            updated_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            FOREIGN KEY (run_id) REFERENCES email_sync_runs(id),
            FOREIGN KEY (original_message_id) REFERENCES email_sync_messages(id),
            FOREIGN KEY (recovery_message_id) REFERENCES email_sync_messages(id)
        );
CREATE TABLE IF NOT EXISTS resume_sources (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            resume_id VARCHAR(191) NOT NULL,
            source_type VARCHAR(191) NOT NULL,
            email_account_id VARCHAR(191) NOT NULL DEFAULT '',
            message_record_id VARCHAR(191) NOT NULL DEFAULT '',
            attachment_id VARCHAR(191) NOT NULL DEFAULT '',
            sender_email VARCHAR(191) NOT NULL DEFAULT '',
            received_at VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) NOT NULL DEFAULT (NOW()),
            UNIQUE (attachment_id)
        );
CREATE INDEX idx_email_accounts_owner
            ON email_accounts(tenant_id, owner_user_id, enabled);
CREATE INDEX idx_email_runs_account
            ON email_sync_runs(email_account_id, created_at);
CREATE INDEX idx_email_runs_tenant
            ON email_sync_runs(tenant_id, created_at);
CREATE INDEX idx_email_messages_run
            ON email_sync_messages(run_id, created_at);
CREATE INDEX idx_email_attachments_message
            ON email_sync_attachments(message_record_id, status);
CREATE INDEX idx_email_attachments_hash
            ON email_sync_attachments(tenant_id, sha256);
CREATE INDEX idx_email_recoveries_run
            ON email_sync_recoveries(run_id, created_at);
CREATE INDEX idx_email_recoveries_original
            ON email_sync_recoveries(original_message_id, created_at);
CREATE INDEX idx_resume_sources_resume
            ON resume_sources(tenant_id, resume_id)"""
    )
    try:
        conn.execute("DROP INDEX idx_email_accounts_due ON email_accounts")
    except Exception as exc:
        message = str(exc).lower()
        if "doesn't exist" not in message and "check that column/key exists" not in message:
            raise

    account_columns = set(_table_columns(conn, "email_accounts"))
    for deprecated_column in (
        "folder",
        "next_sync_at",
        "last_success_at",
        "last_error_code",
        "last_error_message",
    ):
        if deprecated_column in account_columns:
            conn.execute(f"ALTER TABLE email_accounts DROP COLUMN {deprecated_column}")

    # 发件（SMTP）参数：与收件（IMAP）共用同一邮箱，复用 credential_ciphertext 存授权码。
    for column, ddl in (
        ("smtp_host", "ALTER TABLE email_accounts ADD COLUMN smtp_host VARCHAR(191) NOT NULL DEFAULT ''"),
        ("smtp_port", "ALTER TABLE email_accounts ADD COLUMN smtp_port INTEGER NOT NULL DEFAULT 465"),
        ("smtp_security", "ALTER TABLE email_accounts ADD COLUMN smtp_security VARCHAR(191) NOT NULL DEFAULT 'ssl'"),
    ):
        if column not in account_columns:
            conn.execute(ddl)


def _seed_agent_configs(conn):
    """Seed default agent configs — idempotent (INSERT IGNORE)"""
    defaults = [
        ("jd_write", "小文", "JD撰写与画像生成", "qwen-plus", "plus", 0.7, 90, 2, 1, 0),
        ("profile_build", "小文", "22维候选人画像", "qwen-plus", "plus", 0.7, 90, 2, 1, 0),
        ("poster_gen", "小海", "招聘海报生成", "qwen-plus", "plus", 0.7, 120, 2, 1, 0),
        ("crawl", "小寻", "简历获取与导入", "qwen3.6-flash", "flash", 0.3, 120, 2, 1, 0),
        ("match", "小筛", "简历匹配过滤", "qwen-plus", "plus", 0.3, 120, 2, 1, 0),
        ("interview_gen", "小面", "面试出题", "qwen-plus", "plus", 0.7, 120, 2, 1, 0),
        ("video_assess", "小面", "视频面试评估", "qwen-vl-max", "max", 0.5, 180, 1, 0, 0),
        ("report", "小评", "AI评估报告", "qwen-plus", "plus", 0.3, 120, 2, 1, 0),
    ]
    for agent_id, name, display, model, complexity, temp, timeout, retries, enabled, human in defaults:
        conn.execute(
            "INSERT IGNORE INTO agent_configs (agent_id, agent_name, display_name, model, complexity, temperature, timeout, retry_count, enabled, human_approval) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (agent_id, name, display, model, complexity, temp, timeout, retries, enabled, human),
        )


def _seed_communication_templates(conn):
    """Seed default communication templates — idempotent (INSERT IGNORE)"""
    defaults = [
        (
            "interview_invite_default",
            "面试邀请",
            "interview_invite",
            "尊敬的{candidate_name}，\n\n您好！感谢您应聘{role}岗位。\n\n经过初步筛选，我们对您的背景非常感兴趣，诚邀您参加面试。\n\n面试方式：{method}\n面试链接：{interview_url}\n链接有效期：{expires_at}\n\n请点击上方链接参加面试，并提前准备好相关材料。如有任何问题，请随时联系我们。\n\n祝好！\n{company_name}招聘团队",
        ),
        (
            "pass_notification_default",
            "通过通知",
            "pass",
            "尊敬的{candidate_name}，\n\n恭喜您！您在{role}岗位的{round}面试中表现优异，已通过评估。\n\n下一步安排：{next_step}\n\n请保持手机畅通，我们会尽快与您联系确认后续安排。\n\n祝好！\n{company_name}招聘团队",
        ),
        (
            "reject_notification_default",
            "淘汰通知",
            "reject",
            "尊敬的{candidate_name}，\n\n感谢您参加{role}岗位的面试。\n\n经过慎重评估，很遗憾地通知您，本次我们未能与您达成合作意向。\n这并不代表对您能力的否定，我们会将您的信息保留在人才库中，未来有合适机会将第一时间联系您。\n\n祝您前程似锦！\n{company_name}招聘团队",
        ),
        (
            "offer_letter_default",
            "录用通知",
            "offer",
            "尊敬的{candidate_name}，\n\n恭喜您！经过全面评估，我们非常高兴地通知您，您已被正式录用为{company_name}的{role}。\n\n入职信息：\n- 入职日期：{start_date}\n- 薪资范围：{salary}\n- 工作地点：{location}\n\n请在{deadline}前确认是否接受此offer。\n\n期待您的加入！\n{company_name}招聘团队",
        ),
    ]
    for tid, name, ctype, template in defaults:
        conn.execute(
            "INSERT IGNORE INTO communication_templates (id, name, type, template) VALUES (%s, %s, %s, %s)",
            (tid, name, ctype, template),
        )


def _seed_company_config(conn):
    """Seed default company config — idempotent (INSERT IGNORE)"""
    default_benefits = json.dumps(
        ["五险一金", "带薪年假", "员工折扣", "节日福利", "年终奖", "门店就近分配"], ensure_ascii=False
    )
    company_intro = (
        "锅圈食汇创立于2017年，总部位于郑州，是中国领先的火锅烧烤食材连锁零售品牌。"
        "主营火锅底料、牛羊肉品、丸滑制品、蔬菜净菜等全品类食材，SKU超800个。"
        "全国门店超10000家，覆盖300+城市，年营收超百亿。"
        "业务模式：社区门店零售 + 加盟连锁 + 线上外卖。"
        "核心岗位类型：门店导购、店长、区域督导、仓储物流、总部运营。"
    )
    conn.execute(
        """INSERT IGNORE INTO company_config
        (id, company_name, company_short, company_en, company_logo,
         industry, company_size, company_website, company_address,
         default_benefits, company_intro,
         brand_color, brand_color_secondary, poster_template, poster_bg_image)
        VALUES (1, '锅圈食汇', '锅圈食汇', 'GUOQUAN', '/brand/guoquan-logo.svg',
                '餐饮/食材零售', '10000+门店', 'https://www.guoquanshihui.com', '郑州市金水区',
                %s, %s,
                '#16A34A', '#FF6B00', 'guoquan_red',
                '/brand/guoquan-poster-bg.svg')
    """,
        (default_benefits, company_intro),
    )


def _migrate_company_config(conn):
    """品牌迁移：霸王茶姬 → 锅圈食汇（幂等，只在检测到旧品牌时执行）"""
    row = conn.execute("SELECT company_name FROM company_config WHERE id = 1").fetchone()
    company_name = row.get("company_name") if isinstance(row, dict) else (row[0] if row else None)
    if not row or "霸王茶姬" not in (company_name or ""):
        return  # 已经是新品牌或用户自定义了，跳过

    new_intro = (
        "锅圈食汇创立于2017年，总部位于郑州，是中国领先的火锅烧烤食材连锁零售品牌。"
        "主营火锅底料、牛羊肉品、丸滑制品、蔬菜净菜等全品类食材，SKU超800个。"
        "全国门店超10000家，覆盖300+城市，年营收超百亿。"
        "业务模式：社区门店零售 + 加盟连锁 + 线上外卖。"
        "核心岗位类型：门店导购、店长、区域督导、仓储物流、总部运营。"
    )
    new_benefits = json.dumps(
        ["五险一金", "带薪年假", "员工折扣", "节日福利", "年终奖", "门店就近分配"],
        ensure_ascii=False,
    )
    conn.execute(
        """UPDATE company_config SET
            company_name = '锅圈食汇',
            company_short = '锅圈食汇',
            company_en = 'GUOQUAN',
            company_logo = '/brand/guoquan-logo.svg',
            industry = '餐饮/食材零售',
            company_size = '10000+门店',
            company_website = 'https://www.guoquanshihui.com',
            company_address = '郑州市金水区',
            brand_color = '#16A34A',
            brand_color_secondary = '#FF6B00',
            poster_template = 'guoquan_red',
            poster_bg_image = '/brand/guoquan-poster-bg.svg',
            default_benefits = %s,
            company_intro = %s
        WHERE id = 1""",
        (new_benefits, new_intro),
    )
    conn.commit()


def _migrate_guoquan_brand_color(conn):
    """将历史锅圈默认红色升级为绿色，保留用户自定义颜色。"""
    row = conn.execute("SELECT company_name, brand_color FROM company_config WHERE id = 1").fetchone()
    if not row:
        return
    company_name = row[0] if not isinstance(row, dict) else row.get("company_name")
    brand_color = row[1] if not isinstance(row, dict) else row.get("brand_color")
    if company_name != "锅圈食汇" or str(brand_color or "").upper() != LEGACY_GUOQUAN_BRAND_COLOR:
        return
    conn.execute(
        "UPDATE company_config SET brand_color = %s, updated_at = NOW() WHERE id = 1",
        (GUOQUAN_DEFAULT_BRAND_COLOR,),
    )
    conn.commit()


def _ensure_leader_chat_schema(conn) -> None:
    """Create leader analytics conversation tables for upgraded databases."""
    conn.executescript(
        """CREATE TABLE IF NOT EXISTS leader_chat_sessions (
            id VARCHAR(191) PRIMARY KEY,
            tenant_id VARCHAR(191) NOT NULL,
            actor_user_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'active',
            created_at VARCHAR(191) DEFAULT (NOW()),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            archived_at VARCHAR(191)
        );
CREATE INDEX idx_leader_chat_sessions_actor
            ON leader_chat_sessions(tenant_id, actor_user_id, status, updated_at);
CREATE TABLE IF NOT EXISTS leader_chat_requests (
            id VARCHAR(191) PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            client_request_id VARCHAR(191) NOT NULL,
            message LONGTEXT NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'pending',
            response_text LONGTEXT NOT NULL,
            response_chart LONGTEXT NOT NULL,
            error_code_internal VARCHAR(191) NOT NULL DEFAULT '',
            error_message_internal LONGTEXT NOT NULL,
            public_error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            lease_token VARCHAR(191) NOT NULL DEFAULT '',
            lease_expires_at VARCHAR(191),
            completed_at VARCHAR(191),
            UNIQUE (session_id, client_request_id),
            FOREIGN KEY (session_id) REFERENCES leader_chat_sessions(id)
        );
CREATE INDEX idx_leader_chat_requests_session
            ON leader_chat_requests(session_id, created_at);
CREATE TABLE IF NOT EXISTS leader_chat_messages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(191) NOT NULL,
            request_id VARCHAR(191) NOT NULL,
            role VARCHAR(191) NOT NULL,
            content LONGTEXT NOT NULL,
            tool_calls LONGTEXT NOT NULL,
            tool_results LONGTEXT NOT NULL,
            chart_spec LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (session_id) REFERENCES leader_chat_sessions(id),
            FOREIGN KEY (request_id) REFERENCES leader_chat_requests(id)
        );
CREATE INDEX idx_leader_chat_messages_session
            ON leader_chat_messages(session_id, id)"""
    )


def _ensure_active_role_index(conn) -> None:
    """为活跃岗位维护普通索引，用于同名岗位查重/分组查询。

    克隆岗位（JD 复制）会合法地产生同名活跃岗位，因此这里不建唯一索引，
    避免阻断克隆流程；同名岗位的创建查重由路由层显式校验兜底。
    """
    _ensure_index(
        conn,
        "CREATE INDEX idx_pipelines_active_role ON pipelines(active_role_key)",
        "idx_pipelines_active_role",
    )


def _migrate():
    """安全添加新列（不影响已有数据）"""
    conn = get_db()
    try:
        auth_user_cols = _table_columns(conn, "auth_users")
        if "tenant_id" not in auth_user_cols:
            conn.execute("ALTER TABLE auth_users ADD COLUMN tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default'")

        # hr_contact 唯一性兜底（并发注册/建号竞态）：
        # 1) 空串改 NULL——唯一索引不去重 NULL，多个未配置邮箱的用户可共存；
        # 2) 加唯一索引——应用层 ensure_email_available 的 check-then-act 预检
        #    在并发窗口下会漏判，靠数据库约束最终拦截（1062 由路由层转 409）。
        conn.execute("ALTER TABLE auth_users MODIFY COLUMN hr_contact VARCHAR(191) NULL DEFAULT NULL")
        conn.execute("UPDATE auth_users SET hr_contact=NULL WHERE hr_contact=''")
        _ensure_index(
            conn,
            "ALTER TABLE auth_users ADD UNIQUE INDEX uk_auth_users_hr_contact (hr_contact)",
            "uk_auth_users_hr_contact",
        )

        pipeline_cols = _table_columns(conn, "pipelines")
        if "tenant_id" not in pipeline_cols:
            conn.execute("ALTER TABLE pipelines ADD COLUMN tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default'")
        if "owner_user_id" not in pipeline_cols:
            conn.execute("ALTER TABLE pipelines ADD COLUMN owner_user_id VARCHAR(191) NOT NULL DEFAULT 'user_shanghai'")
        # 历史岗位名称与创建入口使用同一规整规则，避免仅空格差异绕过查重和分组。
        conn.execute("UPDATE pipelines SET role=TRIM(REPLACE(role, '　', ' '))")
        # archived 状态从未被代码写入，废除该状态前把历史数据统一收口为 completed，
        # 否则这些行会以“活跃岗位”身份参与同名查重与活跃岗位索引。
        conn.execute("UPDATE pipelines SET status='completed' WHERE status='archived'")
        # 历史 MySQL 库可能由早期部署创建，未经过 init_db() 中的
        # 增量字段补齐；面试中心岗位下拉会读取该字段，因此启动迁移也必须覆盖。
        if "type" not in pipeline_cols:
            conn.execute("ALTER TABLE pipelines ADD COLUMN type VARCHAR(191) NOT NULL DEFAULT 'tech'")
            pipeline_cols.append("type")
        # 早期部署把这两个 TEXT 增量列转换成了 VARCHAR(1024)，
        # 而它们随后会参与组合索引。统一收窄到 191 字符，兼容 utf8mb4
        # 的 3072 字节索引上限；实际租户/用户 ID 远小于此长度。
        conn.execute("ALTER TABLE pipelines MODIFY COLUMN tenant_id VARCHAR(191) NOT NULL DEFAULT 'tenant_default'")
        conn.execute("ALTER TABLE pipelines MODIFY COLUMN owner_user_id VARCHAR(191) NOT NULL DEFAULT 'user_shanghai'")
        # 早期版本已创建的增量列可能仍是 VARCHAR(1024)，统一收窄短字段，
        # 同时把 JSON 字段改为 LONGTEXT，避免 InnoDB 行大小限制。
        for table, short_columns in {
            "candidates": {
                "education",
                "major",
                "hr_note",
                "phone",
                "email",
                "contact_status",
            },
            "resumes": {
                "phone",
                "gender",
                "contact_status",
                "source_type",
                "source_account_id",
                "source_message_id",
                "source_attachment_id",
                "candidate_email",
                "sender_email",
                "content_sha256",
                "storage_backend",
                "storage_key",
                "original_filename",
            },
        }.items():
            columns = _table_columns(conn, table)
            for column in short_columns & set(columns):
                conn.execute(f"ALTER TABLE `{table}` MODIFY COLUMN `{column}` VARCHAR(191) DEFAULT ''")
            if "ragflow_json" in columns:
                conn.execute(f"ALTER TABLE `{table}` MODIFY COLUMN `ragflow_json` LONGTEXT")
        _ensure_mysql_long_text_columns(conn)
        conn.execute("UPDATE pipelines SET tenant_id='tenant_default' WHERE tenant_id IS NULL OR tenant_id=''")
        legacy_owner_row = conn.execute(
            "SELECT id FROM auth_users WHERE role_id='admin' ORDER BY created_at LIMIT 1"
        ).fetchone()
        legacy_owner_id = legacy_owner_row["id"] if legacy_owner_row else "user_shanghai"
        conn.execute(
            "UPDATE pipelines SET owner_user_id=%s WHERE owner_user_id IS NULL OR owner_user_id='' OR NOT EXISTS (SELECT 1 FROM auth_users users WHERE users.id=pipelines.owner_user_id)",
            (legacy_owner_id,),
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_pipelines_owner ON pipelines(tenant_id, owner_user_id, created_at)",
            "idx_pipelines_owner",
        )
        pipeline_cols = _table_columns(conn, "pipelines")
        if "active_role_key" not in pipeline_cols:
            conn.execute(
                "ALTER TABLE pipelines ADD COLUMN active_role_key VARCHAR(383) "
                "GENERATED ALWAYS AS "
                "(CASE WHEN status NOT IN ('completed') "
                "THEN CONCAT(tenant_id, ':', owner_user_id, ':', role) ELSE NULL END) STORED"
            )
        _ensure_active_role_index(conn)

        # 检查并添加 candidates 表新列
        existing = _table_columns(conn, "candidates")
        new_cols = {
            "education_score": "INTEGER DEFAULT 0",
            "major_match_score": "INTEGER DEFAULT 0",
            "education": "VARCHAR(191) DEFAULT ''",
            "major": "VARCHAR(191) DEFAULT ''",
            "resume_id": "VARCHAR(191) DEFAULT NULL",
            "tenant_id": "VARCHAR(191) NOT NULL DEFAULT 'tenant_default'",
            "hr_note": "LONGTEXT",
            "phone": "VARCHAR(191) DEFAULT ''",
            "email": "VARCHAR(191) DEFAULT ''",
            "contact_status": "VARCHAR(191) DEFAULT ''",
            "ragflow_json": "LONGTEXT",
            "match_batch": "VARCHAR(191) NOT NULL DEFAULT ''",
            "shortlist_min": "INTEGER",
            "screening_decision": "VARCHAR(191) NOT NULL DEFAULT ''",
            "screening_decision_at": "VARCHAR(191) NOT NULL DEFAULT ''",
            "offered_at": "VARCHAR(191) DEFAULT NULL",
        }
        for col, col_type in new_cols.items():
            if col not in existing:
                conn.execute(f"ALTER TABLE candidates ADD COLUMN {col} {col_type}")
        conn.execute("UPDATE candidates SET tenant_id='tenant_default' WHERE tenant_id IS NULL OR tenant_id=''")
        # 历史候选人没有录用决策时间，只能用入库时间做一次性兼容回填；新记录由 update_candidate 写入真实时间。
        conn.execute(
            "UPDATE candidates SET offered_at=created_at "
            "WHERE status='offered' AND (offered_at IS NULL OR offered_at='')"
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_candidates_offered_at ON candidates(offered_at)",
            "idx_candidates_offered_at",
        )

        # 检查并添加 resumes 表新列
        resume_cols = _table_columns(conn, "resumes")
        resume_new_cols = {
            "linked_resume_id": "VARCHAR(191) DEFAULT NULL",
            "tenant_id": "VARCHAR(191) NOT NULL DEFAULT 'tenant_default'",
            "email": "VARCHAR(191) DEFAULT ''",
            "phone": "VARCHAR(191) DEFAULT ''",
            "gender": "VARCHAR(191) DEFAULT ''",
            "contact_status": "VARCHAR(191) DEFAULT ''",
            "ragflow_json": "LONGTEXT",
            "owner_user_id": "VARCHAR(191) DEFAULT ''",
            "source_type": "VARCHAR(191) DEFAULT ''",
            "source_account_id": "VARCHAR(191) DEFAULT ''",
            "source_message_id": "VARCHAR(191) DEFAULT ''",
            "source_attachment_id": "VARCHAR(191) DEFAULT ''",
            "candidate_email": "VARCHAR(191) DEFAULT ''",
            "sender_email": "VARCHAR(191) DEFAULT ''",
            "content_sha256": "VARCHAR(191) DEFAULT ''",
            "storage_backend": "VARCHAR(191) DEFAULT ''",
            "storage_key": "VARCHAR(191) DEFAULT ''",
            "original_filename": "VARCHAR(191) DEFAULT ''",
        }
        for col, col_type in resume_new_cols.items():
            if col not in resume_cols:
                conn.execute(f"ALTER TABLE resumes ADD COLUMN {col} {col_type}")
        conn.execute("UPDATE resumes SET tenant_id='tenant_default' WHERE tenant_id IS NULL OR tenant_id=''")

        # 简历归档功能已废除：代码不再读写 is_archived，历史库中的该列一并删除。
        if "is_archived" in resume_cols:
            conn.execute("ALTER TABLE resumes DROP COLUMN is_archived")

        # 为新列创建索引（使用 IF NOT EXISTS 保证安全）
        _ensure_index(conn, "CREATE INDEX idx_resumes_tenant ON resumes(tenant_id)", "idx_resumes_tenant")
        _ensure_index(conn, "CREATE INDEX idx_resumes_linked ON resumes(linked_resume_id)", "idx_resumes_linked")
        try:
            conn.execute("DROP INDEX IF EXISTS idx_resumes_fp_high")
        except Exception:
            try:
                conn.execute("DROP INDEX idx_resumes_fp_high ON resumes")
            except Exception:
                pass
        # MySQL has no partial indexes; application-level high-confidence checking
        # still enforces deduplication while this index keeps tenant lookups fast.
        _ensure_index(
            conn,
            "CREATE INDEX idx_resumes_fp_high ON resumes(tenant_id, fingerprint)",
            "idx_resumes_fp_high",
        )
        _ensure_email_domain_schema(conn)
        _ensure_leader_chat_schema(conn)

        # 百人面试 — interview_sessions 新增列（P0视频面试）
        session_cols = _table_columns(conn, "interview_sessions")
        session_new_cols = {
            "video_paths": "LONGTEXT DEFAULT ('[]')",
            "recommendation": "LONGTEXT",
            "evaluated_at": "VARCHAR(191) DEFAULT NULL",
            # 阿里云直播字段
            "stream_name": "VARCHAR(191) DEFAULT ''",
            "rtmp_push_url": "VARCHAR(191) DEFAULT ''",
            "hls_play_url": "VARCHAR(191) DEFAULT ''",
            "flv_play_url": "VARCHAR(191) DEFAULT ''",
            "is_streaming": "INTEGER DEFAULT 0",
            "stream_started_at": "VARCHAR(191) DEFAULT NULL",
            "stream_ended_at": "VARCHAR(191) DEFAULT NULL",
            "recording_url": "VARCHAR(191) DEFAULT ''",
            "oss_object_key": "VARCHAR(191) DEFAULT ''",
            "snapshots": "LONGTEXT DEFAULT ('[]')",
            "feishu_chat_id": "VARCHAR(191) DEFAULT ''",
            "invite_sent_at": "VARCHAR(191) DEFAULT NULL",
            "active_client_id": "VARCHAR(191) DEFAULT ''",
            "lease_expires_at": "VARCHAR(191) DEFAULT ''",
        }
        for col, col_type in session_new_cols.items():
            if col not in session_cols:
                conn.execute(f"ALTER TABLE interview_sessions ADD COLUMN {col} {col_type}")
        _ensure_index(
            conn,
            "CREATE INDEX idx_sessions_status ON interview_sessions(pipeline_id, status)",
            "idx_sessions_status",
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_sessions_stream ON interview_sessions(stream_name)",
            "idx_sessions_stream",
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_sessions_candidate_status ON interview_sessions(pipeline_id, candidate_id, status, id)",
            "idx_sessions_candidate_status",
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_sessions_invite_expiry ON interview_sessions(pipeline_id, invite_sent_at, expires_at)",
            "idx_sessions_invite_expiry",
        )
        _ensure_index(
            conn,
            "CREATE INDEX idx_sessions_stream_online ON interview_sessions(pipeline_id, stream_name, is_streaming)",
            "idx_sessions_stream_online",
        )

        conn.commit()
    except Exception as e:
        print(f"[DB] Migration error: {e}")


def create_monitor_tables():
    """创建监控系统所需的 3 个表（日志、Token 用量、操作审计）"""
    conn = get_db()
    conn.executescript("""CREATE TABLE IF NOT EXISTS system_logs (
            id        BIGINT AUTO_INCREMENT PRIMARY KEY,
            timestamp VARCHAR(191)    NOT NULL DEFAULT (NOW()),
            level VARCHAR(191)    NOT NULL,
            source VARCHAR(191)    NOT NULL,
            message LONGTEXT    NOT NULL,
            extra LONGTEXT,
            exception VARCHAR(191)    DEFAULT NULL
        );
CREATE INDEX idx_logs_timestamp ON system_logs(timestamp);
CREATE INDEX idx_logs_level     ON system_logs(level);
CREATE INDEX idx_logs_source    ON system_logs(source);
CREATE TABLE IF NOT EXISTS llm_usage (
            id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
            timestamp VARCHAR(191)    NOT NULL DEFAULT (NOW()),
            model VARCHAR(191)    NOT NULL,
            call_type VARCHAR(191)    NOT NULL DEFAULT 'text',
            prompt_tokens       INTEGER NOT NULL DEFAULT 0,
            completion_tokens   INTEGER NOT NULL DEFAULT 0,
            total_tokens        INTEGER NOT NULL DEFAULT 0,
            estimated_cost_usd  REAL    NOT NULL DEFAULT 0.0,
            agent VARCHAR(191)    DEFAULT NULL,
            operation VARCHAR(191)    DEFAULT NULL,
            pipeline_id VARCHAR(191)    DEFAULT NULL,
            latency_ms          INTEGER DEFAULT NULL,
            success             INTEGER NOT NULL DEFAULT 1
        );
CREATE INDEX idx_usage_timestamp ON llm_usage(timestamp);
CREATE INDEX idx_usage_model     ON llm_usage(model);
CREATE INDEX idx_usage_agent     ON llm_usage(agent);
CREATE TABLE IF NOT EXISTS llm_trace (
            id          BIGINT AUTO_INCREMENT PRIMARY KEY,
            trace_id VARCHAR(191)    NOT NULL,
            step VARCHAR(191)    NOT NULL,
            model VARCHAR(191)    DEFAULT '',
            status LONGTEXT,
            latency_ms  INTEGER DEFAULT 0,
            detail VARCHAR(191)    DEFAULT '',
            created_at VARCHAR(191)    NOT NULL DEFAULT (NOW())
        );
CREATE INDEX idx_trace_id ON llm_trace(trace_id);
CREATE TABLE IF NOT EXISTS audit_events (
            id          BIGINT AUTO_INCREMENT PRIMARY KEY,
            timestamp VARCHAR(191)    NOT NULL DEFAULT (NOW()),
            event_type VARCHAR(191)    NOT NULL,
            actor VARCHAR(191)    NOT NULL DEFAULT 'system',
            entity_type VARCHAR(191)    DEFAULT NULL,
            entity_id VARCHAR(191)    DEFAULT NULL,
            summary VARCHAR(191)    NOT NULL,
            details VARCHAR(191)    DEFAULT '{}'
        );
CREATE INDEX idx_audit_timestamp  ON audit_events(timestamp);
CREATE INDEX idx_audit_event_type ON audit_events(event_type);
DELETE FROM system_logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL 30 DAY)""")
    conn.commit()
