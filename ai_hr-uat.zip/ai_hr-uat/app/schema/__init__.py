"""数据库表结构领域包（目录整理）。

原 ``app/db_schema.py`` 按 ``docs/directory-reorganization-plan.md``
归入本包，实现原样保留。旧导入路径 ``import app.db_schema`` /
``from app.db_schema import X`` 经 sys.modules 别名指向同一模块对象，
``importlib.reload(app.db_schema)`` 与 monkeypatch 语义不变
（test_db_schema 依赖这两个行为）。
"""

import importlib
import sys

import app as _app_pkg  # noqa: E402

_mod = importlib.import_module("app.schema.db_schema")
sys.modules.setdefault("app.db_schema", _mod)
setattr(_app_pkg, "db_schema", _mod)
