"""Shared utility functions extracted from main.py."""

from app.service_helpers import parse_stage_output


def decode_bytes(content: bytes) -> str:
    """Decode bytes with automatic encoding detection."""
    encodings = ["utf-8", "gb18030", "gbk", "gb2312", "latin-1"]
    for enc in encodings:
        try:
            text = content.decode(enc)
            if enc == "utf-8":
                return text
            if any("一" <= c <= "鿿" for c in text[:200]):
                return text
        except (UnicodeDecodeError, UnicodeError):
            continue
    return content.decode("utf-8", errors="ignore")


def extract_text_from_file(content: bytes, ext: str) -> str:
    """Extract text from uploaded file content based on file extension."""
    if ext == "pdf":
        try:
            import io

            import PyPDF2

            pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
            return "\n".join([page.extract_text() or "" for page in pdf_reader.pages])
        except Exception:
            return decode_bytes(content)
    elif ext in ("docx", "doc"):
        try:
            import io

            import docx

            doc = docx.Document(io.BytesIO(content))
            return "\n".join([p.text for p in doc.paragraphs])
        except Exception:
            return decode_bytes(content)
    else:
        return decode_bytes(content)


def extract_text_from_bytes_rich(content: bytes, filename: str = "") -> str:
    """Extract text using ragflow's layout-aware extractor (port).

    PDFs use pdfplumber word-level extraction + two-column/label reordering;
    DOCX uses paragraphs + tables; other formats decode bytes directly.
    Falls back to ``extract_text_from_file`` if the rich path returns empty.

    Returns plain text (lines joined by newline).
    """
    try:
        from app.resume_parser.core import extract_text as ragflow_extract_text

        name = filename or "resume.txt"
        indexed_text, lines, _positions = ragflow_extract_text(name, content)
        if lines:
            return "\n".join(lines)
        if indexed_text:
            return indexed_text
    except Exception:
        pass

    # Legacy fallback
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    return extract_text_from_file(content, ext)
