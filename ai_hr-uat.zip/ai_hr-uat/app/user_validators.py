"""账号与邮箱字段的公共校验（管理端建号与企微自助注册共用）。

错误统一抛 HTTPException（422 格式 / 409 占用），与 admin 路由的既有
行为保持一致；auth 路由侧捕获后转成 {error: detail} 响应。
"""

import re

from fastapi import HTTPException

from app.db import get_db

USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def validate_username(username: str) -> str:
    normalized = (username or "").strip()
    if not USERNAME_PATTERN.fullmatch(normalized):
        raise HTTPException(status_code=422, detail="账号仅支持 3-32 位字母、数字、点、下划线和连字符")
    return normalized


def validate_email(email: str) -> str:
    normalized = (email or "").strip().lower()
    if not normalized:
        raise HTTPException(status_code=422, detail="请填写 HR 联系邮箱")
    if not EMAIL_PATTERN.fullmatch(normalized):
        raise HTTPException(status_code=422, detail="HR 联系邮箱格式不正确")
    return normalized


def ensure_email_available(email: str, exclude_user_id: str = "") -> None:
    email = (email or "").strip().lower()
    if not email:
        return
    conn = get_db()
    auth_row = conn.execute(
        "SELECT id FROM auth_users WHERE hr_contact=%s  AND id!=%s",
        (email, exclude_user_id),
    ).fetchone()
    if auth_row:
        raise HTTPException(status_code=409, detail="该 HR 联系邮箱已被其他用户使用")
    account_row = conn.execute(
        "SELECT id FROM email_accounts WHERE email_address=%s  AND owner_user_id!=%s",
        (email, exclude_user_id),
    ).fetchone()
    if account_row:
        raise HTTPException(status_code=409, detail="该 HR 联系邮箱已被其他用户使用")
