#!/usr/bin/env python3
"""
模板合成器 - 画幅配置、投递区定位口径与字体加载

CANVAS_CONFIGS / CANVAS_ID_MAP 定义各画幅的设计坐标；delivery_layout /
qr_slot_from_delivery 是投递区「占位框」与「真码粘贴」的唯一定位口径；
load_font 为投递区排版提供字体加载。旧版模板贴字渲染（generate_text_layer、
composite_with_template 等）已随投递区改造移除。
"""

from __future__ import annotations

import os
from pathlib import Path

from PIL import ImageFont

# 项目根目录：优先环境变量，回退到包上级（app/ 的上级）
PROJECT_ROOT = Path(os.getenv("PROJECT_ROOT", str(Path(__file__).resolve().parents[1])))

# 字体路径
FONT_DIR = PROJECT_ROOT / "assets" / "fonts" / "SubsetOTF" / "CN"
FONT_HEAVY = FONT_DIR / "SourceHanSansCN-Heavy.otf"
FONT_BOLD = FONT_DIR / "SourceHanSansCN-Bold.otf"
FONT_REGULAR = FONT_DIR / "SourceHanSansCN-Regular.otf"

CANVAS_CONFIGS = {
    "recruit_long": {
        "name": "招聘长图",
        "width": 1080,
        "height": 2400,
        "scale_x": 1080 / 768,
        "scale_y": 2400 / 1024,
        "layout": {
            "logo": {"x": 32, "y": 31, "w": 192, "h": 128},
            "stock": {"x": 842, "y": 47, "w": 211, "h": 40},
            "bear": {"cx": 216, "cy": 405, "w": 435, "h": 490},
            "title": {"x": 410, "y": 126, "w": 595, "h": 291},
            "job_info": {"x": 410, "y": 442, "w": 636, "h": 58},
            "block1": {"x": 85, "y": 620, "w": 907, "h": 1230},
            "block2": {"x": 85, "y": 1885, "w": 907, "h": 150},
            "delivery": {"x": 85, "y": 2070, "w": 907, "h": 220},
            "footer": {"x": 53, "y": 2325, "w": 974, "h": 48},
        },
    },
    "xiaohongshu": {
        "name": "小红书图文",
        "width": 1242,
        "height": 1660,
        "scale_x": 1242 / 768,
        "scale_y": 1660 / 1024,
        "layout": {
            "logo": {"x": 37, "y": 32, "w": 221, "h": 131},
            "stock": {"x": 968, "y": 48, "w": 242, "h": 40},
            "bear": {"cx": 249, "cy": 415, "w": 501, "h": 502},
            "title": {"x": 472, "y": 129, "w": 682, "h": 291},
            "job_info": {"x": 472, "y": 453, "w": 729, "h": 58},
            "block1": {"x": 98, "y": 575, "w": 1043, "h": 711},
            "block2": {"x": 98, "y": 1313, "w": 1043, "h": 119},
            "delivery": {"x": 98, "y": 1450, "w": 1043, "h": 145},
            "footer": {"x": 61, "y": 1605, "w": 1117, "h": 48},
        },
    },
    "douyin_h": {
        "name": "抖音横版",
        "width": 1920,
        "height": 1080,
        "scale_x": 1920 / 768,
        "scale_y": 1080 / 1024,
        "layout": {
            "logo": {"x": 40, "y": 30, "w": 240, "h": 140},
            "stock": {"x": 1650, "y": 40, "w": 230, "h": 30},
            "bear": {"cx": 280, "cy": 350, "w": 450, "h": 500},
            "title": {"x": 550, "y": 80, "w": 800, "h": 200},
            "job_info": {"x": 550, "y": 300, "w": 800, "h": 60},
            "block1": {"x": 550, "y": 380, "w": 1320, "h": 450},
            "block2": {"x": 550, "y": 850, "w": 1320, "h": 80},
            "delivery": {"x": 550, "y": 950, "w": 1320, "h": 90},
            "footer": {"x": 40, "y": 1045, "w": 1840, "h": 28},
        },
    },
    "douyin_v": {
        "name": "抖音竖版",
        "width": 1080,
        "height": 1920,
        "scale_x": 1080 / 768,
        "scale_y": 1920 / 1024,
        "layout": {
            "logo": {"x": 32, "y": 37, "w": 192, "h": 151},
            "stock": {"x": 842, "y": 56, "w": 211, "h": 47},
            "bear": {"cx": 216, "cy": 480, "w": 435, "h": 581},
            "title": {"x": 410, "y": 150, "w": 595, "h": 337},
            "job_info": {"x": 410, "y": 525, "w": 636, "h": 67},
            "block1": {"x": 85, "y": 665, "w": 907, "h": 823},
            "block2": {"x": 85, "y": 1518, "w": 907, "h": 138},
            "delivery": {"x": 85, "y": 1678, "w": 907, "h": 150},
            "footer": {"x": 53, "y": 1838, "w": 974, "h": 56},
        },
    },
    "moments": {
        "name": "朋友圈单图",
        "width": 1080,
        "height": 1440,
        "scale_x": 1080 / 768,
        "scale_y": 1440 / 1024,
        "layout": {
            "logo": {"x": 23, "y": 20, "w": 137, "h": 81},
            "stock": {"x": 599, "y": 30, "w": 150, "h": 25},
            "bear": {"cx": 154, "cy": 256, "w": 310, "h": 310},
            "title": {"x": 292, "y": 80, "w": 422, "h": 180},
            "job_info": {"x": 292, "y": 280, "w": 451, "h": 36},
            "block1": {"x": 61, "y": 355, "w": 645, "h": 439},
            "block2": {"x": 61, "y": 810, "w": 645, "h": 74},
            "delivery": {"x": 61, "y": 895, "w": 645, "h": 105},
            "footer": {"x": 38, "y": 1010, "w": 691, "h": 30},
        },
    },
}

# 画幅ID映射（小海前端使用的ID）
CANVAS_ID_MAP = {
    "long": "recruit_long",
    "xhs": "xiaohongshu",
    "dy_h": "douyin_h",
    "dy_v": "douyin_v",
    "moments": "moments",
}


def qr_slot_from_delivery(canvas_id: str, margin_pct: float = 8) -> dict:
    """返回二维码槽位（设计坐标系，基于投递框 delivery）。

    这是「占位框」与「真码粘贴」的唯一定位口径：槽位取投递卡右侧、
    垂直居中的方槽，四周留 margin_pct% 边距。坐标基于该画幅的标准宽高，
    实际贴码时需按目标图像尺寸等比缩放。
    """
    return delivery_layout(canvas_id, margin_pct)["qr_slot"]


def delivery_layout(canvas_id: str, margin_pct: float = 8) -> dict:
    """Return the canonical delivery-area layout in design coordinates.

    The email column and QR slot share the delivery box center line and mirror
    the same outer padding. Callers should scale this layout only after the
    final image has been cover-fitted to the configured canvas size.
    """
    template_id = CANVAS_ID_MAP.get(canvas_id, "recruit_long")
    config = CANVAS_CONFIGS.get(template_id, CANVAS_CONFIGS["recruit_long"])
    box = config["layout"]["delivery"]
    dx, dy, dw, dh = box["x"], box["y"], box["w"], box["h"]
    pad = max(6, int(dh * margin_pct / 100))
    # Keep the QR square inside the right half while adapting to each format's
    # delivery height, including short horizontal and moments canvases.
    size = max(40, min(dh - pad * 2, dw // 2 - pad))
    qr_x = dx + dw - pad - size
    qr_y = dy + (dh - size) // 2
    gap = max(12, int(dw * 0.035))
    email_x = dx + pad
    email_w = max(40, qr_x - gap - email_x)
    return {
        "delivery_box": {"x": dx, "y": dy, "w": dw, "h": dh},
        "email_box": {"x": email_x, "y": dy + pad, "w": email_w, "h": max(20, dh - pad * 2)},
        "qr_slot": {
            "x": qr_x,
            "y": qr_y,
            "size": size,
            "pad": pad,
            "canvas_w": config["width"],
            "canvas_h": config["height"],
        },
        "center_y": dy + dh / 2,
        "canvas_w": config["width"],
        "canvas_h": config["height"],
    }


def load_font(weight="regular", size=48):
    """加载思源黑体"""
    size = max(1, int(size))
    project_font = {"heavy": FONT_HEAVY, "bold": FONT_BOLD, "regular": FONT_REGULAR}.get(weight, FONT_REGULAR)
    system_fonts = {
        "heavy": [
            "/System/Library/Fonts/STHeiti Medium.ttc",
            "/System/Library/Fonts/Hiragino Sans GB.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
        ],
        "bold": [
            "/System/Library/Fonts/STHeiti Medium.ttc",
            "/System/Library/Fonts/Hiragino Sans GB.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        ],
        "regular": [
            "/System/Library/Fonts/Hiragino Sans GB.ttc",
            "/System/Library/Fonts/STHeiti Light.ttc",
            "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.otf",
        ],
    }
    windows_path = "C:/Windows/Fonts/msyhbd.ttc" if weight in ["heavy", "bold"] else "C:/Windows/Fonts/msyh.ttc"
    for path in [project_font, Path(windows_path), *map(Path, system_fonts.get(weight, system_fonts["regular"]))]:
        if path.exists():
            try:
                return ImageFont.truetype(str(path), size)
            except OSError:
                continue
    raise RuntimeError(
        "No scalable CJK font is available. Install fonts-noto-cjk in Linux or provide the project Source Han fonts."
    )
