"""用户（HR）邮箱账户联动：让 email_accounts 与 auth_users 保持 1:1。

每个 HR 只有一个邮箱，邮箱的维护入口在用户权限界面。这里的函数由 admin 路由
在创建/更新/删除用户时调用，把邮箱收发配置（服务商、SMTP/IMAP 参数、授权码）
落进 email_accounts，供邮箱同步引擎读取；复用 email_accounts.encrypt_credential
做授权码加密。
"""

from __future__ import annotations

import uuid

from app.db import get_auth_user, get_db
from app.email_accounts import encrypt_credential
from app.email_providers import resolve_provider_config


def _normalized_email(email: str) -> str:
    return (email or "").strip().lower()


def sync_user_mailbox(
    user_id: str,
    *,
    email: str,
    provider: str = "custom",
    credential: str = "",
    smtp_host: str = "",
    smtp_port: int | None = None,
    smtp_security: str = "",
    imap_host: str = "",
    imap_port: int | None = None,
    imap_security: str = "",
) -> None:
    """按 owner_user_id 维护 HR 邮箱账户（1:1 upsert）。

    服务商预设带出收发服务器/端口/加密方式；显式传入值优先（用于 custom 或覆盖）。
    授权码与 IMAP 收信共用 credential_ciphertext；非空时加密更新，空则保留旧值。
    """
    email = _normalized_email(email)
    if not email:
        return

    preset = resolve_provider_config(provider)
    smtp = preset["smtp"]
    imap = preset["imap"]

    r_smtp_host = (smtp_host or "").strip() or smtp["host"]
    r_smtp_port = int(smtp_port or smtp["port"])
    r_smtp_security = (smtp_security or "").strip() or smtp["security"]
    r_imap_host = (imap_host or "").strip() or imap["host"]
    r_imap_port = int(imap_port or imap["port"])
    r_imap_security = (imap_security or "").strip() or imap["security"]

    conn = get_db()
    existing = conn.execute("SELECT id FROM email_accounts WHERE owner_user_id=%s", (user_id,)).fetchone()

    if existing:
        account_id = existing["id"]
        conn.execute(
            """
            UPDATE email_accounts SET
                email_address=%s, provider=%s, imap_host=%s, imap_port=%s, security_mode=%s,
                username=%s, smtp_host=%s, smtp_port=%s, smtp_security=%s, updated_by=%s,
                updated_at=NOW()
            WHERE id=%s
            """,
            (
                email,
                provider,
                r_imap_host,
                r_imap_port,
                r_imap_security,
                email,
                r_smtp_host,
                r_smtp_port,
                r_smtp_security,
                user_id,
                account_id,
            ),
        )
        if credential:
            conn.execute(
                "UPDATE email_accounts SET credential_ciphertext=%s, credential_key_version=1 WHERE id=%s",
                (encrypt_credential(credential), account_id),
            )
    else:
        user_row = conn.execute("SELECT tenant_id FROM auth_users WHERE id=%s", (user_id,)).fetchone()
        tenant_id = user_row["tenant_id"] if user_row else "tenant_default"
        account_id = f"mail_{uuid.uuid4().hex}"
        conn.execute(
            """
            INSERT INTO email_accounts
                (id, tenant_id, owner_user_id, name, email_address, provider, imap_host, imap_port,
                 security_mode, username, credential_ciphertext, credential_key_version,
                 smtp_host, smtp_port, smtp_security, enabled, created_by, updated_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1, %s, %s, %s, 1, %s, %s)
            """,
            (
                account_id,
                tenant_id,
                user_id,
                email,
                email,
                provider,
                r_imap_host,
                r_imap_port,
                r_imap_security,
                email,
                encrypt_credential(credential),
                r_smtp_host,
                r_smtp_port,
                r_smtp_security,
                user_id,
                user_id,
            ),
        )

    conn.commit()


def delete_user_mailbox(user_id: str) -> None:
    """删除该用户的邮箱账户及其同步历史（对齐 email_accounts.delete_account 的清理）。"""
    conn = get_db()
    account = conn.execute("SELECT id FROM email_accounts WHERE owner_user_id=%s", (user_id,)).fetchone()
    if not account:
        return
    account_id = account["id"]
    conn.execute("DELETE FROM email_sync_recoveries WHERE email_account_id=%s", (account_id,))
    conn.execute(
        "DELETE FROM email_sync_attachments WHERE message_record_id IN (SELECT id FROM email_sync_messages WHERE email_account_id=%s)",
        (account_id,),
    )
    conn.execute("DELETE FROM email_sync_messages WHERE email_account_id=%s", (account_id,))
    conn.execute("DELETE FROM email_sync_runs WHERE email_account_id=%s", (account_id,))
    conn.execute("DELETE FROM email_sync_leases WHERE email_account_id=%s", (account_id,))
    conn.execute("DELETE FROM email_account_grants WHERE email_account_id=%s", (account_id,))
    conn.execute("DELETE FROM email_accounts WHERE id=%s", (account_id,))
    conn.commit()


def resolve_user_qr(user: dict) -> str:
    """把 hr_qr_code_storage_key 重新签成短时效 URL，避免存库 URL 过期。"""
    key = (user.get("hr_qr_code_storage_key") or "").strip()
    if not key:
        return ""
    try:
        from app.brand_assets import brand_asset_url

        return brand_asset_url(key.rsplit("/", 1)[-1], storage_key=key)
    except Exception:
        return ""


def delete_oss_object(storage_key: str) -> None:
    """删除 OSS 对象（换/清二维码、删除用户时清理旧文件，失败不阻断主流程）。"""
    if not storage_key:
        return
    try:
        from app.media_storage import get_media_storage

        get_media_storage().delete(storage_key)
    except Exception:
        pass


class PipelineHrNotConfiguredError(Exception):
    """职位归属 HR 缺少用户级联系配置（联系邮箱 / 投递二维码）。"""


def resolve_pipeline_hr(pipeline: dict | None) -> dict | None:
    """按 pipelines.owner_user_id 解析职位归属 HR 用户（用户级联系方式与二维码）。"""
    if not pipeline:
        return None
    owner_id = (pipeline.get("owner_user_id") or "").strip()
    if not owner_id:
        return None
    return get_auth_user(owner_id)


def require_pipeline_hr(pipeline: dict | None) -> dict:
    """严格校验职位归属 HR；不存在或未配置联系邮箱/投递二维码时抛错。

    公司级 HR 邮箱/二维码配置已移除，这些信息只维护在「用户与权限」的用户上。
    """
    user = resolve_pipeline_hr(pipeline)
    if not user:
        raise PipelineHrNotConfiguredError("该职位的归属 HR 不存在")
    if not (user.get("hr_contact") or "").strip():
        raise PipelineHrNotConfiguredError("该职位的归属 HR 尚未配置联系邮箱")
    if not (user.get("hr_qr_code_storage_key") or "").strip():
        raise PipelineHrNotConfiguredError("该职位的归属 HR 尚未配置投递二维码")
    return user


def hr_brand_config(company_config: dict, hr_user: dict) -> dict:
    """把归属 HR 的用户级投递二维码并入公司品牌配置（无公司级 HR 字段）。"""
    return {
        **company_config,
        "hr_qr_code": resolve_user_qr(hr_user),
        "hr_qr_code_storage_key": hr_user.get("hr_qr_code_storage_key") or "",
    }
