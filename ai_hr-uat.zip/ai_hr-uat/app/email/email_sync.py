"""Email sync module — multi-account IMAP runner, resume detection, and auto-import."""

from __future__ import annotations


import asyncio
import email
import hashlib
import imaplib
import os
import re
import time
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from email.header import decode_header
from email.utils import parseaddr, parsedate_to_datetime
from html import unescape
from io import BytesIO
from urllib.parse import parse_qs, unquote, urlencode, urljoin, urlparse, urlunparse

import requests

from app.email_logging import get_email_logger
from app.talent_pool import save_resume

logger = get_email_logger()


ACCOUNT_EMAIL_FOLDER = "INBOX"


def _mask_email(email_addr: str) -> str:
    """Mask email address for safe logging: t***@example.com"""
    if "@" not in email_addr:
        return email_addr[0] + "***" if len(email_addr) > 1 else "***"
    local, domain = email_addr.split("@", 1)
    masked_local = local[0] + "***" if len(local) > 1 else "***"
    return f"{masked_local}@{domain}"


def _log_text(value: str, limit: int = 120) -> str:
    """Keep user-controlled mail metadata on one bounded log line."""
    return re.sub(r"[\r\n\t]+", " ", str(value or "")).strip()[:limit]


# 支持的附件类型
_SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".doc", ".md", ".txt"}

# 最大附件大小（10MB）
_MAX_ATTACHMENT_SIZE = 10 * 1024 * 1024
# QQ/企业微信云附件可以大于普通 MIME 附件，但仍需有硬上限，避免把远端
# 响应无限制地读入内存。可通过环境变量调整，单位为 MB。
_MAX_REMOTE_ATTACHMENT_SIZE = int(os.getenv("EMAIL_REMOTE_ATTACHMENT_MAX_MB", "50")) * 1024 * 1024
_REMOTE_ATTACHMENT_HOSTS = {
    "wx.mail.qq.com",
    "mail.qq.com",
    "exmail.qq.com",
    "exmail.qq.com.cn",
}
_REMOTE_ATTACHMENT_TIMEOUT = (10, 90)


def _is_allowed_remote_host(host: str) -> bool:
    host = (host or "").lower().rstrip(".")
    return host in _REMOTE_ATTACHMENT_HOSTS or host.endswith(".mail.ftn.qq.com")


# ── 邮件解析 ────────────────────────────────────────────────────


def _decode_header_value(value) -> str:
    """Decode an RFC 2047 email header with encoding fallback chain."""
    if value is None:
        return ""
    # 即使邮件头仍包含 RFC 2047 编码词（例如 =?utf-8?B?...?=），IMAP 也会
    # 将其作为 str 返回。因此始终交给 decode_header 处理；若原样返回普通 str，
    # “简历”等有效中文主题可能无法命中简历关键词过滤器。
    try:
        parts = decode_header(value)
    except Exception:
        return str(value)
    result = []
    for part, charset in parts:
        if isinstance(part, str):
            result.append(part)
        elif isinstance(part, bytes):
            charsets = [charset, "utf-8", "gbk", "gb2312", "latin-1"]
            decoded = None
            for cs in charsets:
                if cs is None:
                    continue
                try:
                    decoded = part.decode(cs)
                    break
                except (UnicodeDecodeError, LookupError):
                    continue
            if decoded is None:
                decoded = part.decode("utf-8", errors="replace")
            result.append(decoded)
    return "".join(result)


def _extract_text_from_bytes(data: bytes, ext: str) -> str:
    """Extract text content from raw bytes based on file extension."""
    from app.utils import extract_text_from_bytes_rich

    return extract_text_from_bytes_rich(data, f"resume.{ext.lstrip('.')}")


# ── 多邮箱同步执行器 ────────────────────────────────────────────

_account_locks: dict[str, asyncio.Lock] = {}
_run_started_monotonic: dict[str, float] = {}
_sync_tasks_by_run_id: dict[str, asyncio.Task] = {}


class _SyncRunAborted(Exception):
    """Raised when the scheduler has failed a run or removed its lease."""


def _sync_run_is_active(run_id: str, account_id: str) -> bool:
    """Return whether a run may still perform mailbox/database work."""
    from app.db import get_db

    row = (
        get_db()
        .execute(
            """SELECT r.status, l.run_id
             FROM email_sync_runs r
             LEFT JOIN email_sync_leases l
               ON l.email_account_id=r.email_account_id AND l.run_id=r.id
            WHERE r.id=%s AND r.email_account_id=%s""",
            (run_id, account_id),
        )
        .fetchone()
    )
    return bool(row and row["status"] in {"queued", "running"} and row["run_id"] == run_id)


def _assert_sync_run_active(run_id: str, account_id: str) -> None:
    if not _sync_run_is_active(run_id, account_id):
        raise _SyncRunAborted(f"同步任务已终止 run={run_id}")


async def _renew_sync_lease_loop(account_id: str, run_id: str) -> None:
    """Renew a run lease independently of mailbox processing progress."""
    from app.email_accounts import renew_sync_lease

    try:
        while True:
            await asyncio.sleep(60)
            if not _sync_run_is_active(run_id, account_id):
                return
            renew_sync_lease(account_id, run_id)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.exception("同步租约续期任务异常 run=%s account=%s", run_id, account_id)


def dispatch_sync_run(run_id: str) -> asyncio.Task:
    """Create and track one sync task so the scheduler can cancel it."""
    task = asyncio.create_task(execute_sync_run(run_id))
    _sync_tasks_by_run_id[run_id] = task

    def _forget(_task: asyncio.Task) -> None:
        if _sync_tasks_by_run_id.get(run_id) is _task:
            _sync_tasks_by_run_id.pop(run_id, None)

    task.add_done_callback(_forget)
    return task


def cancel_sync_tasks(run_ids: list[str]) -> None:
    """Cancel in-process work after the scheduler marks runs failed."""
    for run_id in run_ids:
        task = _sync_tasks_by_run_id.get(run_id)
        if task and not task.done():
            task.cancel()


def _imap_connection(account: dict, credential: str):
    if account.get("security_mode") == "starttls":
        mail = imaplib.IMAP4(account["imap_host"], int(account["imap_port"]), timeout=10)
        mail.starttls()
        return mail
    return imaplib.IMAP4_SSL(account["imap_host"], int(account["imap_port"]), timeout=10)


def test_account_connection(account: dict, credential: str) -> dict:
    """Validate login and folder visibility without downloading messages."""
    mail = None
    username = _mask_email(str(account.get("username") or ""))
    host = str(account.get("imap_host") or "")
    port = int(account.get("imap_port") or 993)
    security = str(account.get("security_mode") or "ssl")
    folder = ACCOUNT_EMAIL_FOLDER
    logger.info(
        "开始测试邮箱连接 user=%s host=%s port=%s security=%s folder=%s credential=<redacted>",
        username,
        host,
        port,
        security,
        folder,
    )
    try:
        mail = _imap_connection(account, credential)
        logger.debug("IMAP 网络连接成功 user=%s host=%s port=%s", username, host, port)
        mail.login(account["username"], credential)
        logger.debug("IMAP 登录成功 user=%s host=%s", username, host)
        status, _ = mail.select(folder, readonly=True)
        if status != "OK":
            logger.warning("邮箱连接测试失败 user=%s code=IMAP_FOLDER_NOT_FOUND folder=%s", username, folder)
            return {"ok": False, "error_code": "IMAP_FOLDER_NOT_FOUND", "message": "邮件文件夹不可读"}
        logger.info("邮箱连接测试成功 user=%s host=%s folder=%s", username, host, folder)
        return {"ok": True, "message": "连接成功"}
    except TimeoutError as exc:
        logger.warning("邮箱连接测试失败 user=%s code=IMAP_CONNECT_TIMEOUT error=%s", username, exc)
        return {"ok": False, "error_code": "IMAP_CONNECT_TIMEOUT", "message": "IMAP 连接超时"}
    except imaplib.IMAP4.error as exc:
        logger.warning("邮箱连接测试失败 user=%s code=IMAP_AUTH_FAILED error=%s", username, exc)
        return {"ok": False, "error_code": "IMAP_AUTH_FAILED", "message": "IMAP 登录失败，请检查授权码"}
    except OSError as exc:
        logger.warning("邮箱连接测试失败 user=%s code=IMAP_CONNECT_FAILED error=%s", username, exc)
        return {"ok": False, "error_code": "IMAP_CONNECT_FAILED", "message": "无法连接 IMAP 服务器"}
    finally:
        if mail:
            try:
                mail.logout()
            except Exception as exc:
                logger.debug("邮箱连接测试退出失败 user=%s error=%s", username, exc)


def _uid_validity(mail) -> str:
    try:
        _name, values = mail.response("UIDVALIDITY")
        if values:
            value = values[-1]
            return value.decode() if isinstance(value, bytes) else str(value)
    except Exception:
        pass
    return "unknown"


def _attachment_candidates(msg) -> list[dict]:
    """Return supported and rejected attachments so every result can be persisted."""
    results = []
    for part in msg.walk():
        disposition = str(part.get("Content-Disposition", ""))
        if "attachment" not in disposition:
            continue
        filename_raw = part.get_filename()
        if not filename_raw:
            continue
        filename = _decode_header_value(filename_raw)
        ext = os.path.splitext(filename)[1].lower()
        try:
            payload = part.get_payload(decode=True)
        except Exception:
            continue
        base = {
            "filename": filename,
            "ext": ext,
            "mime_type": part.get_content_type() or "application/octet-stream",
            "data": payload,
        }
        if not payload:
            results.append({**base, "initial_status": "empty"})
            continue
        if len(payload) > _MAX_ATTACHMENT_SIZE:
            results.append({**base, "initial_status": "too_large"})
            continue
        if ext == ".zip":
            try:
                with zipfile.ZipFile(BytesIO(payload)) as archive:
                    for member in archive.namelist():
                        member_ext = os.path.splitext(member)[1].lower()
                        member_data = archive.read(member)
                        status = "ready"
                        if member_ext not in _SUPPORTED_EXTENSIONS:
                            status = "unsupported"
                        elif not member_data:
                            status = "empty"
                        elif len(member_data) > _MAX_ATTACHMENT_SIZE:
                            status = "too_large"
                        results.append(
                            {
                                "filename": member,
                                "ext": member_ext,
                                "mime_type": "application/octet-stream",
                                "data": member_data,
                                "initial_status": status,
                            }
                        )
            except zipfile.BadZipFile:
                results.append({**base, "initial_status": "parse_failed"})
            continue
        results.append({**base, "initial_status": "ready" if ext in _SUPPORTED_EXTENSIONS else "unsupported"})
    return results


def _remote_attachment_specs(msg) -> list[dict]:
    """Extract QQ/WeCom cloud-attachment links embedded in HTML mail bodies.

    QQ's IMAP representation for large attachments is often ``multipart/alternative``
    with no MIME attachment part. The HTML contains one ``qqmailbgattach`` span per
    file; only those links are accepted, rather than arbitrary URLs from the body.
    """
    specs = []
    seen = set()
    html_payloads = []
    for part in msg.walk() if msg.is_multipart() else [msg]:
        if part.get_content_type() != "text/html":
            continue
        try:
            payload = part.get_payload(decode=True) or b""
            charset = part.get_content_charset() or "utf-8"
            html_payloads.append(payload.decode(charset, errors="replace"))
        except Exception:
            continue
    pattern = re.compile(
        r"<span[^>]*class=[\"']qqmailbgattach[\"'][^>]*downloadlink=[\"']([^\"']+)[\"'][^>]*>(.*?)</span>",
        re.IGNORECASE | re.DOTALL,
    )
    for html in html_payloads:
        for match in pattern.finditer(html):
            raw_url = unescape(match.group(1)).strip()
            parsed = urlparse(raw_url)
            host = (parsed.hostname or "").lower().rstrip(".")
            query = parse_qs(parsed.query)
            if host not in _REMOTE_ATTACHMENT_HOSTS or "code" not in query:
                continue
            key = (query.get("key") or query.get("k") or [""])[0]
            code = query["code"][0]
            if not key:
                continue
            # Avoid logging or retaining the long token-bearing URL. Rebuild it at
            # download time from validated query fields.
            dedup_key = (host, key, code)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)
            body = unescape(match.group(2))
            labels = re.findall(r"<a[^>]*>([^<]*\.[A-Za-z0-9]{2,8})</a>", body, re.IGNORECASE)
            label = next((re.sub(r"\s+", " ", value).strip() for value in labels if value.strip()), "")
            specs.append({"host": host, "key": key, "code": code, "filename": label})
    return specs


def _download_remote_attachment(spec: dict) -> dict:
    """Download one whitelisted QQ cloud attachment using its binary endpoint."""
    started = time.perf_counter()
    filename = _log_text(spec.get("filename") or "attachment")
    params = {"func": "4", "key": spec["key"], "code": spec["code"]}
    url = urlunparse(("https", spec["host"], "/ftn/download", "", urlencode(params), ""))
    session = None
    try:
        response = None
        session = requests.Session()
        session.headers.update({"User-Agent": "Mozilla/5.0 (ai-hr-email-sync/1.0)"})
        current_url = url
        for _ in range(3):
            parsed_url = urlparse(current_url)
            if parsed_url.scheme != "https" or not _is_allowed_remote_host(parsed_url.hostname or ""):
                raise ValueError("REMOTE_ATTACHMENT_REDIRECT_BLOCKED")
            response = session.get(
                current_url,
                timeout=_REMOTE_ATTACHMENT_TIMEOUT,
                stream=True,
                allow_redirects=False,
            )
            if response.status_code not in {301, 302, 303, 307, 308}:
                break
            location = response.headers.get("Location")
            response.close()
            if not location:
                raise RuntimeError("REMOTE_ATTACHMENT_REDIRECT_MISSING")
            current_url = urljoin(current_url, location)
        if response is None:
            raise RuntimeError("REMOTE_ATTACHMENT_EMPTY_RESPONSE")
        try:
            if response.status_code != 200:
                raise RuntimeError(f"HTTP_{response.status_code}")
            content_type = (response.headers.get("Content-Type") or "").split(";", 1)[0].lower()
            content_length = int(response.headers.get("Content-Length") or 0)
            if content_length > _MAX_REMOTE_ATTACHMENT_SIZE:
                raise ValueError("REMOTE_ATTACHMENT_TOO_LARGE")
            chunks = []
            total = 0
            for chunk in response.iter_content(chunk_size=256 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > _MAX_REMOTE_ATTACHMENT_SIZE:
                    raise ValueError("REMOTE_ATTACHMENT_TOO_LARGE")
                chunks.append(chunk)
            data = b"".join(chunks)
            header = response.headers.get("Content-Disposition") or ""
            filename_match = re.search(r"filename\*=UTF-8''([^;]+)", header, re.IGNORECASE)
            if filename_match:
                filename = unquote(filename_match.group(1)).strip() or filename
            elif not os.path.splitext(filename)[1]:
                simple_match = re.search(r"filename=\"?([^\";]+)", header, re.IGNORECASE)
                if simple_match:
                    filename = simple_match.group(1).strip()
            ext = os.path.splitext(filename)[1].lower()
            if ext not in _SUPPORTED_EXTENSIONS:
                ext_by_type = {"application/pdf": ".pdf"}
                ext = ext_by_type.get(content_type, ext)
                if ext and not os.path.splitext(filename)[1]:
                    filename = f"{filename}{ext}"
            elapsed_ms = round((time.perf_counter() - started) * 1000)
            logger.info(
                "云附件下载完成 host=%s filename=%s size=%s content_type=%s elapsed_ms=%s",
                spec["host"],
                _log_text(filename),
                len(data),
                content_type,
                elapsed_ms,
            )
            return {
                "filename": filename,
                "ext": ext,
                "mime_type": content_type or "application/octet-stream",
                "data": data,
                "initial_status": "ready" if data and ext in _SUPPORTED_EXTENSIONS else "unsupported",
                "remote": True,
            }
        finally:
            response.close()
            session.close()
    except Exception as exc:
        if session is not None:
            session.close()
        elapsed_ms = round((time.perf_counter() - started) * 1000)
        logger.warning(
            "云附件下载失败 host=%s filename=%s code=%s elapsed_ms=%s",
            spec["host"],
            filename,
            _log_text(str(exc)),
            elapsed_ms,
        )
        return {
            "filename": filename,
            "ext": os.path.splitext(filename)[1].lower(),
            "mime_type": "application/octet-stream",
            "data": b"",
            "initial_status": "remote_download_failed",
            "remote": True,
        }


_RESUME_METADATA_RE = re.compile(r"(?:简历|个人履历|resume|curriculum\s+vitae|\bcv\b)", re.IGNORECASE)
_NON_RESUME_METADATA_RE = re.compile(
    r"(?:录用通知|入职通知|offer|隐私政策|privacy\s+policy|发票|对账单|合同|毕业论文|设计论文)",
    re.IGNORECASE,
)
_RESUME_CONTENT_SIGNALS = (
    re.compile(r"(?:工作经历|工作经验|任职经历|职业经历|employment|work\s+experience)", re.IGNORECASE),
    re.compile(r"(?:项目经历|项目经验|项目介绍|project\s+experience)", re.IGNORECASE),
    re.compile(r"(?:教育经历|教育背景|毕业院校|最高学历|education)", re.IGNORECASE),
    re.compile(r"(?:专业技能|技能特长|核心技能|skills?)", re.IGNORECASE),
    re.compile(r"(?:求职意向|目标岗位|期望职位|应聘岗位|career\s+objective)", re.IGNORECASE),
    re.compile(r"(?:自我评价|个人优势|个人简介|profile|summary)", re.IGNORECASE),
    re.compile(
        r"(?:手机号|联系电话|电子邮箱|\bemail\b|\bphone\b|1[3-9]\d{9}|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,})", re.IGNORECASE
    ),
)


def _looks_like_resume_document(subject: str, filename: str, text: str) -> bool:
    """Use conservative document signals before spending an LLM call on an attachment."""
    metadata = f"{subject}\n{filename}"
    explicit_resume = bool(_RESUME_METADATA_RE.search(metadata))
    if _NON_RESUME_METADATA_RE.search(metadata) and not explicit_resume:
        return False
    signal_count = sum(bool(pattern.search(text)) for pattern in _RESUME_CONTENT_SIGNALS)
    if signal_count >= 2 or (explicit_resume and signal_count >= 1):
        return True
    # Some PDFs use custom glyph maps: extracted Chinese words such as “工作经历”
    # are broken, while phone/email and year ranges remain readable. Treat that
    # common resume shape as a candidate and leave the final judgment to the LLM.
    has_contact = bool(_RESUME_CONTENT_SIGNALS[-1].search(text))
    year_count = len(re.findall(r"(?:19|20)\d{2}", text))
    return has_contact and year_count >= 2 and len(text) >= 500


def _safe_received_at(msg) -> str:
    try:
        parsed = parsedate_to_datetime(msg.get("Date", ""))
        if parsed:
            return parsed.strftime("%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError, OverflowError):
        pass
    return ""


def _persist_source(
    tenant_id: str,
    resume_id: str,
    account_id: str,
    message_id: str,
    attachment_id: str,
    sender_email: str,
    received_at: str,
) -> None:
    from app.db import get_db

    conn = get_db()
    conn.execute(
        """INSERT IGNORE INTO resume_sources
           (id, tenant_id, resume_id, source_type, email_account_id, message_record_id,
            attachment_id, sender_email, received_at)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (
            f"src_{uuid.uuid4().hex}",
            tenant_id,
            resume_id,
            "email",
            account_id,
            message_id,
            attachment_id,
            sender_email,
            received_at,
        ),
    )
    conn.commit()


def _update_attachment(attachment_id: str, status: str, **values) -> None:
    from app.db import get_db

    allowed = {"resume_id", "duplicate_resume_id", "error_code", "error_message", "storage_key"}
    data = {key: value for key, value in values.items() if key in allowed}
    data["status"] = status
    data["processed_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    assignments = ", ".join(f"{key}=%s" for key in data)
    get_db().execute(
        f"UPDATE email_sync_attachments SET {assignments} WHERE id=%s", list(data.values()) + [attachment_id]
    )
    get_db().commit()


def _mark_deleted_attachment_recovered(message_record_id: str, sha256: str, current_id: str) -> None:
    """Close deleted attachment markers after the source was restored or re-linked."""
    from app.db import get_db

    conn = get_db()
    conn.execute(
        """UPDATE email_sync_attachments
              SET status='recovered', processed_at=NOW()
            WHERE message_record_id=%s AND sha256=%s AND id<>%s AND status='deleted_resume'""",
        (message_record_id, sha256, current_id),
    )
    conn.commit()


def _finalize_run(run_id: str, account_id: str, top_error: tuple[str, str] | None = None) -> dict:
    from app.db import get_db

    conn = get_db()
    current = conn.execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone()
    # The scheduler may have already written the authoritative lease-expired
    # failure.  Never let a cancelled worker overwrite that terminal state.
    if current and current["status"] not in {"queued", "running"}:
        conn.execute(
            "DELETE FROM email_sync_leases WHERE email_account_id=%s AND run_id=%s",
            (account_id, run_id),
        )
        conn.commit()
        _run_started_monotonic.pop(run_id, None)
        return dict(current)
    counts = conn.execute(
        """SELECT
             COUNT(*) AS attachment_total,
             SUM(CASE WHEN a.status='imported' THEN 1 ELSE 0 END) AS imported_count,
             SUM(CASE WHEN a.status IN ('duplicate_file','duplicate_resume') THEN 1 ELSE 0 END) AS deduped_count,
             SUM(CASE WHEN a.status='suspect_duplicate' THEN 1 ELSE 0 END) AS suspect_count,
             SUM(CASE WHEN a.status IN ('unsupported','too_large','empty') THEN 1 ELSE 0 END) AS skipped_count,
             SUM(CASE WHEN a.status IN ('parse_failed','failed','remote_download_failed') THEN 1 ELSE 0 END) AS failed_count
           FROM email_sync_attachments a JOIN email_sync_messages m ON m.id=a.message_record_id
           WHERE m.run_id=%s""",
        (run_id,),
    ).fetchone()
    values = {key: int(counts[key] or 0) for key in counts.keys()}
    if top_error:
        status = "failed"
        error_code, error_message = top_error
    elif values["failed_count"] and (values["imported_count"] or values["deduped_count"]):
        status, error_code, error_message = "partial_success", "", ""
    elif values["failed_count"]:
        status, error_code, error_message = "failed", "ATTACHMENT_PROCESS_FAILED", "部分附件处理失败"
    else:
        status, error_code, error_message = "succeeded", "", ""
    if error_message:
        # 让错误信息自带账户身份，前端/日志无需再 JOIN email_accounts
        account_row = conn.execute(
            "SELECT email_address, username FROM email_accounts WHERE id=%s", (account_id,)
        ).fetchone()
        account_email = (account_row["email_address"] or account_row["username"]) if account_row else account_id
        error_message = f"{account_email}：{error_message}"
    message_counts = conn.execute(
        "SELECT COUNT(*) AS total FROM email_sync_messages WHERE run_id=%s", (run_id,)
    ).fetchone()
    conn.execute(
        """UPDATE email_sync_runs SET status=%s, finished_at=NOW(), attachment_total=%s,
           imported_count=%s, deduped_count=%s, suspect_count=%s, skipped_count=%s, failed_count=%s,
           message_total=%s, message_new=%s, error_code=%s, error_message=%s WHERE id=%s""",
        (
            status,
            values["attachment_total"],
            values["imported_count"],
            values["deduped_count"],
            values["suspect_count"],
            values["skipped_count"],
            values["failed_count"],
            int(message_counts["total"] or 0),
            int(message_counts["total"] or 0),
            error_code,
            error_message[:500],
            run_id,
        ),
    )
    conn.execute(
        "UPDATE email_accounts SET last_sync_at=NOW(), updated_at=NOW() WHERE id=%s",
        (account_id,),
    )
    conn.execute(
        "DELETE FROM email_sync_leases WHERE email_account_id=%s AND run_id=%s",
        (account_id, run_id),
    )
    conn.commit()
    finalized = dict(conn.execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone())
    started_monotonic = _run_started_monotonic.pop(run_id, None)
    elapsed_ms = round((time.perf_counter() - started_monotonic) * 1000) if started_monotonic else -1
    log_method = logger.error if status == "failed" else logger.info
    log_method(
        "同步任务结束 run=%s account=%s status=%s messages=%s attachments=%s imported=%s deduped=%s "
        "suspect=%s skipped=%s failed=%s error_code=%s error=%s elapsed_ms=%s",
        run_id,
        account_id,
        status,
        finalized["message_total"],
        finalized["attachment_total"],
        finalized["imported_count"],
        finalized["deduped_count"],
        finalized["suspect_count"],
        finalized["skipped_count"],
        finalized["failed_count"],
        error_code or "-",
        _log_text(error_message) or "-",
        elapsed_ms,
    )
    return finalized


def _insert_sync_message_record(conn, values: tuple) -> None:
    conn.execute(
        """INSERT INTO email_sync_messages
           (id, tenant_id, run_id, email_account_id, folder, uid_validity, uid,
            message_id, subject, sender_name, sender_email, received_at, status,
            error_code, error_message)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (*values, "", ""),
    )


def _insert_sync_attachment_record(conn, values: tuple) -> None:
    conn.execute(
        """INSERT INTO email_sync_attachments
           (id, tenant_id, message_record_id, filename, extension, mime_type,
            size_bytes, sha256, status, error_code, error_message)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (*values, "", ""),
    )


def _insert_recovery_records(
    conn,
    account: dict,
    run_id: str,
    folder: str,
    uid_validity: str,
    uid_text: str,
    original_message_id: str,
    message: email.message.Message,
    sender_name: str,
    sender_email: str,
    received_at: str,
) -> tuple[str, str]:
    """Create current-run recovery detail without mutating the original message."""
    recovery_message_id = f"msg_recovery_{uuid.uuid4().hex}"
    _insert_sync_message_record(
        conn,
        (
            recovery_message_id,
            account["tenant_id"],
            run_id,
            account["id"],
            folder,
            uid_validity,
            f"{uid_text}:recovery:{run_id}",
            str(message.get("Message-ID", "")),
            _decode_header_value(message.get("Subject", "")),
            sender_name,
            sender_email,
            received_at,
            "processing",
        ),
    )
    recovery_id = f"recovery_{uuid.uuid4().hex}"
    conn.execute(
        """INSERT INTO email_sync_recoveries
           (id, tenant_id, email_account_id, run_id,
            original_message_id, recovery_message_id, uid_validity, uid, status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (
            recovery_id,
            account["tenant_id"],
            account["id"],
            run_id,
            original_message_id,
            recovery_message_id,
            uid_validity,
            uid_text,
            "processing",
        ),
    )
    return recovery_id, recovery_message_id


async def execute_sync_run(run_id: str) -> dict:
    """Execute one persisted run. The HTTP endpoint only creates and dispatches it."""
    from app.db import get_db
    from app.email_accounts import decrypt_credential
    from app.infrastructure.cache.redis_client import get_redis_client

    conn = get_db()
    run_row = conn.execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone()
    if not run_row:
        logger.error("同步任务不存在 run=%s", run_id)
        return {"status": "missing", "run_id": run_id}
    run = dict(run_row)
    account_id = run["email_account_id"]
    current_task = asyncio.current_task()
    if current_task is not None and run_id not in _sync_tasks_by_run_id:
        _sync_tasks_by_run_id[run_id] = current_task
        tracked_here = True
    else:
        tracked_here = False
    _run_started_monotonic[run_id] = time.perf_counter()
    logger.info(
        "开始执行同步任务 run=%s account=%s trigger=%s actor=%s",
        run_id,
        account_id,
        run["trigger_type"],
        run["triggered_by"],
    )
    lock = _account_locks.setdefault(account_id, asyncio.Lock())
    if lock.locked():
        logger.warning("同步任务被本地锁拒绝 run=%s account=%s", run_id, account_id)
        result = _finalize_run(run_id, account_id, ("EMAIL_SYNC_ALREADY_RUNNING", "邮箱已有运行中任务"))
        if tracked_here and _sync_tasks_by_run_id.get(run_id) is current_task:
            _sync_tasks_by_run_id.pop(run_id, None)
        return result

    redis = get_redis_client()
    redis_lock_name = f"lock:email-sync:{account_id}"
    redis_locked = False
    if getattr(redis, "backend", "none") == "redis":
        redis_locked = redis.set(redis_lock_name, run_id, ttl=1800, nx=True)
        if not redis_locked:
            logger.warning("同步任务被 Redis 锁拒绝 run=%s account=%s", run_id, account_id)
            result = _finalize_run(run_id, account_id, ("EMAIL_SYNC_ALREADY_RUNNING", "邮箱已有运行中任务"))
            if tracked_here and _sync_tasks_by_run_id.get(run_id) is current_task:
                _sync_tasks_by_run_id.pop(run_id, None)
            return result

    async with lock:
        mail = None
        lease_task: asyncio.Task | None = None
        try:
            account_row = conn.execute("SELECT * FROM email_accounts WHERE id=%s", (account_id,)).fetchone()
            if not account_row:
                logger.error("同步任务找不到邮箱账户 run=%s account=%s", run_id, account_id)
                return _finalize_run(run_id, account_id, ("EMAIL_ACCOUNT_NOT_FOUND", "邮箱不存在"))
            account = dict(account_row)
            folder = ACCOUNT_EMAIL_FOLDER
            credential = decrypt_credential(account["credential_ciphertext"])
            conn.execute(
                "UPDATE email_sync_runs SET status='running', started_at=NOW() WHERE id=%s AND status='queued'",
                (run_id,),
            )
            conn.commit()
            _assert_sync_run_active(run_id, account_id)
            lease_task = asyncio.create_task(_renew_sync_lease_loop(account_id, run_id))
            logger.info(
                "连接 IMAP run=%s account=%s user=%s host=%s port=%s security=%s folder=%s credential=<redacted>",
                run_id,
                account_id,
                _mask_email(account["username"]),
                account["imap_host"],
                account["imap_port"],
                account["security_mode"],
                folder,
            )
            mail = await asyncio.to_thread(_imap_connection, account, credential)
            logger.debug("IMAP 网络连接成功 run=%s account=%s", run_id, account_id)
            try:
                await asyncio.to_thread(mail.login, account["username"], credential)
            except imaplib.IMAP4.error as exc:
                logger.error(
                    "IMAP 登录失败(疑似授权码错误) run=%s account=%s user=%s error=%s",
                    run_id,
                    account_id,
                    _mask_email(account["username"]),
                    exc,
                )
                return _finalize_run(
                    run_id,
                    account_id,
                    ("IMAP_AUTH_FAILED", "IMAP 登录失败，请检查该邮箱的授权码是否正确"),
                )
            logger.debug("IMAP 登录成功 run=%s account=%s", run_id, account_id)
            selected, _ = await asyncio.to_thread(mail.select, folder)
            if selected != "OK":
                logger.error("IMAP 文件夹选择失败 run=%s account=%s folder=%s", run_id, account_id, folder)
                return _finalize_run(run_id, account_id, ("IMAP_FOLDER_NOT_FOUND", "邮件文件夹不可读"))
            uid_validity = _uid_validity(mail)
            since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%d-%b-%Y")
            search_status, messages = await asyncio.to_thread(mail.uid, "SEARCH", None, f'(SINCE "{since}")')
            if search_status != "OK":
                logger.error("IMAP 邮件搜索失败 run=%s account=%s since=%s", run_id, account_id, since)
                return _finalize_run(run_id, account_id, ("IMAP_SEARCH_FAILED", "IMAP 搜索失败"))
            uid_list = messages[0].split() if messages and messages[0] else []
            logger.info(
                "IMAP 邮件搜索完成 run=%s account=%s folder=%s since=%s scanned=%s uid_validity=%s",
                run_id,
                account_id,
                folder,
                since,
                len(uid_list),
                uid_validity,
            )

            for uid in uid_list:
                _assert_sync_run_active(run_id, account_id)
                if redis_locked and redis.get(redis_lock_name) == run_id:
                    redis.set(redis_lock_name, run_id, ttl=1800)
                uid_text = uid.decode() if isinstance(uid, bytes) else str(uid)
                known = conn.execute(
                    "SELECT id FROM email_sync_messages WHERE email_account_id=%s AND folder=%s AND uid_validity=%s AND uid=%s",
                    (account_id, folder, uid_validity, uid_text),
                ).fetchone()
                if known:
                    # A deleted talent-pool resume must be recoverable from its
                    # original mailbox message.  Keep normal UID de-duplication,
                    # but reopen messages whose attachment provenance no longer
                    # resolves to a live resume (including legacy stale rows).
                    recoverable = conn.execute(
                        """SELECT 1
                             FROM email_sync_attachments a
                             JOIN email_sync_messages m ON m.id=a.message_record_id
                        LEFT JOIN resumes r1 ON r1.id=a.resume_id
                        LEFT JOIN resumes r2 ON r2.id=a.duplicate_resume_id
                            WHERE m.email_account_id=%s AND m.folder=%s
                              AND m.uid_validity=%s AND m.uid=%s
                              AND (
                                   a.status='deleted_resume'
                                OR (a.status='imported' AND a.resume_id<>'' AND r1.id IS NULL)
                                OR (a.status IN ('duplicate_file','duplicate_resume')
                                    AND a.duplicate_resume_id<>'' AND r2.id IS NULL)
                              )
                              AND NOT EXISTS (
                                  SELECT 1 FROM email_sync_recoveries rec
                                   WHERE rec.original_message_id=m.id
                                     AND rec.status IN ('completed','partial_success')
                              )
                            LIMIT 1""",
                        (account_id, folder, uid_validity, uid_text),
                    ).fetchone()
                    if not recoverable:
                        logger.debug("跳过已处理邮件 run=%s account=%s uid=%s", run_id, account_id, uid_text)
                        continue
                    logger.info("发现已删除简历，重新处理邮件 run=%s account=%s uid=%s", run_id, account_id, uid_text)
                fetch_started = time.perf_counter()
                fetch_status, msg_data = await asyncio.to_thread(mail.uid, "FETCH", uid, "(RFC822)")
                _assert_sync_run_active(run_id, account_id)
                fetch_elapsed_ms = round((time.perf_counter() - fetch_started) * 1000)
                if fetch_status != "OK" or not msg_data or not isinstance(msg_data[0], tuple):
                    logger.warning(
                        "邮件下载失败 run=%s account=%s uid=%s fetch_status=%s elapsed_ms=%s",
                        run_id,
                        account_id,
                        uid_text,
                        fetch_status,
                        fetch_elapsed_ms,
                    )
                    continue
                msg = email.message_from_bytes(msg_data[0][1])
                subject = _decode_header_value(msg.get("Subject", ""))
                sender_name, sender_email = parseaddr(_decode_header_value(msg.get("From", "")))
                message_record_id = known["id"] if known and recoverable else f"msg_{uuid.uuid4().hex}"
                recovery_record_id = ""
                original_message_id = ""
                received_at = _safe_received_at(msg)
                logger.info(
                    "处理邮件 run=%s uid=%s subject=%s sender=%s received_at=%s fetch_elapsed_ms=%s",
                    run_id,
                    uid_text,
                    _log_text(subject),
                    _mask_email(sender_email),
                    received_at,
                    fetch_elapsed_ms,
                )
                if known and recoverable:
                    # Keep the original message row and its run ownership intact.
                    # Recovery gets a synthetic message row in the current run.
                    original_message_id = message_record_id
                    recovery_record_id, message_record_id = _insert_recovery_records(
                        conn,
                        account,
                        run_id,
                        folder,
                        uid_validity,
                        uid_text,
                        original_message_id,
                        msg,
                        sender_name,
                        sender_email,
                        received_at,
                    )
                else:
                    _insert_sync_message_record(
                        conn,
                        (
                            message_record_id,
                            account["tenant_id"],
                            run_id,
                            account_id,
                            folder,
                            uid_validity,
                            uid_text,
                            str(msg.get("Message-ID", "")),
                            subject,
                            sender_name,
                            sender_email,
                            received_at,
                            "processing",
                        ),
                    )
                conn.commit()
                _assert_sync_run_active(run_id, account_id)
                # QQ/企业微信的大附件在 IMAP 中通常只表现为 HTML 云附件链接。
                # 下载后与标准 MIME 附件合并，后续仍按“每个附件一条流水线”处理。
                candidates = [item for item in _attachment_candidates(msg) if item["ext"] in _SUPPORTED_EXTENSIONS]
                remote_specs = _remote_attachment_specs(msg)
                remote_candidates = []
                remote_rejected = []
                for spec in remote_specs:
                    remote_item = await asyncio.to_thread(_download_remote_attachment, spec)
                    if remote_item["initial_status"] == "ready" and remote_item["ext"] in _SUPPORTED_EXTENSIONS:
                        remote_candidates.append(remote_item)
                    else:
                        remote_rejected.append(remote_item)
                for item in remote_rejected:
                    _assert_sync_run_active(run_id, account_id)
                    attachment_id = f"att_{uuid.uuid4().hex}"
                    sha256 = hashlib.sha256(item["data"]).hexdigest() if item["data"] else ""
                    _insert_sync_attachment_record(
                        conn,
                        (
                            attachment_id,
                            account["tenant_id"],
                            message_record_id,
                            item["filename"],
                            item["ext"],
                            item["mime_type"],
                            len(item["data"]),
                            sha256,
                            item["initial_status"],
                        ),
                    )
                if remote_rejected:
                    conn.commit()
                if remote_specs:
                    logger.info(
                        "云附件发现完成 run=%s uid=%s detected=%s downloaded=%s",
                        run_id,
                        uid_text,
                        len(remote_specs),
                        len(remote_candidates),
                    )
                candidates.extend(remote_candidates)
                if not candidates:
                    _assert_sync_run_active(run_id, account_id)
                    skip_reason = "remote_attachment_download_failed" if remote_specs else "no_supported_attachment"
                    logger.info("邮件已跳过 run=%s uid=%s reason=%s", run_id, uid_text, skip_reason)
                    conn.execute(
                        "UPDATE email_sync_messages SET status='skipped', skip_reason=%s, updated_at=NOW() WHERE id=%s",
                        (skip_reason, message_record_id),
                    )
                    conn.commit()
                    continue

                resume_candidates = []
                for item in candidates:
                    _assert_sync_run_active(run_id, account_id)
                    text_content = ""
                    extract_elapsed_ms = 0
                    if item["initial_status"] == "ready":
                        extract_started = time.perf_counter()
                        try:
                            text_content = await asyncio.to_thread(_extract_text_from_bytes, item["data"], item["ext"])
                        except Exception as exc:
                            item["initial_status"] = "parse_failed"
                            logger.warning(
                                "附件文本提取失败 run=%s uid=%s filename=%s error=%s",
                                run_id,
                                uid_text,
                                _log_text(item["filename"]),
                                _log_text(str(exc)),
                            )
                        extract_elapsed_ms = round((time.perf_counter() - extract_started) * 1000)
                        logger.debug(
                            "附件文本提取完成 run=%s uid=%s filename=%s text_chars=%s elapsed_ms=%s",
                            run_id,
                            uid_text,
                            _log_text(item["filename"]),
                            len(text_content),
                            extract_elapsed_ms,
                        )
                    if _looks_like_resume_document(subject, item["filename"], text_content):
                        item["text_content"] = text_content
                        item["extract_elapsed_ms"] = extract_elapsed_ms
                        resume_candidates.append(item)
                        logger.debug(
                            "附件通过简历筛选 run=%s uid=%s filename=%s size=%s",
                            run_id,
                            uid_text,
                            _log_text(item["filename"]),
                            len(item["data"]),
                        )
                    else:
                        logger.debug(
                            "附件未通过简历筛选 run=%s uid=%s filename=%s",
                            run_id,
                            uid_text,
                            _log_text(item["filename"]),
                        )
                if not resume_candidates:
                    _assert_sync_run_active(run_id, account_id)
                    logger.info(
                        "邮件已跳过 run=%s uid=%s reason=non_resume supported_attachments=%s",
                        run_id,
                        uid_text,
                        len(candidates),
                    )
                    conn.execute(
                        "UPDATE email_sync_messages SET status='skipped', skip_reason='non_resume', updated_at=NOW() WHERE id=%s",
                        (message_record_id,),
                    )
                    conn.commit()
                    continue

                message_failed = False
                for item in resume_candidates:
                    _assert_sync_run_active(run_id, account_id)
                    attachment_id = f"att_{uuid.uuid4().hex}"
                    sha256 = hashlib.sha256(item["data"]).hexdigest() if item["data"] else ""
                    _insert_sync_attachment_record(
                        conn,
                        (
                            attachment_id,
                            account["tenant_id"],
                            message_record_id,
                            item["filename"],
                            item["ext"],
                            item["mime_type"],
                            len(item["data"]),
                            sha256,
                            item["initial_status"],
                        ),
                    )
                    conn.commit()
                    if item["initial_status"] != "ready":
                        _assert_sync_run_active(run_id, account_id)
                        logger.warning(
                            "附件无法处理 run=%s uid=%s attachment=%s filename=%s status=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            item["initial_status"],
                        )
                        _update_attachment(attachment_id, item["initial_status"])
                        continue
                    duplicate = conn.execute(
                        """SELECT a.resume_id, a.duplicate_resume_id FROM email_sync_attachments a
                           LEFT JOIN resumes r1 ON r1.id=a.resume_id
                           LEFT JOIN resumes r2 ON r2.id=a.duplicate_resume_id
                           WHERE a.tenant_id=%s AND a.sha256=%s AND a.id<>%s
                           AND a.status IN ('imported','duplicate_file','duplicate_resume')
                           AND ((a.status='imported' AND r1.id IS NOT NULL)
                                OR (a.status IN ('duplicate_file','duplicate_resume')
                                    AND r2.id IS NOT NULL))
                           ORDER BY a.created_at LIMIT 1""",
                        (account["tenant_id"], sha256, attachment_id),
                    ).fetchone()
                    if duplicate:
                        _assert_sync_run_active(run_id, account_id)
                        resume_id = duplicate["resume_id"] or duplicate["duplicate_resume_id"]
                        logger.info(
                            "附件文件去重 run=%s uid=%s attachment=%s filename=%s existing_resume=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            resume_id,
                        )
                        _update_attachment(attachment_id, "duplicate_file", duplicate_resume_id=resume_id)
                        _persist_source(
                            account["tenant_id"],
                            resume_id,
                            account_id,
                            message_record_id,
                            attachment_id,
                            sender_email,
                            received_at,
                        )
                        if original_message_id:
                            _mark_deleted_attachment_recovered(original_message_id, sha256, attachment_id)
                        continue
                    from app.infrastructure.config import settings
                    from app.media_storage import get_media_storage, join_storage_key

                    storage = get_media_storage()
                    _assert_sync_run_active(run_id, account_id)
                    storage_key = join_storage_key(
                        settings.oss_resume_prefix,
                        "email",
                        account["tenant_id"],
                        account_id,
                        f"{sha256}{item['ext']}",
                    )
                    await asyncio.to_thread(
                        storage.write,
                        storage_key,
                        item["data"],
                        item["mime_type"],
                    )
                    logger.debug(
                        "附件已保存 run=%s uid=%s attachment=%s filename=%s storage=%s",
                        run_id,
                        uid_text,
                        attachment_id,
                        _log_text(item["filename"]),
                        storage_key,
                    )
                    text_content = item.get("text_content", "")
                    if not text_content.strip():
                        _assert_sync_run_active(run_id, account_id)
                        logger.warning(
                            "附件文本为空 run=%s uid=%s attachment=%s filename=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                        )
                        _update_attachment(
                            attachment_id,
                            "empty",
                            storage_key=storage_key,
                            error_code="ATTACHMENT_EMPTY",
                            error_message="附件无可用文本",
                        )
                        continue
                    from app import services

                    logger.info(
                        "开始大模型解析简历 run=%s uid=%s attachment=%s filename=%s text_chars=%s "
                        "extract_elapsed_ms=%s requested_model=%s timeout_seconds=90",
                        run_id,
                        uid_text,
                        attachment_id,
                        _log_text(item["filename"]),
                        len(text_content),
                        item.get("extract_elapsed_ms", 0),
                        os.getenv("RESUME_PARSE_MODEL", "auto") or "auto",
                    )
                    parse_started = time.perf_counter()
                    try:
                        parsed = await services.parse_resume_with_llm(text_content, item["filename"])
                    except Exception as exc:
                        parsed = None
                        logger.exception(
                            "大模型解析异常 run=%s uid=%s attachment=%s filename=%s error=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            _log_text(str(exc)),
                        )
                    parse_elapsed_ms = round((time.perf_counter() - parse_started) * 1000)
                    logger.info(
                        "大模型解析结束 run=%s uid=%s attachment=%s filename=%s success=%s elapsed_ms=%s",
                        run_id,
                        uid_text,
                        attachment_id,
                        _log_text(item["filename"]),
                        bool(parsed),
                        parse_elapsed_ms,
                    )
                    if not parsed:
                        _assert_sync_run_active(run_id, account_id)
                        message_failed = True
                        logger.error(
                            "简历解析失败 run=%s uid=%s attachment=%s filename=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                        )
                        _update_attachment(
                            attachment_id,
                            "parse_failed",
                            storage_key=storage_key,
                            error_code="RESUME_PARSE_FAILED",
                            error_message="简历解析失败",
                        )
                        continue
                    _assert_sync_run_active(run_id, account_id)
                    candidate_email = str(parsed.get("email") or "").strip()
                    parsed.update(
                        {
                            "source": f"email:{account_id}:{item['filename']}",
                            "source_channel": "email",
                            "source_type": "email",
                            "source_account_id": account_id,
                            "source_message_id": message_record_id,
                            "source_attachment_id": attachment_id,
                            "owner_user_id": account["owner_user_id"],
                            "candidate_email": candidate_email,
                            "sender_email": sender_email,
                            "email": candidate_email,
                            "content_sha256": hashlib.sha256(
                                re.sub(r"\s+", "", text_content).encode("utf-8")
                            ).hexdigest(),
                            "storage_backend": storage.backend,
                            "storage_key": storage_key,
                            "original_filename": item["filename"],
                        }
                    )
                    _assert_sync_run_active(run_id, account_id)
                    result = save_resume(parsed, tenant_id=account["tenant_id"])
                    _assert_sync_run_active(run_id, account_id)
                    if result.get("skipped"):
                        message_failed = True
                        logger.error(
                            "简历入库失败 run=%s uid=%s attachment=%s filename=%s reason=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            _log_text(str(result.get("reason") or "unknown")),
                        )
                        _update_attachment(
                            attachment_id,
                            "failed",
                            storage_key=storage_key,
                            error_code="RESUME_SAVE_FAILED",
                            error_message=str(result.get("reason") or "入库失败"),
                        )
                        continue
                    if result.get("duplicate"):
                        resume_id = result.get("existing_id", "")
                        logger.info(
                            "简历内容去重 run=%s uid=%s attachment=%s filename=%s existing_resume=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            resume_id,
                        )
                        _update_attachment(
                            attachment_id,
                            "duplicate_resume",
                            storage_key=storage_key,
                            duplicate_resume_id=resume_id,
                        )
                    else:
                        resume_id = result.get("id", "")
                        status = "suspect_duplicate" if result.get("suspect_match") else "imported"
                        logger.info(
                            "简历入库成功 run=%s uid=%s attachment=%s filename=%s resume=%s status=%s",
                            run_id,
                            uid_text,
                            attachment_id,
                            _log_text(item["filename"]),
                            resume_id,
                            status,
                        )
                        _update_attachment(attachment_id, status, storage_key=storage_key, resume_id=resume_id)
                    _persist_source(
                        account["tenant_id"],
                        resume_id,
                        account_id,
                        message_record_id,
                        attachment_id,
                        sender_email,
                        received_at,
                    )
                    if original_message_id:
                        _mark_deleted_attachment_recovered(original_message_id, sha256, attachment_id)
                conn.execute(
                    "UPDATE email_sync_messages SET status=%s, updated_at=NOW() WHERE id=%s",
                    ("partial_success" if message_failed else "completed", message_record_id),
                )
                if recovery_record_id:
                    recovered_resume = conn.execute(
                        """SELECT resume_id FROM email_sync_attachments
                           WHERE message_record_id=%s AND resume_id<>''
                           ORDER BY created_at DESC LIMIT 1""",
                        (message_record_id,),
                    ).fetchone()
                    conn.execute(
                        """UPDATE email_sync_recoveries
                              SET status=%s, recovered_resume_id=%s, updated_at=NOW()
                            WHERE id=%s""",
                        (
                            "partial_success" if message_failed else "completed",
                            (recovered_resume["resume_id"] if recovered_resume else ""),
                            recovery_record_id,
                        ),
                    )
                conn.commit()
                logger.info(
                    "邮件处理完成 run=%s uid=%s status=%s resume_attachments=%s",
                    run_id,
                    uid_text,
                    "partial_success" if message_failed else "completed",
                    len(resume_candidates),
                )
                try:
                    await asyncio.to_thread(mail.uid, "STORE", uid, "+FLAGS", "\\Seen")
                except Exception:
                    pass
            return _finalize_run(run_id, account_id)
        except asyncio.CancelledError:
            logger.warning("同步任务因服务停止被取消 run=%s account=%s", run_id, account_id)
            if not _sync_run_is_active(run_id, account_id):
                row = get_db().execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone()
                return dict(row) if row else {"status": "missing", "run_id": run_id}
            return _finalize_run(run_id, account_id, ("SERVICE_SHUTDOWN", "服务停止，同步任务已取消"))
        except _SyncRunAborted:
            logger.warning("同步任务已被调度器终止 run=%s account=%s", run_id, account_id)
            row = get_db().execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone()
            return dict(row) if row else {"status": "missing", "run_id": run_id}
        except TimeoutError as exc:
            logger.error("同步连接超时 run=%s account=%s error=%s", run_id, account_id, exc)
            return _finalize_run(run_id, account_id, ("IMAP_CONNECT_TIMEOUT", "IMAP 连接超时"))
        except imaplib.IMAP4.error as exc:
            logger.error("同步读取失败 run=%s account=%s error=%s", run_id, account_id, exc)
            return _finalize_run(run_id, account_id, ("IMAP_READ_FAILED", f"IMAP 读取邮件失败：{exc}"))
        except OSError as exc:
            logger.error("同步网络连接失败 run=%s account=%s error=%s", run_id, account_id, exc)
            return _finalize_run(
                run_id,
                account_id,
                ("IMAP_CONNECT_FAILED", "无法连接 IMAP 服务器，请检查邮箱地址与服务器配置"),
            )
        except Exception as exc:
            logger.exception("Mailbox sync run failed: %s", run_id)
            return _finalize_run(run_id, account_id, ("EMAIL_SYNC_FAILED", str(exc)))
        finally:
            if lease_task:
                lease_task.cancel()
                try:
                    await lease_task
                except asyncio.CancelledError:
                    pass
            if mail:
                try:
                    await asyncio.to_thread(mail.logout)
                except asyncio.CancelledError:
                    logger.debug("IMAP 退出因任务取消而中止 run=%s account=%s", run_id, account_id)
                except Exception as exc:
                    logger.debug("IMAP 退出失败 run=%s account=%s error=%s", run_id, account_id, exc)
            if redis_locked:
                redis.delete(redis_lock_name)
            if tracked_here and _sync_tasks_by_run_id.get(run_id) is current_task:
                _sync_tasks_by_run_id.pop(run_id, None)
