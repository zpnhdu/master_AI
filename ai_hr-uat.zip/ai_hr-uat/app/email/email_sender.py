"""SMTP email sender module — send interview invitations and notifications.

Features:
- SMTP_SSL connection (QQ Mail / generic SMTP)
- Retry with exponential backoff
- Connection pooling (single-connection reuse)
- Template rendering with variable substitution
- Rate-limit-safe batch sending with configurable delay
- Structured logging for stability monitoring
"""

import asyncio
import html
import logging
import os
import smtplib
import time
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

DEFAULT_INTERVIEW_INVITE_TEMPLATE = (
    "尊敬的{candidate_name}，您好！\n\n"
    "感谢您应聘{company_name}{role}岗位。经过初步筛选，我们现向您发出面试邀请。\n\n"
    "面试方式：{method}\n"
    "面试链接：{interview_url}\n"
    "链接有效期：{expires_at}\n\n"
    "请点击上方链接完成面试。如有任何问题，请随时联系我们。\n\n"
    "祝好！\n{company_name}招聘团队"
)

# ── SMTP 配置 ───────────────────────────────────────────────────
# Compatibility values for standalone mail utilities/tests. Interview invites
# always pass the current user's mailbox configuration explicitly; no account
# credentials are stored in source code.
SMTP_HOST = os.getenv("SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT", "465") or 465)
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "").strip()
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM_NAME = os.getenv("EMAIL_FROM_NAME", "锅圈食汇招聘团队")

# ── 重试配置 ─────────────────────────────────────────────────────

MAX_RETRIES = 3
RETRY_BASE_DELAY = 2.0  # 秒，指数退避间隔为 2→4→8
BATCH_DELAY = 1.5  # 批量发送的间隔秒数，用于避免触发限流


# ── 数据类 ───────────────────────────────────────────────────────


@dataclass
class SendResult:
    """Result of a single email send attempt."""

    email: str
    success: bool
    error: str = ""
    retries: int = 0
    elapsed_ms: float = 0.0


@dataclass
class BatchResult:
    """Aggregate result of a batch send operation."""

    total: int = 0
    success: int = 0
    failed: int = 0
    results: list[SendResult] = field(default_factory=list)
    total_elapsed_ms: float = 0.0

    @property
    def success_rate(self) -> float:
        return self.success / self.total if self.total > 0 else 0.0


# ── 连接管理 ─────────────────────────────────────────────────────

_connection_lock = asyncio.Lock()
_shared_connections: dict[tuple, tuple[object, float]] = {}
_CONNECTION_MAX_AGE = 300  # 连接使用 5 分钟后重新建立


def _smtp_settings(config: Optional[dict]) -> dict:
    values = config or {}
    return {
        "host": str(values.get("host") or SMTP_HOST).strip(),
        "port": int(values.get("port") or SMTP_PORT),
        "security": str(values.get("security") or "ssl").strip().lower(),
        "username": str(values.get("username") or SMTP_USERNAME).strip(),
        "from_email": str(values.get("from_email") or values.get("username") or SMTP_USERNAME).strip(),
        "password": str(values.get("password") or SMTP_PASSWORD),
        "from_name": str(values.get("from_name") or SMTP_FROM_NAME),
    }


def _validate_smtp_settings(settings: dict) -> None:
    missing = [key for key in ("host", "username", "password") if not str(settings.get(key) or "").strip()]
    if missing:
        raise ValueError("SMTP 配置不完整，请在用户与权限中完善邮箱服务商、SMTP 服务器和授权码")


async def _get_connection(config: Optional[dict] = None, check_health: bool = True):
    """Get a connection pooled by the complete SMTP account configuration."""
    settings = _smtp_settings(config)
    key = (settings["host"], settings["port"], settings["security"], settings["username"])

    async with _connection_lock:
        now = time.monotonic()
        entry = _shared_connections.get(key)
        if entry is None or (now - entry[1] > _CONNECTION_MAX_AGE):
            if entry:
                try:
                    entry[0].quit()
                except Exception:
                    pass
            _shared_connections[key] = (_connect_smtp(settings), now)
        elif check_health:
            # 验证连接是否仍然有效
            try:
                entry[0].noop()
            except Exception:
                try:
                    entry[0].quit()
                except Exception:
                    pass
                _shared_connections[key] = (_connect_smtp(settings), now)

    return _shared_connections[key][0]


def _connect_smtp(config: Optional[dict] = None):
    settings = _smtp_settings(config)
    security = settings["security"]
    if security in {"starttls", "tls"}:
        conn = smtplib.SMTP(settings["host"], settings["port"], timeout=30)
        conn.ehlo()
        conn.starttls()
        conn.ehlo()
    elif security in {"none", "plain", ""}:
        conn = smtplib.SMTP(settings["host"], settings["port"], timeout=30)
    else:
        conn = smtplib.SMTP_SSL(settings["host"], settings["port"], timeout=30)
    conn.login(settings["username"], settings["password"])
    return conn


def close_connection():
    """Close the shared SMTP connection (call on shutdown)."""
    for conn, _ in list(_shared_connections.values()):
        try:
            conn.quit()
        except Exception:
            pass
    _shared_connections.clear()


# ── 模板渲染 ─────────────────────────────────────────────────────


def render_template(template: str, variables: dict) -> str:
    """Render a template string with {variable} substitution.

    Args:
        template: Template string with {key} placeholders
        variables: Dict of variable name → value

    Returns:
        Rendered string with all known variables replaced.
        Unknown placeholders are left as-is.
    """
    result = template
    for key, value in variables.items():
        result = result.replace(f"{{{key}}}", str(value) if value is not None else "")
    return result


def _absolute_public_url(value: str, base_url: str) -> str:
    """Convert company-config asset paths to URLs usable by email clients."""
    value = (value or "").strip()
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value
    return urljoin(f"{base_url.rstrip('/')}/", value.lstrip("/")) if base_url else value


def render_interview_invite_html(content: str, company_config: dict, base_url: str, *, hr_qr_code: str = "") -> str:
    """Wrap the editable invitation text with company branding and the HR's own QR code."""
    config = company_config or {}
    company_name = html.escape(str(config.get("company_name") or "锅圈食汇"))
    logo_url = _absolute_public_url(str(config.get("company_logo") or ""), base_url)
    website = _absolute_public_url(str(config.get("company_website") or ""), base_url)
    qr_code_url = _absolute_public_url(str(hr_qr_code or ""), base_url)
    company_intro = html.escape(str(config.get("company_intro") or "")).replace("\n", "<br />")
    brand_color = html.escape(str(config.get("brand_color") or "#16A34A"))
    logo_block = (
        f'<img src="{html.escape(logo_url, quote=True)}" alt="{company_name}" '
        'style="max-height:76px;max-width:180px;display:block;border:0;" />'
        if logo_url
        else f'<strong style="font-size:20px;color:{brand_color};">{company_name}</strong>'
    )
    centered_logo_block = (
        '<table role="presentation" align="center" border="0" cellpadding="0" cellspacing="0" '
        'style="margin:0 auto;"><tr><td align="center">'
        f"{logo_block}</td></tr></table>"
    )
    website_block = (
        f'<p style="margin:8px 0;">官网：<a href="{html.escape(website, quote=True)}">{html.escape(website)}</a></p>'
        if website
        else ""
    )
    intro_block = f'<p style="margin:8px 0;color:#475569;line-height:1.7;">{company_intro}</p>' if company_intro else ""
    qr_block = (
        (
            f'<div style="margin-top:16px;padding-top:16px;border-top:1px solid #e2e8f0;">'
            f'<p style="margin:0 0 8px;">关注更多招聘机会，可扫码联系 HR：</p>'
            f'<img src="{html.escape(qr_code_url, quote=True)}" alt="HR 投递二维码" style="width:132px;height:132px;display:block;" />'
            f"</div>"
        )
        if qr_code_url
        else ""
    )
    invitation = html.escape(content).replace("\n", "<br />")
    return f"""<!doctype html><html><body style="margin:0;background:#f1f5f9;padding:24px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;color:#1e293b;">
<div style="max-width:640px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(15,23,42,.12);">
  <div align="center" style="padding:20px 24px;background:#edffed;text-align:center;">{centered_logo_block}</div>
  <div style="padding:0 24px 24px;font-size:15px;line-height:1.8;">{invitation}</div>
  <div style="padding:20px 24px;background:#f8fafc;font-size:13px;">{intro_block}{website_block}{qr_block}</div>
</div></body></html>"""


# ── 单封邮件发送 ─────────────────────────────────────────────────


async def send_email(
    to_email: str,
    subject: str,
    body: str,
    *,
    to_name: str = "",
    is_html: bool = False,
    cc: list[str] = None,
    _check_connection: bool = True,
    smtp_config: Optional[dict] = None,
) -> SendResult:
    """Send a single email with retry logic.

    Args:
        to_email: Recipient email address
        subject: Email subject (supports Unicode)
        body: Email body (plain text or HTML)
        to_name: Optional recipient display name
        is_html: Set True if body is HTML
        cc: Optional list of CC email addresses

    Returns:
        SendResult with success/error details
    """
    start = time.monotonic()
    last_error = ""

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            settings = _smtp_settings(smtp_config)
            _validate_smtp_settings(settings)
            conn = await _get_connection(settings, check_health=_check_connection)

            msg = MIMEMultipart("alternative")
            msg["From"] = formataddr((settings["from_name"], settings["from_email"]))
            if to_name:
                msg["To"] = formataddr((to_name, to_email))
            else:
                msg["To"] = to_email
            msg["Subject"] = Header(subject, "utf-8")

            if cc:
                msg["Cc"] = ", ".join(cc)

            subtype = "html" if is_html else "plain"
            msg.attach(MIMEText(body, subtype, "utf-8"))

            recipients = [to_email] + (cc or [])
            conn.sendmail(settings["username"], recipients, msg.as_string())

            elapsed = (time.monotonic() - start) * 1000
            logger.info(
                f"Email sent to {to_email} (attempt {attempt}, {elapsed:.0f}ms)",
                extra={"source": "EmailSender"},
            )
            return SendResult(email=to_email, success=True, retries=attempt - 1, elapsed_ms=elapsed)

        except smtplib.SMTPServerDisconnected:
            last_error = "SMTP 服务器连接中断"
            logger.warning(f"SMTP disconnected, reconnecting... (attempt {attempt})")
            # 下次尝试时强制重新连接
            async with _connection_lock:
                key = (settings["host"], settings["port"], settings["security"], settings["username"])
                _shared_connections.pop(key, None)

        except smtplib.SMTPAuthenticationError:
            last_error = "SMTP 认证失败，请检查当前账号的授权码和邮箱服务商配置"
            logger.error(last_error)
            break  # 认证失败时不重试

        except smtplib.SMTPRecipientsRefused as e:
            last_error = f"收件人邮箱被服务器拒绝：{e}"
            logger.warning(f"Recipient refused for {to_email}: {e}")
            break  # 收件人无效时不重试

        except smtplib.SMTPDataError as e:
            last_error = f"SMTP 邮件内容提交失败：{e}"
            logger.warning(f"SMTP data error for {to_email}: {e} (attempt {attempt})")

        except smtplib.SMTPException as e:
            last_error = f"SMTP 服务错误：{e}"
            logger.warning(f"SMTP error for {to_email}: {e} (attempt {attempt})")

        except Exception as e:
            last_error = f"邮件发送异常：{e}"
            logger.error(f"Unexpected error sending to {to_email}: {e} (attempt {attempt})")

        # 重试前等待（指数退避）
        if attempt < MAX_RETRIES:
            delay = RETRY_BASE_DELAY * (2 ** (attempt - 1))
            await asyncio.sleep(delay)

    elapsed = (time.monotonic() - start) * 1000
    logger.error(f"Failed to send email to {to_email} after {MAX_RETRIES} attempts: {last_error}")
    return SendResult(email=to_email, success=False, error=last_error, retries=MAX_RETRIES, elapsed_ms=elapsed)


# ── 批量发送 ─────────────────────────────────────────────────────


async def send_batch(
    recipients: list[dict],
    subject: str,
    body_template: str,
    *,
    is_html: bool = False,
    rate_limit_delay: float = BATCH_DELAY,
) -> BatchResult:
    """Send emails to multiple recipients with rate limiting.

    Args:
        recipients: List of dicts, each with at least "email" key.
                    Optional keys: "name", custom template variables.
        subject: Email subject (shared across batch)
        body_template: Template string with {variable} placeholders
        is_html: Set True if body_template is HTML
        rate_limit_delay: Seconds between each send

    Returns:
        BatchResult with per-recipient details and aggregate stats
    """
    start = time.monotonic()
    results: list[SendResult] = []

    for i, recipient in enumerate(recipients):
        if i > 0:
            await asyncio.sleep(rate_limit_delay)

        to_email = recipient.get("email", "")
        if not to_email:
            results.append(SendResult(email="", success=False, error="No email address"))
            continue

        # 渲染个性化正文
        try:
            body = render_template(body_template, recipient)
        except Exception as e:
            results.append(SendResult(email=to_email, success=False, error=f"Template error: {e}"))
            continue

        result = await send_email(
            to_email=to_email,
            subject=subject,
            body=body,
            to_name=recipient.get("name", ""),
            is_html=is_html,
        )
        results.append(result)

    total_elapsed = (time.monotonic() - start) * 1000
    batch = BatchResult(
        total=len(recipients),
        success=sum(1 for r in results if r.success),
        failed=sum(1 for r in results if not r.success),
        results=results,
        total_elapsed_ms=total_elapsed,
    )

    logger.info(
        f"Batch send complete: {batch.success}/{batch.total} success, "
        f"{batch.failed} failed ({batch.total_elapsed_ms:.0f}ms)",
        extra={"source": "EmailSender"},
    )
    return batch


# ── 面试邀请辅助函数 ─────────────────────────────────────────────


async def send_interview_invite(
    to_email: str,
    candidate_name: str,
    role: str,
    *,
    date: str = "",
    time: str = "",
    method: str = "视频面试",
    interviewer: str = "",
    company_name: str = "",
    company_config: Optional[dict] = None,
    base_url: str = "",
    template: str = "",
    interview_url: str = "",
    expires_at: str = "",
    hr_qr_code: str = "",
    _check_connection: bool = True,
    smtp_config: Optional[dict] = None,
) -> SendResult:
    """Send an interview invitation email to a candidate.

    Args:
        to_email: Candidate's email address
        candidate_name: Candidate's name
        role: Job role title
        date: Interview date
        time: Interview time
        method: Interview method (视频面试/现场面试/电话面试)
        interviewer: Interviewer name
        company_name: Company display name
        template: Custom template string (uses default if empty)

    Returns:
        SendResult
    """
    if not template:
        from app.db import get_db

        conn = get_db()
        row = conn.execute(
            "SELECT template FROM communication_templates WHERE id = 'interview_invite_default'"
        ).fetchone()
        if row:
            template = row["template"]

    variables = {
        "candidate_name": candidate_name,
        "role": role,
        "date": date or "待定",
        "time": time or "待定",
        "method": method,
        "interviewer": interviewer or "面试官",
        "company_name": company_name or "锅圈食汇",
        "company_website": (company_config or {}).get("company_website", ""),
        "company_logo": (company_config or {}).get("company_logo", ""),
        "hr_qr_code": hr_qr_code or "",
        "company_intro": (company_config or {}).get("company_intro", ""),
        "interview_url": interview_url,
        "url": interview_url,
        "expires_at": expires_at or "待定",
    }

    if not template or "{interview_url}" not in template:
        template = DEFAULT_INTERVIEW_INVITE_TEMPLATE
    body = render_interview_invite_html(
        render_template(template, variables),
        company_config or {"company_name": company_name},
        base_url,
        hr_qr_code=hr_qr_code,
    )
    subject = f"面试邀请 — {role} — {candidate_name}"

    return await send_email(
        to_email=to_email,
        subject=subject,
        body=body,
        is_html=True,
        _check_connection=_check_connection,
        smtp_config=smtp_config,
    )


# ── 快速连通性检查 ───────────────────────────────────────────────


async def check_smtp_connection() -> dict:
    """Test SMTP connectivity without sending an email.

    Returns:
        {"ok": bool, "message": str, "latency_ms": float}
    """
    start = time.monotonic()
    try:
        settings = _smtp_settings(None)
        _validate_smtp_settings(settings)
        conn = _connect_smtp(settings)
        conn.noop()
        conn.quit()
        elapsed = (time.monotonic() - start) * 1000
        return {"ok": True, "message": "SMTP 连接正常", "latency_ms": round(elapsed, 1)}
    except smtplib.SMTPAuthenticationError:
        elapsed = (time.monotonic() - start) * 1000
        return {"ok": False, "message": "SMTP 认证失败 — 请检查授权码", "latency_ms": round(elapsed, 1)}
    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        return {"ok": False, "message": f"SMTP 连接失败: {e}", "latency_ms": round(elapsed, 1)}
