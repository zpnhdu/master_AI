"""Dedicated rotating file logger for mailbox configuration and sync diagnostics."""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

from app.audit.logger import get_logger

EMAIL_LOG_DIR = Path(os.getenv("APP_LOG_DIR") or (Path(__file__).resolve().parents[2] / "logs"))
EMAIL_LOG_PATH = EMAIL_LOG_DIR / "email.log"


def get_email_logger() -> logging.Logger:
    """Return the shared email logger with a UTF-8 rotating file handler."""
    logger = get_logger("email")
    if os.getenv("TESTING") == "1":
        return logger
    if any(getattr(handler, "_email_file_handler", False) for handler in logger.handlers):
        return logger

    EMAIL_LOG_DIR.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        EMAIL_LOG_PATH,
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler._email_file_handler = True  # type: ignore[attr-defined]
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(levelname)s [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger.addHandler(handler)
    return logger
