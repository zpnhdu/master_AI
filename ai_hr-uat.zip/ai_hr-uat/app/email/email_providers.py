"""邮箱服务商预设：提供收发（SMTP/IMAP）服务器与端口默认值。

用户只选服务商 + 填邮箱 + 填授权码，服务器/端口/加密方式由这里的预设带出；
选择 custom 时由上层传入显式覆盖值。
"""

from __future__ import annotations

EMAIL_PROVIDERS: dict[str, dict] = {
    "qq": {
        "label": "QQ 邮箱",
        "smtp": {"host": "smtp.qq.com", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.qq.com", "port": 993, "security": "ssl"},
    },
    "163": {
        "label": "网易 163",
        "smtp": {"host": "smtp.163.com", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.163.com", "port": 993, "security": "ssl"},
    },
    "126": {
        "label": "网易 126",
        "smtp": {"host": "smtp.126.com", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.126.com", "port": 993, "security": "ssl"},
    },
    "wecom": {
        "label": "企业微信 / 腾讯企业邮",
        "smtp": {"host": "smtp.exmail.qq.com", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.exmail.qq.com", "port": 993, "security": "ssl"},
    },
    "dingtalk": {
        "label": "钉钉企业邮箱",
        "smtp": {"host": "smtp.qiye.aliyun.com", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.qiye.aliyun.com", "port": 993, "security": "ssl"},
    },
    "feishu": {
        "label": "飞书邮箱",
        "smtp": {"host": "smtp.feishu.cn", "port": 465, "security": "ssl"},
        "imap": {"host": "imap.feishu.cn", "port": 993, "security": "ssl"},
    },
    "outlook": {
        "label": "Outlook",
        "smtp": {"host": "smtp-mail.outlook.com", "port": 587, "security": "starttls"},
        "imap": {"host": "outlook.office365.com", "port": 993, "security": "ssl"},
    },
    "gmail": {
        "label": "Gmail",
        "smtp": {"host": "smtp.gmail.com", "port": 587, "security": "starttls"},
        "imap": {"host": "imap.gmail.com", "port": 993, "security": "ssl"},
    },
    "custom": {
        "label": "自定义",
        "smtp": {"host": "", "port": 465, "security": "ssl"},
        "imap": {"host": "", "port": 993, "security": "ssl"},
    },
}

DEFAULT_PROVIDER = "custom"


def provider_presets() -> list[dict]:
    """供前端下拉读取的服务商预设列表（含收发两套默认参数）。"""
    return [
        {
            "key": key,
            "label": config["label"],
            "smtp": config["smtp"],
            "imap": config["imap"],
        }
        for key, config in EMAIL_PROVIDERS.items()
    ]


def resolve_provider_config(provider: str | None) -> dict:
    """返回指定服务商的配置；未知值回落到 custom。"""
    return EMAIL_PROVIDERS.get(provider or DEFAULT_PROVIDER, EMAIL_PROVIDERS[DEFAULT_PROVIDER])
