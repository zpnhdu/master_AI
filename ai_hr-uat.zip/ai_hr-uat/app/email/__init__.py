"""邮件领域包（目录整理）。

原 ``app/email_logging.py``、``app/email_providers.py``、
``app/email_sender.py``、``app/user_mailbox.py``、``app/email_sync.py``
按 ``docs/directory-reorganization-plan.md`` 归入本包，实现原样保留。

与其他域不同，本包不在导入时立即加载子模块：email_sender 的 SMTP_*
常量在导入时从环境变量固化，旧顶层路径依赖「测试 fixture 先
monkeypatch.setenv、再在函数内首次 import」的时序；启动期预加载会
把常量固化为空。因此这里注册按需解析的模块占位符，首次访问
``app.email_sender`` / ``from app.email_sender import X`` 时才真正导入。
"""

import importlib
import sys
import types

_MODULES = (
    "email_logging",
    "email_providers",
    "email_sender",
    "user_mailbox",
    "email_sync",
)


def _resolve(name: str):
    return importlib.import_module("app.email." + name)


def _make_alias(name: str) -> types.ModuleType:
    # 占位模块：首次属性访问 / from-import 时解析为真实子模块。
    # sys.modules 占位不能直接复用自身（会形成 name 循环），用轻量 shim。
    shim = types.ModuleType("app." + name)
    shim.__getattr__ = lambda attr: getattr(_resolve(name), attr)  # type: ignore[attr-defined]
    return shim


import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    if ("app." + _name) not in sys.modules:
        sys.modules["app." + _name] = _make_alias(_name)
    setattr(_app_pkg, _name, sys.modules["app." + _name])

__all__ = list(_MODULES)
