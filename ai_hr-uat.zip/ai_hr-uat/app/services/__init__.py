"""业务服务领域包（目录整理）。

原 ``app/services.py``、``app/wecom_schedule.py`` 按
``docs/directory-reorganization-plan.md`` 归入本包，实现原样保留。

特殊兼容点：旧模块名 ``app.services`` 与本包同名，importlib 解析
``app.services`` 得到包 ``__init__`` 而非包内 ``services.py``。因此
旧 ``from app.services import X``（含测试直接引用的私有名）由本文件
显式转发；``app.services.<attr>`` 的属性访问与 monkeypatch 经
``__getattr__`` 动态解析到 ``app.services.services`` 模块，
``app.wecom_schedule`` 旧名仍走常规别名。
"""

import importlib
import sys

import app as _app_pkg  # noqa: E402

_services_mod = importlib.import_module("app.services.services")
_wecom_mod = importlib.import_module("app.services.wecom_schedule")

# 测试直接引用的私有名（from app.services import _x）
_merge_match_output = _services_mod._merge_match_output
_merge_interview_output = _services_mod._merge_interview_output
_cross_batch_dedup = _services_mod._cross_batch_dedup

# 公开名照常转发
from app.services.services import *  # noqa: E402,F401,F403
from app.services.wecom_schedule import *  # noqa: E402,F401,F403


def __getattr__(name: str):
    # 属性访问 / from-import 未列名时动态解析到 services 模块，
    # monkeypatch app.services.X 仍命中同一模块对象上的属性。
    return getattr(_services_mod, name)


sys.modules.setdefault("app.wecom_schedule", _wecom_mod)
setattr(_app_pkg, "wecom_schedule", _wecom_mod)

__all__ = [
    "_merge_match_output",
    "_merge_interview_output",
    "_cross_batch_dedup",
]
