"""企业微信复试日程的创建服务。

凭据只从环境变量读取，绝不由前端传入或写入数据库。访问令牌可用于
临时联调；生产环境建议配置企业 ID 和应用 Secret，让服务自动获取令牌。
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

import requests

_API_BASE = "https://qyapi.weixin.qq.com/cgi-bin"
_SCHEDULE_ADD_URL = f"{_API_BASE}/oa/schedule/add"
_GET_TOKEN_URL = f"{_API_BASE}/gettoken"
_SHANGHAI = ZoneInfo("Asia/Shanghai")


class WeComScheduleError(RuntimeError):
    """企业微信拒绝或无法完成日程创建。"""


def _is_enabled() -> bool:
    return os.getenv("WECOM_SCHEDULE_ENABLED", "").strip().lower() in {"1", "true", "yes", "on"}


def _access_token() -> str:
    token = os.getenv("WECOM_SCHEDULE_ACCESS_TOKEN", "").strip()
    if token:
        return token

    corpid = os.getenv("WECOM_CORPID", "").strip()
    secret = os.getenv("WECOM_SECRET", "").strip()
    if not corpid or not secret:
        raise WeComScheduleError("缺少 WECOM_SCHEDULE_ACCESS_TOKEN，或 WECOM_CORPID 与 WECOM_SECRET 配置")

    try:
        response = requests.get(
            _GET_TOKEN_URL,
            params={"corpid": corpid, "corpsecret": secret},
            timeout=10,
        )
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError) as error:
        raise WeComScheduleError("获取企业微信访问令牌失败") from error

    if payload.get("errcode", 0) != 0 or not payload.get("access_token"):
        raise WeComScheduleError(f"获取企业微信访问令牌失败：{payload.get('errmsg', '未知错误')}")
    return str(payload["access_token"])


def _attendee_userids() -> list[str]:
    # 面试官是业务展示名称；企业微信接收人只能由后端环境变量控制，
    # 避免前端自由文本被误当作 UserID，也不允许客户端覆盖通知对象。
    raw_userids = os.getenv("WECOM_SCHEDULE_DEFAULT_ATTENDEES", "")
    userids = [item for item in re.split(r"[,，\s]+", raw_userids.strip()) if item]
    if not userids:
        raise WeComScheduleError("缺少 WECOM_SCHEDULE_DEFAULT_ATTENDEES 配置")
    return list(dict.fromkeys(userids))


def _event_times(schedule: dict[str, Any]) -> tuple[int, int]:
    date = str(schedule.get("date") or "").strip()
    time = str(schedule.get("time") or "09:00").strip()
    try:
        start = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M").replace(tzinfo=_SHANGHAI)
    except ValueError as error:
        raise WeComScheduleError("复试日期或时间格式无效") from error

    try:
        duration_minutes = int(schedule.get("duration_minutes") or 60)
    except (TypeError, ValueError) as error:
        raise WeComScheduleError("复试时长必须为整数分钟") from error
    if duration_minutes <= 0 or duration_minutes > 24 * 60:
        raise WeComScheduleError("复试时长需介于 1 到 1440 分钟之间")
    end = start + timedelta(minutes=duration_minutes)
    return int(start.timestamp()), int(end.timestamp())


def build_schedule_payload(schedule: dict[str, Any]) -> dict[str, Any]:
    """将本地复试排期转换为企业微信 ``oa/schedule/add`` 请求体。"""
    start_time, end_time = _event_times(schedule)
    candidate_name = str(schedule.get("candidate_name") or schedule.get("candidate_id") or "候选人").strip()
    interviewer = str(schedule.get("interviewer") or "").strip()
    notes = str(schedule.get("notes") or "").strip()
    meeting_url = str(schedule.get("meeting_url") or "").strip()
    description = "\n".join(
        item
        for item in (
            ([f"面试官：{interviewer}"] if interviewer else [])
            + ([f"腾讯会议：{meeting_url}"] if meeting_url else [])
            + ([notes] if notes else [])
        )
    )

    return {
        "schedule": {
            "start_time": start_time,
            "end_time": end_time,
            "attendees": [{"userid": userid} for userid in _attendee_userids()],
            "summary": f"复试 · {candidate_name}",
            "description": description or "复试安排",
            "reminders": {
                "is_remind": 1,
                "remind_before_event_secs": 3600,
                "is_repeat": 0,
            },
            "location": str(schedule.get("location") or "线上面试").strip(),
        }
    }


def create_schedule_if_enabled(schedule: dict[str, Any]) -> dict[str, Any]:
    """创建企业微信日程；功能未启用时显式返回 disabled。"""
    if not _is_enabled():
        return {"status": "disabled"}

    payload = build_schedule_payload(schedule)
    try:
        response = requests.post(
            _SCHEDULE_ADD_URL,
            params={"access_token": _access_token()},
            json=payload,
            timeout=10,
        )
        response.raise_for_status()
        result = response.json()
    except (requests.RequestException, ValueError) as error:
        raise WeComScheduleError("调用企业微信日程接口失败") from error

    if result.get("errcode", 0) != 0:
        raise WeComScheduleError(f"企业微信日程创建失败：{result.get('errmsg', '未知错误')}")
    return {"status": "created", "schedule_id": result.get("schedule_id")}
