"""Pipeline processing services - extracted from main.py.

Contains resume parsing, pipeline processing, video assessment,
and report generation.
All WebSocket broadcasts use state.broadcast().
"""

import json
import hashlib
import logging
import os
import time
from datetime import datetime
from typing import Optional
from uuid import uuid4

from app import service_helpers as _service_helpers
from app.db import (
    clear_pending,
    create_stage,
    get_candidates,
    get_pipeline,
    get_stages,
    save_candidate,
    save_message,
    update_candidate,
    update_pipeline,
    update_stage,
)
from app.state import (
    broadcast,
    interview_generation_tasks,
    pending_resumes,
    pending_videos,
    processing_locks,
)

_parse_stage_output = _service_helpers.parse_stage_output
_candidate_id = _service_helpers.candidate_id
_merge_match_output = _service_helpers.merge_match_output
_merge_interview_output = _service_helpers.merge_interview_output
parse_years = _service_helpers.parse_years
split_resume_text = _service_helpers.split_resume_text
_generate_match_summary = _service_helpers.generate_match_summary

logger = logging.getLogger(__name__)
INTERVIEW_TASK_RETENTION_SECONDS = 3600

# 简历处理：冷却保护
COOLDOWN_SECONDS = 5.0  # 同一流水线 5 秒内不重复匹配
_match_cooldowns: dict[str, float] = {}  # pipeline_id → 最近一次匹配完成时间戳


# ============ 简历解析辅助函数 ============


async def _parse_resume_legacy_llm(text: str, source: str) -> dict:
    """Legacy single-call LLM JSON parsing (fallback when ragflow port fails)."""
    from hermes_wrapper.client import get_client
    from hermes_wrapper.models import LLMRequest

    client = get_client()
    req = LLMRequest(
        prompt=f"""从以下文本提取简历信息，输出JSON：
{{
    "name": "姓名",
    "years_experience": 数字,
    "current_company": "当前公司",
    "current_salary": "当前薪资",
    "skills": ["技能1", "技能2"],
    "resume_text": "300字详细摘要（包含：核心项目经历、管理团队规模、关键业绩数据）",
    "education": "学历",
    "location": "城市",
    "title": "当前职位",
    "phone": "手机号（大陆11位，无则空字符串）",
    "email": "邮箱（无则空字符串）"
}}

文本：
{text[:5000]}""",
        system="从简历文本中提取结构化信息，输出JSON。如果文本不是简历，返回null。",
        model=os.environ.get("RESUME_PARSE_MODEL", ""),
        complexity="flash",
        temperature=0.1,
        timeout=90,
    )
    result = await client.chat_json(req)
    if isinstance(result, dict) and result.get("name"):
        return result
    return None


async def parse_resume_with_llm(text: str, source: str) -> dict:
    """Parse resume text into structured data — ragflow field-first, with legacy fallback."""
    if len(text.strip()) < 20:
        return None

    try:
        import hashlib

        from app.resume_parser import mapper, parse_resume_text

        # ── Primary: ragflow port (4 parallel LLM subtasks + regex fallback) ──
        ragflow = await parse_resume_text(text, "Chinese")
        result = mapper.ragflow_to_legacy(ragflow)

        # If the ragflow path produced no usable identity, fall back to legacy.
        if not result.get("name") or result["name"] in ("未知", "Unknown", ""):
            logger.warning(f"[Resume Parse] ragflow path returned no name for {source}; falling back to legacy LLM")
            legacy = await _parse_resume_legacy_llm(text, source)
            if legacy:
                result.update({k: v for k, v in legacy.items() if v})
                # Keep ragflow pass-through for later fields.
                result.setdefault("ragflow_raw", ragflow)
                result["ragflow_json"] = mapper.ragflow_raw_to_json(ragflow)

        if not result.get("name"):
            return None

        # ── Contact: rule fallback + three-tier classification (unchanged) ──
        phone = str(result.get("phone") or "").strip()
        email = str(result.get("email") or "").strip().lower()
        if not phone and not email:
            from app.resume_contact import extract_contact

            rule_phone, rule_email = extract_contact(text)
            phone = phone or rule_phone
            email = email or rule_email

        from app.resume_contact import classify_contact

        result["phone"] = phone
        result["email"] = email
        result["contact_status"] = classify_contact(phone, email)

        id_hash = hashlib.md5(text[:500].encode()).hexdigest()[:8]
        result["id"] = f"imp_{id_hash}"

        # Ensure ragflow_raw is always populated for storage (db/talent_pool).
        if "ragflow_raw" not in result:
            result["ragflow_raw"] = ragflow
        if "ragflow_json" not in result:
            result["ragflow_json"] = mapper.ragflow_raw_to_json(ragflow)

        return result
    except Exception as e:
        logger.exception(f"[Resume Parse] ragflow path error: {e}")
        # ── Fallback: original single-LLM-JSON path ──
        try:
            legacy = await _parse_resume_legacy_llm(text, source)
            if legacy:
                import hashlib

                phone = str(legacy.get("phone") or "").strip()
                email = str(legacy.get("email") or "").strip().lower()
                if not phone and not email:
                    from app.resume_contact import extract_contact

                    rule_phone, rule_email = extract_contact(text)
                    if rule_phone and not phone:
                        phone = rule_phone
                    if rule_email and not email:
                        email = rule_email

                from app.resume_contact import classify_contact

                legacy["phone"] = phone
                legacy["email"] = email
                legacy["contact_status"] = classify_contact(phone, email)

                id_hash = hashlib.md5(text[:500].encode()).hexdigest()[:8]
                legacy["id"] = f"imp_{id_hash}"
                return legacy
        except Exception as e2:
            logger.error(f"[Resume Parse] legacy fallback error: {e2}")

    return None


# ============ 流水线后台运行器 ============


async def run_pipeline_bg(
    role: str,
    hints: str = "",
    quiz_answers: list = None,
    pipeline_type: str = "tech",
    enabled_agents: list = None,
    extra_fields: dict = None,
    pipeline_id: str = None,
    exclude_stages: set = None,
    engine_version: int = 2,
    skip_planning: bool = False,
):
    """Run pipeline in background (for REST API)."""
    import logging

    logger = logging.getLogger("app.services")

    # 加载 KG 上下文（带缓存，不阻塞主流程）
    kg_context = {}
    try:
        from kg.core import get_knowledge_graph

        kg = get_knowledge_graph()
        kg_context = kg.traverse_for_role(role, depth=2, max_tokens=500)
    except Exception as e:
        logger.warning(f"KG context load failed: {e}")

    # 加载公司配置
    company_config = {}
    try:
        from app.db import get_company_config

        company_config = get_company_config()
    except Exception:
        pass

    # 注入到 extra_fields
    if extra_fields is None:
        extra_fields = {}
    extra_fields["kg_context"] = kg_context
    extra_fields["company_config"] = company_config

    from app.state import broadcast, get_supervisor

    supervisor = get_supervisor()

    # 广播回调：让 REST 触发的 auto-run 也能通过 WS 推送阶段事件（ISSUE-1-01）
    def _now() -> str:
        return datetime.now().isoformat()

    async def on_stage_start(stage_id: str, stage_name: str):
        await broadcast(
            {
                "type": "stage_start",
                "pipeline_id": pipeline_id,
                "stage_id": stage_id,
                "stage_name": stage_name,
                "timestamp": _now(),
            },
            pipeline_id=pipeline_id,
        )

    async def on_stage_done(stage_id: str, stage_name: str, output):
        await broadcast(
            {
                "type": "stage_done",
                "pipeline_id": pipeline_id,
                "stage_id": stage_id,
                "stage_name": stage_name,
                "output": output,
                "timestamp": _now(),
            },
            pipeline_id=pipeline_id,
        )

    async def on_stage_progress(stage_id: str, message: str):
        await broadcast(
            {
                "type": "stage_progress",
                "pipeline_id": pipeline_id,
                "stage_id": stage_id,
                "message": message,
                "timestamp": _now(),
            },
            pipeline_id=pipeline_id,
        )

    async def on_pipeline_done(result: dict):
        status = result.get("status", "completed")
        await broadcast(
            {
                "type": "pipeline_waiting_human" if status == "waiting_human" else "pipeline_done",
                "pipeline_id": result.get("pipeline_id", pipeline_id),
                "role": result.get("role", role),
                "status": status,
                "timestamp": _now(),
            },
            pipeline_id=result.get("pipeline_id", pipeline_id),
        )

    async def on_error(stage_id: str, stage_name: str, error):
        await broadcast(
            {
                "type": "stage_error",
                "pipeline_id": pipeline_id,
                "stage_id": stage_id,
                "stage_name": stage_name,
                "error": str(error),
                "timestamp": _now(),
            },
            pipeline_id=pipeline_id,
        )

    try:
        await supervisor.run_pipeline(
            role=role,
            user_hints=hints,
            quiz_answers=quiz_answers,
            pipeline_type=pipeline_type,
            enabled_agents=enabled_agents,
            extra_fields=extra_fields,
            pipeline_id=pipeline_id,
            exclude_stages=exclude_stages,
            engine_version=engine_version,
            skip_planning=skip_planning,
            on_stage_start=on_stage_start,
            on_stage_done=on_stage_done,
            on_stage_progress=on_stage_progress,
            on_pipeline_done=on_pipeline_done,
            on_error=on_error,
        )
    except Exception:
        if pipeline_id:
            update_pipeline(pipeline_id, "failed")
        logger.exception("后台流水线执行失败: %s", pipeline_id)
        raise


def _task_timestamp() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _prune_interview_generation_tasks() -> None:
    """Drop expired in-memory compatibility tasks when Redis is unavailable."""
    cutoff = datetime.now().timestamp() - INTERVIEW_TASK_RETENTION_SECONDS
    for task_id, task in list(interview_generation_tasks.items()):
        if task.get("status") not in {"done", "failed"} or not task.get("completed_at"):
            continue
        try:
            completed_at = datetime.fromisoformat(task["completed_at"]).timestamp()
        except (TypeError, ValueError):
            continue
        if completed_at < cutoff:
            interview_generation_tasks.pop(task_id, None)


def create_interview_generation_task(pipeline_id: str, candidate_count: int, question_count: int = None) -> dict:
    """Create a UI-pollable generation job before scheduling the LLM work."""
    _prune_interview_generation_tasks()
    task_id = f"interview_gen_{uuid4().hex}"
    now = _task_timestamp()
    task = {
        "id": task_id,
        "pipeline_id": pipeline_id,
        "status": "queued",
        "progress": 0,
        "candidate_count": candidate_count,
        "question_count": question_count,
        "message": "正在排队准备生成面试题",
        "error": "",
        "created_at": now,
        "started_at": "",
        "updated_at": now,
        "completed_at": "",
    }
    redis = _interview_task_redis()
    if redis is not None:
        payload = json.dumps(task, ensure_ascii=False)
        redis.set(f"interview_generation:{task_id}", payload, ttl=INTERVIEW_TASK_RETENTION_SECONDS)
        redis.set(
            f"interview_generation:active:{pipeline_id}",
            task_id,
            ttl=INTERVIEW_TASK_RETENTION_SECONDS,
        )
    else:
        interview_generation_tasks[task_id] = task
    return dict(task)


def get_interview_generation_task(task_id: str, pipeline_id: str = "") -> Optional[dict]:
    _prune_interview_generation_tasks()
    redis = _interview_task_redis()
    task = None
    if redis is not None:
        raw = redis.get(f"interview_generation:{task_id}")
        if raw:
            try:
                task = json.loads(raw)
            except (TypeError, ValueError, json.JSONDecodeError):
                logger.warning("Invalid Redis interview generation task payload: %s", task_id)
    else:
        task = interview_generation_tasks.get(task_id)
    if not task or (pipeline_id and task.get("pipeline_id") != pipeline_id):
        return None
    return dict(task)


def get_active_interview_generation_task(pipeline_id: str) -> Optional[dict]:
    _prune_interview_generation_tasks()
    redis = _interview_task_redis()
    if redis is not None:
        task_id = redis.get(f"interview_generation:active:{pipeline_id}")
        return get_interview_generation_task(str(task_id), pipeline_id) if task_id else None
    for task in reversed(list(interview_generation_tasks.values())):
        if task.get("pipeline_id") == pipeline_id and task.get("status") in {"queued", "running"}:
            return dict(task)
    return None


def update_interview_generation_task(task_id: str, **updates) -> None:
    redis = _interview_task_redis()
    task = None
    if redis is not None:
        raw = redis.get(f"interview_generation:{task_id}")
        if raw:
            try:
                task = json.loads(raw)
            except (TypeError, ValueError, json.JSONDecodeError):
                return
    else:
        task = interview_generation_tasks.get(task_id)
    if not task:
        return
    task.update(updates)
    task["updated_at"] = _task_timestamp()
    if task.get("status") == "running" and not task.get("started_at"):
        task["started_at"] = task["updated_at"]
    if task.get("status") in {"done", "failed"} and not task.get("completed_at"):
        task["completed_at"] = task["updated_at"]
    if redis is not None:
        redis.set(
            f"interview_generation:{task_id}",
            json.dumps(task, ensure_ascii=False),
            ttl=INTERVIEW_TASK_RETENTION_SECONDS,
        )
        if task.get("status") in {"done", "failed"}:
            active_key = f"interview_generation:active:{task.get('pipeline_id', '')}"
            if redis.get(active_key) == task_id:
                redis.delete(active_key)


def _interview_task_redis():
    """Return Redis for generation-task state, or None for test/demo fallback."""
    try:
        from app.infrastructure.cache.redis_client import get_redis_client

        client = get_redis_client()
        return client if getattr(client, "backend", "none") == "redis" else None
    except Exception as exc:
        logger.warning("Redis unavailable for interview generation task state: %s", exc)
        return None


async def _run_interview_gen(
    pipeline_id: str,
    match_result: dict,
    jd: dict,
    role: str,
    question_count: int = None,
    task_id: str = "",
    candidate_id: str = "",
):
    """match 完成后触发面试题生成。

    question_count: 1-20 可配置（缺省 None → 使用 InterviewAgent 默认 3 道）
    批量生成完成后直接标记为 review_status="reviewed"，允许立即发起面试。
    """
    from hr_harness.agents.interview_agent import (
        InterviewAgent,
        build_shared_question_cache_metadata,
        get_shared_question_knowledge,
    )

    shortlisted_ids = match_result.get("shortlisted", [])
    all_candidates = match_result.get("candidates", [])
    workflow_status = str(match_result.get("workflow_status") or "").strip().lower()
    modern_screening = bool(match_result.get("screening_workflow")) or workflow_status in {
        "review_pending",
        "confirmed",
    }
    if modern_screening:
        if workflow_status != "confirmed":
            shortlisted_ids = []
        shortlisted_ids = [
            item
            for item in (shortlisted_ids if isinstance(shortlisted_ids, list) else [])
            if (isinstance(item, dict) and str(item.get("screening_decision") or "").strip().lower() == "passed")
            or (
                not isinstance(item, dict)
                and any(
                    str(candidate.get("id") or candidate.get("candidate_id") or "") == str(item)
                    and str(candidate.get("screening_decision") or "").strip().lower() == "passed"
                    for candidate in all_candidates
                )
            )
        ]
    # 将入围候选人 ID 解析为完整候选人对象
    if shortlisted_ids and all_candidates:
        id_map = {}
        for c in all_candidates:
            cid = c.get("id") or c.get("candidate_id") or ""
            id_map[str(cid)] = c
        candidates = []
        for item in shortlisted_ids:
            if isinstance(item, dict):
                cid = item.get("id") or item.get("candidate_id") or ""
                candidates.append(id_map.get(str(cid), item))
            else:
                candidate = id_map.get(str(item))
                if candidate:
                    candidates.append(candidate)
        # 旧版匹配阶段可能保存了旧候选人 ID；新版小筛不能用全量候选人兜底。
        if not candidates and not modern_screening:
            candidates = list(all_candidates)
    else:
        candidates = shortlisted_ids
    if modern_screening:
        candidates = [
            candidate
            for candidate in candidates
            if str(candidate.get("screening_decision") or "").strip().lower() == "passed"
        ]
    thresholds = match_result.get("thresholds", {})
    shortlist_min = thresholds.get("shortlist_min", 70)
    force_gen = False  # 是否强制生成（无入围时）
    update_interview_generation_task(
        task_id,
        status="running",
        progress=5,
        message="正在准备候选人资料",
    )

    if not candidates:
        # 新版小筛没有确认通过者时直接结束，不能按旧分数线或最高分降级。
        if modern_screening:
            msg_text = "📋 没有已确认通过筛选的候选人，无法生成面试题。"
            save_message(pipeline_id, "assistant", msg_text)
            stages = get_stages(pipeline_id)
            if not any(s["stage_id"] == "interview_gen" for s in stages):
                create_stage(pipeline_id, "interview_gen", "面试题生成")
            update_stage(
                pipeline_id,
                "interview_gen",
                "done",
                {"skipped": True, "reason": msg_text, "generation_job_id": task_id},
            )
            update_interview_generation_task(task_id, status="done", progress=100, message=msg_text)
            await broadcast(
                {"type": "stage_done", "stage_id": "interview_gen", "stage_name": "面试题生成"}, pipeline_id
            )
            return
        # 旧版匹配数据保留分数最高的前3位降级行为。
        all_candidates = match_result.get("candidates", [])
        if not all_candidates:
            msg_text = "📋 没有候选人数据，无法生成面试题。"
            save_message(pipeline_id, "assistant", msg_text)
            stages = get_stages(pipeline_id)
            if not any(s["stage_id"] == "interview_gen" for s in stages):
                create_stage(pipeline_id, "interview_gen", "面试题生成")
            update_stage(
                pipeline_id,
                "interview_gen",
                "done",
                {"skipped": True, "reason": msg_text, "generation_job_id": task_id},
            )
            update_interview_generation_task(task_id, status="done", progress=100, message=msg_text)
            await broadcast(
                {"type": "stage_done", "stage_id": "interview_gen", "stage_name": "面试题生成"}, pipeline_id
            )
            return
        top_score = max((c.get("overall_score", 0) for c in all_candidates), default=0)
        candidates = sorted(all_candidates, key=lambda c: c.get("overall_score", 0), reverse=True)[:3]
        force_gen = True
        save_message(
            pipeline_id,
            "assistant",
            f"⚠️ 所有候选人均未达到入围线（{shortlist_min}分），最高分{top_score}分。已为分数最高的{len(candidates)}位候选人生成面试题。",
        )

    update_interview_generation_task(
        task_id,
        status="running",
        progress=10,
        candidate_count=len(candidates),
        message=f"正在为 {len(candidates)} 位候选人生成面试题",
    )

    # 确保 interview_gen stage 存在
    stages = get_stages(pipeline_id)
    existing_ids = {s["stage_id"] for s in stages}
    if "interview_gen" not in existing_ids:
        create_stage(pipeline_id, "interview_gen", "面试题生成")

    stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    existing_output = _parse_stage_output(stage)
    running_output = dict(existing_output)
    running_output["generation_job_id"] = task_id
    if question_count:
        running_output["generated_count"] = int(question_count)
    update_stage(pipeline_id, "interview_gen", "running", running_output)
    await broadcast({"type": "stage_start", "stage_id": "interview_gen", "stage_name": "面试题生成"}, pipeline_id)

    try:
        agent = InterviewAgent()
        pipeline = get_pipeline(pipeline_id) or {}
        pipeline_type = pipeline.get("type", "tech")
        actor_user_id = str(pipeline.get("owner_user_id") or "")
        _, pipeline_job_type_label = agent._resolve_pipeline_job_type(pipeline_type)
        shared_kb_context, shared_kb_revision = get_shared_question_knowledge(role)
        from hr_harness.memory.core import MemorySystem

        interview_memory_context = MemorySystem(pipeline_id, actor_user_id=actor_user_id).get_interview_context(role)
        memory_revision = (
            hashlib.sha256(interview_memory_context.encode("utf-8")).hexdigest()
            if interview_memory_context
            else ""
        )
        requested_count = int(question_count or existing_output.get("generated_count") or 3)
        cache_metadata = build_shared_question_cache_metadata(
            jd,
            role,
            pipeline_job_type_label,
            shared_kb_revision,
            requested_count,
            memory_revision,
        )
        cached_set = existing_output.get("shared_question_set", {})
        cached_questions = cached_set.get("questions", []) if isinstance(cached_set, dict) else []
        if not isinstance(cached_questions, list):
            cached_questions = []
        cached_source_matches = isinstance(cached_set, dict) and all(
            cached_set.get(key) == cache_metadata[key]
            for key in ("jd_revision", "kb_revision", "prompt_version", "model")
        ) and cached_set.get("memory_revision", "") == memory_revision
        if cached_source_matches and len(cached_questions) >= requested_count:
            existing_interviews = existing_output.get("interviews", [])
            template = next((item for item in existing_interviews if isinstance(item, dict)), {})
            template_meta = {
                key: value
                for key, value in template.items()
                if key not in {"candidate_id", "candidate_name", "questions", "review_status"}
            }
            interview_result = {
                "interviews": [
                    {
                        **template_meta,
                        "candidate_id": candidate.get("id") or candidate.get("candidate_id", ""),
                        "candidate_name": candidate.get("name", ""),
                        "questions": [dict(item) for item in cached_questions[:requested_count]],
                        "review_status": "reviewed",
                    }
                    for candidate in candidates
                ],
                "shared_question_set": dict(cached_set),
                "generated_count": requested_count,
                "cache_hit": True,
                "status": "completed",
            }
        else:
            # The count is intentionally excluded from this comparison.  When an
            # HR user expands (for example) 5 questions to 10, retain the
            # approved draft and ask the model for only the missing questions.
            # `previous_questions` is included in the prompt so the additions do
            # not repeat the existing set.
            extend_cached_questions = (
                cached_questions if 0 < len(cached_questions) < requested_count and cached_source_matches else []
            )
            context = {
                "candidates": candidates,
                "jd": jd,
                "role": role,
                "pipeline_type": pipeline_type,
                "pipeline_id": pipeline_id,
                "shared_kb_context": shared_kb_context,
                "shared_kb_revision": shared_kb_revision,
                "interview_memory_context": interview_memory_context,
                "actor_user_id": actor_user_id,
            }
            if extend_cached_questions:
                context["question_count"] = requested_count - len(extend_cached_questions)
                context["previous_questions"] = extend_cached_questions
            elif question_count:
                context["question_count"] = int(question_count)
            interview_result = await agent.execute(context)
            if extend_cached_questions and isinstance(interview_result, dict):
                generated_set = interview_result.get("shared_question_set", {})
                generated_questions = generated_set.get("questions", []) if isinstance(generated_set, dict) else []
                if isinstance(generated_questions, list) and generated_questions:
                    combined_questions = [
                        *[dict(question) for question in extend_cached_questions if isinstance(question, dict)],
                        *[dict(question) for question in generated_questions if isinstance(question, dict)],
                    ][:requested_count]
                    if len(combined_questions) == requested_count:
                        interview_result["shared_question_set"] = {**cache_metadata, "questions": combined_questions}
                        for interview in interview_result.get("interviews", []):
                            if isinstance(interview, dict):
                                interview["questions"] = [dict(question) for question in combined_questions]
                                interview["time_allocation"] = {
                                    "total_minutes": 3 * len(combined_questions),
                                    "per_question": [3] * len(combined_questions),
                                }
                        interview_result["generated_count"] = requested_count
                        interview_result["cache_extended"] = True
    except Exception as e:
        logger.error(f"InterviewAgent error: {e}", exc_info=True)
        save_message(pipeline_id, "assistant", f"⚠️ 面试题生成失败：{str(e)[:100]}")
        # 确保阶段不会停留在 running 状态
        failure_output = dict(existing_output)
        failure_output["error"] = str(e)[:200]
        if task_id:
            failure_output["generation_job_id"] = task_id
        update_stage(pipeline_id, "interview_gen", "failed", failure_output)
        update_interview_generation_task(
            task_id,
            status="failed",
            progress=100,
            error=str(e)[:200],
            message="面试题生成失败",
        )
        await broadcast(
            {"type": "stage_error", "stage_id": "interview_gen", "error": f"面试题生成失败: {str(e)[:100]}"},
            pipeline_id,
        )
        return

        # 防御性检查：确保 interview_result 是包含 interviews 键的字典
    if not isinstance(interview_result, dict):
        interview_result = {"interviews": [], "status": "parse_error", "error": "Agent returned non-dict result"}

    # 强制人工审核：新生成的题目默认待审核，写回源头供审核页使用
    interviews = interview_result.get("interviews", [])
    if isinstance(interviews, list):
        for iv in interviews:
            if isinstance(iv, dict):
                iv["review_status"] = "reviewed"
    interview_result["review_status"] = "reviewed"
    if task_id:
        interview_result["generation_job_id"] = task_id
    if question_count:
        interview_result["generated_count"] = int(question_count)

    if candidate_id and len(interviews) == 1 and not interviews[0].get("candidate_id"):
        interviews[0]["candidate_id"] = candidate_id
    generated_count = len(interviews)
    interview_result = _merge_interview_output(existing_output, interview_result)

    update_stage(pipeline_id, "interview_gen", "done", interview_result)
    update_interview_generation_task(
        task_id,
        status="done",
        progress=100,
        message=f"已为 {generated_count} 位候选人生成面试题",
    )
    interviews = interview_result.get("interviews", [])
    if interviews:
        interview_result["force_gen"] = force_gen  # 标记是否为降级生成
        summary_text = f"为{generated_count}人生成面试题"
        if force_gen:
            summary_text += " ⚠️降级"
        save_message(
            pipeline_id,
            "assistant",
            f"📝 面试题已生成：{generated_count}人" + ("（降级生成，候选人未达入围线）" if force_gen else ""),
            card_type="interview_card",
            card_data=interview_result,
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "interview_gen",
                "card": {"type": "interview_card", "data": interview_result, "summary": summary_text},
            },
            pipeline_id,
        )
    await broadcast({"type": "stage_done", "stage_id": "interview_gen", "stage_name": "面试题生成"}, pipeline_id)


# ============ 简历处理 ============


def _cross_batch_dedup(dedup_resumes: list, pipeline_id: str) -> tuple:
    """跨批次查重：与库中已有候选人同名（含批次内同名）→ 返回 (kept, removed)。

    规则：归一化姓名与流水线已有候选人（排除本批次自身已入库的记录、以及已标记
    duplicate 的记录）相同，或与本批次先前出现的姓名相同 → 视为重复，保留先出现的
    记录，移除后来的记录。占位名不参与。

    注1：本批简历在查重前已通过 save_candidate 入库（候选人 id 与简历 id 相同），
    必须按 id 排除本批自身，否则每份简历都会匹配到自己 → 整批被误删。
    注2：批内被 DedupAgent 移除的成员（status=duplicate）仍在 candidates 表，
    若不禁用它，幸存者会因与它同名而被误杀 → “留 1 删 1”变“两个全删”。
    """
    from app.talent_pool import PLACEHOLDER_NAMES, _normalize_for_fingerprint

    batch_ids = {r.get("id", "") for r in dedup_resumes if r.get("id")}
    existing_candidates = get_candidates(pipeline_id)
    existing_names = set()
    for c in existing_candidates:
        if c.get("id") in batch_ids:
            continue  # 当前批次自身已入库的记录，不作为“已有候选人”来源
        if c.get("status") == "duplicate":
            continue  # 已标记重复的记录（含本批被 DedupAgent 移除的成员），不作为来源
        n = _normalize_for_fingerprint(c.get("name", ""))
        if n and len(n) >= 2 and n not in PLACEHOLDER_NAMES:
            existing_names.add(n)

    batch_names = set()
    kept, removed = [], []
    for r in dedup_resumes:
        n = _normalize_for_fingerprint(r.get("name", ""))
        is_valid_name = bool(n) and len(n) >= 2 and n not in PLACEHOLDER_NAMES
        if is_valid_name and (n in existing_names or n in batch_names):
            removed.append(r)
            continue
        if is_valid_name:
            batch_names.add(n)
        kept.append(r)
    return kept, removed


async def process_imported_resumes(pipeline_id: str):
    """Process imported resumes through match + summary.

    Returns:
        dict with "status" ("ok"/"skipped") and "reason" on non-ok.
    """
    if processing_locks.get(pipeline_id):
        return {"status": "skipped", "reason": "匹配进行中，请等待当前匹配完成"}
    last_match = _match_cooldowns.get(pipeline_id, 0)
    if time.time() - last_match < COOLDOWN_SECONDS:
        return {"status": "skipped", "reason": f"匹配刚完成，请{int(COOLDOWN_SECONDS)}秒后再试"}
    if not pending_resumes.get(pipeline_id):
        return {"status": "skipped", "reason": "没有待匹配的简历，请先导入简历"}
    processing_locks[pipeline_id] = True
    return {"status": "ok"}


async def _do_process_imported_resumes(pipeline_id: str):
    """Actual resume processing logic: match + summary."""
    print(f"[DEBUG] _do_process START pid={pipeline_id}", flush=True)
    from app.db import create_stage
    from hr_harness.agents.match_agent import MatchAgent

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        return

    resumes = pending_resumes.get(pipeline_id, [])
    print(f"[DEBUG] Resumes count: {len(resumes)}", flush=True)
    if not resumes:
        print("[DEBUG] No resumes found, returning early", flush=True)
        return

    stages = get_stages(pipeline_id)
    existing_stage_ids = {s["stage_id"] for s in stages}
    match_stage = next((s for s in stages if s["stage_id"] == "match"), None)
    existing_match_output = _parse_stage_output(match_stage)
    is_re_match = bool(match_stage and existing_match_output.get("candidates"))

    update_pipeline(pipeline_id, "running")
    await broadcast({"type": "pipeline_resumed", "pipeline_id": pipeline_id, "source": "manual_match"}, pipeline_id)

    # 从阶段中获取 JD
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_output = _parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    # Get profile from profile_build stage (画像驱动评估)
    profile_stage = next((s for s in stages if s["stage_id"] == "profile_build"), None)
    profile_output = _parse_stage_output(profile_stage)
    profile = profile_output.get("profile", {})

    # 创建缺失的阶段（仅 crawl 和 match）
    for sid, sname in [("crawl", "简历获取"), ("match", "AI匹配")]:
        if sid not in existing_stage_ids:
            create_stage(pipeline_id, sid, sname)

    if is_re_match:
        existing_candidates = get_candidates(pipeline_id)
        existing_ids = {c["id"] for c in existing_candidates}
        new_resumes = [r for r in resumes if r["id"] not in existing_ids]
        for r in new_resumes:
            save_candidate(pipeline_id, r)

        if not new_resumes:
            save_message(pipeline_id, "assistant", "📥 没有新增简历，所有导入的简历已在之前匹配过。")
            await broadcast({"type": "stage_done", "stage_id": "match", "stage_name": "AI匹配"}, pipeline_id)
            return

        save_message(pipeline_id, "assistant", f"📥 新增{len(new_resumes)}份简历，开始匹配...")
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "crawl",
                "card": {
                    "type": "crawl_card",
                    "data": {"resumes": new_resumes, "resume_count": len(new_resumes)},
                    "summary": f"新增{len(new_resumes)}份简历",
                },
            },
            pipeline_id,
        )
        context = {
            "jd": jd,
            "resumes": new_resumes,
            "role": pipeline["role"],
            "pipeline_id": pipeline_id,
            "profile": profile,
        }
    else:
        crawl_output = {
            "resumes": resumes,
            "resume_count": len(resumes),
            "sources": list(set(r.get("source", "import") for r in resumes)),
            "status": "completed",
        }
        update_stage(pipeline_id, "crawl", "done", crawl_output)
        for r in resumes:
            save_candidate(pipeline_id, r)
        save_message(
            pipeline_id, "assistant", f"📥 导入了{len(resumes)}份简历", card_type="crawl_card", card_data=crawl_output
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "crawl",
                "card": {"type": "crawl_card", "data": crawl_output, "summary": f"导入{len(resumes)}份简历"},
            },
            pipeline_id,
        )
        await broadcast({"type": "stage_done", "stage_id": "crawl", "stage_name": "简历获取"}, pipeline_id)
        context = {
            "jd": jd,
            "resumes": resumes,
            "role": pipeline["role"],
            "pipeline_id": pipeline_id,
            "profile": profile,
        }

    print("[DEBUG] Building context...", flush=True)

    # === 查重 ===
    from hr_harness.agents.dedup_agent import DedupAgent

    dedup_resumes = new_resumes if is_re_match else resumes
    print(f"[DEBUG] Before dedup, resumes={len(dedup_resumes)}", flush=True)
    dedup_agent = DedupAgent()
    dedup_result = await dedup_agent.execute({"resumes": dedup_resumes})
    if dedup_result.get("duplicates"):
        dup_count = len(dedup_result["duplicates"])
        dedup_resumes, removed_resumes = DedupAgent.filter_duplicates(dedup_resumes, dedup_result["duplicates"])
        dedup_result["removed"] = [{"id": r.get("id", ""), "name": r.get("name", "")} for r in removed_resumes]
        for r in removed_resumes:
            update_candidate(r.get("id", ""), {"status": "duplicate"})
        if is_re_match:
            new_resumes = dedup_resumes
        else:
            resumes = dedup_resumes
        context["resumes"] = dedup_resumes
        first_name = dedup_resumes[0].get("name", "none") if dedup_resumes else "none"
        print(f"[DEBUG] After dedup: {first_name}", flush=True)
        save_message(
            pipeline_id,
            "assistant",
            f"⚠️ 发现 {dup_count} 组疑似重复简历，已过滤 {len(removed_resumes)} 份重复项",
            card_type="dedup_card",
            card_data=dedup_result,
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "dedup",
                "card": {
                    "type": "dedup_card",
                    "data": dedup_result,
                    "summary": f"{dup_count}组重复，过滤{len(removed_resumes)}份",
                },
            },
            pipeline_id,
        )

    # === 跨批次查重：与库中已有候选人（同一流水线已匹配过）同名 → 跳过 ===
    kept, removed_by_existing = _cross_batch_dedup(dedup_resumes, pipeline_id)
    if removed_by_existing:
        dedup_resumes = kept
        for r in removed_by_existing:
            update_candidate(r.get("id", ""), {"status": "duplicate"})
        if is_re_match:
            new_resumes = dedup_resumes
        else:
            resumes = dedup_resumes
        context["resumes"] = dedup_resumes
        dedup_result.setdefault("removed", [])
        dedup_result["removed"] = dedup_result["removed"] + [
            {"id": r.get("id", ""), "name": r.get("name", "")} for r in removed_by_existing
        ]
        save_message(
            pipeline_id,
            "assistant",
            f"⚠️ 跳过 {len(removed_by_existing)} 份与已有候选人重复的简历",
            card_type="dedup_card",
            card_data=dedup_result,
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "dedup",
                "card": {
                    "type": "dedup_card",
                    "data": dedup_result,
                    "summary": f"跳过{len(removed_by_existing)}份重复",
                },
            },
            pipeline_id,
        )

    # === 匹配 ===
    match_start_time = __import__("time").time()
    update_stage(pipeline_id, "match", "running", "")
    await broadcast({"type": "stage_start", "stage_id": "match", "stage_name": "AI匹配"}, pipeline_id)

    async def match_progress(msg: str):
        print(f"[Match] {msg}", flush=True)
        await broadcast({"type": "stage_progress", "stage_id": "match", "message": msg}, pipeline_id)

    match_agent = MatchAgent()
    match_agent._progress_cb = match_progress
    print("[DEBUG] Running MatchAgent...", flush=True)
    try:
        match_result = await match_agent.execute(context)
        print(
            f"[DEBUG] MatchAgent returned: type={type(match_result).__name__} keys={list(match_result.keys())[:5] if isinstance(match_result, dict) else 'N/A'}",
            flush=True,
        )
    except Exception as e:
        print(f"[DEBUG] MatchAgent ERROR: {e}", flush=True)
        print(f"[Match] ERROR: {e}", flush=True)
        import traceback

        traceback.print_exc()
        save_message(pipeline_id, "assistant", f"❌ AI匹配失败：{str(e)[:100]}。请点击「重新处理」重试。")
        await broadcast(
            {"type": "stage_error", "stage_id": "match", "error": f"AI匹配失败: {str(e)[:100]}"}, pipeline_id
        )
        return
    context["candidates"] = match_result.get("candidates", [])
    match_batch = datetime.now().strftime("%Y%m%dT%H%M%S")
    batch_thresholds = match_result.get("thresholds") or {}
    for candidate in context["candidates"]:
        candidate["match_batch"] = match_batch
        if batch_thresholds.get("shortlist_min") is not None:
            candidate["shortlist_min"] = int(batch_thresholds["shortlist_min"])

    for c in context["candidates"]:
        save_candidate(pipeline_id, c)

    persisted_match_result = (
        _merge_match_output(existing_match_output, match_result, match_batch) if is_re_match else match_result
    )
    persisted_match_result.setdefault("batch_thresholds", {})[match_batch] = dict(batch_thresholds)
    match_stage_status = "running" if persisted_match_result.get("workflow_status") == "review_pending" else "done"
    update_stage(pipeline_id, "match", match_stage_status, persisted_match_result)
    shortlisted = persisted_match_result.get("shortlisted", [])
    save_message(
        pipeline_id,
        "assistant",
        f"🎯 AI匹配完成：{len(shortlisted)}人入围",
        card_type="match_card",
        card_data=persisted_match_result,
    )
    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "match",
            "card": {"type": "match_card", "data": persisted_match_result, "summary": f"{len(shortlisted)}人入围"},
        },
        pipeline_id,
    )
    await broadcast({"type": "stage_done", "stage_id": "match", "stage_name": "AI匹配"}, pipeline_id)

    # 计算效率对比数据
    match_elapsed = __import__("time").time() - match_start_time
    resume_count = len(context.get("candidates", []))
    match_result["timing"] = {
        "ai_seconds": round(match_elapsed, 1),
        "hr_estimate_minutes": resume_count * 3,
        "speedup_factor": round((resume_count * 3 * 60) / max(match_elapsed, 1), 1),
    }

    # === 匹配总结 ===（先展示总结，再生成面试题）
    summary = _generate_match_summary(match_result, pipeline["role"])
    if summary:
        save_message(pipeline_id, "assistant", summary["text"], card_type="summary_card", card_data=summary["data"])
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "match",
                "card": {"type": "summary_card", "data": summary["data"], "summary": summary["text"]},
            },
            pipeline_id,
        )

    # 面试题生成 — 不再自动级联，由 HR 手动触发生成面试题
    # await _run_interview_gen(pipeline_id, match_result, jd, pipeline["role"])

    # 通知用户匹配完成，始终显示生成面试题按钮（无入围时附带警告）
    total_count = len(context.get("candidates", []))
    shortlist_min = match_result.get("thresholds", {}).get("shortlist_min", 70)
    if shortlisted:
        btn_html = (
            '<div class="card-v4" id="interview-gen-card" style="border-left:3px solid var(--primary)">'
            '<div class="card-v4-hd" style="display:flex;align-items:center;gap:6px">'
            '<div class="card-v4-ic" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff">'
            '<svg class="icon" width="14" height="14"><use href="#i-target"/></svg></div>'
            '<div><div class="card-v4-tt">✅ 匹配完成</div>'
            f'<div style="font-size:11px;color:var(--text2);margin-top:2px;font-weight:500">{len(shortlisted)} 位候选人入围</div></div>'
            "</div>"
            '<div class="card-v4-bd" style="padding-top:8px;display:flex;gap:8px;flex-wrap:wrap">'
            '<button class="btn btn-primary btn-sm" id="generate-interview-btn" '
            'onclick="generateInterviewQuestions()" '
            'style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;padding:8px 20px;font-size:13px">'
            "📝 生成面试题</button>"
            '<button class="btn btn-outline btn-sm" onclick="openResumeImport()" '
            'style="padding:8px 16px;font-size:13px">📤 继续导入简历</button>'
            "</div></div>",
        )
        save_message(
            pipeline_id,
            "assistant",
            f"匹配完成，{len(shortlisted)} 位候选人入围",
            card_type="interview_gen_prompt",
            card_data={"shortlisted_count": len(shortlisted), "html": btn_html},
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "interview_gen_prompt",
                "card": {
                    "type": "interview_gen_prompt",
                    "data": {"shortlisted_count": len(shortlisted), "html": btn_html},
                    "summary": f"{len(shortlisted)} 位候选人入围",
                },
            },
            pipeline_id,
        )
    else:
        # 无候选人入围，仍显示生成面试题按钮但附带警告
        btn_html = (
            '<div class="card-v4" id="interview-gen-card" style="border-left:3px solid #f59e0b">'
            '<div class="card-v4-hd" style="display:flex;align-items:center;gap:6px">'
            '<div class="card-v4-ic" style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff">'
            '<svg class="icon" width="14" height="14"><use href="#i-warning"/></svg></div>'
            '<div><div class="card-v4-tt">⚠️ 匹配完成 · 无候选人入围</div>'
            f'<div style="font-size:11px;color:var(--text2);margin-top:2px;font-weight:500">共{total_count}份简历，均未达到入围线（{shortlist_min}分）</div></div>'
            "</div>"
            '<div class="card-v4-bd" style="padding-top:8px">'
            '<div style="font-size:12px;color:#d97706;background:#fffbeb;padding:10px 14px;border-radius:8px;margin-bottom:10px;line-height:1.6">'
            "💡 不建议生成面试题。候选人均未达到入围标准，建议：<br>"
            "1. 导入更多符合条件的简历<br>"
            "2. 调整匹配标准后重新匹配</div>"
            '<div style="display:flex;gap:8px;flex-wrap:wrap">'
            '<button class="btn btn-outline btn-sm" id="generate-interview-btn" '
            'onclick="generateInterviewQuestions()" '
            'style="padding:8px 20px;font-size:13px;border-color:#f59e0b;color:#d97706">'
            "📝 仍然生成面试题</button>"
            '<button class="btn btn-outline btn-sm" onclick="openResumeImport()" '
            'style="padding:8px 16px;font-size:13px">📤 继续导入简历</button>'
            "</div></div></div>"
        )
        save_message(
            pipeline_id,
            "assistant",
            f"匹配完成，无候选人入围（共{total_count}份）",
            card_type="interview_gen_prompt",
            card_data={"shortlisted_count": 0, "html": btn_html},
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "interview_gen_prompt",
                "card": {
                    "type": "interview_gen_prompt",
                    "data": {"shortlisted_count": 0, "html": btn_html},
                    "summary": "无候选人入围",
                },
            },
            pipeline_id,
        )

    # 不自动完成，保持等待状态，等用户录用后再生成报告
    update_pipeline(pipeline_id, "waiting_for_resumes")
    await broadcast(
        {
            "type": "pipeline_done",
            "pipeline_id": pipeline_id,
            "role": pipeline["role"],
            "status": "waiting_for_resumes",
        },
        pipeline_id,
    )

    pending_resumes.pop(pipeline_id, None)
    clear_pending(pipeline_id, "resumes")
    _match_cooldowns[pipeline_id] = time.time()


# ============ 视频处理 ============


async def process_uploaded_videos(pipeline_id: str):
    """Process uploaded interview videos/transcripts through video agent -> report."""
    if processing_locks.get(pipeline_id):
        print(f"[Video] Pipeline {pipeline_id} already processing, skipping", flush=True)
        return
    processing_locks[pipeline_id] = True

    try:
        await _do_process_uploaded_videos(pipeline_id)
    finally:
        processing_locks.pop(pipeline_id, None)


async def _do_process_uploaded_videos(pipeline_id: str):
    """Actual video processing logic."""
    try:
        from hr_harness.agents.video_agent import VideoAgent

        pipeline = get_pipeline(pipeline_id)
        if not pipeline:
            print(f"[Video] Pipeline {pipeline_id} not found", flush=True)
            return

        videos = pending_videos.get(pipeline_id, [])
        if not videos:
            print(f"[Video] No videos for pipeline {pipeline_id}", flush=True)
            return

        print(f"[Video] Processing {len(videos)} videos for pipeline {pipeline_id}", flush=True)

        stages = get_stages(pipeline_id)
        candidates = get_candidates(pipeline_id)

        jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
        jd_output = _parse_stage_output(jd_stage)
        jd = jd_output.get("jd", {})

        interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
        interview_output = _parse_stage_output(interview_stage)
        interviews = interview_output.get("interviews", [])

        shortlisted = [c for c in candidates if c.get("status") == "shortlisted" or c.get("overall_score", 0) >= 70]
        if not shortlisted:
            shortlisted = candidates[:3]

        print(f"[Video] Found {len(shortlisted)} candidates, {len(interviews)} interviews", flush=True)

        update_pipeline(pipeline_id, "running")
        await broadcast({"type": "pipeline_resumed", "pipeline_id": pipeline_id, "source": "video_assess"}, pipeline_id)

        context = {
            "jd": jd,
            "candidates": shortlisted,
            "interviews": interviews,
            "role": pipeline["role"],
            "pipeline_id": pipeline_id,
            "videos": videos,
        }

        update_stage(pipeline_id, "video_assess", "running", {"status": "running"})
        await broadcast({"type": "stage_start", "stage_id": "video_assess", "stage_name": "视频评估"}, pipeline_id)

        async def video_progress(msg: str):
            print(f"[Video] {msg}", flush=True)
            await broadcast({"type": "stage_progress", "stage_id": "video_assess", "message": msg}, pipeline_id)

        video_agent = VideoAgent()
        video_agent._progress_cb = video_progress
        video_result = await video_agent.execute(context)
        context["assessments"] = video_result.get("assessments", [])

        print(f"[Video] Assessment done: {len(context['assessments'])} candidates", flush=True)

        for a in context["assessments"]:
            cid = a.get("candidate_id")
            if cid:
                update_candidate(cid, {"video_assessment": a})

        update_stage(pipeline_id, "video_assess", "done", video_result)
        save_message(
            pipeline_id,
            "assistant",
            f"视频评估完成：{len(context['assessments'])}人（基于真实面试记录）",
            card_type="assessment_card",
            card_data=video_result,
        )
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "video_assess",
                "card": {
                    "type": "assessment_card",
                    "data": video_result,
                    "summary": f"{len(context['assessments'])}人评估完成",
                },
            },
            pipeline_id,
        )
        await broadcast({"type": "stage_done", "stage_id": "video_assess", "stage_name": "视频评估"}, pipeline_id)

        # 不再自动级联到报告生成，由 HR 手动触发
        save_message(pipeline_id, "assistant", "💡 视频评估完成。可手动触发「生成录用报告」来生成最终报告。")
        await broadcast(
            {
                "type": "pipeline_done",
                "pipeline_id": pipeline_id,
                "role": pipeline["role"],
                "status": "waiting_for_resumes",
            },
            pipeline_id,
        )

        pending_videos.pop(pipeline_id, None)
        clear_pending(pipeline_id, "videos")
        print(f"[Video] Pipeline {pipeline_id} video assessment done, waiting for manual report", flush=True)

    except Exception as e:
        print(f"[Video] Error processing videos for {pipeline_id}: {e}", flush=True)
        import traceback

        traceback.print_exc()
        await broadcast(
            {"type": "stage_error", "stage_id": "video_assess", "error": f"视频处理失败: {str(e)[:100]}"}, pipeline_id
        )


async def skip_to_report(pipeline_id: str):
    """Skip video assessment and generate report directly."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        return

    stages = get_stages(pipeline_id)
    candidates = get_candidates(pipeline_id)

    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_output = _parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    interview_output = _parse_stage_output(interview_stage)
    interviews = interview_output.get("interviews", [])

    shortlisted = [c for c in candidates if c.get("status") == "shortlisted" or c.get("overall_score", 0) >= 70]
    if not shortlisted:
        shortlisted = candidates[:3]

    update_pipeline(pipeline_id, "running")

    update_stage(
        pipeline_id, "video_assess", "done", {"status": "skipped", "assessments": [], "message": "HR选择跳过视频评估"}
    )
    save_message(pipeline_id, "assistant", "⏭️ 跳过视频评估，直接生成录用报告")
    await broadcast({"type": "stage_done", "stage_id": "video_assess", "stage_name": "视频评估"}, pipeline_id)

    context = {
        "jd": jd,
        "candidates": shortlisted,
        "interviews": interviews,
        "role": pipeline["role"],
        "pipeline_id": pipeline_id,
        "assessments": [],
    }

    await run_report(pipeline_id, context, pipeline)


async def run_report(pipeline_id: str, context: dict, pipeline: dict):
    """Run the report stage."""
    from hr_harness.agents.report_agent import ReportAgent

    update_stage(pipeline_id, "report", "running", "")
    await broadcast({"type": "stage_start", "stage_id": "report", "stage_name": "录用报告"}, pipeline_id)

    async def report_progress(msg: str):
        print(f"[Report] {msg}", flush=True)
        await broadcast({"type": "stage_progress", "stage_id": "report", "message": msg}, pipeline_id)

    report_agent = ReportAgent()
    report_agent._progress_cb = report_progress
    report_result = await report_agent.execute(context)

    update_stage(pipeline_id, "report", "done", report_result)
    save_message(pipeline_id, "assistant", "📊 录用报告生成完成", card_type="report_card", card_data=report_result)
    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "report",
            "card": {"type": "report_card", "data": report_result, "summary": "录用决策完成"},
        },
        pipeline_id,
    )
    await broadcast({"type": "stage_done", "stage_id": "report", "stage_name": "录用报告"}, pipeline_id)
    update_pipeline(pipeline_id, "waiting_human")
    await broadcast(
        {"type": "pipeline_waiting_human", "pipeline_id": pipeline_id, "role": pipeline["role"]}, pipeline_id
    )
