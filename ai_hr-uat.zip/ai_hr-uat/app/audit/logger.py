"""集中日志系统 — DBLogHandler + get_logger 工厂。

控制台/文件输出统一由 ``app.log_config.configure_logging()`` 的 dictConfig
根 logger 承担；本模块只负责业务日志的数据库落库（system_logs 表）。
"""

import json
import logging
import os
import queue
import threading
import time
from datetime import datetime


class DBLogHandler(logging.Handler):
    """批量写入数据库的日志 handler。

    通过 queue.Queue + 后台守护线程实现非阻塞写入，
    500ms 或 50 条触发 flush，避免阻塞请求循环。
    """

    def __init__(self, flush_interval: float = 0.5, batch_size: int = 50):
        super().__init__()
        self._queue = queue.Queue()
        self._flush_interval = flush_interval
        self._batch_size = batch_size
        self._running = True

        self._thread = threading.Thread(target=self._drain_loop, daemon=True, name="db-log-writer")
        self._thread.start()

    def emit(self, record: logging.LogRecord):
        try:
            formatter = self.formatter or logging.Formatter()
            entry = {
                "timestamp": datetime.fromtimestamp(record.created).strftime("%Y-%m-%d %H:%M:%S"),
                "level": record.levelname,
                "source": getattr(record, "source", record.name),
                "message": self.format(record),
                "extra": json.dumps(
                    {
                        k: v
                        for k, v in record.__dict__.items()
                        if k not in logging.LogRecord("", 0, "", 0, "", None, None).__dict__
                        and k not in ("message", "msg", "args", "exc_info", "exc_text", "stack_info")
                    },
                    ensure_ascii=False,
                    default=str,
                ),
                "exception": formatter.formatException(record.exc_info) if record.exc_info else None,
            }
            self._queue.put(entry)
        except Exception:
            self.handleError(record)

    def _drain_loop(self):
        while self._running:
            time.sleep(self._flush_interval)
            self._flush()

    def _flush(self):
        batch = []
        while len(batch) < self._batch_size and not self._queue.empty():
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break

        if not batch:
            return

        try:
            from app.db import _write_lock, get_db

            with _write_lock:
                conn = get_db()
                conn.executemany(
                    "INSERT INTO system_logs (timestamp, level, source, message, extra, exception) VALUES (%(timestamp)s, %(level)s, %(source)s, %(message)s, %(extra)s, %(exception)s)",
                    batch,
                )
                conn.commit()
        except Exception:
            pass  # 日志写入失败不应影响主流程

    def close(self):
        self._running = False
        self._flush()
        super().close()


# 全局单例，避免重复创建线程
_handler: DBLogHandler = None
_loggers: dict = {}


def _get_handler() -> DBLogHandler:
    global _handler
    if _handler is None:
        _handler = DBLogHandler()
        _handler.setFormatter(logging.Formatter("%(message)s"))
    return _handler


def get_logger(name: str) -> logging.Logger:
    """获取业务 logger：输出经根 logger 到控制台和 logs/app.log，并批量落库。

    级别交由根 logger（LOG_LEVEL 环境变量）统一控制，这里不再单独设置。
    """
    if name in _loggers:
        return _loggers[name]

    logger = logging.getLogger(f"hr_os.{name}")
    logger.setLevel(logging.NOTSET)
    logger.propagate = True

    if not logger.handlers:
        if os.getenv("TESTING") != "1":
            logger.addHandler(_get_handler())

    _loggers[name] = logger
    return logger
