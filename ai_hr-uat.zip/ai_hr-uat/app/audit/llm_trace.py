"""全链路调用 trace 日志 — 为耗时定位提供"一次业务请求 → 多个 LLM 环节"的关联视图。

from __future__ import annotations

用法：
    1. 在业务入口（如海报生成）开启 trace 上下文：
        with llm_trace_context("poster_generate", pipeline_id="p1") as trace_id:
            ...  # 内部所有经 track_llm_call / hermes 的 LLM 调用自动记入该 trace
    2. 无 trace 上下文时，所有打点静默跳过（不影响收口统计）。
    3. 前端通过 /api/monitor/trace?trace_id=xxx 查询某次请求的完整调用链路。
"""

from __future__ import annotations

import threading
import time
import uuid

from app.db import _write_lock, get_db

# 线程本地 trace 上下文（async 单线程内可用；跨线程的后台任务不继承）
_TRACE_LOCAL = threading.local()


def current_trace_id() -> str | None:
    """当前线程活跃的 trace_id，无则返回 None。"""
    return getattr(_TRACE_LOCAL, "trace_id", None)


class llm_trace_context:
    """开启一个 trace 上下文；with 块内所有 LLM 调用记入同一 trace_id。

    支持嵌套：内层结束后恢复外层 trace_id。
    """

    def __init__(self, scope: str = "request", pipeline_id: str = ""):
        self._scope = scope
        self._pipeline_id = pipeline_id
        self.trace_id = f"{scope}_{uuid.uuid4().hex[:8]}"
        self._prev = None

    def __enter__(self):
        self._prev = getattr(_TRACE_LOCAL, "trace_id", None)
        _TRACE_LOCAL.trace_id = self.trace_id
        return self.trace_id

    def __exit__(self, exc_type, exc_val, exc_tb):
        _TRACE_LOCAL.trace_id = self._prev
        return False


def record_trace_step(
    step: str,
    model: str = "",
    status: str = "ok",
    latency_ms: int = 0,
    detail: str = "",
):
    """记一条 trace 环节。无活跃 trace 上下文时静默跳过。"""
    trace_id = current_trace_id()
    if not trace_id:
        return
    try:
        with _write_lock:
            conn = get_db()
            conn.execute(
                "INSERT INTO llm_trace (trace_id, step, model, status, latency_ms, detail) VALUES (%s,%s,%s,%s,%s,%s)",
                (trace_id, step, model, status, latency_ms, detail[:500]),
            )
            conn.commit()
    except Exception:
        pass  # 打点失败不影响主流程


class llm_trace_step:
    """在某 LLM 调用点记录单个环节（自动计时）。

    用法：
        with llm_trace_step("poster_generate", model="gpt-image-2") as st:
            st.status = "error: xxx"   # 可选标记失败
    """

    def __init__(self, step: str, model: str = "", detail: str = ""):
        self.step = step
        self.model = model
        self.detail = detail
        self.status = "ok"
        self._start = time.time()

    def __enter__(self):
        self._start = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        latency_ms = int((time.time() - self._start) * 1000)
        if exc_val is not None:
            self.status = f"error: {str(exc_val)[:200]}"
        record_trace_step(self.step, self.model, self.status, latency_ms, self.detail)
        return False
