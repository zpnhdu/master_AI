"""监控 API 路由 — 日志查询、Token 统计、审计事件、聚合面板"""

import csv
import io
import json
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Query
from fastapi.responses import StreamingResponse

from app.db import get_db

monitor_router = APIRouter(prefix="/api/monitor", tags=["monitor"])

_USAGE_DETAIL_SORT_COLUMNS = {
    "id": "id",
    "timestamp": "timestamp",
    "model": "model",
    "call_type": "call_type",
    "prompt_tokens": "prompt_tokens",
    "completion_tokens": "completion_tokens",
    "total_tokens": "total_tokens",
    "estimated_cost_usd": "estimated_cost_usd",
    "agent": "agent",
    "operation": "operation",
    "pipeline_id": "pipeline_id",
    "latency_ms": "latency_ms",
    "success": "success",
}


def _usage_detail_order(sort_by: str, sort_order: str) -> str:
    """Build a validated, stable ORDER BY clause for usage detail rows."""
    column = _USAGE_DETAIL_SORT_COLUMNS.get(sort_by, "id")
    direction = "ASC" if sort_order.lower() == "asc" else "DESC"
    if column == "id":
        return f"{column} {direction}"
    return f"{column} {direction}, id {direction}"


def _parse_row(row) -> dict:
    """将数据库行转为 dict，自动解析 JSON 字段"""
    d = dict(row)
    for key in ("extra", "details"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


@monitor_router.get("/logs")
async def get_logs(
    level: Optional[str] = None,
    source: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """查询系统日志"""
    conn = get_db()
    conditions = []
    params: list = []

    if level:
        conditions.append("level = %s")
        params.append(level.upper())
    if source:
        conditions.append("source = %s")
        params.append(source)
    if from_ts:
        conditions.append("timestamp >= %s")
        params.append(from_ts)
    if to_ts:
        conditions.append("timestamp <= %s")
        params.append(to_ts)
    if search:
        conditions.append("message LIKE %s")
        params.append(f"%{search}%")

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    total = conn.execute(f"SELECT COUNT(*) as c FROM system_logs{where}", params).fetchone()["c"]

    offset = (page - 1) * page_size
    rows = conn.execute(
        f"SELECT * FROM system_logs{where} ORDER BY id DESC LIMIT %s OFFSET %s",
        params + [page_size, offset],
    ).fetchall()

    return {
        "items": [_parse_row(r) for r in rows],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@monitor_router.get("/usage")
async def get_usage(
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    model: Optional[str] = None,
    agent: Optional[str] = None,
    call_type: Optional[str] = None,
    range: str = Query("", pattern="^(|day|week|month|custom)$"),
    granularity: str = Query("day", pattern="^(hour|day|week|month)$"),
):
    """Token 用量统计（支持日/周/月快捷窗口 + 按类型过滤）。

    range=day   → 今日，按小时曲线
    range=week  → 近7天，按天曲线
    range=month → 近30天，按天曲线
    range=custom → 由 from_ts/to_ts 决定窗口
    """
    conn = get_db()
    conditions = []
    params: list = []

    if range == "day":
        from_ts = datetime.now().strftime("%Y-%m-%d 00:00:00")
        if granularity == "day":
            granularity = "hour"
    elif range == "week":
        from_ts = (datetime.now() - timedelta(days=6)).strftime("%Y-%m-%d 00:00:00")
    elif range == "month":
        from_ts = (datetime.now() - timedelta(days=29)).strftime("%Y-%m-%d 00:00:00")

    if from_ts:
        conditions.append("timestamp >= %s")
        params.append(from_ts)
    if to_ts:
        conditions.append("timestamp <= %s")
        params.append(to_ts)
    if model:
        conditions.append("model = %s")
        params.append(model)
    if agent:
        conditions.append("agent = %s")
        params.append(agent)
    if call_type:
        conditions.append("call_type = %s")
        params.append(call_type)

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    # 汇总统计
    summary_row = conn.execute(
        f"""SELECT
            COUNT(*) as call_count,
            COALESCE(SUM(prompt_tokens), 0) as total_prompt,
            COALESCE(SUM(completion_tokens), 0) as total_completion,
            COALESCE(SUM(total_tokens), 0) as total_tokens,
            COALESCE(SUM(estimated_cost_usd), 0) as total_cost,
            COALESCE(AVG(CASE WHEN success = 1 THEN 1.0 ELSE 0.0 END), 0) as success_rate
        FROM llm_usage{where}""",
        params,
    ).fetchone()

    # 按模型分组
    by_model_rows = conn.execute(
        f"""SELECT model,
            COUNT(*) as call_count,
            COALESCE(SUM(total_tokens), 0) as tokens,
            COALESCE(SUM(estimated_cost_usd), 0) as cost
        FROM llm_usage{where} GROUP BY model ORDER BY cost DESC""",
        params,
    ).fetchall()

    by_model = {
        row["model"]: {
            "call_count": row["call_count"],
            "total_tokens": row["tokens"],
            "estimated_cost_usd": round(row["cost"], 6),
        }
        for row in by_model_rows
    }

    # 按类型分组
    by_type_rows = conn.execute(
        f"""SELECT call_type,
            COUNT(*) as call_count,
            COALESCE(SUM(total_tokens), 0) as tokens,
            COALESCE(SUM(estimated_cost_usd), 0) as cost
        FROM llm_usage{where} GROUP BY call_type ORDER BY cost DESC""",
        params,
    ).fetchall()

    by_type = {
        row["call_type"]: {
            "call_count": row["call_count"],
            "total_tokens": row["tokens"],
            "estimated_cost_usd": round(row["cost"], 6),
        }
        for row in by_type_rows
    }

    # 时间序列（按粒度生成 DATE_FORMAT 时间桶）
    date_format = {"hour": "%Y-%m-%d %H:00", "day": "%Y-%m-%d", "week": "%X-W%V", "month": "%Y-%m"}
    fmt = date_format.get(granularity, "%Y-%m-%d")

    timeseries_rows = conn.execute(
        f"""SELECT
            DATE_FORMAT(timestamp, %s) as bucket,
            COUNT(*) as call_count,
            COALESCE(SUM(prompt_tokens), 0) as prompt_tokens,
            COALESCE(SUM(completion_tokens), 0) as completion_tokens,
            COALESCE(SUM(estimated_cost_usd), 0) as cost_usd
        FROM llm_usage{where}
        GROUP BY bucket ORDER BY bucket""",
        [fmt] + params,
    ).fetchall()

    return {
        "summary": {
            "total_calls": summary_row["call_count"],
            "total_prompt_tokens": summary_row["total_prompt"],
            "total_completion_tokens": summary_row["total_completion"],
            "total_tokens": summary_row["total_tokens"],
            "total_estimated_cost_usd": round(summary_row["total_cost"], 6),
            "success_rate": round(summary_row["success_rate"] * 100, 1),
            "by_model": by_model,
            "by_type": by_type,
        },
        "timeseries": [
            {
                "bucket": row["bucket"],
                "call_count": row["call_count"],
                "prompt_tokens": row["prompt_tokens"],
                "completion_tokens": row["completion_tokens"],
                "cost_usd": round(row["cost_usd"], 6),
            }
            for row in timeseries_rows
        ],
    }


@monitor_router.get("/usage/detail")
async def get_usage_detail(
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    model: Optional[str] = None,
    agent: Optional[str] = None,
    operation: Optional[str] = None,
    call_type: Optional[str] = None,
    pipeline_id: Optional[str] = None,
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    format: str = Query("json", pattern="^(json|csv)$"),
    sort_by: str = "",
    sort_order: str = "desc",
):
    """Token 消耗明细分页查询；format=csv 导出全量（忽略分页）。"""
    conn = get_db()
    conditions = []
    params: list = []

    if from_ts:
        conditions.append("timestamp >= %s")
        params.append(from_ts)
    if to_ts:
        conditions.append("timestamp <= %s")
        params.append(to_ts)
    if model:
        conditions.append("model = %s")
        params.append(model)
    if agent:
        conditions.append("agent = %s")
        params.append(agent)
    if operation:
        conditions.append("operation = %s")
        params.append(operation)
    if call_type:
        conditions.append("call_type = %s")
        params.append(call_type)
    if pipeline_id:
        conditions.append("pipeline_id = %s")
        params.append(pipeline_id)
    if search:
        conditions.append("(model LIKE %s OR agent LIKE %s OR operation LIKE %s OR pipeline_id LIKE %s)")
        like = f"%{search}%"
        params.extend([like, like, like, like])

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    total = conn.execute(f"SELECT COUNT(*) as c FROM llm_usage{where}", params).fetchone()["c"]
    order_by = _usage_detail_order(sort_by, sort_order)

    if format == "csv":
        # 导出全量（上限 50 万行，防误导出拖垮服务）
        rows = conn.execute(
            f"""SELECT id, timestamp, model, call_type, prompt_tokens, completion_tokens,
                       total_tokens, estimated_cost_usd, agent, operation, pipeline_id,
                       latency_ms, success
                FROM llm_usage{where} ORDER BY {order_by} LIMIT 500000""",
            params,
        ).fetchall()

        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(
            [
                "id",
                "时间",
                "模型",
                "类型",
                "Prompt Tokens",
                "Completion Tokens",
                "总 Tokens",
                "估算费用 USD",
                "调用方",
                "场景",
                "Pipeline",
                "耗时 ms",
                "成功",
            ]
        )
        for r in rows:
            writer.writerow(
                [
                    r["id"],
                    r["timestamp"],
                    r["model"],
                    r["call_type"],
                    r["prompt_tokens"],
                    r["completion_tokens"],
                    r["total_tokens"],
                    r["estimated_cost_usd"],
                    r["agent"],
                    r["operation"],
                    r["pipeline_id"],
                    r["latency_ms"],
                    "成功" if r["success"] else "失败",
                ]
            )
        filename = f"llm_usage_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        return StreamingResponse(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    offset = (page - 1) * page_size
    rows = conn.execute(
        f"""SELECT id, timestamp, model, call_type, prompt_tokens, completion_tokens,
                   total_tokens, estimated_cost_usd, agent, operation, pipeline_id,
                   latency_ms, success
            FROM llm_usage{where} ORDER BY {order_by} LIMIT %s OFFSET %s""",
        params + [page_size, offset],
    ).fetchall()

    return {
        "items": [dict(r) for r in rows],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@monitor_router.get("/trace")
async def get_trace(trace_id: str):
    """查询某次业务请求（如海报生成）的完整 LLM 调用链路，用于耗时定位。"""
    conn = get_db()
    rows = conn.execute(
        """SELECT id, trace_id, step, model, status, latency_ms, detail, created_at
        FROM llm_trace WHERE trace_id = %s ORDER BY id""",
        (trace_id,),
    ).fetchall()

    total_latency = sum((r["latency_ms"] or 0) for r in rows)
    return {
        "trace_id": trace_id,
        "steps": [dict(r) for r in rows],
        "total_latency_ms": total_latency,
        "step_count": len(rows),
    }


@monitor_router.get("/events")
async def get_events(
    event_type: Optional[str] = None,
    entity_type: Optional[str] = None,
    from_ts: Optional[str] = None,
    to_ts: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """查询审计事件"""
    conn = get_db()
    conditions = []
    params: list = []

    if event_type:
        conditions.append("event_type = %s")
        params.append(event_type)
    if entity_type:
        conditions.append("entity_type = %s")
        params.append(entity_type)
    if from_ts:
        conditions.append("timestamp >= %s")
        params.append(from_ts)
    if to_ts:
        conditions.append("timestamp <= %s")
        params.append(to_ts)

    where = " WHERE " + " AND ".join(conditions) if conditions else ""

    total = conn.execute(f"SELECT COUNT(*) as c FROM audit_events{where}", params).fetchone()["c"]

    offset = (page - 1) * page_size
    rows = conn.execute(
        f"SELECT * FROM audit_events{where} ORDER BY id DESC LIMIT %s OFFSET %s",
        params + [page_size, offset],
    ).fetchall()

    return {
        "items": [_parse_row(r) for r in rows],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@monitor_router.get("/dashboard")
async def get_dashboard():
    """聚合面板 — 24h 汇总 + 最近错误 + 最近事件"""
    conn = get_db()

    # 24h LLM 统计
    usage_row = conn.execute(
        """SELECT COUNT(*) as call_count,
           COALESCE(SUM(total_tokens), 0) as total_tokens,
           COALESCE(SUM(estimated_cost_usd), 0) as total_cost
        FROM llm_usage WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 1 DAY)"""
    ).fetchone()

    # 24h 错误数
    error_count = conn.execute(
        "SELECT COUNT(*) as c FROM system_logs WHERE level IN ('ERROR','CRITICAL') AND timestamp >= DATE_SUB(NOW(), INTERVAL 1 DAY)"
    ).fetchone()["c"]

    # 24h 审计事件数
    event_count = conn.execute(
        "SELECT COUNT(*) as c FROM audit_events WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 1 DAY)"
    ).fetchone()["c"]

    # 最近 5 条错误
    error_rows = conn.execute(
        "SELECT * FROM system_logs WHERE level IN ('ERROR','CRITICAL') ORDER BY id DESC LIMIT 5"
    ).fetchall()

    # 最近 10 条审计事件
    event_rows = conn.execute("SELECT * FROM audit_events ORDER BY id DESC LIMIT 10").fetchall()

    # 按模型费用分布
    cost_rows = conn.execute(
        """SELECT model, COALESCE(SUM(estimated_cost_usd), 0) as cost
        FROM llm_usage GROUP BY model ORDER BY cost DESC"""
    ).fetchall()

    return {
        "last_24h": {
            "total_llm_calls": usage_row["call_count"],
            "total_tokens": usage_row["total_tokens"],
            "total_cost_usd": round(usage_row["total_cost"], 6),
            "error_count": error_count,
            "pipeline_events": event_count,
        },
        "recent_errors": [_parse_row(r) for r in error_rows],
        "recent_events": [_parse_row(r) for r in event_rows],
        "cost_by_model": {row["model"]: round(row["cost"], 6) for row in cost_rows},
    }
