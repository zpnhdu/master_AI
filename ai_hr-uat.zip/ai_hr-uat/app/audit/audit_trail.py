"""操作审计 — 记录 HR 业务事件到 audit_events 表"""

import json

from app.db import _write_lock, get_db


def audit(
    event_type: str,
    summary: str,
    actor: str = "system",
    entity_type: str = None,
    entity_id: str = None,
    details: dict = None,
):
    """记录一条操作审计事件。

    同步函数，不抛异常 — 记录失败不影响主流程。
    使用 _write_lock 防止与活跃事务冲突。
    """
    try:
        with _write_lock:
            conn = get_db()
            conn.execute(
                """INSERT INTO audit_events
                   (event_type, summary, actor, entity_type, entity_id, details)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (event_type, summary, actor, entity_type, entity_id, json.dumps(details or {}, ensure_ascii=False)),
            )
            # 仅在没有活跃事务时才提交（避免提交外层事务）
            if not conn.in_transaction:
                conn.commit()
    except Exception:
        pass  # 审计记录失败不应影响主流程
