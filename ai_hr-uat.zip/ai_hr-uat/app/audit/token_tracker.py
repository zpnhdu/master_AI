"""Token 用量追踪 — 记录每次 LLM/生图调用的 token 消耗和估算费用"""

from contextlib import contextmanager

from app.db import _write_lock, get_db

# 模型定价（USD per 1M tokens，近似值）
PRICING = {
    "qwen-plus": {"input": 0.80, "output": 2.00},
    "qwen3.6-flash": {"input": 0.10, "output": 0.30},
    "qwen3.7-max": {"input": 1.20, "output": 3.60},
    "qwen-vl-max": {"input": 1.00, "output": 3.00},
    "qwen-image-2.0-pro": {"input": 0, "output": 0.04},
}

# 未知模型的默认价格（按最贵的算）
_DEFAULT_PRICING = {"input": 0.80, "output": 2.00}

# 生图按张估算费用（USD per image）。OpenAI 兼容 images API 通常不返回 usage，
# 无真实 usage 时按此定价表估算，支撑成本核算与对账。
IMAGE_PRICING = {
    "gpt-image-2": 0.02,
    "gpt-image-2-client": 0.02,
    "gpt-image-2-client-4K": 0.08,
    "gpt-image-2-high": 0.06,
    "gpt-image-2-medium": 0.03,
    "gpt-image-2-low": 0.015,
    "gpt-image-1": 0.02,
    "qwen-image": 0.02,
    "wanx": 0.02,
    "nn147": 0.02,
    "default": 0.02,
}

# 生图 image tokens 估算（API 未返回 usage 时）：按面积折算，1024x1024 ≈ 1024 tokens
_IMAGE_TOKENS_PER_MP = 1.0  # 每 1024*1024 像素对应的 Token 数


def estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    """根据模型和 token 数估算费用（USD）"""
    rates = PRICING.get(model, _DEFAULT_PRICING)
    return (prompt_tokens * rates["input"] + completion_tokens * rates["output"]) / 1_000_000


def estimate_image_tokens(width: int = 1024, height: int = 1024) -> int:
    """生图 image tokens 估算：按面积折算，API 未返回 usage 时使用"""
    if width <= 0 or height <= 0:
        return 0
    return max(1, int(width * height / 1024 * _IMAGE_TOKENS_PER_MP))


def estimate_image_cost(model: str, width: int = 1024, height: int = 1024, cost_usd: float = None) -> float:
    """生图费用估算：优先外部传入真实值（如 billing tokens），否则按张定价表"""
    if cost_usd is not None:
        return float(cost_usd)
    # 按面积缩放：1024x1024 为基准价
    base = IMAGE_PRICING.get(model, IMAGE_PRICING["default"])
    if width <= 0 or height <= 0:
        return base
    return round(base * (width * height) / (1024 * 1024), 6)


def record_usage(
    model: str,
    token_usage: dict,
    agent: str = None,
    operation: str = None,
    pipeline_id: str = None,
    latency_ms: int = None,
    success: bool = True,
    call_type: str = "text",
):
    """记录一次 LLM 调用的 token 用量到 llm_usage 表。

    设计为同步函数，由调用方决定是否 await（通过 asyncio.to_thread 包装）。
    不抛异常 — 记录失败不影响主流程。
    使用 _write_lock 防止与活跃事务冲突。
    call_type: text / image / audio / video，用于生图与文本分账。
    """
    try:
        prompt_tokens = int(token_usage.get("prompt_tokens", 0))
        completion_tokens = int(token_usage.get("completion_tokens", 0))
        total_tokens = int(token_usage.get("total_tokens", prompt_tokens + completion_tokens))
        cost = float(token_usage.get("estimated_cost_usd") or estimate_cost(model, prompt_tokens, completion_tokens))

        with _write_lock:
            conn = get_db()
            conn.execute(
                """INSERT INTO llm_usage
                   (model, call_type, prompt_tokens, completion_tokens, total_tokens,
                    estimated_cost_usd, agent, operation, pipeline_id, latency_ms, success)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    model,
                    call_type,
                    prompt_tokens,
                    completion_tokens,
                    total_tokens,
                    cost,
                    agent,
                    operation,
                    pipeline_id,
                    latency_ms,
                    1 if success else 0,
                ),
            )
            conn.commit()
    except Exception:
        pass  # 记录失败不应影响主流程


def record_image_usage(
    model: str,
    *,
    agent: str = None,
    operation: str = None,
    pipeline_id: str = None,
    latency_ms: int = None,
    success: bool = True,
    width: int = 1024,
    height: int = 1024,
    image_tokens: int = None,
    cost_usd: float = None,
):
    """记录一次生图调用（call_type=image）。

    - image_tokens: API 真实返回的 image tokens（部分 OpenAI 兼容网关有 billing tokens），
      未提供时按面积估算。
    - cost_usd: 真实费用，未提供时按 IMAGE_PRICING 按张估算。
    """
    tokens = image_tokens if image_tokens is not None else estimate_image_tokens(width, height)
    cost = cost_usd if cost_usd is not None else estimate_image_cost(model, width, height)
    record_usage(
        model=model,
        token_usage={
            "prompt_tokens": 0,
            "completion_tokens": tokens,
            "total_tokens": tokens,
            "estimated_cost_usd": cost,
        },
        agent=agent,
        operation=operation,
        pipeline_id=pipeline_id,
        latency_ms=latency_ms,
        success=success,
        call_type="image",
    )


class _TrackContext:
    """track_llm_call 上下文中暴露给业务代码的句柄。"""

    __slots__ = (
        "usage",
        "image_tokens",
        "cost_usd",
        "success",
        "width",
        "height",
        "error",
    )

    def __init__(self):
        self.usage = None
        self.image_tokens = None
        self.cost_usd = None
        self.success = True
        self.width = 1024
        self.height = 1024
        self.error = ""


@contextmanager
def track_llm_call(
    model: str,
    *,
    agent: str = None,
    operation: str = None,
    pipeline_id: str = None,
    call_type: str = "text",
):
    """统一大模型/生图调用打点：自动计时 + 成败都记 usage。

    用法（直接 requests.post 的收口点）：

        with track_llm_call("qwen-vl-max", agent="x", operation="analyze_image", call_type="image") as t:
            resp = requests.post(...)
            if resp.status_code >= 400:
                t.success = False
            else:
                t.usage = resp.json().get("usage", {})   # 文本调用：真实 usage
                # 生图调用：t.image_tokens / t.cost_usd / t.width / t.height

    退出时自动写入 llm_usage（成功/失败各记一条，失败时 token 为 0）。
    注意：hermes_wrapper.client 内部已自行 record_usage，不要在此处重复包。
    """
    import time as _time

    start = _time.time()
    ctx = _TrackContext()
    try:
        yield ctx
    except Exception as exc:  # noqa: BLE001 - 打点不应吞掉业务异常
        ctx.success = False
        ctx.error = str(exc)[:500]
        raise
    finally:
        latency_ms = int((_time.time() - start) * 1000)
        try:
            if call_type == "image":
                record_image_usage(
                    model,
                    agent=agent,
                    operation=operation,
                    pipeline_id=pipeline_id,
                    latency_ms=latency_ms,
                    success=ctx.success,
                    width=ctx.width,
                    height=ctx.height,
                    image_tokens=ctx.image_tokens,
                    cost_usd=ctx.cost_usd,
                )
            else:
                record_usage(
                    model,
                    ctx.usage or {},
                    agent=agent,
                    operation=operation,
                    pipeline_id=pipeline_id,
                    latency_ms=latency_ms,
                    success=ctx.success,
                    call_type=call_type,
                )
        except Exception:
            pass  # 打点失败不影响主流程
        # 全链路 trace 环节（无活跃 trace 上下文时静默跳过）
        try:
            from app.audit.llm_trace import record_trace_step

            record_trace_step(
                operation or "llm_call",
                model=model,
                status=(f"error: {ctx.error[:200]}" if not ctx.success else "ok"),
                latency_ms=latency_ms,
                detail=f"call_type={call_type}",
            )
        except Exception:
            pass
