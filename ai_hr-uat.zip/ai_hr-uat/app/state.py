"""Shared application state and broadcast helper.

Extracted from main.py to avoid circular imports when splitting modules.
"""

from fastapi import WebSocket

# WebSocket 连接与订阅跟踪
connections: list[WebSocket] = []
_ws_subscriptions: dict[WebSocket, set] = {}  # {WebSocket: 流水线 ID 集合}

# 内存中的待处理数据（由数据库持久化，保证重启安全）
pending_resumes: dict[str, list] = {}
pending_videos: dict[str, list] = {}
processing_locks: dict[str, bool] = {}

# Chrome 扩展会话存储
chrome_sessions: dict[str, dict] = {}

# 内存中的面试问题生成任务。阶段输出仍是持久化事实来源；
# 此注册表为界面提供可精确轮询的任务。
interview_generation_tasks: dict[str, dict] = {}

# 批量面试监控 WebSocket 客户端：pipeline_id -> set(websocket)
monitor_clients: dict[str, set] = {}
# 批量面试候选人 WebSocket 客户端：token -> websocket
candidate_clients: dict[str, object] = {}


# 关键消息类型 — 不检查订阅，广播到所有客户端
# stage_card/stage_done/pipeline_done 是 REST API 触发的自动匹配结果，
# 客户端可能在刷新后未订阅，但仍需收到这些更新
_ALWAYS_BROADCAST = {"stage_card", "stage_done", "pipeline_done", "pipeline_completed", "pipeline_resumed"}


async def broadcast(data: dict, pipeline_id: str = None):
    """Send data to WebSocket clients. If pipeline_id is set, only send to subscribed clients.

    Key status messages (stage_card, stage_done, pipeline_done, etc.) bypass the
    subscription check so that REST API-triggered updates reach all clients.
    """
    msg_type = data.get("type", "")
    require_sub = pipeline_id is not None and msg_type not in _ALWAYS_BROADCAST
    for conn in list(connections):
        if require_sub:
            subs = _ws_subscriptions.get(conn, set())
            if pipeline_id not in subs:
                continue
        try:
            await conn.send_json(data)
        except (RuntimeError, Exception):
            if conn in connections:
                connections.remove(conn)
            _ws_subscriptions.pop(conn, None)


# 延迟初始化单例，避免导入时产生副作用
_supervisor = None
_action_handler = None


def get_supervisor():
    global _supervisor
    if _supervisor is None:
        from hr_harness.orchestrator import SupervisorAgent

        _supervisor = SupervisorAgent()
    return _supervisor


def get_action_handler():
    global _action_handler
    if _action_handler is None:
        from app.action_handler import ActionHandler

        _action_handler = ActionHandler()
    return _action_handler
