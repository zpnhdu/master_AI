"""Deterministic behavioral scoring for open-ended written-test answers."""

from __future__ import annotations

from typing import Any

WRITTEN_SCORING_VERSION = "written_v2"

WRITTEN_DIMENSIONS = {
    "岗位要点": 0.35,
    "专业准确性": 0.25,
    "分析逻辑": 0.15,
    "方案可执行性": 0.15,
    "证据与边界": 0.10,
}


def _difficulty_expectation(difficulty: str) -> str:
    normalized = (difficulty or "").strip().lower()
    if normalized in {"困难", "高", "hard"}:
        return "需要处理复杂约束、关键权衡、量化结果及潜在风险"
    if normalized in {"简单", "低", "easy"}:
        return "需要正确说明核心概念、基本步骤和直接结论"
    return "需要结合业务情境说明判断依据、实施步骤和预期结果"


def _default_written_criteria(question: dict) -> list[dict]:
    expected_points = [str(point).strip() for point in question.get("expected_points", []) if str(point).strip()]
    points_text = "、".join(expected_points) if expected_points else "题目要求的核心内容"
    expectation = _difficulty_expectation(str(question.get("difficulty") or ""))
    return [
        {
            "id": "job_coverage",
            "name": "岗位要点匹配",
            "dimension": "岗位要点",
            "weight": WRITTEN_DIMENSIONS["岗位要点"],
            "anchors": {
                "0": f"未回答或内容与{points_text}无关",
                "1": f"仅零散提到{points_text}中的个别词语，没有实质说明",
                "2": f"覆盖部分要点，但关键内容缺失或展开不足；{expectation}",
                "3": f"覆盖大部分核心要点，说明较具体，基本满足题目要求；{expectation}",
                "4": f"完整覆盖核心要点或给出等价的高质量答案，并清楚说明依据、取舍与结果；{expectation}",
            },
        },
        {
            "id": "professional_accuracy",
            "name": "专业准确性",
            "dimension": "专业准确性",
            "weight": WRITTEN_DIMENSIONS["专业准确性"],
            "anchors": {
                "0": "核心概念或结论明显错误，无法支持岗位判断",
                "1": "存在较多专业错误，主要依赖空泛表述",
                "2": "基本概念正确，但关键判断、数据口径或方法存在不足",
                "3": "专业判断总体准确，方法适用，只有次要遗漏",
                "4": "专业判断准确严谨，能说明适用条件、关键假设及例外情况",
            },
        },
        {
            "id": "analytical_logic",
            "name": "分析逻辑",
            "dimension": "分析逻辑",
            "weight": WRITTEN_DIMENSIONS["分析逻辑"],
            "anchors": {
                "0": "没有形成可理解的分析过程",
                "1": "观点堆砌，前后关系不清，结论缺少依据",
                "2": "有基本结构，但因果链、优先级或关键推导不完整",
                "3": "结构清楚，能从问题拆解到结论，主要推导有依据",
                "4": "分析层次清晰，能比较方案、处理权衡并验证关键假设",
            },
        },
        {
            "id": "solution_feasibility",
            "name": "方案可执行性",
            "dimension": "方案可执行性",
            "weight": WRITTEN_DIMENSIONS["方案可执行性"],
            "anchors": {
                "0": "没有提出有效方案或结论",
                "1": "只有方向性口号，没有具体动作",
                "2": "提出基本步骤，但缺少资源、优先级、指标或落地条件",
                "3": "方案步骤明确，包含关键资源、优先级或验证指标，可实际执行",
                "4": "方案完整可执行，明确阶段、负责人或资源、衡量指标及调整机制",
            },
        },
        {
            "id": "evidence_boundaries",
            "name": "证据与边界",
            "dimension": "证据与边界",
            "weight": WRITTEN_DIMENSIONS["证据与边界"],
            "anchors": {
                "0": "没有任何依据，或使用明显虚构、矛盾的信息",
                "1": "仅给出主观判断，没有案例、数据、验证方式或边界说明",
                "2": "有少量依据，但证据较弱，未说明风险或适用边界",
                "3": "提供了可信案例、数据或验证方法，并识别主要风险或边界",
                "4": "证据充分可核验，主动说明数据口径、限制条件、风险及复盘方式",
            },
        },
    ]


def build_written_rubric(question: dict) -> dict:
    """Build or normalize a frozen written-test rubric for one question."""
    raw = question.get("written_scoring_rubric")
    raw_criteria = raw.get("criteria") if isinstance(raw, dict) else None
    criteria = []
    if isinstance(raw_criteria, list) and raw.get("version") == WRITTEN_SCORING_VERSION:
        for expected in _default_written_criteria(question):
            item = next(
                (
                    candidate
                    for candidate in raw_criteria
                    if isinstance(candidate, dict) and candidate.get("id") == expected["id"]
                ),
                None,
            )
            if not item:
                criteria = []
                break
            anchors = item.get("anchors") if isinstance(item.get("anchors"), dict) else {}
            criteria.append(
                {
                    **expected,
                    "anchors": {
                        str(level): str(anchors.get(str(level)) or expected["anchors"][str(level)])
                        for level in range(5)
                    },
                }
            )
    if not criteria:
        criteria = _default_written_criteria(question)
    return {"version": WRITTEN_SCORING_VERSION, "criteria": criteria}


def zero_written_answer(rubric: dict) -> dict:
    """Return a complete, deterministic zero result for an unanswered question."""
    criteria = [
        {
            "id": item["id"],
            "name": item["name"],
            "dimension": item["dimension"],
            "weight": item["weight"],
            "level": 0,
            "score": 0,
            "evidence": "未作答",
            "confidence": 1.0,
        }
        for item in rubric["criteria"]
    ]
    return {
        "score": 0,
        "comment": "未作答",
        "candidate_feedback": "请完整作答并说明判断依据。",
        "hit_points": [],
        "missed_points": [item["name"] for item in criteria],
        "criteria": criteria,
        "scoring_confidence": 1.0,
        "rubric_version": WRITTEN_SCORING_VERSION,
        "eval_failed": False,
    }


def technical_failure_written_answer(rubric: dict, reason: str) -> dict:
    """Return a complete zero result when automatic scoring was unavailable."""
    criteria = [
        {
            "id": item["id"],
            "name": item["name"],
            "dimension": item["dimension"],
            "weight": item["weight"],
            "level": 0,
            "score": 0,
            "evidence": f"系统异常：{reason}",
            "confidence": 0.0,
        }
        for item in rubric["criteria"]
    ]
    return {
        "score": 0,
        "comment": f"本题未能完成自动评分：{reason}。已按 0 分计入总分。",
        "candidate_feedback": "",
        "hit_points": [],
        "missed_points": [item["name"] for item in criteria],
        "criteria": criteria,
        "scoring_confidence": 0.0,
        "rubric_version": WRITTEN_SCORING_VERSION,
        "technical_failure": True,
        "failure_reason": reason,
        "eval_failed": False,
    }


def score_written_model_result(rubric: dict, result: dict) -> dict:
    """Validate model levels and compute the question score in code."""
    raw_criteria = result.get("criteria") if isinstance(result, dict) else None
    if not isinstance(raw_criteria, list):
        reason = (
            str(result.get("failure_reason") or "missing written criteria assessments")
            if isinstance(result, dict)
            else "missing written criteria assessments"
        )
        raise ValueError(reason[:300])
    by_id = {
        str(item.get("id")): item for item in raw_criteria if isinstance(item, dict) and item.get("id") is not None
    }
    criteria = []
    weighted_score = 0.0
    weighted_confidence = 0.0
    for expected in rubric["criteria"]:
        assessment = by_id.get(expected["id"])
        if not assessment:
            raise ValueError(f"missing criterion {expected['id']}")
        level = assessment.get("level")
        confidence = assessment.get("confidence")
        if not isinstance(level, (int, float)) or isinstance(level, bool) or level not in (0, 1, 2, 3, 4):
            raise ValueError(f"invalid level for {expected['id']}")
        if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not 0 <= confidence <= 1:
            raise ValueError(f"invalid confidence for {expected['id']}")
        evidence = str(assessment.get("evidence") or "").strip()
        if level >= 3 and not evidence:
            confidence = min(float(confidence), 0.49)
        criterion_score = round(float(level) / 4 * 100)
        weighted_score += criterion_score * expected["weight"]
        weighted_confidence += float(confidence) * expected["weight"]
        criteria.append(
            {
                "id": expected["id"],
                "name": expected["name"],
                "dimension": expected["dimension"],
                "weight": expected["weight"],
                "level": int(level),
                "score": criterion_score,
                "evidence": evidence,
                "confidence": round(float(confidence), 3),
            }
        )

    overall_confidence = result.get("overall_confidence")
    if (
        isinstance(overall_confidence, (int, float))
        and not isinstance(overall_confidence, bool)
        and 0 <= overall_confidence <= 1
    ):
        scoring_confidence = min(float(overall_confidence), weighted_confidence)
    else:
        scoring_confidence = weighted_confidence

    output = {
        "score": round(weighted_score),
        "comment": str(result.get("comment") or "已按笔试行为锚点完成证据化评分。"),
        "candidate_feedback": str(result.get("candidate_feedback") or ""),
        "hit_points": [item["name"] for item in criteria if item["level"] >= 3],
        "missed_points": [item["name"] for item in criteria if item["level"] <= 1],
        "criteria": criteria,
        "scoring_confidence": round(scoring_confidence, 3),
        "rubric_version": WRITTEN_SCORING_VERSION,
        "eval_failed": False,
    }
    return output


def aggregate_written_dimensions(results: list[dict]) -> dict[str, Any]:
    """Aggregate criterion evidence into written dimensions and a final score."""
    dimension_values: dict[str, list[tuple[float, float]]] = {dimension: [] for dimension in WRITTEN_DIMENSIONS}
    dimension_detail: dict[str, list[dict]] = {dimension: [] for dimension in WRITTEN_DIMENSIONS}
    for result in results:
        question_index = result["question_index"]
        for criterion in result.get("criteria", []):
            dimension = criterion.get("dimension")
            if dimension not in WRITTEN_DIMENSIONS:
                continue
            score = criterion.get("score")
            weight = criterion.get("weight")
            if not isinstance(score, (int, float)) or not isinstance(weight, (int, float)) or weight <= 0:
                continue
            dimension_values[dimension].append((float(score), float(weight)))
            dimension_detail[dimension].append(
                {
                    "question_index": question_index,
                    "criterion_id": criterion.get("id"),
                    "score": score,
                    "evidence": criterion.get("evidence", ""),
                    "confidence": criterion.get("confidence"),
                }
            )

    dimension_scores = {}
    for dimension, values in dimension_values.items():
        if values:
            total_weight = sum(weight for _, weight in values)
            dimension_scores[dimension] = round(sum(score * weight for score, weight in values) / total_weight)
    covered_weight = sum(WRITTEN_DIMENSIONS[name] for name in dimension_scores)
    if not dimension_scores or covered_weight <= 0:
        raise ValueError("no written dimensions covered")
    total_score = round(
        sum(dimension_scores[name] * WRITTEN_DIMENSIONS[name] for name in dimension_scores) / covered_weight
    )
    uncovered = [name for name in WRITTEN_DIMENSIONS if name not in dimension_scores]
    return {
        "total_score": total_score,
        "dimension_scores": dimension_scores,
        "dimension_coverage": {
            "covered": list(dimension_scores),
            "uncovered": uncovered,
            "ratio": round(covered_weight / sum(WRITTEN_DIMENSIONS.values()), 3),
            "status": "complete" if not uncovered else "partial",
        },
        "dimension_detail": dimension_detail,
    }
