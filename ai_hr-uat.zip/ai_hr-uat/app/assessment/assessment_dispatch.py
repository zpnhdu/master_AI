"""统一评估状态机的后续环节派发。"""

from __future__ import annotations

from fastapi import HTTPException

from app.db import get_db, save_message


def _existing_written_session(pipeline_id: str, candidate_id: str) -> bool:
    database = get_db()
    table = database.execute(
        "SELECT 1 FROM information_schema.tables "
        "WHERE table_schema = DATABASE() AND table_name = 'written_test_sessions'"
    ).fetchone()
    if not table:
        return False
    row = database.execute(
        """SELECT 1 FROM written_test_sessions
           WHERE pipeline_id=%s AND candidate_id=%s AND status IN ('pending', 'in_progress') LIMIT 1""",
        (pipeline_id, candidate_id),
    ).fetchone()
    return bool(row)


async def dispatch_next_actions(pipeline_id: str, candidate_id: str, package: dict) -> list[dict]:
    """按状态机产出的下一环节创建邀请；人工面试只生成明确待办。"""
    results = []
    for action in package.get("next_actions", []):
        if action.get("handoff") != "automatic":
            continue
        modality = action.get("modality")
        try:
            if modality == "video_interview":
                from app.routers.mass_interview import api_launch_mass_interview

                launched = await api_launch_mass_interview(
                    {"pipeline_id": pipeline_id, "candidate_ids": [candidate_id], "expires_hours": 48}
                )
                results.append({"modality": modality, "status": "invited", "detail": launched})
            elif modality == "written_test":
                if _existing_written_session(pipeline_id, candidate_id):
                    results.append({"modality": modality, "status": "already_invited"})
                    continue
                from app.routers.written_test import LaunchRequest, api_launch_written_test

                launched = await api_launch_written_test(
                    LaunchRequest(pipeline_id=pipeline_id, candidate_ids=[candidate_id])
                )
                results.append({"modality": modality, "status": "invited", "detail": launched})
            elif modality == "manual_interview":
                save_message(
                    pipeline_id,
                    "assistant",
                    f"候选人 {package.get('candidate_name', candidate_id)} 已进入人工面试待安排队列。",
                    card_type="manual_interview_required",
                    card_data={"candidate_id": candidate_id, "step_id": action.get("step_id", "")},
                )
                results.append({"modality": modality, "status": "requires_scheduling"})
        except HTTPException as error:
            results.append({"modality": modality, "status": "blocked", "reason": str(error.detail)})
        except Exception as error:
            results.append({"modality": modality, "status": "failed", "reason": str(error)[:200]})
    return results
