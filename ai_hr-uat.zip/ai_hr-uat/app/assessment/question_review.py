"""面试出题人工审核核心逻辑。

from __future__ import annotations

职责（与路由解耦的纯逻辑层）：
- 审核状态读写（存于 interview_gen stage output，无新表）
- 题目增删改（上限 MAX_QUESTIONS=20）
- 统一题集 apply_to_all（把某人题集复制给全部候选人）
- 标记审核（单人/全部）
- 重新生成题目（复用 InterviewAgent，数量 1-20 可配）
- 导出 Word / Markdown（python-docx，无新增依赖）

兼容性约定（关键）：
- interview_gen output 中某候选人 review_status 缺失 → 视为已审核，
  旧数据 / 存量流程不被新拦截逻辑破坏；
- 新生成 / 任何人工修改后 → 显式写 review_status="pending"，强制人工审核。
- 修改一律写回 interview_gen 源头，并同步更新该候选人仍处于待面试状态的笔试/面试 session；已开始的 session 保持锁定。

并发：per-pipeline asyncio.Lock，所有读改写（读 output → 改 → 写回）原子化。
"""

import asyncio
import io
import json
import logging
import re
from datetime import datetime
from typing import Callable, Optional

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt

from app.db import (
    _effective_written_test_status,
    _get_written_test_sessions,
    create_stage,
    get_candidates,
    get_db,
    get_pipeline,
    get_stages,
    get_interview_sessions,
    update_stage,
)
from app.state import broadcast

logger = logging.getLogger(__name__)

MAX_QUESTIONS = 20
DEFAULT_QUESTION_COUNT = 3


def _record_question_changes(pipeline_id: str, before: list, after: list, actor_user_id: str = "") -> None:
    """Persist HR question edits as reusable Xiao Mian memory without blocking edits."""
    try:
        from hr_harness.memory.core import MemorySystem

        pipeline = get_pipeline(pipeline_id) or {}
        memory = MemorySystem(pipeline_id, actor_user_id=actor_user_id)
        role = str(pipeline.get("role") or "")
        shared = min(len(before), len(after))
        for index in range(shared):
            if before[index] != after[index]:
                memory.learn_from_interview_question_edit(
                    role, "update", before[index], after[index], actor_user_id=actor_user_id
                )
        for question in after[shared:]:
            memory.learn_from_interview_question_edit(role, "add", None, question, actor_user_id=actor_user_id)
        for question in before[shared:]:
            memory.learn_from_interview_question_edit(role, "delete", question, None, actor_user_id=actor_user_id)
    except Exception:
        logger.exception("Failed to learn from interview question edit", extra={"pipeline_id": pipeline_id})
QUESTION_EDIT_LOCKED_STATUSES = {
    "started",
    "in_progress",
    "answering",
    "active",
    "completed",
    "evaluated",
    "submitted",
    "expired",
}


def question_edit_lock(pipeline_id: str, candidate_id: str) -> str:
    """Return the interview status that prevents changing a candidate's questions."""
    pipeline = get_pipeline(pipeline_id)
    context = pipeline.get("context") if pipeline else {}
    if isinstance(context, str):
        try:
            context = json.loads(context)
        except (TypeError, json.JSONDecodeError):
            context = {}
    locked_ids = {str(value) for value in (context or {}).get("question_edit_locked_candidate_ids", [])}
    if str(candidate_id) in locked_ids:
        return "interview_center"
    candidate_row = next((c for c in get_candidates(pipeline_id) if str(c.get("id")) == str(candidate_id)), None)
    candidate_name = str((candidate_row or {}).get("name") or (candidate_row or {}).get("candidate_name") or "").strip()
    # Candidate lifecycle marks completed interviews as ``interviewed`` even
    # when the session row has been archived or removed.
    candidate_status = str((candidate_row or {}).get("status") or "").lower()
    if candidate_status in {"interviewed", "interview_completed", "interview_ended"}:
        return "completed"
    if candidate_status in {"interview", "interviewing", "in_interview", "interview_in_progress"}:
        return "in_progress"
    # The interview center also derives status from unified assessment state
    # rows when legacy session rows are absent.
    try:
        row = (
            get_db()
            .execute(
                "SELECT step_results FROM assessment_candidate_states WHERE pipeline_id=%s AND candidate_id=%s",
                (pipeline_id, candidate_id),
            )
            .fetchone()
        )
        if row:
            payload = row.get("step_results") if isinstance(row, dict) else row[0]
            if isinstance(payload, str):
                payload = json.loads(payload or "{}")
            for result in (payload or {}).values() if isinstance(payload, dict) else []:
                if not isinstance(result, dict):
                    continue
                execution = str(result.get("execution_status") or "").lower()
                if execution in {"submitted", "completed", "evaluated"}:
                    return "completed" if execution != "evaluated" else "evaluated"
                if execution in {"started", "in_progress", "answering", "active"}:
                    return execution
    except Exception:
        pass
    sessions = [
        s
        for s in get_interview_sessions(pipeline_id)
        if str(s.get("candidate_id")) == str(candidate_id)
        or (candidate_name and str(s.get("candidate_name") or "").strip() == candidate_name)
    ]
    for session in sessions:
        status = str(session.get("status") or "").lower()
        if status in QUESTION_EDIT_LOCKED_STATUSES or session.get("started_at"):
            return status
    # Written-test sessions live in a separate table from video sessions.
    # Once a candidate opens the link, its status becomes ``in_progress``;
    # expose the same lock contract so question editing and natural-language
    # commands are blocked consistently across both modalities.
    try:
        written_sessions = _get_written_test_sessions(pipeline_id)
        for session in written_sessions:
            same_candidate = str(session.get("candidate_id")) == str(candidate_id)
            same_name = candidate_name and str(session.get("candidate_name") or "").strip() == candidate_name
            if not (same_candidate or same_name):
                continue
            status = _effective_written_test_status(session)
            if status in QUESTION_EDIT_LOCKED_STATUSES or session.get("started_at"):
                return status
    except Exception:
        # Older databases may not have the optional written-test table yet.
        pass
    return ""


def ensure_questions_editable(pipeline_id: str, candidate_id: str) -> None:
    status = question_edit_lock(pipeline_id, candidate_id)
    if status:
        if status == "interview_center":
            label = "已进入面试中心"
        else:
            label = "面试中" if status in {"started", "in_progress"} else "面试已结束"
        raise ValueError(f"该候选人{label}，不允许修改面试题")


async def lock_question_batch(pipeline_id: str, candidate_ids: list[str]) -> dict:
    """Persist the handoff boundary for this pipeline's current candidate batch."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError("pipeline not found")
    targets = {str(value) for value in candidate_ids if value}
    if not targets:
        raise ValueError("没有可锁定的候选人")

    def _fn(output, _interviews):
        existing = {str(value) for value in output.get("question_edit_locked_candidate_ids", [])}
        output["question_edit_locked_candidate_ids"] = sorted(existing | targets)
        output["question_edit_locked_at"] = output.get("question_edit_locked_at") or datetime.now().isoformat(
            timespec="seconds"
        )
        return {"locked_count": len(targets)}

    async with _lock_for(pipeline_id):
        return (await _mutate(pipeline_id, _fn))["result"]


_locks: dict[str, asyncio.Lock] = {}


# ---------------------------------------------------------------------------
# 基础读写
# ---------------------------------------------------------------------------


def _lock_for(pipeline_id: str) -> asyncio.Lock:
    return _locks.setdefault(pipeline_id, asyncio.Lock())


def _parse_stage_output(stage: Optional[dict]) -> dict:
    raw = (stage or {}).get("output") or "{}"
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return {}
    return raw if isinstance(raw, dict) else {}


def _status_of(iv: dict) -> str:
    """单人审核状态：缺失视为已审核（旧数据兼容）。"""
    return "reviewed" if iv.get("review_status") in (None, "reviewed") else "pending"


def _global_status(interviews: list) -> str:
    if not interviews:
        return "pending"
    return "reviewed" if all(_status_of(iv) == "reviewed" for iv in interviews) else "pending"


def _write_output(pipeline_id: str, output: dict) -> None:
    # update_stage 仅 status=="done" 时写 output
    update_stage(pipeline_id, "interview_gen", "done", output)


def _find_interview(interviews: list, candidate_id: str) -> Optional[dict]:
    target_id = str(candidate_id or "")
    for iv in interviews:
        if isinstance(iv, dict) and str(iv.get("candidate_id") or "") == target_id:
            return iv
    return None


def _normalize_question_dimensions(interviews: list) -> None:
    """Remove presentation prefixes from persisted question dimensions."""
    prefix = re.compile(r"^\s*(?:\u80fd\u529b\u5730\u56fe\u7ef4\u5ea6|\u5c97\u4f4d\u7ef4\u5ea6)\s*[:\uff1a]\s*")
    for interview in interviews:
        if not isinstance(interview, dict):
            continue
        for question in interview.get("questions", []) or []:
            if not isinstance(question, dict):
                continue
            for field in ("competency_ref", "dimension"):
                value = question.get(field)
                if isinstance(value, str):
                    question[field] = prefix.sub("", value).strip()


def _sync_pending_session_questions(pipeline_id: str, candidate_id: str, questions: list) -> None:
    """Update links that have not been opened so both modalities use latest 小面题目."""
    if not candidate_id:
        return
    conn = get_db()
    question_snapshot = list(questions or [])
    # Written scoring needs the rubric embedded in its session snapshot.
    try:
        from app.written_scoring import build_written_rubric

        written_questions = []
        for raw_question in question_snapshot:
            if isinstance(raw_question, dict):
                question = dict(raw_question)
                question["written_scoring_rubric"] = build_written_rubric(question)
                written_questions.append(question)
    except Exception:
        written_questions = question_snapshot

    conn.execute(
        """UPDATE interview_sessions
           SET questions=%s, total_questions=%s, updated_at=NOW()
           WHERE pipeline_id=%s AND candidate_id=%s
             AND status IN ('invited','pending')
             AND (started_at IS NULL OR started_at='')""",
        (json.dumps(question_snapshot, ensure_ascii=False), len(question_snapshot), pipeline_id, candidate_id),
    )
    conn.execute(
        """UPDATE written_test_sessions
           SET questions=%s
           WHERE pipeline_id=%s AND candidate_id=%s
             AND status IN ('pending','invited')
             AND (started_at IS NULL OR started_at='')""",
        (json.dumps(written_questions, ensure_ascii=False), pipeline_id, candidate_id),
    )
    conn.commit()


def _sync_pending_sessions_from_output(pipeline_id: str, interviews: list) -> None:
    """Propagate the current 小面 snapshots to every still-pending link."""
    for interview in interviews:
        if not isinstance(interview, dict) or not isinstance(interview.get("questions"), list):
            continue
        _sync_pending_session_questions(
            pipeline_id,
            str(interview.get("candidate_id") or ""),
            interview["questions"],
        )


def _question_signature(questions: list) -> tuple:
    """Compare question content while ignoring generated metadata."""
    return tuple(
        (
            str(question.get("type", "")).strip(),
            str(question.get("question", question.get("text", ""))).strip(),
            str(question.get("follow_up", "")).strip(),
        )
        for question in questions
        if isinstance(question, dict)
    )


def _get_jd(stages: list, context: dict) -> dict:
    jd = context.get("jd", {})
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if jd_stage:
        parsed = _parse_stage_output(jd_stage)
        jd = parsed.get("jd", jd)
    return jd


async def _mutate(pipeline_id: str, fn: Callable[[dict, list], object]) -> dict:
    """读 interview_gen output → fn(output, interviews) → 写回 + 重算全局状态 + 广播。

    返回 {output, result}；fn 抛 ValueError 时不写回（不污染数据）。
    """
    stages = get_stages(pipeline_id)
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    if not iv_stage:
        raise ValueError("面试出题阶段不存在，请先批量生成题目")
    output = _parse_stage_output(iv_stage)
    interviews = output.setdefault("interviews", [])
    if not isinstance(interviews, list):
        interviews = output["interviews"] = []

    result = fn(output, interviews)

    output["review_status"] = _global_status(interviews)
    _normalize_question_dimensions(interviews)
    _write_output(pipeline_id, output)
    _sync_pending_sessions_from_output(pipeline_id, interviews)
    await broadcast({"type": "questions_updated", "pipeline_id": pipeline_id}, pipeline_id)
    return {"output": output, "result": result}


# ---------------------------------------------------------------------------
# 读取
# ---------------------------------------------------------------------------


async def get_review_state(pipeline_id: str) -> dict:
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError("pipeline not found")
    stages = get_stages(pipeline_id)
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    output = _parse_stage_output(iv_stage) if iv_stage else {}
    interviews = output.get("interviews", [])
    if not isinstance(interviews, list):
        interviews = []
    _normalize_question_dimensions(interviews)
    # 返回时归一化单人状态（缺失视为已审核），不污染存储
    normalized = []
    for iv in interviews:
        if isinstance(iv, dict):
            item = dict(iv)
            item["review_status"] = _status_of(iv)
            lock_status = question_edit_lock(pipeline_id, str(item.get("candidate_id") or ""))
            if not lock_status:
                target_name = str(item.get("candidate_name") or item.get("name") or "").strip()
                for session in get_interview_sessions(pipeline_id):
                    same_candidate = str(session.get("candidate_id") or "") == str(item.get("candidate_id") or "")
                    same_name = target_name and str(session.get("candidate_name") or "").strip() == target_name
                    status = str(session.get("status") or "").lower()
                    if (same_candidate or same_name) and (
                        status in QUESTION_EDIT_LOCKED_STATUSES or session.get("started_at")
                    ):
                        lock_status = status
                        break
            item["question_edit_locked"] = bool(lock_status)
            item["question_edit_lock_status"] = lock_status
            item["interview_status"] = lock_status
            normalized.append(item)
    return {
        "pipeline_id": pipeline_id,
        "role": (pipeline.get("role") or ""),
        "review_status": _global_status(interviews),
        "max_questions": MAX_QUESTIONS,
        "generated_count": output.get("generated_count", DEFAULT_QUESTION_COUNT),
        "interviews": normalized,
    }


# ---------------------------------------------------------------------------
# 题目增删改
# ---------------------------------------------------------------------------


async def set_questions(pipeline_id: str, candidate_id: str, questions: list, actor_user_id: str = "") -> dict:
    """整体替换某人题目（校验 ≤20，保留候选人身份与扩展字段由调用方负责）。"""
    if len(questions) > MAX_QUESTIONS:
        raise ValueError(f"题目数量不能超过{MAX_QUESTIONS}道")
    ensure_questions_editable(pipeline_id, candidate_id)
    snapshot = {}

    def _fn(output, interviews):
        iv = _find_interview(interviews, candidate_id)
        if not iv:
            raise ValueError("该候选人没有面试题")
        snapshot["before"] = [dict(item) for item in iv.get("questions", []) if isinstance(item, dict)]
        iv["questions"] = list(questions)
        snapshot["after"] = [dict(item) for item in iv["questions"] if isinstance(item, dict)]
        iv["review_status"] = "pending"
        return iv

    async with _lock_for(pipeline_id):
        result = (await _mutate(pipeline_id, _fn))["result"]
    _record_question_changes(pipeline_id, snapshot.get("before", []), snapshot.get("after", []), actor_user_id)
    return result


async def add_question(pipeline_id: str, candidate_id: str, question: dict, actor_user_id: str = "") -> dict:
    ensure_questions_editable(pipeline_id, candidate_id)
    snapshot = {}

    def _fn(output, interviews):
        iv = _find_interview(interviews, candidate_id)
        if not iv:
            raise ValueError("该候选人没有面试题")
        if len(iv.get("questions", [])) >= MAX_QUESTIONS:
            raise ValueError(f"题目数量已达上限{MAX_QUESTIONS}道")
        snapshot["before"] = [dict(item) for item in iv.get("questions", []) if isinstance(item, dict)]
        iv["questions"].append(dict(question))
        snapshot["after"] = [dict(item) for item in iv["questions"] if isinstance(item, dict)]
        iv["review_status"] = "pending"
        return iv

    async with _lock_for(pipeline_id):
        result = (await _mutate(pipeline_id, _fn))["result"]
    _record_question_changes(pipeline_id, snapshot.get("before", []), snapshot.get("after", []), actor_user_id)
    return result


async def update_question(pipeline_id: str, candidate_id: str, index: int, question: dict, actor_user_id: str = "") -> dict:
    ensure_questions_editable(pipeline_id, candidate_id)
    """修改一题：仅覆盖传入字段，保留题对象其余扩展字段（兼容两套 schema）。"""
    snapshot = {}

    def _fn(output, interviews):
        iv = _find_interview(interviews, candidate_id)
        if not iv:
            raise ValueError("该候选人没有面试题")
        qs = iv.get("questions", [])
        if not (0 <= index < len(qs)):
            raise ValueError("题目索引不存在")
        snapshot["before"] = [dict(item) for item in qs if isinstance(item, dict)]
        merged = dict(qs[index])
        merged.update(question)
        qs[index] = merged
        snapshot["after"] = [dict(item) for item in qs if isinstance(item, dict)]
        iv["review_status"] = "pending"
        return iv

    async with _lock_for(pipeline_id):
        result = (await _mutate(pipeline_id, _fn))["result"]
    _record_question_changes(pipeline_id, snapshot.get("before", []), snapshot.get("after", []), actor_user_id)
    return result


async def delete_question(pipeline_id: str, candidate_id: str, index: int, actor_user_id: str = "") -> dict:
    ensure_questions_editable(pipeline_id, candidate_id)
    snapshot = {}

    def _fn(output, interviews):
        iv = _find_interview(interviews, candidate_id)
        if not iv:
            raise ValueError("该候选人没有面试题")
        qs = iv.get("questions", [])
        if not (0 <= index < len(qs)):
            raise ValueError("题目索引不存在")
        snapshot["before"] = [dict(item) for item in qs if isinstance(item, dict)]
        qs.pop(index)
        snapshot["after"] = [dict(item) for item in qs if isinstance(item, dict)]
        iv["review_status"] = "pending"
        return iv

    async with _lock_for(pipeline_id):
        result = (await _mutate(pipeline_id, _fn))["result"]
    _record_question_changes(pipeline_id, snapshot.get("before", []), snapshot.get("after", []), actor_user_id)
    return result


# ---------------------------------------------------------------------------
# 统一题集 / 审核
# ---------------------------------------------------------------------------


async def apply_to_all(pipeline_id: str, from_candidate_id: str, actor_user_id: str = "") -> dict:
    ensure_questions_editable(pipeline_id, from_candidate_id)
    """把某候选人题集深拷贝给全部候选人；复制后目标候选人重置为待审核。"""
    snapshot = {}

    def _fn(output, interviews):
        src = _find_interview(interviews, from_candidate_id)
        if not src:
            raise ValueError("源候选人没有面试题")
        template = json.loads(json.dumps(src.get("questions", []), ensure_ascii=False))
        snapshot["after"] = [dict(item) for item in template if isinstance(item, dict)]
        for iv in interviews:
            if iv.get("candidate_id") != from_candidate_id:
                iv["questions"] = json.loads(json.dumps(template, ensure_ascii=False))
                iv["review_status"] = "pending"
        return output

    async with _lock_for(pipeline_id):
        result = (await _mutate(pipeline_id, _fn))["result"]
    _record_question_changes(pipeline_id, [], snapshot.get("after", []), actor_user_id)
    return result


async def mark_reviewed(pipeline_id: str, candidate_ids: Optional[list] = None, reviewer: str = "") -> dict:
    """标记审核通过；candidate_ids 为空 → 全部候选人。"""

    def _fn(output, interviews):
        targets = (
            {str(value) for value in candidate_ids if value is not None}
            if candidate_ids
            else {str(iv.get("candidate_id")) for iv in interviews if isinstance(iv, dict)}
        )
        count = 0
        for iv in interviews:
            if str(iv.get("candidate_id")) in targets:
                iv["review_status"] = "reviewed"
                iv["reviewed_by"] = reviewer
                iv["reviewed_at"] = datetime.now().isoformat(timespec="seconds")
                count += 1
        return {"reviewed_count": count}

    async with _lock_for(pipeline_id):
        out = await _mutate(pipeline_id, _fn)
    return {**out["result"], "review_status": out["output"]["review_status"]}


async def set_generated_count(pipeline_id: str, count: int) -> dict:
    """设置批量生成题数（1-20），写入 output 供发起流程与下次生成使用。"""
    if not (1 <= count <= MAX_QUESTIONS):
        raise ValueError(f"题目数量需在 1-{MAX_QUESTIONS} 之间")

    def _fn(output, interviews):
        output["generated_count"] = count
        return {"generated_count": count}

    async with _lock_for(pipeline_id):
        if not any(stage["stage_id"] == "interview_gen" for stage in get_stages(pipeline_id)):
            create_stage(pipeline_id, "interview_gen", "面试题生成")
        return (await _mutate(pipeline_id, _fn))["result"]


# ---------------------------------------------------------------------------
# 重新生成
# ---------------------------------------------------------------------------


async def _generate_with_agent(
    cand: dict,
    jd: dict,
    role: str,
    pipeline_id: str,
    question_count: int,
    previous_questions: list | None = None,
) -> list:
    """供 regenerate 使用；独立函数便于测试 mock。"""
    from hr_harness.agents.interview_agent import InterviewAgent

    agent = InterviewAgent()
    gen_context = {
        "candidates": [cand],
        "jd": jd,
        "role": role,
        "pipeline_id": pipeline_id,
        "question_count": question_count,
        "previous_questions": previous_questions or [],
        "regenerate": True,
    }
    result = await agent.execute(gen_context)
    interviews = result.get("interviews", [])
    if interviews:
        return interviews[0].get("questions", [])[:question_count]
    return []


async def _generate_single(cand: dict, jd: dict, role: str, pipeline_id: str, direction: str, difficulty: str) -> dict:
    """按「题型方向 + 难度」为候选人个性化生成 1 道题（独立函数便于测试 mock）。

    结合候选人简历、经验与 JD 要求；返回单题 dict，失败返回 {}。
    """
    from hr_harness.agents.interview_agent import InterviewAgent

    agent = InterviewAgent()
    cand_brief = {
        "name": cand.get("name", "候选人"),
        "years_experience": cand.get("years_experience", 0),
        "current_company": cand.get("current_company", ""),
        "skills": cand.get("skills", []),
        "resume": (cand.get("resume_text", "") or "")[:500],
    }
    jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)

    system = f"""你是一位在{role}领域有 12 年经验的资深面试官。请为候选人设计 1 道面试题。

出题要求：
1. 题型方向：{direction}
2. 难度：{difficulty}（简单=基础能力验证；中等=结合实际业务场景；困难=复杂约束与权衡决策）
3. 必须结合候选人简历、经验与 JD 要求个性化，题目不能空泛通用
4. 题面用自然语言描述一个具体场景/问题（100-200字），嵌入业务数字与约束条件，让候选人自己拆解
5. 配套 1-2 条追问方向、3-5 个期望要点，答题时长固定为 3 分钟

输出严格的 JSON 对象（不要数组、不要任何解释文字）：
{{
  "type": "{direction}",
  "question": "题面",
  "duration": "3分钟",
  "follow_up": "追问方向",
  "reason": "为什么出这道题（关联候选人经验/JD要求/风险点）",
  "expected_points": ["要点1", "要点2", "要点3"],
  "difficulty": "{difficulty}"
}}"""

    prompt = f"""候选人：{cand_brief["name"]} · {cand_brief["years_experience"]}年 · {cand_brief["current_company"]}
技能：{", ".join(cand_brief["skills"])}
简历摘要：{cand_brief["resume"]}

JD：
{jd_text[:1200]}

请按题型方向【{direction}】、难度【{difficulty}】输出 1 道个性化面试题（严格 JSON 对象）："""

    result = await agent.call_llm_json(prompt, system, complexity="plus")
    if isinstance(result, dict) and result.get("question"):
        result.setdefault("type", direction)
        result["difficulty"] = difficulty
        result["duration"] = "3分钟"
        return result
    return {}


# ---------------------------------------------------------------------------
# AI 智能补全 / 反生（单智能按钮）
# ---------------------------------------------------------------------------


async def _ai_fill(
    cand: dict,
    jd: dict,
    role: str,
    pipeline_id: str,
    current: dict,
    fill_fields: list,
    difficulty: str,
) -> dict:
    """根据当前题已有内容，AI 生成缺失字段（独立函数便于测试 mock）。

    current: 当前题 {question, follow_up, expected_points, type, ...}
    fill_fields: 需要生成的字段，如 ["follow_up"] / ["expected_points"] /
                 ["question", "follow_up"]（反生）
    """
    from hr_harness.agents.interview_agent import InterviewAgent

    agent = InterviewAgent()
    cand_brief = {
        "name": cand.get("name", "候选人"),
        "years_experience": cand.get("years_experience", 0),
        "current_company": cand.get("current_company", ""),
        "skills": cand.get("skills", []),
        "resume": (cand.get("resume_text", "") or "")[:500],
    }
    jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)

    parts = []
    if current.get("question"):
        parts.append(f"【题面】{current['question']}")
    if current.get("follow_up"):
        parts.append(f"【追问方向】{current['follow_up']}")
    if current.get("expected_points"):
        points = "、".join(current["expected_points"])
        parts.append(f"【期望要点】{points}")
    existing_text = "\n".join(parts) if parts else "（暂无）"

    out_specs = []
    if "question" in fill_fields:
        out_specs.append('"question": "题面（100-200字自然语言场景，嵌入业务数字与约束，与期望要点严格对应）"')
    if "follow_up" in fill_fields:
        out_specs.append('"follow_up": "1-2 条追问方向（用；分隔）"')
    if "expected_points" in fill_fields:
        out_specs.append('"expected_points": ["3-5 个评分要点，每条约 10-20 字"]')

    system = f"""你是一位在{role}领域有 12 年经验的资深面试官。请根据题目已有内容，AI 补全缺失字段，所有内容必须结合候选人简历与 JD 个性化，不能空泛。

当前难度参考：{difficulty}（简单=基础能力验证；中等=结合实际业务场景；困难=复杂约束与权衡决策）

只输出缺失字段，输出严格的 JSON 对象（不要数组、不要解释）：
{{
{", ".join(out_specs)}
}}"""

    prompt = f"""候选人：{cand_brief["name"]} · {cand_brief["years_experience"]}年 · {cand_brief["current_company"]}
技能：{", ".join(cand_brief["skills"])}
简历摘要：{cand_brief["resume"]}

JD：
{jd_text[:1200]}

题目已有内容：
{existing_text}

请生成缺失字段（{", ".join(fill_fields)}），严格 JSON 对象："""

    result = await agent.call_llm_json(prompt, system, complexity="plus")
    if isinstance(result, dict):
        return result
    return {}


async def _ai_fill_from_content(pipeline_id: str, candidate_id: str, current: dict, difficulty: str) -> dict:
    """对任意内容（已存题 或 空白卡草稿）做智能补全/反生/优化，返回 merged 题 + message（不写库）。

    规则：
    - 题面空 + 期望要点有 → 反生：生成 题面+追问（要点保留）
    - 题面有，缺追问/要点 → 补齐缺失（已有不动）
    - 题面/追问/要点齐全 → 优化模式：AI 重写追问+要点（不空转）
    - 题面与要点都空 → 报错
    """
    if difficulty not in ("简单", "中等", "困难"):
        difficulty = "中等"

    stages = get_stages(pipeline_id)
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError("pipeline not found")
    pctx = {}
    if pipeline.get("context"):
        try:
            pctx = json.loads(pipeline["context"])
        except (json.JSONDecodeError, TypeError):
            pctx = {}
    role = pctx.get("role") or pipeline.get("role") or "工程师"
    jd = _get_jd(stages, pctx)

    candidates = get_candidates(pipeline_id)
    cand = next((c for c in candidates if c.get("id") == candidate_id), None)
    if not cand:
        raise ValueError("候选人不存在")

    current = dict(current)
    q_text = (current.get("question") or "").strip()
    follow = (current.get("follow_up") or "").strip()
    points = current.get("expected_points") or []
    field_names = {"question": "题面", "follow_up": "追问方向", "expected_points": "期望要点"}

    if not q_text and not points:
        raise ValueError("请先填写题面或期望要点，再使用 AI 补全")

    if not q_text:
        # 反生：由要点生成 题面 + 追问
        fill_fields = ["question", "follow_up"]
        verb = "生成"
    elif follow and points:
        # 齐全 → 优化模式：AI 重写追问+要点，不空转
        fill_fields = ["follow_up", "expected_points"]
        verb = "优化"
    else:
        fill_fields = []
        if not follow:
            fill_fields.append("follow_up")
        if not points:
            fill_fields.append("expected_points")
        verb = "生成"

    generated = await _ai_fill(cand, jd, role, pipeline_id, current, fill_fields, difficulty)
    if not generated:
        raise ValueError("AI 补全失败，请重试")

    merged = dict(current)
    for f in fill_fields:
        if f == "expected_points":
            gp = generated.get("expected_points") or []
            if isinstance(gp, list) and gp:
                merged[f] = gp
        else:
            val = (generated.get(f) or "").strip()
            if val:
                merged[f] = val
    return {
        "question": merged,
        "message": f"已{verb}：{'、'.join(field_names[f] for f in fill_fields)}",
    }


async def ai_fill_question(pipeline_id: str, candidate_id: str, index: int, difficulty: str = "中等") -> dict:
    """已生成题：读 stage 中 index 题 → 智能补全/反生/优化（不写库）。"""
    stages = get_stages(pipeline_id)
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    output = _parse_stage_output(iv_stage) if iv_stage else {}
    iv = _find_interview(output.get("interviews", []) or [], candidate_id)
    if not iv:
        raise ValueError("该候选人没有面试题")
    qs = iv.get("questions", []) or []
    if not (0 <= index < len(qs)):
        raise ValueError("题目索引不存在")
    current = dict(qs[index])
    return await _ai_fill_from_content(pipeline_id, candidate_id, current, difficulty)


async def ai_fill_draft(pipeline_id: str, candidate_id: str, draft: dict, difficulty: str = "中等") -> dict:
    """空白卡草稿：不读 stage，直接对面试官填的内容补全/反生/优化（不写库）。"""
    if not draft or not isinstance(draft, dict):
        raise ValueError("请先填写题面或期望要点")
    return await _ai_fill_from_content(pipeline_id, candidate_id, draft, difficulty)


async def generate_one_question(pipeline_id: str, candidate_id: str, direction: str, difficulty: str = "中等") -> dict:
    ensure_questions_editable(pipeline_id, candidate_id)
    """按方向+难度为候选人生成 1 道题并追加（含 20 上限校验、重置待审核）。"""
    direction = (direction or "").strip()
    if not direction:
        raise ValueError("请填写题型方向")
    if difficulty not in ("简单", "中等", "困难"):
        difficulty = "中等"

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError("pipeline not found")
    stages = get_stages(pipeline_id)

    context = {}
    if pipeline.get("context"):
        try:
            context = json.loads(pipeline["context"])
        except (json.JSONDecodeError, TypeError):
            context = {}
    role = context.get("role") or pipeline.get("role") or "工程师"
    jd = _get_jd(stages, context)

    candidates = get_candidates(pipeline_id)
    cand = next((c for c in candidates if c.get("id") == candidate_id), None)
    if not cand:
        raise ValueError("候选人不存在")

    question = await _generate_single(cand, jd, role, pipeline_id, direction, difficulty)
    if not question:
        raise ValueError("AI 生成题目失败，请重试")

    # 复用 add_question：上限校验 + 追加 + 重置 pending + 写回 + 广播
    return await add_question(pipeline_id, candidate_id, question)


async def regenerate_questions(
    pipeline_id: str, candidate_id: Optional[str] = None, count: Optional[int] = None
) -> dict:
    """重新生成候选人题目（复用 InterviewAgent 出题链路）。

    - candidate_id 为空 → 为全部入围（shortlist/passed）候选人生成
    - count 1-20，缺省用 generated_count
    - 生成后该候选人重置为待审核
    """
    count = count or DEFAULT_QUESTION_COUNT
    if not (1 <= count <= MAX_QUESTIONS):
        raise ValueError(f"题目数量需在 1-{MAX_QUESTIONS} 之间")

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError("pipeline not found")
    if candidate_id:
        ensure_questions_editable(pipeline_id, candidate_id)
    stages = get_stages(pipeline_id)

    context = {}
    if pipeline.get("context"):
        try:
            context = json.loads(pipeline["context"])
        except (json.JSONDecodeError, TypeError):
            context = {}
    role = context.get("role") or pipeline.get("role") or "工程师"
    jd = _get_jd(stages, context)

    candidates = get_candidates(pipeline_id)
    eligible = [c for c in candidates if c.get("status") in ("shortlist", "passed")]
    if candidate_id:
        eligible = [c for c in eligible if str(c.get("id") or "") == str(candidate_id)]
    if not eligible:
        raise ValueError("没有可重新出题的候选人（需已通过筛选）")

    async with _lock_for(pipeline_id):
        stages = get_stages(pipeline_id)
        iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
        if not iv_stage:
            raise ValueError("面试出题阶段不存在，请先批量生成题目")
        output = _parse_stage_output(iv_stage)
        interviews = output.setdefault("interviews", [])

        updated = []
        for cand in eligible:
            current_iv = _find_interview(interviews, cand.get("id")) or {}
            previous_questions = current_iv.get("questions", [])
            generation_candidate = dict(cand)
            if isinstance(current_iv.get("competency_map"), dict):
                generation_candidate["_existing_competency_map"] = current_iv["competency_map"]
            questions = await _generate_with_agent(
                generation_candidate,
                jd,
                role,
                pipeline_id,
                count,
                previous_questions=previous_questions,
            )
            questions = list(questions)[:count]
            if previous_questions and _question_signature(questions) == _question_signature(previous_questions):
                questions = await _generate_with_agent(
                    cand,
                    jd,
                    role,
                    pipeline_id,
                    count,
                    previous_questions=list(previous_questions) + questions,
                )
                questions = list(questions)[:count]

            if not questions:
                raise ValueError("重新生成未得到有效题目，请检查模型服务后重试")
            if previous_questions and _question_signature(questions) == _question_signature(previous_questions):
                raise ValueError("重新生成未得到不同题目，已保留原题，请稍后重试")

            iv = _find_interview(interviews, cand.get("id")) or {
                "candidate_id": cand.get("id"),
                "candidate_name": cand.get("name", "候选人"),
            }
            if iv not in interviews:
                interviews.append(iv)
            iv["questions"] = questions
            iv["review_status"] = "pending"
            updated.append(cand.get("id"))

        output["generated_count"] = count
        output["review_status"] = _global_status(interviews)
        _write_output(pipeline_id, output)
        _sync_pending_sessions_from_output(pipeline_id, interviews)

    await broadcast({"type": "questions_updated", "pipeline_id": pipeline_id}, pipeline_id)
    return {"updated": updated, "count": count}


# ---------------------------------------------------------------------------
# 发起校验（供 written_test / mass_interview launch 调用）
# ---------------------------------------------------------------------------


async def check_reviewed_for(pipeline_id: str, candidate_ids: list) -> list:
    """返回候选人中未通过审核的（candidate_id, name）列表；缺失状态视为已审核。"""
    stages = get_stages(pipeline_id)
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    output = _parse_stage_output(iv_stage) if iv_stage else {}
    interviews = output.get("interviews", []) or []
    targets = {str(value) for value in candidate_ids if value is not None}
    pending = []
    for iv in interviews:
        cid = iv.get("candidate_id")
        if str(cid) in targets and _status_of(iv) != "reviewed":
            pending.append((cid, iv.get("candidate_name", cid)))
    return pending


# ---------------------------------------------------------------------------
# 导出
# ---------------------------------------------------------------------------


def build_markdown(state: dict) -> str:
    lines = ["# 面试题手册\n"]
    for iv in state.get("interviews", []):
        name = iv.get("candidate_name", iv.get("candidate_id", ""))
        lines.append(f"## {name}\n")
        lines.append(f"**审核状态：** {'已审核' if _status_of(iv) == 'reviewed' else '待审核'}\n")
        for i, q in enumerate(iv.get("questions", []), 1):
            qtext = q.get("question", q.get("text", ""))
            lines.append(f"### Q{i}: {q.get('type', '')} ({q.get('difficulty', '')})\n")
            lines.append(f"**题目：** {qtext}\n")
            if q.get("follow_up"):
                lines.append(f"**追问：** {q['follow_up']}\n")
            if q.get("expected_points"):
                lines.append("**期望要点：**")
                for p in q["expected_points"]:
                    lines.append(f"- {p}")
            lines.append("")
    return "\n".join(lines)


def _set_run_font(run, size: int = 11, bold: bool = False):
    run.font.name = "微软雅黑"
    run.font.size = Pt(size)
    run.bold = bold
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "微软雅黑")


def build_docx(state: dict) -> io.BytesIO:
    """导出 Word：每个候选人一节，Q1..N（题型/难度/题目/追问/期望要点）。"""
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "微软雅黑"
    normal.font.size = Pt(11)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "微软雅黑")

    title = doc.add_paragraph()
    _set_run_font(title.add_run("面试题手册"), size=20, bold=True)

    for iv in state.get("interviews", []):
        name = iv.get("candidate_name", iv.get("candidate_id", ""))
        h = doc.add_paragraph()
        _set_run_font(h.add_run(f"{name}"), size=14, bold=True)

        st = doc.add_paragraph()
        _set_run_font(
            st.add_run(f"审核状态：{'已审核' if _status_of(iv) == 'reviewed' else '待审核'}"),
            size=10,
        )

        for i, q in enumerate(iv.get("questions", []), 1):
            qtext = q.get("question", q.get("text", ""))
            qh = doc.add_paragraph()
            _set_run_font(qh.add_run(f"Q{i}：{q.get('type', '')}（{q.get('difficulty', '')}）"), size=12, bold=True)
            qp = doc.add_paragraph()
            _set_run_font(qp.add_run(f"题目：{qtext}"))

            if q.get("follow_up"):
                fp = doc.add_paragraph()
                _set_run_font(fp.add_run(f"追问：{q['follow_up']}"))
            if q.get("expected_points"):
                for p in q["expected_points"]:
                    ep = doc.add_paragraph()
                    _set_run_font(ep.add_run(f"• {p}"))

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf
