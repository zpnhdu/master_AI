"""统一评估方案、候选人评估状态与小评决策包。"""

from __future__ import annotations

import json
import logging
import uuid
from copy import deepcopy
from datetime import datetime, timezone

from app.db import get_db, get_pipeline

logger = logging.getLogger(__name__)

COMBINATIONS = {"all", "any", "conditional"}
MODALITIES = {"written_test", "video_interview", "manual_interview"}
OPERATORS = {"gt", "gte", "lt", "lte", "eq"}
BRANCH_ACTIONS = {"ready", "review", "close"}
READY_EXECUTION_STATUSES = {"submitted", "completed", "evaluated"}
COMPARISON_DIMENSIONS = (
    "岗位要点匹配",
    "专业准确性",
    "分析逻辑",
    "方案可执行性",
    "证据与边界",
)
_COMPARISON_DIMENSION_ALIASES = {
    "job_coverage": "岗位要点匹配",
    "岗位要点": "岗位要点匹配",
    "岗位要点匹配": "岗位要点匹配",
    "professional_accuracy": "专业准确性",
    "专业准确性": "专业准确性",
    "analytical_logic": "分析逻辑",
    "分析逻辑": "分析逻辑",
    "solution_feasibility": "方案可执行性",
    "方案可执行性": "方案可执行性",
    "evidence_boundaries": "证据与边界",
    "证据与边界": "证据与边界",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def _parse(value, fallback):
    if isinstance(value, type(fallback)):
        return value
    try:
        parsed = json.loads(value or "")
    except (json.JSONDecodeError, TypeError):
        return deepcopy(fallback)
    return parsed if isinstance(parsed, type(fallback)) else deepcopy(fallback)


def _ensure_tables(conn=None) -> None:
    database = conn or get_db()
    database.execute(
        """CREATE TABLE IF NOT EXISTS assessment_plans (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            version INTEGER NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'draft',
            config LONGTEXT NOT NULL,
            actor_id VARCHAR(191) NOT NULL DEFAULT '',
            created_at VARCHAR(191) NOT NULL,
            activated_at VARCHAR(191),
            UNIQUE(pipeline_id, version)
        )"""
    )
    database.execute(
        """CREATE TABLE IF NOT EXISTS assessment_candidate_states (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL,
            candidate_name VARCHAR(191) NOT NULL DEFAULT '',
            plan_id VARCHAR(191) NOT NULL,
            plan_version INTEGER NOT NULL,
            queue_status VARCHAR(191) NOT NULL DEFAULT 'incomplete',
            step_results LONGTEXT NOT NULL,
            package LONGTEXT NOT NULL,
            created_at VARCHAR(191) NOT NULL,
            updated_at VARCHAR(191) NOT NULL,
            UNIQUE(pipeline_id, candidate_id, plan_id)
        )"""
    )
    database.execute(
        """CREATE TABLE IF NOT EXISTS assessment_flow_audit (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL DEFAULT '',
            action VARCHAR(191) NOT NULL,
            actor_id VARCHAR(191) NOT NULL DEFAULT '',
            detail VARCHAR(191) NOT NULL DEFAULT '{}',
            created_at VARCHAR(191) NOT NULL
        )"""
    )
    if conn is None:
        database.commit()


def _audit(conn, pipeline_id: str, action: str, actor_id: str = "", candidate_id: str = "", detail=None) -> None:
    conn.execute(
        """INSERT INTO assessment_flow_audit
           (id, pipeline_id, candidate_id, action, actor_id, detail, created_at)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (f"audit_{uuid.uuid4().hex}", pipeline_id, candidate_id, action, actor_id, _json(detail or {}), _now()),
    )


def validate_plan(config: dict) -> dict:
    """校验并规范化首版支持的三种评估组合。"""
    if not isinstance(config, dict):
        raise ValueError("评估方案格式无效")
    normalized = deepcopy(config)
    combination = normalized.get("combination", "")
    if combination not in COMBINATIONS:
        raise ValueError("评估组合只支持全部完成、任意完成一个或条件分支")

    raw_steps = normalized.get("steps")
    if not isinstance(raw_steps, list) or not raw_steps:
        raise ValueError("评估方案至少需要一个环节")
    steps = []
    step_ids = set()
    for index, raw_step in enumerate(raw_steps):
        if not isinstance(raw_step, dict):
            raise ValueError("评估环节格式无效")
        step_id = str(raw_step.get("id") or f"step_{index + 1}").strip()
        modality = raw_step.get("modality", "")
        if not step_id or step_id in step_ids:
            raise ValueError("评估环节 ID 不能为空或重复")
        if modality not in MODALITIES:
            raise ValueError("评估方式只支持笔试、视频面试和人工面试")
        weight = raw_step.get("weight", 0)
        if not isinstance(weight, (int, float)) or isinstance(weight, bool) or weight < 0:
            raise ValueError("评估权重必须是非负数字")
        pass_score = raw_step.get("pass_score")
        if pass_score is not None and (
            not isinstance(pass_score, (int, float)) or isinstance(pass_score, bool) or not 0 <= pass_score <= 100
        ):
            raise ValueError("环节通过分必须在 0-100 之间")
        step_ids.add(step_id)
        steps.append(
            {
                "id": step_id,
                "name": str(raw_step.get("name") or step_id),
                "modality": modality,
                "required": bool(raw_step.get("required", True)),
                "weight": weight,
                "pass_score": pass_score,
                "max_attempts": max(1, int(raw_step.get("max_attempts", 1))),
            }
        )
    normalized["steps"] = steps
    normalized["name"] = str(normalized.get("name") or "评估方案")
    normalized["handoff"] = "automatic"

    if combination == "any" and len(steps) < 2:
        raise ValueError("任意完成组合至少需要两个评估环节")
    if combination == "conditional":
        condition = normalized.get("condition")
        if not isinstance(condition, dict):
            raise ValueError("条件分支必须配置完整判断条件")
        if condition.get("source_step") not in step_ids or condition.get("operator") not in OPERATORS:
            raise ValueError("条件分支的来源环节或比较符无效")
        threshold = condition.get("threshold")
        if not isinstance(threshold, (int, float)) or isinstance(threshold, bool):
            raise ValueError("条件分支必须配置数字阈值")
        for prefix in ("then", "else"):
            step = condition.get(f"{prefix}_step")
            action = condition.get(f"{prefix}_action")
            if not step and not action:
                raise ValueError("条件分支必须同时配置满足和不满足后的路径")
            if step and step not in step_ids:
                raise ValueError("条件分支引用了不存在的评估环节")
            if action and action not in BRANCH_ACTIONS:
                raise ValueError("条件分支动作无效")
            if step and action:
                raise ValueError("同一条件分支不能同时配置环节和结束动作")
        normalized["condition"] = {
            "source_step": condition["source_step"],
            "operator": condition["operator"],
            "threshold": threshold,
            **{
                key: condition[key]
                for key in ("then_step", "then_action", "else_step", "else_action")
                if condition.get(key)
            },
        }
    else:
        normalized.pop("condition", None)
    return normalized


def _plan_from_row(row) -> dict | None:
    if not row:
        return None
    plan = dict(row)
    plan["config"] = _parse(plan.get("config"), {})
    return plan


def save_plan_draft(pipeline_id: str, config: dict, actor_id: str = "", conn=None) -> dict:
    if not get_pipeline(pipeline_id):
        raise ValueError("流水线不存在")
    normalized = validate_plan(config)
    database = conn or get_db()
    _ensure_tables(database)
    row = database.execute(
        "SELECT COALESCE(MAX(version), 0) AS latest_version FROM assessment_plans WHERE pipeline_id=%s",
        (pipeline_id,),
    ).fetchone()
    version = int(row["latest_version"] if row else 0) + 1
    plan_id = f"plan_{uuid.uuid4().hex}"
    database.execute(
        """INSERT INTO assessment_plans
           (id, pipeline_id, version, status, config, actor_id, created_at)
           VALUES (%s, %s, %s, 'draft', %s, %s, %s)""",
        (plan_id, pipeline_id, version, _json(normalized), actor_id, _now()),
    )
    _audit(database, pipeline_id, "plan_draft_created", actor_id, detail={"plan_id": plan_id, "version": version})
    if conn is None:
        database.commit()
    return {"id": plan_id, "pipeline_id": pipeline_id, "version": version, "status": "draft", "config": normalized}


def activate_plan(pipeline_id: str, plan_id: str, actor_id: str = "", conn=None) -> dict:
    database = conn or get_db()
    _ensure_tables(database)
    row = database.execute(
        "SELECT * FROM assessment_plans WHERE id=%s AND pipeline_id=%s",
        (plan_id, pipeline_id),
    ).fetchone()
    if not row:
        raise ValueError("评估方案不存在")
    database.execute(
        "UPDATE assessment_plans SET status='superseded' WHERE pipeline_id=%s AND status='active'",
        (pipeline_id,),
    )
    database.execute(
        "UPDATE assessment_plans SET status='active', activated_at=%s WHERE id=%s",
        (_now(), plan_id),
    )
    _audit(database, pipeline_id, "plan_activated", actor_id, detail={"plan_id": plan_id, "version": row["version"]})
    if conn is None:
        database.commit()
    active = _plan_from_row(database.execute("SELECT * FROM assessment_plans WHERE id=%s", (plan_id,)).fetchone())
    return active or {}


def get_active_plan(pipeline_id: str, conn=None) -> dict | None:
    database = conn or get_db()
    _ensure_tables(database)
    row = database.execute(
        "SELECT * FROM assessment_plans WHERE pipeline_id=%s AND status='active' ORDER BY version DESC LIMIT 1",
        (pipeline_id,),
    ).fetchone()
    return _plan_from_row(row)


def ensure_single_step_plan(pipeline_id: str, modality: str, actor_id: str = "system") -> dict:
    names = {
        "written_test": "在线笔试",
        "video_interview": "视频面试",
        "manual_interview": "人工面试",
    }
    active = get_active_plan(pipeline_id)
    if active:
        if not any(step["modality"] == modality for step in active["config"]["steps"]):
            config = deepcopy(active["config"])
            steps = list(config.get("steps") or [])
            steps.append(
                {
                    "id": modality,
                    "name": names[modality],
                    "modality": modality,
                    "required": True,
                    "weight": 100,
                }
            )
            config["steps"] = steps
            modalities = {step.get("modality") for step in steps}
            if {"written_test", "video_interview"}.issubset(modalities):
                config["name"] = "笔试 + 视频面试评估（视频优先）"
                config["selection_policy"] = "video_priority"
            draft = save_plan_draft(
                pipeline_id,
                config,
                actor_id,
            )
            activated = activate_plan(pipeline_id, draft["id"], actor_id)
            _migrate_plan_results(active, activated, actor_id)
            return activated
        return active
    draft = save_plan_draft(
        pipeline_id,
        {
            "name": f"{names[modality]}评估",
            "combination": "all",
            "steps": [{"id": modality, "name": names[modality], "modality": modality, "required": True, "weight": 100}],
            "source": "launch_confirmation",
        },
        actor_id,
    )
    return activate_plan(pipeline_id, draft["id"], actor_id)


def _migrate_plan_results(previous_plan: dict, active_plan: dict, actor_id: str) -> None:
    """Carry completed assessment evidence into an expanded plan version."""
    database = get_db()
    _ensure_tables(database)
    rows = database.execute(
        "SELECT * FROM assessment_candidate_states WHERE pipeline_id=%s AND plan_id=%s",
        (active_plan["pipeline_id"], previous_plan["id"]),
    ).fetchall()
    step_by_modality = {step["modality"]: step for step in active_plan["config"]["steps"]}
    migrated = 0
    for row in rows:
        previous_state = _state_from_row(row) or {}
        step_results = {}
        for result in (previous_state.get("step_results") or {}).values():
            target = step_by_modality.get(result.get("modality"))
            if target:
                step_results[target["id"]] = {**deepcopy(result), "step_id": target["id"]}
        if not step_results:
            continue
        queue_status, package = _build_package(
            active_plan,
            previous_state.get("candidate_id", ""),
            previous_state.get("candidate_name", ""),
            step_results,
        )
        timestamp = _now()
        database.execute(
            """INSERT INTO assessment_candidate_states
               (id, pipeline_id, candidate_id, candidate_name, plan_id, plan_version,
                queue_status, step_results, package, created_at, updated_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                f"assessment_{uuid.uuid4().hex}",
                active_plan["pipeline_id"],
                previous_state.get("candidate_id", ""),
                previous_state.get("candidate_name", ""),
                active_plan["id"],
                active_plan["version"],
                queue_status,
                _json(step_results),
                _json(package),
                timestamp,
                timestamp,
            ),
        )
        migrated += 1
    if migrated:
        _audit(
            database,
            active_plan["pipeline_id"],
            "plan_results_migrated",
            actor_id,
            detail={"from_plan_id": previous_plan["id"], "to_plan_id": active_plan["id"], "count": migrated},
        )
        database.commit()


def _compare(score: float, operator: str, threshold: float) -> bool:
    return {
        "gt": score > threshold,
        "gte": score >= threshold,
        "lt": score < threshold,
        "lte": score <= threshold,
        "eq": score == threshold,
    }[operator]


def _step_ready(result: dict | None) -> bool:
    if not result:
        return False
    return (
        result.get("execution_status") in READY_EXECUTION_STATUSES
        and result.get("scoring_status") == "succeeded"
        and result.get("score") is not None
        and result.get("review_status") in {"not_required", "completed"}
    )


def _step_blocked(result: dict | None) -> bool:
    return bool(
        result
        and (
            result.get("scoring_status") == "failed"
            or result.get("review_status") == "pending"
            or result.get("execution_status") == "failed"
        )
    )


def _video_priority_path(config: dict, step_results: dict) -> tuple[list[str], str, list[str]] | None:
    """Select video when both assessment modalities have results, otherwise use the available one."""
    if config.get("combination") == "conditional":
        return None
    step_ids = {step.get("modality"): step["id"] for step in config["steps"]}
    video_id = step_ids.get("video_interview")
    written_id = step_ids.get("written_test")
    if not video_id or not written_id:
        return None

    video = step_results.get(video_id)
    written = step_results.get(written_id)
    selected_id = video_id if video is not None else written_id if written is not None else ""
    if not selected_id:
        return [video_id, written_id], "incomplete", []

    selected_result = step_results.get(selected_id)
    if _step_blocked(selected_result):
        return [selected_id], "incomplete", [selected_id]
    if _step_ready(selected_result):
        return [selected_id], "ready_for_decision", []
    return [selected_id], "incomplete", []


def _selected_path(config: dict, step_results: dict) -> tuple[list[str], str, list[str]]:
    steps = config["steps"]
    combination = config["combination"]
    video_priority = _video_priority_path(config, step_results)
    if video_priority is not None:
        return video_priority
    if combination == "all":
        selected = [step["id"] for step in steps if step["required"]]
        blocked = [step_id for step_id in selected if _step_blocked(step_results.get(step_id))]
        if blocked:
            return selected, "incomplete", blocked
        ready = all(_step_ready(step_results.get(step_id)) for step_id in selected)
        return selected, "ready_for_decision" if ready else "incomplete", []

    if combination == "any":
        ready_step = next((step["id"] for step in steps if _step_ready(step_results.get(step["id"]))), "")
        if ready_step:
            return [ready_step], "ready_for_decision", []
        unattempted = [step["id"] for step in steps if step["id"] not in step_results]
        if unattempted:
            return unattempted, "incomplete", []
        blocked = [step["id"] for step in steps if _step_blocked(step_results.get(step["id"]))]
        return [], "incomplete", blocked

    condition = config["condition"]
    source_id = condition["source_step"]
    source = step_results.get(source_id)
    if _step_blocked(source):
        return [source_id], "incomplete", [source_id]
    if not _step_ready(source):
        return [source_id], "incomplete", []
    matched = _compare(float(source["score"]), condition["operator"], float(condition["threshold"]))
    prefix = "then" if matched else "else"
    branch_step = condition.get(f"{prefix}_step")
    branch_action = condition.get(f"{prefix}_action")
    selected = [source_id] + ([branch_step] if branch_step else [])
    if branch_step:
        result = step_results.get(branch_step)
        if _step_blocked(result):
            return selected, "incomplete", [branch_step]
        return selected, "ready_for_decision" if _step_ready(result) else "incomplete", []
    if branch_action == "review" and source.get("review_status") != "completed":
        return selected, "incomplete", [source_id]
    if branch_action == "close":
        return selected, "closed_incomplete", []
    return selected, "ready_for_decision", []


def _overall_score(config: dict, step_results: dict, selected_path: list[str], queue_status: str):
    if queue_status != "ready_for_decision":
        return None
    step_map = {step["id"]: step for step in config["steps"]}
    values = []
    for step_id in selected_path:
        result = step_results.get(step_id) or {}
        if result.get("score") is None:
            continue
        values.append((float(result["score"]), float(step_map[step_id].get("weight", 0))))
    if not values:
        return None
    total_weight = sum(weight for _, weight in values)
    if total_weight > 0:
        return round(sum(value * weight for value, weight in values) / total_weight)
    return round(sum(value for value, _ in values) / len(values))


def _build_package(plan: dict, candidate_id: str, candidate_name: str, step_results: dict) -> tuple[str, dict]:
    config = plan["config"]
    selected_path, queue_status, blockers = _selected_path(config, step_results)
    overall_score = _overall_score(config, step_results, selected_path, queue_status)
    step_map = {step["id"]: step for step in config["steps"]}
    next_actions = []
    if queue_status == "incomplete":
        for step_id in selected_path:
            if step_id not in step_results:
                step = step_map[step_id]
                next_actions.append(
                    {
                        "step_id": step_id,
                        "name": step["name"],
                        "modality": step["modality"],
                        "handoff": config.get("handoff", "automatic"),
                    }
                )
    package = {
        "candidate_id": candidate_id,
        "candidate_name": candidate_name,
        "plan_id": plan["id"],
        "plan_version": plan["version"],
        "plan_name": config["name"],
        "combination": config["combination"],
        "selected_path": selected_path,
        "queue_status": queue_status,
        "blockers": blockers,
        "overall_score": overall_score,
        "decision_score_source": (
            (step_results.get(selected_path[0]) or {}).get("modality", "")
            if queue_status == "ready_for_decision" and selected_path
            else ""
        ),
        "next_actions": next_actions,
        "step_results": deepcopy(step_results),
        "score_provenance": [
            {
                "step_id": step_id,
                "modality": (step_results.get(step_id) or {}).get("modality", ""),
                "score": (step_results.get(step_id) or {}).get("score"),
                "scoring_version": (step_results.get(step_id) or {}).get("scoring_version", ""),
            }
            for step_id in selected_path
        ],
        "updated_at": _now(),
    }
    if queue_status == "ready_for_decision":
        package["ready_at"] = _now()
    return queue_status, package


def _state_from_row(row) -> dict | None:
    if not row:
        return None
    state = dict(row)
    state["step_results"] = _parse(state.get("step_results"), {})
    state["package"] = _parse(state.get("package"), {})
    return state


def record_step_result(
    *,
    pipeline_id: str,
    candidate_id: str,
    candidate_name: str,
    modality: str,
    execution_status: str,
    scoring_status: str,
    review_status: str,
    result_status: str,
    score,
    evidence: dict | None = None,
    scoring_version: str = "",
    red_flags: list | None = None,
    metadata: dict | None = None,
    actor_id: str = "system",
) -> dict:
    if modality not in MODALITIES:
        raise ValueError("不支持的评估方式")
    if score is not None and (not isinstance(score, (int, float)) or isinstance(score, bool) or not 0 <= score <= 100):
        raise ValueError("评估分数必须在 0-100 之间")
    database = get_db()
    _ensure_tables(database)
    plan = get_active_plan(pipeline_id, database)
    if not plan:
        raise ValueError("当前岗位还没有已确认的评估方案")
    step = next((item for item in plan["config"]["steps"] if item["modality"] == modality), None)
    if not step and modality in {"written_test", "video_interview"}:
        ensure_single_step_plan(pipeline_id, modality, actor_id=f"{actor_id}_plan_sync")
        plan = get_active_plan(pipeline_id, database)
        step = next((item for item in plan["config"]["steps"] if item["modality"] == modality), None)
    if not step:
        raise ValueError("当前评估方式不在已确认方案中")

    row = database.execute(
        """SELECT * FROM assessment_candidate_states
           WHERE pipeline_id=%s AND candidate_id=%s AND plan_id=%s""",
        (pipeline_id, candidate_id, plan["id"]),
    ).fetchone()
    state = _state_from_row(row)
    step_results = deepcopy((state or {}).get("step_results", {}))
    step_results[step["id"]] = {
        "step_id": step["id"],
        "modality": modality,
        "execution_status": execution_status,
        "scoring_status": scoring_status,
        "review_status": review_status,
        "result_status": result_status,
        "score": score,
        "evidence": evidence or {},
        "scoring_version": scoring_version,
        "red_flags": red_flags or [],
        "metadata": metadata or {},
        "updated_at": _now(),
    }
    queue_status, package = _build_package(plan, candidate_id, candidate_name, step_results)
    timestamp = _now()
    if state:
        database.execute(
            """UPDATE assessment_candidate_states
               SET candidate_name=%s, queue_status=%s, step_results=%s, package=%s, updated_at=%s WHERE id=%s""",
            (candidate_name, queue_status, _json(step_results), _json(package), timestamp, state["id"]),
        )
    else:
        database.execute(
            """INSERT INTO assessment_candidate_states
               (id, pipeline_id, candidate_id, candidate_name, plan_id, plan_version,
                queue_status, step_results, package, created_at, updated_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                f"assessment_{uuid.uuid4().hex}",
                pipeline_id,
                candidate_id,
                candidate_name,
                plan["id"],
                plan["version"],
                queue_status,
                _json(step_results),
                _json(package),
                timestamp,
                timestamp,
            ),
        )
    _audit(
        database,
        pipeline_id,
        "step_result_recorded",
        actor_id,
        candidate_id,
        {"modality": modality, "queue_status": queue_status, "score": score},
    )
    database.commit()
    return {"queue_status": queue_status, "package": package}


def resolve_review(
    pipeline_id: str,
    candidate_id: str,
    modality: str,
    actor_id: str,
    reason: str,
    override_score=None,
) -> dict:
    if not reason.strip():
        raise ValueError("人工复核必须填写原因")
    database = get_db()
    _ensure_tables(database)
    plan = get_active_plan(pipeline_id, database)
    if not plan:
        raise ValueError("当前岗位还没有已确认的评估方案")
    row = database.execute(
        """SELECT * FROM assessment_candidate_states
           WHERE pipeline_id=%s AND candidate_id=%s AND plan_id=%s""",
        (pipeline_id, candidate_id, plan["id"]),
    ).fetchone()
    state = _state_from_row(row)
    if not state:
        raise ValueError("候选人还没有可复核的评估结果")
    step = next((item for item in plan["config"]["steps"] if item["modality"] == modality), None)
    result = (state["step_results"] or {}).get((step or {}).get("id", ""))
    if not step or not result:
        raise ValueError("评估环节不存在")
    original_score = result.get("score")
    result["review_status"] = "completed"
    result["review"] = {"actor_id": actor_id, "reason": reason, "reviewed_at": _now()}
    if override_score is not None:
        if (
            not isinstance(override_score, (int, float))
            or isinstance(override_score, bool)
            or not 0 <= override_score <= 100
        ):
            raise ValueError("人工覆盖分数必须在 0-100 之间")
        result["score"] = override_score
        result["scoring_status"] = "succeeded"
        result["scoring_version"] = "manual_override"
        result["result_status"] = "passed" if override_score >= 60 else "not_passed"
        evaluation = result.setdefault("evidence", {}).setdefault("evaluation", {})
        if isinstance(evaluation, dict):
            evaluation["score_status"] = "manual_final"
            evaluation["provisional_score"] = None
            evaluation["manual_override_score"] = override_score
            evaluation["manual_review_reason"] = reason
    queue_status, package = _build_package(plan, candidate_id, state["candidate_name"], state["step_results"])
    database.execute(
        """UPDATE assessment_candidate_states
           SET queue_status=%s, step_results=%s, package=%s, updated_at=%s WHERE id=%s""",
        (queue_status, _json(state["step_results"]), _json(package), _now(), state["id"]),
    )
    _audit(
        database,
        pipeline_id,
        "review_resolved",
        actor_id,
        candidate_id,
        {"modality": modality, "reason": reason, "override_score": override_score},
    )
    database.commit()
    if override_score is not None:
        try:
            from hr_harness.memory.core import MemorySystem

            pipeline = get_pipeline(pipeline_id) or {}
            MemorySystem(pipeline_id, actor_user_id=actor_id).learn_from_interview_score_override(
                str(pipeline.get("role") or ""),
                modality,
                original_score,
                override_score,
                reason,
                actor_user_id=actor_id,
            )
        except Exception:
            logger.exception("Failed to learn from interview score override", extra={"pipeline_id": pipeline_id})
    return {"queue_status": queue_status, "package": package}


def get_candidate_assessment(pipeline_id: str, candidate_id: str) -> dict | None:
    database = get_db()
    _ensure_tables(database)
    plan = get_active_plan(pipeline_id, database)
    if not plan:
        return None
    row = database.execute(
        """SELECT * FROM assessment_candidate_states
           WHERE pipeline_id=%s AND candidate_id=%s AND plan_id=%s""",
        (pipeline_id, candidate_id, plan["id"]),
    ).fetchone()
    return _state_from_row(row)


def list_decision_queue(pipeline_id: str) -> dict:
    database = get_db()
    _ensure_tables(database)
    plan = get_active_plan(pipeline_id, database)
    queues = {"ready_for_decision": [], "incomplete": [], "closed_incomplete": []}
    if not plan:
        return {"plan": None, **queues, "counts": {key: 0 for key in queues}}
    rows = database.execute(
        """SELECT * FROM assessment_candidate_states
           WHERE pipeline_id=%s AND plan_id=%s ORDER BY updated_at DESC""",
        (pipeline_id, plan["id"]),
    ).fetchall()
    for row in rows:
        state = _state_from_row(row) or {}
        queues.setdefault(state.get("queue_status", "incomplete"), []).append(state.get("package", {}))
    return {
        "plan": plan,
        **queues,
        "counts": {key: len(value) for key, value in queues.items()},
    }


def _as_list(value) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)] if value and str(value).strip() else []


def _comparison_dimension_scores(evidence: dict) -> dict[str, int]:
    """从冻结的逐题评分项确定性聚合综合报告五维分数。"""
    evaluation = evidence.get("evaluation", {}) if isinstance(evidence.get("evaluation"), dict) else {}
    criteria_groups = []
    for item in evidence.get("answers", []) if isinstance(evidence.get("answers"), list) else []:
        if isinstance(item, dict) and isinstance(item.get("criteria"), list):
            criteria_groups.append(item["criteria"])
    if not criteria_groups:
        for item in evaluation.get("detail", []) if isinstance(evaluation.get("detail"), list) else []:
            if isinstance(item, dict) and isinstance(item.get("criteria"), list):
                criteria_groups.append(item["criteria"])

    values: dict[str, list[tuple[float, float]]] = {name: [] for name in COMPARISON_DIMENSIONS}
    for criteria in criteria_groups:
        for criterion in criteria:
            if not isinstance(criterion, dict):
                continue
            raw_name = str(criterion.get("dimension") or criterion.get("name") or criterion.get("id") or "")
            name = _COMPARISON_DIMENSION_ALIASES.get(raw_name)
            score = criterion.get("score")
            weight = criterion.get("weight", 1)
            if (
                not name
                or not isinstance(score, (int, float))
                or isinstance(score, bool)
                or not isinstance(weight, (int, float))
                or isinstance(weight, bool)
                or weight <= 0
            ):
                continue
            values[name].append((float(score), float(weight)))

    scores = {
        name: round(sum(score * weight for score, weight in items) / sum(weight for _, weight in items))
        for name, items in values.items()
        if items
    }
    if scores:
        return scores

    raw_dimensions = evaluation.get("dimension_scores", {})
    if not isinstance(raw_dimensions, dict):
        return {}
    for raw_name, score in raw_dimensions.items():
        name = _COMPARISON_DIMENSION_ALIASES.get(str(raw_name))
        if name and isinstance(score, (int, float)) and not isinstance(score, bool):
            scores[name] = round(float(score))
    return scores


def build_report_inputs(pipeline_id: str, minimum_score: float | None = None) -> dict:
    """将可决策评估包转换为小评报告输入，禁止使用简历分或默认分补齐。"""
    queue = list_decision_queue(pipeline_id)
    packages = queue["ready_for_decision"]
    if minimum_score is not None:
        packages = [
            package
            for package in packages
            if package.get("overall_score") is not None and package["overall_score"] >= minimum_score
        ]
    assessments = []
    interview_records = []

    for package in packages:
        dimensions = {}
        comparison_dimension_values: dict[str, list[int]] = {name: [] for name in COMPARISON_DIMENSIONS}
        highlights = []
        concerns = []
        answers = []
        for step_id in package.get("selected_path", []):
            result = package.get("step_results", {}).get(step_id, {})
            evidence = result.get("evidence", {})
            for name, value in _comparison_dimension_scores(evidence).items():
                comparison_dimension_values[name].append(value)
            modality = result.get("modality", "")
            if modality == "manual_interview":
                assessment = evidence.get("assessment", {})
                dimensions.update(assessment.get("dimensions", {}))
                highlights.extend(_as_list(assessment.get("highlights")))
                concerns.extend(_as_list(assessment.get("concerns")))
            elif modality == "video_interview":
                evaluation = evidence.get("evaluation", {})
                dimensions.update(evaluation.get("dimension_scores", {}))
                highlights.extend(_as_list(evaluation.get("strengths")))
                concerns.extend(_as_list(evaluation.get("weaknesses")))
            elif modality == "written_test":
                dimensions["在线笔试"] = result.get("score")
                highlights.extend(_as_list(evidence.get("evaluation", {}).get("comment")))
            answers.extend(evidence.get("answers", []))

        score = package.get("overall_score")
        recommendation = "通过" if score >= 60 else "淘汰"
        assessments.append(
            {
                "candidate_id": package["candidate_id"],
                "candidate_name": package.get("candidate_name", ""),
                "dimensions": dimensions,
                "comparison_dimensions": {
                    name: round(sum(values) / len(values))
                    for name, values in comparison_dimension_values.items()
                    if values
                },
                "highlights": highlights,
                "concerns": concerns,
                "recommendation": recommendation,
                "overall_score": score,
                "score_provenance": package.get("score_provenance", []),
            }
        )
        interview_records.append(
            {
                "candidate_id": package["candidate_id"],
                "candidate_name": package.get("candidate_name", ""),
                "interviewer": "统一评估流程",
                "answers": answers,
            }
        )

    return {
        "queue": queue,
        "assessment_packages": packages,
        "candidate_ids": [package["candidate_id"] for package in packages],
        "assessments": assessments,
        "interview_records": interview_records,
    }
