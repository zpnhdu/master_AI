"""锅圈食汇 FastAPI 应用入口。"""

import os

from app.environment import load_environment

# 配置必须在导入业务模块前加载，部分模块会在导入阶段读取环境变量。
load_environment()

from app.audit.logger import get_logger  # noqa: E402
from app.bootstrap import create_app  # noqa: E402

logger = get_logger("main")
logger.info(
    f"OPENAI_API_BASE={os.getenv('OPENAI_API_BASE')}, KEY loaded: {bool(os.getenv('OPENAI_API_KEY'))}",
    extra={"source": "ENV"},
)

app = create_app()
