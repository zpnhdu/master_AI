"""Pipeline、阶段与 JD 锁领域模块。

从 ``app/db/__init__.py`` 迁移的实现。事务、连接获取与跨函数调用通过
``_db.`` 动态属性查找解析，保证测试对 ``app.db.<name>`` 的 monkeypatch
语义与单文件时期完全一致。delete_pipeline 的跨表删除顺序与
lock_pipeline_jd 的 SELECT ... FOR UPDATE 边界逐行保持原样。
"""

import json
from datetime import datetime
from typing import Optional

from app import db as _db
from app import pending_repository as _pending_repository


# 流水线操作
def _default_pipeline_owner_id(conn) -> str:
    row = conn.execute("SELECT id FROM auth_users WHERE role_id='admin' ORDER BY created_at LIMIT 1").fetchone()
    return str(row["id"]) if row else "user_shanghai"


def create_pipeline(
    pipeline_id: str,
    role: str,
    pipeline_type: str = "tech",
    enabled_agents: list = None,
    owner_user_id: str = "",
    tenant_id: str = "tenant_default",
) -> dict:
    conn = _db.get_db()
    role = _db.normalize_role_name(role)
    pipeline_type = _db.normalize_job_type(pipeline_type)
    agents_json = json.dumps(enabled_agents or [], ensure_ascii=False)
    effective_owner_id = owner_user_id or _default_pipeline_owner_id(conn)
    conn.execute(
        "INSERT INTO pipelines (id, role, type, enabled_agents, owner_user_id, tenant_id) VALUES (%s, %s, %s, %s, %s, %s)",
        (pipeline_id, role, pipeline_type, agents_json, effective_owner_id, tenant_id or "tenant_default"),
    )
    conn.commit()
    return {
        "id": pipeline_id,
        "role": role,
        "status": "running",
        "type": pipeline_type,
        "enabled_agents": enabled_agents or [],
        "owner_user_id": effective_owner_id,
        "tenant_id": tenant_id or "tenant_default",
        "jd_locked_at": None,
        "jd_locked_by_stage": "",
        "cloned_from_pipeline_id": "",
    }


def delete_pipeline(pipeline_id: str) -> bool:
    """Delete a pipeline and all related data across all tables."""
    conn = _db.get_db()
    try:
        # 删行前先收集存储资源引用(OSS/本地),行删成功后尽力清理远端对象
        media_asset_keys = conn.execute(
            "SELECT storage_backend, storage_key FROM media_assets WHERE pipeline_id=%s",
            (pipeline_id,),
        ).fetchall()
        stream_names = conn.execute(
            "SELECT DISTINCT stream_name FROM interview_sessions WHERE pipeline_id=%s AND stream_name IS NOT NULL AND stream_name != ''",
            (pipeline_id,),
        ).fetchall()
        # 海报/媒体数据存在指向 pipelines 的外键，且彼此还有外键链
        # （附件→消息/资产、版本→资产/自身、任务→会话/指令/版本），
        # 必须先按依赖顺序清除，否则删除 pipelines 行会触发 1451。
        conn.execute("DELETE FROM xiao_hai_generation_jobs WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM poster_generation_jobs WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute(
            "DELETE FROM conversation_message_attachments WHERE message_id IN (SELECT id FROM conversation_messages WHERE session_id IN (SELECT id FROM conversation_sessions WHERE pipeline_id=%s))",
            (pipeline_id,),
        )
        conn.execute(
            "DELETE FROM conversation_message_attachments WHERE asset_id IN (SELECT id FROM media_assets WHERE pipeline_id=%s)",
            (pipeline_id,),
        )
        # poster_versions 自引用 parent_version_id，先置空再删，避免行级外键冲突
        conn.execute("UPDATE poster_versions SET parent_version_id=NULL WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM poster_versions WHERE pipeline_id=%s", (pipeline_id,))
        # media_assets 被 poster_versions.image_asset_id 引用，须在版本之后删除
        conn.execute("DELETE FROM media_assets WHERE pipeline_id=%s", (pipeline_id,))
        # 核心流水线数据
        conn.execute("DELETE FROM candidates WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM messages WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM pipeline_stages WHERE pipeline_id=%s", (pipeline_id,))
        # 面试中心
        conn.execute("DELETE FROM interview_sessions WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM interview_schedules WHERE pipeline_id=%s", (pipeline_id,))
        session_rows = conn.execute(
            "SELECT id FROM conversation_sessions WHERE pipeline_id=%s", (pipeline_id,)
        ).fetchall()
        session_ids = [row[0] for row in session_rows]
        for session_id in session_ids:
            conn.execute("DELETE FROM conversation_messages WHERE session_id=%s", (session_id,))
            conn.execute("DELETE FROM conversation_commands WHERE session_id=%s", (session_id,))
        conn.execute("DELETE FROM active_conversation_sessions WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM conversation_sessions WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM elimination_records WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM aggregate_report_jobs WHERE pipeline_id=%s", (pipeline_id,))
        # 触达、日志、规则
        conn.execute("DELETE FROM outreach_events WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM agent_call_logs WHERE pipeline_id=%s", (pipeline_id,))
        _pending_repository.delete_pending_for_pipeline(conn, pipeline_id)
        conn.execute("DELETE FROM ontology_rules WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM memory_rules WHERE pipeline_id=%s", (pipeline_id,))
        conn.execute("DELETE FROM rpa_tasks WHERE pipeline_id=%s", (pipeline_id,))
        # 最后删流水线本体
        conn.execute("DELETE FROM pipelines WHERE id=%s", (pipeline_id,))
        conn.commit()

        # 行已删干净,再清理 OSS/本地对象。流名按候选人命名、可能被多条流水线
        # 共用,仅当删除后不再被任何会话引用时才清理录制与截图。
        to_clean_streams = [
            row["stream_name"]
            for row in stream_names
            if conn.execute(
                "SELECT COUNT(*) FROM interview_sessions WHERE stream_name=%s", (row["stream_name"],)
            ).fetchone()[0]
            == 0
        ]
        try:
            from app.pipeline_cleanup import cleanup_pipeline_storage

            cleanup_pipeline_storage(
                pipeline_id,
                [(row["storage_backend"], row["storage_key"]) for row in media_asset_keys],
                to_clean_streams,
            )
        except Exception as e:
            print(f"[DB] pipeline storage cleanup error: {e}")
        return True
    except Exception as e:
        print(f"[DB] delete_pipeline error: {e}")
        return False


def update_pipeline(pipeline_id: str, status: str, context: dict = None, conn=None):
    conn_local = conn or _db.get_db()
    if context:
        conn_local.execute(
            "UPDATE pipelines SET status=%s, context=%s, updated_at=NOW() WHERE id=%s",
            (status, json.dumps(context, ensure_ascii=False), pipeline_id),
        )
    else:
        conn_local.execute("UPDATE pipelines SET status=%s, updated_at=NOW() WHERE id=%s", (status, pipeline_id))
    if conn is None:
        conn_local.commit()


def claim_pipeline_run(pipeline_id: str) -> bool:
    """Atomically reserve a pipeline for one background run."""
    conn = _db.get_db()
    cursor = conn.execute(
        """UPDATE pipelines
           SET status='starting', updated_at=NOW()
           WHERE id=%s AND status NOT IN ('starting', 'running', 'running_auto')""",
        (pipeline_id,),
    )
    conn.commit()
    return cursor.rowcount == 1


def update_pipeline_agents(pipeline_id: str, enabled_agents: list):
    """Update the enabled_agents list for a pipeline."""
    conn = _db.get_db()
    conn.execute(
        "UPDATE pipelines SET enabled_agents=%s, updated_at=NOW() WHERE id=%s",
        (json.dumps(enabled_agents, ensure_ascii=False), pipeline_id),
    )
    conn.commit()


def get_pipeline(pipeline_id: str) -> Optional[dict]:
    return _db._pipeline_query_call("get_pipeline", pipeline_id)


def lock_pipeline_jd(
    pipeline_id: str,
    locked_by_stage: str = "xiao_wen",
    expected_revision: Optional[int] = None,
) -> Optional[dict]:
    """Atomically lock a pipeline's JD and return its lock metadata.

    Locking is idempotent: repeated handoffs preserve the original timestamp and
    stage. When ``expected_revision`` is provided, a revision mismatch returns
    ``None`` without locking. A missing pipeline also returns ``None``.
    """
    now = datetime.utcnow().isoformat()
    with _db.transaction() as conn:
        pipeline_query = "SELECT id FROM pipelines WHERE id=%s FOR UPDATE"
        existing = conn.execute(pipeline_query, (pipeline_id,)).fetchone()
        if not existing:
            return None
        if expected_revision is not None:
            revision_query = (
                "SELECT output FROM pipeline_stages WHERE pipeline_id=%s AND stage_id=%s LIMIT 1 FOR UPDATE"
            )
            stage = conn.execute(
                revision_query,
                (pipeline_id, "jd_write"),
            ).fetchone()
            raw_output = stage["output"] if stage else {}
            if isinstance(raw_output, str):
                try:
                    raw_output = json.loads(raw_output)
                except (TypeError, json.JSONDecodeError):
                    raw_output = {}
            if isinstance(raw_output, str):
                try:
                    raw_output = json.loads(raw_output)
                except (TypeError, json.JSONDecodeError):
                    raw_output = {}
            try:
                current_revision = int(raw_output.get("revision") or 0) if isinstance(raw_output, dict) else 0
            except (TypeError, ValueError):
                current_revision = 0
            if current_revision != expected_revision:
                return None
        conn.execute(
            """UPDATE pipelines
               SET jd_locked_at=COALESCE(NULLIF(jd_locked_at, ''), %s),
                   jd_locked_by_stage=COALESCE(NULLIF(jd_locked_by_stage, ''), %s),
                   updated_at=%s
               WHERE id=%s""",
            (now, locked_by_stage or "xiao_wen", now, pipeline_id),
        )
        row = conn.execute(
            "SELECT jd_locked_at, jd_locked_by_stage FROM pipelines WHERE id=%s", (pipeline_id,)
        ).fetchone()
    return dict(row) if row else None


def list_pipelines() -> list[dict]:
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM pipelines ORDER BY created_at DESC").fetchall()
    result = []
    for r in rows:
        d = dict(r)
        ea = d.get("enabled_agents", "")
        if isinstance(ea, str) and ea:
            try:
                d["enabled_agents"] = json.loads(ea)
            except (json.JSONDecodeError, TypeError):
                d["enabled_agents"] = []
        elif not ea:
            d["enabled_agents"] = []
        result.append(d)
    return result


def list_pipelines_for_user(
    user_id: str,
    tenant_id: str = "tenant_default",
    include_all: bool = False,
    q: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    owner_user_id: str | None = None,
) -> list[dict]:
    return _db._pipeline_query_call(
        "list_pipelines_for_user",
        user_id,
        tenant_id,
        include_all,
        q,
        created_from,
        created_to,
        owner_user_id,
    )


def get_pipeline_for_user(
    pipeline_id: str, user_id: str, tenant_id: str = "tenant_default", include_all: bool = False
) -> Optional[dict]:
    return _db._pipeline_query_call("get_pipeline_for_user", pipeline_id, user_id, tenant_id, include_all)


# 阶段操作
def create_stage(pipeline_id: str, stage_id: str, stage_name: str, conn=None):
    conn_local = conn or _db.get_db()
    conn_local.execute(
        "INSERT INTO pipeline_stages (pipeline_id, stage_id, stage_name, status, started_at) VALUES (%s,%s,%s,%s,NOW())",
        (pipeline_id, stage_id, stage_name, "running"),
    )
    if conn is None:
        conn_local.commit()


def update_stage(pipeline_id: str, stage_id: str, status: str, output: dict = None, conn=None):
    conn_local = conn or _db.get_db()
    existing = conn_local.execute(
        "SELECT id FROM pipeline_stages WHERE pipeline_id=%s AND stage_id=%s ORDER BY id DESC LIMIT 1",
        (pipeline_id, stage_id),
    ).fetchone()

    if existing:
        if output is not None:
            conn_local.execute(
                """UPDATE pipeline_stages
                   SET status=%s, output=%s,
                       completed_at=CASE WHEN %s='done' THEN NOW() ELSE NULL END
                   WHERE id=%s""",
                (status, json.dumps(output, ensure_ascii=False), status, existing["id"]),
            )
        else:
            conn_local.execute(
                """UPDATE pipeline_stages
                   SET status=%s, completed_at=CASE WHEN %s='done' THEN NOW() ELSE NULL END
                   WHERE id=%s""",
                (status, status, existing["id"]),
            )
    else:
        # 阶段尚未创建（异步竞态），此处补充插入
        if output is not None:
            conn_local.execute(
                """INSERT INTO pipeline_stages
                   (pipeline_id, stage_id, stage_name, status, output, started_at, completed_at)
                   VALUES (%s,%s,%s,%s,%s,NOW(),CASE WHEN %s='done' THEN NOW() ELSE NULL END)""",
                (pipeline_id, stage_id, stage_id, status, json.dumps(output, ensure_ascii=False), status),
            )
        else:
            conn_local.execute(
                "INSERT INTO pipeline_stages (pipeline_id, stage_id, stage_name, status, started_at) VALUES (%s,%s,%s,%s,NOW())",
                (pipeline_id, stage_id, stage_id, status),
            )
    if conn is None:
        conn_local.commit()


def get_stages(pipeline_id: str) -> list[dict]:
    return _db._pipeline_query_call("get_stages", pipeline_id)
