"""面试会话、日程、指令台账、排名与直播状态领域模块。

从 ``app/db/__init__.py`` 迁移的实现。连接获取、跨函数调用与模块常量
（_db.SHANGHAI_TZ、_db.INTERVIEW_SESSION_TIMEOUT_MINUTES、
INTERVIEW_PASS_SCORE_THRESHOLD 等）通过 ``_db.`` 动态属性查找解析，
保证测试对 ``app.db.<name>`` 的 monkeypatch 语义与单文件时期完全一致
（test_mass_interview_streams 直接 patch app.db.get_db 后调用
_update_stream_status_for_session / _update_recording_url_for_session）。
"""

import json
import os
from datetime import datetime, timedelta
from typing import Optional

from app import db as _db

# ============ 面试日程增删改查 ============


def save_interview_schedule(schedule: dict) -> str:
    """Save an interview schedule. Returns the schedule ID."""
    conn = _db.get_db()
    sid = schedule.get("id", f"iv_{int(datetime.now().timestamp())}")
    conn.execute(
        "REPLACE INTO interview_schedules (id, pipeline_id, candidate_id, date, time, interviewer, method, round, status, notes, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())",
        (
            sid,
            schedule.get("pipeline_id", ""),
            schedule.get("candidate_id", ""),
            schedule.get("date", ""),
            schedule.get("time", ""),
            schedule.get("interviewer", ""),
            schedule.get("method", ""),
            schedule.get("round", ""),
            schedule.get("status", "scheduled"),
            schedule.get("notes", ""),
        ),
    )
    conn.commit()
    return sid


def get_interview_schedules(pipeline_id: str) -> list[dict]:
    return _db._pipeline_query_call("get_interview_schedules", pipeline_id)


def cancel_interview_schedule(schedule_id: str) -> bool:
    """Cancel a schedule without deleting its audit trail."""
    conn = _db.get_db()
    cursor = conn.execute("UPDATE interview_schedules SET status='cancelled' WHERE id=%s", (schedule_id,))
    conn.commit()
    return cursor.rowcount > 0


# ============ 面试对话命令台账 ============


_INTERVIEW_COMMAND_JSON_FIELDS = {"payload", "preview", "result"}
_INTERVIEW_COMMAND_UPDATE_FIELDS = {
    "source",
    "source_text",
    "intent",
    "status",
    "payload",
    "preview",
    "result",
    "executed_at",
}


def _parse_interview_command_row(row) -> Optional[dict]:
    if not row:
        return None
    command = dict(row)
    for field in _INTERVIEW_COMMAND_JSON_FIELDS:
        raw = command.get(field)
        if isinstance(raw, str):
            try:
                command[field] = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                command[field] = {}
    return command


def save_interview_command(command: dict) -> str:
    """Persist a parsed interview command and return its stable ID."""
    conn = _db.get_db()
    command_id = command["id"]
    conn.execute(
        """INSERT INTO interview_commands
           (id, pipeline_id, source, source_text, intent, status, payload, preview, result)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (
            command_id,
            command["pipeline_id"],
            command.get("source", "text"),
            command.get("source_text", ""),
            command.get("intent", ""),
            command.get("status", "draft"),
            json.dumps(command.get("payload", {}), ensure_ascii=False),
            json.dumps(command.get("preview", {}), ensure_ascii=False),
            json.dumps(command.get("result", {}), ensure_ascii=False),
        ),
    )
    conn.commit()
    return command_id


def get_interview_command(command_id: str) -> Optional[dict]:
    conn = _db.get_db()
    row = conn.execute("SELECT * FROM interview_commands WHERE id=%s", (command_id,)).fetchone()
    return _parse_interview_command_row(row)


def update_interview_command(command_id: str, **updates) -> Optional[dict]:
    """Update allowlisted command fields and return the refreshed command."""
    if not get_interview_command(command_id):
        return None

    assignments = []
    values = []
    for field, value in updates.items():
        if field not in _INTERVIEW_COMMAND_UPDATE_FIELDS:
            continue
        if field in _INTERVIEW_COMMAND_JSON_FIELDS:
            value = json.dumps(value, ensure_ascii=False)
        assignments.append(f"{field}=%s")
        values.append(value)

    if updates.get("status") == "executed" and "executed_at" not in updates:
        assignments.append("executed_at=NOW()")
    if assignments:
        assignments.append("updated_at=NOW()")
        values.append(command_id)
        conn = _db.get_db()
        conn.execute(f"UPDATE interview_commands SET {', '.join(assignments)} WHERE id=%s", values)
        conn.commit()
    return get_interview_command(command_id)


# ============ 淘汰记录增删改查 ============


def get_elimination_records(pipeline_id: str) -> list[dict]:
    return _db._pipeline_query_call("get_elimination_records", pipeline_id)


# ============ 面试会话增删改查（百人面试） ============


def create_interview_session(
    pipeline_id: str,
    candidate_id: str,
    candidate_name: str,
    token: str,
    questions: list,
    total_questions: int,
    expires_at: str,
    stream_name: str = "",
    rtmp_push_url: str = "",
    hls_play_url: str = "",
    flv_play_url: str = "",
    feishu_chat_id: str = "",
) -> int:
    """创建面试session，返回session id"""
    conn = _db.get_db()
    cur = conn.execute(
        """INSERT INTO interview_sessions
           (token, pipeline_id, candidate_id, candidate_name, questions,
            total_questions, expires_at, stream_name, rtmp_push_url,
            hls_play_url, flv_play_url, feishu_chat_id)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (
            token,
            pipeline_id,
            candidate_id,
            candidate_name,
            json.dumps(questions, ensure_ascii=False),
            total_questions,
            expires_at,
            stream_name,
            rtmp_push_url,
            hls_play_url,
            flv_play_url,
            feishu_chat_id,
        ),
    )
    conn.commit()
    return cur.lastrowid


def get_interview_session(token: str) -> Optional[dict]:
    """通过token获取session"""
    conn = _db.get_db()
    row = conn.execute("SELECT * FROM interview_sessions WHERE token=%s", (token,)).fetchone()
    if not row:
        return None
    d = dict(row)
    for key in ("questions", "answers", "dimension_scores", "video_paths", "snapshots", "device_info"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


def get_interview_sessions(pipeline_id: str) -> list[dict]:
    """获取pipeline下所有session"""
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM interview_sessions WHERE pipeline_id=%s ORDER BY id", (pipeline_id,)).fetchall()
    results = []
    for row in rows:
        d = dict(row)
        for key in ("questions", "answers", "dimension_scores", "video_paths", "snapshots", "device_info"):
            if key in d and isinstance(d[key], str):
                try:
                    d[key] = json.loads(d[key])
                except (json.JSONDecodeError, TypeError):
                    pass
        results.append(d)
    return results


def update_interview_session(token: str, updates: dict) -> Optional[dict]:
    """更新session字段"""
    conn = _db.get_db()
    if not updates:
        return get_interview_session(token)
    sets = []
    vals = []
    for k, v in updates.items():
        if isinstance(v, (list, dict)):
            v = json.dumps(v, ensure_ascii=False)
        sets.append(f"{k}=%s")
        vals.append(v)
    sets.append("updated_at=NOW()")
    vals.append(token)
    conn.execute(f"UPDATE interview_sessions SET {', '.join(sets)} WHERE token=%s", vals)
    conn.commit()
    return get_interview_session(token)


def get_session_by_stream(stream_name: str) -> Optional[dict]:
    """通过流名获取session"""
    conn = _db.get_db()
    row = conn.execute("SELECT * FROM interview_sessions WHERE stream_name=%s", (stream_name,)).fetchone()
    if not row:
        return None
    d = dict(row)
    for key in ("questions", "answers", "dimension_scores", "video_paths", "snapshots", "device_info"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


def get_sessions_by_stream(stream_name: str) -> list[dict]:
    """Return every session bound to a stream name for ambiguity checks."""
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM interview_sessions WHERE stream_name=%s ORDER BY id", (stream_name,)).fetchall()
    results = []
    for row in rows:
        d = dict(row)
        for key in ("questions", "answers", "dimension_scores", "video_paths", "snapshots", "device_info"):
            if key in d and isinstance(d[key], str):
                try:
                    d[key] = json.loads(d[key])
                except (json.JSONDecodeError, TypeError):
                    pass
        results.append(d)
    return results


def _effective_interview_status(session: dict, now: datetime | None = None) -> str:
    """Return the display status without persisting expiry during a read."""
    status = str(session.get("status") or "invited")
    if status == "streaming":
        # Legacy rows may have received the old callback-only status. Keep them
        # in the ordinary started bucket; new callbacks never write this value.
        status = "started"
    current = now or datetime.now(_db.SHANGHAI_TZ).replace(tzinfo=None)
    if status in {"invited", "started", "in_progress"} and session.get("invite_sent_at") and session.get("expires_at"):
        expires_at = _db._parse_db_ts(session.get("expires_at"))
        if expires_at and expires_at < current:
            return "expired"
    if status in {"started", "in_progress"}:
        started_at = _db._parse_db_ts(session.get("started_at"))
        if started_at and started_at + timedelta(minutes=_db.INTERVIEW_SESSION_TIMEOUT_MINUTES) <= current:
            return "expired"
    return status


def _effective_written_test_status(session: dict, now: datetime | None = None) -> str:
    """Map written-test storage states to the monitoring status vocabulary."""
    status = str(session.get("status") or "pending")
    current = now or datetime.now(_db.SHANGHAI_TZ).replace(tzinfo=None)
    if status in {"pending", "in_progress"} and session.get("expires_at"):
        expires_at = _db._parse_db_ts(session.get("expires_at"))
        if expires_at and expires_at < current:
            return "expired"
    if status == "in_progress":
        started_at = _db._parse_db_ts(session.get("started_at"))
        if started_at and started_at + timedelta(minutes=_db.INTERVIEW_SESSION_TIMEOUT_MINUTES) <= current:
            return "expired"
    return {"submitted": "completed", "pending": "invited"}.get(status, status)


def get_session_stats(pipeline_id: str, sessions: list[dict] | None = None) -> dict:
    """获取统计（按candidate_id去重，过期状态只在读取时计算）。"""
    conn = _db.get_db()
    now = datetime.now(_db.SHANGHAI_TZ).replace(tzinfo=None)
    all_session_rows = (
        [dict(session) for session in sessions]
        if sessions is not None
        else conn.execute(
            """SELECT * FROM interview_sessions
               WHERE pipeline_id=%s
                 AND status IN ('completed','evaluated','expired','in_progress','invited','started','streaming')
                 AND COALESCE(invite_sent_at, '') <> ''
                 AND id = (
                   SELECT s2.id FROM interview_sessions s2
                   WHERE s2.pipeline_id=interview_sessions.pipeline_id
                     AND s2.candidate_id=interview_sessions.candidate_id
                     AND s2.status IN ('completed','evaluated','expired','in_progress','invited','started','streaming')
                     AND COALESCE(s2.invite_sent_at, '') <> ''
                   ORDER BY CASE s2.status
                     WHEN 'completed' THEN 0 WHEN 'evaluated' THEN 1
                     WHEN 'in_progress' THEN 2 WHEN 'started' THEN 3
                     WHEN 'streaming' THEN 3 WHEN 'invited' THEN 4 ELSE 5 END,
                     s2.id DESC LIMIT 1
                 )""",
            (pipeline_id,),
        ).fetchall()
    )
    stats = {
        "total": 0,
        "invited": 0,
        "started": 0,
        "in_progress": 0,
        "completed": 0,
        "evaluated": 0,
        "expired": 0,
        "recorded": 0,
    }
    effective_rows = []
    counted_rows = []
    for row in all_session_rows:
        session = dict(row)
        session["status"] = _effective_interview_status(session, now)
        effective_rows.append(session)
        if session.get("invite_sent_at"):
            counted_rows.append(session)
            stats[session["status"]] = stats.get(session["status"], 0) + 1
            stats["total"] += 1

    assessment_completion = _get_assessment_completion(pipeline_id)
    if assessment_completion:
        session_candidate_ids = {str(row.get("candidate_id")) for row in effective_rows}
        counted_candidate_ids = {str(row.get("candidate_id")) for row in counted_rows}
        for row in effective_rows:
            candidate_key = str(row["candidate_id"])
            if (
                candidate_key in counted_candidate_ids
                and candidate_key in assessment_completion
                and row["status"] not in ("completed", "evaluated")
            ):
                stats[row["status"]] = max(0, stats[row["status"]] - 1)
                stats["completed"] += 1
        written_sessions = _get_written_test_sessions(pipeline_id)
        written_candidate_ids = {str(row.get("candidate_id")) for row in written_sessions}
        assessment_candidate_ids = [
            candidate_id
            for candidate_id in assessment_completion
            if str(candidate_id) in counted_candidate_ids
            and str(candidate_id) not in session_candidate_ids
            and str(candidate_id) not in written_candidate_ids
        ]
        if assessment_candidate_ids:
            placeholders = ",".join("%s" for _ in assessment_candidate_ids)
            candidate_rows = conn.execute(
                f"SELECT id FROM candidates WHERE pipeline_id=%s AND id IN ({placeholders})",
                [pipeline_id, *assessment_candidate_ids],
            ).fetchall()
            stats["completed"] += len(candidate_rows)
            stats["total"] += len(candidate_rows)
    written_sessions = _get_written_test_sessions(pipeline_id)
    video_candidate_ids = {str(row["candidate_id"]) for row in effective_rows}
    for session in written_sessions:
        if not session.get("invite_sent_at") or str(session.get("candidate_id")) in video_candidate_ids:
            continue
        status = _effective_written_test_status(session, now)
        stats[status] = stats.get(status, 0) + 1
        stats["total"] += 1
    # 已录制 = 去重后有 video_paths 的 session 数
    recorded_sql = """
        SELECT COUNT(*) as cnt FROM interview_sessions s
        WHERE s.pipeline_id = %s
          AND s.video_paths IS NOT NULL AND s.video_paths != '' AND s.video_paths != '[]'
          AND s.id = (
            SELECT s2.id FROM interview_sessions s2
            WHERE s2.pipeline_id = s.pipeline_id
              AND s2.candidate_id = s.candidate_id
              AND s2.status IN ('completed','evaluated','expired','in_progress','invited','started','streaming')
            ORDER BY CASE s2.status
              WHEN 'completed' THEN 0 WHEN 'evaluated' THEN 1
              WHEN 'in_progress' THEN 2 WHEN 'started' THEN 3
              WHEN 'streaming' THEN 3 WHEN 'invited' THEN 4 ELSE 5 END,
              s2.id DESC LIMIT 1
          )
    """
    recorded_row = conn.execute(recorded_sql, (pipeline_id,)).fetchone()
    if recorded_row:
        stats["recorded"] = recorded_row["cnt"]
    # “已邀请”表示已经发出邀请的候选人总数，而不是当前仍处于 invited 状态的人数。
    stats["invited"] = stats["total"]
    return stats


def _get_assessment_completion(pipeline_id: str) -> dict[str, list[str]]:
    """Return completed written/video modalities from the unified assessment flow."""
    try:
        rows = (
            _db.get_db()
            .execute(
                "SELECT candidate_id, step_results FROM assessment_candidate_states WHERE pipeline_id=%s",
                (pipeline_id,),
            )
            .fetchall()
        )
    except Exception:
        return {}
    completed: dict[str, set[str]] = {}
    for row in rows:
        try:
            step_results = row["step_results"]
            if isinstance(step_results, str):
                step_results = json.loads(step_results or "{}")
            if not isinstance(step_results, dict):
                continue
            modalities = {
                str(result.get("modality"))
                for result in step_results.values()
                if isinstance(result, dict)
                and result.get("modality") in {"written_test", "video_interview"}
                and result.get("execution_status") in {"submitted", "completed", "evaluated"}
            }
            if modalities:
                completed.setdefault(str(row["candidate_id"]), set()).update(modalities)
        except (TypeError, json.JSONDecodeError):
            continue
    return {candidate_id: sorted(modalities) for candidate_id, modalities in completed.items()}


def _get_written_test_sessions(pipeline_id: str) -> list[dict]:
    """Read written-test sessions when that optional table has been initialized."""
    try:
        rows = (
            _db.get_db()
            .execute(
                "SELECT * FROM written_test_sessions WHERE pipeline_id=%s ORDER BY created_at DESC",
                (pipeline_id,),
            )
            .fetchall()
        )
    except Exception:
        return []
    sessions = []
    for row in rows:
        session = dict(row)
        for key in ("questions", "answers"):
            if isinstance(session.get(key), str):
                try:
                    session[key] = json.loads(session[key] or "[]")
                except (TypeError, json.JSONDecodeError):
                    session[key] = []
        sessions.append(session)
    return sessions


def get_session_ranking(
    pipeline_id: str,
    start_from: str | None = None,
    start_to: str | None = None,
) -> list[dict]:
    """获取排名（按状态+综合分排序：已完成按分数排前面，未完成/过期排后面）"""
    conn = _db.get_db()
    now = datetime.now(_db.SHANGHAI_TZ).replace(tzinfo=None)
    if start_from and len(start_from) == 10:
        start_from = f"{start_from} 00:00:00"
    if start_to and len(start_to) == 10:
        start_to = f"{start_to} 23:59:59"
    # 日期筛选以实际邀请时间为准：链接可能提前生成、稍后才发送邮件。
    session_time = "COALESCE(NULLIF(s.invite_sent_at, ''), NULLIF(s.started_at, ''), s.created_at)"
    time_conditions = []
    time_params = []
    if start_from:
        time_conditions.append(f"{session_time} >= %s")
        time_params.append(start_from)
    if start_to:
        time_conditions.append(f"{session_time} <= %s")
        time_params.append(start_to)
    time_filter = " AND " + " AND ".join(time_conditions) if time_conditions else ""
    nested_time_filter = time_filter.replace("s.", "s2.")
    rows = conn.execute(
        f"""SELECT s.*, c.overall_score as match_score, c.status as candidate_status
           FROM interview_sessions s
           LEFT JOIN candidates c ON s.candidate_id = c.id AND s.pipeline_id = c.pipeline_id
           WHERE s.pipeline_id=%s
             AND s.status IN ('completed','evaluated','expired','in_progress','invited','started','streaming')
             AND COALESCE(s.invite_sent_at, '') <> ''
             {time_filter}
             AND s.id = (
                   SELECT s2.id FROM interview_sessions s2
                   WHERE s2.pipeline_id = s.pipeline_id
                     AND s2.candidate_id = s.candidate_id
                     AND s2.status IN ('completed','evaluated','expired','in_progress','invited','started','streaming')
                     AND COALESCE(s2.invite_sent_at, '') <> ''
                     {nested_time_filter}
                   ORDER BY
                     CASE s2.status
                       WHEN 'completed' THEN 0
                       WHEN 'evaluated' THEN 1
                       WHEN 'in_progress' THEN 2
                       WHEN 'started' THEN 3
                       WHEN 'invited' THEN 4
                       ELSE 5
                     END,
                     s2.id DESC
                   LIMIT 1
                 )
           ORDER BY s.interview_score DESC""",
        [pipeline_id, *time_params, *time_params],
    ).fetchall()
    # HR 标记状态映射：candidates.status → 前端 hr_action
    _hr_action_map = {"passed": "pass", "review": "review", "rejected": "reject"}
    assessment_completion = _get_assessment_completion(pipeline_id)
    rankings = []
    ranking_candidate_ids = set()
    for row in rows:
        d = dict(row)
        # 仅生成链接时 invite_sent_at 为空，绝不能进入面试中心。
        if not str(d.get("invite_sent_at") or "").strip():
            continue
        d["status"] = _effective_interview_status(d, now)
        ranking_candidate_ids.add(str(d.get("candidate_id")))
        match_score = d.get("match_score", 0) or 0
        interview_score = d.get("interview_score", 0) or 0
        # 面试中心的小评评分必须使用面试评估分，不能误用简历匹配分。
        d["total_score"] = round(interview_score)
        # hr_action: 从 candidates.status 映射（仅 HR 已标记的才有值）
        d["hr_action"] = _hr_action_map.get(d.pop("candidate_status", ""), "")
        if d.get("status") == "expired" and not d["hr_action"]:
            d["hr_action"] = "reject"
        completed_modalities = assessment_completion.get(str(d.get("candidate_id")), [])
        d["assessment_completed"] = bool(completed_modalities)
        d["completed_modalities"] = completed_modalities
        d["invite_type"] = "video_interview"
        # 趋势需要历史评分才能计算；单次面试先明确归为稳定，避免前端筛选无结果。
        d["trend"] = d.get("trend") or "stable"
        # recommendation: 未评估的根据 interview_score 自动推算
        if not d.get("recommendation") and interview_score > 0:
            if interview_score >= 85:
                d["recommendation"] = "strong_recommend"
            elif interview_score >= 70:
                d["recommendation"] = "recommend"
            elif interview_score >= 50:
                d["recommendation"] = "consider"
            else:
                d["recommendation"] = "not_recommend"
        for key in ("questions", "answers", "dimension_scores", "video_paths", "snapshots"):
            if key in d and isinstance(d[key], str):
                try:
                    d[key] = json.loads(d[key])
                except (json.JSONDecodeError, TypeError):
                    pass
        rankings.append(d)

    candidate_rows = conn.execute(
        "SELECT * FROM candidates WHERE pipeline_id=%s",
        (pipeline_id,),
    ).fetchall()
    candidate_by_id = {row["id"]: dict(row) for row in candidate_rows}
    # 笔试 session 没有对应视频 session 时，也映射为面试中心卡片。
    for session in _get_written_test_sessions(pipeline_id):
        candidate_id = session.get("candidate_id")
        if not session.get("invite_sent_at"):
            continue
        if not candidate_id or str(candidate_id) in ranking_candidate_ids:
            continue
        candidate = candidate_by_id.get(candidate_id, {})
        display_status = _effective_written_test_status(session, now)
        evaluation = session.get("evaluation") or {}
        if isinstance(evaluation, str):
            try:
                evaluation = json.loads(evaluation or "{}")
            except (TypeError, json.JSONDecodeError):
                evaluation = {}
        scoring_status = str(evaluation.get("scoring_status") or "")
        # 笔试提交后先处于 processing；只有后台评分成功才允许面试中心读分。
        score = session.get("score") if scoring_status == "succeeded" else None
        rankings.append(
            {
                "id": session.get("id"),
                "token": session.get("token", ""),
                "candidate_id": candidate_id,
                "candidate_name": session.get("candidate_name") or candidate.get("name", "候选人"),
                "status": display_status,
                "expires_at": session.get("expires_at", ""),
                "invite_sent_at": session.get("invite_sent_at", ""),
                "created_at": session.get("created_at", ""),
                "started_at": session.get("started_at", ""),
                "questions": session.get("questions", []),
                "answers": session.get("answers", []),
                "match_score": candidate.get("overall_score", 0) or 0,
                "interview_score": score,
                "total_score": round(score) if score is not None else None,
                "hr_action": "reject"
                if display_status == "expired"
                else _hr_action_map.get(candidate.get("status", ""), ""),
                "trend": "stable",
                "assessment_completed": display_status == "completed" and scoring_status == "succeeded",
                "completed_modalities": ["written_test"]
                if display_status == "completed" and scoring_status == "succeeded"
                else [],
                "video_paths": [],
                "invite_type": "written_test",
                "scoring_status": scoring_status or ("succeeded" if score is not None else "processing"),
                "dimension_scores": evaluation.get("dimension_scores", {}) if scoring_status == "succeeded" else {},
            }
        )
        ranking_candidate_ids.add(str(candidate_id))

    # 笔试完成但没有创建视频 session 的候选人也必须出现在面试中心。
    if assessment_completion:
        invited_candidate_ids = {str(row.get("candidate_id")) for row in rankings if row.get("invite_sent_at")}
        invited_candidate_ids.update(
            str(row.get("candidate_id")) for row in _get_written_test_sessions(pipeline_id) if row.get("invite_sent_at")
        )
        for candidate_row in candidate_rows:
            candidate_id = candidate_row["id"]
            modalities = assessment_completion.get(str(candidate_id), [])
            if (
                not modalities
                or str(candidate_id) in ranking_candidate_ids
                or str(candidate_id) not in invited_candidate_ids
            ):
                continue
            candidate = dict(candidate_row)
            candidate_name = candidate.get("name", "候选人")
            score = candidate.get("overall_score", 0) or 0
            rankings.append(
                {
                    "candidate_id": candidate_id,
                    "candidate_name": candidate_name,
                    "status": "completed",
                    "match_score": score,
                    "interview_score": 0,
                    "total_score": round(score),
                    "hr_action": _hr_action_map.get(candidate.get("status", ""), ""),
                    "trend": "stable",
                    "assessment_completed": True,
                    "completed_modalities": modalities,
                    "token": "",
                    "invite_type": "written_test",
                    "video_paths": [],
                    "answers": [],
                }
            )

    # 排序：已完成的按 total_score 降序，未完成的按状态排后面
    def _sort_key(r):
        status = r.get("status", "")
        raw_score = r.get("total_score")
        try:
            score = float(raw_score) if raw_score is not None else 0
        except (TypeError, ValueError):
            score = 0
        if r.get("assessment_completed") or status in ("completed", "evaluated"):
            return (0, -score)
        elif status == "in_progress":
            return (1, -score)
        elif status in ("invited", "started"):
            return (2, -score)
        else:  # 已过期
            return (3, -score)

    rankings.sort(key=_sort_key)
    for i, r in enumerate(rankings):
        r["rank"] = i + 1
    return rankings


def _update_stream_status_for_session(
    session_id: int | str,
    is_streaming: int,
    started_at: str = None,
    ended_at: str = None,
):
    """Update one interview session, keeping stream names non-authoritative."""
    conn = _db.get_db()
    updates = {"is_streaming": int(bool(is_streaming))}
    if started_at:
        updates["stream_started_at"] = started_at
    if ended_at:
        updates["stream_ended_at"] = ended_at
    sets = [f"{key}=%s" for key in updates]
    values = list(updates.values()) + [session_id]
    sets.append("updated_at=NOW()")
    conn.execute(f"UPDATE interview_sessions SET {', '.join(sets)} WHERE id=%s", values)
    conn.commit()


def update_stream_status(stream_name: str, is_streaming: int, started_at: str = None, ended_at: str = None):
    """Legacy stream-name update retained for non-callback integrations."""
    conn = _db.get_db()
    updates = {"is_streaming": int(bool(is_streaming))}
    if started_at:
        updates["stream_started_at"] = started_at
    if ended_at:
        updates["stream_ended_at"] = ended_at
    sets = [f"{key}=%s" for key in updates]
    values = list(updates.values()) + [stream_name]
    sets.append("updated_at=NOW()")
    conn.execute(f"UPDATE interview_sessions SET {', '.join(sets)} WHERE stream_name=%s", values)
    conn.commit()


def _update_recording_url_for_session(session_id: int | str, recording_url: str):
    """Persist a recording URL for exactly one interview session."""
    conn = _db.get_db()
    conn.execute(
        "UPDATE interview_sessions SET recording_url=%s, updated_at=NOW() WHERE id=%s",
        (recording_url, session_id),
    )
    conn.commit()


def update_recording_url(stream_name: str, recording_url: str):
    """Legacy stream-name update retained for non-callback integrations."""
    conn = _db.get_db()
    conn.execute(
        "UPDATE interview_sessions SET recording_url=%s, updated_at=NOW() WHERE stream_name=%s",
        (recording_url, stream_name),
    )
    conn.commit()


# 导入模块时初始化（测试模式跳过，conftest 会先注入测试库连接配置）
if not os.environ.get("TESTING"):
    _db.init_db()
    _db._migrate()
    _db.create_monitor_tables()
