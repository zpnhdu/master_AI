"""用户、角色、session 与 RBAC 领域模块。

从 ``app/db/__init__.py`` 迁移的 auth 持久化实现。公开函数之间的跨调用
通过 ``_db.`` 动态属性查找解析，保证测试对 ``app.db.<name>`` 的
monkeypatch 语义与单文件时期完全一致；私有 helper 保持在模块内直调。
"""

import json
from typing import Optional

from app import db as _db


def canonicalize_auth_permissions(raw_value) -> list[str]:
    """Parse the persisted permission JSON into a de-duplicated list."""
    if isinstance(raw_value, list):
        values = raw_value
    else:
        try:
            parsed = json.loads(raw_value or "[]")
            values = parsed if isinstance(parsed, list) else []
        except (TypeError, json.JSONDecodeError):
            values = []

    normalized = []
    for value in values:
        permission = str(value).strip()
        if permission and permission not in normalized:
            normalized.append(permission)
    return normalized


def _parse_auth_permissions(raw_value) -> list[str]:
    return canonicalize_auth_permissions(raw_value)


def _auth_role_from_row(row) -> Optional[dict]:
    if not row:
        return None
    role = dict(row)
    role["permissions"] = _parse_auth_permissions(role.get("permissions"))
    role["is_system"] = bool(role.get("is_system"))
    return role


def _auth_user_from_row(row) -> Optional[dict]:
    if not row:
        return None
    user = dict(row)
    user["permissions"] = _parse_auth_permissions(user.get("permissions"))
    user["is_active"] = bool(user.get("is_active"))
    user.pop("password_hash", None)
    return user


def list_auth_roles() -> list[dict]:
    rows = (
        _db.get_db()
        .execute(
            """
        SELECT * FROM auth_roles
        ORDER BY
            CASE id WHEN 'admin' THEN 0 WHEN 'hr_specialist' THEN 1 ELSE 2 END,
            name
        """
        )
        .fetchall()
    )
    return [_auth_role_from_row(row) for row in rows]


def get_auth_role(role_id: str) -> Optional[dict]:
    row = _db.get_db().execute("SELECT * FROM auth_roles WHERE id=%s", (role_id,)).fetchone()
    return _auth_role_from_row(row)


def update_auth_role(role_id: str, updates: dict) -> Optional[dict]:
    allowed = {"name", "description", "permissions"}
    assignments = []
    values = []
    for field, value in updates.items():
        if field not in allowed:
            continue
        if field == "permissions":
            value = json.dumps(value, ensure_ascii=False)
        assignments.append(f"{field}=%s")
        values.append(value)
    if not assignments:
        return _db.get_auth_role(role_id)

    assignments.append("updated_at=NOW()")
    values.append(role_id)
    conn = _db.get_db()
    conn.execute(f"UPDATE auth_roles SET {', '.join(assignments)} WHERE id=%s", values)
    conn.commit()
    return _db.get_auth_role(role_id)


def auth_role_user_count(role_id: str) -> int:
    row = _db.get_db().execute("SELECT COUNT(*) AS count FROM auth_users WHERE role_id=%s", (role_id,)).fetchone()
    return int(row["count"]) if row else 0


def _auth_user_select(where: str = "", params: tuple = ()) -> list:
    query = """
        SELECT
            users.id,
            users.username,
            users.display_name,
            users.password_hash,
            users.role_id,
            users.tenant_id,
            users.hr_contact,
            users.hr_qr_code_storage_key,
            users.wecom_userid,
            users.is_active,
            users.last_login_at,
            users.created_at,
            users.updated_at,
            roles.name AS role_name,
            roles.permissions AS permissions,
            mailbox.provider AS email_provider,
            mailbox.smtp_host AS email_smtp_host,
            mailbox.smtp_port AS email_smtp_port,
            mailbox.smtp_security AS email_smtp_security,
            mailbox.imap_host AS email_imap_host,
            mailbox.imap_port AS email_imap_port,
            mailbox.security_mode AS email_imap_security
        FROM auth_users users
        JOIN auth_roles roles ON roles.id = users.role_id
        LEFT JOIN email_accounts mailbox ON mailbox.owner_user_id = users.id
    """
    if where:
        query += f" WHERE {where}"
    return _db.get_db().execute(query, params).fetchall()


def list_auth_users() -> list[dict]:
    rows = _auth_user_select("1=1 ORDER BY users.created_at DESC")
    return [_auth_user_from_row(row) for row in rows]


def get_auth_user(user_id: str) -> Optional[dict]:
    rows = _auth_user_select("users.id=%s", (user_id,))
    return _auth_user_from_row(rows[0]) if rows else None


def get_auth_user_by_username(username: str, include_password: bool = False) -> Optional[dict]:
    rows = _auth_user_select("users.username=%s ", (username,))
    if not rows:
        return None
    user = dict(rows[0]) if include_password else _auth_user_from_row(rows[0])
    if include_password:
        user["permissions"] = _parse_auth_permissions(user.get("permissions"))
        user["is_active"] = bool(user.get("is_active"))
    return user


def get_auth_user_by_wecom_userid(wecom_userid: str) -> Optional[dict]:
    rows = _auth_user_select("users.wecom_userid=%s AND users.wecom_userid!=''", (wecom_userid,))
    return _auth_user_from_row(rows[0]) if rows else None


def set_auth_user_wecom_userid(user_id: str, wecom_userid: str) -> None:
    conn = _db.get_db()
    conn.execute("UPDATE auth_users SET wecom_userid=%s, updated_at=NOW() WHERE id=%s", (wecom_userid, user_id))
    conn.commit()


def create_auth_user(
    user_id: str,
    username: str,
    display_name: str,
    password_hash: str,
    role_id: str,
    is_active: bool = True,
    hr_contact: Optional[str] = None,
    hr_qr_code_storage_key: str = "",
) -> dict:
    # hr_contact 允许 None（未配置邮箱）：NULL 不参与 uk_auth_users_hr_contact
    # 唯一索引去重，多个无邮箱用户可共存。
    conn = _db.get_db()
    conn.execute(
        """
        INSERT INTO auth_users
            (id, username, display_name, password_hash, role_id, is_active, hr_contact, hr_qr_code_storage_key)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            user_id,
            username,
            display_name,
            password_hash,
            role_id,
            int(is_active),
            hr_contact or None,
            hr_qr_code_storage_key,
        ),
    )
    conn.commit()
    return _db.get_auth_user(user_id)


def update_auth_user(user_id: str, updates: dict) -> Optional[dict]:
    allowed = {
        "display_name",
        "password_hash",
        "role_id",
        "is_active",
        "last_login_at",
        "hr_contact",
        "hr_qr_code_storage_key",
    }
    assignments = []
    values = []
    for field, value in updates.items():
        if field not in allowed:
            continue
        if field == "is_active":
            value = int(bool(value))
        if field == "hr_contact":
            # 空串统一归一为 NULL，与唯一索引的语义保持一致
            value = value or None
        assignments.append(f"{field}=%s")
        values.append(value)
    if not assignments:
        return _db.get_auth_user(user_id)

    assignments.append("updated_at=NOW()")
    values.append(user_id)
    conn = _db.get_db()
    conn.execute(f"UPDATE auth_users SET {', '.join(assignments)} WHERE id=%s", values)
    conn.commit()
    return _db.get_auth_user(user_id)


def delete_auth_user(user_id: str) -> bool:
    conn = _db.get_db()
    conn.execute("DELETE FROM auth_sessions WHERE user_id=%s", (user_id,))
    cursor = conn.execute("DELETE FROM auth_users WHERE id=%s", (user_id,))
    conn.commit()
    return cursor.rowcount > 0


def active_auth_user_count(role_id: str) -> int:
    row = (
        _db.get_db()
        .execute(
            "SELECT COUNT(*) AS count FROM auth_users WHERE role_id=%s AND is_active=1",
            (role_id,),
        )
        .fetchone()
    )
    return int(row["count"]) if row else 0


def create_auth_session(token_hash: str, user_id: str, expires_at: str) -> None:
    conn = _db.get_db()
    conn.execute("DELETE FROM auth_sessions WHERE expires_at <= NOW()")
    conn.execute(
        "INSERT INTO auth_sessions (token_hash, user_id, expires_at) VALUES (%s, %s, %s)",
        (token_hash, user_id, expires_at),
    )
    conn.commit()


def get_auth_user_by_session(token_hash: str) -> Optional[dict]:
    rows = _auth_user_select(
        """
        users.id IN (
            SELECT user_id FROM auth_sessions
            WHERE token_hash=%s AND expires_at > NOW()
        ) AND users.is_active=1
        """,
        (token_hash,),
    )
    return _auth_user_from_row(rows[0]) if rows else None


def delete_auth_session(token_hash: str) -> None:
    conn = _db.get_db()
    conn.execute("DELETE FROM auth_sessions WHERE token_hash=%s", (token_hash,))
    conn.commit()


def delete_auth_sessions_for_user(user_id: str) -> None:
    conn = _db.get_db()
    conn.execute("DELETE FROM auth_sessions WHERE user_id=%s", (user_id,))
    conn.commit()
