"""Database persistence layer — MySQL."""

from contextlib import contextmanager
from datetime import datetime
from zoneinfo import ZoneInfo

from app import analytics_time_helpers as _analytics_time_helpers
from app import db_runtime as _db_runtime
from app import db_schema as _db_schema
from app import job_types as _job_types
from app import pending_repository as _pending_repository
from app import role_overview_helpers as _role_overview_helpers
from app import talent_pool_helpers as _talent_pool_helpers
from app.repositories import pipeline_queries as _pipeline_queries

JOB_TYPE_OPTIONS = _job_types.JOB_TYPE_OPTIONS
normalize_job_type = _job_types.normalize_job_type
job_type_label = _job_types.job_type_label

# ── 数据库配置 ────────────────────────────────────────────────

# MySQL 配置（来自环境变量，启动时由 config/environments/.env.{APP_ENV} 注入）

MYSQL_CONFIG = _db_runtime.MYSQL_CONFIG

GUOQUAN_DEFAULT_BRAND_COLOR = "#16A34A"
LEGACY_GUOQUAN_BRAND_COLOR = "#E60012"

# 小面通过统一按正式评分阈值判定；完成但未评分的记录不计为通过。
INTERVIEW_PASS_SCORE_THRESHOLD = 60
INTERVIEW_PASS_FALLBACK_TO_COMPLETED = False
SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
INTERVIEW_SESSION_TIMEOUT_MINUTES = 35


def now_db_string() -> str:
    """Return the application timestamp format used by analytics and event fields."""
    # MySQL legacy columns are timezone-less; define them explicitly as
    # Asia/Shanghai so every writer uses the same wall-clock reference.
    return datetime.now(SHANGHAI_TZ).strftime("%Y-%m-%d %H:%M:%S")


# 旧模块级状态仍由 app.db 暴露，runtime 调用前会同步这些兼容状态。
_conn = None
_write_lock = _db_runtime._write_lock
_local = _db_runtime._local


normalize_role_name = _role_overview_helpers.normalize_role_name


def ensure_access_control_tables():
    """启动时确保账号、角色和会话表已完成初始化。"""
    conn = get_db()
    _ensure_access_control_schema(conn)
    conn.commit()


def _sync_runtime_state():
    """Keep legacy app.db state and the extracted runtime state aligned."""
    _db_runtime.MYSQL_CONFIG = MYSQL_CONFIG
    _db_runtime._conn = _conn
    _db_runtime._local = _local
    _db_runtime._write_lock = _write_lock


def _sync_facade_state():
    """Copy runtime connection state back to app.db after a runtime call."""
    global _conn, _local, _write_lock
    _conn = _db_runtime._conn
    _local = _db_runtime._local
    _write_lock = _db_runtime._write_lock


def get_db():
    """Get a per-thread MySQL connection through the extracted runtime."""
    _sync_runtime_state()
    try:
        return _db_runtime.get_db()
    finally:
        _sync_facade_state()


def _create_mysql_pool():
    """Create a wrapped MySQL connection using the facade configuration."""
    _sync_runtime_state()
    return _db_runtime.create_mysql_pool(MYSQL_CONFIG)


def _pipeline_query_call(name, *args, **kwargs):
    """Dispatch read-only pipeline queries while preserving app.db exports."""
    return getattr(_pipeline_queries, name)(*args, **kwargs)


def _schema_call(name, *args, **kwargs):
    """Dispatch schema operations while preserving app.db compatibility names."""
    return getattr(_db_schema, name)(*args, **kwargs)


def _ensure_access_control_schema(conn):
    return _schema_call("_ensure_access_control_schema", conn)


def _seed_auth_defaults(conn):
    return _schema_call("_seed_auth_defaults", conn)


def _table_columns(conn, table_name: str) -> list[str]:
    return _schema_call("_table_columns", conn, table_name)


def _ensure_index(conn, sql: str, index_name: str) -> None:
    return _schema_call("_ensure_index", conn, sql, index_name)


def _ensure_mysql_long_text_columns(conn) -> None:
    return _schema_call("_ensure_mysql_long_text_columns", conn)


def _migrate_poster_job_progress(conn):
    return _schema_call("_migrate_poster_job_progress", conn)


def _migrate_poster_version_numbers(conn):
    return _schema_call("_migrate_poster_version_numbers", conn)


def init_db():
    return _schema_call("init_db")


def _ensure_email_domain_schema(conn):
    return _schema_call("_ensure_email_domain_schema", conn)


def _seed_agent_configs(conn):
    return _schema_call("_seed_agent_configs", conn)


def _seed_communication_templates(conn):
    return _schema_call("_seed_communication_templates", conn)


def _seed_company_config(conn):
    return _schema_call("_seed_company_config", conn)


def _migrate_company_config(conn):
    return _schema_call("_migrate_company_config", conn)


def _migrate_guoquan_brand_color(conn):
    return _schema_call("_migrate_guoquan_brand_color", conn)


def _ensure_leader_chat_schema(conn) -> None:
    return _schema_call("_ensure_leader_chat_schema", conn)


def _ensure_active_role_index(conn) -> None:
    return _schema_call("_ensure_active_role_index", conn)


def _migrate():
    return _schema_call("_migrate")


def create_monitor_tables():
    return _schema_call("create_monitor_tables")


_MYSQL_LONG_TEXT_COLUMNS = {
    "context",
    "output",
    "skills",
    "resume_text",
    "reason",
    "video_assessment",
    "content",
    "card_data",
    "value",
    "rule_data",
    "preference_value",
    "data_json",
    "error",
    "error_message",
    "rules",
    "notes",
    "tags",
    "source_text",
    "payload",
    "preview",
    "result",
    "latest_data",
    "transcript",
    "questions",
    "answers",
    "dimension_scores",
    "video_paths",
    "snapshots",
    "message",
    "extra",
    "fields",
    "request_payload",
    "render_data",
    "package",
    "step_results",
    "evaluation",
    "config",
    "recording_url",
    "voice_answers",
    "response_text",
    "response_chart",
    "error_message_internal",
    "public_error_message",
    "tool_calls",
    "tool_results",
    "chart_spec",
}

# 表级精确长文本列：某些通用短列名（如 status）在个别表里存了超长错误详情，
# 若按列名全局转 LONGTEXT 会破坏其上建立的普通索引（如 idx_sessions_status），
# 因此用 table.column 逐一指定，兼顾列宽与索引可用性。
_MYSQL_LONG_TEXT_COLUMNS_BY_TABLE: dict[str, set[str]] = {
    "candidate_assessment_reports": {"report_json"},
    "llm_trace": {"status"},
    "wiki_pages": {"sources", "embedding"},
    "wiki_ingest": {"error_msg", "pages_written"},
}


@contextmanager
def transaction():
    """Run an atomic write transaction through the extracted runtime."""
    _sync_runtime_state()
    try:
        with _db_runtime.transaction() as conn:
            yield conn
    finally:
        _sync_facade_state()


# ── 用户、角色、session 与 RBAC ──────────────────────────────
# 实现已迁移至 app/db/auth.py；此处显式 re-export 维持旧导入路径。


# ── 看板、漏斗、排名与人员概览 ───────────────────────────────
# 实现已迁移至 app/db/analytics.py；此处显式 re-export 维持旧导入路径。
from app.db.analytics import (  # noqa: E402,F401
    _average_hire_cycle_expression,
    _candidate_id_from_item,
    _candidate_ranking_dimension_scores,
    _candidate_ranking_identity,
    _candidate_ranking_keywords,
    _candidate_ranking_small_review_scores,
    _count_interview_passed_from_rows,
    _decode_stage_output,
    _interview_candidate_key,
    _numeric_score,
    _record_passes_interview,
    _resume_dedup_key,
    _row_value,
    _stage_interview_records,
    _talent_pool_funnel_metrics,
    get_activity_feed,
    get_candidate_ranking_for_user,
    get_dashboard_extra,
    get_funnel_data,
    get_funnel_data_for_user,
    get_hr_performance,
    get_owner_overview_for_user,
    get_role_overview_for_user,
    get_stage_pass_rate_trend,
    get_talent_attrition,
    get_talent_pool_distribution,
    get_talent_pool_growth,
)
from app.db.auth import (  # noqa: E402,F401
    _auth_role_from_row,
    _auth_user_from_row,
    _auth_user_select,
    _parse_auth_permissions,
    active_auth_user_count,
    auth_role_user_count,
    canonicalize_auth_permissions,
    create_auth_session,
    create_auth_user,
    delete_auth_session,
    delete_auth_sessions_for_user,
    delete_auth_user,
    get_auth_role,
    get_auth_user,
    get_auth_user_by_session,
    get_auth_user_by_username,
    get_auth_user_by_wecom_userid,
    list_auth_roles,
    list_auth_users,
    set_auth_user_wecom_userid,
    update_auth_role,
    update_auth_user,
)

# ── 候选人、消息、学习与记忆 ─────────────────────────────────
# 实现已迁移至 app/db/candidates.py；此处显式 re-export 维持旧导入路径。
from app.db.candidates import (  # noqa: E402,F401
    count_messages_by_pipeline,
    get_candidates,
    get_learnings,
    get_memory_rules,
    get_memory_stats,
    get_messages,
    get_ontology_rules,
    get_preferences,
    reset_memory_rules,
    save_candidate,
    save_learning,
    save_memory_rule,
    save_message,
    save_ontology_rule,
    save_preference,
    save_simple_candidate,
    toggle_memory_rule,
    update_candidate,
)

# ── 公司配置、Agent 配置、调用日志与沟通模板 ─────────────────
# 实现已迁移至 app/db/company.py；此处显式 re-export 维持旧导入路径。
from app.db.company import (  # noqa: E402,F401
    _with_company_asset_urls,
    get_agent_config,
    get_agent_configs,
    get_agent_stats,
    get_company_config,
    get_recent_calls,
    list_communication_templates,
    log_agent_call,
    update_company_config,
    upsert_agent_config,
)

# ── 面试会话、日程、指令台账与直播状态 ───────────────────────
# 实现已迁移至 app/db/interview.py；此处显式 re-export 维持旧导入路径。
from app.db.interview import (  # noqa: E402,F401
    _INTERVIEW_COMMAND_JSON_FIELDS,
    _INTERVIEW_COMMAND_UPDATE_FIELDS,
    _effective_interview_status,
    _effective_written_test_status,
    _get_assessment_completion,
    _get_written_test_sessions,
    _parse_interview_command_row,
    _update_recording_url_for_session,
    _update_stream_status_for_session,
    cancel_interview_schedule,
    create_interview_session,
    get_elimination_records,
    get_interview_command,
    get_interview_schedules,
    get_interview_session,
    get_interview_sessions,
    get_session_by_stream,
    get_session_ranking,
    get_session_stats,
    get_sessions_by_stream,
    save_interview_command,
    save_interview_schedule,
    update_interview_command,
    update_interview_session,
    update_recording_url,
    update_stream_status,
)

# ============ 沟通模板增删改查 ============
# list_communication_templates 已迁移至 app/db/company.py。
# ── Pipeline、阶段与 JD 锁 ────────────────────────────────────
# 实现已迁移至 app/db/pipelines.py；此处显式 re-export 维持旧导入路径。
from app.db.pipelines import (  # noqa: E402,F401
    _default_pipeline_owner_id,
    claim_pipeline_run,
    create_pipeline,
    create_stage,
    delete_pipeline,
    get_pipeline,
    get_pipeline_for_user,
    get_stages,
    list_pipelines,
    list_pipelines_for_user,
    lock_pipeline_jd,
    update_pipeline,
    update_pipeline_agents,
    update_stage,
)

# ── 人才库、简历库与触达事件 ─────────────────────────────────
# 实现已迁移至 app/db/talent_pool.py；此处显式 re-export 维持旧导入路径。
from app.db.talent_pool import (  # noqa: E402,F401
    add_to_talent_pool,
    delete_resume_db,
    get_candidate_email,
    get_resume_by_fingerprint,
    get_resume_by_id,
    get_resume_count,
    get_talent_pool_stats,
    rediscover_talents,
    save_outreach_event,
    save_resume_db,
    search_resumes_db,
    search_talent_pool,
    update_resume_linked,
)

_gender_bucket = _talent_pool_helpers.gender_bucket
_education_bucket = _talent_pool_helpers.education_bucket
_years_bucket = _talent_pool_helpers.years_bucket
_rank_items = _talent_pool_helpers.rank_items
_parse_db_ts = _analytics_time_helpers.parse_db_ts

# get_talent_pool_distribution / get_talent_attrition / get_stage_pass_rate_trend /
# get_hr_performance / get_talent_pool_growth 已迁移至 app/db/analytics.py。


# save_outreach_event 已迁移至 app/db/talent_pool.py。


# 漏斗/看板/动态流已迁移至 app/db/analytics.py。


# ============ DB迁移 ============


# ============ 待处理数据（服务重启后保留） ============


def _pending_call(name, *args, **kwargs):
    """Dispatch pending persistence operations through the compatibility facade."""
    return getattr(_pending_repository, name)(*args, **kwargs)


def save_pending(pipeline_id: str, data_type: str, data: dict):
    return _pending_call("save_pending", pipeline_id, data_type, data)


def get_pending(pipeline_id: str, data_type: str) -> list[dict]:
    return _pending_call("get_pending", pipeline_id, data_type)


def clear_pending(pipeline_id: str, data_type: str = None):
    return _pending_call("clear_pending", pipeline_id, data_type)


def get_all_pending() -> dict[str, dict[str, list[dict]]]:
    return _pending_call("get_all_pending")


# ============ 监控数据表 ============


# ── RPA 任务增删改查 ─────────────────────────────────────────
# 实现已迁移至 app/db/rpa.py；此处显式 re-export 维持旧导入路径。


from app.db.rpa import (  # noqa: E402,F401
    create_rpa_task,
    get_pending_rpa_tasks,
    get_rpa_task,
    increment_rpa_task_count,
    list_rpa_tasks,
    update_rpa_task,
)
