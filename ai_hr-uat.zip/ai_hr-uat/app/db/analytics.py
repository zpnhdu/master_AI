"""看板、漏斗、排名与人员概览分析领域模块。

从 ``app/db/__init__.py`` 迁移的分析查询实现。连接获取与跨函数调用通过
``_db.`` 动态属性查找解析，保证测试对 ``app.db.<name>`` 的 monkeypatch
语义与单文件时期完全一致。
"""

import json
import re
from datetime import datetime, timedelta

from app import analytics_time_helpers as _analytics_time_helpers
from app import db as _db
from app import owner_overview_helpers as _owner_overview_helpers
from app import role_overview_helpers as _role_overview_helpers
from app import talent_pool_helpers as _talent_pool_helpers
from app.job_types import job_type_label

_numeric_score = _role_overview_helpers.numeric_score
_interview_candidate_key = _role_overview_helpers.interview_candidate_key
_stage_interview_records = _role_overview_helpers.stage_interview_records
_row_value = _role_overview_helpers.row_value


def _record_passes_interview(record: dict, fallback: str, completed: bool = False) -> tuple[str, bool]:
    return _role_overview_helpers.record_passes_interview(
        record,
        fallback,
        completed=completed,
        threshold=_db.INTERVIEW_PASS_SCORE_THRESHOLD,
    )


def _count_interview_passed_from_rows(
    pipeline_id: str,
    assessment_rows: list,
    stage_rows: list,
    session_rows: list,
    eligible_keys: set[str] | None = None,
    alias_to_key: dict[str, str] | None = None,
) -> int:
    return _role_overview_helpers.count_interview_passed_from_rows(
        pipeline_id,
        assessment_rows,
        stage_rows,
        session_rows,
        threshold=_db.INTERVIEW_PASS_SCORE_THRESHOLD,
        eligible_keys=eligible_keys,
        alias_to_key=alias_to_key,
    )


def get_role_overview_for_user(
    user_id: str, tenant_id: str = "tenant_default", include_all: bool = False
) -> list[dict]:
    """Aggregate role overview rows within the caller's visibility boundary."""
    pipelines = _db.list_pipelines_for_user(user_id, tenant_id, include_all=include_all)
    if not pipelines:
        return []
    conn = _db.get_db()
    pipeline_ids = [str(p["id"]) for p in pipelines]
    placeholders = ",".join("%s" for _ in pipeline_ids)
    # 小筛通过是候选人进入小面的固定 cohort。新流程将结果写入
    # screening_decision，旧流程则可能只留下 passed/shortlisted 或后续面试状态；
    # 不能只看当前 status，否则候选人进入小面/录用后会从分母消失。
    screened_rows = conn.execute(
        f"""SELECT pipeline_id, id, name, phone, email, resume_id, status, screening_decision
            FROM candidates
            WHERE pipeline_id IN ({placeholders})
              AND (
                LOWER(TRIM(COALESCE(screening_decision, ''))) = 'passed'
                OR (
                  LOWER(TRIM(COALESCE(screening_decision, ''))) = ''
                  AND LOWER(TRIM(COALESCE(status, ''))) IN (
                    'passed', 'shortlisted', 'shortlist', 'interview', 'interviewing',
                    'in_interview', 'interview_in_progress', 'interviewed',
                    'interview_completed', 'interview_ended', 'offered'
                  )
                )
              )""",
        pipeline_ids,
    ).fetchall()
    screened_map: dict[str, int] = {}
    screened_keys: dict[str, set[str]] = {}
    screened_aliases: dict[str, dict[str, str]] = {}
    for row in screened_rows:
        pipeline_key = str(row["pipeline_id"])
        primary = str(row["id"] or row["name"] or "").strip()
        if not primary:
            continue
        screened_keys.setdefault(pipeline_key, set()).add(primary)
        aliases = screened_aliases.setdefault(pipeline_key, {})
        for field in ("id", "name", "phone", "email", "resume_id"):
            value = str(row[field] or "").strip()
            if value:
                aliases[value] = primary
    screened_map = {pipeline_key: len(keys) for pipeline_key, keys in screened_keys.items()}

    assessment_map: dict[str, list] = {pid: [] for pid in pipeline_ids}
    try:
        rows = conn.execute(
            f"SELECT id, pipeline_id, candidate_id, package FROM assessment_candidate_states "
            f"WHERE pipeline_id IN ({placeholders})",
            pipeline_ids,
        ).fetchall()
        for row in rows:
            assessment_map.setdefault(str(row["pipeline_id"]), []).append(row)
    except Exception:
        pass
    stage_map: dict[str, list] = {pid: [] for pid in pipeline_ids}
    for row in conn.execute(
        f"SELECT pipeline_id, output FROM pipeline_stages "
        f"WHERE pipeline_id IN ({placeholders}) AND stage_id IN ('interview_gen','video_assess')",
        pipeline_ids,
    ).fetchall():
        stage_map.setdefault(str(row["pipeline_id"]), []).append(row)
    session_map: dict[str, list] = {pid: [] for pid in pipeline_ids}
    for row in conn.execute(
        f"SELECT pipeline_id, candidate_id, candidate_name, status, interview_score FROM interview_sessions "
        f"WHERE pipeline_id IN ({placeholders})",
        pipeline_ids,
    ).fetchall():
        session_map.setdefault(str(row["pipeline_id"]), []).append(row)

    return _role_overview_helpers.aggregate_role_overview(
        pipelines,
        screened_map,
        assessment_map,
        stage_map,
        session_map,
        job_type_label,
        interview_pass_score_threshold=_db.INTERVIEW_PASS_SCORE_THRESHOLD,
        screened_keys=screened_keys,
        screened_aliases=screened_aliases,
    )


def _candidate_ranking_identity(candidate: dict) -> str:
    """Build a stable identity key for cross-pipeline candidate deduplication."""
    resume_id = str(candidate.get("resume_id") or "").strip()
    if resume_id:
        return f"resume:{resume_id}"
    for field in ("phone", "email"):
        value = str(candidate.get(field) or "").strip().lower()
        if value:
            return f"{field}:{value}"
    name = re.sub(r"\s+", "", str(candidate.get("name") or "").strip().lower())
    return f"name:{name}" if name else f"candidate:{candidate.get('id', '')}"


def _candidate_ranking_keywords(pipeline_ids: list[str]) -> list[str]:
    """Extract comparable job keywords from visible pipeline JD stages."""
    keywords: list[str] = []
    seen: set[str] = set()
    for pipeline_id in pipeline_ids:
        stage = next((item for item in _db.get_stages(pipeline_id) if item.get("stage_id") == "jd_write"), None)
        output = stage.get("output") if stage else {}
        if isinstance(output, str):
            try:
                output = json.loads(output)
            except (json.JSONDecodeError, TypeError):
                output = {}
        jd = output.get("jd", output) if isinstance(output, dict) else {}
        if not isinstance(jd, dict):
            continue
        for field in ("tech_stack", "keywords", "required_skills"):
            values = jd.get(field, [])
            if isinstance(values, str):
                values = re.split(r"[,，、/\s]+", values)
            if not isinstance(values, list):
                continue
            for value in values:
                keyword = str(value or "").strip()
                if keyword and keyword.lower() not in seen:
                    seen.add(keyword.lower())
                    keywords.append(keyword)
    return keywords


def _candidate_ranking_dimension_scores(pipeline_ids: list[str]) -> dict[tuple[str, str], dict[str, int]]:
    """Return completed small-review dimensions keyed by pipeline and candidate."""
    if not pipeline_ids:
        return {}
    try:
        from app.assessment_flow import COMPARISON_DIMENSIONS, _comparison_dimension_scores

        conn = _db.get_db()
        placeholders = ",".join("%s" for _ in pipeline_ids)
        rows = conn.execute(
            f"SELECT pipeline_id, candidate_id, package FROM assessment_candidate_states "
            f"WHERE pipeline_id IN ({placeholders}) AND queue_status=%s",
            [*pipeline_ids, "ready_for_decision"],
        ).fetchall()
    except Exception:
        return {}

    result: dict[tuple[str, str], dict[str, int]] = {}
    for row in rows:
        package = row["package"]
        if isinstance(package, str):
            try:
                package = json.loads(package or "{}")
            except (json.JSONDecodeError, TypeError):
                package = {}
        if not isinstance(package, dict):
            continue
        dimension_values: dict[str, list[int]] = {name: [] for name in COMPARISON_DIMENSIONS}
        step_results = package.get("step_results")
        if not isinstance(step_results, dict):
            continue
        selected_path = package.get("selected_path")
        step_ids = selected_path if isinstance(selected_path, list) else list(step_results)
        for step_id in step_ids:
            step = step_results.get(step_id)
            if not isinstance(step, dict):
                continue
            evidence = step.get("evidence")
            if not isinstance(evidence, dict):
                continue
            for name, value in _comparison_dimension_scores(evidence).items():
                dimension_values[name].append(value)
        if not all(dimension_values.values()):
            continue
        canonical = {
            "job_coverage": round(
                sum(dimension_values[COMPARISON_DIMENSIONS[0]]) / len(dimension_values[COMPARISON_DIMENSIONS[0]])
            ),
            "professional_accuracy": round(
                sum(dimension_values[COMPARISON_DIMENSIONS[1]]) / len(dimension_values[COMPARISON_DIMENSIONS[1]])
            ),
            "analytical_logic": round(
                sum(dimension_values[COMPARISON_DIMENSIONS[2]]) / len(dimension_values[COMPARISON_DIMENSIONS[2]])
            ),
            "solution_feasibility": round(
                sum(dimension_values[COMPARISON_DIMENSIONS[3]]) / len(dimension_values[COMPARISON_DIMENSIONS[3]])
            ),
            "evidence_boundaries": round(
                sum(dimension_values[COMPARISON_DIMENSIONS[4]]) / len(dimension_values[COMPARISON_DIMENSIONS[4]])
            ),
        }
        result[(str(row["pipeline_id"]), str(row["candidate_id"]))] = canonical
    return result


def _candidate_ranking_small_review_scores(pipeline_ids: list[str]) -> dict[tuple[str, str], float]:
    """Return formal small-review scores keyed by pipeline and candidate.

    A modern assessment state owns the candidate's score even while incomplete,
    so an older interview score cannot be shown as a current formal review. Older
    pipelines without assessment states may still use a completed interview score.
    """
    if not pipeline_ids:
        return {}

    def decode(value) -> dict:
        payload = value
        for _ in range(2):
            if isinstance(payload, dict):
                return payload
            if not isinstance(payload, str):
                return {}
            try:
                payload = json.loads(payload)
            except (json.JSONDecodeError, TypeError):
                return {}
        return payload if isinstance(payload, dict) else {}

    conn = _db.get_db()
    placeholders = ",".join("%s" for _ in pipeline_ids)
    scores: dict[tuple[str, str], float] = {}
    assessment_keys: set[tuple[str, str]] = set()
    latest_assessment_keys: set[tuple[str, str]] = set()
    try:
        rows = conn.execute(
            f"""SELECT pipeline_id, candidate_id, queue_status, package
                FROM assessment_candidate_states
                WHERE pipeline_id IN ({placeholders})
                ORDER BY updated_at DESC""",
            pipeline_ids,
        ).fetchall()
        for row in rows:
            key = (str(row["pipeline_id"]), str(row["candidate_id"]))
            if key in latest_assessment_keys:
                continue
            latest_assessment_keys.add(key)
            assessment_keys.add(key)
            if str(row.get("queue_status") or "") != "ready_for_decision":
                continue
            package = decode(row["package"])
            score = _numeric_score(package.get("overall_score"))
            if score is not None:
                scores[key] = score
    except Exception:
        # Older installations may not have assessment-flow tables yet.
        pass

    try:
        rows = conn.execute(
            f"""SELECT pipeline_id, candidate_id, interview_score
                FROM interview_sessions
                WHERE pipeline_id IN ({placeholders})
                  AND status IN ('completed', 'evaluated')
                  AND interview_score IS NOT NULL
                ORDER BY COALESCE(evaluated_at, completed_at, updated_at, created_at) DESC""",
            pipeline_ids,
        ).fetchall()
        for row in rows:
            key = (str(row["pipeline_id"]), str(row["candidate_id"]))
            score = _numeric_score(row["interview_score"])
            if score is not None and key not in assessment_keys and key not in scores:
                scores[key] = score
    except Exception:
        pass
    return scores


def get_candidate_ranking_for_user(
    user_id: str,
    tenant_id: str = "tenant_default",
    include_all: bool = False,
    role: str = "",
    type_code: str = "",
    limit: int | None = 4,
) -> dict:
    """Return highest-scoring candidates grouped within one visible role."""
    pipelines = _db.list_pipelines_for_user(user_id, tenant_id, include_all=include_all)
    normalized_role = _db.normalize_role_name(role)
    groups: dict[tuple[str, str], list[dict]] = {}
    for pipeline in pipelines:
        key = (_db.normalize_role_name(pipeline.get("role")), str(pipeline.get("type") or "general"))
        groups.setdefault(key, []).append(pipeline)

    ordered_keys = list(groups)
    if not normalized_role and not type_code:
        overview = get_role_overview_for_user(user_id, tenant_id, include_all=include_all)
        overview_key = next(
            ((_db.normalize_role_name(item.get("role")), str(item.get("type_code") or "general")) for item in overview),
            None,
        )
        if overview_key not in groups:
            return {
                "role": "",
                "type_code": "general",
                "type_label": job_type_label("general"),
                "keywords": [],
                "total": 0,
                "candidates": [],
            }
        ordered_keys = [overview_key, *(key for key in ordered_keys if key != overview_key)]
    selected_key = next(
        (
            key
            for key in ordered_keys
            if (not normalized_role or key[0] == normalized_role) and (not type_code or key[1] == type_code)
        ),
        None,
    )
    if selected_key is None:
        return {
            "role": normalized_role,
            "type_code": type_code or "general",
            "type_label": job_type_label(type_code or "general"),
            "keywords": [],
            "total": 0,
            "candidates": [],
        }

    selected_pipelines = groups[selected_key]
    pipeline_ids = [str(item["id"]) for item in selected_pipelines]
    conn = _db.get_db()
    placeholders = ",".join("%s" for _ in pipeline_ids)
    rows = conn.execute(
        f"""SELECT c.*, r.skills AS resume_skills
            FROM candidates c
            LEFT JOIN resumes r
              ON r.id = c.resume_id
             AND r.tenant_id = c.tenant_id
            WHERE c.pipeline_id IN ({placeholders})""",
        pipeline_ids,
    ).fetchall()
    dimension_scores = _candidate_ranking_dimension_scores(pipeline_ids)
    small_review_scores = _candidate_ranking_small_review_scores(pipeline_ids)
    best_by_identity: dict[str, dict] = {}
    for row in rows:
        candidate = dict(row)
        candidate_key = (str(candidate.get("pipeline_id") or ""), str(candidate.get("id") or ""))
        small_review_score = small_review_scores.get(candidate_key)
        screening_match_score = _numeric_score(candidate.get("overall_score")) or 0
        score = small_review_score if small_review_score is not None else screening_match_score
        candidate["overall_score"] = score
        candidate["score_source"] = "small_review" if small_review_score is not None else "screening_match_legacy"
        candidate["dimension_scores"] = dimension_scores.get(candidate_key)
        identity = _candidate_ranking_identity(candidate)
        current = best_by_identity.get(identity)
        current_score = current.get("overall_score", 0) if current else -1
        current_is_small_review = bool(current and current.get("score_source") == "small_review")
        candidate_is_small_review = small_review_score is not None
        if (
            current is None
            or (candidate_is_small_review and not current_is_small_review)
            or (
                candidate_is_small_review == current_is_small_review
                and (
                    score > current_score
                    or (score == current_score and str(candidate.get("id", "")) > str(current.get("id", "")))
                )
            )
        ):
            best_by_identity[identity] = candidate

    candidates = []
    for candidate in best_by_identity.values():
        resume_skills = candidate.get("resume_skills")
        skills = resume_skills if resume_skills is not None else candidate.get("skills")
        skills = skills or []
        if isinstance(skills, str):
            try:
                skills = json.loads(skills)
            except (json.JSONDecodeError, TypeError):
                skills = re.split(r"[,，、\s]+", skills)
        if not isinstance(skills, list):
            skills = []
        candidates.append(
            {
                "candidate_id": str(candidate.get("id") or ""),
                "name": str(candidate.get("name") or "候选人"),
                "years_experience": candidate.get("years_experience") or 0,
                "skills": list(dict.fromkeys(str(skill).strip() for skill in skills if str(skill).strip())),
                "score": candidate.get("overall_score") or 0,
                "score_source": candidate.get("score_source", "screening_match_legacy"),
                "pipeline_id": str(candidate.get("pipeline_id") or ""),
                "dimension_scores": candidate.get("dimension_scores"),
            }
        )
    candidates.sort(
        key=lambda item: (
            0 if item.get("score_source") == "small_review" else 1,
            -float(item["score"]),
            item["name"],
            item["candidate_id"],
        )
    )
    for index, candidate in enumerate(candidates, 1):
        candidate["rank"] = index
    keywords = _candidate_ranking_keywords(pipeline_ids)
    if not keywords:
        keywords = [selected_key[0]] if selected_key[0] else []
    visible_candidates = candidates if limit is None else candidates[: max(0, limit)]
    return {
        "role": selected_key[0],
        "type_code": selected_key[1],
        "type_label": job_type_label(selected_key[1]),
        "keywords": keywords,
        "total": len(candidates),
        "candidates": visible_candidates,
    }


def get_owner_overview_for_user(
    user_id: str, tenant_id: str = "tenant_default", include_all: bool = False
) -> list[dict]:
    """Aggregate hiring outcomes by pipeline owner within the caller's scope."""
    pipelines = _db.list_pipelines_for_user(user_id, tenant_id, include_all=include_all)
    if not pipelines:
        return []

    conn = _db.get_db()
    pipeline_ids = [str(p["id"]) for p in pipelines]
    placeholders = ",".join("%s" for _ in pipeline_ids)
    candidate_rows = conn.execute(
        f"""SELECT pipeline_id,
                   COUNT(*) AS candidate_count,
                   SUM(CASE WHEN status = 'offered' THEN 1 ELSE 0 END) AS hire_count
            FROM candidates
            WHERE pipeline_id IN ({placeholders})
            GROUP BY pipeline_id""",
        pipeline_ids,
    ).fetchall()
    owner_ids = {str(p.get("owner_user_id") or "") for p in pipelines}
    owner_rows = []
    if owner_ids:
        owner_placeholders = ",".join("%s" for _ in owner_ids)
        owner_rows = conn.execute(
            f"SELECT id, display_name, username FROM auth_users WHERE tenant_id=%s AND id IN ({owner_placeholders})",
            [tenant_id, *owner_ids],
        ).fetchall()

    return _owner_overview_helpers.aggregate_owner_overview(
        pipelines,
        candidate_rows,
        owner_rows,
    )


_gender_bucket = _talent_pool_helpers.gender_bucket
_education_bucket = _talent_pool_helpers.education_bucket
_years_bucket = _talent_pool_helpers.years_bucket
_rank_items = _talent_pool_helpers.rank_items


def get_talent_pool_distribution(tenant_id: str = "tenant_default") -> dict:
    """Aggregate talent-pool resume demographics for the leader cabin panel.

    Counts resumes of a single tenant across gender, education
    (normalized), location and years-of-experience buckets. The last dimension
    stands in for age until the pool carries a real age/birth-date field.
    """
    conn = _db.get_db()
    rows = conn.execute(
        """SELECT gender, education, location, years_experience
           FROM resumes WHERE tenant_id = %s""",
        (tenant_id,),
    ).fetchall()

    gender: dict[str, int] = {}
    education: dict[str, int] = {}
    location: dict[str, int] = {}
    years: dict[str, int] = {
        "应届/0-1年": 0,
        "1-3年": 0,
        "3-5年": 0,
        "5-10年": 0,
        "10年以上": 0,
        "未填写": 0,
    }
    for row in rows:
        gender_key = _gender_bucket(row["gender"])
        gender[gender_key] = gender.get(gender_key, 0) + 1

        education_key = _education_bucket(row["education"])
        education[education_key] = education.get(education_key, 0) + 1

        location_key = (row["location"] or "").strip() or "未填写"
        location[location_key] = location.get(location_key, 0) + 1

        years_key = _years_bucket(row["years_experience"])
        years[years_key] += 1

    return {
        "gender": _rank_items(gender, 5),
        "education": _rank_items(education, 7),
        "location": _rank_items(location, 8),
        "years_experience": [{"name": name, "value": years[name]} for name in years],
    }


def _decode_stage_output(output) -> dict:
    """Decode a pipeline_stages.output cell into a dict, undoing double JSON encoding."""
    if isinstance(output, dict):
        return output
    if isinstance(output, str) and output:
        value = output
        for _ in range(2):
            try:
                parsed = json.loads(value)
            except (json.JSONDecodeError, TypeError):
                break
            if isinstance(parsed, str):
                value = parsed
                continue
            if isinstance(parsed, dict):
                return parsed
            break
    return {}


def _candidate_id_from_item(item) -> str:
    """Extract a candidate id from a str or a candidate dict."""
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        return str(item.get("id") or item.get("candidate_id") or "")
    return ""


def get_talent_attrition(tenant_id: str = "tenant_default") -> dict:
    """Aggregate attrition signals, deduping a candidate across pipelines.

    When the same resume appears in multiple pipelines, keep the attrition
    signal from the pipeline that progressed furthest: interview rejection,
    expired interview link, then screening rejection.
    """
    conn = _db.get_db()
    # 流失统计只覆盖已完成岗位流水线。
    active_scope = "p.status = 'completed'"
    candidate_rows = conn.execute(
        f"""SELECT c.id, c.pipeline_id, c.resume_id, c.status, c.screening_decision
            FROM candidates c JOIN pipelines p ON p.id = c.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}""",
        (tenant_id,),
    ).fetchall()
    candidate_keys = {
        (str(row["pipeline_id"]), str(row["id"])): _resume_dedup_key(row["resume_id"], row["id"])
        for row in candidate_rows
    }
    screening_decisions = {
        (str(row["pipeline_id"]), str(row["id"])): row["screening_decision"] for row in candidate_rows
    }

    # match 阶段结果用于识别小寻淘汰；candidates.screening_decision 用于识别小筛淘汰。
    # 保留来源 pipeline，随后按候选人流程推进程度跨岗位去重。
    stage_rows = conn.execute(
        f"""SELECT ps.pipeline_id, ps.output
            FROM pipeline_stages ps JOIN pipelines p ON p.id = ps.pipeline_id
            WHERE ps.stage_id = 'match' AND p.tenant_id = %s AND {active_scope}
            ORDER BY ps.id DESC""",
        (tenant_id,),
    ).fetchall()
    classification: dict[str, tuple[int, str]] = {}

    def _identity(pipeline_id: str, candidate_id: str) -> str:
        return candidate_keys.get((str(pipeline_id), str(candidate_id)), f"c:{candidate_id}")

    # 同一候选人投递多个岗位时，只保留其流程推进最远的流水线结果。
    pipeline_progress: dict[tuple[str, str], int] = {}
    max_progress: dict[str, int] = {}
    preferred_pipeline: dict[str, tuple[int, str, int]] = {}
    for row in candidate_rows:
        pipeline_id = str(row["pipeline_id"])
        cid = str(row["id"])
        identity = _identity(pipeline_id, cid)
        decision = str(row["screening_decision"] or "").strip().lower()
        candidate_status = str(row.get("status") or "").strip().lower()
        # match 完成后进入小筛的候选人（通过或淘汰）都算已推进到小筛阶段。
        progress = (
            2 if decision in {"passed", "rejected"} or candidate_status in {"passed", "shortlisted", "rejected"} else 0
        )
        pipeline_progress[(pipeline_id, cid)] = progress
        max_progress[identity] = max(max_progress.get(identity, 0), progress)
        quality = 1 if decision == "passed" or candidate_status in {"passed", "shortlisted"} else 0
        current = preferred_pipeline.get(identity)
        if current is None or (progress, quality) > (current[0], current[2]):
            preferred_pipeline[identity] = (progress, pipeline_id, quality)

    session_progress_rows = conn.execute(
        f"""SELECT s.pipeline_id, s.candidate_id, s.status
            FROM interview_sessions s JOIN pipelines p ON p.id = s.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}
            UNION ALL
            SELECT s.pipeline_id, s.candidate_id, s.status
            FROM written_test_sessions s JOIN pipelines p ON p.id = s.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}""",
        (tenant_id, tenant_id),
    ).fetchall()
    for row in session_progress_rows:
        pipeline_id = str(row["pipeline_id"])
        cid = str(row["candidate_id"])
        identity = _identity(pipeline_id, cid)
        if identity.startswith("c:") and (pipeline_id, cid) not in pipeline_progress:
            continue
        status = str(row["status"] or "").strip().lower()
        progress = 3 if status in {"completed", "evaluated", "submitted", "scored"} else 2
        pipeline_progress[(pipeline_id, cid)] = max(pipeline_progress.get((pipeline_id, cid), 0), progress)
        max_progress[identity] = max(max_progress.get(identity, 0), progress)
        current = preferred_pipeline.get(identity)
        if current is None or progress > current[0]:
            preferred_pipeline[identity] = (progress, pipeline_id, 0)

    def _record(identity: str, rank: int, kind: str, pipeline_id: str = "", cid: str = "") -> None:
        if not identity:
            return
        if (
            pipeline_id
            and cid
            and pipeline_progress.get((str(pipeline_id), str(cid)), 0) < max_progress.get(identity, 0)
        ):
            return
        if pipeline_id and preferred_pipeline.get(identity, (0, "", 0))[0] == max_progress.get(identity, 0):
            preferred = preferred_pipeline.get(identity, (0, "", 0))[1]
            if preferred and preferred != str(pipeline_id):
                return
        current = classification.get(identity)
        if current is None or rank > current[0]:
            classification[identity] = (rank, kind)

    def _classify(item: dict, pipeline_id: str, cid: str) -> None:
        identity = _identity(pipeline_id, cid)
        if not cid or item.get("status") != "rejected":
            return
        # 小寻/AI 匹配阶段淘汰，计入“岗位不匹配”。
        _record(identity, 0, "job_mismatch", pipeline_id, cid)

    # 小筛阶段明确淘汰，计入“初筛不通过”；该阶段晚于小寻匹配。
    for row in candidate_rows:
        decision = str(row["screening_decision"] or "").strip().lower()
        if decision == "rejected":
            pipeline_id = str(row["pipeline_id"])
            cid = str(row["id"])
            _record(_identity(pipeline_id, cid), 1, "screening_reject", pipeline_id, cid)

    latest_stage_rows: dict[str, dict] = {}
    for row in stage_rows:
        latest_stage_rows.setdefault(str(row["pipeline_id"]), row)
    for row in latest_stage_rows.values():
        pipeline_id = str(row["pipeline_id"])
        output = _decode_stage_output(row["output"])
        for item in output.get("candidates") or []:
            if isinstance(item, dict):
                _classify(item, pipeline_id, _candidate_id_from_item(item))
        for legacy_key in ("rejected", "eliminated"):
            for item in output.get(legacy_key) or []:
                cid = _candidate_id_from_item(item)
                identity = _identity(pipeline_id, cid)
                _record(identity, 0, "job_mismatch", pipeline_id, cid)

    # 小面不通过取小评评估包最终分数（低于 60），而不是简历匹配分数。
    assessment_rows = conn.execute(
        f"""SELECT a.pipeline_id, a.candidate_id, a.package,
                   (SELECT c.resume_id FROM candidates c
                    WHERE c.id = a.candidate_id AND c.pipeline_id = a.pipeline_id) AS resume_id
            FROM assessment_candidate_states a
            JOIN pipelines p ON p.id = a.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}
            ORDER BY a.id DESC""",
        (tenant_id,),
    ).fetchall()
    latest_assessments: dict[tuple[str, str], dict] = {}
    for row in assessment_rows:
        latest_assessments.setdefault((str(row["pipeline_id"]), str(row["candidate_id"])), row)
    for row in latest_assessments.values():
        package = _decode_stage_output(row["package"])
        if package.get("queue_status") not in {"ready_for_decision", "completed"}:
            continue
        try:
            score = float(package.get("final_score", package.get("overall_score", package.get("score"))))
        except (TypeError, ValueError):
            continue
        # 小面评估完成是最远流程阶段，无论是否通过都覆盖较早岗位结果。
        pipeline_id = str(row["pipeline_id"])
        candidate_id = str(row["candidate_id"])
        identity = _resume_dedup_key(row["resume_id"], candidate_id)
        pipeline_progress[(pipeline_id, candidate_id)] = max(pipeline_progress.get((pipeline_id, candidate_id), 0), 4)
        max_progress[identity] = max(max_progress.get(identity, 0), 4)
        current_choice = preferred_pipeline.get(identity)
        if current_choice is None or current_choice[0] < 4:
            preferred_pipeline[identity] = (4, pipeline_id, 1 if score >= _db.INTERVIEW_PASS_SCORE_THRESHOLD else 0)
        if score < _db.INTERVIEW_PASS_SCORE_THRESHOLD:
            _record(identity, 4, "interview_reject", pipeline_id, candidate_id)

    # 人才库中未进入任何已完成岗位流水线的简历，视为在小寻岗位匹配阶段流失。
    completed_candidate_resumes = {
        str(row["resume_id"]).strip() for row in candidate_rows if str(row["resume_id"] or "").strip()
    }
    for row in conn.execute(
        "SELECT id FROM resumes WHERE tenant_id = %s",
        (tenant_id,),
    ).fetchall():
        resume_id = str(row["id"] or "").strip()
        if resume_id and resume_id not in completed_candidate_resumes:
            _record(_resume_dedup_key(resume_id, resume_id), 0, "job_mismatch")

    expired_rows = conn.execute(
        f"""SELECT s.candidate_id, s.pipeline_id, s.status, s.expires_at, s.lease_expires_at, c.resume_id
            FROM interview_sessions s
            JOIN pipelines p ON p.id = s.pipeline_id
            LEFT JOIN candidates c ON c.id = s.candidate_id AND c.pipeline_id = s.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}
           UNION ALL
           SELECT s.candidate_id, s.pipeline_id, s.status, s.expires_at, s.lease_expires_at, c.resume_id
            FROM written_test_sessions s
            JOIN pipelines p ON p.id = s.pipeline_id
            LEFT JOIN candidates c ON c.id = s.candidate_id AND c.pipeline_id = s.pipeline_id
            WHERE p.tenant_id = %s AND {active_scope}""",
        (tenant_id, tenant_id),
    ).fetchall()
    for row in expired_rows:
        expires_at = _parse_db_ts(row.get("expires_at"))
        lease_expires_at = _parse_db_ts(row.get("lease_expires_at"))
        now_ts = datetime.now().replace(tzinfo=None)
        if (
            str(row.get("status") or "").strip().lower() != "expired"
            and (expires_at is None or expires_at > now_ts)
            and (lease_expires_at is None or lease_expires_at > now_ts)
        ):
            continue
        identity = _resume_dedup_key(row["resume_id"], row["candidate_id"])
        _record(identity, 2, "interview_declined", row["pipeline_id"], row["candidate_id"])

    talent_pool_total = int(
        conn.execute(
            "SELECT COUNT(*) AS c FROM resumes WHERE tenant_id = %s",
            (tenant_id,),
        ).fetchone()["c"]
        or 0
    )
    passed_identities: set[str] = set()
    for row in latest_assessments.values():
        package = _decode_stage_output(row["package"])
        try:
            score = float(package.get("final_score", package.get("overall_score", package.get("score"))))
        except (TypeError, ValueError):
            continue
        identity = _resume_dedup_key(row["resume_id"], row["candidate_id"])
        chosen = preferred_pipeline.get(identity)
        if score >= _db.INTERVIEW_PASS_SCORE_THRESHOLD and chosen and chosen[1] == str(row["pipeline_id"]):
            passed_identities.add(identity)
    interview_passed = len(passed_identities)
    # 同一候选人若最远流水线被小面判定不通过，不计入面试通过。
    interview_passed = sum(
        1 for identity in passed_identities if classification.get(identity, (0, ""))[1] != "interview_reject"
    )
    counts = {
        "job_mismatch": sum(1 for _, kind in classification.values() if kind == "job_mismatch"),
        "screening_reject": sum(1 for _, kind in classification.values() if kind == "screening_reject"),
        "interview_reject": sum(1 for _, kind in classification.values() if kind == "interview_reject"),
        "interview_declined": sum(1 for _, kind in classification.values() if kind == "interview_declined"),
    }
    # 四类流失为互斥的最远阶段分类，确保与人才库总数守恒。
    interview_passed = max(talent_pool_total - sum(counts.values()), 0)
    counts.update(
        {
            "talent_pool_total": talent_pool_total,
            "interview_passed": interview_passed,
            "attrition_total": max(talent_pool_total - interview_passed, 0),
        }
    )
    return counts


def get_stage_pass_rate_trend(tenant_id: str = "tenant_default", days: int = 30) -> dict:
    """Return cumulative pass-rate trends aggregated across all HR users.

    The scope deliberately matches the adjacent HR performance card: completed
    pipelines owned by an HR user in the current tenant. Each application is
    counted once per pipeline. Screening rate is passed screening divided by
    applications; interview rate is passed formal review divided by candidates
    who participated in an interview or written assessment. Legacy completed
    interview scores are used only when no formal assessment state exists.
    """
    conn = _db.get_db()
    now = datetime.now()

    def metric_key(pipeline_id, resume_id, candidate_id) -> str:
        return f"{pipeline_id}:{_resume_dedup_key(resume_id, candidate_id)}"

    def record_earliest(events: dict[str, datetime], key: str, value) -> None:
        parsed = _parse_db_ts(value)
        if parsed is not None and (key not in events or parsed < events[key]):
            events[key] = parsed

    candidate_rows = conn.execute(
        """SELECT c.id, c.pipeline_id, c.resume_id, c.status, c.screening_decision,
                  c.screening_decision_at, c.created_at, p.created_at AS pipeline_created_at
           FROM candidates c
           JOIN pipelines p ON p.id = c.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND COALESCE(p.owner_user_id, '') <> ''""",
        (tenant_id,),
    ).fetchall()

    applications: dict[str, datetime] = {}
    screened_events: dict[str, datetime] = {}
    candidate_metric_keys: dict[tuple[str, str], str] = {}
    for row in candidate_rows:
        pipeline_id = str(row["pipeline_id"])
        candidate_id = str(row["id"])
        key = metric_key(pipeline_id, row["resume_id"], candidate_id)
        candidate_metric_keys[(pipeline_id, candidate_id)] = key
        record_earliest(applications, key, row["created_at"] or row["pipeline_created_at"])

    match_stage_rows = conn.execute(
        """SELECT ps.id, ps.pipeline_id, ps.output, ps.completed_at
           FROM pipeline_stages ps
           JOIN pipelines p ON p.id = ps.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND COALESCE(p.owner_user_id, '') <> '' AND ps.stage_id = 'match'
           ORDER BY ps.id DESC""",
        (tenant_id,),
    ).fetchall()
    latest_match_rows: dict[str, dict] = {}
    for row in match_stage_rows:
        latest_match_rows.setdefault(str(row["pipeline_id"]), row)

    screening_status_by_key: dict[tuple[str, str], str] = {}
    screening_event_by_key: dict[tuple[str, str], object] = {}
    screening_stage_pipelines: set[str] = set()
    for row in latest_match_rows.values():
        pipeline_id = str(row["pipeline_id"])
        output = _decode_stage_output(row["output"])
        candidates = output.get("candidates")
        if not isinstance(candidates, list):
            continue
        screening_stage_pipelines.add(pipeline_id)
        for candidate in candidates:
            if not isinstance(candidate, dict) or not candidate.get("id"):
                continue
            status = str(candidate.get("status") or "").strip().lower()
            if status not in {"passed", "rejected"}:
                continue
            identity = (pipeline_id, str(candidate["id"]))
            screening_status_by_key[identity] = status
            screening_event_by_key[identity] = row["completed_at"]

    for row in candidate_rows:
        pipeline_id = str(row["pipeline_id"])
        candidate_id = str(row["id"])
        candidate_key = (pipeline_id, candidate_id)
        key = candidate_metric_keys[candidate_key]
        if key not in applications:
            continue
        if pipeline_id in screening_stage_pipelines:
            passed = screening_status_by_key.get(candidate_key) == "passed"
            event_at = screening_event_by_key.get(candidate_key) or row["screening_decision_at"] or row["created_at"]
        else:
            status = str(row["status"] or "").strip().lower()
            decision = str(row["screening_decision"] or "").strip().lower()
            passed = decision == "passed" or status in {"passed", "shortlisted"}
            event_at = row["screening_decision_at"] or row["created_at"]
        if passed:
            record_earliest(screened_events, key, event_at)

    session_rows = conn.execute(
        """SELECT s.pipeline_id, s.candidate_id, s.status, s.started_at, s.completed_at,
                  s.evaluated_at, s.created_at, s.interview_score
           FROM interview_sessions s
           JOIN pipelines p ON p.id = s.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND COALESCE(p.owner_user_id, '') <> ''
             AND (COALESCE(s.started_at, '') <> ''
                  OR s.status IN ('started', 'streaming', 'in_progress', 'completed', 'evaluated'))""",
        (tenant_id,),
    ).fetchall()
    participated_events: dict[str, datetime] = {}
    passed_events: dict[str, datetime] = {}
    for row in session_rows:
        candidate_key = (str(row["pipeline_id"]), str(row["candidate_id"]))
        key = candidate_metric_keys.get(candidate_key)
        if key is None:
            continue
        event_at = row["started_at"] or row["evaluated_at"] or row["completed_at"] or row["created_at"]
        record_earliest(participated_events, key, event_at)

    try:
        written_rows = conn.execute(
            """SELECT s.pipeline_id, s.candidate_id, s.started_at, s.submitted_at,
                      s.scoring_completed_at, s.created_at
               FROM written_test_sessions s
               JOIN pipelines p ON p.id = s.pipeline_id
               WHERE p.tenant_id = %s AND p.status = 'completed'
                 AND COALESCE(p.owner_user_id, '') <> ''
                 AND (COALESCE(s.started_at, '') <> ''
                      OR s.status IN ('in_progress', 'submitted', 'scored'))""",
            (tenant_id,),
        ).fetchall()
    except Exception:
        written_rows = []
    for row in written_rows:
        candidate_key = (str(row["pipeline_id"]), str(row["candidate_id"]))
        key = candidate_metric_keys.get(candidate_key)
        if key is None:
            continue
        event_at = row["started_at"] or row["submitted_at"] or row["scoring_completed_at"] or row["created_at"]
        record_earliest(participated_events, key, event_at)

    try:
        assessment_rows = conn.execute(
            """SELECT a.id, a.pipeline_id, a.candidate_id, a.queue_status, a.package,
                      a.updated_at, a.created_at
               FROM assessment_candidate_states a
               JOIN pipelines p ON p.id = a.pipeline_id
               WHERE p.tenant_id = %s AND p.status = 'completed'
                 AND COALESCE(p.owner_user_id, '') <> ''
               ORDER BY a.updated_at DESC, a.id DESC""",
            (tenant_id,),
        ).fetchall()
    except Exception:
        assessment_rows = []
    latest_assessments: dict[tuple[str, str], dict] = {}
    for row in assessment_rows:
        candidate_key = (str(row["pipeline_id"]), str(row["candidate_id"]))
        latest_assessments.setdefault(candidate_key, row)

    for candidate_key, row in latest_assessments.items():
        key = candidate_metric_keys.get(candidate_key)
        if key is None:
            continue
        package = _decode_stage_output(row["package"])
        queue_status = str(package.get("queue_status") or row["queue_status"] or "").strip().lower()
        if queue_status not in {"ready_for_decision", "completed"}:
            continue
        event_at = row["updated_at"] or row["created_at"]
        record_earliest(participated_events, key, event_at)
        try:
            score = float(package.get("final_score", package.get("overall_score", package.get("score"))))
        except (TypeError, ValueError):
            continue
        if score >= _db.INTERVIEW_PASS_SCORE_THRESHOLD:
            record_earliest(passed_events, key, event_at)

    formal_candidate_keys = set(latest_assessments)
    for row in session_rows:
        candidate_key = (str(row["pipeline_id"]), str(row["candidate_id"]))
        if candidate_key in formal_candidate_keys:
            continue
        key = candidate_metric_keys.get(candidate_key)
        if key is None:
            continue
        try:
            passed = float(row["interview_score"]) >= _db.INTERVIEW_PASS_SCORE_THRESHOLD
        except (TypeError, ValueError):
            passed = False
        if passed and str(row["status"] or "").strip().lower() in {"completed", "evaluated"}:
            event_at = row["evaluated_at"] or row["completed_at"] or row["created_at"]
            record_earliest(passed_events, key, event_at)

    # A pass is always part of the participation denominator, including sparse
    # legacy records where the start timestamp was not persisted.
    for key, event_at in passed_events.items():
        record_earliest(participated_events, key, event_at)

    days_axis: list[str] = []
    screening_pass_rate: list[float | None] = []
    interview_pass_rate: list[float | None] = []
    for offset in range(days - 1, -1, -1):
        day = (now - timedelta(days=offset)).date()
        days_axis.append(day.strftime("%Y-%m-%d"))
        application_keys = {key for key, event_at in applications.items() if event_at.date() <= day}
        screened_keys = {
            key for key, event_at in screened_events.items() if key in application_keys and event_at.date() <= day
        }
        participant_keys = {key for key, event_at in participated_events.items() if event_at.date() <= day}
        passed_keys = {
            key for key, event_at in passed_events.items() if key in participant_keys and event_at.date() <= day
        }
        screening_pass_rate.append(round(len(screened_keys) / len(application_keys), 4) if application_keys else None)
        interview_pass_rate.append(round(len(passed_keys) / len(participant_keys), 4) if participant_keys else None)

    return {
        "days": days_axis,
        "screening_pass_rate": screening_pass_rate,
        "interview_pass_rate": interview_pass_rate,
        "aggregation_scope": "all_hr_completed_pipelines",
        "trend_basis": "cumulative",
    }


_parse_db_ts = _analytics_time_helpers.parse_db_ts


def _resume_dedup_key(resume_id, candidate_id: str) -> str:
    """去重键：同一简历在 HR 名下多个岗位只计一次；无简历号时退回候选人 ID。"""
    rid = str(resume_id or "").strip()
    return f"r:{rid}" if rid else f"c:{candidate_id}"


def get_hr_performance(tenant_id: str = "tenant_default") -> list[dict]:
    """Per-HR workload rows for the leader cabin HR card.

    口径（与需求确认一致）：
      - 仅统计当前租户内 status='completed' 的流水线（进行中/归档不计）；
      - 岗位 = HR 名下已完成流水线数；
      - 简历 = 通过小筛的简历去重数（screening_decision='passed' 或 status
        为 passed/shortlisted；仅在同一岗位流水线内按 resume_id 去重）；
      - 面试 = 小评状态为 passed 的候选人去重数（仅在同一岗位流水线内去重）；
      - 参加面试 = 视频/笔试链接已打开的候选人去重数（会话写入 started_at
        或进入进行中/已提交/已评估状态），以及小评状态为 passed 的候选人；
      - 通过率 = 小评通过 ÷ 参加面试，参加面试为 0 时返回 None；分子是
        分母的子集，因此任何数据下都在 0~100% 之间。
      - 响应时间 = HR 已完成流水线的平均耗时：小评结束时间 − 流水线创建时间
        − 该流水线内各候选人的面试时长（面试时长由候选人掌控，不予计入）；
        小评结束取 interview_gen/video_assess 阶段 completed_at，缺失时退回
        最后一场面试的 evaluated_at/completed_at；负值截断为 0。

    Includes every active tenant user, zero-filled when they own no completed
    pipeline. Sorted by pass rate desc (uncomputable last), then jobs desc.
    """
    conn = _db.get_db()

    users = conn.execute(
        """SELECT id, display_name, username
           FROM auth_users
           WHERE tenant_id = %s AND is_active = 1""",
        (tenant_id,),
    ).fetchall()

    pipelines = conn.execute(
        """SELECT id, owner_user_id, created_at
           FROM pipelines
           WHERE tenant_id = %s AND status = 'completed'""",
        (tenant_id,),
    ).fetchall()

    stage_rows = conn.execute(
        """SELECT ps.pipeline_id, MAX(ps.completed_at) AS stage_end
           FROM pipeline_stages ps
           JOIN pipelines p ON p.id = ps.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND ps.stage_id IN ('interview_gen', 'video_assess')
             AND ps.status = 'done'
             AND ps.completed_at IS NOT NULL AND ps.completed_at != ''
           GROUP BY ps.pipeline_id""",
        (tenant_id,),
    ).fetchall()
    stage_end_by_pipeline = {str(row["pipeline_id"]): row["stage_end"] for row in stage_rows}

    session_rows = conn.execute(
        """SELECT s.pipeline_id, s.candidate_id, s.status, s.started_at, s.completed_at, s.evaluated_at
           FROM interview_sessions s
           JOIN pipelines p ON p.id = s.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'""",
        (tenant_id,),
    ).fetchall()
    sessions_by_pipeline: dict[str, list] = {}
    for row in session_rows:
        sessions_by_pipeline.setdefault(str(row["pipeline_id"]), []).append(row)

    resume_rows = conn.execute(
        """SELECT p.owner_user_id, c.pipeline_id, c.resume_id, c.id, c.status, c.screening_decision
           FROM candidates c
           JOIN pipelines p ON p.id = c.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'""",
        (tenant_id,),
    ).fetchall()

    match_stage_rows = conn.execute(
        """SELECT pipeline_id, output
           FROM pipeline_stages
           WHERE stage_id = 'match' AND pipeline_id IN (
             SELECT id FROM pipelines WHERE tenant_id = %s AND status = 'completed'
           )
           ORDER BY id DESC""",
        (tenant_id,),
    ).fetchall()
    # 同一流水线可能有多次小评，只保留自增 id 最大的最新结果。
    latest_match_rows: dict[str, dict] = {}
    for stage_row in match_stage_rows:
        latest_match_rows.setdefault(str(stage_row["pipeline_id"]), stage_row)
    screening_status_by_key: dict[tuple[str, str], str] = {}
    screening_stage_pipelines: set[str] = set()
    for stage_row in latest_match_rows.values():
        pipeline_key = str(stage_row["pipeline_id"])
        raw_output = stage_row.get("output")
        try:
            output = json.loads(raw_output) if isinstance(raw_output, str) else raw_output
        except (TypeError, ValueError, json.JSONDecodeError):
            output = None
        if not isinstance(output, dict):
            continue
        if not isinstance(output.get("candidates"), list):
            continue
        screening_stage_pipelines.add(pipeline_key)
        # 小评页面展示的是 candidates[].status（仅 passed/rejected），
        # 不使用可能残留历史批次 ID 的 passed_ids/rejected 汇总字段。
        for candidate in output.get("candidates", []):
            if not isinstance(candidate, dict) or not candidate.get("id"):
                continue
            status = str(candidate.get("status") or "").strip().lower()
            if status in {"passed", "rejected"} and (pipeline_key, str(candidate["id"])) not in screening_status_by_key:
                screening_status_by_key[(pipeline_key, str(candidate["id"]))] = status

    interview_rows = conn.execute(
        """SELECT p.owner_user_id, s.pipeline_id, s.candidate_id, s.status, s.started_at,
                  (SELECT c2.resume_id FROM candidates c2
                   WHERE c2.id = s.candidate_id AND c2.pipeline_id = s.pipeline_id) AS resume_id
           FROM interview_sessions s
           JOIN pipelines p ON p.id = s.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND (COALESCE(s.started_at, '') <> '' OR s.status IN ('started', 'in_progress', 'completed', 'evaluated'))""",
        (tenant_id,),
    ).fetchall()

    jobs: dict[str, int] = {}
    resume_keys: dict[str, set] = {}
    interviewed_keys: dict[str, set] = {}
    passed_keys: dict[str, set] = {}
    pipeline_seconds: dict[str, list] = {}

    def metric_key(pipeline_id, resume_id, candidate_id) -> str:
        return f"{pipeline_id}:{_resume_dedup_key(resume_id, candidate_id)}"

    for pipeline in pipelines:
        owner = str(pipeline["owner_user_id"] or "")
        if not owner:
            continue
        jobs[owner] = jobs.get(owner, 0) + 1
        created = _parse_db_ts(pipeline["created_at"])
        sessions = sessions_by_pipeline.get(str(pipeline["id"]), [])
        end_ts = _parse_db_ts(stage_end_by_pipeline.get(str(pipeline["id"])))
        if end_ts is None:
            fallbacks = []
            for session in sessions:
                for field in ("evaluated_at", "completed_at"):
                    parsed = _parse_db_ts(session.get(field))
                    if parsed is not None:
                        fallbacks.append(parsed)
            end_ts = max(fallbacks) if fallbacks else None
        # 响应时间按每条已完成流水线计算；没有候选人面试时长时按 0 秒扣减，
        # 不能因为 sessions 为空而漏掉该流水线。
        if created is not None:
            interview_seconds = 0
            for session in sessions:
                started = _parse_db_ts(session.get("started_at"))
                completed = _parse_db_ts(session.get("completed_at"))
                if started is not None and completed is not None and completed > started:
                    interview_seconds += int((completed - started).total_seconds())
            if end_ts is not None and end_ts > created:
                elapsed = max(0, int((end_ts - created).total_seconds()) - interview_seconds)
                pipeline_seconds.setdefault(owner, []).append(elapsed)

    for row in resume_rows:
        owner = str(row["owner_user_id"] or "")
        key = metric_key(row["pipeline_id"], row["resume_id"], row["id"])
        # 小评只有 passed/rejected 两种最终状态；以当前 status 为准，
        # 只要存在小评阶段就完全以阶段结果为准，避免候选人表残留旧决策。
        pipeline_key = str(row.get("pipeline_id") or "")
        stage_status = screening_status_by_key.get((pipeline_key, str(row["id"])))
        if pipeline_key in screening_stage_pipelines:
            status = stage_status or ""
            decision = ""
            resume_eligible = status == "passed"
        else:
            status = str(row.get("status") or "").strip().lower()
            decision = str(row.get("screening_decision") or "").strip().lower()
            resume_eligible = decision == "passed" or status in {"passed", "shortlisted"}
        if resume_eligible:
            resume_keys.setdefault(owner, set()).add(key)
    for row in interview_rows:
        owner = str(row["owner_user_id"] or "")
        if not owner:
            continue
        key = metric_key(row["pipeline_id"], row["resume_id"], row["candidate_id"])
        interviewed_keys.setdefault(owner, set()).add(key)

    written_rows = conn.execute(
        """SELECT p.owner_user_id, s.pipeline_id, s.candidate_id, s.status, s.started_at,
                  (SELECT c.resume_id FROM candidates c
                   WHERE c.id = s.candidate_id AND c.pipeline_id = s.pipeline_id) AS resume_id
           FROM written_test_sessions s
           JOIN pipelines p ON p.id = s.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
             AND (COALESCE(s.started_at, '') <> '' OR s.status IN ('in_progress', 'submitted', 'scored'))""",
        (tenant_id,),
    ).fetchall()
    for row in written_rows:
        owner = str(row["owner_user_id"] or "")
        if not owner:
            continue
        key = metric_key(row["pipeline_id"], row["resume_id"], row["candidate_id"])
        interviewed_keys.setdefault(owner, set()).add(key)

    assessment_rows = conn.execute(
        """SELECT a.pipeline_id, a.candidate_id, a.package, p.owner_user_id,
                  (SELECT c.resume_id FROM candidates c
                   WHERE c.id = a.candidate_id AND c.pipeline_id = a.pipeline_id) AS resume_id
           FROM assessment_candidate_states a
           JOIN pipelines p ON p.id = a.pipeline_id
           WHERE p.tenant_id = %s AND p.status = 'completed'
           ORDER BY a.id DESC""",
        (tenant_id,),
    ).fetchall()
    latest_assessments: dict[tuple[str, str], dict] = {}
    for row in assessment_rows:
        latest_assessments.setdefault((str(row["pipeline_id"]), str(row["candidate_id"])), row)
    for row in latest_assessments.values():
        package = row.get("package")
        try:
            package = json.loads(package) if isinstance(package, str) else package
        except (TypeError, ValueError, json.JSONDecodeError):
            package = None
        if not isinstance(package, dict) or package.get("queue_status") != "ready_for_decision":
            continue
        try:
            score = float(package.get("final_score", package.get("overall_score")))
        except (TypeError, ValueError):
            continue
        if score < _db.INTERVIEW_PASS_SCORE_THRESHOLD:
            continue
        owner = str(row["owner_user_id"] or "")
        if not owner:
            continue
        key = metric_key(row["pipeline_id"], row["resume_id"], row["candidate_id"])
        interviewed_keys.setdefault(owner, set()).add(key)
        passed_keys.setdefault(owner, set()).add(key)

    result = []
    for user in users:
        hr_id = str(user["id"])
        resume_count = len(resume_keys.get(hr_id, set()))
        interviewed_count = len(interviewed_keys.get(hr_id, set()))
        interview_count = len(passed_keys.get(hr_id, set()))
        seconds = pipeline_seconds.get(hr_id) or []
        pass_rate = round(interview_count / interviewed_count, 4) if interviewed_count > 0 else None
        response_days = round(sum(seconds) / len(seconds) / 86400, 1) if seconds else None
        result.append(
            {
                "hr_id": hr_id,
                "name": str(user["display_name"] or user["username"] or hr_id),
                "jobs": jobs.get(hr_id, 0),
                "resumes": resume_count,
                "interviewed": interviewed_count,
                "interviews": interview_count,
                "pass_rate": pass_rate,
                "response_days": response_days,
            }
        )

    result.sort(
        key=lambda row: (
            row["pass_rate"] is None,
            -(row["pass_rate"] or 0),
            -row["jobs"],
            -row["resumes"],
            row["name"],
        )
    )
    return result


def get_talent_pool_growth(tenant_id: str = "tenant_default", days: int = 30) -> dict:
    """Talent pool growth trend for the leader cabin panel.

    Daily buckets over the last ``days`` days, anchored to the whole
    resumes pool (the same scope as get_talent_pool_distribution):

      - daily_new        = 当日新增入库简历数（按 created_at 落 bucket）
      - cumulative_total = 截至当日的简历累计总量（含窗口之前的历史存量）
      - growth_rate      = 新增候选人环比 = (当日新增 − 前一日新增) ÷ 前一日新增；
                           前一日新增为 0 时返回 None

    The day before the window is counted as well, so the first visible day has
    a real period-over-period rate. Buckets are local dates, matching
    get_stage_pass_rate_trend.
    """
    conn = _db.get_db()
    today = datetime.now()
    window_start, pre_start = _talent_pool_helpers.talent_pool_growth_window(days, today=today)

    rows = conn.execute(
        """SELECT date(created_at) AS day, COUNT(*) AS c
           FROM resumes
           WHERE tenant_id = %s AND created_at >= %s
           GROUP BY date(created_at)""",
        (tenant_id, pre_start.strftime("%Y-%m-%d")),
    ).fetchall()
    new_by_day = {str(row["day"]): int(row["c"] or 0) for row in rows if row["day"]}

    total_row = conn.execute(
        "SELECT COUNT(*) AS c FROM resumes WHERE tenant_id = %s",
        (tenant_id,),
    ).fetchone()
    total = int(total_row["c"] if total_row else 0)

    before_row = conn.execute(
        """SELECT COUNT(*) AS c FROM resumes
           WHERE tenant_id = %s AND created_at < %s""",
        (tenant_id, window_start.strftime("%Y-%m-%d")),
    ).fetchone()
    before_count = int(before_row["c"] if before_row else 0)

    return _talent_pool_helpers.talent_pool_growth_series(
        new_by_day,
        before_count,
        total,
        days=days,
        today=today,
    )


# ============ 漏斗分析 ============


def get_funnel_data(pipeline_id: str = "") -> dict:
    """获取招聘漏斗数据"""
    conn = _db.get_db()
    if pipeline_id:
        stages = conn.execute(
            "SELECT stage_id, stage_name, status, started_at, completed_at FROM pipeline_stages WHERE pipeline_id = %s ORDER BY id",
            (pipeline_id,),
        ).fetchall()
        candidates = conn.execute(
            "SELECT status, COUNT(*) as c FROM candidates WHERE pipeline_id = %s GROUP BY status", (pipeline_id,)
        ).fetchall()
        cand_map = {row["status"]: row["c"] for row in candidates}

        return {
            "pipeline_id": pipeline_id,
            "stages": [dict(s) for s in stages],
            "candidate_flow": {
                "total": sum(cand_map.values()),
                "new": cand_map.get("new", 0),
                "matched": cand_map.get("matched", 0),
                "shortlisted": cand_map.get("shortlisted", 0),
                "interviewed": cand_map.get("interviewed", 0),
                "rejected": cand_map.get("rejected", 0),
                "offered": cand_map.get("offered", 0),
            },
        }
    else:
        total_pipelines = conn.execute("SELECT COUNT(*) as c FROM pipelines").fetchone()["c"]
        completed = conn.execute("SELECT COUNT(*) as c FROM pipelines WHERE status='completed'").fetchone()["c"]
        total_candidates = conn.execute("SELECT COUNT(*) as c FROM candidates").fetchone()["c"]

        status_dist = {}
        for row in conn.execute("SELECT status, COUNT(*) as c FROM candidates GROUP BY status").fetchall():
            status_dist[row["status"]] = row["c"]

        avg_scores = conn.execute("""
            SELECT
                AVG(CASE WHEN overall_score > 0 THEN overall_score END) as avg_overall,
                AVG(CASE WHEN tech_score > 0 THEN tech_score END) as avg_tech,
                AVG(CASE WHEN experience_score > 0 THEN experience_score END) as avg_exp,
                AVG(CASE WHEN education_score > 0 THEN education_score END) as avg_edu,
                AVG(CASE WHEN major_match_score > 0 THEN major_match_score END) as avg_major,
                AVG(CASE WHEN culture_score > 0 THEN culture_score END) as avg_culture
            FROM candidates
        """).fetchone()

        return {
            "total_pipelines": total_pipelines,
            "completed_pipelines": completed,
            "completion_rate": round(completed / total_pipelines * 100, 1) if total_pipelines else 0,
            "total_candidates": total_candidates,
            "candidate_flow": status_dist,
            "avg_scores": {
                "overall": round(avg_scores["avg_overall"] or 0, 1),
                "tech": round(avg_scores["avg_tech"] or 0, 1),
                "experience": round(avg_scores["avg_exp"] or 0, 1),
                "education": round(avg_scores["avg_edu"] or 0, 1),
                "major_match": round(avg_scores["avg_major"] or 0, 1),
                "culture": round(avg_scores["avg_culture"] or 0, 1),
            },
        }


def _talent_pool_funnel_metrics(
    user_id: str,
    tenant_id: str = "tenant_default",
    include_all: bool = False,
    days: int = 30,
) -> dict:
    """Return a cumulative, person-deduplicated funnel based on talent-pool resumes.

    Each resume is one person. Across visible pipelines, the deepest
    stage reached by that resume wins; deeper stages also count in every earlier
    funnel stage. Tenant admins use the complete talent pool, while regular users
    only use talent-pool people linked to one of their visible pipelines.
    """
    conn = _db.get_db()
    owner_clause = "" if include_all else " AND p.owner_user_id=%s"
    params = (tenant_id,) if include_all else (tenant_id, user_id)

    if include_all:
        resume_rows = conn.execute(
            """SELECT id, created_at FROM resumes
               WHERE tenant_id=%s""",
            (tenant_id,),
        ).fetchall()
    else:
        resume_rows = conn.execute(
            """SELECT DISTINCT r.id, r.created_at
               FROM resumes r
               JOIN candidates c ON c.resume_id=r.id AND c.tenant_id=r.tenant_id
               JOIN pipelines p ON p.id=c.pipeline_id AND p.tenant_id=r.tenant_id
               WHERE r.tenant_id=%s AND p.owner_user_id=%s""",
            (tenant_id, user_id),
        ).fetchall()

    people: dict[str, dict[str, datetime | None]] = {
        str(row["id"]): {
            "talent_pool": _parse_db_ts(row["created_at"]),
            "applied": None,
            "screened": None,
            "interviewed": None,
            "interview_passed": None,
        }
        for row in resume_rows
        if str(row["id"] or "").strip()
    }

    def record_stage(resume_id, stage: str, event_at) -> None:
        key = str(resume_id or "").strip()
        if key not in people:
            return
        parsed = _parse_db_ts(event_at) or people[key]["applied"] or people[key]["talent_pool"]
        current = people[key][stage]
        if parsed is not None and (current is None or parsed < current):
            people[key][stage] = parsed

    candidate_rows = conn.execute(
        """SELECT c.id, c.pipeline_id, c.resume_id, c.status, c.screening_decision,
                  c.screening_decision_at, c.created_at
           FROM candidates c
           JOIN pipelines p ON p.id=c.pipeline_id
           WHERE p.tenant_id=%s"""
        + owner_clause,
        params,
    ).fetchall()
    screened_statuses = {
        "shortlist",
        "shortlisted",
        "passed",
        "interview",
        "interviewing",
        "in_interview",
        "interview_in_progress",
        "interviewed",
        "offered",
    }
    interview_statuses = {
        "interview",
        "interviewing",
        "in_interview",
        "interview_in_progress",
        "interviewed",
        "offered",
    }
    for row in candidate_rows:
        status = str(row["status"] or "").strip().lower()
        decision = str(row["screening_decision"] or "").strip().lower()
        record_stage(row["resume_id"], "applied", row["created_at"])
        if decision == "passed" or (not decision and status in screened_statuses):
            record_stage(row["resume_id"], "screened", row["screening_decision_at"] or row["created_at"])
        if status in interview_statuses:
            record_stage(row["resume_id"], "interviewed", row["created_at"])

    interview_rows = conn.execute(
        """SELECT c.resume_id, c.id AS candidate_id, c.pipeline_id,
                  s.status, s.started_at, s.created_at, s.updated_at,
                  s.completed_at, s.evaluated_at
           FROM interview_sessions s
           JOIN pipelines p ON p.id=s.pipeline_id
           JOIN candidates c ON c.id=s.candidate_id AND c.pipeline_id=s.pipeline_id
           WHERE p.tenant_id=%s"""
        + owner_clause,
        params,
    ).fetchall()
    reached_interview_statuses = {"started", "streaming", "in_progress", "completed", "evaluated"}
    for row in interview_rows:
        status = str(row["status"] or "").strip().lower()
        if status not in reached_interview_statuses and not row["started_at"]:
            continue
        record_stage(
            row["resume_id"],
            "interviewed",
            row["started_at"] or row["completed_at"] or row["evaluated_at"] or row["created_at"],
        )

    pipeline_ids = sorted({str(row["pipeline_id"]) for row in candidate_rows})
    small_review_scores = _candidate_ranking_small_review_scores(pipeline_ids)
    review_event_times: dict[tuple[str, str], datetime | None] = {}
    for row in interview_rows:
        key = (str(row["pipeline_id"]), str(row["candidate_id"]))
        event_at = _parse_db_ts(row["evaluated_at"] or row["completed_at"] or row["updated_at"] or row["created_at"])
        if event_at is not None and (key not in review_event_times or event_at > review_event_times[key]):
            review_event_times[key] = event_at
    if pipeline_ids:
        placeholders = ",".join("%s" for _ in pipeline_ids)
        try:
            assessment_rows = conn.execute(
                f"""SELECT pipeline_id, candidate_id, updated_at
                    FROM assessment_candidate_states
                    WHERE pipeline_id IN ({placeholders})
                    ORDER BY updated_at DESC""",
                pipeline_ids,
            ).fetchall()
            for row in assessment_rows:
                key = (str(row["pipeline_id"]), str(row["candidate_id"]))
                review_event_times.setdefault(key, _parse_db_ts(row["updated_at"]))
        except Exception:
            pass
    for row in candidate_rows:
        key = (str(row["pipeline_id"]), str(row["id"]))
        score = small_review_scores.get(key)
        if score is not None and score >= _db.INTERVIEW_PASS_SCORE_THRESHOLD:
            record_stage(
                row["resume_id"],
                "interview_passed",
                review_event_times.get(key) or row["created_at"],
            )

    # Reaching a deeper stage implies every preceding stage, even when legacy
    # records omitted the earlier milestone timestamp.
    for person in people.values():
        if person["interview_passed"] is not None:
            if person["interviewed"] is None or person["interview_passed"] < person["interviewed"]:
                person["interviewed"] = person["interview_passed"]
        if person["interviewed"] is not None:
            if person["screened"] is None or person["interviewed"] < person["screened"]:
                person["screened"] = person["interviewed"]
        for stage in ("screened", "interviewed", "interview_passed"):
            event_at = person[stage]
            if event_at is not None and (person["applied"] is None or event_at < person["applied"]):
                person["applied"] = event_at

    cumulative_stage_names = ("applied", "screened", "interviewed", "interview_passed")
    stages = {
        "talent_pool": len(people),
        "not_applied": sum(1 for person in people.values() if person["applied"] is None),
        **{
            stage: sum(1 for person in people.values() if person[stage] is not None) for stage in cumulative_stage_names
        },
    }

    trend_days: list[str] = []
    trend = {stage: [] for stage in cumulative_stage_names}
    today = datetime.now(_db.SHANGHAI_TZ).date()
    for offset in range(days - 1, -1, -1):
        day = today - timedelta(days=offset)
        trend_days.append(day.strftime("%Y-%m-%d"))
        for stage in trend:
            trend[stage].append(
                sum(1 for person in people.values() if person[stage] is not None and person[stage].date() <= day)
            )

    return {
        "total_candidates": stages["talent_pool"],
        "stages": stages,
        "daily_trend": {"days": trend_days, **trend},
    }


def get_funnel_data_for_user(user_id: str, tenant_id: str = "tenant_default", include_all: bool = False) -> dict:
    """Return aggregate funnel data limited to pipelines visible to a user."""
    conn = _db.get_db()
    owner_clause = "" if include_all else " AND p.owner_user_id=%s"
    params = (tenant_id,) if include_all else (tenant_id, user_id)
    talent_funnel = _talent_pool_funnel_metrics(user_id, tenant_id, include_all)

    total_pipelines = conn.execute(
        f"SELECT COUNT(*) AS c FROM pipelines p WHERE p.tenant_id=%s{owner_clause}", params
    ).fetchone()["c"]
    completed = conn.execute(
        f"SELECT COUNT(*) AS c FROM pipelines p WHERE p.tenant_id=%s{owner_clause} AND p.status='completed'",
        params,
    ).fetchone()["c"]
    status_dist = {}
    status_rows = conn.execute(
        f"SELECT c.status, COUNT(*) AS c FROM candidates c JOIN pipelines p ON p.id=c.pipeline_id "
        f"WHERE p.tenant_id=%s{owner_clause} GROUP BY c.status",
        params,
    ).fetchall()
    for row in status_rows:
        status_dist[row["status"]] = row["c"]

    avg_scores = conn.execute(
        f"""SELECT
                AVG(CASE WHEN c.overall_score > 0 THEN c.overall_score END) AS avg_overall,
                AVG(CASE WHEN c.tech_score > 0 THEN c.tech_score END) AS avg_tech,
                AVG(CASE WHEN c.experience_score > 0 THEN c.experience_score END) AS avg_exp,
                AVG(CASE WHEN c.education_score > 0 THEN c.education_score END) AS avg_edu,
                AVG(CASE WHEN c.major_match_score > 0 THEN c.major_match_score END) AS avg_major,
                AVG(CASE WHEN c.culture_score > 0 THEN c.culture_score END) AS avg_culture
            FROM candidates c JOIN pipelines p ON p.id=c.pipeline_id
            WHERE p.tenant_id=%s{owner_clause}""",
        params,
    ).fetchone()

    return {
        "total_pipelines": total_pipelines,
        "completed_pipelines": completed,
        "completion_rate": round(completed / total_pipelines * 100, 1) if total_pipelines else 0,
        "total_candidates": talent_funnel["total_candidates"],
        "stages": talent_funnel["stages"],
        "candidate_flow": status_dist,
        "avg_scores": {
            "overall": round(avg_scores["avg_overall"] or 0, 1),
            "tech": round(avg_scores["avg_tech"] or 0, 1),
            "experience": round(avg_scores["avg_exp"] or 0, 1),
            "education": round(avg_scores["avg_edu"] or 0, 1),
            "major_match": round(avg_scores["avg_major"] or 0, 1),
            "culture": round(avg_scores["avg_culture"] or 0, 1),
        },
    }


def get_dashboard_extra(user_id: str, tenant_id: str = "tenant_default", include_all: bool = False) -> dict:
    """补充看板图表需要的额外数据：渠道分布、漏斗阶段、pipeline列表、周统计。

    所有统计都经由 pipelines 表限定可见范围：普通 HR 只统计自己创建的流水线，
    租户管理员（include_all=True）统计整个租户；范围条件与 get_funnel_data_for_user 一致。
    """
    conn = _db.get_db()
    scope = "" if include_all else " AND p.owner_user_id=%s"
    owner_params: tuple = () if include_all else (user_id,)
    base_params = (tenant_id,) + owner_params
    talent_funnel = _talent_pool_funnel_metrics(user_id, tenant_id, include_all)

    # 1. 渠道分布（从 candidates.source 统计）
    channel_rows = conn.execute(
        """SELECT COALESCE(c.source, 'unknown') as src, COUNT(*) as total,
           SUM(CASE WHEN c.status IN ('shortlisted','passed','interview','offered') THEN 1 ELSE 0 END) as passed
           FROM candidates c JOIN pipelines p ON p.id = c.pipeline_id
           WHERE p.tenant_id=%s"""
        + scope
        + " GROUP BY c.source",
        base_params,
    ).fetchall()
    channel_breakdown = {}
    for r in channel_rows:
        key = (r["src"] or "unknown").lower()
        if "boss" in key:
            mapped = "boss"
        elif "liepin" in key or "猎聘" in key:
            mapped = "liepin"
        elif "neitui" in key or "内推" in key:
            mapped = "neitui"
        else:
            mapped = "other"
        if mapped not in channel_breakdown:
            channel_breakdown[mapped] = {"total": 0, "passed": 0}
        channel_breakdown[mapped]["total"] += r["total"]
        channel_breakdown[mapped]["passed"] += r["passed"] or 0

    # 2. 人才库人员去重后的累计漏斗阶段。
    stages = talent_funnel["stages"]

    # 3. Pipeline列表（甘特图用）
    pipeline_rows = conn.execute(
        """SELECT p.id, p.role, p.status,
           (SELECT COUNT(*) FROM candidates c WHERE c.pipeline_id = p.id) as candidate_count,
           (SELECT COUNT(*) FROM pipeline_stages ps WHERE ps.pipeline_id = p.id AND ps.status = 'done') as done_stages,
           (SELECT COUNT(*) FROM pipeline_stages ps WHERE ps.pipeline_id = p.id) as total_stages
           FROM pipelines p WHERE p.tenant_id=%s"""
        + scope
        + """
           ORDER BY p.updated_at DESC LIMIT 20""",
        base_params,
    ).fetchall()
    pipelines = []
    for r in pipeline_rows:
        total = r["total_stages"] or 1
        progress = r["done_stages"] / total if total > 0 else 0
        pipelines.append(
            {
                "id": r["id"],
                "role": r["role"],
                "status": r["status"],
                "candidate_count": r["candidate_count"],
                "stage_progress": progress,
            }
        )

    # 4. 最近 7 天首次到达各漏斗阶段的去重人数。
    cumulative_trend = talent_funnel["daily_trend"]

    def recent_stage_count(stage: str) -> int:
        values = cumulative_trend.get(stage) or []
        if not values:
            return 0
        baseline = values[-8] if len(values) >= 8 else 0
        return max(0, int(values[-1]) - int(baseline))

    weekly_new = recent_stage_count("applied")
    weekly_interviews = recent_stage_count("interviewed")
    weekly_interview_passed = recent_stage_count("interview_passed")

    # 5. 分数分布
    score_rows = conn.execute(
        """SELECT
            SUM(CASE WHEN c.overall_score >= 90 THEN 1 ELSE 0 END) as s90,
            SUM(CASE WHEN c.overall_score >= 80 AND c.overall_score < 90 THEN 1 ELSE 0 END) as s80,
            SUM(CASE WHEN c.overall_score >= 70 AND c.overall_score < 80 THEN 1 ELSE 0 END) as s70,
            SUM(CASE WHEN c.overall_score >= 60 AND c.overall_score < 70 THEN 1 ELSE 0 END) as s60,
            SUM(CASE WHEN c.overall_score >= 50 AND c.overall_score < 60 THEN 1 ELSE 0 END) as s50,
            SUM(CASE WHEN c.overall_score > 0 AND c.overall_score < 50 THEN 1 ELSE 0 END) as s_low
        FROM candidates c JOIN pipelines p ON p.id = c.pipeline_id
        WHERE p.tenant_id=%s"""
        + scope,
        base_params,
    ).fetchone()
    score_distribution = {
        "90-100": score_rows["s90"] or 0,
        "80-89": score_rows["s80"] or 0,
        "70-79": score_rows["s70"] or 0,
        "60-69": score_rows["s60"] or 0,
        "50-59": score_rows["s50"] or 0,
        "<50": score_rows["s_low"] or 0,
    }

    # 6. 左侧趋势与右侧漏斗共用同一份去重、累计数据。
    daily_trend = cumulative_trend

    # 7. 平均招聘周期(天)
    cycle_expression = _average_hire_cycle_expression()
    avg_cycle_row = conn.execute(
        f"""SELECT AVG({cycle_expression}) as avg_days
           FROM pipelines p WHERE p.status = 'completed' AND p.tenant_id=%s"""
        + scope,
        base_params,
    ).fetchone()
    avg_hire_cycle = round(avg_cycle_row["avg_days"] or 0, 1)

    # 8. 面试中实时数
    live_interviews = conn.execute(
        """SELECT COUNT(*) as c FROM interview_sessions s
           JOIN pipelines p ON p.id = s.pipeline_id
           WHERE s.status IN ('in_progress', 'started') AND p.tenant_id=%s"""
        + scope,
        base_params,
    ).fetchone()["c"]

    return {
        "funnel_extra": {
            "total_candidates": talent_funnel["total_candidates"],
            "channel_breakdown": channel_breakdown,
            "stages": stages,
            "pipelines": pipelines,
            "score_distribution": score_distribution,
        },
        "summary_extra": {
            "weekly_new": weekly_new,
            "weekly_interviews": weekly_interviews,
            "weekly_interview_passed": weekly_interview_passed,
            "daily_trend": daily_trend,
            "avg_hire_cycle": avg_hire_cycle,
            "live_interviews": live_interviews,
        },
    }


def _average_hire_cycle_expression() -> str:
    """Return the MySQL day-difference expression."""
    return "TIMESTAMPDIFF(SECOND, created_at, updated_at) / 86400.0"


def get_activity_feed() -> list[dict]:
    """获取最近20条招聘动态事件"""
    conn = _db.get_db()
    events = []

    # 1. Candidate milestones use the event timestamp, not resume ingestion time.
    # Interview milestones are sourced from the session lifecycle because the
    # candidate row does not carry a reliable completion/evaluation timestamp.
    interview_event_times: dict[tuple[str, str], str] = {}
    interview_rows = conn.execute(
        """SELECT pipeline_id, candidate_id, evaluated_at, completed_at, created_at
           FROM interview_sessions
           WHERE status IN ('completed', 'evaluated')"""
    ).fetchall()
    for session in interview_rows:
        event_value = session["evaluated_at"] or session["completed_at"] or session["created_at"]
        event_time = _parse_db_ts(event_value)
        if event_time is None:
            continue
        key = (str(session["pipeline_id"]), str(session["candidate_id"]))
        previous = _parse_db_ts(interview_event_times.get(key))
        if previous is None or event_time > previous:
            interview_event_times[key] = event_time.strftime("%Y-%m-%d %H:%M:%S")

    candidate_rows = conn.execute(
        """SELECT c.id AS candidate_id, c.name, c.status, c.overall_score, c.created_at, c.offered_at,
                  c.screening_decision_at, p.role, p.id AS pipeline_id
           FROM candidates c JOIN pipelines p ON c.pipeline_id = p.id
           WHERE c.status IN ('offered', 'shortlisted', 'passed', 'rejected', 'interviewed')"""
    ).fetchall()

    for r in candidate_rows:
        status = r["status"]
        score = r["overall_score"] or 0
        name = r["name"]
        role = r["role"]
        event_at = r["offered_at"] if status == "offered" else r["screening_decision_at"]
        if status == "interviewed":
            event_at = interview_event_times.get((str(r["pipeline_id"]), str(r["candidate_id"])))
        event_at = _parse_db_ts(event_at or r["created_at"])
        event_at = event_at.strftime("%Y-%m-%d %H:%M:%S") if event_at else _db.now_db_string()
        if status == "offered":
            text, event_type = f"{name} Offer已发出", "complete"
        elif status in ("shortlisted", "passed"):
            text, event_type = f"{name} 通过AI筛选，综合评分{score}分", "progress"
        elif status == "rejected":
            text, event_type = f"{name} 未通过筛选", "progress"
        else:
            text, event_type = f"{name} 完成面试", "progress"
        events.append(
            {
                "type": event_type,
                "text": text,
                "tag": role,
                "pipeline_id": r["pipeline_id"],
                "created_at": event_at,
            }
        )

    # 2. 预警事件：候选人不足的岗位
    pipeline_rows = conn.execute(
        """SELECT p.id, p.role,
                  (SELECT COUNT(*) FROM candidates c WHERE c.pipeline_id = p.id) as cnt
           FROM pipelines p WHERE p.status = 'running'"""
    ).fetchall()
    for r in pipeline_rows:
        if r["cnt"] < 20:
            events.append(
                {
                    "type": "warning",
                    "text": f"\u201c{r['role']}\u201d岗位候选人不足，当前仅{r['cnt']}人，建议扩大渠道投放",
                    "tag": "预警",
                    "pipeline_id": r["id"],
                    "created_at": _db.now_db_string(),
                }
            )

    # 3. 转化率异常预警
    for r in pipeline_rows:
        total = r["cnt"]
        if total >= 10:
            passed = conn.execute(
                """SELECT COUNT(*) as c FROM candidates
                   WHERE pipeline_id = %s AND status IN ('shortlisted','passed','offered','interviewed')""",
                (r["id"],),
            ).fetchone()["c"]
            rate = passed / total * 100
            if rate < 15:
                events.append(
                    {
                        "type": "error",
                        "text": f"\u201c{r['role']}\u201d面试转化率低于均值({rate:.0f}% vs 18%)，建议优化JD描述",
                        "tag": "异常",
                        "pipeline_id": r["id"],
                        "created_at": _db.now_db_string(),
                    }
                )

    # 按事件发生时间倒序，取前20条。兼容历史 T 分隔时间。
    events.sort(
        key=lambda item: _parse_db_ts(item.get("created_at")) or datetime.min,
        reverse=True,
    )
    result = events[:20]

    # 计算相对时间
    now = datetime.now()
    for e in result:
        try:
            t = _parse_db_ts(e.get("created_at"))
            if t is None:
                raise ValueError("invalid activity timestamp")
            diff = (now - t).total_seconds()
            if diff < 60:
                e["time_ago"] = "刚刚"
            elif diff < 3600:
                e["time_ago"] = f"{int(diff / 60)}分钟前"
            elif diff < 86400:
                e["time_ago"] = f"{int(diff / 3600)}小时前"
            else:
                e["time_ago"] = f"{int(diff / 86400)}天前"
        except Exception:
            e["time_ago"] = ""

    return result
