"""RPA 任务持久化领域模块。

从 ``app/db/__init__.py`` 迁移的 RPA fetch 任务增删改查实现。函数体内的
数据库连接与跨函数调用统一通过 ``_db.`` 动态属性查找解析，保证测试对
``app.db.get_db`` 等入口的 monkeypatch 语义与单文件时期完全一致。
"""

from typing import Optional

from app import db as _db


def create_rpa_task(task: dict) -> dict:
    """Create an RPA fetch task."""
    conn = _db.get_db()
    conn.execute(
        """REPLACE INTO rpa_tasks (id, platform, keywords, target_count, status, pipeline_id, created_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
    """,
        (
            task["id"],
            task.get("platform", "liepin"),
            task.get("keywords", ""),
            task.get("target_count", 10),
            task.get("status", "pending"),
            task.get("pipeline_id", ""),
        ),
    )
    conn.commit()
    return _db.get_rpa_task(task["id"])


def get_rpa_task(task_id: str) -> Optional[dict]:
    """Get a single RPA task by ID."""
    conn = _db.get_db()
    row = conn.execute("SELECT * FROM rpa_tasks WHERE id = %s", (task_id,)).fetchone()
    return dict(row) if row else None


def list_rpa_tasks(status: str = "", pipeline_id: str = "", limit: int = 50) -> list[dict]:
    """List RPA tasks, optionally filtered by status or pipeline."""
    conn = _db.get_db()
    conditions = []
    params = []
    if status:
        conditions.append("status = %s")
        params.append(status)
    if pipeline_id:
        conditions.append("pipeline_id = %s")
        params.append(pipeline_id)
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    rows = conn.execute(
        f"SELECT * FROM rpa_tasks{where} ORDER BY created_at DESC LIMIT %s", params + [limit]
    ).fetchall()
    return [dict(r) for r in rows]


def update_rpa_task(task_id: str, updates: dict) -> Optional[dict]:
    """Update RPA task fields."""
    task = _db.get_rpa_task(task_id)
    if not task:
        return None
    allowed = {"status", "fetched_count", "error_message", "completed_at", "target_count"}
    sets = []
    params = []
    for k, v in updates.items():
        if k in allowed:
            sets.append(f"{k} = %s")
            params.append(v)
    if not sets:
        return task
    sets.append("updated_at = NOW()")
    params.append(task_id)
    conn = _db.get_db()
    conn.execute(f"UPDATE rpa_tasks SET {', '.join(sets)} WHERE id = %s", params)
    conn.commit()
    return _db.get_rpa_task(task_id)


def get_pending_rpa_tasks(platform: str = "") -> list[dict]:
    """Get pending RPA tasks for plugin polling.
    Returns tasks that are 'pending' or 'running' (under target count).
    """
    conn = _db.get_db()
    if platform:
        rows = conn.execute(
            "SELECT * FROM rpa_tasks WHERE status IN ('pending','running') AND platform = %s ORDER BY created_at ASC LIMIT 10",
            (platform,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM rpa_tasks WHERE status IN ('pending','running') ORDER BY created_at ASC LIMIT 10"
        ).fetchall()
    return [dict(r) for r in rows]


def increment_rpa_task_count(task_id: str) -> Optional[dict]:
    """Increment fetched_count for a task. Mark completed if target reached."""
    task = _db.get_rpa_task(task_id)
    if not task:
        return None
    new_count = (task.get("fetched_count", 0) or 0) + 1
    updates = {"fetched_count": new_count}
    if new_count >= (task.get("target_count", 10) or 10):
        updates["status"] = "completed"
        updates["completed_at"] = _db.now_db_string()
    else:
        updates["status"] = "running"
    return _db.update_rpa_task(task_id, updates)
