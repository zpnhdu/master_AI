"""候选人、消息、学习与记忆领域模块。

从 ``app/db/__init__.py`` 迁移的实现。公开函数之间的跨调用、连接获取
与 ``app.db`` 模块级常量通过 ``_db.`` 动态属性查找解析，保证测试对
``app.db.<name>`` 的 monkeypatch 语义与单文件时期完全一致。
"""

import json

from app import db as _db


# 候选人操作
def save_candidate(pipeline_id: str, candidate: dict, conn=None):
    conn_local = conn or _db.get_db()
    existing = conn_local.execute("SELECT offered_at FROM candidates WHERE id=%s", (candidate["id"],)).fetchone()
    offered_at = candidate.get("offered_at") or (existing["offered_at"] if existing else None)
    if candidate.get("status") == "offered" and not offered_at:
        offered_at = _db.now_db_string()
    conn_local.execute(
        """REPLACE INTO candidates
        (id, pipeline_id, name, source, years_experience, current_company, current_salary,
         skills, resume_text, tech_score, experience_score, education_score, major_match_score,
         culture_score, salary_risk, overall_score, reason, status, resume_id,
         phone, email, contact_status, education, major, ragflow_json,
         match_batch, shortlist_min, screening_decision, screening_decision_at, offered_at)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """,
        (
            candidate["id"],
            pipeline_id,
            candidate["name"],
            candidate.get("source", ""),
            candidate.get("years_experience", 0),
            candidate.get("current_company", ""),
            candidate.get("current_salary", ""),
            json.dumps(candidate.get("skills", []), ensure_ascii=False),
            candidate.get("resume_text", ""),
            candidate.get("tech_score", 0),
            candidate.get("experience_score", 0),
            candidate.get("education_score", 0),
            candidate.get("major_match_score", 0),
            candidate.get("culture_score", 0),
            candidate.get("salary_risk", 0),
            candidate.get("overall_score", 0),
            candidate.get("reason", ""),
            candidate.get("status", "new"),
            candidate.get("resume_id", ""),
            candidate.get("phone", ""),
            candidate.get("email", ""),
            candidate.get("contact_status", ""),
            candidate.get("education", ""),
            candidate.get("major", ""),
            candidate.get("ragflow_json", ""),
            candidate.get("match_batch", ""),
            candidate.get("shortlist_min"),
            candidate.get("screening_decision", ""),
            candidate.get("screening_decision_at", ""),
            offered_at,
        ),
    )
    if conn is None:
        conn_local.commit()


def save_simple_candidate(pipeline_id: str, name: str, phone: str, conn=None) -> str:
    """保存仅包含姓名和手机号的历史兼容候选人。"""
    import hashlib

    target_conn = conn or _db.get_db()
    candidate_id = f"c_{hashlib.md5(f'{pipeline_id}{name}{phone}'.encode()).hexdigest()[:8]}"
    resume_text = f"姓名：{name}\n手机号：{phone}"
    target_conn.execute(
        """REPLACE INTO candidates
        (id, pipeline_id, name, source, phone, resume_text,
         overall_score, status, created_at)
        VALUES (%s,%s,%s,%s,%s,%s,0,'new',NOW())
        """,
        (candidate_id, pipeline_id, name, "simple_import", phone, resume_text),
    )
    if conn is None:
        target_conn.commit()
    return candidate_id


def update_candidate(candidate_id: str, updates: dict, conn=None):
    conn_local = conn or _db.get_db()
    sets = []
    vals = []
    for k, v in updates.items():
        if k == "skills":
            sets.append(f"{k}=%s")
            vals.append(json.dumps(v, ensure_ascii=False))
        elif k == "video_assessment":
            sets.append(f"{k}=%s")
            vals.append(json.dumps(v, ensure_ascii=False))
        else:
            sets.append(f"{k}=%s")
            vals.append(v)
    if updates.get("status") == "offered" and "offered_at" not in updates:
        # Keep the first offer decision time when a report or webhook retries the update.
        sets.append("offered_at=COALESCE(NULLIF(offered_at, ''), %s)")
        vals.append(_db.now_db_string())
    if not sets:
        return
    vals.append(candidate_id)
    conn_local.execute(f"UPDATE candidates SET {','.join(sets)} WHERE id=%s", vals)
    if conn is None:
        conn_local.commit()


def get_candidates(pipeline_id: str) -> list[dict]:
    return _db._pipeline_query_call("get_candidates", pipeline_id)


# 消息操作
def save_message(
    pipeline_id: str,
    role: str,
    content: str,
    card_type: str = None,
    card_data: dict = None,
    stage_id: str = "",
    conn=None,
):
    conn_local = conn or _db.get_db()
    conn_local.execute(
        "INSERT INTO messages (pipeline_id, role, content, card_type, card_data, stage_id) VALUES (%s,%s,%s,%s,%s,%s)",
        (pipeline_id, role, content, card_type, json.dumps(card_data or {}, ensure_ascii=False), stage_id),
    )
    msg_id = conn_local.execute("SELECT LAST_INSERT_ID()").fetchone()[0]
    if conn is None:
        conn_local.commit()
    return msg_id


def get_messages(pipeline_id: str = None, limit: int = 100) -> list[dict]:
    return _db._pipeline_query_call("get_messages", pipeline_id, limit)


def count_messages_by_pipeline(pipeline_ids: list[str]) -> dict[str, int]:
    """Pipeline -> 消息条数，用单条 GROUP BY 聚合，避免看板逐 pipeline 查询（N+1）。"""
    if not pipeline_ids:
        return {}
    conn = _db.get_db()
    placeholders = ",".join("%s" for _ in pipeline_ids)
    rows = conn.execute(
        f"SELECT pipeline_id, COUNT(*) AS c FROM messages WHERE pipeline_id IN ({placeholders}) GROUP BY pipeline_id",
        pipeline_ids,
    ).fetchall()
    return {str(row["pipeline_id"]): int(row["c"] or 0) for row in rows}


# 学习数据操作
def save_learning(category: str, key: str, value: str, confidence: float = 0.5, pipeline_id: str = ""):
    conn = _db.get_db()
    existing = conn.execute(
        "SELECT id, usage_count FROM learnings WHERE category=%s AND `key`=%s AND pipeline_id=%s",
        (category, key, pipeline_id),
    ).fetchone()
    if existing:
        conn.execute(
            "UPDATE learnings SET value=%s, confidence=CASE WHEN confidence+0.1 > 1.0 THEN 1.0 ELSE confidence+0.1 END, usage_count=usage_count+1, updated_at=NOW() WHERE id=%s",
            (value, existing["id"]),
        )
    else:
        conn.execute(
            "INSERT INTO learnings (category, `key`, value, confidence, pipeline_id) VALUES (%s,%s,%s,%s,%s)",
            (category, key, value, confidence, pipeline_id),
        )
    conn.commit()


def get_learnings(category: str = None, pipeline_id: str = None) -> list[dict]:
    conn = _db.get_db()
    # 确保 pipeline_id 列存在（迁移）
    try:
        conn.execute("SELECT pipeline_id FROM learnings LIMIT 1")
    except:
        conn.execute("ALTER TABLE learnings ADD COLUMN pipeline_id VARCHAR(191) DEFAULT ''")
        conn.commit()

    conditions = []
    params = []
    if category:
        conditions.append("category=%s")
        params.append(category)
    if pipeline_id is not None:
        conditions.append("(pipeline_id=%s OR pipeline_id='')")
        params.append(pipeline_id)

    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    rows = conn.execute(f"SELECT * FROM learnings{where} ORDER BY confidence DESC, usage_count DESC", params).fetchall()
    return [dict(r) for r in rows]


# HR 偏好设置
def save_preference(key: str, value: str, learned_from: str = None):
    conn = _db.get_db()
    conn.execute(
        "REPLACE INTO hr_preferences (preference_key, preference_value, learned_from, updated_at) VALUES (%s,%s,%s,NOW())",
        (key, value, learned_from),
    )
    conn.commit()


def get_preferences() -> dict[str, str]:
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM hr_preferences").fetchall()
    return {r["preference_key"]: r["preference_value"] for r in rows}


# ============ 本体规则 ============
def save_ontology_rule(node_id: str, rule_id: str, rule_data: dict, pipeline_id: str = "", source: str = "hr_custom"):
    conn = _db.get_db()
    conn.execute(
        """REPLACE INTO ontology_rules (node_id, rule_id, rule_data, pipeline_id, source, updated_at)
           VALUES (%s,%s,%s,%s,%s,NOW())""",
        (node_id, rule_id, json.dumps(rule_data, ensure_ascii=False), pipeline_id, source),
    )
    conn.commit()


def get_ontology_rules(pipeline_id: str = "") -> list[dict]:
    conn = _db.get_db()
    if pipeline_id:
        rows = conn.execute(
            "SELECT * FROM ontology_rules WHERE pipeline_id=%s OR pipeline_id='' ORDER BY id", (pipeline_id,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM ontology_rules ORDER BY id").fetchall()
    return [dict(r) for r in rows]


# ============ 记忆规则（ARON 学习记忆库） ============
def save_memory_rule(
    memory_id: str,
    ontology_node_id: str,
    rule_type: str,
    content: dict,
    source: str,
    source_detail: str = "",
    confidence: float = 0.5,
    growth_stage: str = "short",
    pipeline_id: str = "",
    actor_user_id: str = "",
):
    conn = _db.get_db()
    try:
        conn.execute("SELECT actor_user_id FROM memory_rules LIMIT 1")
    except Exception:
        conn.execute("ALTER TABLE memory_rules ADD COLUMN actor_user_id VARCHAR(191) DEFAULT ''")
        conn.commit()
    existing = conn.execute("SELECT id, usage_count, confidence FROM memory_rules WHERE id=%s", (memory_id,)).fetchone()
    if existing:
        # 重复学习 → 提升置信度 + 使用次数
        new_conf = min(1.0, existing["confidence"] + 0.1)
        conn.execute(
            """UPDATE memory_rules SET content=%s, confidence=%s, usage_count=usage_count+1,
               growth_stage=%s, updated_at=NOW() WHERE id=%s""",
            (json.dumps(content, ensure_ascii=False), new_conf, growth_stage, memory_id),
        )
    else:
        conn.execute(
            """INSERT INTO memory_rules (id, ontology_node_id, rule_type, content, source, source_detail,
               confidence, growth_stage, pipeline_id, actor_user_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                memory_id,
                ontology_node_id,
                rule_type,
                json.dumps(content, ensure_ascii=False),
                source,
                source_detail,
                confidence,
                growth_stage,
                pipeline_id,
                actor_user_id,
            ),
        )
    conn.commit()


def get_memory_rules(
    pipeline_id: str = "", ontology_node_id: str = "", is_active: bool = None, growth_stage: str = "", actor_user_id: str = ""
) -> list[dict]:
    conn = _db.get_db()
    try:
        conn.execute("SELECT actor_user_id FROM memory_rules LIMIT 1")
    except Exception:
        conn.execute("ALTER TABLE memory_rules ADD COLUMN actor_user_id VARCHAR(191) DEFAULT ''")
        conn.commit()
    conditions = []
    params = []
    if pipeline_id:
        conditions.append("(pipeline_id=%s OR pipeline_id='')")
        params.append(pipeline_id)
    if ontology_node_id:
        conditions.append("ontology_node_id=%s")
        params.append(ontology_node_id)
    if is_active is not None:
        conditions.append("is_active=%s")
        params.append(1 if is_active else 0)
    if growth_stage:
        conditions.append("growth_stage=%s")
        params.append(growth_stage)
    if actor_user_id:
        conditions.append("actor_user_id=%s")
        params.append(actor_user_id)

    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    rows = conn.execute(
        f"SELECT * FROM memory_rules{where} ORDER BY confidence DESC, usage_count DESC", params
    ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d["content"] = json.loads(d["content"]) if isinstance(d["content"], str) else d["content"]
        result.append(d)
    return result


def toggle_memory_rule(memory_id: str, is_active: bool) -> bool:
    conn = _db.get_db()
    conn.execute(
        "UPDATE memory_rules SET is_active=%s, updated_at=NOW() WHERE id=%s", (1 if is_active else 0, memory_id)
    )
    conn.commit()
    return True


def reset_memory_rules(pipeline_id: str = "", scope: str = "pipeline") -> int:
    """重置学习规则。scope: pipeline(单岗位) / all(全库)"""
    conn = _db.get_db()
    if scope == "pipeline" and pipeline_id:
        cursor = conn.execute("DELETE FROM memory_rules WHERE pipeline_id=%s", (pipeline_id,))
    elif scope == "all":
        cursor = conn.execute("DELETE FROM memory_rules")
    else:
        return 0
    count = cursor.rowcount
    conn.commit()
    return count


def get_memory_stats(pipeline_id: str = "") -> dict:
    """获取记忆库统计"""
    conn = _db.get_db()
    pid_filter = "WHERE (pipeline_id=%s OR pipeline_id='')" if pipeline_id else ""
    params = (pipeline_id,) if pipeline_id else ()

    total = conn.execute(f"SELECT COUNT(*) as c FROM memory_rules {pid_filter}", params).fetchone()["c"]
    active = conn.execute(
        f"SELECT COUNT(*) as c FROM memory_rules {pid_filter} {'AND' if pid_filter else 'WHERE'} is_active=1", params
    ).fetchone()["c"]

    stages = {}
    for stage in ["short", "mid", "long"]:
        c = conn.execute(
            f"SELECT COUNT(*) as c FROM memory_rules {pid_filter} {'AND' if pid_filter else 'WHERE'} growth_stage=%s",
            (*params, stage),
        ).fetchone()["c"]
        stages[stage] = c

    return {
        "total": total,
        "active": active,
        "inactive": total - active,
        "by_stage": stages,
    }
