"""人才库、简历库与触达事件领域模块。

从 ``app/db/__init__.py`` 迁移的实现。连接获取与跨函数调用通过
``_db.`` 动态属性查找解析，保证测试对 ``app.db.<name>`` 的
monkeypatch 语义与单文件时期完全一致。
"""

import json
import re
from typing import Optional

from app import db as _db

# ============ 人才库操作 ============


def add_to_talent_pool(candidate: dict) -> str:
    """将候选人加入人才库（跨pipeline持久化）"""
    pool_id = candidate.get("talent_pool_id") or candidate.get("id", "")
    conn = _db.get_db()
    try:
        conn.execute(
            """REPLACE INTO talent_pool
            (id, name, skills, years_experience, current_company, current_salary,
             education, major, best_score, best_role, source_pipeline, outcome,
             tags, notes, resume_text, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """,
            (
                pool_id,
                candidate.get("name", ""),
                json.dumps(candidate.get("skills", []), ensure_ascii=False),
                candidate.get("years_experience", 0),
                candidate.get("current_company", ""),
                candidate.get("current_salary", ""),
                candidate.get("education", ""),
                candidate.get("major", ""),
                candidate.get("overall_score", 0),
                candidate.get("best_role", ""),
                candidate.get("pipeline_id", ""),
                candidate.get("outcome", "pooled"),
                json.dumps(candidate.get("tags", []), ensure_ascii=False),
                candidate.get("notes", ""),
                candidate.get("resume_text", ""),
            ),
        )
        conn.commit()
    finally:
        return pool_id


def search_talent_pool(query: str = "", skills: list[str] = None, min_score: int = 0, limit: int = 20) -> list[dict]:
    """搜索人才库"""
    conn = _db.get_db()
    sql = "SELECT * FROM talent_pool WHERE best_score >= %s"
    params: list = [min_score]

    if query:
        sql += " AND (name LIKE %s OR current_company LIKE %s OR resume_text LIKE %s)"
        q = f"%{query}%"
        params.extend([q, q, q])

    if skills:
        for skill in skills:
            sql += " AND skills LIKE %s"
            params.append(f"%{skill}%")

    sql += " ORDER BY best_score DESC, updated_at DESC LIMIT %s"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    results = []
    for row in rows:
        d = dict(row)
        d["skills"] = json.loads(d.get("skills") or "[]")
        d["tags"] = json.loads(d.get("tags") or "[]")
        results.append(d)
    return results


def get_talent_pool_stats() -> dict:
    """人才库统计"""
    conn = _db.get_db()
    total = conn.execute("SELECT COUNT(*) as c FROM talent_pool").fetchone()["c"]
    outcomes = {}
    for row in conn.execute("SELECT outcome, COUNT(*) as c FROM talent_pool GROUP BY outcome").fetchall():
        outcomes[row["outcome"]] = row["c"]
    avg_score = (
        conn.execute("SELECT AVG(best_score) as avg FROM talent_pool WHERE best_score > 0").fetchone()["avg"] or 0
    )
    top_skills_raw = conn.execute("SELECT skills FROM talent_pool WHERE skills != '[]' LIMIT 100").fetchall()

    skill_counts: dict[str, int] = {}
    for row in top_skills_raw:
        try:
            for s in json.loads(row["skills"]):
                skill_counts[s] = skill_counts.get(s, 0) + 1
        except (json.JSONDecodeError, TypeError):
            pass
    top_skills = sorted(skill_counts.items(), key=lambda x: -x[1])[:10]

    return {
        "total": total,
        "by_outcome": outcomes,
        "avg_score": round(avg_score, 1),
        "top_skills": [{"skill": s, "count": c} for s, c in top_skills],
    }


def rediscover_talents(role: str, skills: list[str] = None, min_score: int = 60, limit: int = 10) -> list[dict]:
    """为新岗位从人才库中发现匹配候选人"""
    conn = _db.get_db()
    sql = "SELECT * FROM talent_pool WHERE best_score >= %s"
    params: list = [min_score]

    if skills:
        for skill in skills:
            sql += " AND skills LIKE %s"
            params.append(f"%{skill}%")

    sql += " ORDER BY best_score DESC LIMIT %s"
    params.append(limit)

    rows = conn.execute(sql, params).fetchall()
    results = []
    for row in rows:
        d = dict(row)
        d["skills"] = json.loads(d.get("skills", "[]"))
        d["tags"] = json.loads(d.get("tags", "[]"))
        d["rediscovered_for"] = role
        results.append(d)
    return results


# ============ 简历库操作 ============


def save_resume_db(resume: dict) -> str:
    """Insert or update a resume in the global pool. Returns resume id."""
    conn = _db.get_db()
    resume_id = resume.get("id", "")
    conn.execute(
        """REPLACE INTO resumes
        (id, fingerprint, fingerprint_confidence, name, source, source_channel,
         years_experience, current_company, current_salary, skills, resume_text,
         education, location, title, tags, email, phone, contact_status,
         linked_resume_id, tenant_id, ragflow_json, owner_user_id, source_type,
         source_account_id, source_message_id, source_attachment_id, candidate_email,
         sender_email, content_sha256, storage_backend, storage_key, original_filename, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
    """,
        (
            resume_id,
            resume.get("fingerprint", ""),
            resume.get("fingerprint_confidence", "high"),
            resume.get("name", ""),
            resume.get("source", ""),
            resume.get("source_channel", ""),
            resume.get("years_experience", 0),
            resume.get("current_company", ""),
            resume.get("current_salary", ""),
            json.dumps(resume.get("skills", []), ensure_ascii=False),
            resume.get("resume_text", ""),
            resume.get("education", ""),
            resume.get("location", ""),
            resume.get("title", ""),
            json.dumps(resume.get("tags", []), ensure_ascii=False),
            resume.get("email", ""),
            resume.get("phone", ""),
            resume.get("contact_status", ""),
            resume.get("linked_resume_id"),
            resume.get("tenant_id", ""),
            resume.get("ragflow_json", ""),
            resume.get("owner_user_id", ""),
            resume.get("source_type", ""),
            resume.get("source_account_id", ""),
            resume.get("source_message_id", ""),
            resume.get("source_attachment_id", ""),
            resume.get("candidate_email", resume.get("email", "")),
            resume.get("sender_email", ""),
            resume.get("content_sha256", ""),
            resume.get("storage_backend", ""),
            resume.get("storage_key", ""),
            resume.get("original_filename", ""),
        ),
    )
    conn.execute("UPDATE resumes SET gender=%s WHERE id=%s", (resume.get("gender", ""), resume_id))
    conn.commit()
    return resume_id


def update_resume_linked(resume_id: str, linked_id: str) -> bool:
    """Set the linked_resume_id for suspect-same-person detection."""
    conn = _db.get_db()
    conn.execute("UPDATE resumes SET linked_resume_id = %s, updated_at = NOW() WHERE id = %s", (linked_id, resume_id))
    conn.commit()
    return True


def get_resume_by_fingerprint(fingerprint: str, tenant_id: str = "tenant_default") -> Optional[dict]:
    """Find a resume by its fingerprint (for dedup check)."""
    conn = _db.get_db()
    row = conn.execute(
        "SELECT * FROM resumes WHERE fingerprint = %s AND tenant_id = %s AND fingerprint_confidence = 'high'",
        (fingerprint, tenant_id),
    ).fetchone()
    if row:
        d = dict(row)
        d["skills"] = json.loads(d.get("skills", "[]"))
        d["tags"] = json.loads(d.get("tags", "[]"))
        return d
    return None


def get_resume_by_id(resume_id: str, tenant_id: str = "") -> Optional[dict]:
    """Get a single resume by ID."""
    conn = _db.get_db()
    sql = "SELECT * FROM resumes WHERE id = %s"
    params = [resume_id]
    if tenant_id:
        sql += " AND tenant_id=%s"
        params.append(tenant_id)
    row = conn.execute(sql, params).fetchone()
    if row:
        d = dict(row)
        d["skills"] = json.loads(d.get("skills", "[]"))
        d["tags"] = json.loads(d.get("tags", "[]"))
        return d
    return None


def get_candidate_email(candidate_name: str, pipeline_id: str = "", candidate_id: str = "") -> Optional[str]:
    """Look up a candidate's email using stable identifiers before a name fallback.

    Checks the candidates table for resume_id, then queries resumes.email.
    Falls back to name-based search in resumes.
    """
    conn = _db.get_db()
    # Candidate cards carry a stable candidate_id. Resolve the linked resume
    # first so display-name formatting cannot break email delivery.
    if candidate_id:
        row = conn.execute(
            "SELECT COALESCE(NULLIF(r.email, ''), r.candidate_email) AS email FROM candidates c JOIN resumes r ON c.resume_id = r.id WHERE c.id = %s AND (c.pipeline_id = %s OR %s = '') LIMIT 1",
            (candidate_id, pipeline_id, pipeline_id),
        ).fetchone()
        if row and row[0]:
            return row[0]
        # A rebuilt pipeline can remove its candidates row while a previously
        # generated session remains.  Some session rows retain the resume id
        # directly as candidate_id, so try that durable relation next.
        row = conn.execute(
            "SELECT COALESCE(NULLIF(email, ''), candidate_email) AS email FROM resumes WHERE id = %s LIMIT 1",
            (candidate_id,),
        ).fetchone()
        if row and row[0]:
            return row[0]
        if candidate_id.startswith("c_") and "_p_" in candidate_id:
            resume_id = candidate_id[2:].rsplit("_p_", 1)[0]
            row = conn.execute(
                "SELECT COALESCE(NULLIF(email, ''), candidate_email) AS email FROM resumes WHERE id = %s LIMIT 1",
                (resume_id,),
            ).fetchone()
            if row and row[0]:
                return row[0]
    # Session names may contain Markdown markers from the generated interview
    # package; normalize them before applying the original name fallback.
    normalized_name = re.sub(r"^[\s*_#·>`~\-]+|[\s*_#·>`~\-]+$", "", str(candidate_name or "")).strip()
    if normalized_name and normalized_name != candidate_name:
        row = conn.execute(
            "SELECT COALESCE(NULLIF(email, ''), candidate_email) AS email FROM resumes WHERE name = %s AND (email != '' OR candidate_email != '') LIMIT 1",
            (normalized_name,),
        ).fetchone()
        if row and row[0]:
            return row[0]
    # 优先通过 candidates.resume_id 查询
    row = conn.execute(
        "SELECT COALESCE(NULLIF(r.email, ''), r.candidate_email) AS email FROM resumes r JOIN candidates c ON c.resume_id = r.id WHERE c.name = %s AND (c.pipeline_id = %s OR %s = '')",
        (candidate_name, pipeline_id, pipeline_id),
    ).fetchone()
    if row and row[0]:
        return row[0]
    # 降级处理：在 resumes 中按姓名搜索
    row = conn.execute(
        "SELECT COALESCE(NULLIF(email, ''), candidate_email) AS email FROM resumes WHERE name = %s AND (email != '' OR candidate_email != '') LIMIT 1",
        (candidate_name,),
    ).fetchone()
    if row and row[0]:
        return row[0]
    return None


def search_resumes_db(
    query: str = "",
    skills: list[str] = None,
    location: str = "",
    min_years: int = 0,
    limit: int = 20,
    tenant_id: str = "",
    offset: int = 0,
    sort_by: str = "",
    sort_order: str = "desc",
) -> list[dict]:
    """Search resumes with multi-dimensional filters."""
    conn = _db.get_db()
    sql = "SELECT * FROM resumes WHERE 1=1"
    params: list = []

    if tenant_id:
        sql += " AND tenant_id = %s"
        params.append(tenant_id)

    if query:
        q = f"%{query}%"
        sql += " AND (name LIKE %s OR title LIKE %s OR current_company LIKE %s OR skills LIKE %s OR location LIKE %s)"
        params.extend([q, q, q, q, q])

    if skills:
        for skill in skills:
            sql += " AND skills LIKE %s"
            params.append(f"%{skill}%")

    if location:
        sql += " AND location LIKE %s"
        params.append(f"%{location}%")

    if min_years > 0:
        sql += " AND years_experience >= %s"
        params.append(min_years)

    # 只允许映射后的列名进入 SQL，避免把客户端输入当作表达式执行。
    sort_columns = {
        "name": "name",
        "title": "title",
        "current_company": "current_company",
        "years_experience": "years_experience",
        "location": "location",
        "created_at": "created_at",
        "updated_at": "updated_at",
    }
    sort_column = sort_columns.get(sort_by)
    direction = "ASC" if sort_order.lower() == "asc" else "DESC"
    if sort_column:
        sql += f" ORDER BY {sort_column} {direction}, id {direction} LIMIT %s OFFSET %s"
    elif skills:
        # 按技能匹配时以经验排序（相关性代理），否则按更新时间。
        sql += " ORDER BY years_experience DESC, id DESC LIMIT %s OFFSET %s"
    else:
        sql += " ORDER BY updated_at DESC, id DESC LIMIT %s OFFSET %s"
    params.extend([limit, offset])

    rows = conn.execute(sql, params).fetchall()
    results = []
    for row in rows:
        d = dict(row)
        d["skills"] = json.loads(d.get("skills") or "[]")
        d["tags"] = json.loads(d.get("tags") or "[]")
        results.append(d)
    return results


def delete_resume_db(resume_id: str, tenant_id: str = "") -> bool:
    """Permanently delete a resume and detach mailbox provenance.

    Mail messages are intentionally retained for sync-history/audit purposes.  Their
    attachment rows are marked ``deleted_resume`` so a later mailbox sync can restore
    a resume that a user removed from the talent pool, without treating the stale
    attachment as a duplicate.
    """
    conn = _db.get_db()
    resume_filter = "resume_id = %s"
    params: list = [resume_id]
    if tenant_id:
        resume_filter += " AND tenant_id = %s"
        params.append(tenant_id)

    # Remove provenance rows first; UNIQUE(attachment_id) otherwise leaves stale
    # sources pointing at a row that no longer exists.
    conn.execute(
        f"DELETE FROM resume_sources WHERE {resume_filter}",
        params,
    )
    # Keep attachment/message history, but make the attachment eligible for recovery.
    conn.execute(
        f"""UPDATE email_sync_attachments
               SET status='deleted_resume', resume_id='', duplicate_resume_id='',
                   processed_at=NOW()
             WHERE ({"resume_id = %s OR duplicate_resume_id = %s"})
               {("AND tenant_id = %s" if tenant_id else "")}""",
        ([resume_id, resume_id, tenant_id] if tenant_id else [resume_id, resume_id]),
    )
    if tenant_id:
        conn.execute("DELETE FROM resumes WHERE id = %s AND tenant_id=%s", (resume_id, tenant_id))
    else:
        conn.execute("DELETE FROM resumes WHERE id = %s", (resume_id,))
    conn.commit()
    return True


def get_resume_count(
    tenant_id: str = "",
    query: str = "",
    skills: list[str] = None,
    location: str = "",
    min_years: int = 0,
) -> int:
    """Get the active resume count for the same filters as the search query."""
    conn = _db.get_db()
    conditions: list[str] = []
    params: list = []
    if tenant_id:
        conditions.append("tenant_id = %s")
        params.append(tenant_id)
    if query:
        wildcard = f"%{query}%"
        conditions.append(
            "(name LIKE %s OR title LIKE %s OR current_company LIKE %s OR skills LIKE %s OR location LIKE %s)"
        )
        params.extend([wildcard] * 5)
    for skill in skills or []:
        conditions.append("skills LIKE %s")
        params.append(f"%{skill}%")
    if location:
        conditions.append("location LIKE %s")
        params.append(f"%{location}%")
    if min_years > 0:
        conditions.append("years_experience >= %s")
        params.append(min_years)
    where = " AND ".join(conditions)
    sql = f"SELECT COUNT(*) as c FROM resumes WHERE {where}" if where else "SELECT COUNT(*) as c FROM resumes"
    return conn.execute(sql, params).fetchone()["c"]


# ============ 触达事件操作 ============


def save_outreach_event(
    pipeline_id: str,
    candidate_id: str,
    candidate_name: str,
    event_type: str,
    content: str = "",
    channel: str = "feishu",
) -> int:
    """记录触达事件"""
    conn = _db.get_db()
    conn.execute(
        """
        INSERT INTO outreach_events
        (pipeline_id, candidate_id, candidate_name, channel, event_type, content)
        VALUES (%s, %s, %s, %s, %s, %s)
    """,
        (pipeline_id, candidate_id, candidate_name, channel, event_type, content),
    )
    conn.commit()
    return conn.execute("SELECT LAST_INSERT_ID()").fetchone()[0]
