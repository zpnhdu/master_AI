"""公司配置、Agent 配置、调用日志与沟通模板领域模块。

从 ``app/db/__init__.py`` 迁移的实现。公开函数之间的跨调用通过 ``_db.``
动态属性查找解析，保证测试对 ``app.db.<name>`` 的 monkeypatch 语义与
单文件时期完全一致；GUOQUAN 常量等模块级状态也经 facade 读取。
"""

import json

from app import db as _db


def get_company_config() -> dict:
    """获取公司配置，默认返回锅圈食汇配置"""
    conn = _db.get_db()
    row = conn.execute("SELECT * FROM company_config WHERE id = 1").fetchone()
    if row:
        d = dict(row)
        benefits = d.get("default_benefits", "[]")
        if isinstance(benefits, str):
            try:
                d["default_benefits"] = json.loads(benefits)
            except (json.JSONDecodeError, TypeError):
                d["default_benefits"] = []
        return _with_company_asset_urls(d)
        # 降级处理：返回默认内存配置
    return _with_company_asset_urls(
        {
            "company_name": "锅圈食汇",
            "company_short": "锅圈食汇",
            "company_en": "GUOQUAN",
            "company_logo": "/brand/guoquan-logo.svg",
            "industry": "餐饮/食材零售",
            "company_size": "10000+门店",
            "company_website": "https://www.guoquanshihui.com",
            "company_address": "郑州市金水区",
            "default_benefits": ["五险一金", "带薪年假", "员工折扣", "节日福利", "年终奖", "门店就近分配"],
            "company_intro": (
                "锅圈食汇创立于2017年，总部位于郑州，是中国领先的火锅烧烤食材连锁零售品牌。"
                "主营火锅底料、牛羊肉品、丸滑制品、蔬菜净菜等全品类食材，SKU超800个。"
                "全国门店超10000家，覆盖300+城市，年营收超百亿。"
                "业务模式：社区门店零售 + 加盟连锁 + 线上外卖。"
                "核心岗位类型：门店导购、店长、区域督导、仓储物流、总部运营。"
            ),
            "brand_color": _db.GUOQUAN_DEFAULT_BRAND_COLOR,
            "brand_color_secondary": "#FF6B00",
            "poster_template": "guoquan_red",
            "poster_bg_image": "/brand/guoquan-poster-bg.svg",
        }
    )


def _with_company_asset_urls(config: dict) -> dict:
    """Resolve configured OSS keys to short-lived URLs without persisting them."""
    try:
        from app.brand_assets import brand_asset_url, is_thumbnailable_brand_asset
        from app.media_storage import get_media_storage

        storage = None

        for field, key_field in (
            ("company_logo", "company_logo_storage_key"),
            ("poster_bg_image", "poster_bg_image_storage_key"),
        ):
            thumbnail_field = f"{field}_thumb"
            storage_key = config.get(key_field) or ""
            if storage_key:
                storage = storage or get_media_storage()
                config[field] = brand_asset_url(
                    storage_key.rsplit("/", 1)[-1],
                    storage=storage,
                    storage_key=storage_key,
                    fallback_url=config.get(field) or "",
                )
                if is_thumbnailable_brand_asset(storage_key):
                    config[thumbnail_field] = brand_asset_url(
                        storage_key.rsplit("/", 1)[-1],
                        storage=storage,
                        storage_key=storage_key,
                        fallback_url=config.get(field) or "",
                        thumbnail=True,
                    )
            else:
                configured_url = config.get(field) or ""
                if configured_url.startswith(("/static/brand/", "/brand/")):
                    storage = storage or get_media_storage()
                    filename = configured_url.rsplit("/", 1)[-1]
                    config[field] = brand_asset_url(
                        filename,
                        storage=storage,
                        fallback_url=f"/brand/{filename}",
                    )
                    if is_thumbnailable_brand_asset(filename):
                        config[thumbnail_field] = brand_asset_url(
                            filename,
                            storage=storage,
                            fallback_url=config[field],
                            thumbnail=True,
                        )
    except Exception:
        # 配置读取不能因为 OSS 暂时不可用而阻断主业务。
        pass
    return config


def update_company_config(data: dict) -> dict:
    """更新公司配置，返回更新后的配置"""
    conn = _db.get_db()
    allowed_fields = [
        "company_name",
        "company_short",
        "company_en",
        "company_logo",
        "company_logo_storage_key",
        "industry",
        "company_size",
        "company_website",
        "company_address",
        "default_benefits",
        "company_intro",
        "brand_color",
        "brand_color_secondary",
        "poster_template",
        "poster_bg_image",
        "poster_bg_image_storage_key",
    ]
    sets = []
    vals = []
    for key in allowed_fields:
        if key in data:
            val = data[key]
            if key == "default_benefits" and isinstance(val, list):
                val = json.dumps(val, ensure_ascii=False)
            sets.append(f"{key} = %s")
            vals.append(val)
    if not sets:
        return _db.get_company_config()
    sets.append("updated_at = NOW()")
    conn.execute(f"UPDATE company_config SET {', '.join(sets)} WHERE id = 1", vals)
    conn.commit()
    return _db.get_company_config()


def log_agent_call(
    pipeline_id: str,
    stage_id: str,
    agent_id: str,
    status: str,
    duration_ms: int = 0,
    tokens_used: int = 0,
    error: str = None,
):
    """Record an agent invocation for the dispatch panel call log."""
    conn = _db.get_db()
    conn.execute(
        "INSERT INTO agent_call_logs (pipeline_id, stage_id, agent_id, status, duration_ms, tokens_used, error) VALUES (%s, %s, %s, %s, %s, %s, %s)",
        (pipeline_id, stage_id, agent_id, status, duration_ms, tokens_used, error),
    )
    conn.commit()


def get_agent_stats() -> list:
    """Return per-agent runtime stats: success rate, avg duration, recent calls."""
    conn = _db.get_db()
    rows = conn.execute("""
        SELECT agent_id,
               COUNT(*) as total_calls,
               SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_count,
               AVG(duration_ms) as avg_duration_ms,
               AVG(tokens_used) as avg_tokens
        FROM agent_call_logs
        GROUP BY agent_id
        ORDER BY agent_id
    """).fetchall()
    return [dict(r) for r in rows]


def get_recent_calls(limit: int = 20) -> list:
    """Return recent agent call logs for the dispatch panel."""
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM agent_call_logs ORDER BY created_at DESC LIMIT %s", (limit,)).fetchall()
    return [dict(r) for r in rows]


# Agent 配置操作
def get_agent_configs() -> list:
    """Return all agent configs as dicts"""
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM agent_configs ORDER BY agent_id").fetchall()
    return [dict(r) for r in rows]


def get_agent_config(agent_id: str) -> dict:
    """Return a single agent config"""
    conn = _db.get_db()
    candidate_ids = [agent_id]
    if agent_id == "jd_writer":
        candidate_ids.append("jd_write")
    elif agent_id == "jd_write":
        candidate_ids.append("jd_writer")
    for candidate_id in candidate_ids:
        row = conn.execute("SELECT * FROM agent_configs WHERE agent_id = %s", (candidate_id,)).fetchone()
        if row:
            return dict(row)
    return None


def upsert_agent_config(
    agent_id: str,
    agent_name: str,
    display_name: str,
    model: str = None,
    complexity: str = None,
    temperature: float = None,
    timeout: int = None,
    retry_count: int = None,
    enabled: bool = None,
    human_approval: bool = None,
):
    """Insert or update agent configuration"""
    conn = _db.get_db()
    existing = _db.get_agent_config(agent_id)
    if existing:
        updates = []
        params = []
        for field in ["model", "complexity", "temperature", "timeout", "retry_count", "enabled", "human_approval"]:
            val = locals().get(field)
            if val is not None:
                updates.append(f"{field} = %s")
                params.append(val if not isinstance(val, bool) else (1 if val else 0))
        if updates:
            params.append(agent_id)
            conn.execute(
                f"UPDATE agent_configs SET {', '.join(updates)}, updated_at = NOW() WHERE agent_id = %s",
                params,
            )
    else:
        conn.execute(
            "INSERT INTO agent_configs (agent_id, agent_name, display_name, model, complexity, temperature, timeout, retry_count, enabled, human_approval) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (
                agent_id,
                agent_name,
                display_name,
                model or "qwen3.6-flash",
                complexity or "plus",
                temperature if temperature is not None else 0.7,
                timeout or 120,
                retry_count or 2,
                1 if enabled is None or enabled else 0,
                1 if human_approval else 0,
            ),
        )
    conn.commit()


def list_communication_templates() -> list[dict]:
    """List all communication templates"""
    conn = _db.get_db()
    rows = conn.execute("SELECT * FROM communication_templates ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]
