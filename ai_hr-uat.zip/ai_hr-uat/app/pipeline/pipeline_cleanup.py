"""删除流水线时同步清理关联的存储对象(小海海报、小面面试视频)。

清理是删除事务提交后的收尾动作,原则是尽力而为:任何失败只记录日志,
绝不影响 delete_pipeline 的返回结果。

清理范围:
- media_assets 行记录的海报图片(按各自 storage_backend 精确删除);
- 面试视频前缀(video/interviews、video/uploads、video/tts、interview);
- 直播录制与截图前缀(video/live、video/snapshots),仅限删除后不再被任何
  面试会话引用的流名 —— 流名按候选人命名,可能被多条流水线共用;
- 本地遗留的 UPLOAD_DIR/<pipeline_id> 目录。

不清理:简历文件(resume/*)—— 人才库 resumes 表存有 storage_key 引用,
删除文件会让人才库记录悬空,需先做引用检查,另行处理。
"""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

from app.config import UPLOAD_DIR
from app.infrastructure.config import settings
from app.media_storage import get_media_storage, join_storage_key

logger = logging.getLogger(__name__)

# 与 upload 侧保持一致的前缀子目录(pipeline 维度)
_VIDEO_PIPELINE_SUBDIRS = ("interviews", "uploads", "tts")


def _delete_keys_safe(storage, keys: list[str], label: str) -> int:
    """逐个删除对象,单键失败仅告警并继续。返回成功删除数量。"""
    deleted = 0
    for key in keys:
        try:
            if storage.delete(key):
                deleted += 1
        except Exception as exc:  # noqa: BLE001 - 收尾任务必须吞掉所有异常
            logger.warning("pipeline cleanup: delete %s key=%s failed: %s", label, key, exc)
    return deleted


def cleanup_pipeline_storage(
    pipeline_id: str,
    media_assets: list[tuple[str, str]],
    stream_names: list[str],
) -> dict:
    """清理流水线关联的存储对象,永不抛异常。media_assets 为 (backend, key) 列表。"""
    stats = {"deleted": 0}

    # 1) 海报等媒体资产:按行记录的 backend 精确删除
    by_backend: dict[str, list[str]] = {}
    for backend, key in media_assets:
        if not key:
            continue
        by_backend.setdefault((backend or "").strip().lower(), []).append(key)
    for backend, keys in by_backend.items():
        try:
            storage = get_media_storage(backend) if backend else get_media_storage()
        except Exception as exc:  # noqa: BLE001
            logger.warning("pipeline cleanup: storage backend=%s unavailable: %s", backend, exc)
            continue
        stats["deleted"] += _delete_keys_safe(storage, keys, f"media({backend or 'default'})")

    # 2) 面试视频前缀(pipeline 维度),走默认存储后端
    default_storage = None
    try:
        default_storage = get_media_storage()
    except Exception as exc:  # noqa: BLE001
        logger.warning("pipeline cleanup: default storage unavailable: %s", exc)
    if default_storage is not None:
        prefixes = [join_storage_key(settings.oss_video_prefix, sub, pipeline_id) for sub in _VIDEO_PIPELINE_SUBDIRS]
        prefixes.append(join_storage_key(settings.oss_interview_prefix, pipeline_id))
        for prefix in prefixes:
            try:
                keys = default_storage.list_keys(prefix)
            except Exception as exc:  # noqa: BLE001
                logger.warning("pipeline cleanup: list prefix=%s failed: %s", prefix, exc)
                continue
            stats["deleted"] += _delete_keys_safe(default_storage, keys, f"prefix:{prefix}")

    # 3) 直播录制与截图:录制固定落 OSS,仅清理独占流名
    if stream_names:
        live_storage = None
        try:
            live_storage = get_media_storage("oss")
        except Exception as exc:  # noqa: BLE001
            logger.warning("pipeline cleanup: OSS unavailable, skip live recording cleanup: %s", exc)
        if live_storage is not None:
            for stream in dict.fromkeys(stream_names):
                for sub in ("live", "snapshots"):
                    prefix = join_storage_key(settings.oss_video_prefix, sub, stream)
                    try:
                        keys = live_storage.list_keys(prefix)
                    except Exception as exc:  # noqa: BLE001
                        logger.warning("pipeline cleanup: list prefix=%s failed: %s", prefix, exc)
                        continue
                    stats["deleted"] += _delete_keys_safe(live_storage, keys, f"stream:{sub}")

    # 4) 本地上传目录里的遗留文件
    local_dir = Path(UPLOAD_DIR) / pipeline_id
    try:
        if local_dir.exists():
            shutil.rmtree(local_dir, ignore_errors=True)
    except Exception as exc:  # noqa: BLE001
        logger.warning("pipeline cleanup: remove local dir=%s failed: %s", local_dir, exc)

    logger.info("pipeline cleanup done pipeline=%s deleted=%s", pipeline_id, stats["deleted"])
    return stats
