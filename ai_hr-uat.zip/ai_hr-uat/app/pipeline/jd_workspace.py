"""JD 草稿、确认和质量检查的单一状态入口。"""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from typing import Optional

from app.db import get_messages, get_pipeline, get_stages, transaction, update_stage
from app.utils import parse_stage_output

WORKFLOW_GROUPS = [
    (
        "岗位准备",
        [
            ("jd_write", "JD撰写", "editor", ""),
            ("profile_build", "候选人画像", "profile", ""),
            ("poster_gen", "招聘海报", "", "xiao_hai"),
        ],
    ),
    (
        "人才获取",
        [
            ("crawl", "简历获取", "", "xiao_xun"),
            ("match", "简历筛查", "", "xiao_shai"),
        ],
    ),
    (
        "招聘决策",
        [
            ("interview_gen", "面试出题", "", "xiao_mian"),
            ("video_assess", "视频评估", "", "xiao_mian"),
            ("report", "录用报告", "", "xiao_ping"),
        ],
    ),
]

JD_STAGE_DEPENDENCIES = {
    "title": {"profile_build", "poster_gen", "match", "interview_gen", "video_assess", "report"},
    "department": {"poster_gen"},
    "location": {"profile_build", "poster_gen", "match"},
    "salary_range": {"profile_build", "poster_gen", "match", "report"},
    "work_hours": {"profile_build", "poster_gen"},
    "responsibilities": {"profile_build", "match", "interview_gen", "report"},
    "requirements": {"profile_build", "match", "interview_gen", "video_assess", "report"},
    "tech_stack": {"profile_build", "match", "interview_gen"},
    "benefits": {"poster_gen"},
    "team_intro": {"poster_gen"},
}
JD_DEPENDENT_STAGES = set().union(*JD_STAGE_DEPENDENCIES.values())
PROFILE_SOURCE_FIELDS = frozenset(
    {"title", "location", "salary_range", "work_hours", "responsibilities", "requirements", "tech_stack"}
)

AGENT_DETAILS = {
    "xiao_wen": {"name": "小文", "action": "完善JD", "page": "xiao_wen"},
    "xiao_hai": {"name": "小海", "action": "生成招聘海报", "page": "xiao_hai"},
    "xiao_xun": {"name": "小寻", "action": "获取简历", "page": "xiao_xun"},
    "xiao_shai": {"name": "小筛", "action": "筛查简历", "page": "xiao_shai"},
    "xiao_mian": {"name": "小面", "action": "生成面试题", "page": "xiao_mian"},
    "xiao_ping": {"name": "小评", "action": "生成录用报告", "page": "xiao_ping"},
}

STAGE_TO_AGENT = {
    "jd_write": "xiao_wen",
    "profile_build": "xiao_wen",
    "poster_gen": "xiao_hai",
    "crawl": "xiao_xun",
    "match": "xiao_shai",
    "interview_gen": "xiao_mian",
    "video_assess": "xiao_mian",
    "report": "xiao_ping",
}

AGENT_FIRST_STAGE = {
    "xiao_hai": "poster_gen",
    "xiao_xun": "crawl",
    "xiao_shai": "match",
    "xiao_mian": "interview_gen",
    "xiao_ping": "report",
}

JD_CONTENT_FIELDS = {
    "title",
    "department",
    "location",
    "salary_range",
    "work_hours",
    "responsibilities",
    "requirements",
    "tech_stack",
    "benefits",
    "team_intro",
}
JD_EDITABLE_FIELDS = JD_CONTENT_FIELDS
JD_ALLOWED_FIELDS = JD_CONTENT_FIELDS | {"company_name", "career_path"}
JD_STRING_FIELDS = {"title", "department", "location", "salary_range", "work_hours", "team_intro"}
JD_LIST_FIELDS = {"responsibilities", "requirements", "tech_stack", "benefits"}


class RevisionConflictError(Exception):
    def __init__(self, current_revision: int):
        self.current_revision = current_revision
        super().__init__(f"JD revision conflict: {current_revision}")


class JdLockedError(Exception):
    """Raised when a downstream handoff has made the JD immutable."""

    def __init__(self, locked_at: str = "", locked_by_stage: str = ""):
        self.locked_at = locked_at
        self.locked_by_stage = locked_by_stage
        super().__init__("JD已锁定，请新建岗位后修改")


def _pipeline_lock_state(conn, pipeline_id: str):
    """Read lock metadata while serializing JD mutations on MySQL."""
    query = "SELECT jd_locked_at, jd_locked_by_stage FROM pipelines WHERE id=%s FOR UPDATE"
    row = conn.execute(query, (pipeline_id,)).fetchone()
    return dict(row) if row else None


def is_valid_jd(value: object) -> bool:
    """判断对象是否为可展示的 JD，而不是模型错误结果。"""
    if not isinstance(value, dict) or value.get("parse_error") or value.get("error"):
        return False
    return any(value.get(field) for field in JD_CONTENT_FIELDS)


def validate_jd_document(jd: dict) -> dict:
    """Reject fields that are outside the server-owned JD schema."""
    if not isinstance(jd, dict) or not jd:
        raise ValueError("JD内容不能为空")
    unknown_fields = sorted(set(jd) - JD_ALLOWED_FIELDS)
    if unknown_fields:
        raise ValueError(f"不支持JD字段：{'、'.join(unknown_fields)}")
    return deepcopy(jd)


def apply_jd_patch(current_jd: dict, patch: dict) -> tuple[dict, list[str]]:
    """Validate and merge a structured JD patch without allowing unknown fields."""
    if not isinstance(patch, dict) or not isinstance(patch.get("changes"), list):
        raise ValueError("AI返回的JD修改格式无效")

    updated = deepcopy(current_jd)
    changed_fields = []
    for change in patch["changes"]:
        if not isinstance(change, dict):
            raise ValueError("AI返回的JD修改项无效")
        field = str(change.get("field") or "")
        if field not in JD_EDITABLE_FIELDS:
            raise ValueError(f"不支持修改字段：{field or '未知字段'}")
        value = change.get("value")
        if field in JD_STRING_FIELDS and not isinstance(value, str):
            raise ValueError(f"字段 {field} 必须是文本")
        if field in JD_LIST_FIELDS and (
            not isinstance(value, list) or not all(isinstance(item, str) for item in value)
        ):
            raise ValueError(f"字段 {field} 必须是文本列表")
        if updated.get(field) != value:
            updated[field] = deepcopy(value)
            changed_fields.append(field)
    return updated, changed_fields


def jd_fingerprint(jd: dict, fields: frozenset[str] = PROFILE_SOURCE_FIELDS) -> str:
    """Return a stable fingerprint for fields that a downstream artifact consumes."""
    canonical = {field: jd.get(field) for field in sorted(fields)}
    payload = json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def is_profile_current(profile_stage: dict | None, profile_output: dict, jd: dict, jd_revision: int) -> bool:
    """Check whether a completed profile was generated from the current profile inputs."""
    profile = profile_output.get("profile", profile_output)
    if not (
        profile_stage
        and profile_stage.get("status") == "done"
        and isinstance(profile, dict)
        and profile.get("dimensions")
    ):
        return False
    fingerprint = profile_output.get("jd_fingerprint")
    if fingerprint:
        return fingerprint == jd_fingerprint(jd)
    return int(profile_output.get("jd_revision") or 0) == int(jd_revision)


def _affected_stages(changed_fields: set[str]) -> set[str]:
    affected = set()
    for field in changed_fields:
        affected.update(JD_STAGE_DEPENDENCIES.get(field, set()))
    return affected


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _jd_stage(pipeline_id: str) -> tuple[dict, dict]:
    stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "jd_write"), None)
    if not stage:
        raise LookupError("JD stage not found")
    return stage, parse_stage_output(stage)


def save_draft(
    pipeline_id: str,
    jd: dict,
    *,
    expected_revision: Optional[int] = None,
    source: str = "manual",
) -> dict:
    with transaction() as conn:
        pipeline = _pipeline_lock_state(conn, pipeline_id)
        if pipeline and pipeline.get("jd_locked_at"):
            raise JdLockedError(pipeline.get("jd_locked_at", ""), pipeline.get("jd_locked_by_stage", ""))
        jd = validate_jd_document(jd)
        _, output = _jd_stage(pipeline_id)
        old_jd = output.get("jd") if isinstance(output.get("jd"), dict) else {}
        # 允许客户端提交单字段更新，避免后续编辑覆盖掉之前已保存的字段。
        jd = {**old_jd, **jd}
        current_revision = int(output.get("revision") or 0)
        if expected_revision is not None and expected_revision != current_revision:
            raise RevisionConflictError(current_revision)
        changed_fields = {field for field in JD_ALLOWED_FIELDS if old_jd.get(field) != jd.get(field)}
        affected_stages = _affected_stages(changed_fields)
        saved = {
            **output,
            "jd": jd,
            "revision": current_revision + 1,
            "approval_status": "draft",
            "updated_at": _now(),
            "source": source,
            "history": [],
        }
        saved.pop("approved_revision", None)
        saved.pop("approved_at", None)
        update_stage(pipeline_id, "jd_write", "pending", saved, conn=conn)

        for stage in get_stages(pipeline_id):
            stage_id = stage["stage_id"]
            if stage_id in affected_stages:
                update_stage(pipeline_id, stage["stage_id"], "pending", {}, conn=conn)
                continue
            if stage_id == "profile_build":
                profile_output = parse_stage_output(stage)
                if is_profile_current(stage, profile_output, old_jd, current_revision):
                    profile_output["jd_revision"] = saved["revision"]
                    profile_output["jd_fingerprint"] = jd_fingerprint(jd)
                    update_stage(pipeline_id, stage_id, stage.get("status") or "done", profile_output, conn=conn)
    return saved


def approve_draft(pipeline_id: str, expected_revision: Optional[int] = None) -> dict:
    with transaction() as conn:
        pipeline = _pipeline_lock_state(conn, pipeline_id)
        if pipeline and pipeline.get("jd_locked_at"):
            raise JdLockedError(pipeline.get("jd_locked_at", ""), pipeline.get("jd_locked_by_stage", ""))
        _, output = _jd_stage(pipeline_id)
        current_revision = int(output.get("revision") or 0)
        if expected_revision is not None and expected_revision != current_revision:
            raise RevisionConflictError(current_revision)
        revision = current_revision or 1
        missing = [item["label"] for item in quality_checks(output.get("jd") or {}) if item["status"] == "missing"]
        if missing:
            raise ValueError("请先补充：" + "、".join(missing))

        approved = {
            **output,
            "revision": revision,
            "approval_status": "approved",
            "approved_revision": revision,
            "approved_at": _now(),
            "updated_at": _now(),
        }
        approved["history"] = []
        update_stage(pipeline_id, "jd_write", "done", approved, conn=conn)

        # 兼容曾被自动流程提前生成画像的历史流水线：首次确认 JD 后必须重新生成画像。
        if output.get("approval_status") != "approved":
            profile_stage = next(
                (stage for stage in get_stages(pipeline_id) if stage["stage_id"] == "profile_build"), None
            )
            profile_output = parse_stage_output(profile_stage) if profile_stage else {}
            if profile_stage and not is_profile_current(
                profile_stage, profile_output, output.get("jd") or {}, revision
            ):
                update_stage(pipeline_id, "profile_build", "pending", {}, conn=conn)
    return approved


def quality_checks(jd: dict) -> list[dict]:
    fields = [
        ("title", "岗位名称", bool(jd.get("title"))),
        ("location", "工作地点", bool(jd.get("location"))),
        ("salary_range", "薪资范围", bool(jd.get("salary_range"))),
        ("responsibilities", "岗位职责", len(jd.get("responsibilities") or []) >= 3),
        ("requirements", "任职要求", len(jd.get("requirements") or []) >= 3),
        ("benefits", "福利待遇", bool(jd.get("benefits"))),
    ]
    return [
        {
            "field": field,
            "label": label,
            "status": "ready" if ready else "missing",
            "message": "已准备" if ready else f"请补充{label}",
        }
        for field, label, ready in fields
    ]


def _agent_list(raw) -> list[str]:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            raw = [item.strip() for item in raw.split(",")]
    if not isinstance(raw, list):
        return []
    result = []
    for item in raw:
        agent = STAGE_TO_AGENT.get(str(item), str(item))
        if agent in AGENT_DETAILS and agent not in result:
            result.append(agent)
    return result


def configured_agents(pipeline: dict) -> list[str]:
    """读取流水线配置的 Agent 顺序；空配置由调用方按兼容规则处理。"""
    return _agent_list(pipeline.get("agents")) or _agent_list(pipeline.get("enabled_agents"))


def next_downstream(pipeline: dict, current_agent: str = "xiao_wen") -> Optional[dict]:
    configured = configured_agents(pipeline)
    agents = configured or list(AGENT_DETAILS)
    if current_agent not in agents:
        next_agent = agents[0] if agents else None
    else:
        current_index = agents.index(current_agent)
        next_agent = agents[current_index + 1] if current_index < len(agents) - 1 else None
    if not next_agent:
        return None
    return {"agent_id": next_agent, **AGENT_DETAILS[next_agent]}


def workflow(
    stages: list[dict],
    jd_output: dict,
    ready_agent: str = "",
    enabled_agents: Optional[list[str]] = None,
) -> list[dict]:
    stages_by_id = {stage["stage_id"]: stage for stage in stages}
    result = []
    enabled = set(enabled_agents or [])

    for group, definitions in WORKFLOW_GROUPS:
        items = []
        for stage_id, label, tab, agent in definitions:
            if enabled and agent and agent not in enabled:
                continue
            stage = stages_by_id.get(stage_id, {})
            status = stage.get("status") or "pending"
            if stage_id == "jd_write" and jd_output.get("jd"):
                approved = jd_output.get("approval_status") == "approved"
                status = "done" if approved else "draft"
                status_label = "已确认" if approved else "草稿"
            elif status not in ("done", "running") and AGENT_FIRST_STAGE.get(ready_agent) == stage_id:
                status = "ready"
                status_label = "可开始"
            else:
                status_label = {
                    "done": "已完成",
                    "running": "进行中",
                    "failed": "异常",
                    "error": "异常",
                }.get(status, "未开始")
            items.append(
                {
                    "stage_id": stage_id,
                    "label": label,
                    "status": status,
                    "status_label": status_label,
                    "tab": tab,
                    "agent": agent,
                }
            )
        if items:
            result.append({"group": group, "items": items})
    return result


def workspace(pipeline_id: str) -> dict:
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise LookupError("Pipeline not found")
    stages = get_stages(pipeline_id)
    stage = next((item for item in stages if item["stage_id"] == "jd_write"), None)
    output = parse_stage_output(stage) if stage else {}
    jd = output.get("jd") if is_valid_jd(output.get("jd")) else {}
    safe_output = {**output, "jd": jd}
    profile_stage = next((item for item in stages if item["stage_id"] == "profile_build"), None)
    profile_output = parse_stage_output(profile_stage) if profile_stage else {}
    profile_revision = int(profile_output.get("jd_revision") or 0)
    profile = profile_output.get("profile", profile_output)
    jd_is_approved = bool(jd) and (
        output.get("approval_status") == "approved"
        or (not output.get("approval_status") and stage and stage.get("status") == "done")
    )
    profile_is_current = bool(
        jd_is_approved and is_profile_current(profile_stage, profile_output, jd, int(output.get("revision") or 0))
    )
    profile = profile_output.get("profile", profile_output) if profile_is_current else {}
    display_stages = deepcopy(stages)
    if not jd_is_approved:
        for display_stage in display_stages:
            if display_stage["stage_id"] == "profile_build":
                display_stage["status"] = "pending"
                break
    all_messages = get_messages(pipeline_id, limit=100)
    # 从最新消息向前回溯，取最近一次变更；next 顺序遍历会误取最早的历史卡片。
    latest_change = next(
        (
            message
            for message in reversed(all_messages)
            if message.get("stage_id") == "jd_write"
            and message.get("card_type") in {"jd_card", "jd_edited", "artifact_pass"}
        ),
        None,
    )
    downstream = next_downstream(pipeline)
    passed_to = (
        latest_change.get("card_data", {}).get("to_agent", "")
        if latest_change and latest_change.get("card_type") == "artifact_pass"
        else ""
    )
    if downstream:
        downstream = {
            **downstream,
            "passed": passed_to == downstream["agent_id"],
        }

    messages = [
        message
        for message in all_messages
        if message.get("card_type") != "jd_edited"
        and (message.get("stage_id") == "jd_write" or message.get("card_type") == "jd_card")
    ]
    return {
        "pipeline_id": pipeline_id,
        "role": pipeline.get("role") or "未命名岗位",
        "pipeline_status": pipeline.get("status") or "draft",
        "jd": jd,
        "revision": int(output.get("revision") or 0),
        "approval_status": "approved" if jd_is_approved else "draft",
        "approved_revision": int(output.get("approved_revision") or 0),
        "updated_at": output.get("updated_at") or "",
        "jd_locked": bool(pipeline.get("jd_locked_at")),
        "jd_locked_at": pipeline.get("jd_locked_at") or "",
        "jd_locked_by_stage": pipeline.get("jd_locked_by_stage") or "",
        "cloned_from_pipeline_id": pipeline.get("cloned_from_pipeline_id") or "",
        "history": [],
        "quality_checks": quality_checks(jd),
        "profile": profile if profile.get("dimensions") else {},
        "profile_revision": profile_revision,
        "profile_status": profile_stage.get("status") if jd_is_approved and profile_stage else "pending",
        "profile_is_current": profile_is_current,
        "workflow": workflow(display_stages, safe_output, passed_to, configured_agents(pipeline)),
        "downstream": downstream,
        "messages": messages[-50:],
    }
