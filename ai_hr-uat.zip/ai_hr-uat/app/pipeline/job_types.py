"""Recruitment job type definitions shared by pipeline creation and interviews."""

from __future__ import annotations

JOB_TYPE_OPTIONS = (
    ("tech", "技术岗"),
    ("product", "产品岗"),
    ("operations", "运营岗"),
    ("sales", "销售岗"),
    ("supply_chain", "供应链岗"),
    ("service", "服务岗"),
    ("management", "管理岗"),
    ("function", "职能岗"),
    ("general", "通用岗"),
)

JOB_TYPE_LABELS = dict(JOB_TYPE_OPTIONS)
JOB_TYPE_ALIASES = {
    **{label: code for code, label in JOB_TYPE_OPTIONS},
    "ops": "operations",
    "retail": "service",
    "technical": "tech",
}


def normalize_job_type(value: str | None) -> str:
    """Return the stable storage code for a job type accepted by the product."""
    normalized = str(value or "").strip()
    if normalized in JOB_TYPE_LABELS:
        return normalized
    if normalized in JOB_TYPE_ALIASES:
        return JOB_TYPE_ALIASES[normalized]
    raise ValueError("不支持的岗位类型")


def job_type_label(value: str | None) -> str:
    """Return a display label while keeping unknown historical values readable."""
    try:
        return JOB_TYPE_LABELS[normalize_job_type(value)]
    except ValueError:
        return str(value or "通用岗")
