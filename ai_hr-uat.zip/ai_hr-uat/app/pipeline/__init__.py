"""招聘流程领域包：岗位类型、流水线清理、JD 工作台（目录整理 R2）。

原 ``app/job_types.py``、``app/pipeline_cleanup.py``、``app/jd_workspace.py``
按 ``docs/directory-reorganization-plan.md`` 归入本包，实现原样保留。
旧导入路径经 sys.modules 别名与 app 包属性注册保持兼容。
"""

import importlib
import sys

_MODULES = (
    "job_types",
    "pipeline_cleanup",
    "jd_workspace",
)

import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    _mod = importlib.import_module(f"app.pipeline.{_name}")
    # app.X 旧路径别名：指向同一模块对象，monkeypatch / 属性访问语义不变
    sys.modules.setdefault(f"app.{_name}", _mod)
    setattr(sys.modules[__name__], _name, _mod)
    setattr(_app_pkg, _name, _mod)

__all__ = list(_MODULES)
