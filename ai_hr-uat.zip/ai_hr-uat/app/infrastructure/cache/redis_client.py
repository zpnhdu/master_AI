"""Lazy Redis client with a no-op fallback for local/demo mode."""

from __future__ import annotations

from typing import Any

from app.infrastructure.config import settings


class NullRedis:
    """Small compatibility object used when Redis is not configured."""

    backend = "none"

    def ping(self) -> bool:
        return True

    def get(self, _key: str) -> None:
        return None

    def set(self, _key: str, _value: Any, **_kwargs: Any) -> bool:
        return False

    def delete(self, *_keys: str) -> int:
        return 0

    def rpush(self, _name: str, *_values: Any) -> int:
        return 0


class RedisClient:
    backend = "redis"

    def __init__(self, client: Any):
        self._client = client

    def key(self, name: str) -> str:
        return f"{settings.redis_prefix}{name}"

    def ping(self) -> bool:
        return bool(self._client.ping())

    def get(self, name: str):
        return self._client.get(self.key(name))

    def set(self, name: str, value: Any, *, ttl: int | None = None, **kwargs: Any) -> bool:
        if ttl is not None:
            kwargs["ex"] = ttl
        return bool(self._client.set(self.key(name), value, **kwargs))

    def delete(self, *names: str) -> int:
        return int(self._client.delete(*(self.key(name) for name in names)))

    def rpush(self, name: str, *values: Any) -> int:
        return int(self._client.rpush(self.key(name), *values))


_client: RedisClient | NullRedis | None = None


def get_redis_client(*, required: bool = False):
    """Return the configured Redis adapter, initializing it on first use."""

    global _client
    if _client is not None:
        return _client
    url = settings.redis_url.strip()
    if not url:
        if required:
            raise RuntimeError("REDIS_URL is required but not configured")
        _client = NullRedis()
        return _client
    try:
        import redis

        client = redis.Redis.from_url(
            url,
            socket_timeout=settings.redis_socket_timeout,
            decode_responses=True,
        )
        _client = RedisClient(client)
    except ImportError as exc:
        raise RuntimeError("Redis backend requires redis package: pip install redis") from exc
    return _client


def reset_redis_client() -> None:
    global _client
    _client = None
