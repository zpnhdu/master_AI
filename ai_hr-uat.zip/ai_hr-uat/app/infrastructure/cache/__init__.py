"""Cache and ephemeral state adapters."""

from app.infrastructure.cache.redis_client import get_redis_client

__all__ = ["get_redis_client"]
