"""Optional infrastructure adapters for the AI HR backend.

The backend persists to MySQL; adapters in this package
are deliberately lazy so a developer can run the project without provisioning
external services first.
"""

from app.infrastructure.config import settings

__all__ = ["settings"]
