"""Backend-owned business timeout policy."""

from __future__ import annotations

import time
from collections.abc import Callable

from app import db

DEFAULT_AGENT_TIMEOUT_SECONDS = 120.0
# GPT Image 2 编辑请求最多需要 180 秒，海报生成还要为 Flash 文案精炼和素材处理留出时间。
POSTER_GENERATION_MIN_TIMEOUT_SECONDS = 300.0
_AGENT_ID_ALIASES = {"jd_writer": "jd_write"}
_LEGACY_AGENT_IDS = {"jd_write": "jd_writer"}


class BusinessTimeoutError(TimeoutError):
    """Raised when a business operation has exhausted its total time budget."""

    def __init__(
        self,
        message: str = "business operation timed out",
        *,
        agent_id: str | None = None,
        operation: str | None = None,
        timeout_seconds: float | None = None,
    ):
        self.agent_id = agent_id
        self.operation = operation or agent_id
        self.timeout_seconds = timeout_seconds
        super().__init__(message)


class TimeoutDeadline:
    """Track a total business timeout using a monotonic clock."""

    def __init__(
        self,
        timeout_seconds: float,
        *,
        clock: Callable[[], float] = time.monotonic,
        agent_id: str | None = None,
    ):
        if timeout_seconds < 0:
            raise ValueError("timeout_seconds must be non-negative")

        self.timeout_seconds = float(timeout_seconds)
        self.agent_id = agent_id
        self._clock = clock
        started_at = clock()
        self._deadline_at = started_at + self.timeout_seconds

    @property
    def deadline(self) -> float:
        """Return the absolute monotonic deadline."""
        return self._deadline_at

    def remaining_seconds(self) -> float:
        """Return remaining budget, capped at the original total timeout."""
        elapsed_remaining = self._deadline_at - self._clock()
        return min(self.timeout_seconds, max(0.0, elapsed_remaining))

    def require_remaining(self) -> float:
        """Return remaining budget or raise when the deadline is exhausted."""
        remaining_seconds = self.remaining_seconds()
        if remaining_seconds <= 0:
            raise BusinessTimeoutError(
                agent_id=self.agent_id,
                timeout_seconds=self.timeout_seconds,
                message=self._timeout_message(),
            )
        return remaining_seconds

    def expired(self) -> bool:
        """Return whether no business time remains."""
        return self.remaining_seconds() <= 0

    def _timeout_message(self) -> str:
        if self.agent_id:
            return f"business operation timed out for agent {self.agent_id}"
        return "business operation timed out"


def get_agent_timeout(agent_id: str) -> float:
    """Read an agent timeout from the backend config with legacy ID support."""
    if not agent_id:
        raise ValueError("agent_id is required")

    canonical_agent_id = _AGENT_ID_ALIASES.get(agent_id, agent_id)
    candidate_ids = [canonical_agent_id]
    for candidate_id in (agent_id, _LEGACY_AGENT_IDS.get(canonical_agent_id)):
        if candidate_id and candidate_id not in candidate_ids:
            candidate_ids.append(candidate_id)

    config = None
    for candidate_id in candidate_ids:
        config = db.get_agent_config(candidate_id)
        if config is not None:
            break

    if not config or config.get("timeout") is None:
        return DEFAULT_AGENT_TIMEOUT_SECONDS

    timeout_seconds = float(config["timeout"])
    if timeout_seconds < 0:
        raise ValueError("agent timeout must be non-negative")
    return timeout_seconds


def get_poster_generation_timeout() -> float:
    """Return a GPT Image 2-compatible poster budget while honoring larger config values."""
    return max(get_agent_timeout("poster_gen"), POSTER_GENERATION_MIN_TIMEOUT_SECONDS)
