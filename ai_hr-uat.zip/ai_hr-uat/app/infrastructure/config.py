"""由环境变量驱动的基础设施配置。

此模块不导入任何 SDK，可以在应用启动期间安全加载；各服务商专用客户端由适配器模块封装。
"""

from __future__ import annotations

import os
from dataclasses import dataclass


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


# OSS 对象前缀统一为 ai-hr/{环境}/{分类}，分类：knowledge / video / attachments。
_APP_ENV = os.getenv("APP_ENV", "local").strip().lower() or "local"
_OSS_ROOT = f"ai-hr/{_APP_ENV}"


@dataclass(frozen=True)
class InfrastructureSettings:
    app_name: str = os.getenv("APP_NAME", "ai-hr-os")
    app_env: str = _APP_ENV
    app_debug: bool = _bool("APP_DEBUG", True)
    timezone: str = os.getenv("APP_TIMEZONE", "Asia/Shanghai")

    db_url: str = os.getenv("DATABASE_URL", "")

    redis_url: str = os.getenv("REDIS_URL", "")
    redis_prefix: str = os.getenv("REDIS_PREFIX", "aihr:")
    redis_socket_timeout: int = _int("REDIS_SOCKET_TIMEOUT_SECONDS", 5)

    vector_backend: str = os.getenv("VECTOR_BACKEND", "none").lower()
    # Agent-facing knowledge retrieval is enabled whenever an ES vector backend
    # is configured.  It is separate from WIKI_VECTOR_ENABLED, which controls
    # the dedicated Wiki chat endpoint's optional remote embedding path.
    knowledge_vector_enabled: bool = _bool("KNOWLEDGE_VECTOR_ENABLED", True)
    wiki_vector_enabled: bool = _bool("WIKI_VECTOR_ENABLED", True)
    elasticsearch_url: str = os.getenv("ELASTICSEARCH_URL", "")
    elasticsearch_api_key: str = os.getenv("ELASTICSEARCH_API_KEY", "")
    elasticsearch_username: str = os.getenv("ELASTICSEARCH_USERNAME", "")
    elasticsearch_password: str = os.getenv("ELASTICSEARCH_PASSWORD", "")
    elasticsearch_verify_certs: bool = _bool("ELASTICSEARCH_VERIFY_CERTS", True)
    elasticsearch_request_timeout: int = _int("ELASTICSEARCH_REQUEST_TIMEOUT_SECONDS", 10)
    elasticsearch_max_retries: int = _int("ELASTICSEARCH_MAX_RETRIES", 2)
    vector_index_prefix: str = os.getenv("VECTOR_INDEX_PREFIX", "aihr_")
    knowledge_vector_index: str = os.getenv("KNOWLEDGE_VECTOR_INDEX", "knowledge_documents_v1")
    wiki_vector_index: str = os.getenv("WIKI_VECTOR_INDEX", "wiki_chunks_v1")
    wiki_vector_chunk_chars: int = _int("WIKI_VECTOR_CHUNK_CHARS", 1200)
    wiki_vector_chunk_overlap_chars: int = _int("WIKI_VECTOR_CHUNK_OVERLAP_CHARS", 150)
    wiki_vector_recall_size: int = _int("WIKI_VECTOR_RECALL_SIZE", 20)
    wiki_vector_min_score: float = _float("WIKI_VECTOR_MIN_SCORE", 0.15)
    wiki_vector_weight: float = _float("WIKI_VECTOR_WEIGHT", 0.7)
    wiki_analysis_concurrency: int = _int("WIKI_ANALYSIS_CONCURRENCY", 5)

    storage_backend: str = os.getenv("MEDIA_STORAGE_BACKEND", os.getenv("OSS_PROVIDER", "local")).lower()
    oss_endpoint: str = os.getenv("OSS_ENDPOINT", os.getenv("ALICLOUD_OSS_ENDPOINT", ""))
    oss_bucket: str = os.getenv("OSS_BUCKET", os.getenv("ALICLOUD_OSS_BUCKET", ""))
    oss_access_key_id: str = os.getenv("OSS_ACCESS_KEY_ID", os.getenv("ALICLOUD_ACCESS_KEY", ""))
    oss_access_key_secret: str = os.getenv("OSS_ACCESS_KEY_SECRET", os.getenv("ALICLOUD_ACCESS_SECRET", ""))
    oss_public_base_url: str = os.getenv("OSS_PUBLIC_BASE_URL", "")
    oss_presign_expire_seconds: int = _int("OSS_PRESIGN_EXPIRE_SECONDS", 3600)
    oss_connect_timeout_seconds: float = _float("OSS_CONNECT_TIMEOUT_SECONDS", 5.0)
    wiki_content_storage_backend: str = os.getenv("WIKI_CONTENT_STORAGE_BACKEND", "local").lower()
    oss_brand_prefix: str = os.getenv("OSS_BRAND_PREFIX", f"{_OSS_ROOT}/attachments/brand").strip("/")
    oss_xiao_hai_prefix: str = os.getenv("OSS_XIAO_HAI_PREFIX", f"{_OSS_ROOT}/attachments/xiao-hai").strip("/")
    oss_knowledge_prefix: str = os.getenv("OSS_KNOWLEDGE_PREFIX", f"{_OSS_ROOT}/knowledge").strip("/")
    oss_written_test_prefix: str = os.getenv("OSS_WRITTEN_TEST_PREFIX", f"{_OSS_ROOT}/attachments/written-test").strip(
        "/"
    )
    oss_interview_prefix: str = os.getenv("OSS_INTERVIEW_PREFIX", f"{_OSS_ROOT}/video/interview").strip("/")
    oss_request_max_attempts: int = _int("OSS_REQUEST_MAX_ATTEMPTS", 3)
    oss_request_retry_backoff_seconds: float = _float("OSS_REQUEST_RETRY_BACKOFF_SECONDS", 1.0)
    oss_video_prefix: str = os.getenv("OSS_VIDEO_PREFIX", f"{_OSS_ROOT}/video").strip("/")
    oss_resume_prefix: str = os.getenv("OSS_RESUME_PREFIX", f"{_OSS_ROOT}/attachments/resume").strip("/")

    worker_concurrency: int = _int("WORKER_CONCURRENCY", 4)
    task_retry_max: int = _int("TASK_RETRY_MAX", 3)
    task_timeout_seconds: int = _int("TASK_TIMEOUT_SECONDS", 600)


settings = InfrastructureSettings()
