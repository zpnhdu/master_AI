"""Minimal task facade; Redis is optional until workers are deployed."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from app.infrastructure.cache.redis_client import get_redis_client


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def enqueue(task_type: str, payload: dict[str, Any], *, task_id: str | None = None) -> dict[str, Any]:
    task_id = task_id or f"task_{uuid.uuid4().hex}"
    task = {"id": task_id, "type": task_type, "payload": payload, "status": "queued", "created_at": _now()}
    redis = get_redis_client()
    if getattr(redis, "backend", "none") == "redis":
        redis.set(f"task:{task_id}", json.dumps(task, ensure_ascii=False), ttl=86400)
        redis.rpush("queue:tasks", json.dumps(task, ensure_ascii=False))
    return task


def get_task_status(task_id: str) -> dict[str, Any] | None:
    redis = get_redis_client()
    if getattr(redis, "backend", "none") != "redis":
        return None
    value = redis.get(f"task:{task_id}")
    if not value:
        return None
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return None
