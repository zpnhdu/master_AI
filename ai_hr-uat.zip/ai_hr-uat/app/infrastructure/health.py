"""Readiness checks for optional infrastructure services."""

from __future__ import annotations

from typing import Any

from app.infrastructure.cache.redis_client import get_redis_client
from app.infrastructure.config import settings
from app.infrastructure.vector.store import get_vector_store


def _check(name: str, fn, *, configured: bool = True) -> dict[str, Any]:
    if not configured:
        return {"status": "disabled", "required": False}
    try:
        fn()
        return {"status": "ok", "required": True}
    except Exception as exc:
        return {"status": "error", "required": True, "error": str(exc)[:200]}


def check_health(*, ready: bool = False) -> dict[str, Any]:
    """Return stable health payload while preserving local demo availability."""

    services: dict[str, dict[str, Any]] = {}
    services["database"] = _check("database", lambda: _database_ping(), configured=True)
    services["redis"] = _check(
        "redis", lambda: get_redis_client(required=ready).ping(), configured=bool(settings.redis_url)
    )
    vector_configured = settings.vector_backend not in {"", "none", "disabled", "local"}
    services["vector"] = _check("vector", lambda: get_vector_store(required=ready).ping(), configured=vector_configured)
    storage_configured = settings.storage_backend in {"oss", "aliyun", "local"}
    services["storage"] = _check("storage", lambda: _storage_ping(), configured=storage_configured)

    required_failures = [name for name, item in services.items() if item.get("required") and item["status"] != "ok"]
    return {
        "status": "ok" if not required_failures else "degraded",
        "ready": not required_failures,
        "environment": settings.app_env,
        "services": services,
    }


def _database_ping() -> None:
    from app.db import get_db

    get_db().execute("SELECT 1").fetchone()


def _storage_ping() -> None:
    import os

    from app.media_storage import get_media_storage

    storage = get_media_storage()
    if storage.backend in {"oss", "aliyun"}:
        # OSS SDK 提供 get_bucket_info；就绪检查中避免执行数据写入。
        if hasattr(storage, "bucket") and hasattr(storage.bucket, "get_bucket_info"):
            storage.bucket.get_bucket_info()
        return
    if storage.backend == "local":
        root = getattr(storage, "root", None)
        if root is None or not os.access(root, os.W_OK):
            raise OSError(f"local media directory is not writable: {root}")
