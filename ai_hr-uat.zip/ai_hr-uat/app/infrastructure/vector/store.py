"""Provider-neutral vector store facade.

Business code depends on this adapter instead of importing the Elasticsearch
SDK.  Index names are always qualified with the configured environment prefix,
which prevents dev/uat/prod data from sharing one logical index accidentally.
"""

from __future__ import annotations

from typing import Any

from app.infrastructure.config import settings


class DisabledVectorStore:
    backend = "none"

    def ping(self) -> bool:
        return True

    def upsert(self, *_args: Any, **_kwargs: Any) -> None:
        raise RuntimeError("vector backend is disabled; configure VECTOR_BACKEND")

    def search(self, *_args: Any, **_kwargs: Any) -> list[dict]:
        return []

    def search_hits(self, *_args: Any, **_kwargs: Any) -> list[dict]:
        return []

    def index_exists(self, *_args: Any, **_kwargs: Any) -> bool:
        return False

    def ensure_index(self, *_args: Any, **_kwargs: Any) -> bool:
        raise RuntimeError("vector backend is disabled; configure VECTOR_BACKEND")

    def bulk_upsert(self, *_args: Any, **_kwargs: Any) -> int:
        raise RuntimeError("vector backend is disabled; configure VECTOR_BACKEND")

    def delete_by_query(self, *_args: Any, **_kwargs: Any) -> int:
        return 0

    def get_documents(self, *_args: Any, **_kwargs: Any) -> dict[str, dict[str, Any]]:
        return {}

    def delete_documents(self, *_args: Any, **_kwargs: Any) -> int:
        return 0


class ElasticsearchVectorStore:
    backend = "elasticsearch"

    def __init__(self, client: Any | None = None):
        if client is not None:
            self.client = client
            return
        try:
            from elasticsearch import Elasticsearch
        except ImportError as exc:
            raise RuntimeError("Elasticsearch backend requires elasticsearch package") from exc
        if not settings.elasticsearch_url:
            raise RuntimeError("ELASTICSEARCH_URL is required for Elasticsearch backend")
        kwargs: dict[str, Any] = {
            "verify_certs": settings.elasticsearch_verify_certs,
            "request_timeout": settings.elasticsearch_request_timeout,
            "max_retries": settings.elasticsearch_max_retries,
            "retry_on_timeout": True,
        }
        if settings.elasticsearch_api_key:
            kwargs["api_key"] = settings.elasticsearch_api_key
        elif settings.elasticsearch_username:
            kwargs["basic_auth"] = (settings.elasticsearch_username, settings.elasticsearch_password)
        self.client = Elasticsearch(settings.elasticsearch_url, **kwargs)

    @staticmethod
    def _index(index: str) -> str:
        return f"{settings.vector_index_prefix}{index}"

    def ping(self) -> bool:
        return bool(self.client.ping())

    def upsert(self, index: str, document_id: str, document: dict[str, Any]) -> None:
        self.client.index(index=self._index(index), id=document_id, document=document)

    def search(self, index: str, query: dict[str, Any], *, size: int = 10) -> list[dict]:
        response = self.client.search(index=self._index(index), query=query, size=size)
        return [hit.get("_source", {}) for hit in response.get("hits", {}).get("hits", [])]

    def search_hits(
        self,
        index: str,
        query: dict[str, Any],
        *,
        size: int = 10,
        source_excludes: list[str] | None = None,
    ) -> list[dict]:
        response = self.client.search(
            index=self._index(index),
            query=query,
            size=size,
            source_excludes=source_excludes,
        )
        hits = []
        for hit in response.get("hits", {}).get("hits", []):
            hits.append(
                {
                    "id": str(hit.get("_id", "")),
                    "score": float(hit.get("_score") or 0.0),
                    "source": dict(hit.get("_source") or {}),
                }
            )
        return hits

    def index_exists(self, index: str) -> bool:
        return bool(self.client.indices.exists(index=self._index(index)))

    def ensure_index(
        self,
        index: str,
        *,
        mappings: dict[str, Any],
        index_settings: dict[str, Any] | None = None,
    ) -> bool:
        qualified = self._index(index)
        if self.client.indices.exists(index=qualified):
            return False
        self.client.indices.create(index=qualified, mappings=mappings, settings=index_settings or {})
        return True

    def get_mapping(self, index: str) -> dict[str, Any]:
        return dict(self.client.indices.get_mapping(index=self._index(index)))

    def bulk_upsert(self, index: str, documents: list[dict[str, Any]], *, batch_size: int = 100) -> int:
        if not documents:
            return 0
        qualified = self._index(index)
        written = 0
        for offset in range(0, len(documents), max(1, batch_size)):
            operations: list[dict[str, Any]] = []
            for item in documents[offset : offset + max(1, batch_size)]:
                document_id = str(item["id"])
                source = dict(item["document"])
                operations.extend(({"index": {"_index": qualified, "_id": document_id}}, source))
            response = self.client.bulk(operations=operations, refresh="wait_for")
            if response.get("errors"):
                failures = []
                for entry in response.get("items", []):
                    action = entry.get("index") or entry.get("create") or {}
                    if action.get("error"):
                        failures.append(str(action.get("error")))
                detail = "; ".join(failures[:3]) or "unknown bulk failure"
                raise RuntimeError(f"Elasticsearch bulk upsert failed: {detail}")
            written += len(operations) // 2
        return written

    def get_documents(
        self,
        index: str,
        document_ids: list[str],
        *,
        source_excludes: list[str] | None = None,
    ) -> dict[str, dict[str, Any]]:
        if not document_ids or not self.index_exists(index):
            return {}
        response = self.client.mget(
            index=self._index(index),
            ids=[str(value) for value in document_ids],
            source_excludes=source_excludes,
        )
        return {
            str(item.get("_id")): dict(item.get("_source") or {})
            for item in response.get("docs", [])
            if item.get("found")
        }

    def delete_documents(self, index: str, document_ids: list[str]) -> int:
        if not document_ids or not self.index_exists(index):
            return 0
        operations = []
        for document_id in document_ids:
            operations.append({"delete": {"_index": self._index(index), "_id": str(document_id)}})
        response = self.client.bulk(operations=operations, refresh="wait_for")
        failures = []
        deleted = 0
        for entry in response.get("items", []):
            action = entry.get("delete") or {}
            if action.get("error") and action.get("status") != 404:
                failures.append(str(action.get("error")))
            elif action.get("status") in {200, 202}:
                deleted += 1
        if failures:
            raise RuntimeError(f"Elasticsearch delete failed: {'; '.join(failures[:3])}")
        return deleted

    def delete_by_query(self, index: str, query: dict[str, Any]) -> int:
        if not self.index_exists(index):
            return 0
        response = self.client.delete_by_query(
            index=self._index(index),
            query=query,
            conflicts="proceed",
            refresh=False,
        )
        return int(response.get("deleted") or 0)


_store: DisabledVectorStore | ElasticsearchVectorStore | None = None


def get_vector_store(*, required: bool = False):
    global _store
    if _store is not None:
        return _store
    if settings.vector_backend in {"", "none", "disabled", "local"}:
        if required:
            raise RuntimeError("VECTOR_BACKEND is required but disabled")
        _store = DisabledVectorStore()
    elif settings.vector_backend in {"elasticsearch", "es"}:
        _store = ElasticsearchVectorStore()
    else:
        raise RuntimeError(f"unsupported vector backend: {settings.vector_backend}")
    return _store


def reset_vector_store() -> None:
    """Clear the process singleton after configuration changes or in tests."""
    global _store
    _store = None
