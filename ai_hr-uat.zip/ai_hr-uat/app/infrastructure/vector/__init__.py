"""Vector search adapters with an explicit disabled fallback."""

from app.infrastructure.vector.store import get_vector_store

__all__ = ["get_vector_store"]
