"""Candidate-level assessment reports with deterministic evidence rendering and DOCX export."""

from __future__ import annotations

import asyncio
import hashlib
import io
import json
import logging
import os
from copy import deepcopy
from datetime import datetime
from typing import Any

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from app import assessment_flow
from app.db import get_db, get_pipeline
from hr_harness.agents.base import BaseAgent

logger = logging.getLogger(__name__)

REPORT_VERSION = "candidate_assessment_report_v2"
_REPORT_GENERATION_TASKS: dict[tuple[str, str], asyncio.Task] = {}
QUEUE_ORDER = ("ready_for_decision", "incomplete", "closed_incomplete")
QUEUE_LABELS = {
    "ready_for_decision": "正式报告",
    "incomplete": "评估未完成",
    "closed_incomplete": "评估已关闭",
}
MODALITY_LABELS = {
    "video_interview": "视频面试",
    "written_test": "在线笔试",
    "manual_interview": "人工面试",
}


def _candidate_report_model() -> str:
    """Resolve the candidate-report model independently from OPENAI_MODEL."""
    return os.getenv("CANDIDATE_REPORT_MODEL", "qwen3.6-flash").strip() or "qwen3.6-flash"


def _ensure_table() -> None:
    database = get_db()
    database.execute(
        """CREATE TABLE IF NOT EXISTS candidate_assessment_reports (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL,
            candidate_name VARCHAR(191) DEFAULT '',
            report_status VARCHAR(191) NOT NULL,
            evidence_hash VARCHAR(191) NOT NULL,
            report_version VARCHAR(191) NOT NULL,
            report_json LONGTEXT NOT NULL,
            generated_at VARCHAR(191) NOT NULL,
            updated_at VARCHAR(191) NOT NULL,
            UNIQUE(pipeline_id, candidate_id)
        )"""
    )
    column = database.execute("SHOW COLUMNS FROM candidate_assessment_reports LIKE 'report_json'").fetchone()
    column_type = str((column or {}).get("Type") or "").lower()
    if column_type and not column_type.startswith(("text", "mediumtext", "longtext", "json")):
        database.execute("ALTER TABLE candidate_assessment_reports MODIFY COLUMN report_json LONGTEXT NOT NULL")
    database.commit()


def _record(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _records(value: Any) -> list[dict]:
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def _strings(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value).strip()] if value and str(value).strip() else []


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _index(value: Any, default: int) -> int:
    numeric = _number(value)
    return int(numeric) if numeric is not None else default


def _score_sort_value(report: dict) -> float:
    score = _number(report.get("score"))
    return score if score is not None else -1


def _unique(values: list[str], limit: int | None = None) -> list[str]:
    output = []
    seen = set()
    for value in values:
        cleaned = str(value).strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        output.append(cleaned)
        if limit is not None and len(output) >= limit:
            break
    return output


def _criterion_rows(value: Any) -> list[dict]:
    output = []
    for index, item in enumerate(_records(value)):
        output.append(
            {
                "id": str(item.get("id") or index),
                "name": str(item.get("name") or item.get("id") or f"评分项{index + 1}"),
                "level": _number(item.get("level")),
                "score": _number(item.get("score")),
                "confidence": _number(item.get("confidence")),
                "evidence": str(item.get("evidence") or "").strip(),
            }
        )
    return output


def _question_row(
    *,
    step_id: str,
    modality: str,
    question_index: int,
    question: dict,
    answer: dict,
    detail: dict,
) -> dict:
    score = _number(detail.get("score"))
    criteria = _criterion_rows(detail.get("criteria"))
    review_required = bool(
        detail.get("scoring_failed")
        or detail.get("asr_failed")
        or (score is None and not any(item.get("score") is not None for item in criteria))
    )
    evidence = next((item["evidence"] for item in criteria if item["evidence"]), "")
    hit_points = _strings(detail.get("hit_points"))
    missed_points = _strings(detail.get("missed_points"))
    if not hit_points and criteria:
        hit_points = [item["name"] for item in criteria if item["level"] is not None and item["level"] >= 3]
    if not missed_points and criteria:
        missed_points = [item["name"] for item in criteria if item["level"] is not None and item["level"] <= 1]
    return {
        "evidence_ref": f"{modality}:q{question_index + 1}",
        "step_id": step_id,
        "modality": modality,
        "modality_label": MODALITY_LABELS.get(modality, modality or "评估"),
        "question_index": question_index,
        "question": str(question.get("question") or answer.get("question") or f"第{question_index + 1}题"),
        "answer": str(answer.get("answer") or answer.get("answer_text") or answer.get("transcript") or ""),
        "score": score,
        "review_required": review_required and not bool(detail.get("technical_failure")),
        "technical_failure": bool(detail.get("technical_failure")),
        "failure_reason": str(detail.get("failure_reason") or "").strip(),
        "comment": str(detail.get("comment") or "").strip(),
        "candidate_feedback": str(detail.get("candidate_feedback") or "").strip(),
        "hit_points": hit_points,
        "missed_points": missed_points,
        "criteria": criteria,
        "key_evidence": evidence,
    }


def _video_question_detail(answer: dict, evaluation: dict, question_index: int) -> dict:
    """Use final-score criterion evidence for legacy answers that did not retain it."""
    if _records(answer.get("criteria")):
        return answer
    for details in _record(evaluation.get("dim_detail")).values():
        for detail in _records(details):
            if _index(detail.get("question_index"), -1) != question_index:
                continue
            if _records(detail.get("criteria")):
                return {**answer, "criteria": detail["criteria"]}
    return answer


def _extract_step_evidence(package: dict) -> tuple[list[dict], dict[str, float], list[str], list[str]]:
    questions = []
    dimensions: dict[str, float] = {}
    strengths: list[str] = []
    risks: list[str] = []
    selected = set(package.get("selected_path") or [])
    step_items = list(_record(package.get("step_results")).items())
    priority = {"video_interview": 0, "written_test": 1, "manual_interview": 2}
    step_items.sort(
        key=lambda pair: (
            0 if pair[0] in selected else 1,
            priority.get(str(_record(pair[1]).get("modality") or ""), 9),
        )
    )

    for step_id, raw_step in step_items:
        step = _record(raw_step)
        modality = str(step.get("modality") or "")
        evidence = _record(step.get("evidence"))
        evaluation = _record(evidence.get("evaluation"))
        step_dimensions = _record(evaluation.get("dimension_scores"))
        for name, value in step_dimensions.items():
            numeric = _number(value)
            if numeric is not None:
                dimensions[f"{MODALITY_LABELS.get(modality, modality)} · {name}"] = numeric
        source_questions = _records(evidence.get("questions"))
        answers = _records(evidence.get("answers"))
        if modality == "written_test":
            for position, detail in enumerate(_records(evaluation.get("detail"))):
                question_index = _index(detail.get("question_index"), position)
                question = source_questions[question_index] if question_index < len(source_questions) else {}
                answer = next(
                    (item for item in answers if _index(item.get("question_index"), -1) == question_index),
                    answers[question_index] if question_index < len(answers) else {},
                )
                row = _question_row(
                    step_id=step_id,
                    modality=modality,
                    question_index=question_index,
                    question=question,
                    answer=answer,
                    detail=detail,
                )
                questions.append(row)
                strengths.extend(row["hit_points"])
                risks.extend(row["missed_points"])
        elif modality == "video_interview":
            for position, answer in enumerate(answers):
                question_index = _index(answer.get("question_index"), position)
                question = source_questions[question_index] if question_index < len(source_questions) else {}
                row = _question_row(
                    step_id=step_id,
                    modality=modality,
                    question_index=question_index,
                    question=question,
                    answer=answer,
                    detail=_video_question_detail(answer, evaluation, question_index),
                )
                questions.append(row)
                strengths.extend(row["hit_points"])
                risks.extend(row["missed_points"])

    return questions, dimensions, _unique(strengths, 5), _unique(risks, 5)


def _recommendation(queue_status: str, score: float | None) -> str:
    if score is None:
        return "评估未完成"
    return "通过" if score >= 60 else "淘汰"


def build_candidate_report(package: dict, queue_status: str, role: str = "") -> dict:
    """Build all factual report content without invoking an LLM."""
    questions, dimensions, strengths, risks = _extract_step_evidence(package)
    formal_score = _number(package.get("overall_score"))
    score = formal_score
    source = str(package.get("decision_score_source") or "")
    if not source:
        selected = package.get("selected_path") or []
        selected_result = _record(package.get("step_results")).get(selected[0], {}) if selected else {}
        source = str(_record(selected_result).get("modality") or "")
    report = {
        "report_version": REPORT_VERSION,
        "pipeline_id": str(package.get("pipeline_id") or ""),
        "candidate_id": str(package.get("candidate_id") or ""),
        "candidate_name": str(package.get("candidate_name") or "未知候选人"),
        "role": role,
        "queue_status": queue_status,
        "report_status": "正式报告" if score is not None else "评估未完成",
        "is_formal": score is not None,
        "score": score,
        "score_status": "final" if score is not None else "unavailable",
        "score_source": source,
        "score_source_label": MODALITY_LABELS.get(source, "评估结果"),
        "recommendation": _recommendation(queue_status, score),
        "dimensions": dimensions,
        "strengths": strengths,
        "risks": risks,
        "questions": questions,
        "blockers": [str(item) for item in package.get("blockers") or []],
        "score_provenance": deepcopy(package.get("score_provenance") or []),
        "comprehensive_evaluation": "",
        "hiring_advice": "",
    }
    stable = deepcopy(report)
    stable.pop("comprehensive_evaluation", None)
    stable.pop("hiring_advice", None)
    report["evidence_hash"] = hashlib.sha256(
        json.dumps(stable, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return report


def _fallback_narrative(report: dict) -> dict:
    score_text = f"综合成绩{report['score']:g}分" if report.get("score") is not None else "当前尚无正式总分"
    strengths = "、".join(report.get("strengths")[:2]) or "已有作答证据"
    risks = "、".join(report.get("risks")[:2]) or "暂未发现明确高风险项"
    if report.get("score") is None:
        advice = "当前评估尚未完成，完成测评后再形成录用结论。"
    else:
        advice = f"确定性结论为“{report['recommendation']}”；建议结合岗位优先级核对关键证据后推进下一步。"
    return {
        "comprehensive_evaluation": f"{score_text}，主要优势体现在{strengths}；需要关注{risks}。",
        "hiring_advice": advice,
    }


async def _generate_narrative(report: dict) -> dict:
    facts = {
        "candidate_name": report["candidate_name"],
        "role": report["role"],
        "score": report["score"],
        "score_status": report["score_status"],
        "score_source": report["score_source_label"],
        "deterministic_recommendation": report["recommendation"],
        "strengths": report["strengths"][:3],
        "risks": report["risks"][:3],
        "evidence": [
            {
                "ref": item["evidence_ref"],
                "score": item["score"],
                "hit_points": item["hit_points"][:3],
                "missed_points": item["missed_points"][:3],
                "key_evidence": item["key_evidence"][:160],
            }
            for item in report["questions"][:10]
        ],
    }
    system = """你是招聘评估报告编辑。只能使用输入中的事实，不得重算或修改分数、录用等级，不得补充候选人的经历、薪资或能力。输出严格JSON，只包含 comprehensive_evaluation 和 hiring_advice 两个字符串。综合评价不超过150个汉字，录用建议说明不超过100个汉字。若报告不是正式状态，录用建议必须要求先完成复核，不得给出正式录用结论。"""
    prompt = "请基于以下已核验评估事实撰写两段简短叙事：\n" + json.dumps(facts, ensure_ascii=False)

    def valid(value: Any) -> bool:
        return bool(
            isinstance(value, dict)
            and isinstance(value.get("comprehensive_evaluation"), str)
            and isinstance(value.get("hiring_advice"), str)
            and value.get("comprehensive_evaluation", "").strip()
            and value.get("hiring_advice", "").strip()
        )

    try:
        result = await BaseAgent().call_llm_json(
            prompt,
            system,
            complexity="flash",
            model=_candidate_report_model(),
            temperature=0.1,
            validator=valid,
            max_retries=1,
            timeout=45,
        )
        if valid(result):
            return {
                "comprehensive_evaluation": result["comprehensive_evaluation"].strip()[:300],
                "hiring_advice": result["hiring_advice"].strip()[:200],
            }
    except Exception as exc:
        logger.warning("Candidate report narrative generation failed: %s", exc)
    return _fallback_narrative(report)


def _load_existing(pipeline_id: str, candidate_id: str) -> dict | None:
    _ensure_table()
    row = (
        get_db()
        .execute(
            "SELECT report_json FROM candidate_assessment_reports WHERE pipeline_id=%s AND candidate_id=%s",
            (pipeline_id, candidate_id),
        )
        .fetchone()
    )
    if not row:
        return None
    try:
        return json.loads(row["report_json"])
    except (TypeError, json.JSONDecodeError):
        return None


def _save_report(pipeline_id: str, report: dict) -> None:
    _ensure_table()
    now = datetime.now().isoformat()
    database = get_db()
    upsert_sql = """
    INSERT INTO candidate_assessment_reports
        (pipeline_id, candidate_id, candidate_name, report_status, evidence_hash,
         report_version, report_json, generated_at, updated_at)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    ON DUPLICATE KEY UPDATE
        candidate_name=VALUES(candidate_name),
        report_status=VALUES(report_status),
        evidence_hash=VALUES(evidence_hash),
        report_version=VALUES(report_version),
        report_json=VALUES(report_json),
        generated_at=VALUES(generated_at),
        updated_at=VALUES(updated_at)
    """
    database.execute(
        upsert_sql,
        (
            pipeline_id,
            report["candidate_id"],
            report["candidate_name"],
            report["report_status"],
            report["evidence_hash"],
            report["report_version"],
            json.dumps(report, ensure_ascii=False),
            now,
            now,
        ),
    )
    database.commit()


def _queue_packages(pipeline_id: str) -> list[tuple[str, dict]]:
    queue = assessment_flow.list_decision_queue(pipeline_id)
    packages = []
    for queue_status in QUEUE_ORDER:
        for package in queue.get(queue_status, []) or []:
            item = deepcopy(package)
            item["pipeline_id"] = pipeline_id
            packages.append((queue_status, item))
    return packages


async def generate_reports(
    pipeline_id: str,
    candidate_ids: list[str] | None = None,
    *,
    force: bool = False,
    include_ai: bool = True,
) -> dict:
    pipeline = get_pipeline(pipeline_id) or {}
    role = str(pipeline.get("role") or "")
    selected_ids = {str(item) for item in candidate_ids or [] if str(item)}
    packages = [
        (status, package)
        for status, package in _queue_packages(pipeline_id)
        if _number(package.get("overall_score")) is not None
        and (not selected_ids or package.get("candidate_id") in selected_ids)
    ]
    semaphore = asyncio.Semaphore(3)

    async def generate_one(queue_status: str, package: dict) -> dict:
        async with semaphore:
            report = build_candidate_report(package, queue_status, role)
            existing = _load_existing(pipeline_id, report["candidate_id"])
            if not force and existing and existing.get("evidence_hash") == report["evidence_hash"]:
                return {**existing, "is_stale": False}
            narrative = await _generate_narrative(report) if include_ai else _fallback_narrative(report)
            report.update(narrative)
            report["generated_at"] = datetime.now().isoformat()
            _save_report(pipeline_id, report)
            return {**report, "is_stale": False}

    reports = await asyncio.gather(*(generate_one(status, package) for status, package in packages))
    reports.sort(key=lambda item: -_score_sort_value(item))
    return {
        "pipeline_id": pipeline_id,
        "reports": reports,
        "counts": {
            "total": len(reports),
            "formal": len(reports),
            "draft": 0,
        },
    }


def schedule_report_generation(pipeline_id: str, candidate_id: str) -> bool:
    """在自动评分落库后后台生成报告，同一候选人只保留一个运行任务。"""
    key = (pipeline_id, candidate_id)
    existing_task = _REPORT_GENERATION_TASKS.get(key)
    if existing_task and not existing_task.done():
        return True

    async def run() -> None:
        try:
            await generate_reports(pipeline_id, [candidate_id])
        except Exception:
            logger.exception("Automatic candidate report generation failed: %s/%s", pipeline_id, candidate_id)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False
    task = loop.create_task(run())
    _REPORT_GENERATION_TASKS[key] = task

    def cleanup(completed: asyncio.Task) -> None:
        if _REPORT_GENERATION_TASKS.get(key) is completed:
            _REPORT_GENERATION_TASKS.pop(key, None)

    task.add_done_callback(cleanup)
    return True


def schedule_missing_reports(pipeline_id: str) -> list[str]:
    """为已有自动评分结果但尚无报告的候选人补发后台生成任务。"""
    for queue_status, package in _queue_packages(pipeline_id):
        if _number(package.get("overall_score")) is None:
            continue
        candidate_id = str(package.get("candidate_id") or "")
        if candidate_id and _load_existing(pipeline_id, candidate_id) is None:
            schedule_report_generation(pipeline_id, candidate_id)
    return sorted(
        candidate_id
        for (task_pipeline_id, candidate_id), task in _REPORT_GENERATION_TASKS.items()
        if task_pipeline_id == pipeline_id and not task.done()
    )


def list_reports(pipeline_id: str) -> list[dict]:
    _ensure_table()
    rows = (
        get_db()
        .execute(
            "SELECT report_json FROM candidate_assessment_reports WHERE pipeline_id=%s ORDER BY id",
            (pipeline_id,),
        )
        .fetchall()
    )
    output = []
    for row in rows:
        try:
            output.append(json.loads(row["report_json"]))
        except (TypeError, json.JSONDecodeError):
            continue
    pipeline = get_pipeline(pipeline_id) or {}
    role = str(pipeline.get("role") or "")
    current_hashes = {
        package.get("candidate_id"): build_candidate_report(package, queue_status, role).get("evidence_hash")
        for queue_status, package in _queue_packages(pipeline_id)
    }
    for report in output:
        current_hash = current_hashes.get(report.get("candidate_id"))
        report["is_stale"] = current_hash is None or current_hash != report.get("evidence_hash")
    output.sort(key=lambda item: (0 if item.get("is_formal") else 1, -_score_sort_value(item)))
    return output


def get_report(pipeline_id: str, candidate_id: str) -> dict | None:
    return _load_existing(pipeline_id, candidate_id)


def _set_cell_text(cell, text: str, *, bold: bool = False, color: str = "222222", align=None) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    if align is not None:
        paragraph.alignment = align
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing = 1.08
    run = paragraph.add_run(str(text))
    _set_run_font(run, size=9.5, bold=bold, color=color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _set_run_font(run, *, size: float = 11, bold: bool | None = None, color: str = "222222") -> None:
    run.font.name = "Arial"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "微软雅黑")
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Arial")
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold


def _shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def _set_cell_margins(cell, top: int = 80, start: int = 120, bottom: int = 80, end: int = 120) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def _set_table_geometry(table, widths_dxa: list[int], indent_dxa: int = 120) -> None:
    table.autofit = False
    table_pr = table._tbl.tblPr
    tbl_w = table_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        table_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = table_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        table_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent_dxa))
    tbl_ind.set(qn("w:type"), "dxa")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    if table.rows:
        tr_pr = table.rows[0]._tr.get_or_add_trPr()
        header = tr_pr.find(qn("w:tblHeader"))
        if header is None:
            header = OxmlElement("w:tblHeader")
            tr_pr.append(header)
        header.set(qn("w:val"), "true")
    for row in table.rows:
        for index, cell in enumerate(row.cells):
            width = widths_dxa[min(index, len(widths_dxa) - 1)]
            tc_w = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            _set_cell_margins(cell)


def _configure_document(document: Document) -> None:
    document.core_properties.title = "候选人评估报告"
    document.core_properties.subject = "招聘评估结果与证据摘要"
    document.core_properties.author = "AI HR"
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for name, size, before, after, color in (
        ("Heading 1", 16, 18, 10, "2E74B5"),
        ("Heading 2", 13, 14, 7, "2E74B5"),
        ("Heading 3", 12, 10, 5, "1F4D78"),
    ):
        style = styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    header.paragraph_format.space_after = Pt(0)
    _set_run_font(header.add_run("候选人评估报告  |  仅供招聘决策"), size=8.5, color="6B7280")
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.paragraph_format.space_after = Pt(0)
    _set_run_font(footer.add_run("内部资料"), size=8.5, color="6B7280")


def _add_title(document: Document, title: str, subtitle: str = "") -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(4)
    paragraph.paragraph_format.space_after = Pt(4)
    _set_run_font(paragraph.add_run(title), size=23, bold=True, color="0B2545")
    if subtitle:
        sub = document.add_paragraph()
        sub.paragraph_format.space_after = Pt(14)
        _set_run_font(sub.add_run(subtitle), size=11, color="6B7280")


def _add_status_callout(document: Document, report: dict) -> None:
    table = document.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    _set_table_geometry(table, [9360])
    cell = table.cell(0, 0)
    formal = bool(report.get("is_formal"))
    _shade_cell(cell, "EAF4EA" if formal else "FFF4D6")
    status_text = (
        f"正式结论：{report['recommendation']}"
        if formal
        else f"{report['report_status']}：当前内容不得作为正式录用结论"
    )
    _set_cell_text(cell, status_text, bold=True, color="1F3A5F" if formal else "7A5A00")


def _add_metadata(document: Document, report: dict) -> None:
    table = document.add_table(rows=3, cols=4)
    table.style = "Table Grid"
    _set_table_geometry(table, [1350, 3330, 1350, 3330])
    score = "—" if report.get("score") is None else f"{report['score']:g} 分"
    if report.get("score_status") == "provisional":
        score += "（暂定）"
    values = (
        ("候选人", report["candidate_name"], "岗位", report.get("role") or "未填写"),
        ("成绩", score, "成绩来源", report.get("score_source_label") or "评估结果"),
        ("报告状态", report["report_status"], "录用等级", report["recommendation"]),
    )
    for row_index, row_values in enumerate(values):
        for column_index, value in enumerate(row_values):
            cell = table.cell(row_index, column_index)
            is_label = column_index % 2 == 0
            if is_label:
                _shade_cell(cell, "E8EEF5")
            _set_cell_text(cell, value, bold=is_label, color="1F3A5F" if is_label else "222222")


def _add_dimensions(document: Document, report: dict) -> None:
    dimensions = report.get("dimensions") or {}
    if not dimensions:
        return
    document.add_heading("维度成绩", level=2)
    table = document.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    _set_table_geometry(table, [6900, 2460])
    _shade_cell(table.cell(0, 0), "E8EEF5")
    _shade_cell(table.cell(0, 1), "E8EEF5")
    _set_cell_text(table.cell(0, 0), "评估维度", bold=True, color="1F3A5F")
    _set_cell_text(table.cell(0, 1), "得分", bold=True, color="1F3A5F", align=WD_ALIGN_PARAGRAPH.CENTER)
    for name, score in dimensions.items():
        cells = table.add_row().cells
        _set_cell_text(cells[0], name)
        _set_cell_text(cells[1], f"{score:g}", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    _set_table_geometry(table, [6900, 2460])


def _add_labeled_paragraph(document: Document, label: str, values: list[str], fallback: str) -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(5)
    _set_run_font(paragraph.add_run(f"{label}："), size=10.5, bold=True, color="1F3A5F")
    _set_run_font(paragraph.add_run("；".join(values) if values else fallback), size=10.5)


def _add_questions(document: Document, report: dict) -> None:
    questions = report.get("questions") or []
    if not questions:
        return
    document.add_heading("逐题证据摘要", level=2)
    for item in questions:
        title = document.add_paragraph()
        title.paragraph_format.keep_with_next = True
        title.paragraph_format.space_before = Pt(7)
        title.paragraph_format.space_after = Pt(3)
        _set_run_font(
            title.add_run(f"{item['modality_label']} · 第{item['question_index'] + 1}题"),
            size=10.5,
            bold=True,
            color="2E74B5",
        )
        score = (
            "系统异常 · 0 分"
            if item.get("technical_failure")
            else "待人工审核"
            if item.get("review_required")
            else (f"{item['score']:g}分" if item.get("score") is not None else "未评分")
        )
        question = str(item.get("question") or "")
        if len(question) > 100:
            question = question[:100] + "…"
        _add_labeled_paragraph(document, "题目", [question], "未记录")
        _add_labeled_paragraph(document, "评分", [score], "未评分")
        if item.get("technical_failure"):
            _add_labeled_paragraph(
                document,
                "系统状态",
                [str(item.get("failure_reason") or "自动评分失败")],
                "自动评分失败",
            )
            continue
        _add_labeled_paragraph(document, "命中", item.get("hit_points") or [], "未提取明确命中项")
        _add_labeled_paragraph(document, "遗漏", item.get("missed_points") or [], "未提取明确遗漏项")
        evidence = str(item.get("key_evidence") or item.get("comment") or "")
        if evidence:
            _add_labeled_paragraph(document, "证据", [evidence[:220]], "")


def _add_narrative(document: Document, report: dict) -> None:
    document.add_heading("综合评价", level=2)
    paragraph = document.add_paragraph(
        report.get("comprehensive_evaluation") or _fallback_narrative(report)["comprehensive_evaluation"]
    )
    paragraph.paragraph_format.space_after = Pt(8)
    document.add_heading("录用建议", level=2)
    paragraph = document.add_paragraph(report.get("hiring_advice") or _fallback_narrative(report)["hiring_advice"])
    paragraph.paragraph_format.space_after = Pt(8)


def _add_candidate(document: Document, report: dict) -> None:
    _add_title(document, "候选人评估报告", f"{report['candidate_name']}  |  {report.get('role') or '招聘评估'}")
    _add_status_callout(document, report)
    document.add_paragraph().paragraph_format.space_after = Pt(2)
    _add_metadata(document, report)
    _add_dimensions(document, report)
    document.add_heading("关键结论", level=2)
    _add_labeled_paragraph(document, "优势", report.get("strengths") or [], "暂无充分证据")
    _add_labeled_paragraph(document, "风险", report.get("risks") or [], "暂无明确风险项")
    _add_questions(document, report)
    _add_narrative(document, report)


def build_reports_docx(reports: list[dict], *, role: str = "") -> io.BytesIO:
    if not reports:
        raise ValueError("没有可导出的候选人报告")
    document = Document()
    _configure_document(document)
    if len(reports) > 1:
        _add_title(document, "候选人评估报告汇总", role or "批量招聘评估")
        summary = document.add_paragraph(
            f"共 {len(reports)} 位候选人，其中正式报告 {sum(1 for item in reports if item.get('is_formal'))} 份，"
            f"草稿或未完成报告 {sum(1 for item in reports if not item.get('is_formal'))} 份。"
        )
        summary.paragraph_format.space_after = Pt(12)
        table = document.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        widths = [2500, 1900, 2300, 2660]
        for index, title in enumerate(("候选人", "成绩", "报告状态", "录用等级")):
            _shade_cell(table.cell(0, index), "E8EEF5")
            _set_cell_text(table.cell(0, index), title, bold=True, color="1F3A5F")
        for report in reports:
            cells = table.add_row().cells
            score = "—" if report.get("score") is None else f"{report['score']:g}"
            if report.get("score_status") == "provisional":
                score += "（暂定）"
            for index, value in enumerate(
                (report["candidate_name"], score, report["report_status"], report["recommendation"])
            ):
                _set_cell_text(cells[index], value, align=WD_ALIGN_PARAGRAPH.CENTER if index == 1 else None)
        _set_table_geometry(table, widths)
        document.add_page_break()

    for index, report in enumerate(reports):
        if index:
            document.add_page_break()
        _add_candidate(document, report)

    output = io.BytesIO()
    document.save(output)
    output.seek(0)
    return output


def build_pipeline_reports_docx(pipeline_id: str, candidate_ids: list[str] | None = None) -> io.BytesIO:
    reports = list_reports(pipeline_id)
    selected_ids = {str(item) for item in candidate_ids or [] if str(item)}
    if selected_ids:
        reports = [item for item in reports if item.get("candidate_id") in selected_ids]
    pipeline = get_pipeline(pipeline_id) or {}
    return build_reports_docx(reports, role=str(pipeline.get("role") or ""))
