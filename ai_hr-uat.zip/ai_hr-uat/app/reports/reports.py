"""Recruitment Report Generator — daily/weekly automated reports.

Generates structured recruitment activity reports from pipeline data.
Can be triggered by cron job or called manually.

Usage:
    python -m app.reports daily    # 今日招聘日报
    python -m app.reports weekly   # 本周招聘周报
    python -m app.reports summary  # 全量汇总
"""

import json
import sys
from datetime import datetime, timedelta
from typing import Any

sys.path.insert(0, ".")
from app.db import get_db


def _query(sql: str, params: tuple = ()) -> list[dict]:
    """Execute query and return list of dicts."""
    conn = get_db()
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def _count(sql: str, params: tuple = ()) -> int:
    """Execute count query."""
    conn = get_db()
    row = conn.execute(sql, params).fetchone()
    return row[0] if row else 0


def generate_daily_report(date: str = "") -> dict[str, Any]:
    """
    Generate daily recruitment activity report.

    Args:
        date: ISO date string (YYYY-MM-DD), defaults to today.

    Returns:
        Structured report dict.
    """
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")

    next_date = (datetime.strptime(date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")

    # 今日创建的流水线
    new_pipelines = _query(
        "SELECT id, role, status FROM pipelines WHERE created_at >= %s AND created_at < %s", (date, next_date)
    )

    # 今日有活动的流水线（完成过阶段）
    active_stages = _query(
        """SELECT ps.pipeline_id, ps.stage_id, ps.stage_name, ps.status,
                  p.role
           FROM pipeline_stages ps
           JOIN pipelines p ON p.id = ps.pipeline_id
           WHERE ps.completed_at >= %s AND ps.completed_at < %s""",
        (date, next_date),
    )

    # 今日新增候选人
    new_candidates = _query(
        """SELECT c.id, c.name, c.pipeline_id, c.overall_score, c.status,
                  p.role
           FROM candidates c
           JOIN pipelines p ON p.id = c.pipeline_id
           WHERE c.created_at >= %s AND c.created_at < %s""",
        (date, next_date),
    )

    # 今日入围候选人
    shortlisted = [c for c in new_candidates if c.get("status") == "shortlisted"]

    # 今日消息
    msg_count = _count("SELECT COUNT(*) FROM messages WHERE created_at >= %s AND created_at < %s", (date, next_date))

    report = {
        "type": "daily",
        "date": date,
        "summary": {
            "new_pipelines": len(new_pipelines),
            "active_stages": len(active_stages),
            "new_candidates": len(new_candidates),
            "shortlisted": len(shortlisted),
            "messages": msg_count,
        },
        "new_pipelines": [{"id": p["id"], "role": p["role"], "status": p["status"]} for p in new_pipelines],
        "completed_stages": [
            {"pipeline": s["pipeline_id"], "role": s["role"], "stage": s["stage_name"], "status": s["status"]}
            for s in active_stages
        ],
        "new_candidates": [
            {"name": c["name"], "role": c["role"], "score": c["overall_score"], "status": c["status"]}
            for c in new_candidates
        ],
    }

    return report


def generate_weekly_report(end_date: str = "") -> dict[str, Any]:
    """
    Generate weekly recruitment report (last 7 days).

    Args:
        end_date: ISO date string, defaults to today.

    Returns:
        Structured weekly report dict.
    """
    if not end_date:
        end_date = datetime.now().strftime("%Y-%m-%d")

    start_date = (datetime.strptime(end_date, "%Y-%m-%d") - timedelta(days=7)).strftime("%Y-%m-%d")
    next_date = (datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")

    # 本周所有流水线
    pipelines = _query(
        "SELECT id, role, status, created_at FROM pipelines WHERE created_at >= %s AND created_at < %s",
        (start_date, next_date),
    )

    # 流水线状态分布
    status_counts = {}
    for p in pipelines:
        s = p["status"]
        status_counts[s] = status_counts.get(s, 0) + 1

    # 本周所有候选人
    candidates = _query(
        """SELECT c.id, c.name, c.pipeline_id, c.overall_score, c.status,
                  c.tech_score, c.experience_score, p.role
           FROM candidates c
           JOIN pipelines p ON p.id = c.pipeline_id
           WHERE c.created_at >= %s AND c.created_at < %s""",
        (start_date, next_date),
    )

    # 评分分布
    score_ranges = {"80+": 0, "60-80": 0, "50-60": 0, "<50": 0}
    for c in candidates:
        score = c.get("overall_score", 0)
        if score >= 80:
            score_ranges["80+"] += 1
        elif score >= 60:
            score_ranges["60-80"] += 1
        elif score >= 50:
            score_ranges["50-60"] += 1
        else:
            score_ranges["<50"] += 1

    # 高分候选人
    top_candidates = sorted(candidates, key=lambda x: x.get("overall_score", 0), reverse=True)[:5]

    # 已完成流水线
    completed = [p for p in pipelines if p["status"] == "completed"]

    report = {
        "type": "weekly",
        "period": f"{start_date} ~ {end_date}",
        "summary": {
            "total_pipelines": len(pipelines),
            "completed_pipelines": len(completed),
            "total_candidates": len(candidates),
            "avg_score": round(sum(c.get("overall_score", 0) for c in candidates) / max(len(candidates), 1), 1),
        },
        "pipeline_status": status_counts,
        "score_distribution": score_ranges,
        "top_candidates": [{"name": c["name"], "role": c["role"], "score": c["overall_score"]} for c in top_candidates],
        "pipelines": [{"id": p["id"], "role": p["role"], "status": p["status"]} for p in pipelines],
    }

    return report


def generate_summary() -> dict[str, Any]:
    """Generate all-time recruitment summary."""
    total_pipelines = _count("SELECT COUNT(*) FROM pipelines")
    total_candidates = _count("SELECT COUNT(*) FROM candidates")
    total_messages = _count("SELECT COUNT(*) FROM messages")

    # 职位分布
    roles = _query("SELECT role, COUNT(*) as count FROM pipelines GROUP BY role ORDER BY count DESC LIMIT 10")

    # 平均评分
    avg_scores = _query(
        "SELECT AVG(overall_score) as avg_score, AVG(tech_score) as avg_tech, "
        "AVG(experience_score) as avg_exp FROM candidates WHERE overall_score > 0"
    )

    # 流水线完成率
    completed = _count("SELECT COUNT(*) FROM pipelines WHERE status = 'completed'")

    return {
        "type": "summary",
        "total_pipelines": total_pipelines,
        "total_candidates": total_candidates,
        "total_messages": total_messages,
        "completion_rate": f"{completed}/{total_pipelines} ({round(completed / max(total_pipelines, 1) * 100)}%)",
        "top_roles": [{"role": r["role"], "count": r["count"]} for r in roles],
        "avg_scores": avg_scores[0] if avg_scores else {},
    }


def format_report_text(report: dict) -> str:
    """Format report dict as readable text for chat delivery."""
    rtype = report.get("type", "unknown")

    if rtype == "daily":
        s = report["summary"]
        lines = [
            f"招聘日报 — {report['date']}",
            "",
            f"新建岗位: {s['new_pipelines']}个",
            f"完成阶段: {s['active_stages']}个",
            f"新增候选人: {s['new_candidates']}人",
            f"入围候选人: {s['shortlisted']}人",
            f"对话消息: {s['messages']}条",
        ]
        if report["new_pipelines"]:
            lines.append("")
            lines.append("新建岗位:")
            for p in report["new_pipelines"]:
                lines.append(f"  - {p['role']} ({p['status']})")
        if report["new_candidates"]:
            lines.append("")
            lines.append("新增候选人:")
            for c in report["new_candidates"]:
                lines.append(f"  - {c['name']} [{c['role']}] {c['score']}分")
        return "\n".join(lines)

    elif rtype == "weekly":
        s = report["summary"]
        lines = [
            f"招聘周报 — {report['period']}",
            "",
            f"招聘岗位: {s['total_pipelines']}个 (完成{s['completed_pipelines']}个)",
            f"评估候选人: {s['total_candidates']}人",
            f"平均综合分: {s['avg_score']}分",
        ]
        dist = report.get("score_distribution", {})
        if any(dist.values()):
            lines.append("")
            lines.append(
                f"分数分布: 80+:{dist.get('80+', 0)} | 60-80:{dist.get('60-80', 0)} | 50-60:{dist.get('50-60', 0)} | <50:{dist.get('<50', 0)}"
            )
        top = report.get("top_candidates", [])
        if top:
            lines.append("")
            lines.append("TOP候选人:")
            for c in top:
                lines.append(f"  - {c['name']} [{c['role']}] {c['score']}分")
        return "\n".join(lines)

    elif rtype == "summary":
        lines = [
            "招聘系统总览",
            "",
            f"累计岗位: {report['total_pipelines']}个",
            f"累计候选人: {report['total_candidates']}人",
            f"完成率: {report['completion_rate']}",
            f"对话消息: {report['total_messages']}条",
        ]
        roles = report.get("top_roles", [])
        if roles:
            lines.append("")
            lines.append("热门岗位:")
            for r in roles[:5]:
                lines.append(f"  - {r['role']}: {r['count']}次")
        return "\n".join(lines)

    return json.dumps(report, ensure_ascii=False, indent=2)


# CLI 入口
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Recruitment Report Generator")
    parser.add_argument("type", choices=["daily", "weekly", "summary"], help="Report type")
    parser.add_argument("--date", help="Report date (YYYY-MM-DD)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    if args.type == "daily":
        report = generate_daily_report(args.date)
    elif args.type == "weekly":
        report = generate_weekly_report(args.date)
    else:
        report = generate_summary()

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(format_report_text(report))
