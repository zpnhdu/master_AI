"""Persistent background jobs for pipeline-level hiring reports."""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Any

from app.db import get_db
from app.state import get_action_handler

logger = logging.getLogger(__name__)

_RUNNING_TASKS: dict[str, asyncio.Task] = {}
_TABLE_READY = False


def _ensure_table() -> None:
    global _TABLE_READY
    if _TABLE_READY:
        return
    database = get_db()
    database.execute(
        """CREATE TABLE IF NOT EXISTS aggregate_report_jobs (
            id VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            status VARCHAR(191) NOT NULL DEFAULT 'queued',
            passed_only INTEGER NOT NULL DEFAULT 1,
            progress INTEGER NOT NULL DEFAULT 0,
            result_json LONGTEXT NOT NULL,
            message LONGTEXT NOT NULL,
            error_code VARCHAR(191) NOT NULL DEFAULT '',
            error_message LONGTEXT NOT NULL,
            created_at VARCHAR(191) DEFAULT (NOW()),
            started_at VARCHAR(191),
            completed_at VARCHAR(191),
            updated_at VARCHAR(191) DEFAULT (NOW()),
            FOREIGN KEY (pipeline_id) REFERENCES pipelines(id)
        )"""
    )
    database.commit()
    _TABLE_READY = True


def _decode_json(value: Any) -> dict:
    if isinstance(value, dict):
        return value
    if not isinstance(value, str) or not value.strip():
        return {}
    try:
        parsed = json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _serialize(row) -> dict | None:
    if not row:
        return None
    job = dict(row)
    job["passed_only"] = bool(job.get("passed_only"))
    job["result"] = _decode_json(job.pop("result_json", "{}"))
    return job


def get_job(job_id: str) -> dict | None:
    _ensure_table()
    row = get_db().execute("SELECT * FROM aggregate_report_jobs WHERE id=%s", (job_id,)).fetchone()
    return _serialize(row)


def get_latest_job(pipeline_id: str) -> dict | None:
    _ensure_table()
    row = (
        get_db()
        .execute(
            """SELECT * FROM aggregate_report_jobs
               WHERE pipeline_id=%s ORDER BY created_at DESC, id DESC LIMIT 1""",
            (pipeline_id,),
        )
        .fetchone()
    )
    return _serialize(row)


def create_job(pipeline_id: str, *, passed_only: bool = True) -> tuple[dict, bool]:
    """Create a job, or return the currently active job for this pipeline."""
    _ensure_table()
    database = get_db()
    active = database.execute(
        """SELECT * FROM aggregate_report_jobs
           WHERE pipeline_id=%s AND status IN ('queued', 'running')
           ORDER BY created_at DESC, id DESC LIMIT 1""",
        (pipeline_id,),
    ).fetchone()
    if active:
        return _serialize(active), False

    created_key = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
    job_id = f"aggregate_report_job_{created_key}_{uuid.uuid4().hex}"
    # MySQL schema translation removes defaults from LONGTEXT columns. Keep all
    # NOT NULL text fields explicit so this also works with already-created tables.
    database.execute(
        """INSERT INTO aggregate_report_jobs
           (id, pipeline_id, status, passed_only, progress, result_json,
            message, error_code, error_message)
           VALUES (%s, %s, 'queued', %s, 5, %s, %s, %s, %s)""",
        (job_id, pipeline_id, int(passed_only), "{}", "", "", ""),
    )
    database.commit()
    return get_job(job_id), True


def _claim_job(job_id: str) -> bool:
    database = get_db()
    cursor = database.execute(
        """UPDATE aggregate_report_jobs
           SET status='running', progress=20, started_at=NOW(), updated_at=NOW(),
               error_code='', error_message=''
           WHERE id=%s AND status='queued'""",
        (job_id,),
    )
    database.commit()
    return cursor.rowcount == 1


def _finish_job(
    job_id: str,
    *,
    status: str,
    result: dict | None = None,
    message: str = "",
    error: Exception | None = None,
) -> None:
    database = get_db()
    error_message = str(error)[:500] if error else ""
    database.execute(
        """UPDATE aggregate_report_jobs
           SET status=%s, progress=%s, result_json=%s, message=%s, error_code=%s, error_message=%s,
               completed_at=NOW(), updated_at=NOW()
           WHERE id=%s""",
        (
            status,
            100 if status == "succeeded" else 0,
            json.dumps(result or {}, ensure_ascii=False),
            message,
            "generation_failed" if error else "",
            error_message,
            job_id,
        ),
    )
    database.commit()


async def run_job(job_id: str) -> None:
    job = get_job(job_id)
    if not job or not _claim_job(job_id):
        return
    try:
        result = await get_action_handler().handle_action(
            job["pipeline_id"],
            "chat",
            {
                "message": "生成通过候选人综合评估报告",
                "stage_id": "report",
                "context": {"passed_only": job["passed_only"]},
            },
        )
        if not isinstance(result, dict):
            raise RuntimeError("aggregate report handler returned an invalid response")
        report = result.get("report") or result.get("report_data")
        message = str(result.get("message") or result.get("reply") or "")
        _finish_job(job_id, status="succeeded", result=result, message=message)
        if not report:
            logger.info("Aggregate report job completed without report data: %s", job_id)
    except Exception as error:  # noqa: BLE001
        logger.exception("Aggregate report job failed: %s", job_id)
        _finish_job(job_id, status="failed", error=error)


def schedule_job(job_id: str) -> None:
    existing = _RUNNING_TASKS.get(job_id)
    if existing and not existing.done():
        return
    task = asyncio.get_running_loop().create_task(run_job(job_id))
    _RUNNING_TASKS[job_id] = task

    def cleanup(completed: asyncio.Task) -> None:
        if _RUNNING_TASKS.get(job_id) is completed:
            _RUNNING_TASKS.pop(job_id, None)

    task.add_done_callback(cleanup)


def list_recoverable_job_ids() -> list[str]:
    _ensure_table()
    # The report business deadline is 120 seconds. A running row older than
    # three minutes can only belong to an interrupted worker.
    stale_before = (datetime.utcnow() - timedelta(minutes=3)).strftime("%Y-%m-%d %H:%M:%S")
    database = get_db()
    database.execute(
        """UPDATE aggregate_report_jobs
           SET status='queued', progress=5, started_at=NULL, updated_at=NOW()
           WHERE status='running' AND started_at<=%s""",
        (stale_before,),
    )
    database.commit()
    rows = database.execute(
        "SELECT id FROM aggregate_report_jobs WHERE status='queued' ORDER BY created_at, id"
    ).fetchall()
    return [str(row["id"]) for row in rows]
