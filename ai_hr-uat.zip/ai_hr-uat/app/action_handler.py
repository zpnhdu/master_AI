"""Action Handler - LLM-powered intent processing with knowledge base"""

from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime

from app.audit.logger import get_logger
from app.db import (
    get_candidates,
    get_company_config,
    get_messages,
    get_pipeline,
    get_stages,
    save_message,
    update_candidate,
    update_stage,
)
from app.infrastructure.timeout_policy import TimeoutDeadline, get_agent_timeout
from app.jd_workspace import JD_STAGE_DEPENDENCIES
from app.state import broadcast
from app.xiao_wen_context import attach_agent_runtime_config, build_xiao_wen_context
from hr_harness.tool_protocol import ToolInput

logger = get_logger("action_handler")

WRITTEN_SCORING_MAX_RETRIES = 3
WRITTEN_SCORING_RETRY_BASE_DELAY_SECONDS = 1.0
JD_NO_OP_OFF_TOPIC_KEYWORDS = (
    "天气",
    "气温",
    "温度",
    "下雨",
    "晴天",
    "阴天",
    "空气质量",
    "风力",
    "湿度",
)
JD_NO_OP_MESSAGES = {
    "off_topic": "天气可以聊，不过我现在主要帮你完善招聘 JD。你想调整岗位职责、任职要求、薪资福利，还是团队介绍？",
    "unchanged": "这部分和当前 JD 看起来差不多，我还没找到需要调整的地方。你可以告诉我想增加、删除或改写哪一项。",
    "unclear": "我明白你想继续调整这份 JD，不过还不确定你想改哪部分。比如工作地点、岗位职责、任职要求或福利待遇？",
}


def _jd_no_op_reason(instruction: str, patch: dict) -> str:
    if any(keyword in instruction for keyword in JD_NO_OP_OFF_TOPIC_KEYWORDS):
        return "off_topic"
    if patch.get("changes"):
        return "unchanged"
    return "unclear"


def _jd_no_op_message(reason: str) -> str:
    return JD_NO_OP_MESSAGES.get(reason, JD_NO_OP_MESSAGES["unclear"])


class ActionHandler:
    """Process user actions through agent pipeline — LLM calls routed to agents."""

    def __init__(self):
        from hermes_wrapper.client import get_client

        self.llm = get_client()
        from knowledge import KnowledgeBase

        self.kb = KnowledgeBase()

    @staticmethod
    def _jd_locked_error(pipeline: dict) -> dict:
        """Return the stable action response used for immutable JD operations."""
        return {
            "code": "jd_locked",
            "error": "JD已锁定，请新建岗位后修改",
            "locked_at": pipeline.get("jd_locked_at") or "",
            "locked_by_stage": pipeline.get("jd_locked_by_stage") or "",
            "reply": "当前 JD 已锁定，请新建岗位后修改。",
        }

    async def _call_llm_json(
        self,
        prompt: str,
        system: str = "",
        model: str = "qwen3.6-flash",
        timeout: int = 60,
        json_mode: bool = False,
        agent_id: str | None = None,
        deadline: TimeoutDeadline | None = None,
        temperature: float | None = None,
    ) -> dict:
        """Route LLM JSON call through the appropriate agent for traceability."""
        from hr_harness.agents.base import BaseAgent

        if deadline is None and agent_id:
            deadline = TimeoutDeadline(get_agent_timeout(agent_id), agent_id=agent_id)

        agent = BaseAgent()
        input_data = ToolInput(
            pipeline_id="action_handler",
            params={
                "raw_prompt": prompt,
                "raw_system": system,
                "model": model,
                "timeout": timeout,
                "temperature": 0.3 if temperature is None else temperature,
                "json_mode": json_mode,
                "deadline": deadline,
                "agent_id": agent_id,
                "operation": agent_id,
            },
        )
        result = await agent.run_with_deadline(input_data, deadline) if deadline else await agent.run(input_data)
        # Token 收口：BaseAgent.run → hermes_wrapper.client 已记录真实 usage 与耗时，此处不再重复打点
        if result.status.value == "failed":
            raise Exception(result.error or "Agent call failed")
        return result.data

    async def handle_action(self, pipeline_id: str, action: str, data: dict = None) -> dict:
        """Handle user action on a card"""
        data = data or {}
        pipeline = get_pipeline(pipeline_id)
        if not pipeline:
            return {"error": "Pipeline not found"}

        stages = get_stages(pipeline_id)
        candidates = get_candidates(pipeline_id)

        if action == "edit_jd":
            return await self._handle_edit_jd(pipeline_id, pipeline, stages, data)
        elif action == "shortlist_candidate":
            return await self._handle_candidate_action(
                pipeline_id, data.get("candidate_id"), "shortlisted", data.get("reason", "")
            )
        elif action == "reject_candidate":
            return await self._handle_candidate_action(
                pipeline_id, data.get("candidate_id"), "rejected", data.get("reason", "")
            )
        elif action == "view_candidate":
            return await self._handle_view_candidate(pipeline_id, data.get("candidate_id"), candidates)
        elif action == "export_interviews":
            return await self._handle_export_interviews(pipeline_id, stages)
        elif action == "export_report":
            return await self._handle_export_report(pipeline_id, stages, candidates)
        elif action == "export_chat":
            return await self._handle_export_chat(pipeline_id)
        elif action == "export_exam":
            return await self._handle_export_exam(pipeline_id, stages)
        elif action == "regenerate_jd":
            return await self._handle_regenerate_jd(pipeline_id, pipeline, stages, data)
        elif action == "submit_answers":
            return await self._handle_submit_answers(pipeline_id, pipeline, stages, candidates, data)
        elif action == "reevaluate":
            return await self._handle_reevaluate(pipeline_id, pipeline, stages, candidates, data)
        elif action == "chat":
            stage_id = data.get("stage_id", "")
            context = data.get("context", {}) or {}
            # JD 生成模式：阶段为 jd_write 且上下文指定 generate_jd
            if stage_id == "jd_write" and context.get("mode") == "generate_jd":
                return await self._handle_generate_jd_from_chat(pipeline_id, pipeline, stages, data.get("message", ""))
            # 报告生成：为保证可靠性，绕过 LLM 意图分类器
            if stage_id == "report":
                return await self._handle_generate_report(
                    pipeline_id,
                    pipeline,
                    stages,
                    candidates,
                    "",
                    passed_only=bool(context.get("passed_only")),
                )
            # 面试生成：结构化入口绕过 LLM 意图分类器，保证批量和单候选人链路一致
            if stage_id == "interview_gen" and (context.get("batch") or context.get("candidate_id")):
                from app.screening_workflow import get_screening_context

                match_data = get_screening_context(pipeline_id)["output"]
                interview_data = self._get_stage_output(stages, "interview_gen").get("interviews", [])
                return await self._handle_generate_interview(
                    pipeline_id,
                    pipeline,
                    stages,
                    candidates,
                    interview_data,
                    match_data,
                    "",
                    context.get("candidate_id") or None,
                )
            return await self._handle_chat(pipeline_id, pipeline, stages, candidates, data.get("message", ""))
        else:
            return {"error": f"Unknown action: {action}"}

    def _get_stage_output(self, stages: list, stage_id: str) -> dict:
        """Extract output from a specific stage"""
        for s in stages:
            if s["stage_id"] == stage_id:
                raw = s.get("output")
                if raw:
                    if isinstance(raw, str):
                        try:
                            parsed = json.loads(raw)
                            return parsed if isinstance(parsed, dict) else {}
                        except (json.JSONDecodeError, TypeError):
                            return {}
                    elif isinstance(raw, dict):
                        return raw
                return {}
        return {}

    # ============ JD 变更检测 + 级联提示 ============

    JD_CASCADE_MAP = {field: sorted(stages) for field, stages in JD_STAGE_DEPENDENCIES.items()}

    def _detect_jd_changes(self, old_jd: dict, new_jd: dict) -> dict:
        """对比新旧 JD，返回 {field: {"old": x, "new": y}}"""
        changes = {}
        all_keys = set(list(old_jd.keys()) + list(new_jd.keys()))
        for key in all_keys:
            old_val = old_jd.get(key)
            new_val = new_jd.get(key)
            if old_val != new_val:
                changes[key] = {"old": old_val, "new": new_val}
        return changes

    async def _cascade_downstream(self, pipeline_id: str, pipeline: dict, new_jd: dict, changes: dict) -> list:
        """Return completed stages affected by a JD edit and notify the user."""
        del pipeline, new_jd
        completed = {s["stage_id"] for s in get_stages(pipeline_id) if s.get("status") == "done"}
        affected = {
            stage_id for field in changes for stage_id in self.JD_CASCADE_MAP.get(field, []) if stage_id in completed
        }
        result = sorted(affected)
        if result:
            names = {
                "profile_build": "职位画像",
                "poster_gen": "招聘海报",
                "match": "AI匹配",
                "interview_gen": "面试题",
                "video_assess": "视频评估",
                "report": "录用报告",
            }
            save_message(
                pipeline_id,
                "assistant",
                f"💡 JD变更可能影响：{'、'.join(names.get(stage, stage) for stage in result)}，如需更新请手动重新生成。",
            )
        return result

    async def _handle_edit_jd(self, pipeline_id: str, pipeline: dict, stages: list, data: dict) -> dict:
        if pipeline.get("jd_locked_at"):
            return self._jd_locked_error(pipeline)
        edit_instruction = data.get("instruction", "").strip()
        if not edit_instruction:
            return {"error": "请提供JD修改要求"}
        old_jd = self._get_stage_output(stages, "jd_write").get("jd", {})
        preview = await self.preview_jd_edit(pipeline_id, edit_instruction)
        if preview.get("status") == "no_op":
            return {
                "status": "no_op",
                "type": "jd_unchanged",
                "message": preview.get("message", "没有检测到可修改的JD字段"),
                "no_op_reason": preview.get("no_op_reason", "unclear"),
            }
        new_jd = preview.get("jd")
        if not new_jd:
            return {"error": preview.get("error", "JD修改失败，请重试")}

        jd_output = self._get_stage_output(stages, "jd_write")
        changes = self._detect_jd_changes(old_jd, new_jd)
        if not data.get("confirmed"):
            return {
                "status": "preview",
                "type": "jd_revision_preview",
                "jd": new_jd,
                "changed_fields": list(changes),
                "message": "修改建议已生成，确认后才会覆盖当前草稿。",
            }

        from app import jd_workspace

        try:
            output = jd_workspace.save_draft(
                pipeline_id,
                new_jd,
                expected_revision=int(jd_output.get("revision") or 0),
                source="ai_revision",
            )
        except jd_workspace.RevisionConflictError as error:
            return {"error": f"JD已被更新，请刷新后重试（当前版本：{error.current_revision}）"}
        except jd_workspace.JdLockedError as error:
            return {
                **self._jd_locked_error(pipeline),
                "locked_at": error.locked_at,
                "locked_by_stage": error.locked_by_stage,
            }
        affected = await self._cascade_downstream(pipeline_id, pipeline, new_jd, changes)
        if changes:
            from hr_harness.memory.core import MemorySystem

            MemorySystem(pipeline_id).learn_from_jd_edit(
                pipeline.get("role", ""), "edit_jd", ", ".join(changes), changes
            )
        save_message(
            pipeline_id,
            "assistant",
            f"JD已修改：{edit_instruction}",
            card_type="jd_card",
            card_data={"jd": output["jd"], "pipeline_id": pipeline_id},
        )
        return {"status": "success", "type": "jd_updated", "jd": output["jd"], "cascaded": affected}

    async def preview_jd_edit(self, pipeline_id: str, edit_instruction: str) -> dict:
        pipeline = get_pipeline(pipeline_id)
        if not pipeline:
            return {"error": "Pipeline not found"}
        if pipeline.get("jd_locked_at"):
            return self._jd_locked_error(pipeline)
        stages = get_stages(pipeline_id)
        current_jd = self._get_stage_output(stages, "jd_write").get("jd", {})
        if not current_jd:
            return {"error": "找不到当前JD数据"}

        kb_ctx = self.kb.get_context_for_intent("edit_jd", edit_instruction)

        system = f"""你是一个JD编辑助手。根据HR的修改要求，生成结构化字段修改建议。
只允许修改这些字段：title、department、location、salary_range、work_hours、responsibilities、requirements、tech_stack、benefits、team_intro。
只修改HR明确提到的字段，不要猜测或扩展修改范围。
如果输入不是JD修改要求，输出 {{"changes": []}}。
必须只输出JSON，不要输出其他文字。
{kb_ctx}"""

        prompt = f"""当前JD（JSON）：
{json.dumps(current_jd, ensure_ascii=False, indent=2)}

HR修改要求：{edit_instruction}

请只输出字段修改Patch，格式为：
{{"changes": [{{"field": "location", "value": "上海"}}]}}
如果没有明确的JD字段修改，输出 {{"changes": []}}。
只输出JSON，不要任何其他文字："""

        runtime_config = attach_agent_runtime_config({}, "jd_write")
        new_jd = await self._call_llm_json(
            prompt,
            system,
            runtime_config.get("model") or "qwen-plus",
            json_mode=True,
            agent_id="jd_write",
            temperature=runtime_config.get("temperature"),
        )

        if isinstance(new_jd, dict) and not new_jd.get("parse_error"):
            from app.jd_workspace import apply_jd_patch

            try:
                merged_jd, changed_fields = apply_jd_patch(current_jd, new_jd)
            except ValueError as error:
                return {"error": str(error)}
            if not changed_fields:
                no_op_reason = _jd_no_op_reason(edit_instruction, new_jd)
                return {
                    "status": "no_op",
                    "jd": current_jd,
                    "changed_fields": [],
                    "no_op_reason": no_op_reason,
                    "message": _jd_no_op_message(no_op_reason),
                }
            return {"status": "preview", "jd": merged_jd, "changed_fields": changed_fields}
        return {"error": "JD修改失败，AI返回格式异常，请重试或换个表述"}

    async def _handle_candidate_action(self, pipeline_id: str, candidate_id: str, action: str, reason: str) -> dict:
        if not candidate_id:
            return {"error": "No candidate_id"}
        update_candidate(candidate_id, {"status": action})
        from app.db import save_learning

        save_learning("feedback", f"decision_{candidate_id}", f"{action}: {reason}", 0.7)
        action_text = "入围" if action == "shortlisted" else "淘汰"
        save_message(
            pipeline_id, "assistant", f"候选人 {candidate_id} 已{action_text}" + (f"（{reason}）" if reason else "")
        )
        return {
            "status": "success",
            "type": "candidate_updated",
            "candidate_id": candidate_id,
            "action": action,
            "message": f"已标记为{action_text}，已学习你的偏好",
        }

    async def _handle_view_candidate(self, pipeline_id: str, candidate_id: str, candidates: list) -> dict:
        cand = None
        for c in candidates:
            if c["id"] == candidate_id:
                cand = c
                break
        if not cand:
            return {"error": "Candidate not found"}

        video = cand.get("video_assessment", {})
        if isinstance(video, str):
            try:
                video = json.loads(video)
            except:
                video = {}

        system = """你是一个资深HR顾问，根据候选人数据生成详细的候选人评估报告。
包含：个人画像、技术能力雷达图数据、面试建议、薪资谈判策略、入职风险评估。输出JSON格式。"""

        prompt = f"""候选人数据：
{json.dumps(cand, ensure_ascii=False, indent=2)}

视频面试评估：
{json.dumps(video, ensure_ascii=False, indent=2)}

请生成详细评估报告（JSON）：
{{
    "profile_summary": "100字个人画像",
    "strengths_analysis": ["优势1详细分析", "优势2详细分析", "优势3详细分析"],
    "weaknesses_analysis": ["不足1及应对建议", "不足2及应对建议"],
    "tech_radar": {{"前端基础": 数字, "架构能力": 数字, "工程化": 数字, "性能优化": 数字, "团队协作": 数字}},
    "interview_strategy": "面试策略建议（100字）",
    "salary_analysis": {{"market_range": "市场薪资范围", "suggested_offer": "建议offer", "negotiation_room": "谈判空间", "strategy": "谈判策略"}},
    "onboarding_risk": "入职风险评估（50字）",
    "culture_fit_detail": "文化匹配度详细分析（80字）",
    "final_verdict": "最终建议（一句话）"
}}"""

        result = await self._call_llm_json(prompt, system, "qwen-plus", timeout=120)
        if isinstance(result, dict) and result.get("parse_error"):
            # LLM 返回的不是 JSON，尝试从原始文本提取有效信息
            raw = result.get("raw", "")
            return {
                "status": "success",
                "type": "candidate_detail",
                "candidate": cand,
                "detail": {"profile_summary": raw[:500] if raw else "详情生成失败，请重试"},
                "video_assessment": video,
            }
        return {
            "status": "success",
            "type": "candidate_detail",
            "candidate": cand,
            "detail": result if isinstance(result, dict) else {},
            "video_assessment": video,
        }

    async def _handle_export_interviews(self, pipeline_id: str, stages: list) -> dict:
        interview_data = self._get_stage_output(stages, "interview_gen").get("interviews", [])
        if not interview_data:
            return {"error": "No interview data"}

        md_lines = ["# 面试题手册\n"]
        for iv in interview_data:
            md_lines.append(f"## {iv.get('candidate_name', '')}\n")
            if iv.get("interview_strategy"):
                md_lines.append(f"**面试策略：** {iv['interview_strategy']}\n")
            for i, q in enumerate(iv.get("questions", []), 1):
                md_lines.append(f"### Q{i}: {q.get('type', '')} ({q.get('difficulty', '')})\n")
                md_lines.append(f"**题目：** {q.get('question', '')}\n")
                if q.get("follow_up"):
                    md_lines.append(f"**追问：** {q['follow_up']}\n")
                if q.get("expected_points"):
                    md_lines.append("**期望要点：**")
                    for p in q["expected_points"]:
                        md_lines.append(f"- {p}")
                md_lines.append("")

        markdown = "\n".join(md_lines)
        filepath = os.path.join(os.path.dirname(__file__), "..", "data", f"interviews_{pipeline_id}.md")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(markdown)

        save_message(pipeline_id, "assistant", f"面试题已导出：{filepath}")
        return {
            "status": "success",
            "type": "export_done",
            "filepath": filepath,
            "content": markdown,
            "message": "面试题已导出为Markdown文件",
        }

    async def _handle_export_report(self, pipeline_id: str, stages: list, candidates: list) -> dict:
        report_data = self._get_stage_output(stages, "report").get("report", {})
        if not report_data:
            return {"error": "No report data"}

        md = ["# 录用决策报告\n"]
        md.append(f"## 执行摘要\n{report_data.get('executive_summary', '')}\n")
        md.append("## 候选人排序\n")
        for r in report_data.get("ranking", []):
            md.append(
                f"### #{r.get('rank', '')} {r.get('name', '')} - {r.get('final_score', r.get('overall_score', ''))}分\n"
            )
            md.append(f"**建议：** {r.get('recommendation', '')}\n")
            md.append(f"**优势：** {', '.join(r.get('key_strengths', []))}\n")
            md.append("")

        markdown = "\n".join(md)
        filepath = os.path.join(os.path.dirname(__file__), "..", "data", f"report_{pipeline_id}.md")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(markdown)

        save_message(pipeline_id, "assistant", f"录用报告已导出：{filepath}")
        return {
            "status": "success",
            "type": "export_done",
            "filepath": filepath,
            "content": markdown,
            "message": "录用报告已导出为Markdown文件",
        }

    async def _handle_export_chat(self, pipeline_id: str) -> dict:
        """Export all chat messages for a pipeline as Markdown"""
        messages = get_messages(pipeline_id, limit=500)
        if not messages:
            return {"error": "No chat messages found"}

        pipeline = get_pipeline(pipeline_id)
        role = pipeline["role"] if pipeline else "unknown"

        md = [f"# {role} - 对话记录\n"]
        md.append(f"导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        md.append(f"消息总数：{len(messages)}\n")
        md.append("---\n")

        for msg in messages:
            role_label = {"user": "👤 HR", "assistant": "🤖 锅圈食汇", "system": "⚠️ 系统"}.get(msg["role"], msg["role"])
            ts = msg.get("created_at", "")
            content = msg.get("content", "")
            card_type = msg.get("card_type", "")

            md.append(f"### {role_label}  ")
            if ts:
                md.append(f"_{ts}_\n")
            md.append(f"{content}\n")
            if card_type:
                md.append(f"_卡片类型：{card_type}_\n")
            md.append("")

        markdown = "\n".join(md)
        filepath = os.path.join(os.path.dirname(__file__), "..", "data", f"chat_{pipeline_id}.md")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(markdown)

        save_message(pipeline_id, "assistant", f"对话记录已导出：{filepath}")
        return {
            "status": "success",
            "type": "export_done",
            "filepath": filepath,
            "content": markdown,
            "message": f"对话记录已导出为Markdown文件（{len(messages)}条消息）",
        }

    async def _handle_export_exam(self, pipeline_id: str, stages: list) -> dict:
        """Export exam questions from interview stage as Markdown"""
        # 优先查找 exam_card 消息（consolidate_exam 输出）
        messages = get_messages(pipeline_id, limit=200)
        exam_data = None
        for msg in messages:
            if msg.get("card_type") == "exam_card":
                card = msg.get("card_data", {})
                if isinstance(card, str):
                    card = json.loads(card)
                exam_data = card.get("exam", card)
                break

        # 降级处理：从阶段中提取面试问题
        if not exam_data:
            interview_output = self._get_stage_output(stages, "interview_gen")
            interviews = interview_output.get("interviews", [])
            if not interviews:
                return {"error": "找不到笔试题或面试题数据"}
            # 根据面试问题构建试卷
            all_questions = []
            for iv in interviews:
                for q in iv.get("questions", []):
                    all_questions.append(
                        {
                            "question_number": len(all_questions) + 1,
                            "question": q.get("question", ""),
                            "question_type": q.get("type", "综合题"),
                            "score": 15,
                            "difficulty": q.get("difficulty", "中等"),
                            "sub_questions": [],
                            "grading_criteria": [{"point": p, "score": 5} for p in q.get("expected_points", [])],
                            "reference_answer": "",
                            "source_topics": [],
                            "candidate_name": iv.get("candidate_name", ""),
                        }
                    )
            exam_data = {
                "exam_title": "招聘笔试题（从面试题提取）",
                "exam_description": f"共{len(all_questions)}题，来自{len(interviews)}位候选人的面试题",
                "total_score": sum(q["score"] for q in all_questions),
                "duration_minutes": 90,
                "questions": all_questions,
            }

        questions = exam_data.get("questions", [])
        if not questions:
            return {"error": "笔试题数据为空"}

        md = [f"# {exam_data.get('exam_title', '综合笔试题')}\n"]
        md.append(f"_{exam_data.get('exam_description', '')}_\n")
        md.append(
            f"总分：{exam_data.get('total_score', 100)}分 | 建议时长：{exam_data.get('duration_minutes', 90)}分钟\n"
        )
        md.append("---\n")

        for q in questions:
            num = q.get("question_number", "")
            qtype = q.get("question_type", "综合题")
            score = q.get("score", 0)
            md.append(f"## {num}. [{qtype}] ({score}分)\n")
            md.append(f"{q.get('question', '')}\n")

            subs = q.get("sub_questions", [])
            if subs:
                for si, s in enumerate(subs, 1):
                    md.append(f"  ({si}) {s}")
                md.append("")

            criteria = q.get("grading_criteria", [])
            if criteria:
                md.append("**评分标准：**")
                for c in criteria:
                    md.append(f"- {c.get('point', '')} ({c.get('score', 0)}分)")
                md.append("")

            ref = q.get("reference_answer", "")
            if ref:
                md.append(f"<details><summary>参考答案</summary>\n\n{ref}\n</details>\n")

            topics = q.get("source_topics", [])
            if topics:
                md.append(f"涉及知识点：{', '.join(topics)}\n")
            md.append("")

        markdown = "\n".join(md)
        filepath = os.path.join(os.path.dirname(__file__), "..", "data", f"exam_{pipeline_id}.md")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(markdown)

        save_message(pipeline_id, "assistant", f"笔试题已导出：{filepath}")
        return {
            "status": "success",
            "type": "export_done",
            "filepath": filepath,
            "content": markdown,
            "message": f"笔试题已导出为Markdown文件（{len(questions)}题）",
        }

    async def _handle_regenerate_jd(self, pipeline_id: str, pipeline: dict, stages: list, data: dict) -> dict:
        if pipeline.get("jd_locked_at"):
            return self._jd_locked_error(pipeline)
        from hr_harness.agents.jd_agent import JDAgent
        from hr_harness.memory.core import MemorySystem

        memory = MemorySystem(pipeline_id)
        agent = JDAgent()
        deadline = TimeoutDeadline(get_agent_timeout("jd_write"), agent_id="jd_write")
        context = build_xiao_wen_context(
            pipeline_id=pipeline_id,
            role=pipeline["role"],
            pipeline_type=pipeline.get("type", "general"),
            user_hints=data.get("hints", ""),
            memory_context=memory.build_system_context(),
        )
        context = attach_agent_runtime_config(context, "jd_write")
        tool_output = await agent.run_with_deadline(
            ToolInput(
                pipeline_id=pipeline_id,
                params=context,
            ),
            deadline,
        )
        result = tool_output.data if tool_output.status.value == "success" else {}
        new_jd = result.get("jd", {})
        if not new_jd:
            return {"error": "JD重新生成失败"}

        from app import jd_workspace

        jd_output = self._get_stage_output(stages, "jd_write")
        old_jd = jd_output.get("jd", {})
        changes = self._detect_jd_changes(old_jd, new_jd)
        try:
            output = jd_workspace.save_draft(
                pipeline_id,
                new_jd,
                expected_revision=int(jd_output.get("revision") or 0),
                source="regenerated",
            )
        except jd_workspace.RevisionConflictError as error:
            return {"error": f"JD已被更新，请刷新后重试（当前版本：{error.current_revision}）"}
        except jd_workspace.JdLockedError as error:
            return {
                **self._jd_locked_error(pipeline),
                "locked_at": error.locked_at,
                "locked_by_stage": error.locked_by_stage,
            }
        except (LookupError, ValueError) as error:
            return {"error": str(error)}
        affected = await self._cascade_downstream(pipeline_id, pipeline, new_jd, changes)
        save_message(
            pipeline_id,
            "assistant",
            "JD重新生成了新的草稿，请确认后生效",
            card_type="jd_card",
            card_data={"jd": output["jd"], "pipeline_id": pipeline_id},
        )
        return {"status": "draft", "type": "jd_generated", "jd": output["jd"], "cascaded": affected}

    async def _handle_regenerate_poster(self, pipeline_id: str, pipeline: dict, stages: list) -> dict:
        from hr_harness.agents.poster_agent import PosterAgent

        jd = self._get_stage_output(stages, "jd_write").get("jd", {})
        if not jd:
            return {"error": "找不到 JD 数据，请先生成 JD"}
        agent = PosterAgent()
        company_config = get_company_config()
        try:
            from app.user_mailbox import PipelineHrNotConfiguredError, require_pipeline_hr, resolve_user_qr

            hr_user = require_pipeline_hr(pipeline)
        except PipelineHrNotConfiguredError as exc:
            return {"error": f"{exc}，请先到「用户与权限」配置后重试。"}
        tool_output = await agent.run(
            ToolInput(
                pipeline_id=pipeline_id,
                params={
                    "jd": jd,
                    "role": pipeline["role"],
                    "company_config": company_config,
                    "hr_contact": (hr_user.get("hr_contact") or "").strip(),
                    "hr_qr_code": resolve_user_qr(hr_user),
                },
            )
        )
        result = tool_output.data if tool_output.status.value == "success" else {}
        update_stage(pipeline_id, "poster_gen", "done", result)
        card_data = dict(result)
        card_data["pipeline_id"] = pipeline_id
        save_message(pipeline_id, "assistant", "🎨 招聘海报已重新生成", card_type="poster_card", card_data=card_data)
        return {"status": "success", "type": "poster_updated", "message": "招聘海报已重新生成"}

    # ============ 通过对话生成 JD ============
    async def _handle_generate_jd_from_chat(self, pipeline_id: str, pipeline: dict, stages: list, message: str) -> dict:
        """Generate JD from chat input on xiao_wen page"""
        if pipeline.get("jd_locked_at"):
            return self._jd_locked_error(pipeline)
        from hr_harness.agents.jd_agent import JDAgent
        from hr_harness.memory.core import MemorySystem

        role = pipeline["role"]
        memory = MemorySystem(pipeline_id)
        memory_context = memory.build_system_context()
        jd_context = memory.get_jd_context(role)

        agent = JDAgent()
        deadline = TimeoutDeadline(get_agent_timeout("jd_write"), agent_id="jd_write")
        context = build_xiao_wen_context(
            pipeline_id=pipeline_id,
            role=role,
            pipeline_type=pipeline.get("type", "general"),
            user_hints=message,
            memory_context=f"{memory_context}\n{jd_context}",
        )
        context = attach_agent_runtime_config(context, "jd_write")
        tool_output = await agent.run_with_deadline(ToolInput(pipeline_id=pipeline_id, params=context), deadline)
        result = tool_output.data if tool_output.status.value == "success" else {}
        new_jd = result.get("jd", {})

        if new_jd:
            from app import jd_workspace

            jd_stage_output = self._get_stage_output(stages, "jd_write")
            try:
                output = jd_workspace.save_draft(
                    pipeline_id,
                    new_jd,
                    expected_revision=int(jd_stage_output.get("revision") or 0),
                    source="chat_generated",
                )
            except jd_workspace.JdLockedError as error:
                return {
                    **self._jd_locked_error(pipeline),
                    "locked_at": error.locked_at,
                    "locked_by_stage": error.locked_by_stage,
                }
            except (jd_workspace.RevisionConflictError, LookupError, ValueError) as error:
                return {"error": str(error), "reply": "JD保存失败，请刷新后重试"}

            save_message(
                pipeline_id,
                "assistant",
                "JD已生成",
                card_type="jd_card",
                card_data={"jd": output["jd"], "pipeline_id": pipeline_id},
            )
            return {
                "status": "success",
                "type": "jd_generated",
                "jd": output["jd"],
                "reply": f"已为「{role}」生成JD",
                "message": f"已为「{role}」生成JD",
            }

        return {"error": "JD生成失败，请重试", "reply": "JD生成失败，请重试"}

    # ============ 智能对话处理器 ============
    async def _handle_chat(
        self, pipeline_id: str, pipeline: dict, stages: list, candidates: list, message: str
    ) -> dict:
        """Smart chat: understand intent using ontology + knowledge base, then execute"""

        # 构建丰富上下文
        stage_summary = [f"- {s.get('stage_name', s.get('stage_id', ''))}: {s.get('status', '')}" for s in stages]
        cand_summary = [
            f"{c.get('name', '未知')}({c.get('overall_score', c.get('score', c.get('match_score', '-')))}分/{c.get('status', '')})"
            for c in candidates[:10]
        ]

        # 获取面试数据作为上下文
        interview_data = self._get_stage_output(stages, "interview_gen").get("interviews", [])
        interview_summary = ""
        if interview_data:
            interview_summary = "\n当前面试题：\n" + "\n".join(
                f"- {iv.get('candidate_name', '')}: {len(iv.get('questions', []))}题 ({iv.get('interview_strategy', '')})"
                for iv in interview_data
            )

        # 获取匹配数据作为上下文；小筛使用最新 match 阶段，避免历史重复阶段绕过确认状态。
        from app.screening_workflow import get_screening_context

        match_data = get_screening_context(pipeline_id)["output"]

        # 加载记忆上下文
        from hr_harness.memory.core import MemorySystem

        memory = MemorySystem(pipeline_id)
        memory_context = ""
        if memory.memory_rules:
            recent = memory.memory_rules[-5:]
            memory_context = "\n已学习的规则:\n" + "\n".join(
                f"- [{r.get('ontology_node_id', '')}] {r.get('source_detail', '')}" for r in recent
            )

        # 在知识库中搜索相关上下文
        kb_context = self.kb.search(message, top_k=3)
        kb_text = ""
        if kb_context:
            kb_text = "\n知识库参考：\n" + "\n".join(f"- [{k['title']}] {k['content'][:100]}" for k in kb_context)

        # 加载最近的对话历史作为上下文
        recent_msgs = get_messages(pipeline_id, limit=10)
        history_text = ""
        if recent_msgs:
            history_text = "\n最近对话：\n" + "\n".join(f"- {m['role']}: {m['content'][:80]}" for m in recent_msgs[-6:])

        system = """你是HR OS，一个具备本体思维的AI HR智能体。你有以下能力：

核心能力：
1. 理解并执行操作（修改JD、修改面试题、操作候选人等）
2. 基于知识库给出专业建议
3. 从HR的反馈中自主学习成长
4. 解释评分逻辑、对比候选人

可能的意图（action字段）：
1. modify_interview - 修改某个候选人的面试题（如"把张三的面试题改一下，多加React底层原理"、"李四的题太简单了"）
2. consolidate_exam - 把面试题综合/合并成笔试题（如"把面试题综合成1题笔试题"、"6题合并成一道综合题"、"出一份笔试卷"）
3. submit_answers - 提交某候选人的面试答案并评估（如"提交张三的答案"、"录入面试回答"）
4. reevaluate - 重新评估某候选人（如"重新评估张三"、"根据答案重新打分"）
5. candidate_action - 对候选人操作（如"张伟入围"、"淘汰吴昊"）
6. compare_candidates - 对比候选人（如"张三和李四谁更适合"、"对比一下前两名"）
7. explain_score - 解释评分（如"为什么王五只有60分"、"张三的优势是什么"）
8. answer - 回答问题（如"谁的匹配度最高"、"还有几个候选人"）
9. learn - 表达偏好/反馈（如"评分标准太松了"、"以后多关注学历"）
10. reply - 其他对话
11. regenerate_poster - 重新生成招聘海报（如"重新生成海报"、"换个海报风格"、"海报不好看重新来"）
12. generate_interview - 手动生成/重新生成面试题（如"生成面试题"、"给入围的人出面试题"、"重新出题"）
13. generate_report - 生成录用评估报告（如"生成评估报告"、"出录用报告"、"生成录用决策"）
14. edit_jd - 生成JD字段修改预览（如"把工作地点改成上海"、"补充门店管理经验"）

对于modify_interview，需要提取：
- target_candidate: 目标候选人姓名
- modification: 具体修改要求

对于consolidate_exam，需要提取：
- exam_format: 笔试题形式（如"1道综合题"、"3道大题"等）
- target_candidate: 指定候选人姓名（可选，为空则对所有候选人）

对于compare_candidates，需要提取：
- candidate_names: 要对比的候选人姓名列表

输出JSON：
{
    "action": "意图类型",
    "response": "给HR的回复（专业、简洁、有数据支撑）",
    "target_candidate": "modify_interview/consolidate_exam时的候选人姓名（可选）",
    "modification": "modify_interview时的修改要求",
    "exam_format": "consolidate_exam时的笔试题形式",
    "candidate_name": "candidate_action时的候选人姓名",
    "candidate_action": "shortlisted/rejected",
    "candidate_names": ["compare时的候选人列表"],
    "learn_type": "learn时的偏好类别",
    "learn_content": "learn时的具体内容",
    "edit_instruction": "edit_jd时的JD修改要求",
    "learned": true/false
}"""

        prompt = f"""当前招聘：{pipeline["role"]}
流水线状态：
{chr(10).join(stage_summary)}

候选人：{", ".join(cand_summary) if cand_summary else "暂无候选人"}
{interview_summary}
{history_text}
{memory_context}
{kb_text}

HR说：{message}

请理解意图并回复（JSON）："""

        result = await self._call_llm_json(prompt, system, "qwen3.6-flash")

        if not isinstance(result, dict):
            return {"status": "success", "type": "reply", "message": str(result)}

        intent_action = result.get("action", "reply")
        response = result.get("response", "")

        # 执行意图
        if intent_action == "edit_jd":
            edit_result = await self._handle_edit_jd(
                pipeline_id, pipeline, stages, {"instruction": result.get("edit_instruction", message)}
            )
            edit_result["llm_response"] = response
            return edit_result

        elif intent_action == "regenerate_poster":
            poster_result = await self._handle_regenerate_poster(pipeline_id, pipeline, stages)
            poster_result["llm_response"] = response
            return poster_result

        elif intent_action == "modify_interview":
            return await self._handle_modify_interview(
                pipeline_id,
                pipeline,
                stages,
                candidates,
                interview_data,
                result.get("target_candidate", ""),
                result.get("modification", message),
                response,
            )

        elif intent_action == "consolidate_exam":
            return await self._handle_consolidate_exam(
                pipeline_id,
                pipeline,
                stages,
                candidates,
                interview_data,
                result.get("target_candidate", ""),
                result.get("exam_format", "1道综合题"),
                response,
            )

        elif intent_action == "submit_answers":
            target_name = result.get("target_candidate", "")
            target_cand = None
            for c in candidates:
                if target_name and target_name in c["name"]:
                    target_cand = c
                    break
            if target_cand:
                return {
                    "status": "success",
                    "type": "reply",
                    "message": f"请点击{target_cand['name']}面试题卡片上的「提交答案」按钮来录入答案。",
                    "candidate_id": target_cand["id"],
                    "candidate_name": target_cand["name"],
                }
            else:
                return {
                    "status": "success",
                    "type": "reply",
                    "message": f"请告诉我要提交哪位候选人的答案？当前候选人：{', '.join(c['name'] for c in candidates[:10])}",
                }

        elif intent_action == "reevaluate":
            target_name = result.get("target_candidate", "")
            target_cand = None
            for c in candidates:
                if target_name and target_name in c["name"]:
                    target_cand = c
                    break
            if target_cand:
                reeval_result = await self._handle_reevaluate(
                    pipeline_id,
                    pipeline,
                    stages,
                    candidates,
                    {"candidate_id": target_cand["id"], "candidate_name": target_cand["name"]},
                )
                reeval_result["llm_response"] = response
                return reeval_result
            else:
                return {
                    "status": "success",
                    "type": "reply",
                    "message": f"请告诉我要重新评估哪位候选人？当前候选人：{', '.join(c['name'] for c in candidates[:10])}",
                }

        elif intent_action == "generate_interview":
            gen_result = await self._handle_generate_interview(
                pipeline_id, pipeline, stages, candidates, interview_data, match_data, response
            )
            return gen_result

        elif intent_action == "generate_report":
            return await self._handle_generate_report(pipeline_id, pipeline, stages, candidates, response)

        elif intent_action == "candidate_action":
            target_name = result.get("candidate_name", "")
            target_cand = None
            for c in candidates:
                if target_name in c["name"]:
                    target_cand = c
                    break
            if target_cand:
                cand_result = await self._handle_candidate_action(
                    pipeline_id, target_cand["id"], result.get("candidate_action", "shortlisted"), message
                )
                cand_result["llm_response"] = response
                return cand_result
            else:
                return {
                    "status": "success",
                    "type": "reply",
                    "message": f"找不到候选人「{target_name}」，当前候选人有：{', '.join(cand_summary)}",
                }

        elif intent_action == "compare_candidates":
            return await self._handle_compare_candidates(
                pipeline_id, candidates, result.get("candidate_names", []), response
            )

        elif intent_action == "explain_score":
            return await self._handle_explain_score(pipeline_id, candidates, interview_data, message, response)

        elif intent_action == "learn":
            learn_type = result.get("learn_type", "general")
            learn_content = result.get("learn_content", message)
            learn_result = memory.learn_from_chat(learn_type, learn_content, f"HR说: {message}")
            if learn_result.get("blocked"):
                response += f"\n\n该偏好被合规规则拦截: {learn_result['reason']}"
            else:
                response += (
                    f"\n\n已学习并记录到记忆库（绑定本体节点: {learn_result.get('node', '')}），后续招聘会自动应用。"
                )
            save_message(pipeline_id, "assistant", response)
            return {"status": "success", "type": "reply", "message": response, "learned": True}

        else:
            save_message(pipeline_id, "assistant", response)
            return {"status": "success", "type": "reply", "message": response}

    async def _handle_generate_interview(
        self,
        pipeline_id: str,
        pipeline: dict,
        stages: list,
        candidates: list,
        interview_data: list,
        match_data: dict,
        llm_response: str,
        candidate_id: str = None,
    ) -> dict:
        """手动生成/重新生成面试题 — 为所有入围候选人出题"""
        from app import services
        from app.services import _run_interview_gen

        jd = self._get_stage_output(stages, "jd_write").get("jd", {})
        if not jd:
            return {
                "status": "success",
                "type": "reply",
                "message": "请先生成 JD 后再生成面试题。",
                "llm_response": llm_response,
            }

        # 新版小筛必须在 confirmed 状态下，以候选人最终 screening_decision 为准。
        workflow_status = str(match_data.get("workflow_status") or "").strip().lower()
        modern_screening = workflow_status in {"review_pending", "confirmed"}
        if modern_screening and workflow_status != "confirmed":
            return {
                "status": "error",
                "type": "reply",
                "message": "小筛尚未确认，请先完成候选人复核和定版。",
                "llm_response": llm_response,
            }
        shortlisted_ids = match_data.get("shortlisted") or match_data.get("passed_ids") or []
        if not isinstance(shortlisted_ids, list):
            shortlisted_ids = []
        shortlisted_id_set = {
            str(item.get("id") or item.get("candidate_id")) if isinstance(item, dict) else str(item)
            for item in shortlisted_ids
        }
        if modern_screening:
            shortlisted = [c for c in candidates if str(c.get("screening_decision") or "").strip().lower() == "passed"]
        else:
            shortlisted = [c for c in candidates if str(c.get("id")) in shortlisted_id_set]
            if not shortlisted:
                shortlisted = [c for c in candidates if c.get("status") in {"passed", "shortlisted"}]
        if candidate_id:
            shortlisted = [c for c in shortlisted if str(c.get("id")) == str(candidate_id)]
            if not shortlisted:
                return {
                    "status": "error",
                    "type": "reply",
                    "message": "该候选人不在小筛已确认的入围名单中，请先完成小筛确认。",
                    "llm_response": llm_response,
                }
        else:
            generated_ids = {
                str(item.get("candidate_id"))
                for item in interview_data
                if isinstance(item, dict) and item.get("candidate_id")
            }
            shortlisted = [candidate for candidate in shortlisted if str(candidate.get("id")) not in generated_ids]
        if not shortlisted:
            return {
                "status": "success",
                "type": "reply",
                "message": "没有需要生成题目的新候选人。",
                "llm_response": llm_response,
            }

        match_result = dict(match_data) if match_data else {}
        match_result["shortlisted"] = [c.get("id") for c in shortlisted]
        match_result["candidates"] = candidates
        match_result["screening_workflow"] = modern_screening
        # 读取审核页设置的生成题数（1-20），缺省 None → 走 InterviewAgent 默认
        question_count = None
        try:
            qc = self._get_stage_output(stages, "interview_gen").get("generated_count")
            if qc:
                question_count = int(qc)
        except (TypeError, ValueError):
            question_count = None
        active_task = services.get_active_interview_generation_task(pipeline_id)
        if active_task:
            return {
                "status": "success",
                "type": "reply",
                "message": "⏳ 已有面试题生成任务正在进行，请等待当前任务完成。",
                "generation_job_id": active_task["id"],
                "generation_status": active_task["status"],
                "llm_response": llm_response,
            }

        task = services.create_interview_generation_task(pipeline_id, len(shortlisted), question_count)
        # 后台执行：面试生成耗时 30-120 秒，不阻塞 HTTP 响应
        asyncio.create_task(
            _run_interview_gen(
                pipeline_id,
                match_result,
                jd,
                pipeline["role"],
                question_count,
                task_id=task["id"],
                candidate_id=candidate_id or "",
            )
        )

        return {
            "status": "success",
            "type": "reply",
            "message": f"⏳ 已开始为 {len(shortlisted)} 位候选人生成面试题，预计30-120秒完成。",
            "generation_job_id": task["id"],
            "generation_status": task["status"],
            "candidate_count": len(shortlisted),
            "question_count": question_count,
            "llm_response": llm_response,
        }

    async def _handle_generate_report(
        self,
        pipeline_id: str,
        pipeline: dict,
        stages: list,
        candidates: list,
        llm_response: str,
        passed_only: bool = False,
    ) -> dict:
        """生成录用评估报告"""
        from app.assessment_flow import build_report_inputs
        from hr_harness.agents.report_agent import ReportAgent

        jd = self._get_stage_output(stages, "jd_write").get("jd", {})
        if not jd:
            return {
                "status": "success",
                "type": "reply",
                "message": "请先生成 JD 后再生成评估报告。",
                "llm_response": llm_response,
            }

        report_inputs = build_report_inputs(pipeline_id, minimum_score=60 if passed_only else None)
        queue = report_inputs["queue"]
        if not queue["plan"]:
            return {
                "status": "success",
                "type": "reply",
                "message": "请先在小面确认并启用评估方案，再生成录用决策报告。",
                "llm_response": llm_response,
            }
        if not report_inputs["assessment_packages"]:
            counts = queue["counts"]
            return {
                "status": "success",
                "type": "reply",
                "message": (
                    ("当前没有评分达到 60 分的通过候选人。" if passed_only else "当前没有可进入正式决策的候选人。")
                    + f"未完成 {counts['incomplete']} 人。"
                ),
                "assessment_queue": queue,
                "llm_response": llm_response,
            }

        candidate_map = {candidate.get("id"): candidate for candidate in candidates}
        decision_candidates = []
        for package in report_inputs["assessment_packages"]:
            decision_candidates.append(
                candidate_map.get(package["candidate_id"])
                or {"id": package["candidate_id"], "name": package.get("candidate_name", "")}
            )

        interview_output = self._get_stage_output(stages, "interview_gen")
        candidate_ids = set(report_inputs["candidate_ids"])
        interviews = [
            item for item in interview_output.get("interviews", []) if item.get("candidate_id") in candidate_ids
        ]

        # 使用完整面试数据运行报告 Agent
        agent = ReportAgent()
        context = {
            "candidates": decision_candidates,
            "assessments": report_inputs["assessments"],
            "interview_records": report_inputs["interview_records"],
            "interviews": interviews,
            "assessment_packages": report_inputs["assessment_packages"],
            "jd": jd,
            "role": pipeline["role"],
            "pipeline_id": pipeline_id,
            "company_config": get_company_config(),
        }
        deadline = TimeoutDeadline(get_agent_timeout("report"), agent_id="report")
        tool_output = await agent.run_with_deadline(ToolInput(pipeline_id=pipeline_id, params=context), deadline)
        tool_data = tool_output.data if tool_output.status.value == "success" else {}
        report_result = tool_data.get("report", tool_data) if isinstance(tool_data, dict) else {}

        # 保存报告阶段
        from app.db import create_stage

        stages_list = get_stages(pipeline_id)
        existing_ids = {s["stage_id"] for s in stages_list}
        if "report" not in existing_ids:
            create_stage(pipeline_id, "report", "录用报告")
        update_stage(pipeline_id, "report", "done", report_result)

        save_message(
            pipeline_id, "assistant", "📊 录用评估报告已生成", card_type="report_card", card_data=report_result
        )

        return {
            "status": "success",
            "type": "reply",
            "message": f"📊 录用评估报告已生成，共评估 {len(decision_candidates)} 位可决策候选人。请查看报告卡片。",
            "report": report_result,
            "assessment_queue": queue,
            "llm_response": llm_response,
        }

    async def _handle_modify_interview(
        self,
        pipeline_id: str,
        pipeline: dict,
        stages: list,
        candidates: list,
        interview_data: list,
        target_name: str,
        modification: str,
        initial_response: str,
    ) -> dict:
        """Modify interview questions for a specific candidate"""
        # 查找目标候选人的面试
        target_iv = None
        for iv in interview_data:
            if target_name and target_name in iv.get("candidate_name", ""):
                target_iv = iv
                break

        if not target_iv and target_name:
            # 尝试模糊匹配
            for iv in interview_data:
                if any(c in iv.get("candidate_name", "") for c in target_name):
                    target_iv = iv
                    break

        if not target_iv:
            names = [iv.get("candidate_name", "") for iv in interview_data]
            return {
                "status": "success",
                "type": "reply",
                "message": f"找不到「{target_name}」的面试题。当前有面试题的候选人：{', '.join(names)}",
            }

        # 查找候选人数据
        cand_data = None
        for c in candidates:
            if c["name"] == target_iv.get("candidate_name"):
                cand_data = c
                break

        from app.question_review import ensure_questions_editable

        try:
            ensure_questions_editable(pipeline_id, str(target_iv.get("candidate_id") or ""))
        except ValueError as exc:
            return {
                "status": "error",
                "type": "question_edit_locked",
                "error_code": "question_edit_locked",
                "message": str(exc),
            }

        kb_ctx = self.kb.get_context_for_intent("modify_interview", modification)

        # 目标题数：优先用审核面板设置的 generated_count，其次保持原题数，不固定写死
        full_output = self._get_stage_output(stages, "interview_gen")
        target_count = full_output.get("generated_count") or len(target_iv.get("questions", [])) or 3
        try:
            target_count = max(1, min(20, int(target_count)))
        except (TypeError, ValueError):
            target_count = len(target_iv.get("questions", [])) or 3

        system = f"""你是一个资深技术面试官。HR要求修改面试题，你需要根据要求重新设计。
保持面试题的结构（技术深度/系统设计/项目经验/软技能），只修改HR提到的部分。
直接输出JSON数组，不要任何解释文字。
{kb_ctx}"""

        # 仅保留问题的必要字段
        current_qs = []
        for q in target_iv.get("questions", []):
            current_qs.append(
                {
                    "type": q.get("type", ""),
                    "question": q.get("question", "")[:100],
                    "difficulty": q.get("difficulty", ""),
                }
            )

        cand_brief = ""
        if cand_data:
            cand_brief = f"{cand_data.get('years_experience', 0)}年经验, {cand_data.get('current_company', '')}, 技能: {', '.join(cand_data.get('skills', [])[:5])}"

        prompt = f"""岗位：{pipeline["role"]}
候选人：{target_iv.get("candidate_name", "")} ({cand_brief})

当前面试题概要（{len(target_iv.get("questions", []))}题）：
{json.dumps(current_qs, ensure_ascii=False)}

HR修改要求：{modification}

请输出修改后的完整面试题列表（JSON数组），{target_count}道题，每道题：
{{"type":"技术深度/系统设计/项目经验/软技能","question":"题目内容","follow_up":"追问方向","reason":"出题原因","expected_points":["要点1","要点2"],"difficulty":"基础/中等/困难"}}"""

        new_questions = await self._call_llm_json(prompt, system, "qwen-plus", timeout=120)

        if isinstance(new_questions, list) and len(new_questions) > 0:
            new_questions = list(new_questions)[:target_count]

            # 统一写回（接入审核机制）：重置 review_status=pending + 全局重算 + 广播
            from app import question_review as qr

            try:
                await qr.set_questions(pipeline_id, target_iv.get("candidate_id", ""), new_questions)
            except ValueError as e:
                return {
                    "status": "success",
                    "type": "reply",
                    "message": f"面试题保存失败：{e}",
                }

            # 重新读取最新输出用于卡片
            full_output = self._get_stage_output(stages, "interview_gen")
            interview_data = full_output.get("interviews", [])

            # 保存包含更新后卡片的消息
            card_data = {"interviews": interview_data}
            save_message(
                pipeline_id,
                "assistant",
                f"已修改{target_iv.get('candidate_name', '')}的面试题：{modification}",
                card_type="interview_card",
                card_data=card_data,
            )

            return {
                "status": "success",
                "type": "interview_modified",
                "candidate_name": target_iv.get("candidate_name", ""),
                "questions": new_questions,
                "interviews": interview_data,
                "message": f"已修改{target_iv.get('candidate_name', '')}的面试题（{len(new_questions)}题）：{modification}",
            }

        return {
            "status": "success",
            "type": "reply",
            "message": "面试题修改失败，请重试。或者告诉我更具体的修改方向。",
        }

    async def _handle_consolidate_exam(
        self,
        pipeline_id: str,
        pipeline: dict,
        stages: list,
        candidates: list,
        interview_data: list,
        target_name: str,
        exam_format: str,
        initial_response: str,
    ) -> dict:
        """Consolidate interview questions into written exam questions"""
        # 确定需要合并的面试
        targets = []
        if target_name:
            for iv in interview_data:
                if target_name in iv.get("candidate_name", ""):
                    targets.append(iv)
                    break
        else:
            targets = interview_data

        if not targets:
            names = [iv.get("candidate_name", "") for iv in interview_data]
            return {
                "status": "success",
                "type": "reply",
                "message": f"找不到面试题。当前有面试题的候选人：{', '.join(names) if names else '无'}",
            }

        # 汇总目标面试的所有问题
        all_questions = []
        for iv in targets:
            for q in iv.get("questions", []):
                all_questions.append(
                    {
                        "candidate": iv.get("candidate_name", ""),
                        "type": q.get("type", ""),
                        "question": q.get("question", ""),
                        "difficulty": q.get("difficulty", ""),
                        "expected_points": q.get("expected_points", []),
                    }
                )

        if not all_questions:
            return {"status": "success", "type": "reply", "message": "面试题数据为空，无法生成笔试题。"}

        # 获取 JD 作为上下文
        jd = self._get_stage_output(stages, "jd_write").get("jd", {})

        system = """你是一个资深技术面试官和出题专家。HR要求把个性化面试题综合成笔试题。

要求：
1. 将多道面试题的知识点融合成综合笔试题
2. 笔试题应有区分度，能考察候选人的综合能力
3. 每道题要有明确的评分标准和参考答案要点
4. 题目要有深度，不是简单拼凑，而是有机融合多个知识点
5. 直接输出JSON，不要任何解释文字"""

        target_desc = (
            f"候选人{targets[0].get('candidate_name', '')}" if len(targets) == 1 else f"所有{len(targets)}位候选人"
        )

        prompt = f"""岗位：{pipeline["role"]}
JD核心要求：{json.dumps({k: jd.get(k, "") for k in ["title", "requirements", "key_skills"]}, ensure_ascii=False)}

当前面试题（共{len(all_questions)}题，来自{target_desc}）：
{json.dumps(all_questions, ensure_ascii=False, indent=2)}

HR要求：综合成{exam_format}

请输出笔试题（JSON格式）：
{{
    "exam_title": "笔试题标题",
    "exam_description": "笔试说明（50字内）",
    "total_score": 100,
    "duration_minutes": 90,
    "questions": [
        {{
            "question_number": 1,
            "question": "题目内容（详细、完整）",
            "question_type": "综合题/编程题/设计题/分析题",
            "score": 分值,
            "sub_questions": ["子问题1", "子问题2"],
            "grading_criteria": [
                {{"point": "评分要点", "score": 分值}}
            ],
            "reference_answer": "参考答案要点概要",
            "source_topics": ["原题涉及的知识点"]
        }}
    ]
}}"""

        exam_result = await self._call_llm_json(prompt, system, "qwen-plus", timeout=120)

        if isinstance(exam_result, dict) and exam_result.get("questions"):
            # 将试卷卡片保存为新消息
            card_data = {
                "exam": exam_result,
                "source_candidates": [iv.get("candidate_name", "") for iv in targets],
                "source_question_count": len(all_questions),
            }

            summary = f"已将{len(all_questions)}道面试题综合为{len(exam_result['questions'])}道笔试题"
            save_message(pipeline_id, "assistant", summary, card_type="exam_card", card_data=card_data)

            return {"status": "success", "type": "exam_generated", "exam": exam_result, "message": summary}

        return {
            "status": "success",
            "type": "reply",
            "message": "笔试题生成失败，请重试。或尝试更具体的描述（如'综合成3道大题'）。",
        }

    async def _handle_compare_candidates(
        self, pipeline_id: str, candidates: list, names: list, initial_response: str
    ) -> dict:
        """Compare candidates"""
        targets = []
        for name in names:
            for c in candidates:
                if name in c["name"]:
                    targets.append(c)
                    break

        if len(targets) < 2:
            all_names = [c["name"] for c in candidates[:10]]
            return {
                "status": "success",
                "type": "reply",
                "message": f"需要至少2个候选人来对比。当前候选人：{', '.join(all_names)}",
            }

        kb_ctx = self.kb.get_context_for_intent("compare_candidates", f"对比{'和'.join(names)}")

        system = f"""你是一个资深HR顾问，对比候选人并给出专业建议。
用数据说话，给出明确的推荐和理由。
{kb_ctx}"""

        prompt = f"""请对比以下候选人：
{json.dumps([{k: v for k, v in c.items() if k != "resume_text"} for c in targets], ensure_ascii=False, indent=2)}

请给出对比分析（JSON）：
{{
    "comparison": "200字对比分析",
    "winner": "推荐人选姓名",
    "reasons": ["推荐理由1", "推荐理由2", "推荐理由3"],
    "risks": {{"候选人1姓名": "风险点", "候选人2姓名": "风险点"}},
    "suggestion": "最终建议（一句话）"
}}"""

        result = await self._call_llm_json(prompt, system, "qwen-plus")

        if isinstance(result, dict) and "comparison" in result:
            response = f"**候选人对比**\n\n{result['comparison']}\n\n"
            response += f"**推荐：{result.get('winner', '')}**\n"
            for r in result.get("reasons", []):
                response += f"- {r}\n"
            if result.get("risks"):
                response += "\n**风险提示：**\n"
                for name, risk in result["risks"].items():
                    response += f"- {name}: {risk}\n"
            response += f"\n{result.get('suggestion', '')}"

            save_message(pipeline_id, "assistant", response)
            return {"status": "success", "type": "reply", "message": response}

        save_message(pipeline_id, "assistant", initial_response)
        return {"status": "success", "type": "reply", "message": initial_response}

    async def _handle_explain_score(
        self, pipeline_id: str, candidates: list, interview_data: list, message: str, initial_response: str
    ) -> dict:
        """Explain scoring for a candidate"""
        kb_ctx = self.kb.get_context_for_intent("explain_score", message)

        system = f"""你是一个资深HR顾问，解释候选人评分逻辑。
用数据说话，解释为什么给出这个分数，优势和不足分别是什么。
{kb_ctx}"""

        cand_data = [{k: v for k, v in c.items() if k != "resume_text"} for c in candidates[:10]]

        prompt = f"""候选人数据：
{json.dumps(cand_data, ensure_ascii=False, indent=2)}

HR的问题：{message}

请给出详细解释（JSON）：
{{
    "explanation": "200字详细解释",
    "key_factors": ["影响评分的关键因素1", "关键因素2", "关键因素3"],
    "suggestion": "建议（一句话）"
}}"""

        result = await self._call_llm_json(prompt, system, "qwen-plus")

        if isinstance(result, dict) and "explanation" in result:
            response = result["explanation"]
            if result.get("key_factors"):
                response += "\n\n**关键因素：**\n"
                for f in result["key_factors"]:
                    response += f"- {f}\n"
            if result.get("suggestion"):
                response += f"\n{result['suggestion']}"

            save_message(pipeline_id, "assistant", response)
            return {"status": "success", "type": "reply", "message": response}

        save_message(pipeline_id, "assistant", initial_response)
        return {"status": "success", "type": "reply", "message": initial_response}

    async def quick_evaluate(
        self,
        pipeline_id: str,
        candidate_id: str,
        question_index: int,
        question: str,
        expected_points: list,
        answer: str,
        jd_role: str = "",
    ) -> dict:
        """快速评估单个面试问题的回答"""
        system = """你是一个资深技术面试官，根据候选人的面试回答进行评估。
请评估候选人的回答，输出JSON格式：
{
    "score": 0-100的分数,
    "hit_points": ["命中的要点"],
    "missed_points": ["遗漏的要点"],
    "comment": "简短评语",
    "should_follow_up": true/false（是否需要追问）
}
评估要求：
1. 基于回答内容客观评分
2. 明确列出命中和遗漏的要点
3. 给出简洁的评价
4. 判断是否需要追问以了解更多"""

        points_text = "\n".join(f"- {p}" for p in expected_points) if expected_points else "（无预设要点）"
        prompt = f"""岗位：{jd_role or "技术岗位"}
问题{question_index + 1}：{question}

期望要点：
{points_text}

候选人回答：
{answer}

请评估这个回答。"""

        try:
            result = await self._call_llm_json(prompt, system, "qwen3.7-max", timeout=120)
            if isinstance(result, dict) and "score" in result:
                return {
                    "score": result.get("score", 0),
                    "hit_points": result.get("hit_points", []),
                    "missed_points": result.get("missed_points", []),
                    "comment": result.get("comment", ""),
                    "should_follow_up": result.get("should_follow_up", False),
                }
        except Exception as e:
            logger.error(f"quick_evaluate LLM error: {e}")

        # LLM 失败时的降级返回
        return {
            "score": 0,
            "hit_points": [],
            "missed_points": expected_points,
            "comment": "评估失败，请重试",
            "should_follow_up": False,
        }

    async def quick_evaluate_written(
        self,
        pipeline_id: str,
        candidate_id: str,
        question_index: int,
        question: str,
        question_type: str,
        difficulty: str,
        expected_points: list,
        scoring_rubric: dict,
        answer: str,
        jd_role: str = "",
    ) -> dict:
        """Evaluate one written answer against observable 0-4 anchors."""
        system = """你是资深岗位笔试评分专家。你只负责识别证据和行为等级，不直接决定百分制分数。

评分规则：
1. 逐项对照给定的0-4级锚点选择level，level只能是0、1、2、3、4。
2. 只依据候选人答案中的内容评分，不得根据简历、姓名或主观印象补充信息。
3. evidence必须引用或忠实概括答案中的具体依据；答案没有体现时应给0或1级。
4. 专业准确性优先于文字长度；不能因为回答长、术语多就给高分。
5. 分析题重点看因果、取舍和验证，方案题重点看步骤、资源、指标和风险。
6. 语法、文风和表达习惯不应影响专业分，除非已经导致答案无法理解。
7. 信息不足、题意不清或答案疑似截断时降低confidence，不要猜测。

输出合法JSON，不要Markdown，不要输出百分制score。"""
        points_text = "\n".join(f"- {point}" for point in expected_points) or "（无预设要点）"
        prompt = f"""岗位：{jd_role or "通用岗位"}
题号：{question_index + 1}
题型：{question_type or "综合题"}
难度：{difficulty or "中等"}
题目：{question}

期望要点：
{points_text}

评分锚点：
{json.dumps(scoring_rubric, ensure_ascii=False)}

候选人答案：
{answer}

请返回：
{{
  "criteria": [
    {{"id": "与评分锚点一致", "level": 3, "evidence": "答案中的具体依据", "confidence": 0.85}}
  ],
  "overall_confidence": 0.85,
  "comment": "面向HR的证据化评语",
  "candidate_feedback": "面向候选人的改进建议"
}}"""
        expected_criterion_ids = {
            str(item.get("id"))
            for item in scoring_rubric.get("criteria", [])
            if isinstance(item, dict) and item.get("id") is not None
        }
        last_failure = "模型未返回完整评分项"
        for attempt in range(WRITTEN_SCORING_MAX_RETRIES + 1):
            try:
                result = await self._call_llm_json(prompt, system, "qwen3.7-max", timeout=120)
                raw_criteria = result.get("criteria") if isinstance(result, dict) else None
                returned_ids = {
                    str(item.get("id"))
                    for item in (raw_criteria or [])
                    if isinstance(item, dict) and item.get("id") is not None
                }
                if isinstance(raw_criteria, list) and raw_criteria and expected_criterion_ids.issubset(returned_ids):
                    return result
                if isinstance(result, dict):
                    last_failure = str(result.get("error") or result.get("comment") or last_failure)
                else:
                    last_failure = f"模型返回类型异常: {type(result).__name__}"
            except Exception as error:
                last_failure = str(error) or type(error).__name__

            if attempt < WRITTEN_SCORING_MAX_RETRIES:
                retry_number = attempt + 1
                delay = WRITTEN_SCORING_RETRY_BASE_DELAY_SECONDS * (2**attempt) + min(question_index, 5) * 0.2
                logger.warning(
                    "quick_evaluate_written failed for pipeline=%s candidate=%s question=%s; retry %s/%s in %.1fs: %s",
                    pipeline_id,
                    candidate_id,
                    question_index,
                    retry_number,
                    WRITTEN_SCORING_MAX_RETRIES,
                    delay,
                    last_failure[:300],
                )
                await asyncio.sleep(delay)

        logger.error(
            "quick_evaluate_written exhausted retries for pipeline=%s candidate=%s question=%s: %s",
            pipeline_id,
            candidate_id,
            question_index,
            last_failure[:300],
        )
        return {
            "criteria": None,
            "overall_confidence": 0,
            "comment": "评估失败，请重试",
            "candidate_feedback": "",
            "failure_reason": last_failure[:300],
        }

    async def _handle_submit_answers(
        self, pipeline_id: str, pipeline: dict, stages: list, candidates: list, data: dict
    ) -> dict:
        """Submit answers for a candidate's interview questions and evaluate"""
        candidate_id = data.get("candidate_id", "")
        candidate_name = data.get("candidate_name", "")
        answers = data.get("answers", [])  # [{问题序号, 回答文本}]

        if not candidate_id and not candidate_name:
            return {"error": "需要指定候选人"}
        if not answers:
            return {"error": "没有答案数据"}

        # 查找候选人
        cand = None
        for c in candidates:
            if c["id"] == candidate_id or (candidate_name and candidate_name in c["name"]):
                cand = c
                break
        if not cand:
            return {"error": f"找不到候选人: {candidate_name or candidate_id}"}

        # 获取该候选人的面试问题
        interview_data = self._get_stage_output(stages, "interview_gen").get("interviews", [])
        target_iv = None
        for iv in interview_data:
            if iv.get("candidate_id") == cand["id"] or iv.get("candidate_name") == cand["name"]:
                target_iv = iv
                break
        if not target_iv:
            return {"error": f"找不到{cand['name']}的面试题"}

        questions = target_iv.get("questions", [])

        # 构建问答对
        qa_pairs = []
        for a in answers:
            idx = a.get("question_index", 0)
            answer_text = a.get("answer_text", "")
            if 0 <= idx < len(questions):
                q = questions[idx]
                qa_pairs.append(
                    {
                        "question": q.get("question", ""),
                        "type": q.get("type", ""),
                        "expected_points": q.get("expected_points", []),
                        "difficulty": q.get("difficulty", ""),
                        "answer": answer_text,
                    }
                )

        if not qa_pairs:
            return {"error": "没有有效的问答对"}

        # LLM 评估
        system = """你是一个资深技术面试官，根据候选人的面试回答评估其表现。
评估要求：
1. 逐题评分（0-100），给出具体评价
2. 综合评估维度：技术表达/逻辑思维/沟通能力/学习意愿/文化匹配(各0-100)
3. 基于回答内容判断，不要编造
4. 给出明确的录用建议
输出JSON格式。"""

        qa_text = ""
        for i, qa in enumerate(qa_pairs, 1):
            qa_text += f"\n--- Q{i} ({qa['type']}, {qa['difficulty']}) ---\n"
            qa_text += f"题目：{qa['question']}\n"
            qa_text += f"期望要点：{', '.join(qa['expected_points'])}\n"
            qa_text += f"候选人回答：{qa['answer']}\n"

        prompt = f"""岗位：{pipeline["role"]}
候选人：{cand["name"]}
背景：{cand.get("years_experience", 0)}年 · {cand.get("current_company", "")} · {cand.get("current_salary", "")}
技能：{", ".join(cand.get("skills", []))}
AI匹配分：{cand.get("overall_score", 0)}

面试问答记录：
{qa_text}

请评估候选人表现，输出JSON：
{{
    "candidate_id": "{cand["id"]}",
    "candidate_name": "{cand["name"]}",
    "question_scores": [
        {{"question_index": 0, "score": 数字, "comment": "20字评价", "hit_points": ["命中的要点"], "missed_points": ["未命中的要点"]}}
    ],
    "dimensions": {{
        "technical_expression": 数字,
        "logical_thinking": 数字,
        "communication": 数字,
        "learning_willingness": 数字,
        "culture_fit": 数字
    }},
    "overall_score": 综合分(0-100),
    "highlights": ["亮点1", "亮点2"],
    "concerns": ["担忧1"],
    "overall_impression": "50字总体印象",
    "recommendation": "强烈推荐/推荐/待定/不推荐",
    "salary_negotiation_tip": "薪资谈判建议"
}}"""

        result = await self._call_llm_json(prompt, system, "qwen-plus", timeout=120)

        if isinstance(result, dict) and "dimensions" in result:
            # 将评估保存到候选人记录
            update_candidate(cand["id"], {"video_assessment": result})

            # 保存到面试阶段输出，并标记回答已提交
            full_output = self._get_stage_output(stages, "interview_gen")
            for iv in full_output.get("interviews", []):
                if iv.get("candidate_id") == cand["id"]:
                    iv["answers_submitted"] = True
                    iv["answers"] = answers
            update_stage(pipeline_id, "interview_gen", "done", full_output)

            # 保存消息
            score = result.get("overall_score", 0)
            rec = result.get("recommendation", "")
            save_message(
                pipeline_id,
                "assistant",
                f"已评估{cand['name']}的面试答案：综合{score}分，{rec}",
                card_type="assessment_card",
                card_data={"assessments": [result]},
            )

            # 广播评估结果到所有 WebSocket 客户端
            await broadcast(
                {
                    "type": "stage_card",
                    "stage_id": "interview_eval",
                    "card": {
                        "type": "assessment_card",
                        "data": {"assessments": [result]},
                        "summary": f"已评估{cand['name']}的面试答案：综合{score}分，{rec}",
                    },
                    "pipeline_id": pipeline_id,
                },
                pipeline_id,
            )

            # 广播录用提示卡片
            hire_prompt_data = {
                "candidate_id": cand["id"],
                "candidate_name": cand["name"],
                "overall_score": score,
                "recommendation": rec,
            }
            save_message(
                pipeline_id,
                "assistant",
                f"💼 {cand['name']} 评估完成，是否要录用？",
                card_type="hire_prompt_card",
                card_data=hire_prompt_data,
            )
            await broadcast(
                {
                    "type": "stage_card",
                    "stage_id": "hire_prompt",
                    "card": {
                        "type": "hire_prompt_card",
                        "data": hire_prompt_data,
                        "summary": f"{cand['name']} 评估完成，是否要录用？",
                    },
                    "pipeline_id": pipeline_id,
                },
                pipeline_id,
            )

            return {
                "status": "success",
                "type": "answers_evaluated",
                "candidate_name": cand["name"],
                "assessment": result,
                "message": f"已评估{cand['name']}的面试答案（{len(qa_pairs)}题）：综合{score}分，建议{rec}",
            }

        return {"error": "评估失败，请重试"}

    async def _handle_reevaluate(
        self, pipeline_id: str, pipeline: dict, stages: list, candidates: list, data: dict
    ) -> dict:
        """Re-evaluate a candidate: re-run report for one person"""
        candidate_id = data.get("candidate_id", "")
        candidate_name = data.get("candidate_name", "")

        cand = None
        for c in candidates:
            if c["id"] == candidate_id or (candidate_name and candidate_name in c["name"]):
                cand = c
                break
        if not cand:
            return {"error": f"找不到候选人: {candidate_name or candidate_id}"}

        # 获取现有评估
        video = cand.get("video_assessment", {})
        if isinstance(video, str):
            try:
                video = json.loads(video)
            except:
                video = {}

        if not video or not video.get("dimensions"):
            return {"error": f"{cand['name']}还没有面试评估数据，请先提交答案或上传面试记录"}

        # 获取面试数据
        interview_data = self._get_stage_output(stages, "interview_gen").get("interviews", [])
        jd = self._get_stage_output(stages, "jd_write").get("jd", {})

        # 仅为该候选人重新生成报告
        from hr_harness.agents.report_agent import ReportAgent

        context = {
            "jd": jd,
            "candidates": [cand],
            "interviews": interview_data,
            "role": pipeline["role"],
            "pipeline_id": pipeline_id,
            "assessments": [video],
            "company_config": get_company_config(),
        }

        report_agent = ReportAgent()
        tool_output = await report_agent.run(ToolInput(pipeline_id=pipeline_id, params=context))
        report_result = tool_output.data if tool_output.status.value == "success" else {}

        save_message(
            pipeline_id, "assistant", f"已重新评估{cand['name']}", card_type="report_card", card_data=report_result
        )

        # 广播重新评估结果到所有 WebSocket 客户端
        await broadcast(
            {
                "type": "stage_card",
                "stage_id": "report",
                "card": {"type": "report_card", "data": report_result, "summary": f"已重新评估{cand['name']}"},
                "pipeline_id": pipeline_id,
            },
            pipeline_id,
        )

        return {
            "status": "success",
            "type": "reevaluated",
            "candidate_name": cand["name"],
            "report": report_result,
            "message": f"已重新评估{cand['name']}，报告已更新",
        }
