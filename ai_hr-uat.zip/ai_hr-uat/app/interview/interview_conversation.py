"""统一面试对话的指令解析、追问与无副作用预览。"""

from __future__ import annotations

import hashlib
import json
import os
import re
import uuid
from copy import deepcopy
from datetime import date, datetime, time
from zoneinfo import ZoneInfo

from app import assessment_flow
from app.db import (
    get_candidates,
    get_interview_command,
    get_interview_schedules,
    get_stages,
    save_interview_command,
    update_interview_command,
)
from app.state import get_action_handler

ALLOWED_INTENTS = {
    "modify_questions",
    "schedule_interview",
    "reschedule_interview",
    "cancel_interview",
    "configure_assessment_plan",
}
TIMEZONE = ZoneInfo("Asia/Shanghai")
TIME_PATTERN = re.compile(r"(?:[01]\d|2[0-3]):[0-5]\d")

_INTENT_FIELDS = {
    "modify_questions": {
        "candidate_id",
        "candidate_name",
        "question_scope",
        "question_index",
        "question_indices",
        "modification",
    },
    "schedule_interview": {
        "candidate_id",
        "candidate_name",
        "date",
        "time",
        "interviewer",
        "method",
        "duration",
        "round",
        "notes",
    },
    "reschedule_interview": {
        "candidate_id",
        "candidate_name",
        "schedule_id",
        "date",
        "time",
        "interviewer",
        "method",
        "duration",
        "round",
        "notes",
    },
    "cancel_interview": {"candidate_id", "candidate_name", "schedule_id"},
    "configure_assessment_plan": {"plan_name", "combination", "steps", "condition"},
}

_REQUIRED_FIELDS = {
    "modify_questions": ("candidate_name", "question_scope", "modification"),
    "schedule_interview": ("candidate_name", "date", "time", "interviewer", "method"),
    "reschedule_interview": ("candidate_name", "schedule_id", "date", "time", "interviewer", "method"),
    "cancel_interview": ("candidate_name", "schedule_id"),
    "configure_assessment_plan": ("combination", "steps"),
}

_CLARIFICATION_MESSAGES = {
    "intent": "请说明是修改面试题，还是安排面试。",
    "candidate_name": "请明确选择一位候选人。",
    "question_scope": "请说明要修改某一道题，还是整套题。",
    "question_index": "请说明要修改第几题。",
    "modification": "请说明希望怎样修改题目。",
    "date": "请提供一个未来的面试日期。",
    "time": "请提供 HH:MM 格式的具体开始时间。",
    "interviewer": "请说明面试官。",
    "method": "请说明采用线上还是线下面试。",
    "schedule_id": "该候选人有多场待进行面试，请选择要操作的排期。",
    "combination": "请说明这些评估需要全部完成、任选一种，还是按分数条件分支。",
    "steps": "请说明需要笔试、视频面试或人工面试中的哪些环节。",
    "condition": "请补充条件阈值，以及满足和不满足条件后的路径。",
}

_FAST_MODIFY_RE = re.compile(
    r"(?:修改|改|调整|优化|重写|提升|降低|增加|减少).{0,20}(?:题|难度|时长)|(?:题|难度|时长).{0,20}(?:修改|改|调整|优化|重写|提升|降低|增加|减少)"
)
_FAST_SINGLE_RE = re.compile(r"第\s*(\d+)\s*题")
_FAST_ALL_RE = re.compile(r"(?:整套|全部|所有|每道|每一题|整体).{0,8}(?:题|改|调整|优化|重写)")
_FAST_PREFIX_RE = re.compile(r"前\s*([一二三四五六七八九十\d]+)\s*道?题")
_FAST_ENUM_RE = re.compile(r"第\s*([一二三四五六七八九十\d]+)\s*道?题")


async def _call_llm_json(
    prompt: str,
    system: str = "",
    model: str | None = None,
    timeout: int = 60,
    json_mode: bool = False,
) -> dict:
    """复用现有 LLM JSON 通道，并保留可 monkeypatch 的测试边界。"""
    handler = get_action_handler()
    selected_model = model or os.getenv("OPENAI_CHAT_MODEL", "qwen-plus")
    return await handler._call_llm_json(prompt, system, selected_model, timeout, json_mode=json_mode)


def _current_plan_config(pipeline_id: str) -> dict:
    active = assessment_flow.get_active_plan(pipeline_id)
    return deepcopy((active or {}).get("config") or {})


def _normalize_plan_payload(payload: dict) -> dict:
    combination_aliases = {
        "全部完成": "all",
        "全部": "all",
        "任意完成一个": "any",
        "任选一种": "any",
        "任意": "any",
        "条件分支": "conditional",
        "按条件": "conditional",
    }
    modality_aliases = {
        "笔试": "written_test",
        "在线笔试": "written_test",
        "视频": "video_interview",
        "视频面试": "video_interview",
        "人工": "manual_interview",
        "人工面试": "manual_interview",
    }
    normalized = deepcopy(payload)
    normalized["combination"] = combination_aliases.get(normalized.get("combination"), normalized.get("combination"))
    steps = normalized.get("steps")
    if isinstance(steps, list):
        for index, step in enumerate(steps):
            if not isinstance(step, dict):
                continue
            step["modality"] = modality_aliases.get(step.get("modality"), step.get("modality"))
            step.setdefault("id", step.get("modality") or f"step_{index + 1}")
            step.setdefault("name", {v: k for k, v in modality_aliases.items()}.get(step.get("modality"), step["id"]))
    return normalized


def _clean_candidate_name(name) -> str:
    """剥离候选人名前后的 *、#、空格等符号（导入数据常带 ** 前缀标记，LLM 也可能残留）。"""
    if not name:
        return name
    return re.sub(r"^[\s*#·]+|[\s*#·]+$", "", str(name)).strip()


def _flatten_parsed(parsed: dict) -> dict:
    """LLM 输出格式不稳定：兼容 intent/action/operation 三种字段名，以及 {intent: {...}} 嵌套。"""
    if not isinstance(parsed, dict):
        return {}
    for key in ("intent", "action", "operation"):
        nested = parsed.get(key)
        if isinstance(nested, dict):
            merged = dict(nested)
            merged.setdefault("intent", key)
            return merged
    return parsed


_QUESTION_INDEX_RE = re.compile(r"第\s*([0-9一二三四五六七八九十]+)\s*题")
_ALL_QUESTION_RE = re.compile(r"整[套个]?题|所有题|全部题目")
_CN_DIGITS = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def _parse_question_index(message: str):
    """从原文提取“第N题”的下标（支持阿拉伯与中文数字）。"""
    match = _QUESTION_INDEX_RE.search(message)
    if not match:
        return None
    token = match.group(1)
    if token.isdigit():
        return int(token)
    return _CN_DIGITS.get(token)


def _fallback_intent(message: str) -> str:
    """LLM 意图识别失败时的关键词兜底，仅在 _call_llm_json 返回空或非法 intent 时触发。"""
    if re.search(r"改期|改时间|推迟|换个时间|调整.*时间", message):
        return "reschedule_interview"
    if re.search(r"取消.*面试|面试.*取消|撤销.*面试", message):
        return "cancel_interview"
    if re.search(r"评估方案|评估流程|组合.*评估|笔试.*视频.*人工|流转", message):
        return "configure_assessment_plan"
    if re.search(r"安排.*面试|预约.*面试|约.*面试|定.*面试", message):
        return "schedule_interview"
    if re.search(r"修改|改|换|调整|题目|难度|时长|第.{0,3}题", message):
        return "modify_questions"
    return ""


async def _parse_command(pipeline_id: str, message: str, previous_payload: dict) -> tuple[str, dict]:
    current_plan = _current_plan_config(pipeline_id)
    prompt = (
        "你是面试指令解析器。把用户输入解析为结构化 JSON，驱动后续面试操作。\n"
        "只能从以下 intent 中选择一个：\n"
        "- modify_questions：修改/替换/调整面试题\n"
        "- schedule_interview：安排/预约面试\n"
        "- reschedule_interview：改期/调整面试时间\n"
        "- cancel_interview：取消面试\n"
        "- configure_assessment_plan：配置评估方案\n\n"
        "各 intent 字段：\n"
        "modify_questions: candidate_name（可选；若页面已提供当前候选人上下文则可省略）, question_scope(single|subset|all), question_index(正整数,仅single), question_indices(题号数组,仅subset), modification\n"
        "schedule_interview: candidate_name, date, time(HH:MM), interviewer, method(线上|线下), duration, round, notes\n"
        "reschedule_interview: candidate_name, schedule_id, date, time(HH:MM), interviewer, method(线上|线下), duration, round, notes\n"
        "cancel_interview: candidate_name, schedule_id\n"
        "configure_assessment_plan: plan_name, combination(all|any|conditional), steps, condition\n\n"
        "规则：\n"
        '1. 必须输出名为 "intent" 的字段，值为上面五个之一；信息不全也要先确定 intent，再用 missing_fields 列出缺失字段。\n'
        '2. 用户说“第N题/这一题/某一道题”→ question_scope="single" 且 question_index=N；说“前N道题”或多个明确题号→ question_scope="subset" 且填写 question_indices；说“整套/所有题/全部题目”→ question_scope="all"。\n'
        "3. modification 用一句话概括用户对题目的修改诉求（难度、时长、题型等）。\n"
        "4. candidate_name 去掉前后 *、#、空格等符号。\n"
        "5. 配置评估方案时 combination 只能是 all/any/conditional，steps 的 modality 只能是 "
        "written_test/video_interview/manual_interview；条件分支必须给 source_step、operator、threshold，"
        "以及 then_step/then_action 和 else_step/else_action。改期字段 date/time 表示新的日期和时间。\n"
        "6. 如果用户说“当前候选人/这个候选人/该候选人”，不要把这些泛称当作真实姓名；候选人由页面上下文提供。\n"
        "7. 只输出一个 JSON 对象，不要解释，不要 markdown 围栏。\n\n"
        f"当前已启用评估方案：{json.dumps(current_plan, ensure_ascii=False)}\n"
        f"当前命令 JSON：{json.dumps(previous_payload, ensure_ascii=False)}\n"
        f"用户补充：{message}\n\n"
        "示例：\n"
        '输入"修改林晓峰第三题，难度改成中等，时间5分钟" → '
        '{"intent":"modify_questions","candidate_name":"林晓峰","question_scope":"single",'
        '"question_index":3,"modification":"难度改为中等，时长5分钟"}\n'
        '输入"把王五的面试改到明天下午3点线上" → '
        '{"intent":"reschedule_interview","candidate_name":"王五","date":"明天",'
        '"time":"15:00","method":"线上","missing_fields":["schedule_id"]}\n'
    )
    system = "只做指令解析，不执行工具，不生成 SQL、URL 或其他动作。只返回一个 JSON 对象。"
    parsed = await _call_llm_json(prompt, system, json_mode=True)
    parsed = _flatten_parsed(parsed if isinstance(parsed, dict) else {})
    intent = (
        parsed.get("intent") or parsed.get("action") or parsed.get("operation") or previous_payload.get("intent", "")
    )
    if intent not in ALLOWED_INTENTS:
        intent = _fallback_intent(message)
    if intent not in ALLOWED_INTENTS:
        return "", {}

    allowed_fields = _INTENT_FIELDS[intent]
    payload = {key: value for key, value in previous_payload.items() if key in allowed_fields}
    for key in allowed_fields:
        value = parsed.get(key)
        if value not in (None, ""):
            payload[key] = value

    if payload.get("candidate_name"):
        payload["candidate_name"] = _clean_candidate_name(payload["candidate_name"])

    # 兜底推导 question_scope：LLM 偶发漏填时，依据 question_index 或原文关键词补齐。
    if intent == "modify_questions" and payload.get("question_scope") not in {"single", "subset", "all"}:
        if not _valid_question_index(payload.get("question_index")):
            payload["question_index"] = _parse_question_index(message)
        if _valid_question_index(payload.get("question_index")):
            payload["question_scope"] = "single"
        elif _ALL_QUESTION_RE.search(message):
            payload["question_scope"] = "all"

    return intent, _normalize_plan_payload(payload) if intent == "configure_assessment_plan" else payload


def _fast_modify_payload(
    pipeline_id: str, message: str, default_candidate_id: str, previous_command: dict | None
) -> dict | None:
    """小面页面已有候选人时，为明确的改题指令跳过一次意图解析 LLM。

    只处理当前候选人且题目范围明确的短指令；显式点名、排期和含糊指令仍走完整解析，
    这样可以减少常见“当前候选人第 N 题改难”场景的一次串行网络请求而不改变复杂语义。
    """
    if previous_command or not default_candidate_id:
        return None
    text = message.strip()
    if not _FAST_MODIFY_RE.search(text):
        return None
    if any(keyword in text for keyword in ("面试时间", "安排面试", "预约面试", "排期", "面试官")):
        return None
    single_match = _FAST_SINGLE_RE.search(text)
    prefix_match = _FAST_PREFIX_RE.search(text)
    enum_matches = _FAST_ENUM_RE.findall(text)
    enum_indices = [_chinese_or_int(value) for value in enum_matches]
    if len(enum_indices) < 2:
        enum_indices = []
    all_match = _FAST_ALL_RE.search(text)
    generic_context = ("当前候选人", "这个候选人", "该候选人", "这位候选人")
    # 没有候选人称呼时，页面当前选中项就是上下文；但显式写出其他候选人姓名时不能误用当前 ID。
    normalized_text = _normalize_candidate_name(text)
    explicit_name = any(
        normalized_name and normalized_name in normalized_text
        for candidate in get_candidates(pipeline_id)
        if candidate.get("id") != default_candidate_id
        for normalized_name in [_normalize_candidate_name(candidate.get("name"))]
    )
    if explicit_name:
        return None
    if (
        not any(keyword in text for keyword in generic_context)
        and not single_match
        and not prefix_match
        and not enum_indices
        and not all_match
    ):
        return None
    if single_match:
        question_scope = "single"
        question_index = int(single_match.group(1))
    elif prefix_match:
        question_scope = "subset"
        question_index = None
    elif enum_indices:
        question_scope = "subset"
        question_index = None
    elif all_match or "面试题" in text:
        question_scope = "all"
        question_index = None
    else:
        return None
    return {
        "intent": "modify_questions",
        "candidate_id": default_candidate_id,
        "question_scope": question_scope,
        "question_index": question_index,
        "question_indices": (
            list(range(1, _chinese_or_int(prefix_match.group(1)) + 1)) if prefix_match else enum_indices
        ),
        "modification": text,
    }


def _explicit_question_scope(message: str) -> tuple[str, list[int]] | None:
    """在调用模型前锁定用户明确写出的题号范围。"""
    prefix_match = _FAST_PREFIX_RE.search(message)
    if prefix_match:
        count = _chinese_or_int(prefix_match.group(1))
        return ("subset", list(range(1, count + 1))) if count > 0 else None
    indices = sorted(
        set(index for index in (_chinese_or_int(value) for value in _FAST_ENUM_RE.findall(message)) if index > 0)
    )
    return ("subset", indices) if len(indices) >= 2 else None


def _chinese_or_int(value: str) -> int:
    if value.isdigit():
        return int(value)
    units = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
    if value == "十":
        return 10
    if value.startswith("十"):
        return 10 + units.get(value[1:], 0)
    if value.endswith("十"):
        return units.get(value[0], 0) * 10
    if "十" in value:
        return units.get(value[0], 0) * 10 + units.get(value[-1], 0)
    return units.get(value, 0)


def _apply_question_scope_hint(message: str, payload: dict) -> dict:
    """用用户原话纠正模型可能把“前三道题”压缩成单个题号的问题。"""
    prefix_match = _FAST_PREFIX_RE.search(message)
    if prefix_match:
        count = _chinese_or_int(prefix_match.group(1))
        if count > 0:
            payload["question_scope"] = "subset"
            payload["question_index"] = None
            payload["question_indices"] = list(range(1, count + 1))
        return payload
    enum_indices = [_chinese_or_int(value) for value in _FAST_ENUM_RE.findall(message)]
    enum_indices = sorted(set(index for index in enum_indices if index > 0))
    if len(enum_indices) >= 2:
        payload["question_scope"] = "subset"
        payload["question_index"] = None
        payload["question_indices"] = enum_indices
    return payload


def _normalize_candidate_name(name) -> str:
    """归一化候选人名用于匹配：去掉 *、#、空格等符号，规避导入数据的 ** 前缀标记。"""
    return re.sub(r"[\s*#·]", "", str(name or ""))


def _is_generic_candidate_name(name) -> bool:
    """模型有时会把页面上下文描述误填进 candidate_name，不能拿它做姓名匹配。"""
    normalized = _normalize_candidate_name(name).rstrip("的")
    return normalized in {
        "当前候选人",
        "这个候选人",
        "该候选人",
        "候选人",
        "当前人选",
        "这位候选人",
    }


def _resolve_candidate(pipeline_id: str, candidate_name: str, candidate_id: str = "") -> tuple[dict | None, list[dict]]:
    candidates = get_candidates(pipeline_id)
    if candidate_id:
        selected = next((candidate for candidate in candidates if candidate["id"] == candidate_id), None)
        return (selected, []) if selected else (None, [])
    if not candidate_name:
        return (None, [])
    target = _normalize_candidate_name(candidate_name)
    # 先做归一化精确匹配（“林晓峰” == “** 林晓峰”）。
    matches = [candidate for candidate in candidates if _normalize_candidate_name(candidate["name"]) == target]
    # 归一化精确匹配无果时，用包含关系兜底，容忍用户只说姓氏或带前后缀。
    if not matches and target:
        matches = [
            candidate
            for candidate in candidates
            if target in _normalize_candidate_name(candidate["name"])
            or _normalize_candidate_name(candidate["name"]) in target
        ]
    options = [
        {"candidate_id": candidate["id"], "candidate_name": candidate["name"]}
        for candidate in sorted(matches, key=lambda item: item["id"])
    ]
    return (matches[0], options) if len(matches) == 1 else (None, options)


def _first_missing(intent: str, payload: dict) -> str:
    for field in _REQUIRED_FIELDS[intent]:
        # 候选人 ID 是稳定主键；已有 ID 时不应再要求模型补一个姓名字段。
        if field == "candidate_name" and payload.get("candidate_id"):
            continue
        if payload.get(field) in (None, ""):
            return field
    if intent == "modify_questions":
        if payload.get("question_scope") not in {"single", "subset", "all"}:
            return "question_scope"
        if payload["question_scope"] == "single" and not _valid_question_index(payload.get("question_index")):
            return "question_index"
        if payload["question_scope"] == "subset" and not payload.get("question_indices"):
            return "question_index"
    if intent == "configure_assessment_plan" and payload.get("combination") == "conditional":
        condition = payload.get("condition")
        if not isinstance(condition, dict):
            return "condition"
        if not ({"source_step", "operator", "threshold"} <= set(condition)):
            return "condition"
        if not (condition.get("then_step") or condition.get("then_action")):
            return "condition"
        if not (condition.get("else_step") or condition.get("else_action")):
            return "condition"
    return ""


def _resolve_schedule(pipeline_id: str, payload: dict) -> tuple[dict | None, list[dict]]:
    schedules = [
        schedule
        for schedule in get_interview_schedules(pipeline_id)
        if schedule.get("candidate_id") == payload.get("candidate_id") and schedule.get("status") != "cancelled"
    ]
    schedule_id = payload.get("schedule_id", "")
    if schedule_id:
        selected = next((schedule for schedule in schedules if schedule["id"] == schedule_id), None)
        return (selected, []) if selected else (None, [])
    options = [
        {
            "schedule_id": schedule["id"],
            "date": schedule.get("date", ""),
            "time": schedule.get("time", ""),
            "interviewer": schedule.get("interviewer", ""),
            "method": schedule.get("method", ""),
        }
        for schedule in schedules
    ]
    return (schedules[0], options) if len(schedules) == 1 else (None, options)


def _valid_question_index(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def _invalid_schedule_field(payload: dict) -> str:
    try:
        scheduled_date = date.fromisoformat(str(payload["date"]))
    except (TypeError, ValueError):
        return "date"
    if scheduled_date <= datetime.now(TIMEZONE).date():
        return "date"
    if not TIME_PATTERN.fullmatch(str(payload["time"])):
        return "time"
    return ""


def _questions_version(questions: list) -> str:
    serialized = json.dumps(questions, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _candidate_interview(pipeline_id: str, candidate_id: str) -> dict:
    stage = next(
        (item for item in get_stages(pipeline_id) if item.get("stage_id") == "interview_gen"),
        None,
    )
    output = (stage or {}).get("output") or {}
    interviews = output.get("interviews", []) if isinstance(output, dict) else []
    interview = next((item for item in interviews if item.get("candidate_id") == candidate_id), None)
    if not interview:
        raise ValueError("该候选人没有面试题")
    return interview


def _candidate_questions(pipeline_id: str, candidate_id: str) -> list[dict]:
    interview = _candidate_interview(pipeline_id, candidate_id)
    questions = interview.get("questions", [])
    if not questions:
        raise ValueError("该候选人没有面试题")
    return deepcopy(questions)


def _question_generation_context(pipeline_id: str, modification: str) -> tuple[str, str]:
    """读取批量生题同源的岗位 JD 与知识库参考，限制长度避免 Prompt 膨胀。"""
    stage = next((item for item in get_stages(pipeline_id) if item.get("stage_id") == "jd_write"), None)
    stage_output = (stage or {}).get("output") or {}
    jd = stage_output.get("jd", {}) if isinstance(stage_output, dict) else {}
    jd_context = json.dumps(jd, ensure_ascii=False, separators=(",", ":"), default=str)[:3500]
    try:
        from knowledge import KnowledgeBase

        knowledge_context = KnowledgeBase().get_context_for_intent("modify_interview", modification)
    except Exception:
        knowledge_context = ""
    return jd_context, str(knowledge_context or "")[:1200]


async def _build_question_preview(pipeline_id: str, payload: dict) -> dict:
    from app.question_review import ensure_questions_editable

    ensure_questions_editable(pipeline_id, payload["candidate_id"])
    before_interview = _candidate_interview(pipeline_id, payload["candidate_id"])
    before_questions = deepcopy(before_interview.get("questions", []))
    if not before_questions:
        raise ValueError("该候选人没有面试题")
    after_questions = deepcopy(before_questions)
    if payload["question_scope"] == "single":
        question_index = payload["question_index"]
        if question_index > len(before_questions):
            raise ValueError("题目索引不存在")
        generated = await _generate_single_question(pipeline_id, before_questions[question_index - 1], payload)
        after_questions[question_index - 1] = generated
        unchanged_count = len(before_questions) - 1
    elif payload["question_scope"] == "subset":
        indices = payload.get("question_indices") or []
        if not indices or any(index < 1 or index > len(before_questions) for index in indices):
            raise ValueError("题目索引不存在")
        selected_questions = [before_questions[index - 1] for index in indices]
        generated_questions = await _generate_all_questions(pipeline_id, selected_questions, payload)
        for index, generated in zip(indices, generated_questions):
            after_questions[index - 1] = generated
        question_index = None
        unchanged_count = len(before_questions) - len(indices)
    else:
        after_questions = await _generate_all_questions(pipeline_id, before_questions, payload)
        question_index = None
        unchanged_count = 0
    return {
        "kind": "question_diff",
        "candidate_id": payload["candidate_id"],
        "candidate_name": payload["candidate_name"],
        "question_scope": payload["question_scope"],
        "question_index": question_index,
        "before_questions": before_questions,
        "after_questions": after_questions,
        "unchanged_count": unchanged_count,
        "questions_version": _questions_version(before_questions),
        "before_review_status": before_interview.get("review_status", "reviewed"),
    }


def _build_assessment_plan_preview(pipeline_id: str, payload: dict) -> dict:
    active = assessment_flow.get_active_plan(pipeline_id)
    config = assessment_flow.validate_plan(
        {
            "name": payload.get("plan_name") or "评估方案",
            "combination": payload["combination"],
            "steps": payload["steps"],
            **({"condition": payload["condition"]} if payload.get("condition") else {}),
        }
    )
    return {
        "kind": "assessment_plan",
        "before_plan_id": (active or {}).get("id", ""),
        "before_version": (active or {}).get("version", 0),
        "before_config": deepcopy((active or {}).get("config") or {}),
        "after_config": config,
        "next_version": int((active or {}).get("version", 0)) + 1,
    }


async def _generate_single_question(pipeline_id: str, current_question: dict, payload: dict) -> dict:
    jd_context, knowledge_context = _question_generation_context(pipeline_id, str(payload["modification"]))
    prompt = (
        "根据修改要求重写这一道面试题，只返回需要更新的字段 JSON：question，以及确实被要求修改的"
        "difficulty 或 duration。其他字段由系统沿用原题，不要输出。\n"
        "必须让 difficulty、duration 等字段真正反映修改要求，而不是只改 question 文本。\n"
        "题目内容也必须围绕修改要求进行实质性重写；即使要求主要涉及难度或时长，也要调整题干的"
        "考察深度、约束条件或场景，禁止原样返回当前 question。\n"
        "不要增删其他题，不要输出解释、markdown 或原题中未要求修改的字段。\n"
        f"岗位 JD：{jd_context or '无'}\n"
        f"知识库参考：{knowledge_context or '无'}\n"
        f"当前题目：{json.dumps({key: current_question.get(key) for key in ('type', 'question', 'difficulty', 'duration', 'expected_points') if key in current_question}, ensure_ascii=False)}\n"
        f"修改要求：{payload['modification']}"
    )
    generated = await _call_llm_json(prompt, "只返回一道有效面试题 JSON，字段与原题对齐。", json_mode=True)
    # 某些模型只改 difficulty/duration 而复述原题；追加一次强约束重试，
    # 确保“改难度/时长”同时带来题干层面的实质变化。
    if isinstance(generated, dict) and generated.get("question") == current_question.get("question"):
        retry_prompt = (
            f"{prompt}\n\n强制约束：新题干必须与原题不同，必须通过增加/减少约束、场景复杂度或考察深度"
            "体现修改后的难度；禁止复制原题。"
        )
        generated = await _call_llm_json(retry_prompt, "只返回一道题干明显不同的有效面试题 JSON。", json_mode=True)
    if not isinstance(generated, dict) or not generated.get("question"):
        raise ValueError("题目生成结果无效")
    rewritten = deepcopy(current_question)
    # 仅接受原题已有字段，避免 LLM 引入杂键；LLM 未返回的字段保持原值。
    for key, value in generated.items():
        if key in current_question:
            rewritten[key] = value
    return rewritten


async def _generate_all_questions(pipeline_id: str, before_questions: list[dict], payload: dict) -> list[dict]:
    jd_context, knowledge_context = _question_generation_context(pipeline_id, str(payload["modification"]))
    prompt = (
        "按要求重写整套面试题，只返回 questions 数组；题目数量必须保持不变，每道题只返回 question，"
        "以及确实被要求修改的 difficulty 或 duration。其他字段由系统沿用原题，不要输出解释或多余字段。\n"
        f"岗位 JD：{jd_context or '无'}\n"
        f"知识库参考：{knowledge_context or '无'}\n"
        f"当前题目概要：{json.dumps([{key: question.get(key) for key in ('type', 'question', 'difficulty', 'duration') if key in question} for question in before_questions], ensure_ascii=False)}\n"
        f"修改要求：{payload['modification']}"
    )
    generated = await _call_llm_json(
        prompt, '只返回 JSON；优先使用 {"questions":[...]}，也兼容直接返回题目数组。', json_mode=True
    )
    # 不同模型对“返回 questions 数组”的理解不同：兼容对象包裹和直接数组。
    questions = _question_array(generated)
    if not isinstance(questions, list) or len(questions) != len(before_questions):
        raise ValueError("整套改题必须保持题目数量")
    # 模型偶尔只改了部分题或复述原题。只要有任一题干未变化，就整体强约束重试，
    # 避免出现用户选了 4 道题、预览却只显示“修改 2 道”的静默部分成功。
    if questions and any(
        not isinstance(after, dict) or not after.get("question") or after.get("question") == before.get("question")
        for before, after in zip(before_questions, questions)
    ):
        retry_prompt = (
            f"{prompt}\n\n强制要求：每一道题的 question 都必须重写为与原题不同的新题干，"
            "并体现本次修改要求；禁止原样复制任何原题。"
        )
        generated = await _call_llm_json(retry_prompt, "只返回题目数组 JSON，所有题干必须与原题不同。", json_mode=True)
        questions = _question_array(generated)
    if not isinstance(questions, list) or len(questions) != len(before_questions):
        raise ValueError("整套改题必须保持题目数量")
    result = []
    for before, after in zip(before_questions, questions):
        if not isinstance(after, dict) or not after.get("question"):
            raise ValueError("题目生成结果无效")
        merged = deepcopy(before)
        for key, value in after.items():
            if key in before:
                merged[key] = value
        modification = str(payload.get("modification", ""))
        if "简单" in modification:
            merged["difficulty"] = "简单"
        elif "困难" in modification:
            merged["difficulty"] = "困难"
        result.append(merged)
    return result


def _question_array(generated) -> list[dict] | None:
    """兼容模型返回 {questions: [...]} 与直接返回 [...] 两种 JSON 结构。"""
    if isinstance(generated, dict):
        questions = generated.get("questions")
    elif isinstance(generated, list):
        questions = generated
    else:
        questions = None
    return questions if isinstance(questions, list) else None


def _build_schedule_preview(pipeline_id: str, payload: dict, exclude_schedule_id: str = "") -> dict:
    scheduled_date = date.fromisoformat(payload["date"])
    scheduled_time = time.fromisoformat(payload["time"])
    scheduled_at = datetime.combine(scheduled_date, scheduled_time, tzinfo=TIMEZONE)
    conflicts = _schedule_conflicts(pipeline_id, payload, exclude_schedule_id)
    return {
        "kind": "schedule",
        "candidate_id": payload["candidate_id"],
        "candidate_name": payload["candidate_name"],
        "date": payload["date"],
        "time": payload["time"],
        "scheduled_at": scheduled_at.isoformat(),
        "timezone": "Asia/Shanghai",
        "interviewer": payload["interviewer"],
        "method": payload["method"],
        "conflicts": conflicts,
        "conflict_check_scope": "internal_schedules_only",
    }


def _schedule_conflicts(pipeline_id: str, payload: dict, exclude_schedule_id: str = "") -> list[dict]:
    conflicts = []
    for schedule in get_interview_schedules(pipeline_id):
        if schedule.get("id") == exclude_schedule_id:
            continue
        if schedule.get("status") == "cancelled":
            continue
        if schedule.get("date") != payload["date"] or schedule.get("time") != payload["time"]:
            continue
        conflict = {
            "schedule_id": schedule["id"],
            "date": schedule.get("date", ""),
            "time": schedule.get("time", ""),
            "candidate_id": schedule.get("candidate_id", ""),
            "interviewer": schedule.get("interviewer", ""),
        }
        if schedule.get("candidate_id") == payload["candidate_id"]:
            conflicts.append({**conflict, "type": "candidate"})
        if schedule.get("interviewer") == payload["interviewer"]:
            conflicts.append({**conflict, "type": "interviewer"})
    return conflicts


def _build_schedule_change_preview(pipeline_id: str, payload: dict, schedule: dict) -> dict:
    action = "cancel" if payload["intent"] == "cancel_interview" else "reschedule"
    after_schedule = deepcopy(schedule)
    if action == "cancel":
        after_schedule["status"] = "cancelled"
        conflicts = []
    else:
        invalid_field = _invalid_schedule_field(payload)
        if invalid_field:
            return {"invalid_field": invalid_field}
        for field in ("date", "time", "interviewer", "method", "round", "notes"):
            if payload.get(field) not in (None, ""):
                after_schedule[field] = payload[field]
        conflicts = _schedule_conflicts(pipeline_id, after_schedule, schedule["id"])
    return {
        "kind": "schedule_change",
        "action": action,
        "candidate_id": payload["candidate_id"],
        "candidate_name": payload["candidate_name"],
        "schedule_id": schedule["id"],
        "before_schedule": deepcopy(schedule),
        "after_schedule": after_schedule,
        "conflicts": conflicts,
        "conflict_check_scope": "internal_schedules_only",
    }


def _persist_command(
    existing: dict | None,
    pipeline_id: str,
    message: str,
    source: str,
    intent: str,
    status: str,
    payload: dict,
    preview: dict,
) -> str:
    if existing:
        update_interview_command(
            existing["id"],
            source=source,
            source_text=message,
            intent=intent,
            status=status,
            payload=payload,
            preview=preview,
        )
        return existing["id"]
    command_id = f"cmd_{uuid.uuid4().hex}"
    return save_interview_command(
        {
            "id": command_id,
            "pipeline_id": pipeline_id,
            "source": source,
            "source_text": message,
            "intent": intent,
            "status": status,
            "payload": payload,
            "preview": preview,
            "result": {},
        }
    )


def _clarification_result(
    intent: str,
    payload: dict,
    field: str,
    candidate_options: list[dict] | None = None,
    schedule_options: list[dict] | None = None,
) -> dict:
    return {
        "intent": intent,
        "status": "clarifying",
        "message": _CLARIFICATION_MESSAGES[field],
        "missing_fields": [field],
        "candidate_options": candidate_options or [],
        "schedule_options": schedule_options or [],
        "payload": payload,
        "preview": {},
    }


async def preview_message(
    pipeline_id: str,
    message: str,
    source: str = "text",
    previous_command: dict | None = None,
    default_candidate_id: str = "",
) -> dict:
    """解析一句指令并生成无副作用预览，由调用方决定如何持久化。

    default_candidate_id：指令未提及候选人时的默认上下文（页面当前选中），
    仅在解析结果既无 candidate_name 也无 candidate_id 时兜底，显式点名优先。
    """
    if previous_command and previous_command["pipeline_id"] != pipeline_id:
        raise ValueError("命令不属于当前 pipeline")

    previous_payload = dict(previous_command.get("payload", {})) if previous_command else {}
    if previous_command:
        previous_payload["intent"] = previous_command.get("intent", "")
    explicit_scope = _explicit_question_scope(message) if not previous_command else None
    fast_payload = None
    if (
        explicit_scope
        and default_candidate_id
        and not any(keyword in message for keyword in ("面试时间", "安排面试", "预约面试", "排期", "面试官"))
    ):
        selected, _ = _resolve_candidate(pipeline_id, "", default_candidate_id)
        if selected:
            fast_payload = {
                "intent": "modify_questions",
                "candidate_id": default_candidate_id,
                "candidate_name": selected.get("name", ""),
                "question_scope": explicit_scope[0],
                "question_index": None,
                "question_indices": explicit_scope[1],
                "modification": message.strip(),
            }
    if not fast_payload:
        fast_payload = _fast_modify_payload(pipeline_id, message, default_candidate_id, previous_command)
    if fast_payload:
        intent, payload = fast_payload["intent"], fast_payload
    else:
        intent, payload = await _parse_command(pipeline_id, message, previous_payload)
    if intent == "modify_questions":
        payload = _apply_question_scope_hint(message, payload)
    if not intent:
        return _clarification_result("", {}, "intent")

    if intent == "configure_assessment_plan":
        missing_field = _first_missing(intent, payload)
        if missing_field:
            return _clarification_result(intent, payload, missing_field)
        return {
            "intent": intent,
            "status": "awaiting_confirm",
            "missing_fields": [],
            "payload": payload,
            "preview": _build_assessment_plan_preview(pipeline_id, payload),
        }

    candidate_name = payload.get("candidate_name", "")
    candidate_id = payload.get("candidate_id", "")
    # 页面已经传入稳定 ID 时，模型返回的泛称不应覆盖该上下文。
    if candidate_name and _is_generic_candidate_name(candidate_name) and default_candidate_id:
        candidate_name = ""
        payload.pop("candidate_name", None)
    # 新指令未提及候选人 → 用页面当前选中的候选人作为默认上下文，免去一轮澄清。
    if not candidate_name and not candidate_id and default_candidate_id:
        candidate_id = default_candidate_id
        payload["candidate_id"] = candidate_id
    candidate, options = (
        _resolve_candidate(pipeline_id, candidate_name, candidate_id) if candidate_name or candidate_id else (None, [])
    )
    # 名字匹配到多位候选人时，若前端已选中其中一位，则用它消歧，免去一轮澄清。
    if not candidate and options and default_candidate_id:
        if any(option["candidate_id"] == default_candidate_id for option in options):
            candidate, options = _resolve_candidate(pipeline_id, "", default_candidate_id)
    if (candidate_name or candidate_id) and not candidate:
        return _clarification_result(intent, payload, "candidate_name", options)
    if candidate:
        payload["candidate_id"] = candidate["id"]
        payload["candidate_name"] = candidate["name"]

    schedule = None
    if intent in {"reschedule_interview", "cancel_interview"} and payload.get("candidate_id"):
        schedule, schedule_options = _resolve_schedule(pipeline_id, payload)
        if not schedule:
            if schedule_options:
                return _clarification_result(intent, payload, "schedule_id", schedule_options=schedule_options)
            raise ValueError("该候选人没有待进行面试")
        payload["schedule_id"] = schedule["id"]
        if intent == "reschedule_interview":
            for field in ("interviewer", "method", "round", "notes"):
                if payload.get(field) in (None, ""):
                    payload[field] = schedule.get(field, "")

    missing_field = _first_missing(intent, payload)
    if missing_field:
        return _clarification_result(intent, payload, missing_field)
    if intent in {"schedule_interview", "reschedule_interview"}:
        invalid_field = _invalid_schedule_field(payload)
        if invalid_field:
            return _clarification_result(intent, payload, invalid_field)
    if intent in {"reschedule_interview", "cancel_interview"}:
        preview = _build_schedule_change_preview(pipeline_id, {**payload, "intent": intent}, schedule)
    elif intent == "schedule_interview":
        preview = _build_schedule_preview(pipeline_id, payload)
    else:
        preview = await _build_question_preview(pipeline_id, payload)

    return {
        "intent": intent,
        "status": "awaiting_confirm",
        "missing_fields": [],
        "payload": payload,
        "preview": preview,
    }


async def submit_message(
    pipeline_id: str,
    message: str,
    source: str = "text",
    command_id: str = "",
) -> dict:
    """兼容旧调用：解析指令并写入旧面试命令账本。"""
    existing = get_interview_command(command_id) if command_id else None
    result = await preview_message(pipeline_id, message, source, existing)
    persisted_id = _persist_command(
        existing,
        pipeline_id,
        message,
        source,
        result["intent"],
        result["status"],
        result["payload"],
        result["preview"],
    )
    return {"command_id": persisted_id, **result}
