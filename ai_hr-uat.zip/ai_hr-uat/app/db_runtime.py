"""MySQL connection runtime shared by the database facade.

This module owns connection wrappers and transaction mechanics.  The public
``app.db`` module remains the compatibility facade for existing callers and
for tests that reset its legacy module-level state.
"""

import os
import threading
from contextlib import contextmanager
from typing import Any

MYSQL_CONFIG = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "ai_hr_os"),
    "charset": "utf8mb4",
    "autocommit": True,
}

# These aliases are intentionally module-level: app.db synchronizes its
# legacy state with them before invoking runtime functions.
_conn = None
_write_lock = threading.Lock()
_local = threading.local()


class MySQLRow(dict):
    """A row supporting both mapping keys and legacy positional access."""

    def __getitem__(self, key):
        if isinstance(key, (int, slice)):
            return list(super().values())[key]
        return super().__getitem__(key)


class MySQLCursor:
    def __init__(self, cursor):
        self._cursor = cursor

    def fetchone(self):
        return _wrap_row(self._cursor.fetchone())

    def fetchall(self):
        return [_wrap_row(row) for row in self._cursor.fetchall()]

    def __getattr__(self, name):
        return getattr(self._cursor, name)


class MySQLConn:
    def __init__(self, config):
        self.config = config
        self._conn = None
        self._lock = threading.RLock()
        self._transaction_active = False

    @property
    def in_transaction(self):
        """Expose transaction state used by audit helpers."""
        return self._transaction_active

    def _ensure_conn(self):
        # PyMySQL 2.x 弃用了 ping(reconnect=True)：改为显式检测断线后重建连接。
        if self._conn is not None:
            try:
                self._conn.ping(reconnect=False)
            except Exception:
                try:
                    self._conn.close()
                except Exception:
                    pass
                self._conn = None
        if self._conn is None:
            pymysql, dict_cursor = _pymysql_dependencies()
            self._conn = pymysql.connect(**self.config, cursorclass=dict_cursor)

    def execute(self, sql, params=None):
        with self._lock:
            self._ensure_conn()
            cursor = self._conn.cursor()
            pymysql, _ = _pymysql_dependencies()
            if not params and sql.strip().upper().startswith(("CREATE TABLE", "CREATE INDEX", "CREATE UNIQUE INDEX")):
                try:
                    cursor.execute(sql)
                except pymysql.err.OperationalError as error:
                    if error.args and error.args[0] == 1061:
                        return MySQLCursor(cursor)
                    raise
            else:
                cursor.execute(sql, params or ())
            return MySQLCursor(cursor)

    def executemany(self, sql, params):
        with self._lock:
            self._ensure_conn()
            cursor = self._conn.cursor()
            cursor.executemany(sql, params)
            return MySQLCursor(cursor)

    def executescript(self, script):
        """Execute semicolon-separated DDL statements on MySQL."""
        cursor = None
        for raw in script.split(";"):
            lines = [line for line in raw.splitlines() if not line.lstrip().startswith("--")]
            statement = "\n".join(lines).strip()
            if not statement:
                continue
            try:
                cursor = self.execute(statement)
            except Exception:
                if statement.lstrip().upper().startswith(("CREATE INDEX", "CREATE UNIQUE INDEX")):
                    continue
                raise
        return cursor

    def commit(self):
        with self._lock:
            if self._conn:
                self._conn.commit()

    def rollback(self):
        with self._lock:
            if self._conn:
                self._conn.rollback()

    def close(self):
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
            self._transaction_active = False


def _pymysql_dependencies():
    try:
        import pymysql
        from pymysql.cursors import DictCursor
    except ImportError as exc:
        raise RuntimeError("需要安装 pymysql: pip install pymysql") from exc
    return pymysql, DictCursor


def _wrap_row(row):
    return None if row is None else MySQLRow(row)


def create_mysql_pool(config: dict[str, Any] | None = None):
    """Create a wrapped MySQL connection using the supplied configuration."""
    return MySQLConn(config if config is not None else MYSQL_CONFIG)


def get_db():
    """Return the current thread's connection, creating it on first use."""
    global _conn
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = create_mysql_pool()
        _local.conn = conn
        if _conn is None:
            _conn = conn
    return conn


@contextmanager
def transaction():
    """Run multi-table writes in one transaction on the current thread."""
    conn = get_db()
    conn._ensure_conn()
    conn._conn.begin()
    conn._transaction_active = True
    try:
        yield conn
        conn._conn.commit()
    except Exception:
        conn._conn.rollback()
        raise
    finally:
        conn._transaction_active = False
