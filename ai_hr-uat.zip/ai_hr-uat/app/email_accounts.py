"""Mailbox accounts, object permissions, credentials, and sync-run persistence."""

from __future__ import annotations

import base64
import hashlib
import os
import uuid
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from app.access_control import is_tenant_admin, tenant_id_for_user
from app.audit.audit_trail import audit
from app.db import get_db
from app.email_logging import get_email_logger

PERMISSION_RANK = {"read": 1, "sync": 2, "manage": 3}
# 仅用于兼容读取历史遗留的本地密钥文件；新密钥一律由 EMAIL_CREDENTIAL_KEY 提供，不再落盘。
KEY_FILE = Path(__file__).resolve().parent.parent / "data" / "email_credential.key"
logger = get_email_logger()


class EmailDomainError(Exception):
    def __init__(self, code: str, message: str, status_code: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code


def _key_bytes() -> bytes:
    configured = os.getenv("EMAIL_CREDENTIAL_KEY", "").strip()
    if configured:
        raw = configured.encode("ascii")
        try:
            Fernet(raw)
            return raw
        except ValueError:
            return base64.urlsafe_b64encode(hashlib.sha256(raw).digest())

    if KEY_FILE.exists():
        logger.warning(
            "仍在读取遗留的邮箱凭据密钥文件 %s，请迁移到环境变量 EMAIL_CREDENTIAL_KEY 后移除该文件",
            KEY_FILE,
        )
        return KEY_FILE.read_bytes().strip()

    raise EmailDomainError(
        "EMAIL_CREDENTIAL_KEY_MISSING",
        "未配置邮箱凭据密钥：请设置环境变量 EMAIL_CREDENTIAL_KEY（Fernet 兼容密钥）",
        500,
    )


def encrypt_credential(value: str) -> str:
    if not value:
        return ""
    return Fernet(_key_bytes()).encrypt(value.encode("utf-8")).decode("ascii")


def decrypt_credential(value: str) -> str:
    if not value:
        raise EmailDomainError("EMAIL_CREDENTIAL_MISSING", "邮箱凭据未配置", 409)
    try:
        return Fernet(_key_bytes()).decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, ValueError) as exc:
        raise EmailDomainError("EMAIL_CREDENTIAL_DECRYPT_FAILED", "邮箱凭据解密失败", 500) from exc


def mask_email(value: str) -> str:
    if not value:
        return ""
    if "@" not in value:
        return f"{value[:1]}***" if value else "***"
    local, domain = value.split("@", 1)
    return f"{local[:1] or '*'}***@{domain}"


def _serialize_account(row, permission: str = "manage") -> dict:
    account = dict(row)
    account["enabled"] = bool(account.get("enabled"))
    account["email_address_masked"] = mask_email(account.pop("email_address", ""))
    account["username_masked"] = mask_email(account.pop("username", ""))
    account["credential_configured"] = bool(account.pop("credential_ciphertext", ""))
    account.pop("credential_key_version", None)
    account.pop("access_permission", None)
    account["permission"] = permission
    return account


def _access_row(account_id: str, user: dict):
    tenant_id = tenant_id_for_user(user)
    row = (
        get_db()
        .execute("SELECT * FROM email_accounts WHERE id=%s AND tenant_id=%s", (account_id, tenant_id))
        .fetchone()
    )
    if not row:
        raise EmailDomainError("EMAIL_ACCOUNT_NOT_FOUND", "邮箱不存在或无权访问", 404)
    account = dict(row)
    if is_tenant_admin(user) or account["owner_user_id"] == user["id"]:
        return account, "manage"
    grant = (
        get_db()
        .execute(
            "SELECT permission FROM email_account_grants WHERE email_account_id=%s AND user_id=%s",
            (account_id, user["id"]),
        )
        .fetchone()
    )
    if not grant:
        raise EmailDomainError("EMAIL_ACCOUNT_NOT_FOUND", "邮箱不存在或无权访问", 404)
    return account, grant["permission"]


def get_account(account_id: str, user: dict, *, include_secret: bool = False, permission: str = "read") -> dict:
    account, actual = _access_row(account_id, user)
    if PERMISSION_RANK.get(actual, 0) < PERMISSION_RANK[permission]:
        raise EmailDomainError("EMAIL_ACCOUNT_FORBIDDEN", "当前授权级别不允许此操作", 403)
    if include_secret:
        account["credential"] = decrypt_credential(account.pop("credential_ciphertext", ""))
        return account
    return _serialize_account(account, actual)


def expire_stale_sync_runs(account_id: str = "") -> list[str]:
    """Fail expired active runs and release leases left behind by terminal runs."""
    conn = get_db()
    due_expression = "NOW()"
    params: list[str] = []
    account_clause = ""
    if account_id:
        account_clause = " AND l.email_account_id=%s"
        params.append(account_id)
    rows = conn.execute(
        "SELECT l.email_account_id, l.run_id, r.status FROM email_sync_leases l "
        "LEFT JOIN email_sync_runs r ON r.id=l.run_id "
        f"WHERE (l.expires_at<={due_expression} OR r.id IS NULL "
        f"OR r.status NOT IN ('queued','running')){account_clause}",
        params,
    ).fetchall()
    releasable_run_ids = [row["run_id"] for row in rows]
    if not releasable_run_ids:
        return []

    expired_run_ids = []
    finished_expression = "NOW()"
    for row in rows:
        if row["status"] not in {"queued", "running"}:
            logger.warning(
                "清理已结束同步任务的残留租约 account=%s run=%s status=%s",
                row["email_account_id"],
                row["run_id"],
                row["status"] or "missing",
            )
            continue
        expired_run_ids.append(row["run_id"])
        conn.execute(
            f"UPDATE email_sync_runs SET status='failed', finished_at={finished_expression}, "
            "error_code='EMAIL_SYNC_LEASE_EXPIRED', error_message='同步任务租约过期' "
            "WHERE id=%s AND status IN ('queued','running')",
            (row["run_id"],),
        )
        logger.warning(
            "过期同步任务已自动收尾 account=%s run=%s code=EMAIL_SYNC_LEASE_EXPIRED",
            row["email_account_id"],
            row["run_id"],
        )
    placeholders = ",".join("%s" for _ in releasable_run_ids)
    conn.execute(f"DELETE FROM email_sync_leases WHERE run_id IN ({placeholders})", releasable_run_ids)
    conn.commit()
    # The database transition is authoritative, but an in-process worker must
    # also be cancelled so it cannot continue writing after lease expiry.
    if expired_run_ids:
        try:
            from app.email_sync import cancel_sync_tasks

            cancel_sync_tasks(expired_run_ids)
        except ImportError:
            # Keep schema/CLI utilities usable without importing the async worker.
            pass
    return expired_run_ids


def _insert_sync_run_record(
    conn,
    run_id: str,
    account: dict,
    account_id: str,
    trigger_type: str,
    actor: str,
    retry_of_run_id: str | None,
) -> None:
    conn.execute(
        """INSERT INTO email_sync_runs
           (id, tenant_id, email_account_id, trigger_type, triggered_by,
            error_code, error_message, retry_of_run_id)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
        (
            run_id,
            account["tenant_id"],
            account_id,
            trigger_type,
            actor,
            "",
            "",
            retry_of_run_id,
        ),
    )


def create_sync_run(
    account_id: str,
    user: dict | None,
    trigger_type: str = "manual",
    retry_of_run_id: str | None = None,
) -> dict:
    row = get_db().execute("SELECT * FROM email_accounts WHERE id=%s", (account_id,)).fetchone()
    if not row:
        raise EmailDomainError("EMAIL_ACCOUNT_NOT_FOUND", "邮箱不存在", 404)
    account = dict(row)
    actor = user["id"] if user else "system"
    if not account["enabled"] and trigger_type == "schedule":
        raise EmailDomainError("EMAIL_ACCOUNT_DISABLED", "邮箱已停用", 409)
    return _create_sync_run_impl(account_id, account, trigger_type, actor, retry_of_run_id)


def _create_sync_run_impl(
    account_id: str,
    account: dict,
    trigger_type: str,
    actor: str,
    retry_of_run_id: str | None,
) -> dict:
    run_id = f"run_{uuid.uuid4().hex}"
    conn = get_db()
    expire_stale_sync_runs(account_id)
    lease_sql = "INSERT IGNORE INTO email_sync_leases (email_account_id, run_id, expires_at) VALUES (%s,%s,DATE_ADD(NOW(), INTERVAL 30 MINUTE))"
    lease = conn.execute(lease_sql, (account_id, run_id))
    if not lease.rowcount:
        existing = conn.execute(
            "SELECT run_id FROM email_sync_leases WHERE email_account_id=%s", (account_id,)
        ).fetchone()
        logger.warning(
            "拒绝重复同步 account=%s trigger=%s existing_run=%s actor=%s",
            account_id,
            trigger_type,
            existing["run_id"],
            actor,
        )
        raise EmailDomainError("EMAIL_SYNC_ALREADY_RUNNING", existing["run_id"], 409)
    try:
        _insert_sync_run_record(conn, run_id, account, account_id, trigger_type, actor, retry_of_run_id)
        conn.commit()
    except Exception:
        conn.execute("DELETE FROM email_sync_leases WHERE email_account_id=%s AND run_id=%s", (account_id, run_id))
        conn.commit()
        raise
    audit("email_sync.triggered", "触发邮箱同步", actor, "email_sync_run", run_id, {"account_id": account_id})
    logger.info(
        "同步任务已创建 run=%s account=%s trigger=%s actor=%s retry_of=%s interval=%s",
        run_id,
        account_id,
        trigger_type,
        actor,
        retry_of_run_id or "-",
        account["interval_minutes"],
    )
    return dict(get_db().execute("SELECT * FROM email_sync_runs WHERE id=%s", (run_id,)).fetchone())


def trigger_sync_all(user: dict) -> dict:
    """Queue one manual sync run for every enabled mailbox in the tenant.

    All-or-nothing on conflicts: if any enabled mailbox already has an active
    lease the whole request fails before anything is queued.
    """
    tenant_id = tenant_id_for_user(user)
    expire_stale_sync_runs()
    rows = (
        get_db()
        .execute(
            "SELECT * FROM email_accounts WHERE tenant_id=%s AND enabled=1 ORDER BY created_at",
            (tenant_id,),
        )
        .fetchall()
    )
    accounts = [dict(row) for row in rows]
    if not accounts:
        raise EmailDomainError("EMAIL_ACCOUNT_NOT_FOUND", "尚未配置已启用的邮箱", 404)
    placeholders = ",".join("%s" for _ in accounts)
    active = (
        get_db()
        .execute(
            f"SELECT email_account_id FROM email_sync_leases WHERE email_account_id IN ({placeholders})",
            [account["id"] for account in accounts],
        )
        .fetchall()
    )
    if active:
        busy_id = active[0]["email_account_id"]
        busy = next(account for account in accounts if account["id"] == busy_id)
        raise EmailDomainError(
            "EMAIL_SYNC_ALREADY_RUNNING",
            f"邮箱「{busy['name']}」正在同步中，请稍后重试",
            409,
        )
    items = []
    for account in accounts:
        run = _create_sync_run_impl(account["id"], account, "manual", user["id"], None)
        items.append({"account_id": account["id"], "account_name": account["name"], "run_id": run["id"]})
    return {"triggered": len(items), "run_ids": [item["run_id"] for item in items], "items": items}


def list_sync_runs(user: dict, run_ids: list[str] | None = None, limit: int = 20) -> list[dict]:
    """Recent sync runs with the owning mailbox identity, for frontend feedback."""
    tenant_id = tenant_id_for_user(user)
    conn = get_db()
    if run_ids:
        placeholders = ",".join("%s" for _ in run_ids)
        rows = conn.execute(
            f"""SELECT r.id, r.email_account_id, r.status, r.trigger_type, r.triggered_by,
                       r.started_at, r.finished_at, r.created_at,
                       r.message_total, r.imported_count, r.deduped_count,
                       r.failed_count, r.error_code, r.error_message,
                       a.name AS account_name, a.email_address
                FROM email_sync_runs r LEFT JOIN email_accounts a ON a.id = r.email_account_id
                WHERE r.tenant_id=%s AND r.id IN ({placeholders})""",
            [tenant_id, *run_ids],
        ).fetchall()
        runs = [dict(row) for row in rows]
        order = {run_id: index for index, run_id in enumerate(run_ids)}
        runs.sort(key=lambda run: order.get(run["id"], len(order)))
        return runs
    rows = conn.execute(
        """SELECT r.id, r.email_account_id, r.status, r.trigger_type, r.triggered_by,
                  r.started_at, r.finished_at, r.created_at,
                  r.message_total, r.imported_count, r.deduped_count,
                  r.failed_count, r.error_code, r.error_message,
                  a.name AS account_name, a.email_address
           FROM email_sync_runs r LEFT JOIN email_accounts a ON a.id = r.email_account_id
           WHERE r.tenant_id=%s
           ORDER BY r.created_at DESC, r.id DESC LIMIT %s""",
        (tenant_id, limit),
    ).fetchall()
    return [dict(row) for row in rows]


def renew_sync_lease(account_id: str, run_id: str) -> None:
    """Keep a progressing mailbox run from being expired by the scheduler."""
    sql = "UPDATE email_sync_leases SET expires_at=DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE email_account_id=%s AND run_id=%s"
    get_db().execute(sql, (account_id, run_id))
    get_db().commit()


def due_account_ids() -> list[str]:
    due_condition = (
        "DATE_ADD(COALESCE(MAX(COALESCE(r.finished_at, r.created_at)), a.created_at), "
        "INTERVAL a.interval_minutes MINUTE) <= NOW()"
    )
    last_run_at = "COALESCE(MAX(COALESCE(r.finished_at, r.created_at)), a.created_at)"
    rows = (
        get_db()
        .execute(
            "SELECT a.id FROM email_accounts a "
            "LEFT JOIN email_sync_runs r ON r.email_account_id=a.id "
            "WHERE a.enabled=1 AND NOT EXISTS ("
            "SELECT 1 FROM email_sync_runs active WHERE active.email_account_id=a.id "
            "AND active.status IN ('queued','running')) "
            "GROUP BY a.id, a.created_at, a.interval_minutes "
            f"HAVING {due_condition} ORDER BY {last_run_at} LIMIT 50"
        )
        .fetchall()
    )
    return [row["id"] for row in rows]
