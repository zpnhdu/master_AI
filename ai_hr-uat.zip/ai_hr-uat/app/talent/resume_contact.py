"""Resume contact extraction — phone/email extraction + contact status classification.

规则优先（正则，零成本）；规则双空时由调用方决定是否触发 LLM 兜底。

联系方式三档状态（contact_status）：
  - "ok"      : 有有效邮箱 → 系统可自动发送面试邀请
  - "manual"  : 仅有效电话、无邮箱 → 系统无法自动推送，需 HR 人工电话联系
  - "missing" : 电话和邮箱均无 → 异常简历，无法联系候选人
"""

from __future__ import annotations

import os
import re

CONTACT_OK = "ok"
CONTACT_MANUAL = "manual"
CONTACT_MISSING = "missing"

# 手机号：大陆 11 位，1[3-9] 开头，兼容 +86 / 86 / 空格 / 横杠 / 全角分隔
_PHONE_FULL = re.compile(r"(?<!\d)(?:\+?86[- ]?)?1[3-9]\d{9}(?!\d)")
_EMAIL_FULL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
# 归一化后的纯 11 位号码（兜底匹配）
_PHONE_11 = re.compile(r"1[3-9]\d{9}")


def _normalize_phone(raw: str) -> str:
    """归一化手机号：全角转半角、去空格/横杠/括号、去 +86/86 前缀。"""
    if not raw:
        return ""
    text = raw.strip()
    # 全角数字 → 半角
    text = text.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
    text = text.replace("（", "").replace("）", "").replace("(", "").replace(")", "")
    text = text.replace(" ", "").replace("-", "").replace("—", "").replace("‐", "")
    if text.startswith("+86"):
        text = text[3:]
    elif text.startswith("86") and len(text) == 13:
        text = text[2:]
    return text


def is_valid_phone(phone: str) -> bool:
    """有效电话：11 位大陆手机号，1[3-9] 开头。"""
    if not phone:
        return False
    return bool(re.fullmatch(r"1[3-9]\d{9}", phone.strip()))


def is_valid_email(email: str) -> bool:
    """有效邮箱：标准邮箱格式。"""
    if not email:
        return False
    return bool(_EMAIL_FULL.fullmatch(email.strip()))


def extract_phone(text: str) -> str:
    """规则提取手机号，返回归一化后的 11 位号码或空串。"""
    if not text:
        return ""
    for m in _PHONE_FULL.finditer(text):
        digits = _normalize_phone(m.group(0))
        if is_valid_phone(digits):
            return digits
    # 兜底：归一化全文后找 11 位连续数字（覆盖 "138 0013 8000" 等分隔写法）
    normalized = _normalize_phone(text)
    m = _PHONE_11.search(normalized)
    if m:
        return m.group(0)
    return ""


def extract_email(text: str) -> str:
    """规则提取邮箱，返回首个合法邮箱（小写）或空串。"""
    if not text:
        return ""
    m = _EMAIL_FULL.search(text)
    return m.group(0).strip().lower() if m else ""


def extract_contact(text: str) -> tuple[str, str]:
    """规则优先提取 (phone, email)。"""
    return extract_phone(text), extract_email(text)


def classify_contact(phone: str, email: str) -> str:
    """联系方式三档分类：ok / manual / missing。"""
    if is_valid_email(email):
        return CONTACT_OK
    if is_valid_phone(phone):
        return CONTACT_MANUAL
    return CONTACT_MISSING


async def extract_contact_with_llm(text: str) -> tuple[str, str]:
    """LLM 兜底：规则未命中时尝试从文本提取 phone/email。

    只问两个字段，flash 复杂度，temperature 0.1。
    失败或未命中返回 ("", "")，不抛异常。
    """
    try:
        from hermes_wrapper.client import get_client
        from hermes_wrapper.models import LLMRequest

        client = get_client()
        req = LLMRequest(
            prompt=f"""从以下简历文本中提取联系方式，只输出 JSON：
{{
    "phone": "手机号（大陆11位，无则空字符串）",
    "email": "邮箱（无则空字符串）"
}}

文本：
{text[:3000]}""",
            system="从简历文本中提取手机号和邮箱，只输出JSON。找不到就返回空字符串。",
            model=os.environ.get("RESUME_PARSE_MODEL", ""),
            complexity="flash",
            temperature=0.1,
            timeout=60,
        )
        result = await client.chat_json(req)
        if isinstance(result, dict):
            phone = str(result.get("phone", "") or "").strip()
            email = str(result.get("email", "") or "").strip().lower()
            if phone:
                norm = _normalize_phone(phone)
                phone = norm if is_valid_phone(norm) else ""
            if email and not is_valid_email(email):
                email = ""
            return phone, email
    except Exception as e:  # noqa: BLE001
        print(f"[ResumeContact] LLM fallback error: {e}")
    return "", ""
