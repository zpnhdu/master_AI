"""Talent pool service layer — centralized resume storage and recommendation.

Features:
- Fingerprint-based dedup (SHA-256, high/low confidence)
- Suspect-same-person detection (character bigram Jaccard)
- Multi-tenant isolation (tenant_id)
- Two-stage recommendation (coarse filter → MatchAgent batch)
"""

import hashlib
import json
import logging
import re
import uuid
from typing import Optional

from app.db import (
    delete_resume_db,
    get_pipeline,
    get_resume_by_fingerprint,
    get_resume_by_id,
    get_stages,
    save_candidate,
    save_resume_db,
    search_resumes_db,
    update_resume_linked,
)

logger = logging.getLogger(__name__)

# 疑似同一人检测的 Jaccard 阈值
SUSPECT_JACCARD_THRESHOLD = 0.8

# 推荐原因常量，用于向前端返回空状态提示
_REASON_NO_PIPELINE = "no_pipeline"
_REASON_NO_ROLE = "no_role"
_REASON_NO_MATCH = "no_match"

RECOMMEND_SCOPE_MIN_SCORE = {"precise": 45, "balanced": 20, "broad": 10}
RECOMMEND_SCOPE_HARD_FILTER = {"precise": True, "balanced": True, "broad": False}

# 硬性门槛学历层级：与小筛工作台同口径（见 screening_workflow.EDUCATION_LEVELS）
HARD_GATE_EDUCATION_LEVELS = {"": 0, "大专": 1, "本科": 2, "硕士": 3, "研究生": 3, "博士": 4}
HARD_GATE_EDUCATION_ORDER = ("博士", "硕士", "本科", "大专")

ROLE_FAMILIES = (
    {"前端", "web", "网页", "javascript", "typescript", "react", "vue"},
    {"后端", "服务端", "工程师", "开发", "全栈", "技术", "研发", "测试", "java", "python", "go", "golang"},
    {"产品", "产品经理", "产品运营"},
    {"运营", "增长", "用户运营", "内容运营", "电商运营", "门店运营"},
    {"销售", "商务", "客户经理", "大客户"},
    {"人力", "招聘", "hr", "人事"},
    {"总经理", "事业部", "负责人", "区域总", "运营总监", "经营管理", "经营", "门店"},
)


# ============ 指纹 ============


def _normalize_for_fingerprint(text: str) -> str:
    """归一化文本用于指纹计算，消除标点符号变体。

    处理：中文/英文括号、各类破折号、全半角符号、多余空白。
    "阿里巴巴—飞猪" == "阿里巴巴（飞猪）" == "阿里巴巴-飞猪"
    """
    if not text:
        return ""
    text = text.strip().lower()
    # 统一括号为空（括号内容保留）
    text = text.replace("（", "").replace("）", "")
    text = text.replace("(", "").replace(")", "")
    text = text.replace("【", "").replace("】", "")
    text = text.replace("[", "").replace("]", "")
    # 统一各类破折号和连接符为空
    text = text.replace("—", "").replace("–", "").replace("-", "")
    text = text.replace("·", "").replace("・", "")
    # 去除所有空白字符
    text = re.sub(r"\s+", "", text)
    return text


def _normalize_phone(phone: str) -> str:
    """电话归一化：去空格/横线/括号，统一 +86/86 前缀，全角转半角。"""
    if not phone:
        return ""
    p = str(phone)
    # 全角转半角
    p = p.translate({0xFF10 + i: 0x30 + i for i in range(10)})
    p = re.sub(r"[^\d+]", "", p)
    if p.startswith("+86"):
        p = p[3:]
    elif p.startswith("0086") and len(p) == 15:
        p = p[4:]
    elif p.startswith("86") and len(p) == 13:
        p = p[2:]
    return p


def compute_fingerprint(data: dict) -> tuple[str, str]:
    """Compute fingerprint and confidence from resume data.

    Returns (fingerprint_str, confidence) or ("", "") if insufficient data.
    Uses _normalize_for_fingerprint to eliminate punctuation variants.
    """
    name = _normalize_for_fingerprint(data.get("name", ""))
    if not name:
        return ("", "")

    parts = [name]
    confidence = "high"

    phone = data.get("phone", "") or ""
    email = data.get("email", "") or ""

    if phone or email:
        parts.append(_normalize_phone(phone))
        parts.append(email.strip().lower())
    else:
        years = str(data.get("years_experience", ""))
        company = _normalize_for_fingerprint(data.get("current_company", ""))
        parts.append(years)
        parts.append(company)
        confidence = "low"

    raw = "|".join(parts)
    fingerprint = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return (fingerprint, confidence)


# ============ 字符二元组 Jaccard ============


def _char_bigrams(text: str) -> set:
    """Extract character bigrams from text (works for CJK + Latin)."""
    text = text.strip().lower()
    if len(text) < 2:
        return {text} if text else set()
    return {text[i : i + 2] for i in range(len(text) - 1)}


def jaccard_similarity(text_a: str, text_b: str) -> float:
    """Character bigram Jaccard similarity between two strings."""
    if not text_a or not text_b:
        return 0.0
    set_a = _char_bigrams(text_a)
    set_b = _char_bigrams(text_b)
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def _find_suspect_match(name: str, company: str, tenant_id: str = "") -> Optional[str]:
    """Find a suspect-same-person match in existing resumes.

    Checks name + company Jaccard >= threshold.
    Returns the matching resume_id or None.
    """
    if not name:
        return None

    # 搜索姓名相似的简历
    candidates = search_resumes_db(query=name, limit=10, tenant_id=tenant_id)

    for candidate in candidates:
        name_sim = jaccard_similarity(name, candidate.get("name", ""))
        company_sim = jaccard_similarity(company, candidate.get("current_company", ""))

        # 姓名或公司二元组的 Jaccard 值达到阈值
        if name_sim >= SUSPECT_JACCARD_THRESHOLD or company_sim >= SUSPECT_JACCARD_THRESHOLD:
            return candidate["id"]

    return None


# ============ 校验门禁 ============


def _validate_resume(data: dict) -> bool:
    """Check minimum required fields before saving to pool."""
    name = (data.get("name") or "").strip()
    if not name:
        return False

    other_fields = [
        data.get("skills"),
        data.get("current_company"),
        data.get("years_experience"),
        data.get("resume_text"),
        data.get("title"),
        data.get("education"),
    ]
    return any(f for f in other_fields if f)


# ============ 核心操作 ============


# 占位名集合：LLM 解析缺失时的兜底姓名，不做姓名去重（避免误杀）
PLACEHOLDER_NAMES = {"未知", "无名", "无", "unknown", "n/a", "暂无", "未提供", "不详"}


def _dedup_by_name_and_role(resume_data: dict, tenant_id: str = "") -> Optional[str]:
    """基础去重：姓名 + 目标岗位 均相同视为同一份简历。

    返回已存在的 resume_id 或 None。
    这是基础去重规则，后续迭代可在此扩展（如名称不规则归一、岗位别名映射等）。
    """
    name = _normalize_for_fingerprint(resume_data.get("name", ""))
    if not name or len(name) < 2 or name in PLACEHOLDER_NAMES:
        return None
    target = _normalize_for_fingerprint(resume_data.get("title", ""))
    if not target:
        return None

    # 快速路径：原始姓名+岗位精确匹配（覆盖绝大多数重复场景，避免全表 LIKE 扫描 + LIMIT 窗口漏匹配）
    raw_name = (resume_data.get("name", "") or "").strip()
    raw_title = (resume_data.get("title", "") or "").strip()
    if raw_name and raw_title:
        from app.db import get_db

        row = (
            get_db()
            .execute(
                "SELECT id FROM resumes WHERE name = %s AND title = %s AND tenant_id = %s LIMIT 1",
                (raw_name, raw_title, tenant_id),
            )
            .fetchone()
        )
        if row:
            return row["id"]

    # 回退：模糊 LIKE 扫描（名称/岗位的标点变体）
    existing = search_resumes_db(query=name, limit=20, tenant_id=tenant_id)
    for cand in existing:
        cand_name = _normalize_for_fingerprint(cand.get("name", ""))
        if cand_name != name:
            continue
        cand_target = _normalize_for_fingerprint(cand.get("title", ""))
        if cand_target and cand_target == target:
            return cand["id"]
    return None


def save_resume(resume_data: dict, tenant_id: str = "") -> dict:
    """Save a parsed resume to the global talent pool.

    Returns:
        - New insert: {"id": resume_id, "duplicate": False}
        - Exact fingerprint match: {"duplicate": True, "existing_id": <id>}
        - Name+role duplicate: {"duplicate": True, "existing_id": <id>}
        - Suspect match: {"id": resume_id, "duplicate": False, "suspect_match": <id>}
        - Validation fail: {"duplicate": False, "skipped": True, "reason": str}
    """
    tenant_id = tenant_id or "tenant_default"
    if not _validate_resume(resume_data):
        return {"duplicate": False, "skipped": True, "reason": "validation_failed"}

    # ── 基础去重（全入口默认开启）：同名 + 同目标岗位 → 视为同一份简历 ──
    # 说明：LLM 解析的简历可能因电话/邮箱提取差异导致内容指纹不同，
    # 这里用“姓名 + 目标岗位”做基础去重兜底，后续可扩展为更复杂的去重策略。
    dedup_result = _dedup_by_name_and_role(resume_data, tenant_id)
    if dedup_result:
        return {"duplicate": True, "existing_id": dedup_result}

    fingerprint, confidence = compute_fingerprint(resume_data)

    # 检查是否存在完全匹配的指纹（任意置信度）
    existing_by_fp = None
    if fingerprint:
        existing_by_fp = get_resume_by_fingerprint(fingerprint, tenant_id=tenant_id)
        if existing_by_fp:
            if confidence == "high":
                # 高置信度：确定为同一人，拒绝导入
                return {"duplicate": True, "existing_id": existing_by_fp["id"]}
        # 低置信度：可能是同一人，保存为新记录并建立关联
        # 不拒绝导入，允许同一人的不同简历版本共存

    # 构建简历记录
    if fingerprint and not existing_by_fp:
        tenant_hash = hashlib.sha256(tenant_id.encode("utf-8")).hexdigest()[:6]
        resume_id = f"res_{tenant_hash}_{fingerprint}"
    elif fingerprint and existing_by_fp:
        # 低置信度冲突：追加技能哈希以作区分
        skill_hash = hashlib.md5(json.dumps(resume_data.get("skills", []), ensure_ascii=False).encode()).hexdigest()[:6]
        resume_id = f"res_{fingerprint}_{skill_hash}_{uuid.uuid4().hex[:6]}"
    else:
        resume_id = f"res_{uuid.uuid4().hex[:16]}"
    resume = {
        "id": resume_id,
        "fingerprint": fingerprint,
        "fingerprint_confidence": confidence,
        "name": resume_data.get("name", ""),
        "source": resume_data.get("source", ""),
        "source_channel": resume_data.get("source_channel", ""),
        "years_experience": resume_data.get("years_experience", 0),
        "current_company": resume_data.get("current_company", ""),
        "current_salary": resume_data.get("current_salary", ""),
        "skills": resume_data.get("skills", []),
        "resume_text": resume_data.get("resume_text", ""),
        "education": resume_data.get("education", ""),
        "location": resume_data.get("location", ""),
        "title": resume_data.get("title", ""),
        "tags": resume_data.get("tags", []),
        "email": resume_data.get("email", ""),
        "phone": resume_data.get("phone", ""),
        "gender": resume_data.get("gender", ""),
        "contact_status": resume_data.get("contact_status", ""),
        "tenant_id": tenant_id,
        "ragflow_json": resume_data.get("ragflow_json", ""),
        "owner_user_id": resume_data.get("owner_user_id", ""),
        "source_type": resume_data.get("source_type", ""),
        "source_account_id": resume_data.get("source_account_id", ""),
        "source_message_id": resume_data.get("source_message_id", ""),
        "source_attachment_id": resume_data.get("source_attachment_id", ""),
        "candidate_email": resume_data.get("candidate_email", resume_data.get("email", "")),
        "sender_email": resume_data.get("sender_email", ""),
        "content_sha256": resume_data.get("content_sha256", ""),
        "storage_backend": resume_data.get("storage_backend", ""),
        "storage_key": resume_data.get("storage_key", ""),
        "original_filename": resume_data.get("original_filename", ""),
    }

    # 疑似同一人检测（检查现有指纹匹配和 Jaccard 值）
    suspect_id = existing_by_fp["id"] if existing_by_fp else None
    if not suspect_id:
        suspect_id = _find_suspect_match(
            resume.get("name", ""),
            resume.get("current_company", ""),
            tenant_id=tenant_id,
        )
    if suspect_id:
        resume["linked_resume_id"] = suspect_id

    try:
        save_resume_db(resume)
    except Exception as e:
        logger.warning(f"[TalentPool] save_resume failed: {e}")
        return {"duplicate": False, "skipped": True, "reason": str(e)}

        # 建立双向关联
    if suspect_id:
        try:
            update_resume_linked(suspect_id, resume_id)
        except Exception as e:
            logger.warning(f"[TalentPool] bidirectional link failed: {e}")

    result = {"id": resume_id, "duplicate": False}
    if suspect_id:
        result["suspect_match"] = suspect_id
    if confidence == "low":
        result["fingerprint_confidence"] = "low"
    return result


def search_resumes(
    query: str = "",
    skills: list = None,
    location: str = "",
    min_years: int = 0,
    limit: int = 20,
    tenant_id: str = "",
    offset: int = 0,
    sort_by: str = "",
    sort_order: str = "desc",
) -> list:
    """Search the talent pool via the structured LIKE backend."""
    return search_resumes_db(
        query=query,
        skills=skills,
        location=location,
        min_years=min_years,
        limit=limit,
        tenant_id=tenant_id,
        offset=offset,
        sort_by=sort_by,
        sort_order=sort_order,
    )


def _tokenize_chinese_skill(skill: str) -> list[str]:
    """Split a long Chinese skill name into bigrams + trigrams for fuzzy matching.

    '文旅项目全周期管理' → ['文旅','旅项','项目','目全','全周','周期','期管','管理',
                         '文旅项','旅项目','项目全','目全周','全周期','周期管','期管理']
    Short skills (Latin, short Chinese ≤2 chars) are returned as-is.
    """
    skill = skill.strip()
    if not skill:
        return []
        # 短技能或纯拉丁字符技能保持原样，用于精确匹配
    if len(skill) <= 2 or skill.isascii():
        return [skill]

    tokens = []
    # 二元组（2 字符窗口）
    for i in range(len(skill) - 1):
        tokens.append(skill[i : i + 2])
        # 对不少于 4 个字符的技能生成三元组
    if len(skill) >= 4:
        for i in range(len(skill) - 2):
            tokens.append(skill[i : i + 3])

    # 去重并保持原有顺序
    seen = set()
    result = []
    for t in tokens:
        if t not in seen:
            seen.add(t)
            result.append(t)
    return result


def _extract_jd_keywords(jd: dict, pipeline_role: str) -> list[str]:
    """Extract search keywords from JD when tech_stack matching fails.

    Pulls from: responsibilities (first 2), requirements (first 2), role name.
    """
    keywords = []
    responsibilities = jd.get("responsibilities", [])
    if isinstance(responsibilities, list):
        for r in responsibilities[:2]:
            # 提取有意义的中文短语（不少于 2 个字符）
            if isinstance(r, str) and len(r) >= 2:
                # 取第一句话或最多 12 个字符
                keywords.append(r[:12])

    requirements = jd.get("requirements", [])
    if isinstance(requirements, list):
        for r in requirements[:2]:
            if isinstance(r, str) and len(r) >= 2:
                keywords.append(r[:12])

    if pipeline_role:
        keywords.append(pipeline_role)

    return keywords


def _as_string_list(value) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return [str(item).strip() for item in parsed if str(item).strip()]
        except (json.JSONDecodeError, TypeError):
            pass
        return [part.strip() for part in re.split(r"[,，、/；;]", value) if part.strip()]
    return []


def _parse_json_object(value) -> dict:
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value:
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except (json.JSONDecodeError, TypeError):
            return {}
    return {}


def _education_level(text) -> int:
    normalized = str(text or "")
    return max(
        (level for name, level in HARD_GATE_EDUCATION_LEVELS.items() if name and name in normalized),
        default=0,
    )


def _screening_hard_gates(stages: list[dict], jd: dict) -> dict:
    """提取与筛选工作台（小筛）口径一致的硬性门槛配置。

    优先复用 match 阶段已保存的 config.hard_gates（HR 手动开启的地点/薪资门槛
    同样生效）；尚未跑过初筛时按 JD 自动提取，规则与前端 extractScreeningDefaults 一致：
    tech_stack → 技能门槛，JD 中出现“N年” → 年限门槛，出现学历词 → 学历门槛。
    地点与薪资上限默认关闭，由 HR 在小筛里手动开启。
    """
    match_stage = next((stage for stage in stages if stage.get("stage_id") == "match"), None)
    stage_output = _parse_json_object(match_stage.get("output") if match_stage else {})
    saved = stage_output.get("config", {}).get("hard_gates")
    if isinstance(saved, dict):
        return saved

    requirements_text = " ".join(_as_string_list(jd.get("requirements")))
    years_match = re.search(r"(\d+)\s*年", requirements_text)
    education = next((item for item in HARD_GATE_EDUCATION_ORDER if item in requirements_text), "")
    skills = [str(item).strip() for item in _as_string_list(jd.get("tech_stack")) if str(item).strip()]
    return {
        "skills": {"enabled": bool(skills), "values": skills, "mode": "all", "minimum": 1},
        "min_years": {"enabled": bool(years_match), "value": int(years_match.group(1)) if years_match else 0},
        "education": {"enabled": bool(education), "value": education},
        "location": {"enabled": False, "value": str(jd.get("location") or "")},
        "salary_max": {"enabled": False, "value": 0},
    }


def _check_hard_gates(resume: dict, gates: dict) -> tuple[list[str], list[str]]:
    """按筛选工作台同口径检查硬性门槛。

    明确填写但不满足的必选条件进入 failed（推荐阶段直接过滤）；
    简历缺少该字段的进入 missing（不硬性过滤，放行并提示补全）。
    技能门槛例外：作为召回依据展示差距，不在这里硬性过滤。
    """
    failed: list[str] = []
    missing: list[str] = []
    gates = gates or {}

    years_gate = gates.get("min_years") or {}
    if years_gate.get("enabled"):
        expected = int(years_gate.get("value") or 0)
        actual = int(resume.get("years_experience") or 0)
        if expected > 0:
            if actual <= 0:
                missing.append("工作年限")
            elif actual < expected:
                failed.append(f"工作年限（{actual}年 / 要求{expected}年以上）")

    education_gate = gates.get("education") or {}
    if education_gate.get("enabled"):
        expected = str(education_gate.get("value") or "")
        actual = str(resume.get("education") or "")
        required_level = HARD_GATE_EDUCATION_LEVELS.get(expected, 0)
        if required_level > 0:
            if not actual:
                missing.append("学历")
            elif _education_level(actual) < required_level:
                failed.append(f"学历（{actual} / 要求{expected}）")

    location_gate = gates.get("location") or {}
    if location_gate.get("enabled"):
        expected = str(location_gate.get("value") or "")
        actual = str(resume.get("location") or "")
        if expected:
            if not actual:
                missing.append("工作地点")
            elif not (actual in expected or expected in actual):
                failed.append(f"工作地点（{actual} / 岗位在{expected}）")

    salary_gate = gates.get("salary_max") or {}
    if salary_gate.get("enabled"):
        expected = int(salary_gate.get("value") or 0)
        salary_match = re.search(r"(\d+)", str(resume.get("current_salary") or ""))
        actual = int(salary_match.group(1)) if salary_match else 0
        if expected > 0:
            if not actual:
                missing.append("薪资上限")
            elif actual > expected:
                failed.append(f"薪资上限（{actual} / 上限{expected}）")

    return failed, missing


def _extract_recommendation_context(
    pipeline: dict,
    stages: list[dict],
    extra_keywords: list[str] = None,
    required_keywords: list[str] = None,
    excluded_conditions: list[str] = None,
) -> dict:
    jd_stage = next((stage for stage in stages if stage.get("stage_id") == "jd_write"), None)
    jd_output = _parse_json_object(jd_stage.get("output") if jd_stage else {})
    jd = jd_output.get("jd", jd_output) if isinstance(jd_output, dict) else {}
    role = str(jd.get("title") or pipeline.get("role") or "").strip()
    skills = []
    for field in ("tech_stack", "skills", "required_skills", "keywords"):
        skills.extend(_as_string_list(jd.get(field)))
    skills.extend(extra_keywords or [])
    skills = list(dict.fromkeys(skills))
    required_keywords = list(dict.fromkeys(required_keywords or []))
    requirements = _as_string_list(jd.get("requirements"))
    responsibilities = _as_string_list(jd.get("responsibilities"))
    all_jd_text = " ".join([role, *skills, *requirements, *responsibilities])
    years_match = re.search(r"(\d+)\s*年", all_jd_text)
    location = str(jd.get("location") or jd.get("work_location") or "").strip()
    excluded = {item.strip() for item in (excluded_conditions or []) if item.strip()}
    skills = [skill for skill in skills if skill not in excluded]
    min_years = int(years_match.group(1)) if years_match else 0
    if f"{min_years}年以上" in excluded:
        min_years = 0
    if location in excluded:
        location = ""
    return {
        "role": role,
        "skills": skills[:12],
        "keywords": _extract_jd_keywords(jd, role)[:8],
        "required_keywords": required_keywords,
        "min_years": min_years,
        "location": location,
        "jd_available": bool(jd),
        "hard_gates": _screening_hard_gates(stages, jd),
    }


def _role_relevance(role: str, candidate_text: str) -> tuple[float, list[str]]:
    normalized_role = role.lower().strip()
    if not normalized_role:
        return (0, [])
    if normalized_role in candidate_text:
        return (35, [role])
    role_tokens = {token for token in _tokenize_chinese_skill(normalized_role) if len(token) >= 2}
    token_hits = [token for token in role_tokens if token in candidate_text]
    for family in ROLE_FAMILIES:
        if any(term in normalized_role for term in family) and any(term in candidate_text for term in family):
            return (28, [role])
    if token_hits:
        return (min(25, 12 + len(token_hits) * 4), [role])
    return (0, [])


def _role_family_ids(text: str) -> set[int]:
    normalized = text.lower().strip()
    if not normalized:
        return set()
    return {index for index, family in enumerate(ROLE_FAMILIES) if any(term.lower() in normalized for term in family)}


def _has_conflicting_role_family(role: str, candidate_text: str) -> bool:
    role_families = _role_family_ids(role)
    candidate_families = _role_family_ids(candidate_text)
    return bool(role_families and candidate_families and not role_families & candidate_families)


def _term_matches_candidate(term: str, candidate_text: str) -> bool:
    normalized = term.lower().strip()
    if not normalized:
        return False
    if normalized in candidate_text:
        return True
    tokens = [token.lower() for token in _tokenize_chinese_skill(normalized) if len(token) >= 2]
    required_hits = 1 if len(tokens) <= 2 else 2
    return sum(token in candidate_text for token in tokens) >= required_hits


def _score_recommendation(resume: dict, context: dict, scope: str = "balanced") -> Optional[dict]:
    skills = _as_string_list(resume.get("skills"))
    candidate_text = " ".join(
        [
            str(resume.get("title") or ""),
            str(resume.get("current_company") or ""),
            " ".join(skills),
            str(resume.get("resume_text") or ""),
            " ".join(_as_string_list(resume.get("tags"))),
        ]
    ).lower()
    matched_terms = []
    gaps = []

    if _has_conflicting_role_family(context["role"], candidate_text):
        return None

    role_score, role_hits = _role_relevance(context["role"], candidate_text)
    matched_terms.extend(role_hits)

    jd_skills = context["skills"]
    skill_hits = [skill for skill in jd_skills if _term_matches_candidate(skill, candidate_text)]
    matched_terms.extend(skill_hits)
    skill_score = min(30, len(skill_hits) / max(len(jd_skills), 1) * 30) if jd_skills else 15
    if jd_skills:
        missing_skills = [skill for skill in jd_skills if skill not in skill_hits]
        if missing_skills:
            gaps.append("未体现" + "、".join(missing_skills[:3]))

    required_keywords = context.get("required_keywords", [])
    required_hits = [term for term in required_keywords if _term_matches_candidate(term, candidate_text)]
    required_missing = [term for term in required_keywords if term not in required_hits]
    matched_terms.extend(required_hits)
    if required_missing:
        gaps.append("必选条件未体现：" + "、".join(required_missing[:3]))
        if RECOMMEND_SCOPE_HARD_FILTER.get(scope, True):
            return None

    context_hits = [term for term in context["keywords"] if _term_matches_candidate(term, candidate_text)]
    matched_terms.extend(context_hits)
    context_score = min(15, len(context_hits) * 5)

    years = int(resume.get("years_experience") or 0)
    min_years = context["min_years"]
    if not min_years:
        experience_score = 7
    elif years >= min_years:
        experience_score = 10
        matched_terms.append(f"{years}年经验")
    else:
        experience_score = max(2, 10 - (min_years - years) * 2)
        gaps.append(f"经验约{years}年，JD期望{min_years}年以上")

    location = str(resume.get("location") or "")
    expected_location = context["location"]
    location_score = 3
    if expected_location and location:
        if expected_location in location or location in expected_location:
            location_score = 5
            matched_terms.append(location)
        else:
            location_score = 1
            gaps.append(f"所在地{location}，岗位在{expected_location}")

    complete_fields = sum(
        bool(resume.get(field)) for field in ("title", "skills", "resume_text", "education", "location")
    )
    completeness_score = min(5, complete_fields)
    required_penalty = 0
    if required_keywords and scope == "broad":
        required_penalty = round(len(required_missing) / len(required_keywords) * 15)
    score = round(
        role_score
        + skill_score
        + context_score
        + experience_score
        + location_score
        + completeness_score
        - required_penalty
    )
    if score < 10:
        return None
    level = "high" if score >= 70 else "possible" if score >= 40 else "explore"
    result = dict(resume)
    result.update(
        {
            "relevance_score": min(score, 95),
            "relevance_level": level,
            "matched_terms": list(dict.fromkeys(matched_terms))[:6],
            "gaps": gaps[:3],
        }
    )
    return result


async def _recommend_scan(
    pipeline_id: str,
    limit: int = 5,
    tenant_id: str = "",
    scope: str = "balanced",
    keywords: list[str] = None,
    required_keywords: list[str] = None,
    excluded_conditions: list[str] = None,
    apply_hard_gates: bool = False,
) -> tuple[list, str, int]:
    tenant_id = tenant_id or "tenant_default"
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        return ([], _REASON_NO_PIPELINE, 0)

    stages = get_stages(pipeline_id)
    context = _extract_recommendation_context(
        pipeline,
        stages,
        keywords,
        required_keywords,
        excluded_conditions,
    )
    if not context["role"]:
        return ([], _REASON_NO_ROLE, 0)
    hard_gates = context.get("hard_gates") or {}

    # 排除已在当前流水线的简历
    existing_resume_ids: set = set()
    try:
        from app.db import get_db

        conn = get_db()
        rows = conn.execute(
            "SELECT resume_id FROM candidates WHERE pipeline_id=%s AND resume_id IS NOT NULL AND resume_id != ''",
            (pipeline_id,),
        ).fetchall()
        existing_resume_ids = {r[0] for r in rows}
    except Exception:
        pass

    from app.db import get_db

    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM resumes WHERE tenant_id=%s ORDER BY updated_at DESC",
        (tenant_id,),
    ).fetchall()
    min_score = RECOMMEND_SCOPE_MIN_SCORE.get(scope, RECOMMEND_SCOPE_MIN_SCORE["balanced"])
    results = []
    hard_gate_filtered = 0
    for row in rows:
        resume = dict(row)
        if resume["id"] in existing_resume_ids:
            continue
        missing_required: list[str] = []
        if apply_hard_gates:
            # 与小筛一致的必选条件前置过滤：明确不满足的剔除，信息不足的放行并打标记
            failed, missing = _check_hard_gates(resume, hard_gates)
            if failed:
                hard_gate_filtered += 1
                continue
            missing_required = missing
        scored = _score_recommendation(resume, context, scope)
        if not scored or scored["relevance_score"] < min_score:
            continue
        if missing_required and "missing_required" not in scored:
            scored["missing_required"] = missing_required
        results.append(scored)

    results.sort(key=lambda item: (item["relevance_score"], item.get("updated_at", "")), reverse=True)

    if not results:
        return ([], _REASON_NO_MATCH, hard_gate_filtered)

    return (results[:limit], "", hard_gate_filtered)


async def recommend_for_pipeline(
    pipeline_id: str,
    limit: int = 5,
    tenant_id: str = "",
    scope: str = "balanced",
    keywords: list[str] = None,
    required_keywords: list[str] = None,
    excluded_conditions: list[str] = None,
) -> tuple[list, str]:
    """Use the current JD for broad talent-pool recall before strict screening.

    Returns (results, reason). reason explains why results are empty when applicable.
    """
    results, reason, _ = await _recommend_scan(
        pipeline_id,
        limit=limit,
        tenant_id=tenant_id,
        scope=scope,
        keywords=keywords,
        required_keywords=required_keywords,
        excluded_conditions=excluded_conditions,
        apply_hard_gates=False,
    )
    return results, reason


async def recommend_for_pipeline_gated(
    pipeline_id: str,
    limit: int = 5,
    tenant_id: str = "",
    scope: str = "balanced",
    keywords: list[str] = None,
    required_keywords: list[str] = None,
    excluded_conditions: list[str] = None,
) -> dict:
    """按筛选工作台的硬性门槛前置过滤人才库召回结果。

    返回 {"results", "reason", "hard_gate_filtered"}：明确不满足必选条件的简历被剔除并计数，
    信息缺失（如未填工作年限/学历）的简历保留并带上 missing_required 标记供前端提示。
    """
    results, reason, hard_gate_filtered = await _recommend_scan(
        pipeline_id,
        limit=limit,
        tenant_id=tenant_id,
        scope=scope,
        keywords=keywords,
        required_keywords=required_keywords,
        excluded_conditions=excluded_conditions,
        apply_hard_gates=True,
    )
    return {"results": results, "reason": reason, "hard_gate_filtered": hard_gate_filtered}


def get_recommendation_context(
    pipeline_id: str,
    keywords: list[str] = None,
    excluded_conditions: list[str] = None,
) -> dict:
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        return {}
    return _extract_recommendation_context(
        pipeline,
        get_stages(pipeline_id),
        extra_keywords=keywords,
        excluded_conditions=excluded_conditions,
    )


def link_resume_to_pipeline(resume_id: str, pipeline_id: str) -> Optional[dict]:
    """Create a candidate record from a talent pool resume."""
    resume = get_resume_by_id(resume_id)
    if not resume:
        return None

    # 检查该 resume 是否已在其他 pipeline 中
    from app.db import get_db

    db_conn = get_db()
    existing = db_conn.execute(
        "SELECT pipeline_id FROM candidates WHERE resume_id = %s AND pipeline_id != %s LIMIT 1",
        (resume_id, pipeline_id),
    ).fetchone()

    candidate = {
        "id": f"c_{resume_id}_{pipeline_id[:8]}",
        "name": resume["name"],
        "source": resume.get("source", "talent_pool"),
        "years_experience": resume.get("years_experience", 0),
        "current_company": resume.get("current_company", ""),
        "current_salary": resume.get("current_salary", ""),
        "skills": resume.get("skills", []),
        "resume_text": resume.get("resume_text", ""),
        "education": resume.get("education", ""),
        "location": resume.get("location", ""),
        "title": resume.get("title", ""),
        "resume_id": resume_id,
    }

    if existing:
        candidate["also_in_pipeline"] = existing["pipeline_id"]

    save_candidate(pipeline_id, candidate)
    return candidate


def delete_resume(resume_id: str, tenant_id: str = "") -> bool:
    """Permanently delete a resume from the database."""
    return delete_resume_db(resume_id, tenant_id=tenant_id)
