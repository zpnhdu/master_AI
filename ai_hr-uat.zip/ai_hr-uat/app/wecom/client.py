"""企业微信服务端 API 客户端。

access_token 有效期 7200 秒且获取频率受限制，进程内缓存并在过期前
刷新。Secret 只来自环境变量，任何日志输出前必须脱敏。
"""

import json
import logging
import threading
import time
import urllib.parse
import urllib.request

from app import config

logger = logging.getLogger("app.wecom")

BASE_URL = "https://qyapi.weixin.qq.com/cgi-bin"
_TOKEN_EXPIRY_MARGIN_SECONDS = 300

# Web 扫码登录页（企业微信官方渲染二维码）
SSO_LOGIN_URL = "https://login.work.weixin.qq.com/wwlogin/sso/login"


class WeComError(RuntimeError):
    """企业微信接口调用失败（含 errcode/errmsg）。"""

    def __init__(self, errcode: int, errmsg: str):
        super().__init__(f"wecom api error {errcode}: {errmsg}")
        self.errcode = errcode
        self.errmsg = errmsg


def _http_get_json(url: str, params: dict | None = None, timeout: int = 15) -> dict:
    if params:
        url = f"{url}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # 4xx/5xx 响应体里往往有 errcode，尽量读出来便于诊断
        try:
            return json.loads(exc.read().decode("utf-8"))
        except Exception:
            raise WeComError(exc.code, f"HTTP {exc.code}") from exc


def _check_errcode(payload: dict) -> dict:
    errcode = int(payload.get("errcode", 0) or 0)
    if errcode != 0:
        raise WeComError(errcode, str(payload.get("errmsg", "")))
    return payload


class _TokenCache:
    """进程内 access_token 缓存（agent 与通讯录两套密钥各自缓存）。"""

    def __init__(self):
        self._lock = threading.Lock()
        self._tokens: dict[str, tuple[str, float]] = {}

    def get(self, secret: str) -> str:
        with self._lock:
            cached = self._tokens.get(secret)
            if cached and cached[1] > time.time():
                return cached[0]
        payload = _check_errcode(
            _http_get_json(f"{BASE_URL}/gettoken", {"corpid": config.WECOM_CORP_ID, "corpsecret": secret})
        )
        token = str(payload["access_token"])
        expires_in = int(payload.get("expires_in", 7200) or 7200)
        with self._lock:
            self._tokens[secret] = (token, time.time() + max(expires_in - _TOKEN_EXPIRY_MARGIN_SECONDS, 60))
        return token


_token_cache = _TokenCache()


def get_agent_access_token() -> str:
    """自建应用 access_token（OAuth 换 userid 用）。"""
    return _token_cache.get(config.WECOM_AGENT_SECRET)


def get_contact_access_token() -> str:
    """通讯录同步 access_token（WECOM_CONTACT_SECRET 对应的密钥）。"""
    return _token_cache.get(config.WECOM_CONTACT_SECRET)


def sso_login_page_url(redirect_uri: str, state: str) -> str:
    """构造企业微信 Web 扫码登录页地址。

    自建应用必须用 login_type=CorpApp（appid 传 CorpID + agentid）；
    ServiceApp 是服务商登录（appid 传 SuiteID），用错会被企微报
    -31027 appid 参数错误。
    """
    return (
        SSO_LOGIN_URL
        + "?"
        + urllib.parse.urlencode(
            {
                "login_type": "CorpApp",
                "appid": config.WECOM_CORP_ID,
                "agentid": config.WECOM_AGENT_ID,
                "redirect_uri": redirect_uri,
                "state": state,
            }
        )
    )


def get_userid_by_code(code: str) -> str:
    """用回调 code 换当前登录人的 userid。"""
    payload = _check_errcode(
        _http_get_json(
            f"{BASE_URL}/auth/getuserinfo",
            {"access_token": get_agent_access_token(), "code": code},
        )
    )
    userid = str(payload.get("userid") or "")
    if not userid:
        # snsapi_privateinfo 之外的手册分支会返回 open_userid；本项目只认企业成员
        raise WeComError(0, "getuserinfo 未返回 userid（非企业成员或 code 已使用）")
    return userid


def list_departments() -> list[dict]:
    """拉取全部部门（id/name），供通讯录同步做部门 id→名称映射。"""
    payload = _check_errcode(
        _http_get_json(f"{BASE_URL}/department/list", {"access_token": get_contact_access_token()})
    )
    return [
        {"id": int(item.get("id", 0) or 0), "name": str(item.get("name") or "")}
        for item in payload.get("department") or []
    ]


def list_department_users(department_id: int = 1, fetch_child: int = 1) -> list[dict]:
    """拉取部门成员（默认根部门含全部子部门）。

    企微新版 /user/list 使用 cursor 分页，循环取到无 next_cursor 为止；
    未激活成员的 userid 可能为空，由调用方过滤。
    """
    users: list[dict] = []
    cursor = ""
    while True:
        params: dict = {
            "access_token": get_contact_access_token(),
            "department_id": department_id,
            "fetch_child": fetch_child,
        }
        if cursor:
            params["cursor"] = cursor
        payload = _check_errcode(_http_get_json(f"{BASE_URL}/user/list", params))
        users.extend(payload.get("userlist") or [])
        cursor = str(payload.get("next_cursor") or "")
        if not cursor:
            return users
