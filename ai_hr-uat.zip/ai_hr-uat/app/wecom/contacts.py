"""企业微信通讯录同步：拉取成员快照写入 wecom_contacts。

供扫码登录策略 A 的通讯录命中/自动开通消费；触发入口有两个：
管理端路由 POST /api/admin/wecom/sync-contacts 与启动定时循环。
"""

import logging

from app import config
from app import db as _db
from app.wecom.client import list_department_users, list_departments

logger = logging.getLogger("app.wecom")


def sync_contacts() -> dict:
    """全量拉取通讯录并覆盖 wecom_contacts 快照。

    department 列存部门名逗号串（部门 id 经 list_departments 映射），
    本次未出现的 userid 视为已离职清理；绑定关系在 auth_users，不受影响。
    未配置 WECOM_CONTACT_SECRET 时返回 disabled，不发任何请求。
    """
    if not config.wecom_contacts_sync_enabled():
        return {"status": "disabled"}

    name_by_id = {int(item["id"]): item["name"] for item in list_departments()}
    fetched = [
        (str(user.get("userid") or ""), str(user.get("name") or ""), user.get("department") or [])
        for user in list_department_users()
    ]
    fetched = [row for row in fetched if row[0]]

    inserted = updated = 0
    conn = _db.get_db()
    for userid, name, dept_ids in fetched:
        department = ",".join(name_by_id.get(int(dept_id), str(dept_id)) for dept_id in dept_ids if str(dept_id))
        cursor = conn.execute(
            "INSERT INTO wecom_contacts (userid, name, department, synced_at) VALUES (%s, %s, %s, NOW()) "
            "ON DUPLICATE KEY UPDATE name=VALUES(name), department=VALUES(department), synced_at=NOW()",
            (userid, name, department),
        )
        # MySQL rowcount 约定：1=新插入，2=更新，0=内容未变
        if cursor.rowcount == 1:
            inserted += 1
        elif cursor.rowcount == 2:
            updated += 1

    if fetched:
        placeholders = ",".join(["%s"] * len(fetched))
        stale = conn.execute(
            f"DELETE FROM wecom_contacts WHERE userid NOT IN ({placeholders})",
            tuple(row[0] for row in fetched),
        )
        removed = max(int(stale.rowcount or 0), 0)
    else:
        # 通讯录拉到 0 人时跳过清理：全量删除大概率是接口异常静默返回空，
        # 宁可保留旧快照也不误清（真实空企业属极端场景，可手工清表）。
        removed = 0
        logger.warning("企微通讯录返回 0 名成员，跳过陈旧行清理")
    conn.commit()

    logger.info(
        "通讯录同步完成 fetched=%s inserted=%s updated=%s removed=%s",
        len(fetched),
        inserted,
        updated,
        removed,
    )
    return {
        "status": "ok",
        "fetched": len(fetched),
        "inserted": inserted,
        "updated": updated,
        "removed": removed,
    }
