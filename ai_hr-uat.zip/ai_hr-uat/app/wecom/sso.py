"""企业微信扫码登录的账号映射与 OAuth state 管理。

策略 A（userid 直接映射）为主：
- 命中 auth_users.wecom_userid 且启用 → 直接登录；
- 通讯录（wecom_contacts）命中 → 自动开通 hr_specialist 账号。
策略 C 兜底：两者都未命中时跳绑定页，凭系统账号密码写入绑定。
"""

import secrets
from typing import Optional

from app import db as _db
from app.wecom.client import WeComError, get_userid_by_code

STATE_TTL_MINUTES = 5
STATE_MAX_BIND_ATTEMPTS = 3

# 不可登录的占位密码哈希：非 PBKDF2 格式，verify_password 恒为 False
_UNUSABLE_PASSWORD_HASH = "!"

WECOM_BIND_ERROR_COUNT = "wecom_bind_error_count"


def issue_state() -> str:
    """生成一次性 OAuth state 并落库（5 分钟内有效）。

    过期判断用 created_at（MySQL DEFAULT NOW() 写入）加 TTL，
    避免 expires_at（应用时钟写入）与 NOW()（数据库时钟）跨时区
    比较导致 state 生来即过期（dev 服务器 MySQL 为 UTC 时踩过）。
    """
    state = secrets.token_urlsafe(24)
    conn = _db.get_db()
    conn.execute(
        "DELETE FROM wecom_oauth_states WHERE created_at < NOW() - INTERVAL %s MINUTE",
        (STATE_TTL_MINUTES,),
    )
    conn.execute("INSERT INTO wecom_oauth_states (state) VALUES (%s)", (state,))
    conn.commit()
    return state


def consume_state(state: str, require_pending: bool = False) -> bool:
    """校验并消费 state（一次性）。

    ``require_pending=True`` 供回调入口使用：只接受尚无扫码人身份的
    "发起态" state——绑定态（已写入 wecom_userid）的 state 只允许
    /wecom/bind 消费，防止回调用重放拿到绑定会话。
    """
    if not state:
        return False
    extra = " AND wecom_userid=''" if require_pending else ""
    condition = f"state=%s AND created_at > NOW() - INTERVAL {STATE_TTL_MINUTES} MINUTE{extra}"
    conn = _db.get_db()
    cursor = conn.execute(f"DELETE FROM wecom_oauth_states WHERE {condition}", (state,))
    conn.commit()
    return cursor.rowcount > 0


def bind_userid_to_state(state: str, wecom_userid: str) -> None:
    """回调阶段记录扫码人 userid，供绑定页换发会话使用。"""
    conn = _db.get_db()
    conn.execute(
        "INSERT INTO wecom_oauth_states (state, wecom_userid, bind_error_count) VALUES (%s, %s, 0) "
        "ON DUPLICATE KEY UPDATE wecom_userid=VALUES(wecom_userid), bind_error_count=0",
        (state, wecom_userid),
    )
    conn.commit()


def record_bind_attempt(state: str) -> int:
    """绑定页密码校验失败计数 +1，返回累计失败次数。"""
    conn = _db.get_db()
    conn.execute(
        "INSERT INTO wecom_oauth_states (state, bind_error_count) VALUES (%s, 1) "
        "ON DUPLICATE KEY UPDATE bind_error_count=bind_error_count+1",
        (state,),
    )
    conn.commit()
    row = conn.execute("SELECT bind_error_count FROM wecom_oauth_states WHERE state=%s", (state,)).fetchone()
    return int(row["bind_error_count"]) if row else 0


def get_state_userid(state: str) -> Optional[str]:
    """绑定页换发会话前取回 state 携带的扫码人 userid。"""
    row = (
        _db.get_db()
        .execute(
            "SELECT wecom_userid FROM wecom_oauth_states WHERE state=%s "
            f"AND created_at > NOW() - INTERVAL {STATE_TTL_MINUTES} MINUTE",
            (state,),
        )
        .fetchone()
    )
    if not row or not row["wecom_userid"]:
        return None
    return str(row["wecom_userid"])


def find_user_by_wecom_userid(wecom_userid: str) -> Optional[dict]:
    return _db.get_auth_user_by_wecom_userid(wecom_userid)


def find_contact(wecom_userid: str) -> Optional[dict]:
    row = (
        _db.get_db()
        .execute("SELECT userid, name, department FROM wecom_contacts WHERE userid=%s", (wecom_userid,))
        .fetchone()
    )
    return dict(row) if row else None


def provision_user_from_contact(contact: dict) -> Optional[dict]:
    """策略 A 自动开通：按通讯录身份创建 hr_specialist 账号。"""
    wecom_userid = str(contact["userid"])
    existing = find_user_by_wecom_userid(wecom_userid)
    if existing:
        return existing
    username = f"wecom_{wecom_userid}"
    if _db.get_auth_user_by_username(username):
        return None
    user_id = f"user_{secrets.token_hex(8)}"
    display_name = str(contact.get("name") or username)
    _db.create_auth_user(
        user_id,
        username,
        display_name,
        _UNUSABLE_PASSWORD_HASH,
        "hr_specialist",
        is_active=True,
    )
    _db.set_auth_user_wecom_userid(user_id, wecom_userid)
    return _db.get_auth_user(user_id)


def login_or_bind_decision(code: str, state: str) -> dict:
    """回调决策：换 userid 后按三策略收敛。

    返回 {action: "login"|"bind"|"error", user?, error_code?}。
    """
    try:
        wecom_userid = get_userid_by_code(code)
    except WeComError as exc:
        return {"action": "error", "error_code": "WECOM_CODE_EXCHANGE_FAILED", "message": str(exc)}

    user = find_user_by_wecom_userid(wecom_userid)
    if user and user.get("is_active"):
        return {"action": "login", "user": user}

    if user and not user.get("is_active"):
        return {"action": "error", "error_code": "WECOM_USER_DISABLED"}

    contact = find_contact(wecom_userid)
    if contact:
        provisioned = provision_user_from_contact(contact)
        if provisioned and provisioned.get("is_active"):
            return {"action": "login", "user": provisioned}
        if provisioned is None:
            return {"action": "bind", "wecom_userid": wecom_userid}

    # 通讯录无此人（未配置通讯录同步或外部人员）→ 策略 C 绑定兜底
    return {"action": "bind", "wecom_userid": wecom_userid}
