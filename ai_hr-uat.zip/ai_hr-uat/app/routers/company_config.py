"""Company configuration and brand asset routes."""

import os

from fastapi import APIRouter, File, UploadFile

from app.brand_assets import brand_asset_url, write_brand_asset
from app.db import get_company_config, update_company_config

router = APIRouter(prefix="/api/company-config", tags=["company-config"])


@router.get("")
async def api_get_company_config():
    """获取公司配置"""
    return get_company_config()


@router.post("")
async def api_update_company_config(data: dict):
    """更新公司配置"""
    return update_company_config(data)


@router.post("/logo")
async def api_upload_company_logo(file: UploadFile = File(...)):
    """上传公司 Logo 图片"""
    ext = os.path.splitext(file.filename or "logo.png")[1] or ".png"
    safe_name = f"company-logo{ext}"
    content = await file.read()
    storage_key = write_brand_asset(safe_name, content, file.content_type or "application/octet-stream")
    logo_url = brand_asset_url(safe_name, storage_key=storage_key)
    update_company_config({"company_logo": logo_url, "company_logo_storage_key": storage_key})
    return {"logo_url": logo_url, "status": "ok"}


@router.post("/poster-bg")
async def api_upload_poster_bg(file: UploadFile = File(...)):
    """上传海报底图"""
    ext = os.path.splitext(file.filename or "poster-bg.png")[1] or ".png"
    safe_name = f"poster-bg{ext}"
    content = await file.read()
    storage_key = write_brand_asset(safe_name, content, file.content_type or "application/octet-stream")
    bg_url = brand_asset_url(safe_name, storage_key=storage_key)
    update_company_config({"poster_bg_image": bg_url, "poster_bg_image_storage_key": storage_key})
    return {"bg_url": bg_url, "status": "ok"}
