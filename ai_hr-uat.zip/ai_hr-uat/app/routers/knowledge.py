"""Knowledge Graph API — 图谱查询、AI问答、推荐、学习路径

Endpoints:
  1. GET  /api/knowledge/graph       — 获取完整知识图谱数据
  2. GET  /api/knowledge/node/{id}   — 获取节点详情 + 关联节点
  3. POST /api/knowledge/chat        — AI 问答（SSE 流式，带安全防护）
  4. POST /api/knowledge/recommend   — 智能推荐：根据岗位和阶段推荐知识
  5. POST /api/knowledge/learn-path  — 生成学习路径
  6. POST /api/knowledge/conflicts   — 检测规则冲突
"""

from __future__ import annotations


import json
import logging
import os

from collections.abc import AsyncGenerator, AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import APIRouter, BackgroundTasks, File, HTTPException, Request, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

if TYPE_CHECKING:
    import aiohttp

logger = logging.getLogger("app.routers.knowledge")
router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])

# AI 接口配置
_API_BASE = os.getenv("OPENAI_API_BASE", "https://dashscope.aliyuncs.com/compatible-mode/v1")
_API_KEY = os.getenv("OPENAI_API_KEY", "") or os.getenv("DASHSCOPE_API_KEY", "")
_CHAT_MODEL = "qwen-plus"

# 全局 LLM Wiki 图兼容实例（延迟加载）
_kg = None


def get_kg():
    """获取 LLM Wiki 图实例（延迟加载 + 自动刷新）。"""
    global _kg
    if _kg is None:
        from kg.core import KnowledgeGraph

        _kg = KnowledgeGraph()
    else:
        _kg.refresh_if_needed()
    return _kg


# ── 请求/响应模型 ──


class RecommendRequest(BaseModel):
    role: str
    stage: str = ""


class LearnPathRequest(BaseModel):
    role: str
    level: str = "beginner"


# ── 0. 岗位识别接口 ────────────────────────────────────────────


@router.get("/identify")
async def api_identify_role(role: str = ""):
    """根据岗位名称识别行业场景、推荐方法、适用规则"""
    if not role or len(role.strip()) < 2:
        return {"scenarios": [], "methods": [], "rules": [], "role_type": "general"}

    kg = get_kg()
    role = role.strip()

    # 1. 识别场景
    scenario_ids = kg._find_role_scenarios(role)
    scenarios = []
    for sid in scenario_ids:
        node = kg.nodes.get(sid)
        if node and node.get("visibility", "public") == "public":
            scenarios.append({"id": sid, "name": node["name"]})

    # 2. 图遍历获取推荐方法和规则
    context = kg.traverse_for_role(role, depth=2, visibility="public", max_tokens=300)

    methods = [{"id": n["id"], "name": n["name"]} for n in context.get("methods", [])[:4]]
    rules = [{"id": n["id"], "name": n["name"]} for n in context.get("rules", [])[:3]]

    # 3. 识别角色类型
    from ontology.engine import OntologyEngine

    role_type = OntologyEngine.detect_role_type(role)

    return {
        "scenarios": scenarios,
        "methods": methods,
        "rules": rules,
        "role_type": role_type,
    }


# ── 0b. 筛选规则生成接口 ────────────────────────────────────────

# 角色类型 → 默认权重映射
_ROLE_WEIGHTS = {
    "service": {"tech": 0.10, "experience": 0.20, "service": 0.35, "culture": 0.20, "education": 0.15},
    "technical": {"tech": 0.40, "experience": 0.25, "education": 0.15, "culture": 0.10, "service": 0.10},
    "management": {"tech": 0.15, "experience": 0.35, "education": 0.15, "culture": 0.25, "service": 0.10},
    "product": {"tech": 0.25, "experience": 0.25, "education": 0.20, "culture": 0.20, "service": 0.10},
    "design": {"tech": 0.30, "experience": 0.20, "education": 0.20, "culture": 0.20, "service": 0.10},
    "sales_marketing": {"tech": 0.10, "experience": 0.30, "education": 0.15, "culture": 0.20, "service": 0.25},
    "general": {"tech": 0.25, "experience": 0.25, "education": 0.20, "culture": 0.15, "service": 0.15},
}

# 角色类型 → 默认经验/学历阈值
_ROLE_DEFAULTS = {
    "service": {"min_years": 0, "min_education": "any", "leadership": False},
    "technical": {"min_years": 2, "min_education": "bachelor", "leadership": False},
    "management": {"min_years": 5, "min_education": "bachelor", "leadership": True},
    "product": {"min_years": 2, "min_education": "bachelor", "leadership": False},
    "design": {"min_years": 2, "min_education": "bachelor", "leadership": False},
    "sales_marketing": {"min_years": 2, "min_education": "any", "leadership": False},
    "general": {"min_years": 1, "min_education": "any", "leadership": False},
}


@router.get("/screening-rules")
async def api_screening_rules(role: str = ""):
    """根据岗位名称，利用 KG 动态生成简历筛选规则"""
    if not role or len(role.strip()) < 2:
        raise HTTPException(400, "岗位名称不能为空")

    kg = get_kg()
    role = role.strip()

    # 1. 识别人物类型
    from ontology.engine import OntologyEngine

    role_type = OntologyEngine.detect_role_type(role)

    # 2. KG 遍历获取相关知识
    kg_context = kg.traverse_for_role(role, depth=2, visibility="public", max_tokens=500)

    # 3. 从 KG 提取技能关键词
    required_skills = []
    preferred_skills = []

    # 从场景节点提取关键词
    for scenario in kg_context.get("scenarios", []):
        tags = scenario.get("tags", [])
        for tag in tags:
            if tag not in required_skills and tag not in ("基础", "进阶"):
                required_skills.append(tag)

    # 从方法节点提取技能
    for method in kg_context.get("methods", []):
        tags = method.get("tags", [])
        for tag in tags:
            if tag not in required_skills and tag not in preferred_skills:
                preferred_skills.append(tag)

    # 限制数量
    required_skills = required_skills[:5] if required_skills else _default_skills(role_type)
    preferred_skills = preferred_skills[:4]

    # 4. 获取权重和默认配置
    weights = _ROLE_WEIGHTS.get(role_type, _ROLE_WEIGHTS["general"])
    defaults = _ROLE_DEFAULTS.get(role_type, _ROLE_DEFAULTS["general"])

    # 5. 领导力关键词（管理岗）
    leadership_keywords = []
    if defaults.get("leadership"):
        leadership_keywords = ["团队管理", "leader", "manager", "总监", "负责人", "head", "带队"]

    # 6. 从 KG 规则提取加分项
    bonus_keywords = []
    for rule in kg_context.get("rules", []):
        tags = rule.get("tags", [])
        for tag in tags:
            if tag not in bonus_keywords:
                bonus_keywords.append(tag)
    bonus_keywords = bonus_keywords[:4]

    return {
        "role": role,
        "role_type": role_type,
        "required_skills": required_skills,
        "preferred_skills": preferred_skills,
        "min_years_experience": defaults["min_years"],
        "min_education": defaults["min_education"],
        "skill_match_mode": "any",
        "leadership_keywords": leadership_keywords,
        "bonus_keywords": bonus_keywords,
        "weights": weights,
        "scenarios": [s["name"] for s in kg_context.get("scenarios", [])[:3]],
    }


def _default_skills(role_type: str) -> list:
    """角色类型 → 默认必需要求（KG 无匹配时的 fallback）"""
    defaults = {
        "service": ["服务意识", "沟通能力"],
        "technical": ["团队协作", "学习能力"],
        "management": ["团队管理", "决策能力"],
        "product": ["需求分析", "逻辑思维"],
        "design": ["审美能力", "用户思维"],
        "sales_marketing": ["沟通能力", "抗压能力"],
        "general": ["学习能力", "沟通能力"],
    }
    return defaults.get(role_type, defaults["general"])


# ── 1. 图谱数据接口 ────────────────────────────────────────────


@router.get("/graph")
async def api_get_graph():
    """返回完整知识图谱数据（节点 + 边 + 统计）。兼容旧版前端字段。"""
    kg = get_kg()
    # 统计类型分布
    type_counts = {"concept": 0, "method": 0, "rule": 0, "scenario": 0}
    nodes = []
    for n in kg.nodes.values():
        if n.get("visibility", "public") != "public":
            continue
        type_counts[n.get("type", "concept")] = type_counts.get(n.get("type", "concept"), 0) + 1
        nodes.append(
            {
                "id": n["id"],
                "name": n["name"],
                "type": n["type"],
                "definition": n.get("definition", ""),
                "tags": n.get("tags", []),  # 前端过滤依赖此字段
                "connections": len(kg._adjacency.get(n["id"], [])),
            }
        )
    edges = [
        {
            "source": e["source"],
            "target": e["target"],
            "relation": e.get("relation", ""),
            "weight": e.get("weight", 0.5),  # 前端边宽依赖此字段
        }
        for e in kg.edges
    ]
    return {
        "nodes": nodes,
        "edges": edges,
        "stats": {
            "nodes": len(nodes),
            "edges": len(edges),
            "types": type_counts,  # 前端统计依赖此字段
            "version": kg.version,
        },
    }


@router.get("/node/{node_id}")
async def api_get_node(node_id: str):
    """获取节点详情 + 关联节点。"""
    kg = get_kg()
    canonical_id = node_id if node_id in kg.nodes else kg._bare_ids.get(node_id)
    node = kg.nodes.get(canonical_id or "")
    if not node:
        raise HTTPException(404, f"节点 {node_id} 不存在")

    # 获取关联节点
    neighbors = []
    for nid in kg._adjacency.get(canonical_id, []):
        neighbor = kg.nodes.get(nid)
        if neighbor and neighbor.get("visibility", "public") == "public":
            neighbors.append(
                {
                    "id": neighbor["id"],
                    "name": neighbor["name"],
                    "type": neighbor["type"],
                    "definition": neighbor.get("definition", "")[:80],
                }
            )

    # 找到关联边
    related_edges = [e for e in kg.edges if e["source"] == canonical_id or e["target"] == canonical_id]

    # 兼容旧版 related_nodes 字段
    related_nodes = [
        {"id": nid, "name": kg.nodes[nid]["name"], "type": kg.nodes[nid]["type"]}
        for nid in kg._adjacency.get(canonical_id, [])
        if nid in kg.nodes
    ]

    return {
        "node": node,
        "neighbors": neighbors,
        "edges": related_edges,
        "related_nodes": related_nodes,
        "connection_count": len(related_edges),
    }


# ── 2. AI 问答接口（SSE 流式 + 安全防护）───────────────


@router.post("/chat")
async def api_knowledge_chat(request: Request):
    """AI 问答接口，SSE 流式返回，带安全防护。

    Request body: { "question": "...", "context_nodes": [...], "mode": "general"|"candidate" }
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "请求体必须为 JSON")

    question = (body.get("question", "") or "").strip()
    if not question:
        raise HTTPException(400, "问题不能为空")

    context_node_ids = body.get("context_nodes", []) or []
    mode = body.get("mode", "general")

    kg = get_kg()

    from kg.safety import (
        check_emotion,
        check_privacy_probe,
        mark_outdated_nodes,
    )

    # 1. 隐私探测检测
    if check_privacy_probe(question):
        return StreamingResponse(
            _stream_simple("抱歉，我无法回答涉及公司内部信息的问题。如有具体疑问，请直接联系 HR。"),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
        )

    # 2. 情感检测 → 走友善模式
    if check_emotion(question):
        return StreamingResponse(
            _stream_empathy(question),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
        )

    # 3. KG 检索
    visibility = "public" if mode == "candidate" else "internal"
    kg_results = kg.search(question, top_k=5, visibility=visibility, min_confidence=0.5)

    # 4. 标记过时节点
    kg_results = mark_outdated_nodes(kg_results)

    # 4b. 文档级检索（已上传文档；候选者模式不注入）
    doc_context = _search_doc_context(question, mode)

    # 5. 构建图谱上下文
    if not kg_results and not context_node_ids:
        context_text = _build_context_default(kg)
    elif context_node_ids:
        nodes_map = {n["id"]: n for n in kg.nodes.values()}
        resolved_ids = [
            node_id if node_id in nodes_map else kg._bare_ids.get(node_id, node_id) for node_id in context_node_ids
        ]
        context_text = _build_context(resolved_ids, nodes_map, kg)
    else:
        nodes_map = {n["id"]: n for n in kg.nodes.values()}
        node_ids = [r["id"] for r in kg_results[:3]]
        context_text = _build_context(node_ids, nodes_map, kg)

    # 5b. 拼接文档检索上下文（若命中）
    if doc_context:
        context_text = context_text + "\n" + doc_context

    # 6. 构建系统提示词
    system_prompt = _build_system_prompt(context_text)

    # 7. 流式返回
    return StreamingResponse(
        _stream_chat_with_safety(system_prompt, question, kg_results[:3], mode),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


# ── 3. 智能推荐 ─────────────────────────────────────


@router.post("/recommend")
async def api_recommend_knowledge(req: RecommendRequest):
    """智能推荐：根据岗位和阶段推荐相关知识。"""
    kg = get_kg()
    role = req.role.strip()
    if not role:
        raise HTTPException(400, "岗位名称不能为空")

    # 图遍历获取相关知识
    context = kg.traverse_for_role(role, depth=2, visibility="public", max_tokens=300)

    # 按阶段过滤
    stage_filter = {
        "jd_write": ["JD撰写", "需求分析"],
        "crawl": ["渠道管理", "简历筛选"],
        "match": ["评估方法"],
        "interview_gen": ["面试方法", "评估方法"],
        "report": ["评估方法", "Offer管理"],
    }
    relevant_tags = stage_filter.get(req.stage, [])

    recommendations = []
    for type_key in ["methods", "rules", "scenarios"]:
        for node in context.get(type_key, []):
            tags = node.get("tags", [])
            stage_match = not relevant_tags or any(t in tags for t in relevant_tags)
            relevance = float(node.get("confidence", 0.5)) * (1.0 if stage_match else 0.8)
            recommendations.append(
                {
                    "id": node["id"].rsplit("/", 1)[-1],
                    "name": node["name"],
                    "type": node["type"],
                    "definition": node.get("definition", "")[:80],
                    "relevance": relevance,
                }
            )

    # 按相关性排序，取 top-5
    recommendations.sort(key=lambda r: r["relevance"], reverse=True)
    recommendations = recommendations[:5]

    # 跟踪使用
    _track_usage("recommend", [r["id"] for r in recommendations])

    return {
        "role": role,
        "stage": req.stage,
        "recommendations": recommendations,
    }


# ── 4. 学习路径 ─────────────────────────────────────


@router.post("/learn-path")
async def api_learning_path(req: LearnPathRequest):
    """生成学习路径。"""
    kg = get_kg()
    path = kg.generate_learning_path(req.role, req.level)

    return {
        "role": req.role,
        "level": req.level,
        "path": [
            {
                "id": n["id"],
                "name": n["name"],
                "type": n["type"],
                "definition": n.get("definition", "")[:80],
                "order": i + 1,
            }
            for i, n in enumerate(path)
        ],
    }


# ── 5. 冲突检测 ─────────────────────────────────────


@router.post("/conflicts")
async def api_check_conflicts(request: Request):
    """检测规则冲突。"""
    kg = get_kg()
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(400, "请求体必须为 JSON")
    active_scenarios = data.get("scenarios", [])

    conflicts = kg.detect_conflicts(active_scenarios)

    # 只返回 medium 以上
    conflicts = [c for c in conflicts if c.get("severity") in ("high", "medium")]

    return {"conflicts": conflicts}


# ── 6. 文档上传与管理 ──────────────────────────────────────


@router.post("/documents/upload")
async def api_upload_documents(background: BackgroundTasks, files: list[UploadFile] = File(default=[])):
    """旧文档上传兼容入口；新请求统一进入 LLM Wiki 摄取。"""
    from app import wiki_ingest
    from app.routers.wiki import _recover_filename

    if not files:
        raise HTTPException(400, "未选择文件")

    max_file_size = 20 * 1024 * 1024
    validated = []
    for f in files:
        name = _recover_filename(os.path.basename(f.filename or ""))
        if not name or "." not in name:
            raise HTTPException(400, f"文件名不合法: {f.filename}")
        ext = name.rsplit(".", 1)[1].lower()
        if ext not in wiki_ingest.SUPPORTED_EXTS:
            raise HTTPException(400, f"不支持的文档类型: .{ext}（支持 {'/'.join(sorted(wiki_ingest.SUPPORTED_EXTS))}）")
        content = await f.read()
        if len(content) == 0:
            raise HTTPException(400, f"文件为空: {name}")
        if len(content) > max_file_size:
            raise HTTPException(400, f"文件超过 {max_file_size // (1024 * 1024)}MB 上限: {name}")
        validated.append((name, ext, content))

    created = []
    for name, ext, content in validated:
        source_id = wiki_ingest.start_ingest_source_sync(name, content, ext)
        created.append(
            {
                "id": source_id,
                "source_id": source_id,
                "filename": name,
                "ext": ext,
                "size_bytes": len(content),
                "status": "processing",
                "chunk_count": 0,
            }
        )

    return {"documents": created}


@router.get("/documents")
async def api_list_documents():
    """旧列表兼容入口；返回 LLM Wiki 资料状态。"""
    from app import wiki_store as ws

    documents = []
    for source in ws.list_ingest():
        try:
            page_count = len(json.loads(source.get("pages_written") or "[]"))
        except (TypeError, json.JSONDecodeError):
            page_count = 0
        documents.append(
            {
                **source,
                "id": source.get("source_id"),
                "chunk_count": page_count,
            }
        )
    return {"documents": documents}


@router.delete("/documents/{doc_id}")
def api_delete_document(doc_id: str):
    """旧删除兼容入口；删除对应 Wiki 资料和生成页。"""
    from app.routers.wiki import api_delete_source

    result = api_delete_source(doc_id)
    return {**result, "id": doc_id}


@router.post("/documents/{doc_id}/reprocess")
async def api_reprocess_document(doc_id: str, background: BackgroundTasks):
    """旧重试兼容入口；强制重新摄取对应 Wiki 资料。"""
    from app.routers.wiki import api_reprocess

    return await api_reprocess(doc_id, background)


# ── 内部方法 ────────────────────────────────────────


def _build_context(node_ids: list, nodes_map: dict, kg) -> str:
    """从图谱中提取相关节点的定义和关系，构建上下文文本。"""
    if not node_ids:
        core_ids = ["c_jd", "c_resume", "c_interview", "c_offer", "c_candidate"]
        node_ids = [nid for nid in core_ids if nid in nodes_map]

    parts = ["## 招聘知识图谱上下文\n"]
    parts.append("以下是与当前问题相关的招聘领域知识：\n")

    for nid in node_ids:
        if nid not in nodes_map:
            continue
        node = nodes_map[nid]
        type_label = {"concept": "概念", "method": "方法", "rule": "规则", "scenario": "场景"}.get(
            node.get("type", ""), node.get("type", "")
        )
        parts.append(f"- **{node['name']}**（{type_label}）：{node['definition']}")

    # 添加相关关系
    if node_ids:
        parts.append("\n### 关键关系\n")
        added_relations = set()
        for nid in node_ids:
            for e in kg.edges:
                rel_key = f"{e['source']}->{e['target']}"
                if (e["source"] == nid or e["target"] == nid) and rel_key not in added_relations:
                    added_relations.add(rel_key)
                    src_name = nodes_map.get(e["source"], {}).get("name", e["source"])
                    tgt_name = nodes_map.get(e["target"], {}).get("name", e["target"])
                    relation_map = {
                        "需要": "需要",
                        "产出": "产出",
                        "优化": "可以优化",
                        "适用于": "适用于",
                        "前置": "是前置条件",
                        "关联": "关联",
                    }
                    rel_text = relation_map.get(e["relation"], e["relation"])
                    parts.append(f"- {src_name} **{rel_text}** {tgt_name}")
                    if len(added_relations) >= 20:
                        break
            if len(added_relations) >= 20:
                break

    return "\n".join(parts)


def _build_context_default(kg) -> str:
    """默认上下文（无匹配结果时）。"""
    nodes_map = {n["id"]: n for n in kg.nodes.values()}
    return _build_context([], nodes_map, kg)


def _search_doc_context(question: str, mode: str, top_k: int = 3) -> str:
    """兼容旧问答接口：从 LLM Wiki 召回页面，构建可引用上下文。

    - 候选者模式（candidate）不注入，避免内部文档泄露
    - 任何失败（无 API Key / 网络 / 空库）返回空串，不影响主链路
    """
    if mode == "candidate":
        return ""
    try:
        from knowledge import get_knowledge_base

        results = get_knowledge_base().search(question, top_k=top_k)
    except Exception as e:
        logger.warning("LLM Wiki 检索失败: %s", e)
        return ""
    if not results:
        return ""

    parts = ["\n## LLM Wiki 参考\n", "以下内容来自企业 LLM Wiki，回答时请引用页面标题：\n"]
    for r in results:
        content = (r["content"] or "").replace("\n", " ").strip()[:200]
        sources = "、".join(r.get("sources") or [])
        suffix = f"（来源：{sources}）" if sources else ""
        parts.append(f"- 《{r['title']}》{suffix}：「{content}」")
    return "\n".join(parts)


def _build_system_prompt(context: str) -> str:
    """构建系统角色提示词。"""
    return f"""你是一位资深的招聘领域专家，拥有丰富的招聘全流程实操经验。

{context}

请基于以上知识图谱中的概念、方法和规则来回答用户的问题。回答要求：
1. 结构化：使用清晰的层次结构（如分点、步骤等）
2. 实操性：给出具体可操作的建议，而非空泛理论
3. 引用知识：在回答中引用图谱中的相关概念和方法
4. 简洁：控制在300字以内，只说要点
5. 场景化：如果问题涉及特定招聘场景，给出针对性的建议
6. 注明来源：如果引用了已上传文档参考中的内容，注明来自哪份文档（如《文档名》）"""


@asynccontextmanager
async def _ai_session() -> AsyncIterator[aiohttp.ClientSession]:
    """aiohttp 会话上下文（强制系统 DNS 解析）。

    aiohttp 3.14+ 默认 DefaultResolver 基于 aiodns/c-ares 直连 DNS 服务器查询，
    在部分网络环境（本机实测）无法解析，而系统 getaddrinfo 正常（requests/curl 均可）。
    ThreadedResolver 走 asyncio 的 getaddrinfo，复用系统 DNS，保证 AI 服务可连接。
    """
    from aiohttp import ClientSession, TCPConnector
    from aiohttp.resolver import ThreadedResolver

    connector = TCPConnector(resolver=ThreadedResolver())
    try:
        async with ClientSession(connector=connector) as session:
            yield session
    finally:
        await connector.close()


async def _stream_chat_with_safety(
    system_prompt: str, question: str, nodes_used: list, mode: str
) -> AsyncGenerator[str, None]:
    """调用 LLM，流式返回 SSE 事件，并在结束时附加安全包装。"""
    import aiohttp
    import time as _time

    from kg.safety import safe_wrap_answer, sanitize_for_candidate

    _call_start = _time.time()

    def _record(_success: bool, _completion_len: int = 0):
        try:
            from app.audit.token_tracker import record_usage

            record_usage(
                _CHAT_MODEL,
                {"prompt_tokens": 0, "completion_tokens": _completion_len, "total_tokens": _completion_len},
                agent="knowledge",
                operation="kb_chat",
                latency_ms=int((_time.time() - _call_start) * 1000),
                success=_success,
            )
        except Exception:
            pass

    if not _API_KEY:
        yield f"data: {json.dumps({'error': 'API Key 未配置，请检查环境配置中的 OPENAI_API_KEY 或 DASHSCOPE_API_KEY'})}\n\n"
        yield "data: [DONE]\n\n"
        return

    payload = {
        "model": _CHAT_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        "stream": True,
        "temperature": 0.7,
        "max_tokens": 1024,
    }

    headers = {
        "Authorization": f"Bearer {_API_KEY}",
        "Content-Type": "application/json",
    }

    api_url = f"{_API_BASE}/chat/completions"
    full_content = ""

    try:
        async with _ai_session() as session:
            async with session.post(
                api_url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    logger.error(f"AI chat error {resp.status}: {error_text[:300]}")
                    _record(False)
                    yield f"data: {json.dumps({'error': f'AI 服务返回错误 ({resp.status})'})}\n\n"
                    yield "data: [DONE]\n\n"
                    return

                async for line in resp.content:
                    line_text = line.decode("utf-8").strip()
                    if not line_text or line_text.startswith(":"):
                        continue
                    if line_text == "data: [DONE]":
                        break
                    if line_text.startswith("data: "):
                        try:
                            chunk = json.loads(line_text[6:])
                            choices = chunk.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    full_content += content
                                    yield f"data: {json.dumps({'content': content})}\n\n"
                        except json.JSONDecodeError:
                            continue

    except aiohttp.ClientError as e:
        logger.error(f"AI chat connection error: {e}")
        _record(False)
        yield f"data: {json.dumps({'error': f'AI 服务连接失败: {str(e)[:100]}'})}\n\n"
        yield "data: [DONE]\n\n"
        return
    except Exception as e:
        logger.error(f"AI chat unexpected error: {e}")
        _record(False)
        yield f"data: {json.dumps({'error': f'未知错误: {str(e)[:100]}'})}\n\n"
        yield "data: [DONE]\n\n"
        return

    # 安全包装
    if mode == "candidate":
        full_content = sanitize_for_candidate(full_content)
    full_content = safe_wrap_answer(full_content, nodes_used)

    # 发送安全包装后的完成标记
    nodes_info = [{"id": n["id"], "name": n["name"], "type": n.get("type", "")} for n in nodes_used]
    yield f"data: {json.dumps({'done': True, 'total_length': len(full_content), 'nodes_used': nodes_info})}\n\n"
    yield "data: [DONE]\n\n"

    # 跟踪使用
    _track_usage("chat", [n["id"] for n in nodes_used])
    _record(True, len(full_content))


async def _stream_simple(message: str) -> AsyncGenerator[str, None]:
    """简单文本流式返回。"""
    yield f"data: {json.dumps({'content': message})}\n\n"
    yield f"data: {json.dumps({'done': True})}\n\n"
    yield "data: [DONE]\n\n"


async def _stream_empathy(question: str) -> AsyncGenerator[str, None]:
    """情感模式流式回答。"""
    import aiohttp
    import time as _time

    _call_start = _time.time()

    def _record(_success: bool, _completion_len: int = 0):
        try:
            from app.audit.token_tracker import record_usage

            record_usage(
                _CHAT_MODEL,
                {"prompt_tokens": 0, "completion_tokens": _completion_len, "total_tokens": _completion_len},
                agent="knowledge",
                operation="kb_empathy",
                latency_ms=int((_time.time() - _call_start) * 1000),
                success=_success,
            )
        except Exception:
            pass

    if not _API_KEY:
        yield f"data: {json.dumps({'content': '别担心，面试是一个双向了解的过程。做好准备，展现真实的自己就好。加油！💪'})}\n\n"
        yield f"data: {json.dumps({'done': True})}\n\n"
        yield "data: [DONE]\n\n"
        return

    system = """你是一个友善专业的招聘助手。候选人可能感到紧张或不安，请给予鼓励和支持。
语气温暖亲切，像朋友一样。不要输出专业知识，重点是安抚情绪。"""

    payload = {
        "model": _CHAT_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": question},
        ],
        "stream": True,
        "temperature": 0.7,
        "max_tokens": 512,
    }

    headers = {
        "Authorization": f"Bearer {_API_KEY}",
        "Content-Type": "application/json",
    }
    api_url = f"{_API_BASE}/chat/completions"

    try:
        async with _ai_session() as session:
            async with session.post(
                api_url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status != 200:
                    _record(False)
                    yield f"data: {json.dumps({'content': '别担心，面试是一个双向了解的过程。做好准备，展现真实的自己就好。加油！💪'})}\n\n"
                    yield f"data: {json.dumps({'done': True})}\n\n"
                    yield "data: [DONE]\n\n"
                    return
                async for line in resp.content:
                    line_text = line.decode("utf-8").strip()
                    if not line_text or line_text.startswith(":"):
                        continue
                    if line_text == "data: [DONE]":
                        break
                    if line_text.startswith("data: "):
                        try:
                            chunk = json.loads(line_text[6:])
                            choices = chunk.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    yield f"data: {json.dumps({'content': content})}\n\n"
                        except json.JSONDecodeError:
                            continue
    except Exception as e:
        logger.error(f"Empathy stream error: {e}")
        _record(False)
        yield f"data: {json.dumps({'content': '别担心，面试是一个双向了解的过程。做好准备，展现真实的自己就好。加油！💪'})}\n\n"

    _record(True)
    yield f"data: {json.dumps({'done': True})}\n\n"
    yield "data: [DONE]\n\n"


def _track_usage(action: str, node_ids: list):
    """匿名记录 KG 使用情况。"""
    usage_path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "kg_usage.json")
    usage = {}
    if os.path.exists(usage_path):
        try:
            with open(usage_path, encoding="utf-8") as f:
                usage = json.load(f)
        except Exception:
            pass

    for nid in node_ids:
        if nid not in usage:
            usage[nid] = {"count": 0, "actions": {}}
        usage[nid]["count"] += 1
        usage[nid]["actions"][action] = usage[nid]["actions"].get(action, 0) + 1

    try:
        with open(usage_path, "w", encoding="utf-8") as f:
            json.dump(usage, f, ensure_ascii=False)
    except Exception as e:
        logger.warning(f"Failed to track KG usage: {e}")
