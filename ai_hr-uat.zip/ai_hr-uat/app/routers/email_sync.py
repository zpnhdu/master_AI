"""Tenant-wide mailbox sync trigger API."""

from __future__ import annotations

import asyncio
import smtplib

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

from app.access_control import require_current_user
from app.email_accounts import EmailDomainError, get_account, list_sync_runs, trigger_sync_all
from app.email.email_sender import _connect_smtp
from app.email.email_sync import dispatch_sync_run, test_account_connection

router = APIRouter(tags=["email-sync"])


def _translate_error(exc: EmailDomainError) -> HTTPException:
    detail = {"code": exc.code, "message": exc.message}
    if exc.code == "EMAIL_SYNC_ALREADY_RUNNING" and exc.message.startswith("run_"):
        detail["run_id"] = exc.message
        detail["message"] = "邮箱已有运行中任务"
    return HTTPException(status_code=exc.status_code, detail=detail)


def _dispatch(run: dict) -> None:
    dispatch_sync_run(run["id"])


@router.post("/api/email-accounts/sync-all", status_code=202)
async def api_sync_all_accounts(request: Request):
    try:
        result = trigger_sync_all(require_current_user(request))
        for item in result["items"]:
            _dispatch({"id": item["run_id"]})
        return {
            "triggered": result["triggered"],
            "run_ids": result["run_ids"],
            "items": result["items"],
            "status": "queued",
        }
    except EmailDomainError as exc:
        raise _translate_error(exc) from exc


@router.get("/api/email-accounts/sync-runs")
async def api_list_sync_runs(
    request: Request,
    run_ids: str | None = Query(default=None, description="逗号分隔的 run id，用于跟踪一次触发"),
    limit: int = Query(default=20, ge=1, le=100),
):
    ids = [item.strip() for item in run_ids.split(",") if item.strip()] if run_ids else None
    return {"items": list_sync_runs(require_current_user(request), run_ids=ids, limit=limit)}


class TestConnectionBody(BaseModel):
    account_id: str


def _check_account_smtp(account: dict, credential: str) -> dict:
    """Per-account SMTP connectivity check; mirrors mass_interview's config mapping."""
    username = str(account.get("username") or account.get("email_address") or "").strip()
    config = {
        "host": account.get("smtp_host"),
        "port": account.get("smtp_port"),
        "security": account.get("smtp_security") or "ssl",
        "username": username,
        "password": credential,
        "from_email": account.get("email_address") or username,
    }
    missing = [key for key in ("host", "username", "password") if not str(config.get(key) or "").strip()]
    if missing:
        return {"ok": False, "error_code": "SMTP_NOT_CONFIGURED", "message": "SMTP 服务器或授权码尚未配置"}
    try:
        conn = _connect_smtp(config)
        conn.noop()
        conn.quit()
        return {"ok": True, "error_code": "", "message": "SMTP 连接正常"}
    except smtplib.SMTPAuthenticationError:
        return {"ok": False, "error_code": "SMTP_AUTH_FAILED", "message": "SMTP 认证失败，请检查该邮箱的授权码"}
    except Exception as exc:
        return {"ok": False, "error_code": "SMTP_CONNECT_FAILED", "message": f"SMTP 连接失败：{exc}"}


@router.post("/api/email-accounts/test-connection")
async def api_test_connection(request: Request, body: TestConnectionBody):
    user = require_current_user(request)
    try:
        account = get_account(body.account_id, user, include_secret=True, permission="read")
    except EmailDomainError as exc:
        raise _translate_error(exc) from exc
    credential = account.pop("credential", "")
    email = account.get("email_address") or account.get("username") or body.account_id
    imap_result = await asyncio.to_thread(test_account_connection, account, credential)
    smtp_result = await asyncio.to_thread(_check_account_smtp, account, credential)
    return {
        "account_id": body.account_id,
        "email": email,
        "imap": imap_result,
        "smtp": smtp_result,
    }
