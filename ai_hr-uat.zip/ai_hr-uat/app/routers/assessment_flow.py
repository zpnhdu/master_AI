"""统一评估方案、小评队列和人工复核 API。"""

from typing import Optional
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app import aggregate_report_jobs, assessment_flow, candidate_reports
from app.access_control import require_current_user, require_pipeline_path_access

router = APIRouter(
    prefix="/api/assessment-flow",
    tags=["assessment-flow"],
    dependencies=[Depends(require_pipeline_path_access)],
)


class PlanDraftRequest(BaseModel):
    config: dict
    actor_id: str = "hr"


class ActivatePlanRequest(BaseModel):
    actor_id: str = "hr"


class ReviewRequest(BaseModel):
    modality: str
    reason: str = Field(min_length=1)
    actor_id: str = "hr"
    override_score: Optional[float] = None


class GenerateCandidateReportsRequest(BaseModel):
    candidate_ids: list[str] = Field(default_factory=list)
    force: bool = False


class GenerateAggregateReportRequest(BaseModel):
    passed_only: bool = True


@router.get("/{pipeline_id}/plan")
async def api_get_active_assessment_plan(pipeline_id: str):
    return {"plan": assessment_flow.get_active_plan(pipeline_id)}


@router.post("/{pipeline_id}/plans/draft")
async def api_create_assessment_plan_draft(pipeline_id: str, request: PlanDraftRequest):
    try:
        return assessment_flow.save_plan_draft(pipeline_id, request.config, request.actor_id)
    except ValueError as error:
        raise HTTPException(400, str(error)) from error


@router.post("/{pipeline_id}/plans/{plan_id}/activate")
async def api_activate_assessment_plan(pipeline_id: str, plan_id: str, request: ActivatePlanRequest):
    try:
        return assessment_flow.activate_plan(pipeline_id, plan_id, request.actor_id)
    except ValueError as error:
        raise HTTPException(400, str(error)) from error


@router.get("/{pipeline_id}/queue")
async def api_get_assessment_queue(pipeline_id: str):
    return assessment_flow.list_decision_queue(pipeline_id)


@router.post("/{pipeline_id}/reports/generate")
async def api_generate_candidate_reports(pipeline_id: str, request: GenerateCandidateReportsRequest):
    return await candidate_reports.generate_reports(
        pipeline_id,
        request.candidate_ids,
        force=request.force,
    )


@router.post("/{pipeline_id}/aggregate-report/jobs")
async def api_start_aggregate_report_job(pipeline_id: str, request: GenerateAggregateReportRequest):
    job, created = aggregate_report_jobs.create_job(pipeline_id, passed_only=request.passed_only)
    aggregate_report_jobs.schedule_job(job["id"])
    return {"job": job, "created": created}


@router.get("/{pipeline_id}/aggregate-report/jobs/latest")
async def api_get_latest_aggregate_report_job(pipeline_id: str):
    return {"job": aggregate_report_jobs.get_latest_job(pipeline_id)}


@router.get("/{pipeline_id}/aggregate-report/jobs/{job_id}")
async def api_get_aggregate_report_job(pipeline_id: str, job_id: str):
    job = aggregate_report_jobs.get_job(job_id)
    if not job or job.get("pipeline_id") != pipeline_id:
        raise HTTPException(404, "综合评估报告任务不存在")
    return {"job": job}


@router.get("/{pipeline_id}/reports")
async def api_list_candidate_reports(pipeline_id: str):
    reports = candidate_reports.list_reports(pipeline_id)
    generating_candidate_ids = candidate_reports.schedule_missing_reports(pipeline_id)
    return {
        "pipeline_id": pipeline_id,
        "reports": reports,
        "total": len(reports),
        "generating_candidate_ids": generating_candidate_ids,
    }


def _docx_response(content, filename: str) -> StreamingResponse:
    encoded = quote(filename)
    return StreamingResponse(
        content,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{encoded}"},
    )


@router.get("/{pipeline_id}/reports/export.docx")
async def api_export_candidate_reports(pipeline_id: str, candidate_ids: str = ""):
    selected = [item.strip() for item in candidate_ids.split(",") if item.strip()]
    try:
        content = candidate_reports.build_pipeline_reports_docx(pipeline_id, selected)
    except ValueError as error:
        raise HTTPException(404, str(error)) from error
    return _docx_response(content, f"候选人评估报告_{pipeline_id}.docx")


@router.get("/{pipeline_id}/reports/{candidate_id}")
async def api_get_candidate_report(pipeline_id: str, candidate_id: str):
    report = candidate_reports.get_report(pipeline_id, candidate_id)
    if not report:
        raise HTTPException(404, "候选人报告尚未生成")
    return {"report": report}


@router.get("/{pipeline_id}/reports/{candidate_id}/export.docx")
async def api_export_candidate_report(pipeline_id: str, candidate_id: str):
    report = candidate_reports.get_report(pipeline_id, candidate_id)
    if not report:
        raise HTTPException(404, "候选人报告尚未生成")
    content = candidate_reports.build_reports_docx([report], role=str(report.get("role") or ""))
    return _docx_response(content, f"{report['candidate_name']}_评估报告.docx")


@router.post("/{pipeline_id}/candidates/{candidate_id}/review")
async def api_resolve_assessment_review(
    pipeline_id: str, candidate_id: str, request: ReviewRequest, http_request: Request
):
    try:
        actor_user_id = str(require_current_user(http_request)["id"])
        result = assessment_flow.resolve_review(
            pipeline_id,
            candidate_id,
            request.modality,
            actor_user_id,
            request.reason,
            request.override_score,
        )
        from app.assessment_dispatch import dispatch_next_actions

        result["next_action_dispatch"] = await dispatch_next_actions(pipeline_id, candidate_id, result["package"])
        return result
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
