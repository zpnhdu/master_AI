"""React page entry routes."""

import os

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from starlette.requests import Request

from app import config
from app.access_control import current_user, default_page_for
from app.brand_assets import read_brand_asset

router = APIRouter(tags=["pages"])


def _serve_react_shell() -> HTMLResponse:
    if config.react_frontend_external():
        return HTMLResponse(content="<h1>React frontend is hosted externally</h1>", status_code=404)

    path = os.path.join(config.REACT_FRONTEND_DIR, "index.html")
    if not os.path.isfile(path):
        return HTMLResponse(content="<h1>React frontend build not found</h1>", status_code=404)
    with open(path, encoding="utf-8") as f:
        return HTMLResponse(
            content=f.read(),
            headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
        )


def _serve_app_entry(not_found_msg: str) -> HTMLResponse:
    if config.react_frontend_available():
        return _serve_react_shell()
    return HTMLResponse(content=f"<h1>{not_found_msg}</h1>", status_code=404)


@router.get("/login")
async def login_page():
    """登录页面"""
    return _serve_app_entry("登录页面未找到")


@router.get("/privacy", response_class=HTMLResponse)
async def privacy_page():
    """招聘产品隐私保护协议"""
    return _serve_app_entry("隐私保护协议未找到")


@router.get("/terms", response_class=HTMLResponse)
async def terms_page():
    """招聘产品用户服务协议"""
    return _serve_app_entry("用户服务协议未找到")


@router.get("/")
async def root(request: Request):
    user = current_user(request)
    return RedirectResponse(url=default_page_for(user) if user else "/login")


@router.get("/forbidden", response_class=HTMLResponse)
async def forbidden_page():
    """403 page for authenticated users without the requested permission."""
    return _serve_app_entry("无权限页面未找到")


@router.get("/studio", response_class=HTMLResponse)
async def studio_page():
    """React Studio 入口。"""
    return _serve_react_shell()


@router.get("/favicon.ico", include_in_schema=False)
async def favicon():
    data = read_brand_asset("company-logo.png")
    if data:
        return Response(data, media_type="image/png")
    return Response(status_code=404)


# 企业微信可信域名校验文件（WW_verify_*.txt）。
# 域名穿透到本机时，校验文件由本服务代答；校验串从环境变量读取
# （WECOM_DOMAIN_VERIFY=文件名:内容，企微后台"验证域名归属"给出，
# 多个域名用逗号分隔），避免每换一次域名就改代码重新部署。
_WECOM_DOMAIN_VERIFY_FILES = {
    # 文件名 -> 文件内容（企微后台"验证域名归属"给出）
    "HgR8pAZbDgh1tqJs": "HgR8pAZbDgh1tqJs",
}


@router.get("/WW_verify_{code}.txt", include_in_schema=False)
async def wecom_domain_verify(code: str):
    import os

    for entry in os.getenv("WECOM_DOMAIN_VERIFY", "").split(","):
        entry = entry.strip()
        if ":" in entry:
            name, _, value = entry.partition(":")
            _WECOM_DOMAIN_VERIFY_FILES.setdefault(name.strip(), value.strip())
    content = _WECOM_DOMAIN_VERIFY_FILES.get(code)
    if content is None:
        return Response(status_code=404)
    return Response(content=content, media_type="text/plain")


@router.get("/monitor")
async def monitor_page():
    """系统监控 — React 入口。"""
    return _serve_react_shell()


@router.get("/talent-pool", response_class=HTMLResponse)
async def talent_pool_page():
    """人才库 — React 入口；开关关闭或构建缺失时回退到旧版页面。"""
    return _serve_app_entry("Talent pool page not found")


@router.get("/roles/{role_id}", response_class=HTMLResponse)
async def role_page(role_id: str):
    """角色管理页面 — React 入口；开关关闭或构建缺失时回退到旧版页面。"""
    return _serve_app_entry("角色页面未找到")


@router.get("/pipeline-detail", response_class=HTMLResponse)
async def pipeline_detail_page():
    """流水线详情页"""
    return _serve_app_entry("流水线详情页未找到")


@router.get("/pipelines/{pipeline_id}", response_class=HTMLResponse)
async def react_pipeline_detail_page(pipeline_id: str):
    """React 流水线详情入口。"""
    return _serve_react_shell()


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page():
    """数据仪表盘 — React 入口；开关关闭或构建缺失时回退到旧版页面。"""
    return _serve_app_entry("仪表盘页面未找到")


@router.get("/profile", response_class=HTMLResponse)
async def profile_page():
    """人才画像详情页 — React 入口；开关关闭或构建缺失时回退到旧版页面。"""
    return _serve_app_entry("画像页面未找到")


@router.get("/mass-interview/{token}", response_class=HTMLResponse)
async def mass_interview_page(token: str):
    """百人面试 — 候选人自助面试页面（移动端优先，免登）；React 入口，开关关闭时回退旧版。"""
    return _serve_app_entry("面试页面未找到")


@router.get("/mass-dashboard", response_class=HTMLResponse)
async def mass_dashboard_index():
    """多人面试 — React 面试中心入口，旧版开关关闭时回退。"""
    return _serve_app_entry("多人面试看板未找到")


@router.get("/mass-dashboard/{pipeline_id}")
async def mass_dashboard_page(pipeline_id: str):
    """多人面试 — HR 监控看板，支持按岗位进入 React 面试中心。"""
    return _serve_react_shell()


@router.get("/knowledge", response_class=HTMLResponse)
async def knowledge_page():
    """招聘流程知识图谱 — React 入口；开关关闭或构建缺失时回退到旧版页面。"""
    return _serve_app_entry("知识图谱页面未找到")


@router.get("/xiao-hai", response_class=HTMLResponse)
async def xiao_hai_page(request: Request):
    """小海 — 海报生成 Agent。"""
    return _serve_react_shell()


@router.get("/xiao-shai", response_class=HTMLResponse)
async def xiao_shai_page(request: Request):
    """小筛 — 简历筛选 Agent。"""
    return _serve_react_shell()


@router.get("/xiao-mian", response_class=HTMLResponse)
async def xiao_mian_page(request: Request):
    """小面 — 面试出题 Agent。"""
    return _serve_react_shell()


@router.get("/xiao-ping", response_class=HTMLResponse)
async def xiao_ping_page(request: Request):
    """小评 — 录用评估 Agent。"""
    return _serve_react_shell()


@router.get("/xiao-wen", response_class=HTMLResponse)
async def xiao_wen_page(request: Request):
    """小文 — JD 工作台；React 开关关闭或构建缺失时回退到旧版页面（保留 query）。"""
    return _serve_react_shell()


@router.get("/xiao-xun", response_class=HTMLResponse)
async def xiao_xun_page(request: Request):
    """小寻 — 简历获取与人才库导入工作台。"""
    return _serve_react_shell()
