"""RPA task management routes — create fetch tasks, poll pending tasks, manage results."""

import hashlib
import secrets

from fastapi import APIRouter, HTTPException, Request

from app.access_control import require_pipeline_access
from app.db import (
    create_rpa_task,
    get_pending_rpa_tasks,
    get_rpa_task,
    increment_rpa_task_count,
    list_rpa_tasks,
    update_rpa_task,
)

router = APIRouter(prefix="/api/rpa", tags=["rpa"])


def _require_task_access(request: Request, task: dict) -> None:
    pipeline_id = task.get("pipeline_id", "")
    if pipeline_id:
        require_pipeline_access(request, pipeline_id)


@router.post("/task")
async def api_create_rpa_task(data: dict, request: Request):
    """Create an RPA fetch task. Chrome plugin polls for pending tasks.

    Required fields: platform (boss/liepin/lagou), keywords
    Optional: target_count (default 10), pipeline_id
    """
    platform = data.get("platform", "liepin")
    keywords = data.get("keywords", "")
    target_count = data.get("target_count", 10)
    pipeline_id = data.get("pipeline_id", "")

    if not keywords:
        raise HTTPException(400, "keywords is required")

    if pipeline_id:
        require_pipeline_access(request, pipeline_id)

    task_id = "rpa_" + hashlib.md5(f"{platform}_{keywords}_{secrets.token_hex(4)}".encode()).hexdigest()[:16]

    task = {
        "id": task_id,
        "platform": platform,
        "keywords": keywords,
        "target_count": target_count,
        "pipeline_id": pipeline_id,
        "status": "pending",
    }

    result = create_rpa_task(task)
    return {"status": "created", "task": result}


@router.get("/task")
async def api_list_rpa_tasks(request: Request, status: str = "", pipeline_id: str = "", limit: int = 50):
    """List RPA tasks with optional filters."""
    if pipeline_id:
        require_pipeline_access(request, pipeline_id)
    tasks = list_rpa_tasks(status=status, pipeline_id=pipeline_id, limit=limit)
    tasks = [task for task in tasks if not task.get("pipeline_id") or _task_is_visible(request, task)]
    return {"tasks": tasks, "total": len(tasks)}


def _task_is_visible(request: Request, task: dict) -> bool:
    try:
        _require_task_access(request, task)
        return True
    except HTTPException as error:
        if error.status_code == 404:
            return False
        raise


@router.get("/task/{task_id}")
async def api_get_rpa_task(task_id: str, request: Request):
    """Get a single RPA task status."""
    task = get_rpa_task(task_id)
    if not task:
        raise HTTPException(404, "RPA task not found")
    _require_task_access(request, task)
    return task


@router.put("/task/{task_id}")
async def api_update_rpa_task(task_id: str, data: dict, request: Request):
    """Update RPA task (HR can cancel or adjust target)."""
    existing = get_rpa_task(task_id)
    if not existing:
        raise HTTPException(404, "RPA task not found")
    _require_task_access(request, existing)
    task = update_rpa_task(task_id, data)
    if not task:
        raise HTTPException(404, "RPA task not found")
    return {"status": "updated", "task": task}


@router.get("/task/pending")
async def api_pending_rpa_tasks(request: Request, platform: str = ""):
    """Get pending RPA tasks — called by Chrome plugin to discover work.
    Returns up to 10 pending/running tasks, ordered by creation time.
    """
    tasks = get_pending_rpa_tasks(platform=platform)
    tasks = [task for task in tasks if not task.get("pipeline_id") or _task_is_visible(request, task)]
    return {"tasks": tasks, "total": len(tasks)}


@router.post("/task/{task_id}/push")
async def api_rpa_push_result(task_id: str, data: dict, request: Request):
    """Plugin calls this after pushing a candidate to report progress.
    Increments fetched_count and auto-completes task when target reached.
    """
    existing = get_rpa_task(task_id)
    if not existing:
        raise HTTPException(404, "RPA task not found")
    _require_task_access(request, existing)
    task = increment_rpa_task_count(task_id)

    # 设置 pipeline_id 时通过广播发送通知
    pipeline_id = task.get("pipeline_id", "")
    if pipeline_id:
        from app.db import save_message
        from app.state import broadcast

        save_message(
            pipeline_id,
            "system",
            f"RPA: {task['platform']} 已抓取 {task['fetched_count']}/{task['target_count']} 份简历",
        )
        await broadcast(
            {
                "type": "rpa_progress",
                "pipeline_id": pipeline_id,
                "task_id": task_id,
                "fetched": task["fetched_count"],
                "target": task["target_count"],
            },
            pipeline_id,
        )

    return {"status": "ok", "task": task}
