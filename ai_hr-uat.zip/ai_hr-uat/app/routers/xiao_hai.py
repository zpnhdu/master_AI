"""Xiao Hai template poster machine API — bootstrap / generate / artifacts."""

from __future__ import annotations

import asyncio
import base64
import copy
import json
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response

from app.access_control import require_pipeline_path_access
from app.audit.logger import get_logger
from app.brand_assets import read_brand_asset
from app.config import REACT_PUBLIC_DIR, UPLOAD_DIR
from app.db import create_stage, get_company_config, get_pipeline, get_stages, save_message, update_stage
from app.infrastructure.config import settings
from app.infrastructure.timeout_policy import (
    TimeoutDeadline,
)
from app.media_storage import MediaStorage, get_media_storage, join_storage_key, storage_cache_key
from app.poster_delivery import (
    LAYOUT_VERSION,
    body_reference,
    compose_poster_body,
    prepare_composition,
    save_brand_snapshots,
)
from app.poster_generation import render_poster
from app.poster_jobs import (
    _backfill_fields_from_pipeline,
    create_workspace_job,
    get_job,
    list_pipeline_jobs,
    load_pipeline_jd,
    refine_poster_fields_llm,
    schedule_job,
)
from app.poster_progress import PosterJobConflictError, public_job, set_phase
from app.xiao_hai_generation_jobs import (
    create_generation_job,
    get_generation_job_by_id,
    public_generation_job,
    schedule_generation_job,
)
from app.poster_service import PosterService, PosterServiceError
from app.state import broadcast
from app.utils import parse_stage_output
from app.user_mailbox import (
    PipelineHrNotConfiguredError,
    hr_brand_config,
    require_pipeline_hr,
    resolve_pipeline_hr,
)
from app.xiao_hai_branding import (
    PosterBrandingError,
    load_company_brand_assets,
    read_default_element,
)
from app.xiao_hai_image import (
    CANVAS_PRESETS,
    DEFAULT_IP_REFERENCE_ID,
    ImageGenerationRateLimitError,
    blur_material_reference,
    build_default_director_prompt,
    build_element_board,
    build_full_poster_prompt,
    call_image_generate,
    get_canvas_preset,
)
from app.xiao_hai_prefill import map_studio_fields

logger = get_logger("xiao_hai")

MEDIA_LIBRARY_DIR = Path(REACT_PUBLIC_DIR) / "xiao-hai"
CANVAS_LIBRARY_DIR = MEDIA_LIBRARY_DIR / "canvas-library"
ELEMENT_LIBRARY_DIR = MEDIA_LIBRARY_DIR / "elements"
OSS_XIAO_HAI_PREFIX = settings.oss_xiao_hai_prefix
OSS_REFERENCE_PREFIX = join_storage_key(OSS_XIAO_HAI_PREFIX, "references")
OSS_CANVAS_PREFIX = join_storage_key(OSS_XIAO_HAI_PREFIX, "canvas")
OSS_ELEMENT_PREFIX = join_storage_key(OSS_XIAO_HAI_PREFIX, "elements")
OSS_ARTIFACT_PREFIX = join_storage_key(OSS_XIAO_HAI_PREFIX, "artifacts")


def _is_oss(storage: MediaStorage) -> bool:
    return storage.backend == "oss"


def _reference_key(filename: str) -> str:
    return join_storage_key(OSS_REFERENCE_PREFIX, filename)


def _canvas_library_key(canvas_folder: str, filename: str) -> str:
    return join_storage_key(OSS_CANVAS_PREFIX, canvas_folder, "library", filename)


def _element_key(kind: str, filename: str) -> str:
    return join_storage_key(OSS_ELEMENT_PREFIX, kind, filename)


def _load_element_manifest(storage: MediaStorage | None = None) -> dict:
    """Read the element library manifest (backgrounds + composable elements)."""
    storage = storage or get_media_storage()
    if _is_oss(storage):
        from app.routers.element_library import _load_manifest

        return _load_manifest(storage)

    path = ELEMENT_LIBRARY_DIR / "manifest.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    for kind in ("backgrounds", "elements"):
        data[kind] = [
            item
            for item in data.get(kind, [])
            if isinstance(item, dict) and item.get("file") and (ELEMENT_LIBRARY_DIR / kind / item["file"]).is_file()
        ]
    return data


# Map canvas preset IDs (English) to on-disk folder names (Chinese)
CANVAS_ID_TO_FOLDER: dict[str, str] = {
    "long": "招聘长图",
    "xhs": "小红书图文",
    "dy_v": "抖音竖版",
    "dy_h": "抖音横版",
    "moments": "朋友圈单图",
}

router = APIRouter(tags=["xiao-hai"], dependencies=[Depends(require_pipeline_path_access)])

REFERENCE_DIR = MEDIA_LIBRARY_DIR / "references"
MANIFEST_PATH = REFERENCE_DIR / "manifest.json"
ARTIFACT_DIR = Path(UPLOAD_DIR) / "xiao-hai" / "artifacts"
ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

SAFE_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")
DEFAULT_CANVAS_ID = "long"
_REFERENCE_CACHE_TTL_SECONDS = 30.0
_REFERENCE_CACHE: dict[str, tuple[float, list[dict]]] = {}


def _load_references(storage: MediaStorage | None = None) -> list[dict]:
    storage = storage or get_media_storage()
    if _is_oss(storage):
        cache_key = storage_cache_key(storage)
        cached = _REFERENCE_CACHE.get(cache_key)
        if cached and time.monotonic() - cached[0] < _REFERENCE_CACHE_TTL_SECONDS:
            return copy.deepcopy(cached[1])
        manifest_key = join_storage_key(OSS_REFERENCE_PREFIX, "manifest.json")
        if not storage.exists(manifest_key):
            return []
        try:
            data = json.loads(storage.read(manifest_key).decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            return []
        existing_keys = set(storage.list_keys(f"{OSS_REFERENCE_PREFIX}/"))
        refs = []
        for item in data.get("references") or []:
            file_name = item.get("file") or ""
            thumb = item.get("thumb") or ""
            file_key = item.get("storage_key") or _reference_key(file_name)
            thumb_key = item.get("thumb_storage_key") or (_reference_key(thumb) if thumb else "")
            if not file_name or file_key not in existing_keys:
                continue
            url = (
                storage.sign_url(file_key) if hasattr(storage, "sign_url") else f"/api/xiao-hai/references/{file_name}"
            )
            refs.append(
                {
                    "id": item.get("id"),
                    "label": item.get("label") or item.get("id"),
                    "group": item.get("group") or "",
                    "url": url,
                    "thumb_url": storage.sign_url(thumb_key)
                    if thumb_key in existing_keys and hasattr(storage, "sign_url")
                    else url,
                    "file": file_name,
                    "storage_key": file_key,
                }
            )
        _REFERENCE_CACHE[cache_key] = (time.monotonic(), copy.deepcopy(refs))
        return refs

    if not MANIFEST_PATH.exists():
        return []
    try:
        data = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    refs = []
    for item in data.get("references") or []:
        file_name = item.get("file") or ""
        thumb = item.get("thumb") or ""
        refs.append(
            {
                "id": item.get("id"),
                "label": item.get("label") or item.get("id"),
                "group": item.get("group") or "",
                "url": f"/api/xiao-hai/references/{file_name}",
                "thumb_url": f"/api/xiao-hai/references/{thumb}" if thumb else "",
                "file": file_name,
            }
        )
    return refs


def _find_stage(stages: list[dict], stage_id: str) -> dict | None:
    return next((s for s in stages if s.get("stage_id") == stage_id), None)


def _poster_history(poster_output: dict) -> list[dict]:
    history = poster_output.get("history")
    if isinstance(history, list):
        return history
    return []


def _usable_history(history: list[dict]) -> list[dict]:
    """History items that can be shown without re-burning a first poster."""
    usable = []
    for item in history or []:
        if not isinstance(item, dict):
            continue
        if item.get("url") and item.get("id"):
            usable.append(item)
    return usable


def _load_reference_bytes(reference_id: str | None, reference_data_url: str | None) -> bytes | None:
    if reference_data_url and reference_data_url.startswith("data:"):
        try:
            _, b64 = reference_data_url.split(",", 1)
            return base64.b64decode(b64)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, f"invalid reference_data_url: {exc}") from exc

    if not reference_id:
        return None
    storage = get_media_storage()
    refs = {r["id"]: r for r in _load_references(storage)}
    ref = refs.get(reference_id)
    if not ref:
        if reference_id == DEFAULT_IP_REFERENCE_ID:
            return read_brand_asset("guoquan-mascot.png", storage=storage)
        return None
    if _is_oss(storage):
        key = ref.get("storage_key") or _reference_key(ref["file"])
        if storage.exists(key):
            return storage.read(key)
    path = REFERENCE_DIR / ref["file"]
    if not path.exists():
        if reference_id == DEFAULT_IP_REFERENCE_ID:
            return read_brand_asset("guoquan-mascot.png", storage=storage)
        return None
    return path.read_bytes()


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


@router.get("/api/xiao-hai/references/{file_path:path}")
async def get_reference_file(file_path: str):
    storage = get_media_storage()
    if _is_oss(storage):
        if ".." in file_path or file_path.startswith(("/", "\\")):
            raise HTTPException(400, "Invalid reference path")
        key = _reference_key(file_path)
        if not storage.exists(key):
            raise HTTPException(404, "Reference image not found")
        suffix = Path(file_path).suffix.lower()
        media_type = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(
            suffix, "application/octet-stream"
        )
        return Response(storage.read(key), media_type=media_type)

    reference_root = REFERENCE_DIR.resolve()
    candidate = (reference_root / file_path).resolve()
    try:
        candidate.relative_to(reference_root)
    except ValueError as exc:
        raise HTTPException(400, "Invalid reference path") from exc
    if not candidate.is_file():
        raise HTTPException(404, "Reference image not found")

    media_types = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
    }
    return FileResponse(candidate, media_type=media_types.get(candidate.suffix.lower(), "application/octet-stream"))


@router.get("/api/xiao-hai/{pipeline_id}/bootstrap")
async def bootstrap_xiao_hai(pipeline_id: str):
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        # Pipeline 不存在时返回最小化响应（含品牌配置），而非 404
        company = get_company_config() or {}
        return {
            "pipeline_id": pipeline_id,
            "role": "",
            "company": company,
            "jd": {},
            "jd_ready": False,
            "fields": {},
            "poster": {"exists": False, "history": [], "selected_image_id": "", "status": "empty"},
            "references": _load_references(),
            "canvases": list(CANVAS_PRESETS.values()),
            "default_canvas_id": DEFAULT_CANVAS_ID,
            "default_director_prompt": "",
            "auto_generate_eligible": False,
            "has_usable_history": False,
        }

    stages = get_stages(pipeline_id)
    jd_stage = _find_stage(stages, "jd_write")
    poster_stage = _find_stage(stages, "poster_gen")
    jd_output = parse_stage_output(jd_stage)
    poster_output = parse_stage_output(poster_stage)

    jd = jd_output.get("jd") if isinstance(jd_output.get("jd"), dict) else jd_output
    poster_data = (
        poster_output.get("poster_data") if isinstance(poster_output.get("poster_data"), dict) else poster_output
    )

    company = get_company_config() or {}
    mapped = map_studio_fields(pipeline=pipeline, jd=jd, company=company, poster_data=poster_data)
    history = _poster_history(poster_output)
    usable = _usable_history(history)
    jd_ready = bool(mapped.get("jd_ready", False))
    fields = mapped.get("fields") or {}
    hr_user = resolve_pipeline_hr(pipeline)
    hr_email = (hr_user.get("hr_contact") or "").strip() if hr_user else ""
    if hr_email:
        fields["email"] = hr_email
    default_canvas_id = DEFAULT_CANVAS_ID
    default_director_prompt = build_default_director_prompt(fields, default_canvas_id)

    # 仅在 JD 就绪且没有可用历史记录时自动生成首张海报
    auto_generate_eligible = bool(jd_ready and not usable)

    versions = PosterService().list_versions(pipeline_id)
    selected_version = next((version for version in versions if version["status"] == "selected"), None)
    return {
        "pipeline_id": pipeline_id,
        "role": mapped.get("role") or pipeline.get("role") or "",
        "company": mapped.get("company") or {},
        "jd": jd or {},
        "jd_ready": jd_ready,
        "fields": fields,
        "poster": {
            "exists": bool(poster_stage),
            "history": history,
            "selected_image_id": poster_output.get("selected_image_id") or (usable[-1]["id"] if usable else ""),
            "selected_version_id": (selected_version or {}).get("id") or poster_output.get("selected_version_id", ""),
            "approval_status": "approved" if (selected_version or {}).get("approved_at") else "pending",
            "approved_version_id": (selected_version or {}).get("id")
            if (selected_version or {}).get("approved_at")
            else "",
            "status": poster_output.get("status") or ("completed" if history else "empty"),
            "template_id": poster_output.get("template_id") or "",
            "poster_html": poster_output.get("poster_html") or "",
            "variants": poster_output.get("variants") or {},
        },
        "versions": versions,
        "references": _load_references(),
        "canvases": list(CANVAS_PRESETS.values()),
        # v2 模板海报引擎
        "default_canvas_id": default_canvas_id,
        "default_director_prompt": default_director_prompt,
        "auto_generate_eligible": auto_generate_eligible,
        "has_usable_history": bool(usable),
    }


def _poster_http_error(error: PosterServiceError) -> HTTPException:
    return HTTPException(404 if "不存在" in str(error) else 400, str(error))


def _image_rate_limit_http_error() -> HTTPException:
    return HTTPException(
        status_code=429,
        detail="生图服务当前触发限流，请等待约 60 秒后再重试，不要连续点击生成。",
        headers={"Retry-After": "60"},
    )


@router.post("/api/xiao-hai/{pipeline_id}/assets")
async def upload_xiao_hai_asset(pipeline_id: str, file: UploadFile = File(...)):
    try:
        data = await file.read()
        asset = PosterService().create_image_asset(
            pipeline_id,
            data,
            filename=file.filename or "reference.png",
            kind="reference",
        )
        return {"asset": asset}
    except PosterServiceError as error:
        raise _poster_http_error(error) from error


@router.get("/api/xiao-hai/{pipeline_id}/assets/{asset_id}")
async def get_xiao_hai_asset(pipeline_id: str, asset_id: str):
    try:
        asset, data = await asyncio.to_thread(PosterService().read_asset, pipeline_id, asset_id)
        return Response(data, media_type=asset["mime_type"])
    except PosterServiceError as error:
        raise _poster_http_error(error) from error


@router.get("/api/xiao-hai/{pipeline_id}/versions")
async def list_xiao_hai_versions(pipeline_id: str):
    if not get_pipeline(pipeline_id):
        raise HTTPException(404, "pipeline not found")
    return {"versions": PosterService().list_versions(pipeline_id)}


@router.post("/api/xiao-hai/{pipeline_id}/versions/{version_id}/select")
async def select_xiao_hai_version(pipeline_id: str, version_id: str):
    try:
        return {"version": PosterService().select_version(pipeline_id, version_id)}
    except PosterServiceError as error:
        raise _poster_http_error(error) from error


@router.post("/api/xiao-hai/{pipeline_id}/versions/{version_id}/approve")
async def approve_xiao_hai_version(pipeline_id: str, version_id: str):
    try:
        version = PosterService().approve_version(pipeline_id, version_id)
        stages = get_stages(pipeline_id)
        poster_stage = _find_stage(stages, "poster_gen")
        poster_output = parse_stage_output(poster_stage)
        poster_output.update(
            {
                "status": "approved",
                "approval_status": "approved",
                "approved_version_id": version_id,
                "approved_at": version.get("approved_at"),
            }
        )
        if not poster_stage:
            create_stage(pipeline_id, "poster_gen", "招聘海报")
        update_stage(pipeline_id, "poster_gen", "done", poster_output)
        card = {"type": "poster_version", "data": version, "summary": "当前海报版本已确认"}
        save_message(
            pipeline_id,
            "assistant",
            "当前海报版本已确认",
            card_type="poster_card",
            card_data=card,
            stage_id="poster_gen",
        )
        await broadcast({"type": "poster_version_approved", "stage_id": "poster_gen", "version": version}, pipeline_id)
        return {"version": version}
    except PosterServiceError as error:
        raise _poster_http_error(error) from error


def _enqueue_workspace(pipeline_id: str, body: dict) -> dict:
    if not get_pipeline(pipeline_id):
        raise HTTPException(404, "pipeline not found")
    request_id = str(body.pop("client_request_id", "") or uuid.uuid4().hex)
    try:
        job, _ = create_workspace_job(pipeline_id, body, request_id)
    except PosterJobConflictError as exc:
        raise HTTPException(409, {"code": "poster_job_active", "message": str(exc), "job_id": exc.job_id}) from exc
    except (ValueError, PosterServiceError) as exc:
        raise HTTPException(422, str(exc)) from exc
    if job["status"] == "queued":
        schedule_job(job["id"])
    return job


@router.post("/api/xiao-hai/{pipeline_id}/jobs", status_code=202)
async def create_poster_job(pipeline_id: str, req: Request):
    body = await req.json()
    if not isinstance(body, dict) or not body.get("client_request_id"):
        raise HTTPException(422, "client_request_id is required")
    return {"job": public_job(_enqueue_workspace(pipeline_id, body))}


@router.get("/api/xiao-hai/{pipeline_id}/jobs")
async def list_poster_jobs(pipeline_id: str):
    if not get_pipeline(pipeline_id):
        raise HTTPException(404, "pipeline not found")
    return {"jobs": await asyncio.to_thread(list_pipeline_jobs, pipeline_id)}


@router.get("/api/xiao-hai/{pipeline_id}/jobs/{job_id}")
async def get_poster_job(pipeline_id: str, job_id: str):
    from app.poster_progress import expire_jobs

    await asyncio.to_thread(expire_jobs)
    job = get_job(job_id)
    if not job or job["pipeline_id"] != pipeline_id:
        generation = get_generation_job_by_id(job_id)
        if generation and generation["pipeline_id"] == pipeline_id:
            return {"job": public_generation_job(generation)}
        raise HTTPException(404, "生成任务不存在")
    return {"job": public_job(job)}


@router.post("/api/xiao-hai/{pipeline_id}/generate", status_code=202)
async def generate_xiao_hai(pipeline_id: str, req: Request):
    body = await req.json()
    if not isinstance(body, dict):
        raise HTTPException(422, "payload must be a JSON object")
    if not get_pipeline(pipeline_id):
        raise HTTPException(404, "pipeline not found")
    request_id = str(body.get("client_request_id") or req.headers.get("X-Client-Request-ID") or "").strip()
    job, _ = await asyncio.to_thread(create_generation_job, pipeline_id, request_id, body)
    if job.get("status") == "queued":
        schedule_generation_job(job["id"])
    return {"job": job, "job_id": job["id"]}


def _mark_poster_timeout(pipeline_id: str, deadline: TimeoutDeadline) -> None:
    stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "poster_gen"), None)
    if not stage:
        create_stage(pipeline_id, "poster_gen", "招聘海报")
    update_stage(
        pipeline_id,
        "poster_gen",
        "failed",
        {"error": "backend_timeout", "timeout_seconds": deadline.timeout_seconds},
    )


def _read_material_entry(entry_id: str, pool: dict, kind: str) -> tuple[dict, bytes]:
    if not entry_id or ".." in entry_id or "/" in entry_id or "\\" in entry_id:
        raise HTTPException(400, f"invalid {kind} id")
    entry = pool.get(entry_id)
    if not entry:
        raise HTTPException(404, f"unknown {kind} id: {entry_id}")
    storage = get_media_storage()
    filename = entry.get("file") or ""
    if _is_oss(storage):
        key = entry.get("storage_key") or _element_key(kind, filename)
        if not storage.exists(key):
            raise HTTPException(404, f"{kind} file not found: {filename}")
        return entry, storage.read(key)
    path = ELEMENT_LIBRARY_DIR / kind / filename
    if not path.is_file():
        raise HTTPException(404, f"{kind} file not found: {filename}")
    return entry, path.read_bytes()


def _read_library_background(library_image: dict | None, canvas_id: str) -> bytes | None:
    if not library_image:
        return None
    canvas_folder = CANVAS_ID_TO_FOLDER.get(library_image.get("canvas_folder") or canvas_id, canvas_id)
    filename = str(library_image.get("filename") or "auto")
    if any(part in value for value in (canvas_folder, filename) for part in ("..", "/", "\\")):
        raise HTTPException(400, "invalid library image")
    storage = get_media_storage()
    if _is_oss(storage):
        prefix = join_storage_key(OSS_CANVAS_PREFIX, canvas_folder, "library") + "/"
        keys = sorted(
            key for key in storage.list_keys(prefix) if Path(key).suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}
        )
        key = keys[0] if filename == "auto" and keys else _canvas_library_key(canvas_folder, filename)
        if not key or not storage.exists(key):
            raise HTTPException(404, "library image not found")
        return storage.read(key)
    directory = CANVAS_LIBRARY_DIR / canvas_folder / "library"
    candidates = sorted(
        path for path in directory.glob("*") if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}
    )
    path = candidates[0] if filename == "auto" and candidates else directory / filename
    if not path.is_file():
        raise HTTPException(404, "library image not found")
    return path.read_bytes()


def _version_raw_asset_id(version: dict) -> str:
    render_data = version.get("render_data") or {}
    return str(render_data.get("raw_image_asset_id") or version.get("image_asset_id") or "")


def _prepare_reference_materials(
    *,
    service: PosterService,
    pipeline_id: str,
    canvas_id: str,
    base_version_id: str,
    reference_asset_ids: list[str],
    reference_id: str,
    reference_data_url: str | None,
    background_element_id: str,
    element_ids: list[str],
    library_image: dict | None,
    use_default_materials: bool,
    use_base_image: bool,
) -> tuple[bytes | None, list[bytes], str, str]:
    manifest = _load_element_manifest()
    backgrounds = {item["id"]: item for item in manifest.get("backgrounds") or []}
    elements = {item["id"]: item for item in manifest.get("elements") or []}
    if len(element_ids) > 2:
        raise HTTPException(400, "装饰元素最多选择 2 个")

    labels: list[str] = []
    parent_version_id = ""
    base_raw = None
    if base_version_id:
        version = service.get_version(pipeline_id, base_version_id)
        parent_version_id = version["id"]
        if use_base_image:
            raw_asset_id = _version_raw_asset_id(version)
            if not raw_asset_id:
                raise PosterServiceError("基础版本没有可编辑原图")
            _, base_raw = service.read_asset(pipeline_id, raw_asset_id)
            base_raw = body_reference(base_raw, version)
            labels.append("基础：当前海报，保留原有视觉语言")
        else:
            labels.append("生成：仅使用原始素材与提示词重新绘制")

    background_bytes = None
    if background_element_id:
        entry, background_bytes = _read_material_entry(background_element_id, backgrounds, "backgrounds")
        labels.append(f"背景：{entry.get('label') or background_element_id}")
    library_background = _read_library_background(library_image, canvas_id)
    explicit_background = bool(background_bytes or library_background)
    background_bytes = background_bytes or library_background
    if background_bytes is None and use_default_materials:
        labels.append("背景：使用品牌默认底图")
    background_bytes = background_bytes or base_raw

    selected_elements: list[bytes] = []
    for element_id in element_ids:
        entry, data = _read_material_entry(element_id, elements, "elements")
        selected_elements.append(data)
        labels.append(f"元素：{entry.get('label') or element_id}")
    if not selected_elements:
        for asset_id in reference_asset_ids[:3]:
            _, data = service.read_asset(pipeline_id, asset_id)
            selected_elements.append(data)
        legacy_reference = _load_reference_bytes(reference_id, reference_data_url)
        if legacy_reference and len(selected_elements) < 3:
            selected_elements.append(legacy_reference)
        if not selected_elements and (base_raw is None or explicit_background or use_default_materials):
            selected_elements.append(read_default_element())
            labels.append("元素：默认锅圈品牌 IP")
    return background_bytes, selected_elements, parent_version_id, "；".join(labels)


async def _call_unified_image_edit(
    *,
    prompt: str,
    reference_board: bytes,
    canvas: dict,
    deadline: TimeoutDeadline | None,
) -> bytes:
    try:
        started = time.monotonic()
        raw_bytes = await asyncio.to_thread(
            call_image_generate,
            prompt=prompt,
            width=canvas["width"],
            height=canvas["height"],
            model="gpt-image-2",
            timeout=180,
            reference_image_bytes=reference_board,
            canvas_id=canvas["id"],
            use_edit_endpoint=True,
            force_gpt_image2=True,
            deadline=deadline,
            body_only=bool(canvas.get("body_only")),
        )
        logger.info(
            "[Generate] unified image edit done elapsed=%.1fs bytes=%d", time.monotonic() - started, len(raw_bytes)
        )
        return raw_bytes
    except ImageGenerationRateLimitError as exc:
        raise _image_rate_limit_http_error() from exc
    except RuntimeError as exc:
        raise HTTPException(502, str(exc)) from exc


def _create_unified_version(
    *,
    service: PosterService,
    pipeline_id: str,
    raw_bytes: bytes,
    final_bytes: bytes,
    canvas: dict,
    parent_version_id: str,
    reference_asset_ids: list[str],
    reference_usage: str,
    fields: dict,
    instruction: str,
    background_element_id: str,
    element_ids: list[str],
    composition_metadata: dict | None = None,
    raw_asset: dict | None = None,
    job_id: str | None = None,
    prompt: str = "",
    reference_id: str = "",
) -> tuple[dict, dict, dict]:
    raw_asset = raw_asset or service.create_image_asset(
        pipeline_id,
        raw_bytes,
        filename=f"{pipeline_id}-model-output.png",
        kind="model_output",
    )
    image_asset = service.create_image_asset(
        pipeline_id,
        final_bytes,
        filename=f"{pipeline_id}-poster.png",
        kind="generated",
    )
    version = service.create_version(
        pipeline_id,
        image_asset_id=image_asset["id"],
        canvas_id=canvas["id"],
        parent_version_id=parent_version_id,
        reference_asset_ids=reference_asset_ids,
        reference_usage=reference_usage,
        fields=fields,
        instruction=instruction,
        source=(
            "image_generation"
            if not parent_version_id or (composition_metadata or {}).get("generation_mode") == "fresh"
            else "image_edit"
        ),
        generation_job_id=job_id,
        on_saved=lambda conn, saved: _persist_unified_generation_result(pipeline_id, saved, conn=conn),
        provider="gpt-image-2",
        model="gpt-image-2",
        render_data={
            "mode": "image2_edits_full_poster",
            "generation_job_id": job_id,
            "raw_image_asset_id": raw_asset["id"],
            "background_asset_id": raw_asset["id"],
            "background_element_id": background_element_id,
            "element_ids": element_ids,
            "text_rendered": True,
            "text_rendered_by_model": True,
            "brand_overlays": ["company_logo", "hr_qr_code"],
            "stock_code_rendered_by_model": True,
            "logo_reference_used": True,
            "brand_layout_version": LAYOUT_VERSION,
            "qr_mode": "hr_qr",
            "generation_response": _generation_response(
                canvas, fields, prompt, image_asset, raw_asset, reference_id, background_element_id, element_ids
            ),
            **(composition_metadata or {}),
        },
    )
    return raw_asset, image_asset, version


async def _run_unified_generation(
    pipeline_id: str,
    req: Request,
    deadline: TimeoutDeadline | None,
) -> dict:
    return await _generate_from_payload(pipeline_id, await req.json(), deadline)


_PHASE_PROGRESS = {
    "preparing": (10, "preparing"),
    "refining": (25, "refining"),
    "generating": (38, "generating"),
    "composing": (84, "composing"),
    "saving": (95, "saving"),
}


async def _run_unified_generation_payload(
    pipeline_id: str, payload: dict, *, deadline: TimeoutDeadline, progress_callback=None
) -> dict:
    """Worker entrypoint used by the persisted xiao_hai_generation_jobs queue."""
    return await _generate_from_payload(pipeline_id, payload, deadline, progress_callback=progress_callback)


async def _generate_from_payload(
    pipeline_id: str, body: dict, deadline, *, job_id: str | None = None, progress_callback=None
) -> dict:
    def on_phase(phase: str):
        if job_id:
            set_phase(job_id, phase)
        if progress_callback:
            progress, stage = _PHASE_PROGRESS.get(phase, (50, phase))
            progress_callback(progress, stage)

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "pipeline not found")
    on_phase("preparing")
    fields = _backfill_fields_from_pipeline(pipeline_id, body.get("fields") or {})
    try:
        hr_user = require_pipeline_hr(pipeline)
    except PipelineHrNotConfiguredError as exc:
        raise HTTPException(422, f"{exc}，请先到「用户与权限」配置后重试。") from exc
    fields["email"] = (hr_user.get("hr_contact") or "").strip()
    canvas_body = body.get("canvas") or {}
    canvas_id = canvas_body.get("id") or body.get("canvas_id") or DEFAULT_CANVAS_ID
    canvas = dict(get_canvas_preset(canvas_id))
    # 客户端可指定目标画幅（缩放预设布局），响应与输出尺寸需与之一致
    if canvas_body.get("width"):
        canvas["width"] = int(canvas_body["width"])
    if canvas_body.get("height"):
        canvas["height"] = int(canvas_body["height"])
    reference_asset_ids = [str(asset_id) for asset_id in body.get("reference_asset_ids") or [] if asset_id]
    element_ids = body.get("element_ids") or []
    element_ids = [element_ids] if isinstance(element_ids, str) else [str(item) for item in element_ids if item]
    background_element_id = str(body.get("background_element_id") or "")
    library_image = body.get("library_image") if isinstance(body.get("library_image"), dict) else None
    generation_mode = str(body.get("generation_mode") or "edit")
    if generation_mode not in {"fresh", "edit"}:
        raise HTTPException(422, "generation_mode must be fresh or edit")
    service = PosterService()

    try:
        brand_result, material_result = await asyncio.gather(
            asyncio.to_thread(load_company_brand_assets, hr_brand_config(get_company_config() or {}, hr_user)),
            asyncio.to_thread(
                _prepare_reference_materials,
                service=service,
                pipeline_id=pipeline_id,
                canvas_id=canvas_id,
                base_version_id=str(body.get("base_version_id") or ""),
                reference_asset_ids=reference_asset_ids,
                reference_id=str(body.get("reference_id") or ""),
                reference_data_url=body.get("reference_data_url"),
                background_element_id=background_element_id,
                element_ids=element_ids,
                library_image=library_image,
                use_default_materials=bool(body.get("use_default_materials")),
                use_base_image=generation_mode == "edit",
            ),
        )
        brand_assets = brand_result
        background_bytes, elements, parent_version_id, reference_context = material_result
    except PosterBrandingError as exc:
        raise HTTPException(422, f"品牌素材预检失败：{exc}") from exc
    except PosterServiceError as exc:
        raise _poster_http_error(exc) from exc

    protected_fields = {
        "jobTitle",
        "title",
        "companyName",
        "company_name",
        "salary",
        "location",
        "deliveryLink",
        "delivery_link",
        "qr_code",
        "hr_qr_code",
        "email",
        "contactText",
        "contact_text",
    }
    protected_fields.update(str(key) for key in body.get("protected_field_keys") or [] if key)
    on_phase("refining")
    fields = await refine_poster_fields_llm(
        fields,
        canvas_id,
        protected_fields=protected_fields,
        jd=load_pipeline_jd(pipeline_id),
        deadline=deadline,
    )
    try:
        composition = await asyncio.to_thread(
            prepare_composition,
            brand_assets,
            canvas_id,
            fields,
            width=canvas["width"],
            height=canvas["height"],
        )
        snapshot_metadata = await asyncio.to_thread(save_brand_snapshots, service, pipeline_id, brand_assets)
    except PosterBrandingError as exc:
        raise HTTPException(422, f"投递区预检失败：{exc}") from exc
    layout = composition.layout
    user_instruction = str(body.get("instruction") or "").strip()
    if str(body.get("operation") or "") == "text" and parent_version_id:
        instruction = (
            "Only update the recruitment copy to the supplied exact text. Preserve the current poster's visual style, "
            f"mascot, composition and color system as closely as possible. {user_instruction}"
        ).strip()
    else:
        instruction = user_instruction or build_default_director_prompt(fields, canvas_id)
    selected_background = bool(background_element_id or library_image)
    operation = str(body.get("operation") or "")
    lock_existing_background = bool(parent_version_id and operation == "text" and not selected_background)
    reference_background_bytes = background_bytes
    if background_bytes and not lock_existing_background:
        reference_background_bytes = await asyncio.to_thread(blur_material_reference, background_bytes)
    reference_board = await asyncio.to_thread(
        build_element_board,
        elements,
        background_bytes=reference_background_bytes,
        size=(layout.body.w, layout.body.h),
        logo_bytes=brand_assets.logo_bytes,
        canvas_id=canvas_id,
        body_layout=layout,
    )
    prompt = build_full_poster_prompt(
        fields=fields,
        canvas=canvas,
        instruction=instruction,
        has_ip_image=bool(elements or parent_version_id),
        reference_context=reference_context
        or (
            "No legacy master is supplied. Create a restrained Guoquan brand visual system with a warm neutral base "
            "and green/orange accents."
        ),
        body_layout=layout,
    )
    try:
        raw_bytes, final_bytes, raw_asset, composition_metadata = await asyncio.to_thread(
            render_poster,
            prompt=prompt,
            reference_board=reference_board,
            composition=composition,
            generate=lambda **kwargs: asyncio.run(_call_unified_image_edit(**kwargs, deadline=deadline)),
            save_raw=lambda raw: service.create_image_asset(
                pipeline_id, raw, filename=f"{pipeline_id}-model-output.png", kind="model_output"
            ),
            compose=compose_poster_body,
            on_phase=on_phase,
        )
    except PosterBrandingError as exc:
        raise HTTPException(422, f"海报合成校验失败：{exc}") from exc
    raw_asset, image_asset, version = _create_unified_version(
        service=service,
        pipeline_id=pipeline_id,
        raw_bytes=raw_bytes,
        final_bytes=final_bytes,
        canvas=canvas,
        parent_version_id=parent_version_id,
        reference_asset_ids=reference_asset_ids,
        reference_usage=str(body.get("reference_usage") or ""),
        fields=fields,
        instruction=instruction,
        background_element_id=background_element_id,
        element_ids=element_ids,
        composition_metadata={
            **composition_metadata,
            **snapshot_metadata,
            "generation_mode": generation_mode,
        },
        raw_asset=raw_asset,
        job_id=job_id,
        prompt=prompt,
        reference_id=str(body.get("reference_id") or ""),
    )
    return await _write_unified_generation_result(
        pipeline_id=pipeline_id,
        canvas=canvas,
        fields=fields,
        prompt=prompt,
        image_asset=image_asset,
        raw_asset=raw_asset,
        version=version,
        reference_id=str(body.get("reference_id") or ""),
        background_element_id=str(body.get("background_element_id") or ""),
        element_ids=element_ids,
    )


def _generation_response(
    canvas, fields, prompt, image_asset, raw_asset, reference_id, background_element_id, element_ids
):
    poster_id = f"img_{image_asset['id'].removeprefix('asset_')[:12]}"
    return {
        "id": poster_id,
        "url": f"{image_asset['url']}?filename={poster_id}.png",
        "width": canvas["width"],
        "height": canvas["height"],
        "canvas_id": canvas["id"],
        "reference_id": reference_id,
        "model": "gpt-image-2",
        "created_at": _utc_now(),
        "qr_mode": "hr_qr",
        "prompt_summary": prompt[:240],
        "mode": "image2_edits_full_poster",
        "background_element_id": background_element_id,
        "element_ids": element_ids,
        "raw_image_asset_id": raw_asset["id"],
        "fields": fields,
    }


async def _write_unified_generation_result(
    *,
    pipeline_id: str,
    canvas: dict,
    fields: dict,
    prompt: str,
    image_asset: dict,
    raw_asset: dict,
    version: dict,
    reference_id: str,
    background_element_id: str,
    element_ids: list[str],
) -> dict:
    item = (version.get("render_data") or {}).get("generation_response") or _generation_response(
        canvas, fields, prompt, image_asset, raw_asset, reference_id, background_element_id, element_ids
    )
    if not (version.get("render_data") or {}).get("generation_job_id"):
        _persist_unified_generation_result(pipeline_id, version, item=item)
    writeback = parse_stage_output(_find_stage(get_stages(pipeline_id), "poster_gen"))
    await broadcast(
        {"type": "stage_card", "stage_id": "poster_gen", "card": {"type": "poster_card", "data": writeback}},
        pipeline_id,
    )
    save_message(pipeline_id, "assistant", "招聘海报已生成", card_type="poster_card", card_data=writeback)
    return {
        **item,
        "version_id": version["id"],
        "parent_version_id": version.get("parent_version_id") or "",
        "image_asset_id": image_asset["id"],
        "image_url": image_asset["url"],
    }


def _persist_unified_generation_result(pipeline_id: str, version: dict, *, conn=None, item=None) -> None:
    item = item or version["render_data"]["generation_response"]
    fields = item["fields"]
    stages = get_stages(pipeline_id)
    poster_stage = _find_stage(stages, "poster_gen")
    poster_output = parse_stage_output(poster_stage)
    history = (_poster_history(poster_output) + [item])[-20:]
    writeback = {
        "status": "generated",
        "approval_status": "pending",
        "template_id": "guoquan_image_studio",
        "poster_data": {
            "title": fields.get("jobTitle") or "",
            "salary": fields.get("salary") or "",
            "location": fields.get("location") or "",
            "company_name": fields.get("companyName") or "",
            "responsibilities": fields.get("responsibilities") or [],
            "requirements": fields.get("requirements") or [],
            "highlights": fields.get("highlights") or [],
            "benefits": fields.get("benefits") or [],
            "career_growth": fields.get("career_growth") or fields.get("careerGrowth") or "",
            "image_url": item["url"],
            "canvas": {"id": item["canvas_id"], "width": item["width"], "height": item["height"]},
            "reference_id": item["reference_id"],
            "qr_mode": "hr_qr",
        },
        "history": history,
        "selected_image_id": item["id"],
        "selected_version_id": version["id"],
    }
    if not poster_stage:
        create_stage(pipeline_id, "poster_gen", "招聘海报", conn=conn)
    update_stage(pipeline_id, "poster_gen", "waiting_human", writeback, conn=conn)
    PosterService().select_version(pipeline_id, version["id"], conn=conn)


@router.get("/api/xiao-hai/artifacts/{artifact_id}.png")
async def get_xiao_hai_artifact(artifact_id: str):
    artifact_id = artifact_id.replace(".png", "")
    if not SAFE_ID_RE.match(artifact_id):
        raise HTTPException(400, "invalid artifact id")
    storage = get_media_storage()
    storage_key = join_storage_key(OSS_ARTIFACT_PREFIX, f"{artifact_id}.png")
    if _is_oss(storage) and storage.exists(storage_key):
        return RedirectResponse(storage.sign_url(storage_key), status_code=307)
    path = ARTIFACT_DIR / f"{artifact_id}.png"
    if not path.exists():
        raise HTTPException(404, "artifact not found")
    return FileResponse(path, media_type="image/png", filename=f"{artifact_id}.png")


@router.post("/api/xiao-hai/{pipeline_id}/jobs/{job_id}/cancel")
async def cancel_poster_generation(pipeline_id: str, job_id: str):
    """取消正在排队或执行中的海报生成任务。"""
    from app.poster_jobs import cancel_generation_job

    if not SAFE_ID_RE.match(pipeline_id):
        raise HTTPException(400, "invalid pipeline_id")
    if not job_id.startswith("poster_job_"):
        raise HTTPException(400, "invalid job_id")

    ok = cancel_generation_job(job_id, pipeline_id)
    if not ok:
        raise HTTPException(404, "任务不存在或已结束，无法取消")
    return {"status": get_job(job_id)["status"], "job_id": job_id}
