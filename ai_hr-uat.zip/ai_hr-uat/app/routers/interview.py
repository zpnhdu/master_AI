"""Interview-related routes — questions, save, ASR, evaluate, and copilot."""

import asyncio
import json
import os
import time

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from starlette.responses import JSONResponse

from app import assessment_flow, services, state
from app.access_control import require_pipeline_access, require_pipeline_path_access
from app.db import (
    get_candidates,
    get_pipeline,
    get_stages,
    save_message,
    update_stage,
)
from app.infrastructure.health import check_health
from app.models.schemas import (
    AssessmentRequest,
    InterviewAnswerRequest,
    QuizRequest,
)
from app.state import broadcast
from app.utils import parse_stage_output
from hr_harness.memory.core import MemorySystem

ASR_MAX_AUDIO_BYTES = 10 * 1024 * 1024

router = APIRouter(tags=["interview"], dependencies=[Depends(require_pipeline_path_access)])


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def get_memory(pipeline_id: str = "") -> MemorySystem:
    """Get memory system scoped to a pipeline"""
    return MemorySystem(pipeline_id)


# ---------------------------------------------------------------------------
# Pydantic 模型（面试路由专用，与 main.py 定义保持一致）
# ---------------------------------------------------------------------------


class SubmitAnswersRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    candidate_name: str = ""
    answers: list  # [{问题序号: int, 回答文本: str}]


class ReevaluateRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    candidate_name: str = ""


class QuickEvaluateRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    question_index: int
    question: str
    expected_points: list = []
    answer: str
    jd_role: str = ""


# ============ 面试问题 ============


@router.get("/api/interview/{pipeline_id}/questions")
async def get_interview_questions(pipeline_id: str, candidate_id: str = ""):
    """获取面试题目 — 从 stages 表读取已有面试题，或用 LLM 重新生成"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    # context 在数据库中是 JSON 字符串，需要解析
    context = {}
    if pipeline.get("context"):
        try:
            context = json.loads(pipeline["context"])
        except (json.JSONDecodeError, TypeError):
            context = {}

    role = context.get("role", "工程师")

    # 优先从 stages 表的 interview_gen 阶段读取面试题
    stages = get_stages(pipeline_id)
    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)

    candidate_questions = None
    if interview_stage and interview_stage.get("output"):
        try:
            stage_output = parse_stage_output(interview_stage)
            # 防御性检查：确保 stage_output 为字典且 interviews 为列表
            if not isinstance(stage_output, dict):
                stage_output = {}
            interviews = stage_output.get("interviews", [])
            if not isinstance(interviews, list):
                interviews = []
            for iv in interviews:
                if isinstance(iv, dict):
                    if iv.get("candidate_id") == candidate_id:
                        candidate_questions = iv.get("questions", [])
                        break
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

    # 未找到则用 LLM 重新生成
    if not candidate_questions:
        from hr_harness.agents.interview_agent import InterviewAgent

        agent = InterviewAgent()

        # 从 candidates 表获取候选人信息
        candidates = get_candidates(pipeline_id)
        candidate_info = next((c for c in candidates if c.get("id") == candidate_id), None)

        # 从 stages 表获取 JD
        jd = context.get("jd", {})
        jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
        if jd_stage:
            parsed_jd = parse_stage_output(jd_stage)
            jd = parsed_jd.get("jd", jd)

        gen_context = {
            "candidates": [candidate_info]
            if candidate_info
            else [{"id": candidate_id, "name": candidate_id, "overall_score": 80}],
            "jd": jd,
            "role": role,
            "pipeline_id": pipeline_id,
        }
        try:
            result = await agent.execute(gen_context)
            gen_interviews = result.get("interviews", [])
            if gen_interviews:
                candidate_questions = gen_interviews[0].get("questions", [])
        except Exception as e:
            from app.audit.logger import get_logger

            logger = get_logger("main")
            logger.warning(f"生成面试题失败: {e}")
            candidate_questions = []

    # 兜底默认题
    if not candidate_questions:
        candidate_questions = [
            {"type": "自我介绍", "question": "请做一个简短的自我介绍。", "duration": "5分钟", "difficulty": "简单"},
            {
                "type": "项目经验",
                "question": "请描述一个你最有成就感的项目。",
                "duration": "10分钟",
                "difficulty": "中等",
            },
            {
                "type": "技术深度",
                "question": f"请谈谈你在{role}领域的核心技术能力。",
                "duration": "10分钟",
                "difficulty": "中等",
            },
        ]

    role_type = (
        "technical"
        if any("技术" in (q.get("type", "")) or "笔试" in (q.get("type", "")) for q in candidate_questions)
        else "general"
    )
    interviewer_role = "资深技术面试官" if role_type == "technical" else "资深面试官"

    return {
        "questions": candidate_questions,
        "interviewer_role": interviewer_role,
        "jd_role": role,
        "candidate_id": candidate_id,
    }


# ============ 保存面试记录 ============


@router.post("/api/interview/{pipeline_id}/save")
async def save_interview_record(pipeline_id: str, req: Request):
    """保存面试记录 — 存文件 + 推送消息到 HR 系统"""
    body = await req.json()
    candidate_id = body.get("candidate_id", "unknown")
    candidate_name = body.get("candidate_name", "候选人")
    markdown = body.get("markdown", "")
    transcript = body.get("transcript", [])
    duration_seconds = body.get("duration_seconds", 0)
    questions_count = body.get("questions_count", 0)

    if not markdown:
        raise HTTPException(400, "markdown is required")

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    # 1. 保存 MD 文件
    interview_dir = os.path.join("data", pipeline_id, "interviews")
    os.makedirs(interview_dir, exist_ok=True)

    ts = int(time.time())
    filename = f"interview_{candidate_id}_{ts}.md"
    filepath = os.path.join(interview_dir, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(markdown)

    from app.audit.logger import get_logger

    logger = get_logger("main")
    logger.info(f"面试记录已保存: {filepath}", extra={"source": "interview"})

    # 2. 保存消息到 DB（HR 系统可查看）
    card_data = {
        "candidate_id": candidate_id,
        "candidate_name": candidate_name,
        "file": filename,
        "path": filepath,
        "duration_seconds": duration_seconds,
        "questions_count": questions_count,
        "transcript": transcript,
        "markdown": markdown,
        "timestamp": ts,
    }
    save_message(
        pipeline_id,
        "system",
        f"🎯 {candidate_name} 面试完成（{questions_count}题，{duration_seconds // 60}分钟）",
        card_type="interview_record_card",
        card_data=card_data,
    )

    # 3. WebSocket 广播到 HR 系统
    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "interview_record",
            "card": {
                "type": "interview_record_card",
                "data": card_data,
                "summary": f"{candidate_name} 面试完成",
            },
        },
        pipeline_id=pipeline_id,
    )

    return {
        "status": "ok",
        "file": filename,
        "path": filepath,
        "duration_seconds": duration_seconds,
        "questions_count": questions_count,
    }


# ============ 面试 ASR ============


@router.post("/api/interview/asr")
async def interview_asr(req: Request):
    """实时语音转文字 — 使用 Qwen3-ASR-Flash 模型"""
    from app.multimodal import transcribe_audio

    try:
        form = await req.form()
        audio_file = form.get("audio")
        if not audio_file:
            raise HTTPException(400, "缺少音频文件")

        audio_data = await audio_file.read()
        if not audio_data or len(audio_data) < 100:
            return {"text": ""}
        if len(audio_data) > ASR_MAX_AUDIO_BYTES:
            raise HTTPException(413, "音频文件过大，请控制在 60 秒以内")

        filename = audio_file.filename or "audio.webm"
        text = await asyncio.to_thread(transcribe_audio, filename, audio_data, model="qwen3-asr-flash")

        if text.startswith("[转录失败"):
            from app.audit.logger import get_logger

            logger = get_logger("main")
            logger.warning(f"ASR failed: {text}", extra={"source": "interview"})
            return {"text": "", "error": text}

        return {"text": text}
    except HTTPException:
        raise
    except Exception as e:
        from app.audit.logger import get_logger

        logger = get_logger("main")
        logger.error(f"ASR error: {e}", extra={"source": "interview"})
        return {"text": "", "error": "语音识别服务暂时不可用"}


# ============ 评估面试 ============


@router.post("/api/interview/{pipeline_id}/evaluate")
async def evaluate_interview_record(pipeline_id: str, req: Request):
    """AI 评估面试记录 — 读取面试 MD，用 LLM 生成评估"""
    body = await req.json()
    candidate_id = body.get("candidate_id", "")
    candidate_name = body.get("candidate_name", "候选人")
    markdown = body.get("markdown", "")
    filepath = body.get("filepath", "")

    # 如果没传 markdown，从文件读取
    if not markdown and filepath and os.path.exists(filepath):
        with open(filepath, encoding="utf-8") as f:
            markdown = f.read()

    if not markdown:
        raise HTTPException(400, "面试记录内容为空")

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    stages = get_stages(pipeline_id)

    # 解析 context 获取岗位信息
    context = {}
    if pipeline.get("context"):
        try:
            context = json.loads(pipeline["context"])
        except (json.JSONDecodeError, TypeError):
            pass

    role = context.get("role", "工程师")
    jd = context.get("jd", {})

    # 从 stages 表获取 JD（优先级更高）
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_parsed = parse_stage_output(jd_stage)
    jd = jd_parsed.get("jd", jd)

    jd_text = ""
    if isinstance(jd, dict):
        jd_text = jd.get("title", "") + "\n" + jd.get("description", "") + "\n" + "\n".join(jd.get("requirements", []))
    elif isinstance(jd, str):
        jd_text = jd

    # 用 LLM 评估
    from hermes_wrapper.client import get_client
    from hermes_wrapper.models import LLMRequest

    client = get_client()
    system = """你是一个资深HR面试评估专家。请根据面试问答记录，对候选人的表现进行全面评估。

评估维度：
1. 专业能力（30%）：回答的技术深度和准确性
2. 沟通表达（25%）：表达清晰度、逻辑性
3. 问题解决（20%）：分析和解决问题的思路
4. 项目经验（15%）：经验的丰富度和成果
5. 文化匹配（10%）：态度和价值观

请输出JSON格式：
{
    "overall_score": 0-100,
    "recommendation": "强烈推荐/推荐/建议复试/待定/不推荐",
    "dimensions": [
        {"name": "专业能力", "score": 0-100, "comment": "评价"},
        {"name": "沟通表达", "score": 0-100, "comment": "评价"},
        {"name": "问题解决", "score": 0-100, "comment": "评价"},
        {"name": "项目经验", "score": 0-100, "comment": "评价"},
        {"name": "文化匹配", "score": 0-100, "comment": "评价"}
    ],
    "highlights": ["亮点1", "亮点2"],
    "concerns": ["担忧1", "担忧2"],
    "summary": "50字总结评价",
    "next_step": "建议的下一步行动"
}"""

    prompt = f"""岗位：{role}
候选人：{candidate_name}

岗位JD：
{jd_text[:2000]}

面试记录：
{markdown[:5000]}

请对候选人的面试表现进行评估。"""

    llm_req = LLMRequest(prompt=prompt, system=system, complexity="max")
    resp = await client.chat_json(llm_req)

    if not resp or not isinstance(resp, dict):
        resp = {
            "overall_score": 0,
            "recommendation": "评估失败",
            "summary": "LLM 评估未返回有效结果，请重试",
            "dimensions": [],
            "highlights": [],
            "concerns": [],
            "next_step": "请重新评估",
        }

    resp["candidate_id"] = candidate_id
    resp["candidate_name"] = candidate_name

    # 保存评估结果到消息
    save_message(
        pipeline_id,
        "system",
        f"📊 {candidate_name} AI面试评估：{resp.get('overall_score', 0)}分 - {resp.get('recommendation', '')}",
        card_type="interview_eval_card",
        card_data=resp,
    )

    # WebSocket 广播
    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "interview_eval",
            "card": {
                "type": "interview_eval_card",
                "data": resp,
                "summary": f"{candidate_name} AI评估：{resp.get('overall_score', 0)}分",
            },
        },
        pipeline_id=pipeline_id,
    )

    return resp


# ============ 笔试题 ============


@router.post("/api/generate-quiz-questions")
async def generate_quiz_questions(req: QuizRequest):
    """Generate 5 contextual Q&A questions for precise JD generation."""
    from hr_harness.agents.quiz_agent import QuizAgent

    agent = QuizAgent()
    if req.mock:
        # 模拟模式：不调用 LLM，直接返回后备问题
        questions = agent._generate_fallback(req.role, req.hints)
    else:
        questions = await agent.generate_questions(req.role, req.hints)
    return {"questions": questions, "quiz_id": f"quiz_{req.role}_{int(time.time())}"}


# ============ 健康检查 ============


@router.get("/api/health")
async def health():
    result = check_health()
    result.update(
        {
            "service": "锅圈食汇",
            "version": "2.0.0",
            "memory": get_memory().get_optimization_summary(),
        }
    )
    return result


@router.get("/api/health/live")
async def health_live():
    return {"status": "ok", "service": "锅圈食汇", "version": "2.0.0"}


@router.get("/api/health/ready")
async def health_ready():
    result = check_health(ready=True)
    if not result["ready"]:
        return JSONResponse(status_code=503, content=result)
    return result


# ============ 面试回答与重新评估 API ============


@router.post("/api/interviews/submit-answers")
async def api_submit_answers(req: SubmitAnswersRequest, request: Request):
    """Submit answers for a candidate's interview questions and get AI evaluation"""
    require_pipeline_access(request, req.pipeline_id)
    result = await state.get_action_handler().handle_action(
        req.pipeline_id,
        "submit_answers",
        {"candidate_id": req.candidate_id, "candidate_name": req.candidate_name, "answers": req.answers},
    )
    return result


@router.post("/api/interviews/reevaluate")
async def api_reevaluate(req: ReevaluateRequest, request: Request):
    """Re-evaluate a candidate (re-run report with latest assessment data)"""
    require_pipeline_access(request, req.pipeline_id)
    result = await state.get_action_handler().handle_action(
        req.pipeline_id, "reevaluate", {"candidate_id": req.candidate_id, "candidate_name": req.candidate_name}
    )
    return result


@router.post("/api/interviews/quick-evaluate")
async def api_quick_evaluate(req: QuickEvaluateRequest, request: Request):
    """快速评估单个面试问题的回答"""
    require_pipeline_access(request, req.pipeline_id)
    if not req.answer or not req.answer.strip():
        raise HTTPException(422, "答案不能为空")
    handler = state.get_action_handler()
    result = await handler.quick_evaluate(
        pipeline_id=req.pipeline_id,
        candidate_id=req.candidate_id,
        question_index=req.question_index,
        question=req.question,
        expected_points=req.expected_points,
        answer=req.answer,
        jd_role=req.jd_role,
    )
    return result


# ============ 保存面试回答 ============


@router.post("/api/pipelines/{pipeline_id}/interview-answers")
async def api_save_interview_answers(pipeline_id: str, req: InterviewAnswerRequest):
    """Save interview answers for a candidate"""
    stages = get_stages(pipeline_id)
    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    if not interview_stage:
        raise HTTPException(404, "面试阶段不存在")
    try:
        assessment_flow.ensure_single_step_plan(pipeline_id, "manual_interview", actor_id="manual_interview")
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    stage_output = parse_stage_output(interview_stage)
    if "interview_records" not in stage_output:
        stage_output["interview_records"] = []

    # 新增或更新记录
    updated = False
    for rec in stage_output["interview_records"]:
        if rec.get("candidate_id") == req.candidate_id:
            rec["answers"] = req.answers
            rec["interviewer"] = req.interviewer
            rec["interview_date"] = req.interview_date
            updated = True
            break
    if not updated:
        stage_output["interview_records"].append(
            {
                "candidate_id": req.candidate_id,
                "candidate_name": req.candidate_name,
                "interviewer": req.interviewer,
                "interview_date": req.interview_date,
                "answers": req.answers,
            }
        )

    answered = sum(1 for a in req.answers if a.get("answer", "").strip())
    summary = f"面试官 {req.interviewer}，{req.interview_date}，回答了 {answered}/{len(req.answers)} 题"

    update_stage(pipeline_id, "interview_gen", "done", stage_output)
    save_message(
        pipeline_id,
        "assistant",
        f"📝 {req.candidate_name} 面试记录已保存：{summary}",
        card_type="interview_record",
        card_data=req.dict(),
    )

    return {"status": "saved", "summary": summary}


# ============ 保存评估 ============


@router.post("/api/pipelines/{pipeline_id}/assessments")
async def api_save_assessment(pipeline_id: str, req: AssessmentRequest):
    """Save interviewer assessment for a candidate"""
    stages = get_stages(pipeline_id)
    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    if not interview_stage:
        raise HTTPException(404, "面试阶段不存在")
    try:
        assessment_flow.ensure_single_step_plan(pipeline_id, "manual_interview", actor_id="manual_interview")
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    if not req.dimensions or any(not 0 <= value <= 100 for value in req.dimensions.values()):
        raise HTTPException(400, "人工评估各维度分数必须在 0-100 之间")

    # 读取现有面试数据
    stage_output = parse_stage_output(interview_stage)
    if "assessments" not in stage_output:
        stage_output["assessments"] = []

    # 新增或更新该候选人的评估
    updated = False
    for a in stage_output["assessments"]:
        if a.get("candidate_id") == req.candidate_id:
            a["dimensions"] = req.dimensions
            a["highlights"] = req.highlights
            a["concerns"] = req.concerns
            a["recommendation"] = req.recommendation
            a["dimension_evidence"] = a.get("dimension_evidence", {})
            updated = True
            break
    if not updated:
        stage_output["assessments"].append(
            {
                "candidate_id": req.candidate_id,
                "candidate_name": req.candidate_name,
                "dimensions": req.dimensions,
                "highlights": req.highlights,
                "concerns": req.concerns,
                "recommendation": req.recommendation,
                "dimension_evidence": {},
            }
        )

    update_stage(pipeline_id, "interview_gen", "done", stage_output)
    save_message(pipeline_id, "assistant", f"📋 {req.candidate_name} 的面试评估已保存")
    record = next(
        (item for item in stage_output.get("interview_records", []) if item.get("candidate_id") == req.candidate_id),
        {},
    )
    scores = [value for value in req.dimensions.values() if isinstance(value, (int, float))]
    score = round(sum(scores) / len(scores)) if scores else None
    assessment_data = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    flow_result = assessment_flow.record_step_result(
        pipeline_id=pipeline_id,
        candidate_id=req.candidate_id,
        candidate_name=req.candidate_name,
        modality="manual_interview",
        execution_status="completed",
        scoring_status="succeeded" if score is not None else "failed",
        review_status="completed",
        result_status="passed" if score is not None and score >= 60 else "not_passed",
        score=score,
        scoring_version="manual_v1",
        evidence={"answers": record.get("answers", []), "assessment": assessment_data},
        metadata={"interviewer": record.get("interviewer", ""), "interview_date": record.get("interview_date", "")},
        actor_id="hr",
    )
    from app.assessment_dispatch import dispatch_next_actions

    dispatch_result = await dispatch_next_actions(pipeline_id, req.candidate_id, flow_result["package"])
    return {
        "status": "saved",
        "candidate_id": req.candidate_id,
        "assessment_flow": flow_result,
        "next_action_dispatch": dispatch_result,
    }


# ============ 生成面试 ============


@router.post("/api/interviews/{pipeline_id}/generate")
async def api_generate_interviews(pipeline_id: str):
    """手动触发生成面试题（匹配完成后由 HR 手动点击）"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    from app.screening_workflow import confirmed_screening_candidates, get_screening_context

    screening_context = get_screening_context(pipeline_id)
    match_stage = screening_context["stage"]
    if screening_context["is_modern"] and screening_context["workflow_status"] != "confirmed":
        return {"error": "小筛尚未确认，请先完成候选人复核和定版"}
    if not match_stage or match_stage["status"] != "done":
        return {"error": "匹配尚未完成，请先执行匹配"}

    match_output = screening_context["output"]
    jd_output = parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    candidates = get_candidates(pipeline_id)
    thresholds = match_output.get("thresholds", {})
    if screening_context["is_modern"]:
        shortlisted, _ = confirmed_screening_candidates(pipeline_id, candidates)
    else:
        fallback_shortlist_min = thresholds.get("shortlist_min", 70)
        shortlisted = [
            candidate
            for candidate in candidates
            if candidate.get("overall_score", 0)
            >= (
                candidate.get("shortlist_min") if candidate.get("shortlist_min") is not None else fallback_shortlist_min
            )
        ]
    existing_generated_ids = set()

    question_count = None
    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    if interview_stage:
        stage_output = parse_stage_output(interview_stage)
        existing_generated_ids = {
            str(item.get("candidate_id"))
            for item in stage_output.get("interviews", [])
            if isinstance(item, dict) and item.get("candidate_id")
        }
        try:
            question_count = int(stage_output.get("generated_count")) if stage_output.get("generated_count") else None
        except (TypeError, ValueError):
            question_count = None
    shortlisted = [candidate for candidate in shortlisted if str(candidate.get("id")) not in existing_generated_ids]
    if not shortlisted and existing_generated_ids:
        return {"status": "done", "count": 0, "message": "没有需要生成题目的新候选人"}

    active_task = services.get_active_interview_generation_task(pipeline_id)
    if active_task:
        return {
            "status": "generating",
            "generation_job_id": active_task["id"],
            "generation_status": active_task["status"],
            "count": active_task.get("candidate_count", 0),
        }

    if not shortlisted and screening_context["is_modern"]:
        return {
            "status": "done",
            "count": 0,
            "message": "没有已确认通过筛选且尚未生成题目的候选人",
        }

    warning = ""
    if not shortlisted:
        # 旧版匹配数据保留分数兜底；新版小筛绝不绕过确认和最终决策。
        match_result = {
            "candidates": candidates,
            "shortlisted": [],
            "thresholds": match_output.get("thresholds", {}),
            "screening_workflow": False,
        }
        warning = "无候选人达到入围线，将为分数最高的候选人生成面试题"
    else:
        match_result = {
            "candidates": candidates,
            "shortlisted": shortlisted,  # 传完整候选人对象，不是 ID 列表
            "thresholds": match_output.get("thresholds", {}),
            "screening_workflow": screening_context["is_modern"],
            "workflow_status": screening_context["workflow_status"],
        }

    task = services.create_interview_generation_task(pipeline_id, len(shortlisted), question_count)
    asyncio.create_task(
        services._run_interview_gen(
            pipeline_id,
            match_result,
            jd,
            pipeline["role"],
            question_count,
            task_id=task["id"],
        )
    )
    result = {
        "status": "generating",
        "generation_job_id": task["id"],
        "generation_status": task["status"],
        "count": len(shortlisted),
    }
    if warning:
        result["warning"] = warning
    return result


# ============ 面试副驾驶 API（参考北森 AI面试助手）============


@router.post("/api/interview-copilot/briefing")
async def api_copilot_briefing(data: dict):
    """面试前准备：秒看简历 + 风险点 + 推荐追问"""
    from hr_harness.agents.interview_copilot import InterviewCopilot

    pipeline_id = data.get("pipeline_id", "")
    candidate_id = data.get("candidate_id", "")
    pipeline = get_pipeline(pipeline_id) if pipeline_id else None
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    candidates = get_candidates(pipeline_id)
    candidate = next((c for c in candidates if c["id"] == candidate_id), None)
    if not candidate:
        raise HTTPException(404, "Candidate not found")
    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_out = parse_stage_output(jd_stage)
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    iv_out = parse_stage_output(iv_stage)
    iv_list = iv_out.get("interviews", [])
    cand_iv = next((i for i in iv_list if i.get("candidate_id") == candidate_id), {})
    copilot = InterviewCopilot()
    return await copilot.prepare_briefing(
        {
            "candidate": candidate,
            "jd": jd_out.get("jd", {}),
            "role": pipeline["role"],
            "interview_questions": cand_iv.get("questions", []),
        }
    )


@router.post("/api/interview-copilot/followup")
async def api_copilot_followup(data: dict):
    """面试中追问建议（北森三层追问法）"""
    from hr_harness.agents.interview_copilot import InterviewCopilot

    pipeline_id = data.get("pipeline_id", "")
    candidate_id = data.get("candidate_id", "")
    pipeline = get_pipeline(pipeline_id) if pipeline_id else None
    candidates = get_candidates(pipeline_id) if pipeline_id else []
    candidate = next((c for c in candidates if c["id"] == candidate_id), {})
    copilot = InterviewCopilot()
    return await copilot.suggest_followup(
        {
            "candidate": candidate,
            "role": pipeline["role"] if pipeline else "",
            "question": data.get("question", ""),
            "answer": data.get("answer", ""),
        }
    )


@router.post("/api/interview-copilot/evaluate")
async def api_copilot_evaluate(data: dict):
    """面试后自动评价（评分卡+证据引用）"""
    from hr_harness.agents.interview_copilot import InterviewCopilot

    pipeline_id = data.get("pipeline_id", "")
    candidate_id = data.get("candidate_id", "")
    pipeline = get_pipeline(pipeline_id) if pipeline_id else None
    candidates = get_candidates(pipeline_id) if pipeline_id else []
    candidate = next((c for c in candidates if c["id"] == candidate_id), {})
    eval_form = []
    if pipeline_id:
        stages = get_stages(pipeline_id)
        iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
        if iv_stage:
            iv_out = parse_stage_output(iv_stage)
            cand_iv = next((i for i in iv_out.get("interviews", []) if i.get("candidate_id") == candidate_id), {})
            eval_form = cand_iv.get("evaluation_form", [])
    copilot = InterviewCopilot()
    return await copilot.generate_evaluation(
        {
            "candidate": candidate,
            "role": pipeline["role"] if pipeline else "",
            "qa_history": data.get("qa_history", []),
            "evaluation_form": eval_form,
        }
    )
