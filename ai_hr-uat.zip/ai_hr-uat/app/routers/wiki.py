"""LLM-wiki 路由 — 把 /knowledge 页面切换到 wiki 方式。

采用「后台任务 + 前端轮询」约定：
- 上传 → 同步落盘建状态 → 后台两步 ingest → 前端 2s 轮询 status。
旧 /api/knowledge/* 端点保留（其它后端功能仍依赖），本 router 前缀
/api/knowledge/wiki，页面只调用本组端点。
"""

from __future__ import annotations

import json
import logging
import os
from collections import defaultdict

from fastapi import APIRouter, BackgroundTasks, File, HTTPException, Request, UploadFile
from fastapi.responses import StreamingResponse

from app import wiki_ingest, wiki_query
from app import wiki_store as ws
from app.db import transaction

logger = logging.getLogger("app.routers.wiki")

router = APIRouter(prefix="/api/knowledge/wiki", tags=["knowledge-wiki"])


def _ensure_ready() -> None:
    """惰性初始化目录 + 建表（幂等）。"""
    ws.ensure_dirs()
    ws.ensure_tables()


def _recover_filename(name: str) -> str:
    """修正部分浏览器按 latin-1 上报的 UTF-8 文件名。"""
    if not name:
        return name
    try:
        return name.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    try:
        return name.encode("latin-1").decode("gb18030")
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    return name


def _parse_written_pages(raw_pages: object) -> list[str]:
    """解析并校验资料生成页清单，避免损坏元数据触发越界删除。"""
    if not raw_pages:
        return []
    try:
        pages = json.loads(raw_pages) if isinstance(raw_pages, str) else raw_pages
    except (json.JSONDecodeError, TypeError) as error:
        raise HTTPException(500, "资料页面索引损坏，无法安全删除") from error
    if not isinstance(pages, list):
        raise HTTPException(500, "资料页面索引格式错误，无法安全删除")

    normalized_pages: list[str] = []
    for page in pages:
        normalized = page.replace("\\", "/").strip("/") if isinstance(page, str) else ""
        if not ws.is_safe_page_path(normalized) or normalized in ws.AGGREGATE_PATHS:
            raise HTTPException(500, f"资料页面索引包含非法路径: {page}")
        if normalized not in normalized_pages:
            normalized_pages.append(normalized)
    return normalized_pages


def _shared_page_paths(source_id: str, pages: list[str]) -> set[str]:
    """返回仍被其他资料声明的生成页，避免资料级删除误删共享页面。"""
    target_pages = set(pages)
    shared: set[str] = set()
    for ingest in ws.list_ingest():
        if str(ingest.get("source_id") or "") == source_id:
            continue
        shared.update(target_pages.intersection(_parse_written_pages(ingest.get("pages_written"))))
    return shared


def _source_page_path(source_id: str) -> str:
    path = f"wiki/sources/{source_id}.md"
    return path if ws.is_safe_page_path(path) else ""


def _source_filename(source_id: str, ext: str) -> tuple[str, str | None]:
    """从来源页恢复原文件名；旧资料没有状态表时只能从来源页取元数据。"""
    page_path = _source_page_path(source_id)
    content = ws.read_page(page_path) if page_path else None
    if content:
        title = ws.page_title(content, "").strip()
        if title and title != "未命名":
            return title, page_path
    return f"{source_id}.{ext}", page_path or None


def _page_source_names(content: str) -> list[str]:
    frontmatter, _ = ws.parse_frontmatter(content)
    sources = (frontmatter or {}).get("sources")
    if isinstance(sources, list):
        return [str(source) for source in sources]
    return [str(sources)] if sources else []


def _pages_for_raw_source(source_id: str, filename: str) -> list[str]:
    source_page = _source_page_path(source_id)
    pages: list[str] = []
    for path in ws.list_page_paths():
        content = ws.read_page(path)
        if path == source_page or (content and filename in _page_source_names(content)):
            pages.append(path)
    return pages


def _shared_raw_source_pages(source_id: str, filename: str, pages: list[str]) -> set[str]:
    """旧资料没有 pages_written 时，按页面 sources 元数据保护共享页面。"""
    other_filenames = {
        str(ingest.get("filename") or "")
        for ingest in ws.list_ingest()
        if str(ingest.get("source_id") or "") != source_id
    }
    for raw_source in wiki_ingest.list_source_files():
        other_id = str(raw_source.get("source_id") or "")
        if other_id and other_id != source_id:
            other_filenames.add(_source_filename(other_id, str(raw_source.get("ext") or ""))[0])

    shared: set[str] = set()
    for path in pages:
        if path == _source_page_path(source_id):
            continue
        content = ws.read_page(path) or ""
        names = set(_page_source_names(content))
        if len(names) > 1 or bool(names.intersection(other_filenames - {filename})):
            shared.add(path)
    return shared


def _raw_source_record(raw_source: dict[str, str]) -> dict[str, str]:
    source_id = str(raw_source.get("source_id") or "")
    ext = str(raw_source.get("ext") or "")
    filename, source_page = _source_filename(source_id, ext)
    parsed = bool(source_page and ws.read_page(source_page))
    record = {
        "source_id": source_id,
        "filename": filename,
        "ext": ext,
        "status": "done" if parsed else "failed",
        "progress": "已解析" if parsed else "",
    }
    if not parsed:
        record["error_msg"] = "原始文件存在，但没有找到解析结果，可点击重试"
    return record


# ── 页树 / 图谱 / 单页 ───────────────────────────────────────


@router.get("/tree")
def api_tree():
    """页树（按类型分组）+ 统计 + 最近 log。"""
    _ensure_ready()
    paths = ws.list_page_paths()
    grouped: dict[str, list[dict]] = defaultdict(list)
    for rel in paths:
        content = ws.read_page(rel)
        if content is None:
            continue
        fm, _ = ws.parse_frontmatter(content)
        ptype = (fm or {}).get("type", "concept") if fm else "concept"
        if not isinstance(ptype, str):
            ptype = "concept"
        title = ws.page_title(content, ws.page_target(rel))
        grouped[ptype].append({"slug": ws.page_target(rel), "path": rel, "title": title})

    stats = {"pages": len(paths), "types": {k: len(v) for k, v in sorted(grouped.items())}}
    log = ws.read_page("wiki/log.md") or ""
    recent_log = "\n".join(log.strip().splitlines()[-20:])
    return {
        "tree": {k: sorted(v, key=lambda x: x["slug"]) for k, v in sorted(grouped.items())},
        "stats": stats,
        "recent_log": recent_log,
    }


@router.get("/graph")
def api_graph():
    """wikilink 图：节点=页、边=正文 [[wikilink]] + frontmatter related[]。

    正文里的 wikilink 是裸 slug，而页路径是目录限定（concepts/foo）。这里用
    ``ws.resolve_page_path`` 把边两侧的 slug 解析到真实页，避免裸 slug 和限定
    slug 各算一个节点 / 边对不上。
    """
    _ensure_ready()
    paths = ws.list_page_paths()
    nodes: list[dict] = []
    edges: list[dict] = []
    slug_by_target: dict[str, str] = {}  # 任意 slug 写法 -> 规范化节点 id
    contents: dict[str, str] = {}

    for rel in paths:
        content = ws.read_page(rel)
        if content is None:
            continue
        contents[rel] = content
        title = ws.page_title(content, ws.page_target(rel))
        fm, _ = ws.parse_frontmatter(content)
        ptype = (fm or {}).get("type", "concept") if fm else "concept"
        if not isinstance(ptype, str):
            ptype = "concept"
        slug = ws.page_target(rel)
        nodes.append({"id": slug, "name": title, "type": ptype})
        # 收录多种写法（含裸文件名），供边解析用
        slug_by_target[slug] = slug
        bare = slug.rsplit("/", 1)[-1]
        slug_by_target.setdefault(bare, slug)

    node_ids = {n["id"] for n in nodes}
    edge_seen: set[tuple[str, str]] = set()
    for rel, content in contents.items():
        src = ws.page_target(rel)
        wikilinks, related = ws.page_links(content)
        for raw_target in wikilinks + related:
            if not raw_target or raw_target == src:
                continue
            tgt = slug_by_target.get(raw_target) or slug_by_target.get(raw_target.rsplit("/", 1)[-1])
            if not tgt or tgt not in node_ids or tgt == src:
                continue
            key = (src, tgt)
            if key in edge_seen:
                continue
            edge_seen.add(key)
            edges.append({"source": src, "target": tgt})

    resolved_node_ids = {n["id"] for n in nodes}
    missing_links = sorted({t for _s, t in edge_seen if t not in resolved_node_ids})
    edges = [e for e in edges if e["source"] in resolved_node_ids and e["target"] in resolved_node_ids]
    return {"nodes": nodes, "edges": edges, "missing_links": missing_links}


@router.get("/page/{path:path}")
def api_page(path: str):
    """单页：frontmatter + body + 正文 wikilink 与回链（backlink）。

    路径可以是目录限定（concepts/foo.md）或裸 slug（foo）；裸 slug 会解析到
    唯一页，方便前端直接从正文里的 [[foo]] 跳转。
    """
    _ensure_ready()
    rel = path.replace("\\", "/").strip("/")
    if not rel.endswith(".md"):
        rel += ".md"
    content = ws.read_page(rel)
    if content is None:
        resolved = ws.resolve_page_path(rel)
        if resolved:
            rel = resolved
            content = ws.read_page(rel)
    if content is None:
        raise HTTPException(404, f"页不存在: {path}")
    fm, body = ws.parse_frontmatter(content)
    wikilinks, related = ws.page_links(content)
    slug = ws.page_target(rel)

    backlinks = []
    for other in ws.list_page_paths():
        if other == rel:
            continue
        oc = ws.read_page(other) or ""
        o_wl, o_rel = ws.page_links(oc)
        if slug in o_wl or slug in o_rel or slug.rsplit("/", 1)[-1] in o_wl or slug.rsplit("/", 1)[-1] in o_rel:
            backlinks.append(
                {
                    "slug": ws.page_target(other),
                    "title": ws.page_title(oc, ws.page_target(other)),
                }
            )

    return {
        "path": rel,
        "slug": slug,
        "frontmatter": fm,
        "body": body,
        "wikilinks": wikilinks,
        "related": related,
        "backlinks": backlinks,
    }


# ── 检索 + 流式问答 ─────────────────────────────────────────


@router.post("/query")
async def api_query(req: Request):
    """轻量召回 + SSE 流式回答。POST JSON: {question, k?}。"""
    try:
        body = await req.json()
    except Exception:
        raise HTTPException(400, "请求体必须为 JSON")
    question = (body.get("question", "") or "").strip()
    if not question:
        raise HTTPException(400, "问题不能为空")
    k = int(body.get("k", wiki_query.DEFAULT_TOP_K) or wiki_query.DEFAULT_TOP_K)

    _ensure_ready()
    return StreamingResponse(
        wiki_query.stream_answer(question, k),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


# ── 上传 / 资料管理 ─────────────────────────────────────────


@router.post("/upload")
async def api_upload(background: BackgroundTasks, files: list[UploadFile] = File(default=[])):
    """上传资料 → 落 raw/ → 建状态 → 后台两步 ingest。支持 pdf/docx/txt/md。"""
    if not files:
        raise HTTPException(400, "未选择文件")
    _ensure_ready()

    created = []
    for f in files:
        name = _recover_filename(os.path.basename(f.filename or ""))
        if not name or "." not in name:
            raise HTTPException(400, f"文件名不合法: {f.filename}")
        ext = name.rsplit(".", 1)[1].lower()
        if ext not in wiki_ingest.SUPPORTED_EXTS:
            raise HTTPException(400, f"不支持的文档类型: .{ext}（支持 {'/'.join(sorted(wiki_ingest.SUPPORTED_EXTS))}）")
        content = await f.read()
        if not content:
            raise HTTPException(400, f"文件为空: {name}")

        source_id = wiki_ingest.start_ingest_source_sync(name, content, ext)
        created.append({"id": source_id, "filename": name, "ext": ext, "status": "processing"})

    return {"sources": created}


@router.get("/sources")
def api_sources():
    """资料列表 + ingest 状态（前端 2s 轮询），并补充 OSS 中的历史原始资料。"""
    _ensure_ready()
    sources = ws.list_ingest()
    known_ids = {str(source.get("source_id") or "") for source in sources}
    for raw_source in wiki_ingest.list_source_files():
        source_id = str(raw_source.get("source_id") or "")
        if source_id and source_id not in known_ids:
            sources.append(_raw_source_record(raw_source))
    return {"sources": sources}


@router.get("/storage")
def api_storage():
    """返回知识库的真实读写分层，供资料管理页展示。"""
    _ensure_ready()
    configured_backend = str(wiki_ingest.settings.storage_backend or "local").strip().lower()
    if configured_backend in {"oss", "aliyun"}:
        raw_location = f"OSS/{wiki_ingest.OSS_RAW_PREFIX}/"
        backend_label = "阿里云 OSS"
        backend = "oss"
    else:
        raw_location = "data/llm_wiki/raw/"
        backend_label = "本地磁盘"
        backend = "local"
    content_backend = ws.WIKI_CONTENT_BACKEND
    if content_backend in {"oss", "aliyun"}:
        page_location = f"OSS/{ws.WIKI_CONTENT_PREFIX}/"
        cache_location = f"OSS/{ws.WIKI_CACHE_STORAGE_KEY}"
    else:
        page_location = "data/llm_wiki/wiki/"
        cache_location = "data/llm_wiki/.llm-wiki/ingest-cache.json"
    return {
        "backend": backend,
        "backend_label": backend_label,
        "raw_location": raw_location,
        "page_backend": "oss" if content_backend in {"oss", "aliyun"} else "local",
        "page_location": page_location,
        "cache_location": cache_location,
        "index_location": "数据库：wiki_ingest（状态） + wiki_pages（页索引）",
        "read_write": "原始文件与 Markdown 页面以 OSS 为内容真源，数据库只做状态与检索索引"
        if content_backend in {"oss", "aliyun"}
        else "Markdown 页面为内容真源，数据库只做状态与检索索引",
    }


@router.delete("/sources/{source_id}")
def api_delete_source(source_id: str):
    """硬删除资料：先清存储，再清缓存和数据库索引。"""
    _ensure_ready()
    with wiki_ingest.content_mutation():
        return _delete_source_locked(source_id)


def _delete_source_locked(source_id: str):
    ing = ws.get_ingest(source_id)
    if not ing:
        raw_source = next(
            (item for item in wiki_ingest.list_source_files() if str(item.get("source_id") or "") == source_id),
            None,
        )
        if raw_source is None:
            raise HTTPException(404, f"资料 {source_id} 不存在")
        ext = str(raw_source.get("ext") or "")
        filename, _source_page = _source_filename(source_id, ext)
        pages = _pages_for_raw_source(source_id, filename)
        shared_raw_pages = _shared_raw_source_pages(source_id, filename, pages)
        ing = {
            "source_id": source_id,
            "filename": filename,
            "ext": ext,
            "status": "done",
            "pages_written": json.dumps(pages),
        }
    else:
        shared_raw_pages = set()
    if ing.get("status") == "processing":
        raise HTTPException(409, "资料正在解析，请等待解析完成后再删除")

    pages = _parse_written_pages(ing.get("pages_written"))
    shared_pages = _shared_page_paths(source_id, pages)
    shared_pages.update(shared_raw_pages)
    pages_to_delete = [page for page in pages if page not in shared_pages]

    failed_pages = [page for page in pages_to_delete if not ws.delete_page(page)]
    if failed_pages:
        raise HTTPException(502, f"生成页面删除失败，请重试: {', '.join(failed_pages[:3])}")

    ext = str(ing.get("ext") or "")
    if not wiki_ingest.delete_source_file(source_id, ext):
        raise HTTPException(502, "原始资料删除失败，请重试")

    try:
        ws.remove_ingest_cache_for_identity(f"{source_id}.{ext}")
    except Exception as error:
        logger.warning("清理 ingest 缓存失败 %s: %s", source_id, error)
        raise HTTPException(502, "知识库缓存清理失败，请重试") from error

    try:
        with transaction() as conn:
            if pages_to_delete:
                placeholders = ", ".join("%s" for _ in pages_to_delete)
                conn.execute(f"DELETE FROM wiki_pages WHERE path IN ({placeholders})", tuple(pages_to_delete))
            conn.execute("DELETE FROM wiki_ingest WHERE source_id = %s", (source_id,))
    except Exception as error:
        logger.exception("删除知识库数据库记录失败 %s", source_id)
        raise HTTPException(500, "知识库索引清理失败，请重试") from error

    # 聚合文件随删除而更新
    try:
        ws.rebuild_index()
        ws.rebuild_overview()
    except Exception:
        logger.exception("删除后重建知识库聚合页失败 %s", source_id)
    return {
        "deleted": True,
        "id": source_id,
        "pages_removed": len(pages_to_delete),
        "pages_preserved": len(shared_pages),
    }


@router.post("/sources/{source_id}/reprocess")
def api_reprocess(source_id: str, background: BackgroundTasks):
    """重跑 ingest（失败重试 / 手动覆盖）。"""
    _ensure_ready()
    ing = ws.get_ingest(source_id)
    if not ing:
        raise HTTPException(404, f"资料 {source_id} 不存在")

    ext = ing.get("ext", "")
    if wiki_ingest.read_source_file(source_id, ext) is None:
        raise HTTPException(404, f"原始文件缺失: {source_id}")

    ws.update_ingest(source_id, status="processing", error_msg="", progress="重新摄取…")

    def _run():
        try:
            content = wiki_ingest.read_source_file(source_id, ext)
            if content is None:
                raise FileNotFoundError(source_id)
            wiki_ingest.run_reprocess(source_id, ing.get("filename", ""), content, ing.get("ext", ""))
        except Exception as e:
            logger.exception("reprocess 失败 %s: %s", source_id, e)
            ws.update_ingest(source_id, status="failed", error_msg=str(e)[:500], progress="")

    background.add_task(_run)
    return {"id": source_id, "status": "processing"}
