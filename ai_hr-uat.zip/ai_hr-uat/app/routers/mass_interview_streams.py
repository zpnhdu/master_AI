"""Live stream status and Alibaba callback routes for mass interviews."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from app import service_helpers as _service_helpers
from app.access_control import require_pipeline_access, require_pipeline_path_access
from app.config import ALICLOUD_PLAY_DOMAIN, ALICLOUD_PUSH_DOMAIN
from app.infrastructure.config import settings
from app.media_storage import join_storage_key

router = APIRouter(
    prefix="/api/mass-interview",
    tags=["mass-interview"],
    dependencies=[Depends(require_pipeline_path_access)],
)


def _legacy():
    """Load the main router lazily to preserve its patchable compatibility API."""
    from app.routers import mass_interview

    return mass_interview


def _live_service():
    from app.alicloud.alicloud_live import get_live_service

    return get_live_service()


def _stream_session(stream_name: str) -> dict | None:
    stream_name = str(stream_name or "").strip()
    if not stream_name:
        return None
    legacy = _legacy()
    resolver = getattr(legacy, "get_sessions_by_stream", None)
    if resolver is not None:
        sessions = resolver(stream_name)
        if len(sessions) != 1:
            return None
        return dict(sessions[0])
    session = legacy.get_session_by_stream(stream_name)
    return dict(session) if session else None


def _require_stream_session(stream_name: str) -> dict:
    session = _stream_session(stream_name)
    if not session or not str(session.get("pipeline_id") or "").strip():
        raise HTTPException(status_code=404, detail="Stream not found")
    return session


def _authorize_stream(request: Request | None, session: dict) -> None:
    # Direct Python callers predate the HTTP request parameter; live HTTP routes
    # always provide it through FastAPI and therefore enforce row-level access.
    if request is not None:
        require_pipeline_access(request, str(session["pipeline_id"]))


_parse_json_list = _service_helpers.parse_json_list


def _full_recording_filename(session: dict) -> str:
    candidates = [session.get("oss_object_key", "")]
    candidates.extend(_parse_json_list(session.get("video_paths", "[]")))
    for path in candidates:
        if not isinstance(path, str) or not path:
            continue
        filename = os.path.basename(path.split("?", 1)[0])
        if filename.lower().startswith("full_interview"):
            return filename
    return ""


def _parse_event_time(value) -> datetime | None:
    if value is None or value == "":
        return None
    try:
        if isinstance(value, (int, float)) or str(value).isdigit():
            return datetime.fromtimestamp(float(value), tz=timezone.utc).replace(tzinfo=None)
    except (TypeError, ValueError, OSError):
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        try:
            parsed = datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None
    if parsed.tzinfo:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


def _is_newer_event(value, previous) -> bool:
    current = _parse_event_time(value)
    old = _parse_event_time(previous)
    return current is None or old is None or current > old


def _recording_object_key(stream_name: str, raw_value: str) -> str:
    value = str(raw_value or "").strip()
    parsed = urlsplit(value)
    if not value or parsed.scheme or parsed.netloc or ".." in value or "\\" in value:
        raise HTTPException(status_code=400, detail="Invalid recording object key")
    prefix = join_storage_key(settings.oss_video_prefix, "live", stream_name).strip("/") + "/"
    if not value.lstrip("/").startswith(prefix):
        raise HTTPException(status_code=400, detail="Recording object is outside the stream prefix")
    return value.lstrip("/")


async def _verified_live_callback(request: Request) -> dict:
    params = dict(request.query_params)
    try:
        form = await request.form()
        params.update(dict(form))
    except Exception:
        pass
    if not params:
        try:
            payload = await request.json()
            if isinstance(payload, dict):
                params.update(payload)
        except Exception:
            pass
    if not _live_service().verify_callback(params):
        raise HTTPException(status_code=403, detail="Invalid live callback signature")
    _require_stream_session(params.get("stream_name", ""))
    return params


async def _notify_stream_event(session: dict, event_type: str, *, online: bool, **payload) -> None:
    token = session.get("token", "")
    pipeline_id = session.get("pipeline_id", "")
    app_state = __import__("app.state", fromlist=["candidate_clients"])
    ws = app_state.candidate_clients.get(token)
    if ws:
        try:
            await ws.send_json({"type": event_type, "stream_name": session.get("stream_name", ""), **payload})
        except Exception:
            pass
    from app.routers.websocket import broadcast_monitor_event

    await broadcast_monitor_event(
        pipeline_id,
        "candidate_online" if online else "candidate_offline",
        session,
        token=token,
        stream_name=session.get("stream_name", ""),
        **payload,
    )


@router.get("/{pipeline_id}/streams")
async def api_streams_status(
    pipeline_id: str,
    request: Request,
    owner_user_id: str = Query(default=""),
):
    legacy = _legacy()
    legacy._validate_owner_filter(request, pipeline_id, owner_user_id)
    sessions = legacy.get_interview_sessions(pipeline_id)
    if not sessions:
        return {"online_count": 0, "recorded": 0, "streams": []}

    best: dict[str, dict] = {}
    for session in sessions:
        stream_name = str(session.get("stream_name") or "").strip()
        stream_name = stream_name or f"candidate_{session.get('candidate_id', session.get('id', 'unknown'))}"
        current = best.get(stream_name)
        if current is None:
            best[stream_name] = session
            continue
        old_key = (
            bool(_full_recording_filename(current)),
            float(current.get("interview_score") or 0),
            int(current.get("id") or 0),
        )
        new_key = (
            bool(_full_recording_filename(session)),
            float(session.get("interview_score") or 0),
            int(session.get("id") or 0),
        )
        if new_key > old_key:
            best[stream_name] = session

    streams = []
    online_count = 0
    recorded_count = 0
    for session in best.values():
        stream_name = str(session.get("stream_name") or "").strip()
        stream_name = stream_name or f"candidate_{session.get('candidate_id', session.get('id', 'unknown'))}"
        is_online = bool(session.get("is_streaming"))
        online_count += int(is_online)
        filename = _full_recording_filename(session)
        recorded_count += int(bool(filename))
        streams.append(
            {
                "stream_name": stream_name,
                "candidate_id": session.get("candidate_id", ""),
                "candidate_name": session.get("candidate_name", ""),
                "is_online": is_online,
                "video_url": f"/api/mass-interview/video/{pipeline_id}/{session.get('candidate_id', '')}/{filename}"
                if filename
                else "",
                "hls_url": session.get("hls_play_url", ""),
                "flv_url": session.get("flv_play_url", ""),
                "snapshot_url": "",
                "current_question": session.get("current_question", 0),
                "total_questions": session.get("total_questions", 5),
                "interview_score": session.get("interview_score", 0),
                "status": session.get("status", ""),
                "stream_started_at": session.get("stream_started_at", ""),
            }
        )
    return {"online_count": online_count, "recorded": recorded_count, "streams": streams}


@router.post("/stream/{stream_name}/kick")
async def api_kick_stream(stream_name: str, request: Request):
    session = _require_stream_session(stream_name)
    _authorize_stream(request, session)
    try:
        ok = _live_service().forbid_stream(stream_name)
    except Exception:
        ok = False
    _legacy()._update_stream_status_for_session(session.get("id"), is_streaming=0, ended_at=_legacy().now_db_string())
    return {"status": "kicked" if ok else "db_updated"}


@router.get("/stream/{stream_name}/snapshot")
async def api_stream_snapshot(stream_name: str, request: Request):
    session = _require_stream_session(stream_name)
    _authorize_stream(request, session)
    try:
        return {"url": _live_service().get_snapshot_url(stream_name) or ""}
    except Exception:
        return {"url": ""}


@router.get("/recording/{stream_name}")
async def api_recording_url(stream_name: str, request: Request):
    session = _require_stream_session(stream_name)
    _authorize_stream(request, session)
    if session.get("recording_url"):
        return {"url": session["recording_url"]}
    try:
        return {"url": _live_service().get_recording_url(stream_name) or ""}
    except Exception:
        return {"url": ""}


@router.get("/alicloud-config")
async def api_alicloud_config():
    return {"push_domain": ALICLOUD_PUSH_DOMAIN, "play_domain": ALICLOUD_PLAY_DOMAIN, "app_name": "live"}


@router.post("/callback/stream-start")
async def callback_stream_start(request: Request):
    body = await _verified_live_callback(request)
    stream_name = body["stream_name"]
    session = _require_stream_session(stream_name)
    publish_time = body.get("publish_time") or _legacy().now_db_string()
    if not _is_newer_event(publish_time, session.get("stream_started_at")):
        return {"code": 0}
    if not _is_newer_event(publish_time, session.get("stream_ended_at")):
        return {"code": 0}
    _legacy()._update_stream_status_for_session(session.get("id"), is_streaming=1, started_at=publish_time)
    await _notify_stream_event(
        session,
        "stream_online",
        online=True,
        hls_url=session.get("hls_play_url", ""),
        publish_time=publish_time,
    )
    return {"code": 0}


@router.post("/callback/stream-end")
async def callback_stream_end(request: Request):
    body = await _verified_live_callback(request)
    stream_name = body["stream_name"]
    session = _require_stream_session(stream_name)
    if not session.get("is_streaming"):
        return {"code": 0}
    ended_at = body.get("publish_time") or _legacy().now_db_string()
    if not _is_newer_event(ended_at, session.get("stream_ended_at")):
        return {"code": 0}
    _legacy()._update_stream_status_for_session(session.get("id"), is_streaming=0, ended_at=ended_at)
    await _notify_stream_event(session, "stream_offline", online=False)
    return {"code": 0}


@router.post("/callback/recording-complete")
async def callback_recording_complete(request: Request):
    body = await _verified_live_callback(request)
    stream_name = body["stream_name"]
    session = _require_stream_session(stream_name)
    oss_file = _recording_object_key(stream_name, body.get("oss_file", "") or body.get("uri", ""))
    if session.get("recording_url"):
        return {"code": 0}
    try:
        storage = _legacy().get_media_storage("oss")
        url = storage.sign_url(oss_file, 7 * 24 * 3600)
    except Exception:
        raise HTTPException(status_code=503, detail="Recording storage unavailable")
    _legacy()._update_recording_url_for_session(session.get("id"), url)
    return {"code": 0}


__all__ = [
    "api_alicloud_config",
    "api_kick_stream",
    "api_recording_url",
    "api_stream_snapshot",
    "api_streams_status",
    "callback_recording_complete",
    "callback_stream_end",
    "callback_stream_start",
    "router",
]
