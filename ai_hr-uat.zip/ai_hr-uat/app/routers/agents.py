"""Agent routes — agent stats, config, test; roles; profile, poster; messages."""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from app.access_control import require_pipeline_access, require_pipeline_path_access
from app.db import (
    get_company_config,
    get_messages,
    get_pipeline,
    get_stages,
    save_message,
    update_stage,
)
from app.poster_service import PosterService
from app.state import broadcast, get_supervisor
from app.utils import parse_stage_output
from app.xiao_wen_context import XIAO_WEN_MODEL, XIAO_WEN_STAGE_IDS
from hr_harness.memory.core import MemorySystem

router = APIRouter(tags=["agents"], dependencies=[Depends(require_pipeline_path_access)])


def get_memory(pipeline_id: str = "") -> MemorySystem:
    """Get memory system scoped to a pipeline"""
    return MemorySystem(pipeline_id)


# ============ 消息 API ============


@router.get("/api/messages")
async def api_get_messages(request: Request, pipeline_id: Optional[str] = None, limit: int = 100):
    """Get message history"""
    if pipeline_id:
        require_pipeline_access(request, pipeline_id)
    return get_messages(pipeline_id, limit)


class MessageRequest(BaseModel):
    pipeline_id: str
    content: str


@router.post("/api/messages")
async def api_send_message(req: MessageRequest, request: Request):
    """Send a message in pipeline context"""
    require_pipeline_access(request, req.pipeline_id)
    msg_id = save_message(req.pipeline_id, "user", req.content)
    return {"id": msg_id, "status": "saved"}


# ============ 管理调度面板 API ============


class AgentConfigUpdateRequest(BaseModel):
    model: Optional[str] = None
    complexity: Optional[str] = None
    temperature: Optional[float] = None
    timeout: Optional[int] = None
    retry_count: Optional[int] = None
    enabled: Optional[bool] = None
    human_approval: Optional[bool] = None


@router.get("/api/agents/stats")
async def api_get_agent_stats():
    """Return per-agent runtime statistics for the dispatch panel."""
    from app.db import get_agent_stats, get_recent_calls

    return {"stats": get_agent_stats(), "recent_calls": get_recent_calls(20)}


@router.get("/api/agents")
async def api_list_agents():
    """Return all agent configs for the dispatch panel."""
    from app.db import get_agent_configs

    return get_agent_configs()


@router.get("/api/agents/{agent_id}/config")
async def api_get_agent_config(agent_id: str):
    """Return a single agent's configuration."""
    from app.db import get_agent_config

    config = get_agent_config(agent_id)
    if not config:
        raise HTTPException(status_code=404, detail="Agent not found")
    return config


@router.put("/api/agents/{agent_id}/config")
async def api_update_agent_config(agent_id: str, update: AgentConfigUpdateRequest):
    """Update agent configuration — takes effect on next agent call."""
    from app.audit.audit_trail import audit
    from app.db import get_agent_config, upsert_agent_config

    existing = get_agent_config(agent_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    if agent_id in XIAO_WEN_STAGE_IDS and update.model not in (None, XIAO_WEN_MODEL):
        raise HTTPException(status_code=400, detail=f"小文模型固定为 {XIAO_WEN_MODEL}")
    upsert_agent_config(
        agent_id=agent_id,
        agent_name=existing["agent_name"],
        display_name=existing["display_name"],
        model=update.model,
        complexity=update.complexity,
        temperature=update.temperature,
        timeout=update.timeout,
        retry_count=update.retry_count,
        enabled=update.enabled,
        human_approval=update.human_approval,
    )
    audit(
        "agent.config_updated",
        f"Agent {agent_id} config updated",
        entity_type="agent",
        details=update.model_dump(exclude_none=True),
    )
    return {"status": "ok", "agent_id": agent_id}


@router.post("/api/agents/{agent_id}/test")
async def api_test_agent(agent_id: str, body: dict):
    """快速测试单个 agent — 用给定参数调用 run() 并返回结果"""
    from hr_harness.tool_protocol import ToolInput

    supervisor = get_supervisor()
    stage_cfg = supervisor.agent_registry.get(agent_id)
    if not stage_cfg:
        raise HTTPException(status_code=404, detail="Agent not found")
    agent_cls = stage_cfg["agent"]
    agent = agent_cls()
    params = body.get("params", {})
    pipeline_id = body.get("pipeline_id", "test")
    try:
        output = await agent.run(ToolInput(pipeline_id=pipeline_id, params=params))
        return {
            "status": output.status.value,
            "data": output.data,
            "error": output.error,
            "tokens_used": output.tokens_used,
            "duration_ms": output.duration_ms,
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ─── 角色 API（六 Agent 角色注册表） ───


@router.get("/api/roles")
async def api_list_roles():
    """返回六角色注册表 — 供调度面板使用"""
    from hr_harness.roles import get_all_roles

    roles = []
    for r in get_all_roles():
        roles.append(
            {
                "role_id": r.role_id,
                "agent_id": r.agent_id,
                "name": r.name,
                "display_name": r.display_name,
                "description": r.description,
                "icon": r.icon,
                "stage_ids": r.stage_ids,
                "enabled": r.enabled,
                "route": r.route,
            }
        )
    return {"roles": roles}


@router.get("/api/roles/{role_id}")
async def api_get_role(role_id: str):
    """返回单个角色的详细信息"""
    from app.db import get_agent_configs
    from hr_harness.roles import get_role

    role = get_role(role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    # 合并 agent 运行时配置
    configs = get_agent_configs()
    stage_configs = {c["agent_id"]: c for c in configs}
    stages = []
    for sid in role.stage_ids:
        cfg = stage_configs.get(sid, {})
        stages.append({"stage_id": sid, "config": cfg})
    return {
        "role_id": role.role_id,
        "name": role.name,
        "display_name": role.display_name,
        "description": role.description,
        "icon": role.icon,
        "enabled": role.enabled,
        "stages": stages,
    }


# ============ 画像 + 海报 API ============


@router.get("/api/profile/{pipeline_id}")
async def api_get_profile(pipeline_id: str):
    """获取职位画像"""
    stages = get_stages(pipeline_id)
    profile_stage = next((s for s in stages if s["stage_id"] == "profile_build"), None)
    if not profile_stage:
        raise HTTPException(404, "Profile not found")
    output = parse_stage_output(profile_stage)
    return {"profile": output.get("profile", {}), "pipeline_id": pipeline_id}


@router.get("/api/poster/{pipeline_id}")
async def api_get_poster(pipeline_id: str):
    """获取招聘海报 HTML"""
    stages = get_stages(pipeline_id)
    poster_stage = next((s for s in stages if s["stage_id"] == "poster_gen"), None)
    if not poster_stage:
        raise HTTPException(404, "Poster not found")
    output = parse_stage_output(poster_stage)
    return {
        "poster_html": output.get("poster_html", ""),
        "template_id": output.get("template_id", ""),
        "poster_data": output.get("poster_data", {}),
        "variants": output.get("variants", {}),
    }


@router.post("/api/poster/{pipeline_id}/save")
async def api_save_poster(pipeline_id: str, req: Request):
    """直接确认使用默认海报（无需 AI 生成）"""
    data = await req.json()
    poster_data = {
        "poster_html": data.get("poster_html", ""),
        "variants": data.get("variants", {}),
        "poster_data": data.get("poster_data", {}),
        "title": data.get("title", ""),
        "company": data.get("company", ""),
        "salary": data.get("salary", ""),
        "location": data.get("location", ""),
        "tags": data.get("tags", ""),
        "template_id": data.get("template_id", "default_branded"),
    }

    stages = get_stages(pipeline_id)
    poster_stage = next((s for s in stages if s["stage_id"] == "poster_gen"), None)
    if poster_stage:
        update_stage(pipeline_id, "poster_gen", "done", poster_data)
    else:
        from app.db import create_stage

        create_stage(pipeline_id, "poster_gen", "招聘海报")
        update_stage(pipeline_id, "poster_gen", "done", poster_data)

    # 广播更新
    card = {"type": "poster_card", "data": poster_data, "summary": "招聘海报已确认"}
    await broadcast({"type": "stage_card", "stage_id": "poster_gen", "card": card}, pipeline_id)
    save_message(pipeline_id, "assistant", "🎨 招聘海报已确认使用", card_type="poster_card", card_data=poster_data)

    version = PosterService().create_version(
        pipeline_id,
        canvas_id="multi_channel",
        fields=poster_data.get("poster_data") or {},
        instruction="确认现有渠道海报",
        source="legacy_html",
        render_data={"poster_html": poster_data["poster_html"], "variants": poster_data["variants"]},
    )
    PosterService().select_version(pipeline_id, version["id"])

    return {"status": "ok", "message": "默认海报已确认", "version_id": version["id"]}


@router.post("/api/poster/{pipeline_id}/regenerate")
async def api_regenerate_poster(pipeline_id: str, req: Request):
    """重新生成招聘海报"""
    from hr_harness.agents.poster_agent import PosterAgent

    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if not jd_stage:
        raise HTTPException(404, "JD not found, run pipeline first")

    jd_output = parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    pipeline = get_pipeline(pipeline_id)
    role = pipeline.get("role", "") if pipeline else ""
    try:
        from app.user_mailbox import PipelineHrNotConfiguredError, require_pipeline_hr, resolve_user_qr

        hr_user = require_pipeline_hr(pipeline)
    except PipelineHrNotConfiguredError as exc:
        raise HTTPException(422, f"{exc}，请先到「用户与权限」配置后重试。") from exc
    body = {}
    if req.headers.get("content-type", "").startswith("application/json"):
        body = await req.json()

    agent = PosterAgent()
    result = await agent.execute(
        {
            "jd": jd,
            "role": role,
            "pipeline_id": pipeline_id,
            "company_config": get_company_config(),
            "hr_contact": (hr_user.get("hr_contact") or "").strip(),
            "hr_qr_code": resolve_user_qr(hr_user),
            "poster_overrides": body.get("poster_data", {}) if isinstance(body, dict) else {},
            "instruction": body.get("instruction", "") if isinstance(body, dict) else "",
        }
    )

    # 更新 stage
    poster_stage = next((s for s in stages if s["stage_id"] == "poster_gen"), None)
    if poster_stage:
        update_stage(pipeline_id, "poster_gen", "done", result)
    else:
        from app.db import create_stage

        create_stage(pipeline_id, "poster_gen", "招聘海报")
        update_stage(pipeline_id, "poster_gen", "done", result)

    # 广播更新
    card = {"type": "poster_card", "data": result, "summary": "招聘海报已更新"}
    await broadcast({"type": "stage_card", "stage_id": "poster_gen", "card": card}, pipeline_id)
    save_message(pipeline_id, "assistant", "🎨 招聘海报已重新生成", card_type="poster_card", card_data=result)

    version = PosterService().create_version(
        pipeline_id,
        canvas_id="multi_channel",
        fields=result.get("poster_data") or {},
        instruction=body.get("instruction", "") if isinstance(body, dict) else "",
        source="legacy_html",
        render_data={"poster_html": result.get("poster_html", ""), "variants": result.get("variants", {})},
    )
    PosterService().select_version(pipeline_id, version["id"])

    return {
        "status": "ok",
        "poster_html": result.get("poster_html", ""),
        "template_id": result.get("template_id", ""),
        "poster_data": result.get("poster_data", {}),
        "variants": result.get("variants", {}),
        "version_id": version["id"],
    }
