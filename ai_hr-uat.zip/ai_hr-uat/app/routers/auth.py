"""Authentication routes — login / logout / me / 企业微信扫码登录。"""

import secrets
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel

from app import config
from app.access_control import COOKIE_NAME, current_user, default_page_for, session_token_hash
from app.db import (
    create_auth_session,
    delete_auth_session,
    get_auth_user_by_username,
    update_auth_user,
)
from app.security import verify_password
from app.wecom import sso as wecom_sso

router = APIRouter(prefix="/api/auth", tags=["auth"])

SESSION_MAX_AGE_SECONDS = 86400 * 7


def issue_session(user: dict, response: Response) -> dict:
    """为已验证身份的用户签发会话：随机 token 入 Cookie，哈希入持久层。

    直接返回 RedirectResponse 的路由拿不到注入 Response 上的头，
    需要用 ``carry_session_cookie`` 把 Cookie 头搬过去。
    """
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(seconds=SESSION_MAX_AGE_SECONDS)
    # Cookie 保存随机 token，持久层保存哈希；服务端可随时撤销指定账号的全部会话。
    create_auth_session(
        session_token_hash(token),
        user["id"],
        expires_at.strftime("%Y-%m-%d %H:%M:%S"),
    )
    update_auth_user(
        user["id"],
        {"last_login_at": now.strftime("%Y-%m-%d %H:%M:%S")},
    )
    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="lax",
        max_age=SESSION_MAX_AGE_SECONDS,
        path="/",
    )
    return user


def carry_session_cookie(response: Response, target: RedirectResponse) -> RedirectResponse:
    """把注入 Response 上的会话 Cookie 头复制到将直接 return 的重定向响应。"""
    for value in response.headers.getlist("set-cookie"):
        target.headers.append("set-cookie", value)
    return target


def _login_redirect(error_code: str) -> RedirectResponse:
    return RedirectResponse(url=f"/login?error={quote(error_code, safe='')}", status_code=302)


_WECOM_CALLBACK_ERROR_CODES = {
    "WECOM_CODE_EXCHANGE_FAILED": "wecom_failed",
    "WECOM_USER_DISABLED": "wecom_user_disabled",
}


@router.post("/login")
async def login(request: Request, response: Response):
    body = await request.json()
    username = str(body.get("username", "")).strip()
    password = body.get("password", "")
    user = get_auth_user_by_username(username, include_password=True)

    if user and user["is_active"] and verify_password(password, user["password_hash"]):
        user.pop("password_hash", None)
        issue_session(user, response)
        return {"ok": True, "user": user}

    return JSONResponse(
        status_code=401,
        content={"error": "用户名或密码错误"},
    )


@router.post("/logout")
async def logout(request: Request, response: Response):
    token = request.cookies.get(COOKIE_NAME)
    if token:
        delete_auth_session(session_token_hash(token))
    response.delete_cookie(COOKIE_NAME, path="/")
    return {"ok": True}


@router.get("/me")
async def me(request: Request):
    user = current_user(request)
    if user:
        return user
    return JSONResponse(status_code=401, content={"error": "未登录"})


# ── 企业微信扫码登录 ─────────────────────────────────────────


@router.get("/wecom/status")
async def wecom_status():
    """前端据此决定是否展示扫码登录入口。"""
    return {"enabled": config.wecom_login_enabled()}


def _wecom_redirect_uri(request: Request) -> str:
    """回调地址优先取公网 SERVER_URL；反代/本地环境下 request.url 不可信。"""
    base = config.SERVER_URL.rstrip("/")
    if base.startswith(("http://127.0.0.1", "http://localhost")):
        base = f"{request.url.scheme}://{request.url.netloc}".rstrip("/")
    return f"{base}/api/auth/wecom/callback"


@router.get("/wecom/login")
async def wecom_login(request: Request):
    """发起扫码：生成一次性 state 并 302 到企业微信官方扫码页。"""
    if not config.wecom_login_enabled():
        return _login_redirect("wecom_disabled")
    state = wecom_sso.issue_state()
    from app.wecom.client import sso_login_page_url

    return RedirectResponse(url=sso_login_page_url(_wecom_redirect_uri(request), state), status_code=302)


@router.get("/wecom/callback")
async def wecom_callback(request: Request, response: Response, code: str = "", state: str = "", error: str = ""):
    """扫码回调：校验 state → 换 userid → 三策略决策收敛。"""
    if not config.wecom_login_enabled():
        return _login_redirect("wecom_disabled")
    if error:
        return _login_redirect("wecom_denied")
    if not code or not wecom_sso.consume_state(state, require_pending=True):
        # state 一次性消费且只接受发起态；过期/重放一律回到登录页
        return _login_redirect("wecom_state_invalid")

    decision = wecom_sso.login_or_bind_decision(code, state)
    if decision["action"] == "login":
        issue_session(decision["user"], response)
        return carry_session_cookie(response, RedirectResponse(url=default_page_for(decision["user"]), status_code=302))
    if decision["action"] == "bind":
        # 策略 C：记录扫码人身份后引导绑定系统账号
        wecom_sso.bind_userid_to_state(state, decision["wecom_userid"])
        return RedirectResponse(url=f"/login?wecom_bind={quote(state, safe='')}", status_code=302)
    return _login_redirect(_WECOM_CALLBACK_ERROR_CODES.get(decision.get("error_code") or "", "wecom_failed"))


class WecomBindBody(BaseModel):
    state: str
    username: str
    password: str


@router.post("/wecom/bind")
async def wecom_bind(request: Request, response: Response, body: WecomBindBody):
    """策略 C 兜底：凭系统账号密码把扫码人写入 auth_users.wecom_userid。"""
    if not config.wecom_login_enabled():
        return JSONResponse(status_code=404, content={"error": "企业微信登录未启用"})
    wecom_userid = wecom_sso.get_state_userid(body.state)
    if not wecom_userid:
        return JSONResponse(status_code=401, content={"error": "扫码状态已过期，请重新扫码"})

    from app.db import get_auth_user_by_wecom_userid, set_auth_user_wecom_userid

    existing = get_auth_user_by_wecom_userid(wecom_userid)
    if existing:
        # 已绑定其他账号则直接换发会话，无需重复绑
        issue_session(existing, response)
        return {"ok": True, "user": existing}

    user = get_auth_user_by_username(body.username.strip(), include_password=True)
    if not user or not user.get("is_active") or not verify_password(body.password, user["password_hash"]):
        attempts = wecom_sso.record_bind_attempt(body.state)
        if attempts >= wecom_sso.STATE_MAX_BIND_ATTEMPTS:
            wecom_sso.consume_state(body.state)
            return JSONResponse(status_code=429, content={"error": "失败次数过多，请重新扫码"})
        return JSONResponse(status_code=401, content={"error": "用户名或密码错误"})

    set_auth_user_wecom_userid(user["id"], wecom_userid)
    wecom_sso.consume_state(body.state)
    user.pop("password_hash", None)
    issue_session(user, response)
    return {"ok": True, "user": user}


class WecomRegisterBody(BaseModel):
    state: str
    username: str
    password: str
    display_name: str
    hr_contact: str


@router.post("/wecom/register")
async def wecom_register(request: Request, response: Response, body: WecomRegisterBody):
    """扫码后自助注册新账号（hr_specialist，企微成员身份即准入门槛）。

    校验失败与绑定共用同一 state 的 3 次失败计数：一次扫码最多失败
    3 次提交，超限作废 state 防爆破。
    """
    if not config.wecom_login_enabled():
        return JSONResponse(status_code=404, content={"error": "企业微信登录未启用"})
    wecom_userid = wecom_sso.get_state_userid(body.state)
    if not wecom_userid:
        return JSONResponse(status_code=401, content={"error": "扫码状态已过期，请重新扫码"})

    import uuid

    import pymysql.err

    from app.db import create_auth_user, get_auth_user_by_wecom_userid, set_auth_user_wecom_userid
    from app.email.user_mailbox import sync_user_mailbox
    from app.security import hash_password
    from app.user_validators import ensure_email_available, validate_email, validate_username

    existing = get_auth_user_by_wecom_userid(wecom_userid)
    if existing:
        # 已绑定（可能通讯录同步期间开通）则直接换发会话，幂等返回
        issue_session(existing, response)
        return {"ok": True, "user": existing}

    if len(body.password) < 8 or len(body.password) > 128:
        return _wecom_register_failure(body.state, 422, "密码长度需为 8-128 位")
    if not body.display_name.strip() or len(body.display_name.strip()) > 50:
        return _wecom_register_failure(body.state, 422, "请填写 1-50 位的姓名")
    try:
        username = validate_username(body.username)
        hr_contact = validate_email(body.hr_contact)
        if get_auth_user_by_username(username):
            raise HTTPException(status_code=409, detail="账号已存在")
        ensure_email_available(hr_contact)
    except HTTPException as exc:
        return _wecom_register_failure(body.state, exc.status_code, str(exc.detail))

    user = None
    try:
        user = create_auth_user(
            user_id=f"user_{uuid.uuid4().hex[:16]}",
            username=username,
            display_name=body.display_name.strip(),
            password_hash=hash_password(body.password),
            role_id="hr_specialist",
            is_active=True,
            hr_contact=hr_contact,
        )
        sync_user_mailbox(user["id"], email=hr_contact, provider="custom", credential="")
    except pymysql.err.IntegrityError as exc:
        # 并发窗口下预检漏判（check-then-act 竞态），由唯一索引兜底拦截
        message = str(exc)
        detail = "账号已存在" if "username" in message else "该 HR 联系邮箱已被其他用户使用"
        return _wecom_register_failure(body.state, 409, detail)
    set_auth_user_wecom_userid(user["id"], wecom_userid)
    wecom_sso.consume_state(body.state)
    issue_session(user, response)
    return {"ok": True, "user": user}


def _wecom_register_failure(state: str, status_code: int, message: str) -> JSONResponse:
    """注册校验失败：计入失败次数，达上限作废 state。"""
    attempts = wecom_sso.record_bind_attempt(state)
    if attempts >= wecom_sso.STATE_MAX_BIND_ATTEMPTS:
        wecom_sso.consume_state(state)
        return JSONResponse(status_code=429, content={"error": "失败次数过多，请重新扫码"})
    return JSONResponse(status_code=status_code, content={"error": message})
