"""面试出题人工审核 REST API。

挂载于 /api/interview/{pipeline_id}/review/*，逻辑全部委托 app.question_review。
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel

from app import question_review as qr
from app.access_control import require_current_user, require_pipeline_path_access

router = APIRouter(
    prefix="/api/interview",
    tags=["question-review"],
    dependencies=[Depends(require_pipeline_path_access)],
)


# ---------------------------------------------------------------------------
# Pydantic 模型
# ---------------------------------------------------------------------------


class QuestionsPayload(BaseModel):
    questions: list


class QuestionPayload(BaseModel):
    question: dict


class ConfirmPayload(BaseModel):
    candidate_ids: Optional[list[str]] = None
    reviewer: str = ""


class LockPayload(BaseModel):
    candidate_ids: list[str]


class RegeneratePayload(BaseModel):
    candidate_id: Optional[str] = None
    count: Optional[int] = None


class QuestionCountPayload(BaseModel):
    count: int


class GenerateQuestionPayload(BaseModel):
    direction: str
    difficulty: str = "中等"


class AiFillPayload(BaseModel):
    difficulty: str = "中等"


class AiFillDraftPayload(BaseModel):
    draft: dict
    difficulty: str = "中等"


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------


def _err(e: ValueError) -> HTTPException:
    msg = str(e)
    return HTTPException(404, msg) if msg == "pipeline not found" else HTTPException(400, msg)


def _attachment(name: str) -> dict:
    from urllib.parse import quote

    return {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"}


# ---------------------------------------------------------------------------
# 读取
# ---------------------------------------------------------------------------


@router.get("/{pipeline_id}/review")
async def api_get_review(pipeline_id: str):
    try:
        return await qr.get_review_state(pipeline_id)
    except ValueError as e:
        raise _err(e)


# ---------------------------------------------------------------------------
# 题目增删改
# ---------------------------------------------------------------------------


@router.post("/{pipeline_id}/review/questions/{candidate_id}/generate")
async def api_generate_question(pipeline_id: str, candidate_id: str, payload: GenerateQuestionPayload):
    """按「方向 + 难度」为候选人生成 1 道题并追加（AI 辅助出题）。"""
    try:
        candidate = await qr.generate_one_question(pipeline_id, candidate_id, payload.direction, payload.difficulty)
    except ValueError as e:
        raise _err(e)
    return {"success": True, "candidate": candidate}


@router.post("/{pipeline_id}/review/questions/{candidate_id}/{index}/ai-fill")
async def api_ai_fill(pipeline_id: str, candidate_id: str, index: int, payload: AiFillPayload = AiFillPayload()):
    """单智能按钮：AI 自动判断缺失字段并补全/反生/优化（返回草稿，不写库）。"""
    try:
        result = await qr.ai_fill_question(pipeline_id, candidate_id, index, payload.difficulty)
    except ValueError as e:
        raise _err(e)
    return {"success": True, **result}


@router.post("/{pipeline_id}/review/questions/{candidate_id}/ai-fill-draft")
async def api_ai_fill_draft(pipeline_id: str, candidate_id: str, payload: AiFillDraftPayload):
    """空白卡草稿：对面试官填的内容补全/反生/优化（返回草稿，不写库）。"""
    try:
        result = await qr.ai_fill_draft(pipeline_id, candidate_id, payload.draft, payload.difficulty)
    except ValueError as e:
        raise _err(e)
    return {"success": True, **result}


@router.put("/{pipeline_id}/review/questions/{candidate_id}")
async def api_set_questions(pipeline_id: str, candidate_id: str, payload: QuestionsPayload, request: Request):
    try:
        candidate = await qr.set_questions(
            pipeline_id, candidate_id, payload.questions, actor_user_id=str(require_current_user(request)["id"])
        )
    except ValueError as e:
        raise _err(e)
    return {"success": True, "candidate": candidate}


@router.post("/{pipeline_id}/review/questions/{candidate_id}")
async def api_add_question(pipeline_id: str, candidate_id: str, payload: QuestionPayload, request: Request):
    try:
        candidate = await qr.add_question(
            pipeline_id, candidate_id, payload.question, actor_user_id=str(require_current_user(request)["id"])
        )
    except ValueError as e:
        raise _err(e)
    return {"success": True, "candidate": candidate}


@router.patch("/{pipeline_id}/review/questions/{candidate_id}/{index}")
async def api_update_question(
    pipeline_id: str, candidate_id: str, index: int, payload: QuestionPayload, request: Request
):
    try:
        candidate = await qr.update_question(
            pipeline_id, candidate_id, index, payload.question, actor_user_id=str(require_current_user(request)["id"])
        )
    except ValueError as e:
        raise _err(e)
    return {"success": True, "candidate": candidate}


@router.delete("/{pipeline_id}/review/questions/{candidate_id}/{index}")
async def api_delete_question(pipeline_id: str, candidate_id: str, index: int, request: Request):
    try:
        candidate = await qr.delete_question(
            pipeline_id, candidate_id, index, actor_user_id=str(require_current_user(request)["id"])
        )
    except ValueError as e:
        raise _err(e)
    return {"success": True, "candidate": candidate}


# ---------------------------------------------------------------------------
# 统一题集 / 审核 / 数量 / 重新生成
# ---------------------------------------------------------------------------


@router.post("/{pipeline_id}/review/apply-to-all/{candidate_id}")
async def api_apply_to_all(pipeline_id: str, candidate_id: str, request: Request):
    try:
        output = await qr.apply_to_all(
            pipeline_id, candidate_id, actor_user_id=str(require_current_user(request)["id"])
        )
    except ValueError as e:
        raise _err(e)
    return {"success": True, "review_status": output["review_status"], "interviews": output["interviews"]}


@router.post("/{pipeline_id}/review/confirm")
async def api_confirm(pipeline_id: str, payload: ConfirmPayload = ConfirmPayload()):
    try:
        result = await qr.mark_reviewed(pipeline_id, payload.candidate_ids, payload.reviewer)
    except ValueError as e:
        raise _err(e)
    return {"success": True, "review_status": result["review_status"], "reviewed_count": result["reviewed_count"]}


@router.post("/{pipeline_id}/review/regenerate")
async def api_regenerate(pipeline_id: str, payload: RegeneratePayload = RegeneratePayload()):
    try:
        result = await qr.regenerate_questions(pipeline_id, payload.candidate_id, payload.count)
    except ValueError as e:
        raise _err(e)
    return {"success": True, **result}


@router.post("/{pipeline_id}/review/lock")
async def api_lock_question_batch(pipeline_id: str, payload: LockPayload):
    try:
        return {"success": True, **(await qr.lock_question_batch(pipeline_id, payload.candidate_ids))}
    except ValueError as e:
        raise _err(e)


@router.post("/{pipeline_id}/review/question-count")
async def api_question_count(pipeline_id: str, payload: QuestionCountPayload):
    try:
        result = await qr.set_generated_count(pipeline_id, payload.count)
    except ValueError as e:
        raise _err(e)
    return {"success": True, **result}


# ---------------------------------------------------------------------------
# 导出
# ---------------------------------------------------------------------------


@router.get("/{pipeline_id}/review/export.md")
async def api_export_markdown(pipeline_id: str):
    try:
        state = await qr.get_review_state(pipeline_id)
    except ValueError as e:
        raise _err(e)
    if not state["interviews"]:
        raise HTTPException(400, "暂无面试题可导出")
    content = qr.build_markdown(state)
    return Response(
        content=content,
        media_type="text/markdown; charset=utf-8",
        headers=_attachment(f"面试题_{pipeline_id}.md"),
    )


@router.get("/{pipeline_id}/review/export.docx")
async def api_export_docx(pipeline_id: str):
    try:
        state = await qr.get_review_state(pipeline_id)
    except ValueError as e:
        raise _err(e)
    if not state["interviews"]:
        raise HTTPException(400, "暂无面试题可导出")
    buf = qr.build_docx(state)
    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers=_attachment(f"面试题_{pipeline_id}.docx"),
    )
