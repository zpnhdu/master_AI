"""Analytics routes — funnel, dashboard, communication templates, outreach, scheduling, proactive health, knowledge cards."""

import json
from collections.abc import AsyncGenerator

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.access_control import (
    is_tenant_admin,
    require_current_user,
    require_pipeline_access,
    tenant_id_for_user,
)
from app.db import (
    get_candidates,
    get_pipeline,
    get_stages,
    list_communication_templates,
    list_pipelines_for_user,
)
from app.leader_chat_service import LeaderChatRequest, handle_leader_chat, stream_leader_chat
from app.leader_chat_store import (
    PUBLIC_FAILURE_MESSAGE,
    archive_session as archive_leader_chat_session,
)
from app.leader_chat_store import (
    create_session as create_leader_chat_session,
)
from app.leader_chat_store import (
    get_session_for_actor,
    list_active_sessions,
)
from app.leader_chat_store import (
    list_messages as list_leader_chat_messages,
)
from app.leader_chat_store import (
    reserve_request,
    try_takeover_expired,
)
from app.utils import parse_stage_output

router = APIRouter(tags=["analytics"])


# ============ 沟通模板 ============


@router.get("/api/communication-templates")
def api_list_communication_templates():
    return list_communication_templates()


class GenerateCommRequest(BaseModel):
    template_id: str
    candidate_name: str
    pipeline_role: str = ""
    interview_date: str = ""
    interview_time: str = ""
    extra: dict = {}


@router.post("/api/communication-templates/generate")
def api_generate_communication(req: GenerateCommRequest):
    templates = list_communication_templates()
    tpl = next((t for t in templates if t["id"] == req.template_id), None)
    if not tpl:
        raise HTTPException(404, "Template not found")
    text = tpl.get("template", "")
    text = text.replace("{name}", req.candidate_name)
    text = text.replace("{role}", req.pipeline_role)
    text = text.replace("{date}", req.interview_date)
    text = text.replace("{time}", req.interview_time)
    for k, v in req.extra.items():
        text = text.replace(f"{{{k}}}", str(v))
    return {"success": True, "text": text, "template_name": tpl.get("name", "")}


# ============ 知识卡片 ============


@router.post("/api/knowledge-cards")
async def api_knowledge_cards(request: Request, pipeline_id: str, candidate_id: str = ""):
    """获取候选人知识卡片"""
    require_pipeline_access(request, pipeline_id)
    from hr_harness.agents.knowledge_card_agent import KnowledgeCardAgent

    candidates = get_candidates(pipeline_id)
    target = next((c for c in candidates if c.get("id") == candidate_id), None) if candidate_id else None
    resumes = [target] if target else candidates
    agent = KnowledgeCardAgent()
    result = await agent.execute({"resumes": resumes})
    return result


# ============ 招聘漏斗 API ============


@router.get("/api/analytics/funnel")
def api_funnel(request: Request, pipeline_id: str = ""):
    """招聘漏斗数据"""
    from app.db import get_funnel_data

    if pipeline_id:
        require_pipeline_access(request, pipeline_id)
        return get_funnel_data(pipeline_id)
    from app.db import get_funnel_data_for_user

    user = require_current_user(request)
    return get_funnel_data_for_user(str(user["id"]), tenant_id_for_user(user), include_all=is_tenant_admin(user))


@router.get("/api/analytics/dashboard")
def api_dashboard(request: Request):
    """招聘看板总览"""
    from collections import Counter

    from app.db import (
        count_messages_by_pipeline,
        get_dashboard_extra,
        get_funnel_data_for_user,
    )

    user = require_current_user(request)
    include_all = is_tenant_admin(user)
    tenant_id = tenant_id_for_user(user)
    visible_pipelines = list_pipelines_for_user(str(user["id"]), tenant_id, include_all=include_all)
    visible_ids = {pipeline["id"] for pipeline in visible_pipelines}
    funnel = get_funnel_data_for_user(str(user["id"]), tenant_id, include_all=include_all)
    completed = funnel["completed_pipelines"]
    total = funnel["total_pipelines"]
    roles = Counter(pipeline["role"] for pipeline in visible_pipelines)
    # 单条 GROUP BY 统计全部可见 pipeline 的消息数，替代逐 pipeline get_messages（N+1）。
    message_counts = count_messages_by_pipeline(list(visible_ids))
    summary = {
        "type": "summary",
        **funnel,
        "total_messages": sum(message_counts.values()),
        "completion_rate": f"{completed}/{total} ({round(completed / max(total, 1) * 100)}%)",
        "top_roles": [{"role": role, "count": count} for role, count in roles.most_common(10)],
    }
    extra = get_dashboard_extra(str(user["id"]), tenant_id, include_all=include_all)
    extra["funnel_extra"]["pipelines"] = [
        pipeline for pipeline in extra["funnel_extra"]["pipelines"] if pipeline["id"] in visible_ids
    ]
    return {
        "funnel": {**funnel, **extra["funnel_extra"]},
        "summary": {**summary, **extra["summary_extra"]},
    }


@router.get("/api/analytics/role-overview")
def api_role_overview(request: Request):
    """岗位一览：按岗位名称和类型汇总当前可见流水线。"""
    from app.db import get_role_overview_for_user

    user = require_current_user(request)
    return get_role_overview_for_user(
        str(user["id"]),
        tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
    )


@router.get("/api/analytics/candidate-ranking")
def api_candidate_ranking(
    request: Request,
    role: str = "",
    type_code: str = "",
    limit: int = 4,
    detail: bool = False,
):
    """候选人评分排名：仅聚合当前用户可见流水线。"""
    from app.db import get_candidate_ranking_for_user

    user = require_current_user(request)
    if limit < 1 or limit > 1000:
        raise HTTPException(status_code=422, detail="limit 必须在 1 到 1000 之间")
    return get_candidate_ranking_for_user(
        str(user["id"]),
        tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
        role=role,
        type_code=type_code,
        limit=None if detail else limit,
    )


@router.get("/api/analytics/activity")
def api_activity(request: Request):
    """招聘动态事件流"""
    from app.db import get_activity_feed

    user = require_current_user(request)
    visible_ids = {
        pipeline["id"]
        for pipeline in list_pipelines_for_user(
            str(user["id"]), tenant_id_for_user(user), include_all=is_tenant_admin(user)
        )
    }
    return [event for event in get_activity_feed() if event.get("pipeline_id") in visible_ids]


# ============ 领导数据舱对话 API ============


def _require_leader_admin(request: Request) -> dict:
    user = require_current_user(request)
    if not is_tenant_admin(user):
        raise HTTPException(status_code=403, detail="仅租户管理员可使用领导数据舱")
    return user


@router.get("/api/analytics/talent-pool-summary")
def api_talent_pool_summary(request: Request):
    """候选人指标汇总：人才库全部候选人的性别/学历/区域/工作年限分布。"""
    from app.db import get_talent_pool_distribution

    user = _require_leader_admin(request)
    return get_talent_pool_distribution(tenant_id_for_user(user))


@router.get("/api/analytics/talent-attrition")
def api_talent_attrition(request: Request):
    """人才流失分析：岗位不匹配/初筛不通过/面试不通过/拒绝面试 四类流失人数。"""
    from app.db import get_talent_attrition

    user = _require_leader_admin(request)
    return get_talent_attrition(tenant_id_for_user(user))


@router.get("/api/analytics/stage-pass-rate-trend")
def api_stage_pass_rate_trend(request: Request):
    """各环节通过率趋势：全部 HR 已完成流程的近 30 天累计通过率折线。"""
    from app.db import get_stage_pass_rate_trend

    user = _require_leader_admin(request)
    return get_stage_pass_rate_trend(tenant_id_for_user(user))


@router.get("/api/analytics/hr-performance")
def api_hr_performance(request: Request):
    """HR 工作观察：岗位、通过小筛人数、小评通过人数与通过率。"""
    from app.db import get_hr_performance

    user = _require_leader_admin(request)
    return {"hrs": get_hr_performance(tenant_id_for_user(user))}


@router.get("/api/analytics/talent-pool-growth")
def api_talent_pool_growth(request: Request):
    """人才库增长趋势：近 30 天每日新增、累计总量与新增环比增长率。"""
    from app.db import get_talent_pool_growth

    user = _require_leader_admin(request)
    return get_talent_pool_growth(tenant_id_for_user(user))


@router.post("/api/analytics/leader-chat/sessions")
def api_create_leader_chat_session(request: Request):
    user = _require_leader_admin(request)
    return {
        "session": create_leader_chat_session(tenant_id_for_user(user), str(user["id"])),
    }


@router.get("/api/analytics/leader-chat/sessions")
def api_list_leader_chat_sessions(request: Request):
    user = _require_leader_admin(request)
    return {
        "sessions": list_active_sessions(tenant_id_for_user(user), str(user["id"])),
    }


@router.get("/api/analytics/leader-chat/sessions/{session_id}/messages")
def api_list_leader_chat_messages(request: Request, session_id: str):
    user = _require_leader_admin(request)
    session = get_session_for_actor(session_id, tenant_id_for_user(user), str(user["id"]))
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    return {"session": session, "messages": list_leader_chat_messages(session_id)}


@router.post("/api/analytics/leader-chat/sessions/{session_id}/archive")
def api_archive_leader_chat_session(request: Request, session_id: str):
    user = _require_leader_admin(request)
    session = archive_leader_chat_session(session_id, tenant_id_for_user(user), str(user["id"]))
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    return {"session": session}


@router.post("/api/analytics/leader-chat")
async def api_leader_chat(request: Request, body: LeaderChatRequest):
    user = _require_leader_admin(request)
    try:
        return await handle_leader_chat(str(user["id"]), tenant_id_for_user(user), body)
    except LookupError:
        raise HTTPException(status_code=404, detail="会话不存在")
    except ValueError as exc:
        detail = str(exc)
        if detail == "session archived":
            raise HTTPException(status_code=409, detail="会话已归档")
        if detail == "client request id already used":
            raise HTTPException(status_code=409, detail="请求标识已被其他消息使用")
        raise HTTPException(status_code=400, detail="请求无法处理")


async def _sse_format(events) -> AsyncGenerator[str, None]:
    """把结构化事件转为 SSE 文本帧，末尾补 [DONE]。"""
    async for event in events:
        yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"
    yield "data: [DONE]\n\n"


@router.post("/api/analytics/leader-chat/stream")
async def api_leader_chat_stream(request: Request, body: LeaderChatRequest):
    """领导数据舱对话流式端点：首帧发确定性数字+图表，随后逐字流式 insight/闲聊。"""
    user = _require_leader_admin(request)
    tenant_id = tenant_id_for_user(user)
    session = get_session_for_actor(body.session_id, tenant_id, str(user["id"]))
    if not session:
        raise HTTPException(status_code=404, detail="会话不存在")
    if session.get("status") != "active":
        raise HTTPException(status_code=409, detail="会话已归档")

    reserved, owner = reserve_request(session, body.client_request_id, body.message)
    if not owner:
        if not reserved.get("same_payload"):
            raise HTTPException(status_code=409, detail="请求标识已被其他消息使用")
        if reserved.get("status") == "succeeded":

            async def replay_events():
                replay_chart = reserved.get("response_chart")
                if not isinstance(replay_chart, dict) or not replay_chart:
                    replay_chart = None
                yield {"phase": "data", "text": reserved.get("response_text") or "", "chart": replay_chart}
                yield {"done": True, "status": "succeeded", "request_id": reserved.get("id"), "chart": replay_chart}

            return StreamingResponse(
                _sse_format(replay_events()),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
            )
        if reserved.get("status") == "failed":

            async def failed_events():
                yield {
                    "error": reserved.get("public_error_message") or PUBLIC_FAILURE_MESSAGE,
                    "request_id": reserved.get("id"),
                }

            return StreamingResponse(
                _sse_format(failed_events()),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
            )
        if reserved.get("lease_expires_at"):
            taken = try_takeover_expired(str(reserved["id"]))
            if taken:
                reserved = taken
                owner = True
        if not owner:

            async def processing_events():
                yield {"phase": "data", "text": "正在分析，请稍候", "chart": None}
                yield {"done": True, "status": "processing", "request_id": reserved.get("id"), "chart": None}

            return StreamingResponse(
                _sse_format(processing_events()),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
            )

    return StreamingResponse(
        _sse_format(stream_leader_chat(str(user["id"]), tenant_id, body, session, reserved)),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


# ============ 触达 & 面试安排 API ============


@router.post("/api/outreach/generate")
async def api_outreach_generate(data: dict, request: Request):
    """为候选人生成触达消息"""
    from hr_harness.agents.outreach_agent import OutreachAgent

    pipeline_id = data.get("pipeline_id", "")
    require_pipeline_access(request, pipeline_id)
    step = data.get("step", "initial")

    pipeline = get_pipeline(pipeline_id) if pipeline_id else None
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    stages = get_stages(pipeline_id)
    candidates = get_candidates(pipeline_id)

    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_output = parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    agent = OutreachAgent()
    context = {
        "candidates": candidates,
        "jd": jd,
        "role": pipeline["role"],
        "pipeline_id": pipeline_id,
        "outreach_step": step,
    }
    result = await agent.execute(context)
    return result


@router.post("/api/scheduling/generate")
async def api_scheduling_generate(data: dict, request: Request):
    """为候选人生成面试安排"""
    from hr_harness.scheduling import SchedulingAgent

    pipeline_id = data.get("pipeline_id", "")
    require_pipeline_access(request, pipeline_id)

    pipeline = get_pipeline(pipeline_id) if pipeline_id else None
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    stages = get_stages(pipeline_id)
    candidates = get_candidates(pipeline_id)

    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    interview_output = parse_stage_output(interview_stage)
    interviews = interview_output.get("interviews", [])

    agent = SchedulingAgent()
    context = {
        "candidates": candidates,
        "interviews": interviews,
        "role": pipeline["role"],
        "pipeline_id": pipeline_id,
    }
    result = await agent.execute(context)
    return result


# ============ 主动巡检 API ============


@router.get("/api/proactive/health")
def api_proactive_health(request: Request, pipeline_id: str = ""):
    """Pipeline健康巡检"""
    from hr_harness.proactive import check_pipeline_health

    if pipeline_id:
        require_pipeline_access(request, pipeline_id)
    return check_pipeline_health(pipeline_id)
