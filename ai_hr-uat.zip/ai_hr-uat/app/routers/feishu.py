"""Feishu webhook routes — receive message callbacks and return interactive cards."""

import json

from fastapi import APIRouter, HTTPException, Request

from app.db import (
    get_candidates,
    get_pipeline,
    get_talent_pool_stats,
    list_pipelines,
    search_talent_pool,
)
from app.feishu_webhook import (
    build_candidate_search_card,
    build_dashboard_summary_card,
    build_error_card,
    build_help_card,
    build_pipeline_status_card,
    build_talent_pool_stats_card,
    build_unknown_intent_card,
    parse_intent,
    verify_url,
)

router = APIRouter(prefix="/api/feishu", tags=["feishu"])


@router.post("/webhook")
async def api_feishu_webhook(request: Request):
    """Receive Feishu message callback.

    Supports:
    - URL verification (challenge)
    - Text message parsing and interactive card response
    - Button action callbacks
    """
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")

    # ── URL 验证 ──
    if body.get("type") == "url_verification":
        challenge = body.get("challenge", "")
        token = body.get("token", "")
        return verify_url(challenge, token)

    # ── 事件回调 ──
    event = body.get("event", {})
    event_type = event.get("type", "")

    if event_type == "message":
        return await _handle_message(event)

    # ── 按钮操作回调 ──
    if event_type == "action":
        return await _handle_action(event)

    return {"status": "ok"}


async def _handle_message(event: dict) -> dict:
    """Handle a text message from Feishu."""
    message_text = event.get("text", "").strip()
    if not message_text:
        return _card_response(build_help_card())

    intent, keyword = parse_intent(message_text)

    try:
        if intent == "help":
            card = build_help_card()

        elif intent == "pipeline_status":
            pipelines = list_pipelines()
            card = build_pipeline_status_card(pipelines)

        elif intent == "search_candidate":
            skill_list = [keyword] if keyword else None
            results = search_talent_pool(query=keyword or "", skills=skill_list, limit=10)
            card = build_candidate_search_card(results, keyword or "")

        elif intent == "talent_pool_stats":
            stats = get_talent_pool_stats()
            card = build_talent_pool_stats_card(stats)

        elif intent == "dashboard_summary":
            from app.db import get_funnel_data
            from app.reports import generate_summary

            funnel = get_funnel_data()
            summary = generate_summary()
            card = build_dashboard_summary_card(
                {
                    "total_pipelines": len(list_pipelines()),
                    "total_candidates": funnel.get("total_candidates", 0),
                    "weekly_new": summary.get("weekly_new", 0),
                    "weekly_interviews": summary.get("weekly_interviews", 0),
                    "weekly_hires": summary.get("weekly_hires", 0),
                }
            )

        elif intent == "recommend_job":
            # 按职位或关键词搜索并返回匹配候选人
            results = search_talent_pool(query=keyword or "", limit=10)
            card = build_candidate_search_card(results, keyword or "")

        elif intent == "schedule_interview":
            # 展示尚未安排面试的候选人
            pipelines = list_pipelines()
            card = build_pipeline_status_card(pipelines)

        else:
            card = build_unknown_intent_card()

    except Exception as e:
        card = build_error_card(str(e))

    return _card_response(card)


async def _handle_action(event: dict) -> dict:
    """Handle button action callbacks from interactive cards."""
    action_value = event.get("action", {}).get("value", "{}")
    try:
        action_data = json.loads(action_value)
    except (json.JSONDecodeError, TypeError):
        action_data = {}

    action_type = action_data.get("action", "")

    try:
        if action_type == "view_pipeline":
            pipeline = get_pipeline(action_data.get("pipeline_id", ""))
            if pipeline:
                candidates = get_candidates(pipeline["id"])
                card = {
                    "config": {"wide_screen_mode": True},
                    "header": {
                        "title": {"tag": "plain_text", "content": f"📋 {pipeline.get('role', '未知岗位')}"},
                        "template": "blue",
                    },
                    "elements": [
                        {
                            "tag": "div",
                            "text": {
                                "tag": "lark_md",
                                "content": (
                                    f"**状态**: {pipeline.get('status', 'unknown')}\n"
                                    f"**候选人**: {len(candidates)} 位\n"
                                    f"**创建时间**: {pipeline.get('created_at', '')}"
                                ),
                            },
                        }
                    ],
                }
                return _card_response(card)

        elif action_type == "reject":
            from app.db import update_candidate

            update_candidate(action_data.get("candidate_id", ""), {"status": "rejected"})
            card = {
                "header": {"title": {"tag": "plain_text", "content": "✅ 已完成"}, "template": "green"},
                "elements": [{"tag": "div", "text": {"tag": "lark_md", "content": "候选人已标记为淘汰"}}],
            }
            return _card_response(card)

    except Exception as e:
        card = build_error_card(str(e))
        return _card_response(card)

    return {"status": "ok"}


def _card_response(card: dict) -> dict:
    """Wrap a card into a Feishu-compatible message response."""
    return {
        "msg_type": "interactive",
        "card": card,
    }
