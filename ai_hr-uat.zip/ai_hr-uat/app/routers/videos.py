"""Video routes — file download, video download, video upload/process/skip."""

import asyncio
import io
import os
import time as _time
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response

from app import services, state
from app.access_control import require_pipeline_path_access
from app.config import UPLOAD_DIR
from app.db import get_pipeline, save_message
from app.infrastructure.config import settings
from app.media_storage import get_media_storage, join_storage_key
from app.utils import decode_bytes

router = APIRouter(tags=["videos"], dependencies=[Depends(require_pipeline_path_access)])


@router.get("/api/files/{filename}")
async def api_download_file(filename: str, request: Request):
    """Download a pipeline-scoped Markdown export."""
    safe_filename = Path(filename.replace("\\", "/")).name
    if safe_filename != filename or not safe_filename.endswith(".md"):
        raise HTTPException(400, "Invalid filename")

    export_prefixes = ("interviews_", "report_", "chat_", "exam_")
    if not safe_filename.startswith(export_prefixes):
        raise HTTPException(404, "File not found")
    pipeline_id = safe_filename.rsplit(".", 1)[0].split("_", 1)[1]
    if not pipeline_id:
        raise HTTPException(404, "File not found")

    from app.access_control import require_pipeline_access

    require_pipeline_access(request, pipeline_id)
    data_root = Path(__file__).resolve().parent.parent / "data"
    filepath = (data_root / safe_filename).resolve()
    try:
        filepath.relative_to(data_root.resolve())
    except ValueError as exc:
        raise HTTPException(400, "Invalid filename") from exc
    if filepath.is_file():
        return FileResponse(filepath, filename=safe_filename, media_type="text/markdown")
    raise HTTPException(404, "File not found")


@router.get("/api/videos/{pipeline_id}/download/{filename}")
async def api_download_video(pipeline_id: str, filename: str):
    """Download uploaded interview video file"""
    safe_filename = Path(filename.replace("\\", "/")).name
    if safe_filename != filename:
        raise HTTPException(400, "Invalid filename")
    storage = get_media_storage()
    candidate_keys = [join_storage_key(settings.oss_video_prefix, "uploads", pipeline_id, safe_filename)]
    candidate_keys.extend(
        key
        for key in storage.list_keys(join_storage_key(settings.oss_interview_prefix, pipeline_id))
        if key.rsplit("/", 1)[-1] == safe_filename
    )
    for storage_key in candidate_keys:
        if hasattr(storage, "sign_url") and storage.exists(storage_key):
            return RedirectResponse(storage.sign_url(storage_key), status_code=307)

    filepath = os.path.join(UPLOAD_DIR, pipeline_id, safe_filename)
    if os.path.exists(filepath):
        return FileResponse(filepath, filename=filename, media_type="video/mp4")
    raise HTTPException(404, "Video file not found")


@router.post("/api/videos/{pipeline_id}/upload")
async def api_upload_videos(
    pipeline_id: str,
    files: list[UploadFile] = File(default=[]),
    text: str = Form(default=""),
    candidate_name: str = Form(default=""),
    candidate_id: str = Form(default=""),
):
    """Upload interview video/transcript files for a pipeline"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    if pipeline_id not in state.pending_videos:
        state.pending_videos[pipeline_id] = []

    storage = get_media_storage()
    # 本地模式保留现有目录；OSS 模式不再创建本地持久化目录。
    pipeline_upload_dir = os.path.join(UPLOAD_DIR, pipeline_id)
    if storage.backend != "oss":
        os.makedirs(pipeline_upload_dir, exist_ok=True)

    imported = []

    # 处理上传文件
    for f in files:
        content = await f.read()
        filename = f.filename or "unknown"
        ext = filename.lower().split(".")[-1] if "." in filename else ""
        file_size = len(content)

        text_content = ""
        stored_filename = ""
        is_video = False

        if ext in ("txt", "md"):
            text_content = decode_bytes(content)
        elif ext == "pdf":
            try:
                import PyPDF2

                pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
                text_content = "\n".join([page.extract_text() or "" for page in pdf_reader.pages])
            except Exception as e:
                from app.audit.logger import get_logger

                logger = get_logger("videos")
                logger.error(f"PDF parse failed: {e}", extra={"source": "Video Upload"})
        elif ext in ("mp4", "webm", "mov", "avi"):
            # 将视频文件存入 uploads 目录
            original_filename = Path(filename.replace("\\", "/")).name or "video"
            stored_filename = f"{int(_time.time())}_{original_filename}"
            storage_key = join_storage_key(settings.oss_video_prefix, "uploads", pipeline_id, stored_filename)
            try:
                if storage.backend == "oss":
                    await asyncio.to_thread(
                        storage.write,
                        storage_key,
                        content,
                        f.content_type or "application/octet-stream",
                    )
                else:
                    video_path = os.path.join(pipeline_upload_dir, stored_filename)
                    with open(video_path, "wb") as vf:
                        vf.write(content)
            except Exception as exc:
                from app.audit.logger import get_logger

                get_logger("videos").error(
                    f"Video storage failed for {stored_filename}: {exc}",
                    extra={"source": "Video Upload"},
                )
                raise HTTPException(502, "视频存储失败") from exc
            is_video = True
            text_content = f"[视频文件: {filename}]"
        else:
            storage_key = ""
            text_content = decode_bytes(content)

        if text_content.strip() or is_video:
            video_entry = {
                "candidate_id": candidate_id or "",
                "candidate_name": candidate_name or filename.split(".")[0],
                "transcript": text_content,
                "source": f"file:{filename}",
                "filename": filename,
                "stored_filename": stored_filename,
                "file_size": file_size,
                "is_video": is_video,
                "file_type": ext,
                "download_url": f"/api/videos/{pipeline_id}/download/{stored_filename}" if is_video else "",
                "storage_key": storage_key if is_video else "",
                "storage_backend": storage.backend if is_video else "",
            }
            state.pending_videos[pipeline_id].append(video_entry)
            from app.db import save_pending

            save_pending(pipeline_id, "videos", video_entry)
            imported.append(video_entry)

    # 处理粘贴文本（面试转写）
    if text.strip():
        video_entry = {
            "candidate_id": candidate_id or "",
            "candidate_name": candidate_name or "未知候选人",
            "transcript": text,
            "source": "paste",
            "filename": "pasted_transcript",
            "stored_filename": "",
            "file_size": len(text.encode("utf-8")),
            "is_video": False,
            "file_type": "text",
            "download_url": "",
        }
        state.pending_videos[pipeline_id].append(video_entry)
        from app.db import save_pending

        save_pending(pipeline_id, "videos", video_entry)
        imported.append(video_entry)

    count = len(state.pending_videos[pipeline_id])
    save_message(pipeline_id, "system", f"上传了{len(imported)}份面试记录（累计{count}份）")

    # 不再自动触发视频评估，由 HR 手动点击"开始评估"按钮
    return {"status": "imported", "count": count, "new": len(imported)}


@router.post("/api/videos/{pipeline_id}/process")
async def api_process_videos(pipeline_id: str):
    """手动触发视频/面试记录评估"""
    import asyncio

    videos = state.pending_videos.get(pipeline_id, [])
    if not videos:
        return {"error": "没有面试记录可评估"}
    asyncio.create_task(services.process_uploaded_videos(pipeline_id))
    return {"status": "processing", "count": len(videos)}


@router.post("/api/videos/{pipeline_id}/skip")
async def api_skip_videos(pipeline_id: str):
    """Skip video assessment and go directly to report"""
    import asyncio

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    asyncio.create_task(services.skip_to_report(pipeline_id))
    return {"status": "skipping"}


# ── 支持 Range 的视频流（供 HR 拖动查看面试视频）──────────────


@router.get("/api/videos/stream/{filepath:path}")
async def api_stream_video(filepath: str, request: Request):
    """Stream a video file with HTTP Range support for seekable playback.

    Path is relative to UPLOAD_DIR, e.g.:
      /api/videos/stream/{pipeline_id}/mass/{candidate_id}/q0.webm
    """
    from app.config import UPLOAD_DIR

    full_path = os.path.join(UPLOAD_DIR, filepath)
    # 安全检查：防止路径遍历
    real_path = os.path.realpath(full_path)
    if not real_path.startswith(os.path.realpath(UPLOAD_DIR)):
        raise HTTPException(403, "Access denied")

    if not os.path.exists(real_path):
        raise HTTPException(404, "Video file not found")

    file_size = os.path.getsize(real_path)
    range_header = request.headers.get("range")

    if range_header:
        try:
            unit, ranges = range_header.split("=", 1)
            if unit != "bytes":
                raise ValueError("Only bytes range supported")
            start_str, end_str = ranges.split("-", 1)
            start = int(start_str) if start_str else 0
            end = int(end_str) if end_str else file_size - 1
            start = max(0, start)
            end = min(end, file_size - 1)
        except Exception:
            start, end = 0, file_size - 1

        length = end - start + 1
        with open(real_path, "rb") as f:
            f.seek(start)
            data = f.read(length)

        return Response(
            content=data,
            status_code=206,
            headers={
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Accept-Ranges": "bytes",
                "Content-Length": str(length),
                "Content-Type": "video/webm",
            },
        )

    return FileResponse(real_path, media_type="video/webm")
