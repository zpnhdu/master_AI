"""Mass Interview API — 百人视频面试：批量出题、一镜到底录制、异步评分、排名看板。

Endpoints:
  1.  POST /api/mass-interview/launch       — HR发起百人面试
  2.  POST /api/mass-interview/{pid}/prepare-tts — TTS预生成
  3.  GET  /api/mass-interview/{pid}/status — 实时进度
  4.  GET  /api/mass-interview/session/{token} — 候选人打开面试
  5.  POST /api/mass-interview/session/{token}/full-video — 完整视频上传（一镜到底）
  6.  GET  /api/mass-interview/{pid}/ranking — 排名看板
  7.  POST /api/mass-interview/{pid}/mark   — HR标记候选人
  8.  POST /api/mass-interview/session/{token}/extend — 续期
  9.  POST /api/mass-interview/{pid}/batch-extend — 批量续期
  10. POST /api/mass-interview/{pid}/invite — 批量发送邀请
  11. GET  /api/mass-interview/video/{pid}/{cid}/{filename} — 视频流播放
  12. POST /api/mass-interview/{pid}/evaluate — 批量深度分析(异步)
  13. POST /api/mass-interview/session/{token}/device-check — 设备检测
  14. GET  /api/mass-interview/pipelines — Pipeline列表
  15. GET  /api/mass-interview/{pid}/streams — 流状态
  16. POST /api/mass-interview/stream/{name}/kick — 踢流
  17. GET  /api/mass-interview/stream/{name}/snapshot — 截图
  18. GET  /api/mass-interview/recording/{name} — 录制URL
  19. GET  /api/mass-interview/alicloud-config — 直播配置
"""

import asyncio
import base64
import binascii
import glob
import hashlib
import hmac
import html
import json
import logging
import os
import re
import secrets
import subprocess
import time
from datetime import datetime, timedelta, timezone
from typing import Optional
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Body, Depends, File, Form, Header, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response
from pydantic import BaseModel, ConfigDict, Field

from app import analytics_time_helpers as _analytics_time_helpers
from app import assessment_flow, candidate_reports
from app import service_helpers as _service_helpers
from app.access_control import (
    is_tenant_admin,
    require_current_user,
    require_pipeline_access,
    require_pipeline_path_access,
    tenant_id_for_user,
)
from app.config import UPLOAD_DIR
from app.db import (
    _effective_interview_status,
    _get_written_test_sessions,
    _update_recording_url_for_session,  # noqa: F401 - extracted stream router dependency
    _update_stream_status_for_session,  # noqa: F401 - extracted stream router dependency
    create_interview_session,
    get_candidates,
    get_db,
    get_interview_schedules,
    get_interview_session,
    get_interview_sessions,
    get_pipeline,
    get_session_by_stream,  # noqa: F401 - legacy module export
    get_session_ranking,
    get_session_stats,
    get_sessions_by_stream,  # noqa: F401 - extracted stream router dependency
    get_stages,
    now_db_string,
    save_message,
    transaction,
    update_candidate,
    update_interview_session,
)
from app.infrastructure.config import settings
from app.media_storage import get_media_storage, join_storage_key
from app.utils import parse_stage_output

logger = logging.getLogger(__name__)
SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
_parse_db_ts = _analytics_time_helpers.parse_db_ts
_parse_json_field = _service_helpers.parse_json_field
_safe_oss_segment = _service_helpers.safe_oss_segment
_lease_client_id = _service_helpers.normalize_lease_client_id
_scored_video_answer = _service_helpers.scored_video_answer


async def _broadcast_mass_event(
    pipeline_id: str,
    event_type: str,
    session: dict | None = None,
    **payload,
) -> None:
    """Send a typed monitor update without coupling DB writes to WebSocket state."""
    from app.routers.websocket import broadcast_monitor_event

    await broadcast_monitor_event(pipeline_id, event_type, session, **payload)


async def _send_retest_schedule_email(request: Request, pipeline_id: str, candidate_id: str, schedule: dict) -> dict:
    """Send the confirmed retest slot from the current HR mailbox to the candidate."""
    try:
        from app.db import get_candidate_email
        from app.email_accounts import get_account
        from app.email_sender import send_email

        user = require_current_user(request)
        account_row = (
            get_db()
            .execute(
                "SELECT id FROM email_accounts WHERE owner_user_id=%s AND tenant_id=%s LIMIT 1",
                (str(user.get("id")), tenant_id_for_user(user)),
            )
            .fetchone()
        )
        if not account_row:
            return {"status": "skipped", "message": "当前 HR 尚未配置发信邮箱"}
        mailbox = get_account(account_row["id"], user, include_secret=True, permission="read")
        sender_email = str(user.get("hr_contact") or mailbox.get("email_address") or "").strip()
        smtp_config = {
            "host": mailbox.get("smtp_host"),
            "port": mailbox.get("smtp_port"),
            "security": mailbox.get("smtp_security") or "ssl",
            "username": mailbox.get("username") or sender_email,
            "from_email": sender_email,
            "password": mailbox.get("credential") or "",
            "from_name": user.get("display_name", "") or "招聘团队",
        }
        if any(not str(smtp_config.get(key) or "").strip() for key in ("host", "username", "password")):
            return {"status": "skipped", "message": "HR 发信邮箱配置不完整"}
        candidate_email = get_candidate_email("", pipeline_id, candidate_id)
        if not candidate_email:
            return {"status": "skipped", "message": "没有候选人邮箱"}
        candidate_name = str(schedule.get("candidate_name") or candidate_id).strip()
        role = str((get_pipeline(pipeline_id) or {}).get("role") or "").strip()
        meeting_url = str(schedule.get("meeting_url") or "").strip()
        rows = [
            f"<p>您好，{html.escape(candidate_name)}：</p>",
            "<p>您的复试安排如下：</p>",
            f"<p>职位：{html.escape(role or '待定')}<br>日期：{html.escape(str(schedule.get('date') or '待定'))}<br>时间：{html.escape(str(schedule.get('time') or '待定'))}<br>面试官：{html.escape(str(schedule.get('interviewer') or '待定'))}",
        ]
        if meeting_url:
            safe_url = html.escape(meeting_url, quote=True)
            rows.append(f'<br>腾讯会议：<a href="{safe_url}">{safe_url}</a>')
        if schedule.get("notes"):
            rows.append(f"<br>备注：{html.escape(str(schedule['notes']))}")
        rows.append("</p><p>请提前做好准备，感谢。</p>")
        result = await send_email(
            to_email=candidate_email,
            subject=f"复试安排 - {role or '面试'}",
            body="".join(rows),
            is_html=True,
            smtp_config=smtp_config,
        )
        return {"status": "sent" if result.success else "failed", "message": result.error or ""}
    except Exception as error:
        logger.warning("Retest schedule email failed for %s/%s: %s", pipeline_id, candidate_id, error)
        return {"status": "failed", "message": str(error)}


def _render_offer_email(candidate_name: str, role: str, company_name: str, hr_name: str) -> str:
    """Build a self-contained offer email that renders consistently across mail clients."""
    safe_candidate_name = html.escape(candidate_name or "候选人")
    safe_role = html.escape(role or "拟录用岗位")
    safe_company_name = html.escape(company_name or "招聘团队")
    safe_hr_name = html.escape(hr_name or "招聘团队")
    return f"""<!doctype html>
<html lang="zh-CN"><body style="margin:0;background:#f4f7f5;padding:24px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',Arial,sans-serif;color:#17352a;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td align="center">
  <table role="presentation" width="640" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:640px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 28px rgba(21,72,52,.12);">
    <tr><td style="padding:34px 40px;background:linear-gradient(135deg,#0f6b46,#1f8f5f);color:#ffffff;">
      <div style="font-size:13px;letter-spacing:2px;opacity:.86;">OFFER LETTER</div>
      <div style="margin-top:8px;font-size:28px;font-weight:700;">录用通知</div>
      <div style="margin-top:8px;font-size:15px;opacity:.92;">{safe_company_name}</div>
    </td></tr>
    <tr><td style="padding:36px 40px;font-size:15px;line-height:1.9;">
      <p style="margin:0 0 18px;">尊敬的 <strong>{safe_candidate_name}</strong>：</p>
      <p style="margin:0 0 18px;">您好！感谢您参加我们的面试。经过综合评估，我们很高兴地通知您，您已通过面试，诚邀您加入 <strong>{safe_company_name}</strong>。</p>
      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin:24px 0;background:#f0faf5;border:1px solid #ccebdd;border-radius:10px;">
        <tr><td style="padding:18px 22px;color:#527064;width:92px;">录用岗位</td><td style="padding:18px 22px;font-size:17px;font-weight:700;color:#0f6b46;">{safe_role}</td></tr>
      </table>
      <p style="margin:0 0 18px;">后续报到时间、薪酬福利、入职材料等具体事项，将由 HR 与您进一步确认，并以双方最终确认或签署的文件为准。</p>
      <p style="margin:0 0 18px;">请直接回复本邮件与我们联系。期待与您携手同行！</p>
      <p style="margin:28px 0 0;">此致<br><strong>{safe_hr_name}</strong><br>{safe_company_name}</p>
    </td></tr>
    <tr><td style="padding:18px 40px;background:#f7faf8;color:#789086;font-size:12px;line-height:1.6;">本邮件为录用意向通知，具体录用条件以双方后续确认或签署的正式文件为准。</td></tr>
  </table>
</td></tr></table></body></html>"""


async def _send_offer_email(
    request: Request,
    pipeline_id: str,
    candidate_id: str,
    candidate_name: str,
) -> dict:
    """Send an offer through the current HR user's configured mailbox."""
    try:
        from app.db import get_candidate_email, get_company_config
        from app.email_accounts import get_account
        from app.email_sender import send_email

        user = require_current_user(request)
        account_row = (
            get_db()
            .execute(
                "SELECT id FROM email_accounts WHERE owner_user_id=%s AND tenant_id=%s LIMIT 1",
                (str(user.get("id")), tenant_id_for_user(user)),
            )
            .fetchone()
        )
        if not account_row:
            return {"status": "skipped", "message": "当前 HR 尚未配置发信邮箱"}

        mailbox = get_account(account_row["id"], user, include_secret=True, permission="read")
        sender_email = str(user.get("hr_contact") or mailbox.get("email_address") or "").strip()
        smtp_config = {
            "host": mailbox.get("smtp_host"),
            "port": mailbox.get("smtp_port"),
            "security": mailbox.get("smtp_security") or "ssl",
            "username": mailbox.get("username") or sender_email,
            "from_email": sender_email,
            "password": mailbox.get("credential") or "",
            "from_name": user.get("display_name", "") or "招聘团队",
        }
        if any(not str(smtp_config.get(key) or "").strip() for key in ("host", "username", "password")):
            return {"status": "skipped", "message": "HR 发信邮箱配置不完整"}

        candidate_email = get_candidate_email("", pipeline_id, candidate_id)
        if not candidate_email:
            return {"status": "skipped", "message": "没有候选人邮箱"}

        pipeline = get_pipeline(pipeline_id) or {}
        role = str(pipeline.get("role") or "").strip()
        company_config = get_company_config() or {}
        company_name = str(company_config.get("company_name") or "招聘团队").strip()
        hr_name = str(user.get("display_name") or "招聘团队").strip()
        result = await send_email(
            to_email=candidate_email,
            to_name=candidate_name,
            subject=f"录用 Offer - {role or '拟录用岗位'} - {candidate_name}",
            body=_render_offer_email(candidate_name, role, company_name, hr_name),
            is_html=True,
            smtp_config=smtp_config,
        )
        return {"status": "sent" if result.success else "failed", "message": result.error or ""}
    except Exception as error:
        logger.warning("Offer email failed for %s/%s: %s", pipeline_id, candidate_id, error)
        return {"status": "failed", "message": str(error)}


router = APIRouter(
    prefix="/api/mass-interview",
    tags=["mass-interview"],
    dependencies=[Depends(require_pipeline_path_access)],
)

# 并发控制：生成问题时最多同时执行 20 个 LLM 调用
_question_semaphore = asyncio.Semaphore(20)


def _positive_env_int(name: str, default: int, minimum: int) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        logger.warning("Invalid integer environment variable %s; using %s", name, default)
        return default


_VIDEO_MIN_BYTES = 1024
_VIDEO_MAX_BYTES = _positive_env_int("MASS_INTERVIEW_VIDEO_MAX_MB", 512, 1) * 1024 * 1024
_DIRECT_UPLOAD_EXPIRES_SECONDS = _positive_env_int("MASS_INTERVIEW_UPLOAD_EXPIRES_SECONDS", 1800, 300)
_DIRECT_UPLOAD_COMPLETION_GRACE_SECONDS = 15 * 60
_ALLOWED_VIDEO_CONTENT_TYPES = {"video/webm", "video/mp4", "video/ogg", "video/quicktime"}
_direct_upload_tasks: dict[str, asyncio.Task] = {}
MASS_INTERVIEW_LEASE_SECONDS = 30


def _lease_expiry() -> str:
    return (datetime.now() + timedelta(seconds=MASS_INTERVIEW_LEASE_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")


def _require_interview_lease(session: dict, client_id: str | None) -> None:
    owner = str(session.get("active_client_id") or "")
    expires = _parse_db_ts(session.get("lease_expires_at"))
    requested = _lease_client_id(client_id)
    if not owner or (expires and expires < datetime.now()):
        raise HTTPException(409, "面试会话未被当前客户端占用，请重新打开面试链接")
    if requested != owner:
        raise HTTPException(409, "该面试已在其他设备或窗口进行")


def _claim_interview_lease(token: str, client_id: str) -> dict:
    client_id = _lease_client_id(client_id)
    if not client_id:
        raise HTTPException(400, "缺少面试客户端标识")
    conn = get_db()
    row = conn.execute("SELECT * FROM interview_sessions WHERE token=%s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "Session not found")
    session = dict(row)
    if _effective_interview_status(session) == "expired":
        raise HTTPException(410, "面试链接已过期")
    if session.get("status") in ("completed", "evaluated"):
        raise HTTPException(409, "面试已完成")
    now = datetime.now()
    expiry = _lease_expiry()
    result = conn.execute(
        "UPDATE interview_sessions SET active_client_id=%s, lease_expires_at=%s, status=CASE WHEN status='invited' THEN 'started' ELSE status END, started_at=CASE WHEN COALESCE(started_at,'')='' THEN %s ELSE started_at END WHERE token=%s AND (COALESCE(active_client_id,'')='' OR lease_expires_at < %s OR active_client_id=%s)",
        (client_id, expiry, now_db_string(), token, now.strftime("%Y-%m-%d %H:%M:%S"), client_id),
    )
    if getattr(result, "rowcount", 1) == 0:
        conn.rollback()
        raise HTTPException(409, "该面试已在其他设备或窗口进行")
    conn.commit()
    return {"status": "claimed", "client_id": client_id, "lease_expires_at": expiry}


class DirectVideoUploadPrepareRequest(BaseModel):
    """Metadata used to create a tightly scoped OSS browser-upload policy."""

    model_config = ConfigDict(extra="forbid")

    filename: str = Field(default="interview.webm", min_length=1, max_length=255)
    content_type: str = Field(default="video/webm", min_length=1, max_length=128)
    size_bytes: int = Field(ge=_VIDEO_MIN_BYTES, le=_VIDEO_MAX_BYTES)


class DirectVideoTimestamp(BaseModel):
    model_config = ConfigDict(extra="forbid")

    q: int = Field(ge=0, le=100)
    start: float = Field(ge=0, le=24 * 60 * 60)
    end: Optional[float] = Field(default=None, ge=0, le=24 * 60 * 60)


class DirectVideoUploadCompleteRequest(BaseModel):
    """Completion proof sent only after the browser receives a successful OSS response."""

    model_config = ConfigDict(extra="forbid")

    object_key: str = Field(min_length=1, max_length=512)
    upload_token: str = Field(min_length=20, max_length=4096)
    timestamps: list[DirectVideoTimestamp] = Field(default_factory=list, max_length=100)


def _generate_token() -> str:
    """Generate a unique interview token."""
    return secrets.token_urlsafe(24)


def _build_invite_url(token: str, base_url: str = "") -> str:
    """Build the interview URL for a candidate."""
    return f"/mass-interview/{token}"


def _session_blocks_launch(session: dict) -> bool:
    """Whether this session should prevent a new launch for the same candidate."""
    status = session.get("status")
    if status == "expired":
        return False
    if status in ("completed", "evaluated"):
        return True

    expires_at = _parse_db_ts(session.get("expires_at"))
    if expires_at is None:
        return True
    return datetime.now() <= expires_at


def _session_to_invite_payload(session: dict) -> dict:
    """Serialize an existing interview session for the launch response."""
    return {
        "token": session.get("token"),
        "pipeline_id": session.get("pipeline_id"),
        "candidate_id": session.get("candidate_id"),
        "candidate_name": session.get("candidate_name"),
        "status": session.get("status"),
        "invite_sent_at": session.get("invite_sent_at", ""),
        "total_questions": session.get("total_questions"),
        "expires_at": session.get("expires_at"),
        "invite_url": _build_invite_url(session.get("token", "")),
    }


def _build_video_questions(reviewed_questions: list, fallback_questions: list | None = None) -> list[dict]:
    """将小面已审核题写入视频会话，并保留旧调用方的降级参数。"""
    video_questions = []
    for reviewed in reviewed_questions:
        if not isinstance(reviewed, dict):
            continue
        if fallback_questions is not None:
            # Compatibility for callers that still provide the former fallback
            # question list; normal launches use the reviewed snapshot below.
            question = {
                "question": reviewed.get("follow_up") or reviewed.get("question", ""),
                "type": reviewed.get("type", ""),
                "time_limit_seconds": 180,
                "answer_mode": "video",
                "assessment_modality": "video_interview",
                "focus": reviewed.get("competency_ref", ""),
            }
            if "expected_points" in reviewed:
                question["expected_points"] = reviewed["expected_points"]
            if "scoring_rubric" in reviewed:
                question["scoring_rubric"] = reviewed["scoring_rubric"]
        else:
            # Copy the saved 小面 question object instead of rebuilding it from
            # an LLM fallback or follow_up. Both written-test and video sessions
            # must use the same question snapshot.
            question = dict(reviewed)
            question.setdefault("answer_mode", "video")
            question["assessment_modality"] = "video_interview"
        video_questions.append(question)
    return video_questions


async def _generate_tts(text: str, object_key: str) -> str:
    """Generate TTS audio via CosyVoice SDK, upload to OSS, return signed URL.

    Args:
        text: Text to synthesize (max 300 chars)
        object_key: OSS object key, e.g. 'tts/{pid}/q0.mp3'

    Returns:
        Signed OSS URL for the generated audio file
    """
    import tempfile

    from app.config import (
        DASHSCOPE_API_KEY,
        TTS_FORMAT,
        TTS_MODEL,
        TTS_VOICE,
    )

    if not DASHSCOPE_API_KEY:
        logger.warning("DASHSCOPE_API_KEY not set, TTS unavailable")
        return ""

    # 截断文本，避免 TTS 内容过长
    text = text[:300]

    try:
        # 使用 DashScope SDK SpeechSynthesizer（cosyvoice-v2 + longxiaochun_v2）
        def _sync_tts():
            import dashscope
            from dashscope.audio.tts_v2 import SpeechSynthesizer

            dashscope.api_key = DASHSCOPE_API_KEY
            synthesizer = SpeechSynthesizer(
                model=TTS_MODEL,
                voice=TTS_VOICE,
            )
            return synthesizer.call(text)

        audio_data = await asyncio.wait_for(
            asyncio.to_thread(_sync_tts),
            timeout=30.0,
        )

        if not audio_data or len(audio_data) == 0:
            logger.warning("TTS returned empty audio")
            return ""

        # 保存到临时文件并上传至 OSS
        with tempfile.NamedTemporaryFile(suffix=f".{TTS_FORMAT}", delete=False) as tmp:
            tmp.write(audio_data)
            tmp_path = tmp.name

        try:
            oss_url = await _upload_to_oss(tmp_path, object_key)
            logger.info(f"TTS generated: {len(audio_data)} bytes -> {object_key}")
            return oss_url
        finally:
            try:
                os.remove(tmp_path)
            except Exception:
                pass

    except Exception as e:
        logger.error(f"TTS generation failed: {e}")

    return ""


# ── 1. 发起面试 ─────────────────────────────────────────────


@router.post("/launch")
async def api_launch_mass_interview(data: dict, request: Request = None):
    """HR clicks "发起百人面试" — creates interview sessions for all matched candidates.

    Input: { pipeline_id, expires_hours?: 72 }
    question_count is now auto-derived from template (no longer specified by HR).
    个性化题目由候选人端逐题播报，不复用其他候选人的缓存音频。
    """
    pipeline_id = data.get("pipeline_id", "")
    # Internal state-machine dispatches have already authorized the owning
    # pipeline and call this compatibility entry point without an HTTP request.
    pipeline = (
        require_pipeline_access(request, str(pipeline_id)) if request is not None else get_pipeline(str(pipeline_id))
    )
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    expires_hours = data.get("expires_hours", 48)

    # 面试方式是流水线级别的选择：一旦该流水线生成过笔试链接，后续批次不能切换为视频。
    written_exists = (
        get_db()
        .execute(
            "SELECT 1 FROM written_test_sessions WHERE pipeline_id=%s LIMIT 1",
            (pipeline_id,),
        )
        .fetchone()
    )
    if written_exists:
        raise HTTPException(400, "该流水线已选择在线笔试，后续批次只能继续生成笔试链接")

    candidates = get_candidates(pipeline_id)
    from app.screening_workflow import confirmed_screening_candidates

    confirmed_candidates, screening_context = confirmed_screening_candidates(pipeline_id, candidates)
    if screening_context["is_modern"] and screening_context["workflow_status"] != "confirmed":
        raise HTTPException(400, "小筛尚未确认，请先完成候选人复核和定版")
    if screening_context["is_modern"]:
        eligible = confirmed_candidates or []
    else:
        # 没有新版小筛记录的旧流水线沿用原状态兼容。
        eligible = [
            candidate
            for candidate in candidates
            if str(candidate.get("screening_decision") or "").strip().lower() == "passed"
            or (
                not candidate.get("match_batch")
                and candidate.get("status") in ("shortlist", "shortlisted", "passed", "interview")
            )
        ]
    requested_ids = {str(value) for value in (data.get("candidate_ids") or []) if value is not None}
    if requested_ids and screening_context["is_modern"]:
        eligible_ids = {str(candidate.get("id")) for candidate in eligible}
        ineligible_requested = requested_ids - eligible_ids
        if ineligible_requested:
            raise HTTPException(400, "仅已确认通过筛选的候选人可以发起视频面试")
    if requested_ids:
        eligible = [candidate for candidate in eligible if str(candidate.get("id")) in requested_ids]
    if not eligible:
        raise HTTPException(400, "没有符合条件的候选人（需要已通过筛选的候选人）")
    selected_eligible_ids = {str(candidate.get("id")) for candidate in eligible}

    # 获取职位信息
    role = pipeline.get("role", "店员")
    stages = get_stages(pipeline_id)

    # 如果可用，从 interview_gen 阶段获取面试问题
    iv_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    iv_output = parse_stage_output(iv_stage) if iv_stage else {}
    existing_interviews = iv_output.get("interviews", [])
    existing_interviews_by_candidate = {
        str(iv.get("candidate_id")): iv for iv in existing_interviews if isinstance(iv, dict) and iv.get("candidate_id")
    }

    try:
        assessment_flow.ensure_single_step_plan(pipeline_id, "video_interview", actor_id="video_interview_launch")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    # 去重：排除已有有效 session 的候选人。一个候选人按最新一条有效 session 处理。
    existing_sessions = get_interview_sessions(pipeline_id)
    existing_by_candidate = {}
    for session in existing_sessions:
        if not _session_blocks_launch(session):
            continue
        candidate_id = session.get("candidate_id")
        if candidate_id:
            existing_by_candidate[candidate_id] = session

    existing_cids = {str(value) for value in existing_by_candidate}

    # Candidates with an active written-test invitation stay on that path;
    # never create a second video invitation for them.
    written_rows = (
        get_db()
        .execute(
            "SELECT DISTINCT candidate_id FROM written_test_sessions WHERE pipeline_id=%s",
            (pipeline_id,),
        )
        .fetchall()
    )
    written_cids = {str(row["candidate_id"]) for row in written_rows if row["candidate_id"] is not None}

    new_eligible = [
        c for c in eligible if str(c.get("id")) not in existing_cids and str(c.get("id")) not in written_cids
    ]
    skipped = len(eligible) - len(new_eligible)

    if not new_eligible:
        existing_payloads = [
            _session_to_invite_payload(session)
            for candidate_id, session in existing_by_candidate.items()
            if str(candidate_id) in selected_eligible_ids
        ]
        return {
            "status": "existing",
            "pipeline_id": pipeline_id,
            "total": 0,
            "skipped": skipped,
            "question_count": iv_output.get("generated_count") or 0,
            "tts_urls": [],
            "sessions": existing_payloads,
        }

    eligible = new_eligible

    # 强制人工审核：候选人必须已有预生成题且已通过审核，否则禁止发起（不静默实时生成）
    iv_cid_set = set(existing_interviews_by_candidate)
    missing = [c for c in eligible if str(c.get("id")) not in iv_cid_set]
    if missing:
        names = "、".join(c.get("name", c.get("id", "")) for c in missing[:10])
        raise HTTPException(
            400,
            f"以下候选人还没有面试题，请先在小面批量生成并完成人工审核后再发起视频面试：{names}",
        )
    from app import question_review as qr

    pending = await qr.check_reviewed_for(pipeline_id, [c.get("id") for c in eligible])
    if pending:
        names = "、".join(n for _, n in pending)
        raise HTTPException(
            400,
            f"以下候选人题目未通过人工审核，请先到小面完成题目审核后再发起视频面试：{names}",
        )
    from hr_harness.agents.mass_interview_agent import MassInterviewAgent

    agent = MassInterviewAgent()
    template = agent.get_template(role)
    # 题数优先取审核页设置的 generated_count，其次模板默认
    question_count = iv_output.get("generated_count") or template.get("question_count", 2)

    created_sessions = []
    expires_at = (datetime.now() + timedelta(hours=expires_hours)).strftime("%Y-%m-%d %H:%M:%S")

    async def _create_one(candidate: dict):
        """Create one interview session with personalized questions."""
        async with _question_semaphore:
            name = candidate.get("name", "候选人")
            resume_text = candidate.get("resume_text", "")
            years = str(candidate.get("years_experience", ""))

            reviewed = existing_interviews_by_candidate.get(str(candidate.get("id"))) or {}
            reviewed_questions = reviewed.get("questions", [])
            questions = _build_video_questions(reviewed_questions)

            token = _generate_token()
            stream_name = f"candidate_{candidate['id']}"

            create_interview_session(
                pipeline_id=pipeline_id,
                candidate_id=candidate["id"],
                candidate_name=name,
                token=token,
                questions=questions,
                total_questions=len(questions),
                expires_at=expires_at,
                stream_name=stream_name,
                rtmp_push_url="",
                hls_play_url="",
                flv_play_url="",
            )
            session = {
                "token": token,
                "pipeline_id": pipeline_id,
                "candidate_id": candidate["id"],
                "candidate_name": name,
                "status": "invited",
                "invite_sent_at": "",
                "questions": questions,
                "total_questions": len(questions),
                "expires_at": expires_at,
            }
            return {**session, "invite_url": _build_invite_url(token)}

    # 使用信号量并发创建会话
    tasks = [_create_one(c) for c in eligible]
    created_sessions = await asyncio.gather(*tasks)

    # 把已经存在的有效链接一起返回，前端刷新后可继续复制/发邮件，而不需要重复发起。
    newly_created_ids = {str(session.get("candidate_id")) for session in created_sessions}
    existing_payloads = [
        _session_to_invite_payload(session)
        for candidate_id, session in existing_by_candidate.items()
        if str(candidate_id) in selected_eligible_ids and str(candidate_id) not in newly_created_ids
    ]
    response_sessions = created_sessions + existing_payloads

    # 保存系统消息
    save_message(
        pipeline_id,
        "system",
        f"🚀 面试邀请已发起：{len(created_sessions)} 位候选人收到面试邀请"
        f"{'，' + str(skipped) + ' 人已有链接已跳过' if skipped else ''}\n"
        f"共{question_count}道题 · 链接{expires_hours}小时内有效",
        card_type="mass_interview_launched",
        card_data={"sessions": len(created_sessions), "question_count": question_count, "skipped": skipped},
    )

    return {
        "status": "launched",
        "pipeline_id": pipeline_id,
        "total": len(created_sessions),
        "skipped": skipped,
        "question_count": question_count,
        "tts_urls": [],
        "sessions": response_sessions,
    }


# ── 1b. 准备 TTS ────────────────────────────────────────────


@router.post("/{pipeline_id}/prepare-tts")
async def api_prepare_tts(pipeline_id: str):
    """Pre-generate TTS audio for all questions in this pipeline's interview.

    Returns { tts_urls: ["https://oss.../q0.mp3", ...] }
    """
    sessions = get_interview_sessions(pipeline_id)
    if not sessions:
        raise HTTPException(404, "No interview sessions found for this pipeline")

    # 从模板获取固定问题，而不是从会话中获取
    pipeline = get_pipeline(pipeline_id)
    role = pipeline.get("role", "店员") if pipeline else "店员"

    from hr_harness.agents.mass_interview_agent import MassInterviewAgent

    agent = MassInterviewAgent()
    template = agent.get_template(role)
    questions = template.get("questions", [])

    if not questions:
        # 降级处理：从最近的会话读取
        sessions = get_interview_sessions(pipeline_id)
        if sessions:
            latest = sessions[-1]
            q_raw = latest.get("questions", "[]")
            if isinstance(q_raw, str):
                try:
                    questions = json.loads(q_raw)
                except (json.JSONDecodeError, TypeError):
                    questions = []
            else:
                questions = q_raw

    if not questions:
        raise HTTPException(400, "No questions found")

    from app.infrastructure.config import settings
    from app.media_storage import join_storage_key

    tts_urls = []
    tts_dir = join_storage_key(settings.oss_video_prefix, "tts", pipeline_id)

    for i, q in enumerate(questions):
        prefix = q.get("tts_prefix", "")
        text = q.get("text", "") or q.get("question", "")
        full_text = f"{prefix} {text}".strip() if prefix else text

        object_key = f"{tts_dir}/q{i}.mp3"

        try:
            audio_url = await _generate_tts(full_text, object_key)
            tts_urls.append(audio_url or "")
        except Exception as e:
            logger.error(f"TTS generation failed for q{i}: {e}")
            tts_urls.append("")  # 空值表示降级使用 speechSynthesis

    # 将 tts_urls 存入流水线元数据以便复用
    try:
        from app.db import get_db

        conn = get_db()
        conn.execute(
            "UPDATE pipelines SET tts_urls = %s WHERE id = %s",
            (json.dumps(tts_urls, ensure_ascii=False), pipeline_id),
        )
        conn.commit()
    except Exception:
        pass

    return {"tts_urls": tts_urls, "question_count": len(questions)}


# ── 2. 状态 ─────────────────────────────────────────────────


def _validate_owner_filter(request: Request, pipeline_id: str, owner_user_id: str) -> None:
    """Ensure an HR-filtered request cannot read a different owner's pipeline."""
    selected_owner = str(owner_user_id or "").strip()
    if not selected_owner:
        return
    user = require_current_user(request)
    if not is_tenant_admin(user):
        if selected_owner != str(user.get("id") or ""):
            raise HTTPException(status_code=404, detail="Pipeline not found")
        return
    row = (
        get_db()
        .execute(
            "SELECT owner_user_id FROM pipelines WHERE id=%s AND tenant_id=%s",
            (pipeline_id, tenant_id_for_user(user)),
        )
        .fetchone()
    )
    if not row or str(row["owner_user_id"] or "") != selected_owner:
        raise HTTPException(status_code=404, detail="Pipeline not found")


@router.get("/{pipeline_id}/status")
async def api_mass_interview_status(
    pipeline_id: str,
    request: Request,
    owner_user_id: str = Query(default=""),
    include_unsent: bool = Query(default=False),
):
    """HR polls for real-time progress."""
    _validate_owner_filter(request, pipeline_id, owner_user_id)
    # 生成链接不等于发送邀请：面试中心只展示已经实际发出邀请的会话。
    all_sessions = get_interview_sessions(pipeline_id)
    # The XiaoMian workspace needs to show generated links before the HR has
    # sent email. The dashboard keeps the historical default of only showing
    # actually sent invitations.
    sessions = (
        all_sessions
        if include_unsent
        else [session for session in all_sessions if str(session.get("invite_sent_at") or "").strip()]
    )
    stats = get_session_stats(pipeline_id, sessions)

    # 解析用于展示的 JSON 字段，并在读取时反映已过期状态。
    for s in sessions:
        s["status"] = _effective_interview_status(s)
        s["invite_url"] = _build_invite_url(str(s.get("token") or ""))
        for field in ("questions", "answers"):
            if isinstance(s.get(field), str):
                try:
                    s[field] = json.loads(s[field])
                except (json.JSONDecodeError, TypeError):
                    pass

    return {
        "pipeline_id": pipeline_id,
        "stats": stats,
        "sessions": sessions,
    }


@router.get("/{pipeline_id}/schedules")
async def api_mass_interview_schedules(pipeline_id: str):
    """Return scheduled follow-up interviews for the selected pipeline."""
    return {
        "pipeline_id": pipeline_id,
        "schedules": get_interview_schedules(pipeline_id),
    }


# ── 3. 打开面试 ─────────────────────────────────────────────


@router.get("/session/{token}")
async def api_open_interview(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    """Candidate opens the interview link. Returns questions and status."""
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "无效的面试链接")

    # 检查是否过期；打开链接是明确的状态维护入口，可以持久化 expired。
    if _effective_interview_status(session) == "expired":
        update_interview_session(token, {"status": "expired"})
        from fastapi.responses import JSONResponse

        pipeline = get_pipeline(session.get("pipeline_id", ""))
        return JSONResponse(
            status_code=410,
            content={
                "detail": "面试链接已过期",
                "candidate_name": session.get("candidate_name", ""),
                "role": pipeline.get("role", "") if pipeline else "",
                "expires_at": session.get("expires_at", ""),
            },
        )

    # 通过复制链接发送时没有 SMTP 回执；首次打开链接即视为已邀请，
    # 这样无邮箱候选人也能进入面试中心，但纯生成、从未打开的链接仍不会展示。
    if not str(session.get("invite_sent_at") or "").strip():
        invited_at = now_db_string()
        update_interview_session(token, {"invite_sent_at": invited_at})
        session["invite_sent_at"] = invited_at

    # Opening the candidate page claims the server-side lease atomically.
    if _lease_client_id(client_id) and session.get("status") not in ("completed", "evaluated"):
        _claim_interview_lease(token, client_id)
        session = get_interview_session(token) or session

    # 首次访问时标记为已开始
    if session.get("status") == "invited":
        update_interview_session(
            token,
            {
                "status": "started",
                "started_at": now_db_string(),
            },
        )
        session["status"] = "started"
        await _broadcast_mass_event(session.get("pipeline_id", ""), "session_updated", session, status="started")

    # 解析 JSON 字段
    for field in ("questions", "answers", "dimension_scores", "device_info"):
        if isinstance(session.get(field), str):
            try:
                session[field] = json.loads(session[field])
            except (json.JSONDecodeError, TypeError):
                session[field] = [] if field in ("questions", "answers") else {}

    # 从流水线获取职位
    pipeline = get_pipeline(session.get("pipeline_id", ""))
    role = pipeline.get("role", "") if pipeline else ""

    # 从JD stage获取公司名，fallback 到公司配置
    company_name = ""
    company_logo = ""
    brand_color = ""
    from app.db import get_company_config

    company_config = get_company_config()
    stages = get_stages(session.get("pipeline_id", ""))
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if jd_stage:
        jd_out = parse_stage_output(jd_stage)
        jd_data = jd_out.get("jd", {})
        if isinstance(jd_data, dict):
            company_name = jd_data.get("company_name", "") or jd_data.get("company", "")
    if not company_name:
        company_name = company_config.get("company_name", "")
    company_logo = company_config.get("company_logo", "")
    brand_color = company_config.get("brand_color", "")

    return {
        "token": token,
        "candidate_name": session.get("candidate_name", ""),
        "role": role,
        "company_name": company_name,
        "company_logo": company_logo,
        "brand_color": brand_color,
        "status": session.get("status", "invited"),
        "questions": _public_questions(session.get("questions", [])),
        "current_question": session.get("current_question", 0),
        "total_questions": session.get("total_questions", 2),
        "question_count": session.get("total_questions", 2),
        "answers": session.get("answers", []),
        "estimated_minutes": session.get("total_questions", 2) * 4,
        "expires_at": session.get("expires_at", ""),
        # 阿里云直播地址
        "rtmp_push_url": session.get("rtmp_push_url", ""),
        "hls_play_url": session.get("hls_play_url", ""),
        "flv_play_url": session.get("flv_play_url", ""),
        "stream_name": session.get("stream_name", ""),
        # TTS 预生成音频URL
        "tts_urls": _get_tts_urls(session.get("pipeline_id", ""), session),
    }


@router.post("/session/{token}/claim")
async def api_claim_interview_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    return _claim_interview_lease(token, client_id)


@router.post("/session/{token}/heartbeat")
async def api_heartbeat_interview_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    _require_interview_lease(session, client_id)
    expiry = _lease_expiry()
    conn = get_db()
    result = conn.execute(
        "UPDATE interview_sessions SET lease_expires_at=%s, updated_at=NOW() WHERE token=%s AND active_client_id=%s",
        (expiry, token, _lease_client_id(client_id)),
    )
    if getattr(result, "rowcount", 1) == 0:
        conn.rollback()
        raise HTTPException(409, "该面试已在其他设备或窗口进行")
    conn.commit()
    return {"status": "ok", "lease_expires_at": expiry}


@router.post("/session/{token}/release")
async def api_release_interview_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    owner = str(session.get("active_client_id") or "")
    if owner and owner != _lease_client_id(client_id):
        raise HTTPException(409, "该面试已在其他设备或窗口进行")
    conn = get_db()
    conn.execute(
        "UPDATE interview_sessions SET active_client_id='', lease_expires_at='', updated_at=NOW() WHERE token=%s",
        (token,),
    )
    conn.commit()
    return {"status": "released"}


# ── 6. 排名 ─────────────────────────────────────────────────


@router.get("/{pipeline_id}/ranking")
async def api_mass_interview_ranking(
    pipeline_id: str,
    request: Request,
    owner_user_id: str = Query(default=""),
    start_from: str = Query(default=""),
    start_to: str = Query(default=""),
):
    """HR views ranked interview results."""
    _validate_owner_filter(request, pipeline_id, owner_user_id)
    results = get_session_ranking(pipeline_id, start_from=start_from, start_to=start_to)
    return {
        "pipeline_id": pipeline_id,
        "total": len(results),
        "ranking": results,
    }


# ── 7. 标记候选人 ───────────────────────────────────────────


def _persist_candidate_mark(
    pipeline_id: str,
    candidate_id: str,
    new_status: str,
    note: str,
    message: str,
    schedule: Optional[dict] = None,
) -> str:
    """Persist the HR decision and optional review schedule in one transaction."""
    schedule_id = ""
    with transaction() as conn:
        candidate_exists = conn.execute(
            "SELECT 1 FROM candidates WHERE id=%s AND pipeline_id=%s",
            (candidate_id, pipeline_id),
        ).fetchone()
        if not candidate_exists:
            raise HTTPException(404, "Candidate not found")

        conn.execute(
            "UPDATE candidates SET status=%s, hr_note=%s WHERE id=%s AND pipeline_id=%s",
            (new_status, note, candidate_id, pipeline_id),
        )
        conn.execute(
            """UPDATE interview_schedules SET status='cancelled'
               WHERE pipeline_id=%s AND candidate_id=%s AND status='scheduled'""",
            (pipeline_id, candidate_id),
        )

        if schedule:
            schedule_id = (
                "sch_" + hashlib.md5(f"{pipeline_id}_{candidate_id}_{schedule['date']}".encode()).hexdigest()[:8]
            )
            conn.execute(
                """REPLACE INTO interview_schedules
                   (id, pipeline_id, candidate_id, date, time, interviewer, method, round, status, notes, created_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'scheduled', %s, NOW())""",
                (
                    schedule_id,
                    pipeline_id,
                    candidate_id,
                    schedule["date"],
                    schedule.get("time", ""),
                    schedule["interviewer"],
                    schedule.get("method", "online"),
                    schedule.get("round", "复试"),
                    schedule.get("notes", ""),
                ),
            )

        save_message(pipeline_id, "system", message, conn=conn)
    return schedule_id


def _validate_future_review_schedule(schedule: dict) -> None:
    """Reject malformed or elapsed follow-up interview slots before persisting them."""
    date_value = str(schedule.get("date") or "").strip()
    time_value = str(schedule.get("time") or "09:00").strip()
    try:
        scheduled_at = datetime.strptime(f"{date_value} {time_value}", "%Y-%m-%d %H:%M").replace(tzinfo=SHANGHAI_TZ)
    except ValueError as error:
        raise HTTPException(400, "复试日期或时间格式无效") from error
    if scheduled_at <= datetime.now(SHANGHAI_TZ):
        raise HTTPException(400, "复试日期和时间必须晚于当前时间")


@router.post("/{pipeline_id}/mark")
async def api_mark_candidate(pipeline_id: str, data: dict, request: Request):
    """HR marks a candidate: pass / review / reject."""
    candidate_id = data.get("candidate_id", "")
    action = data.get("action", "")  # 操作：pass、review、reject
    note = data.get("note", "")
    schedule = data.get("schedule")

    if action not in ("pass", "review", "reject"):
        raise HTTPException(400, "action must be pass, review, or reject")
    if schedule and action != "review":
        raise HTTPException(400, "schedule is only allowed for review action")
    if schedule and (not schedule.get("date") or not schedule.get("interviewer")):
        raise HTTPException(400, "review schedule requires date and interviewer")
    if schedule:
        _validate_future_review_schedule(schedule)

    status_map = {"pass": "passed", "review": "review", "reject": "rejected"}
    new_status = status_map[action]

    # 保存消息
    labels = {"pass": "✅ 通过", "review": "🔄 复试", "reject": "❌ 淘汰"}
    schedule_id = _persist_candidate_mark(
        pipeline_id,
        candidate_id,
        new_status,
        note,
        f"{labels[action]} 候选人 {candidate_id}" + (f" — {note}" if note else ""),
        schedule,
    )

    result = {"status": "marked", "candidate_id": candidate_id, "action": action}
    if schedule_id:
        result["schedule_id"] = schedule_id

    # 日程先在本地事务中落库，再同步到企业微信。外部接口失败不会撤销已保存的
    # 排期，因此客户端会得到明确的 failed 状态，HR 可据此处理或重新安排。
    if schedule:
        try:
            from app.wecom_schedule import WeComScheduleError, create_schedule_if_enabled

            result["wecom_schedule"] = await asyncio.to_thread(create_schedule_if_enabled, schedule)
        except WeComScheduleError as error:
            logger.warning("WeCom schedule creation failed for %s/%s: %s", pipeline_id, candidate_id, error)
            result["wecom_schedule"] = {"status": "failed", "message": str(error)}
        result["email_notification"] = await _send_retest_schedule_email(request, pipeline_id, candidate_id, schedule)

    # 通过 → 自动传递面试数据给小评(report stage)
    if action == "pass":
        try:
            from app.db import get_stages, update_stage

            stages = get_stages(pipeline_id)
            report_stage = next((s for s in stages if s["stage_id"] == "report"), None)
            if report_stage:
                sessions = get_interview_sessions(pipeline_id)
                passed_session = next(
                    (s for s in sessions if s.get("candidate_id") == candidate_id and s.get("status") == "completed"),
                    None,
                )
                if passed_session:
                    artifact = {
                        "candidate_id": candidate_id,
                        "interview_score": passed_session.get("interview_score", 0),
                        "dimension_scores": passed_session.get("dimension_scores", {}),
                        "answers": passed_session.get("answers", []),
                        "hr_action": "passed",
                    }
                    update_stage(pipeline_id, "report", "ready", output=artifact)
            result["next_step"] = "report"
        except Exception:
            pass

    return result


@router.post("/{pipeline_id}/offer")
async def api_send_offer(pipeline_id: str, data: dict, request: Request):
    """Send an offer to one candidate and mark them offered only after delivery succeeds."""
    candidate_id = str(data.get("candidate_id") or "").strip()
    if not candidate_id:
        raise HTTPException(400, "candidate_id is required")

    candidate_row = (
        get_db()
        .execute(
            "SELECT id, name FROM candidates WHERE id=%s AND pipeline_id=%s",
            (candidate_id, pipeline_id),
        )
        .fetchone()
    )
    if not candidate_row:
        raise HTTPException(404, "Candidate not found")

    candidate_name = str(dict(candidate_row).get("name") or candidate_id).strip()
    result = await _send_offer_email(request, pipeline_id, candidate_id, candidate_name)
    response = {**result, "candidate_id": candidate_id}
    if result["status"] != "sent":
        return response

    with transaction() as conn:
        update_candidate(candidate_id, {"status": "offered"}, conn=conn)
        save_message(pipeline_id, "system", f"🎯 已向候选人 {candidate_name} 发送录用 Offer", conn=conn)
    return response


# ── 7b. 延长会话 ────────────────────────────────────────────


@router.post("/session/{token}/extend")
async def api_extend_session(token: str, data: dict = Body(default={})):
    """续期过期的面试链接，延长expires_at"""
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")

    extend_hours = data.get("extend_hours", 24)

    # 从当前时间（不是原过期时间）开始延长
    new_expires = (datetime.now() + timedelta(hours=extend_hours)).strftime("%Y-%m-%d %H:%M:%S")

    update_interview_session(
        token,
        {
            "expires_at": new_expires,
            "status": "invited" if session.get("status") == "expired" else session.get("status"),
        },
    )

    return {
        "token": token,
        "candidate_name": session.get("candidate_name", ""),
        "new_expires_at": new_expires,
        "status": "extended",
    }


@router.post("/{pipeline_id}/batch-extend")
async def api_batch_extend(pipeline_id: str, data: dict):
    """批量续期指定候选人的过期 session。"""
    extend_hours = data.get("extend_hours", 24)
    candidate_ids = {str(candidate_id) for candidate_id in data.get("candidate_ids", []) if candidate_id}
    sessions = get_interview_sessions(pipeline_id)
    expired = [
        session
        for session in sessions
        if session.get("status") == "expired"
        and (not candidate_ids or str(session.get("candidate_id") or "") in candidate_ids)
    ]

    new_expires = (datetime.now() + timedelta(hours=extend_hours)).strftime("%Y-%m-%d %H:%M:%S")
    extended = []
    for s in expired:
        update_interview_session(
            s["token"],
            {
                "expires_at": new_expires,
                "status": "invited",
            },
        )
        extended.append(
            {
                "token": s["token"],
                "candidate_id": s.get("candidate_id", ""),
                "candidate_name": s.get("candidate_name", ""),
            }
        )

    return {"extended": len(extended), "sessions": extended, "new_expires_at": new_expires}


# ── 8. 发送邀请 ─────────────────────────────────────────────


@router.post("/{pipeline_id}/invite")
async def api_send_invites(pipeline_id: str, data: dict, request: Request):
    """Send interview invites in batch.

    Input: { method: "feishu"|"link"|"qrcode"|"email", session_ids?: [...] }
    """
    method = data.get("method", "link")
    session_ids = data.get("session_ids", [])
    requested_invites = data.get("invites", [])

    sessions = get_interview_sessions(pipeline_id)
    # Use the same decoder as the interview-center ranking endpoint.  The
    # written-test table is an independent invitation source and must remain
    # usable when no video session exists for the candidate.
    written_sessions = _get_written_test_sessions(pipeline_id)
    # Dashboard cards submit their own stable candidate_id + current token.
    # Resolve those exact sessions rather than deriving a new link by display
    # name or by a second, potentially stale, candidate lookup.
    requested_by_token = {}
    if isinstance(requested_invites, list):
        for item in requested_invites:
            if not isinstance(item, dict):
                continue
            token = str(item.get("token", "")).strip()
            candidate_id = str(item.get("candidate_id", "")).strip()
            if token:
                requested_by_token[token] = candidate_id
    if requested_by_token:
        sessions = [
            session
            for session in sessions
            if session.get("token") in requested_by_token
            and (
                not requested_by_token[session.get("token")]
                or session.get("candidate_id") == requested_by_token[session.get("token")]
            )
        ]
        written_sessions = [
            session
            for session in written_sessions
            if session.get("token") in requested_by_token
            and (
                not requested_by_token[session.get("token")]
                or session.get("candidate_id") == requested_by_token[session.get("token")]
            )
        ]
    elif session_ids:
        sessions = [s for s in sessions if s.get("token") in session_ids or str(s.get("id")) in session_ids]
        written_sessions = [s for s in written_sessions if s.get("token") in session_ids]

    base_url = str(data.get("base_url", "")).strip().rstrip("/")
    if not base_url:
        # 兼容直接调用接口的场景；反向代理部署时优先使用转发后的公网地址。
        forwarded_host = request.headers.get("x-forwarded-host", "").split(",", 1)[0].strip()
        forwarded_proto = request.headers.get("x-forwarded-proto", "").split(",", 1)[0].strip()
        host = forwarded_host or request.headers.get("host", "")
        scheme = forwarded_proto or request.url.scheme
        base_url = f"{scheme}://{host}" if host else str(request.base_url).rstrip("/")

    invite_links = []
    for s in sessions:
        if s.get("status") == "completed":
            continue
        url = f"{base_url}/mass-interview/{s['token']}"
        invite_links.append(
            {
                "token": s["token"],
                "candidate_id": s.get("candidate_id", ""),
                "candidate_name": s.get("candidate_name", ""),
                "url": url,
                "expires_at": s.get("expires_at", ""),
            }
        )
    for s in written_sessions:
        if s.get("status") == "submitted":
            continue
        invite_links.append(
            {
                "token": s["token"],
                "candidate_id": s.get("candidate_id", ""),
                "candidate_name": s.get("candidate_name", ""),
                "url": f"{base_url}/written-test/{s['token']}",
                "expires_at": s.get("expires_at", ""),
            }
        )

    if method == "link":
        return {"method": "link", "count": len(invite_links), "links": invite_links}

    elif method == "feishu":
        # 通过 feishu_notify 批量发送
        try:
            from app.db import get_company_config
            from app.feishu_notify import send_mass_interview_invite

            company_config = get_company_config()
            sent = 0
            for link in invite_links:
                try:
                    send_mass_interview_invite(
                        chat_id="",
                        candidate_name=link["candidate_name"],
                        role=get_pipeline(pipeline_id).get("role", ""),
                        interview_url=link["url"],
                        expires_at=link.get("expires_at", "")[:16].replace("T", " "),
                        company_name=company_config.get("company_name", ""),
                    )
                    sent += 1
                except Exception:
                    pass
            return {"method": "feishu", "count": len(invite_links), "sent": sent, "links": invite_links}
        except ImportError:
            # 降级为链接模式
            return {
                "method": "link",
                "count": len(invite_links),
                "links": invite_links,
                "warning": "飞书通知模块未就绪，已返回链接列表",
            }

    elif method == "qrcode":
        # 为每个链接生成二维码
        try:
            import base64
            import io

            import qrcode

            for link in invite_links:
                qr = qrcode.QRCode(version=1, box_size=10, border=4)
                qr.add_data(link["url"])
                qr.make(fit=True)
                img = qr.make_image(fill_color="black", back_color="white")
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                link["qrcode_base64"] = base64.b64encode(buf.getvalue()).decode()
        except ImportError:
            pass

        return {"method": "qrcode", "count": len(invite_links), "links": invite_links}

    elif method == "email":
        # 通过 SMTP 邮件批量发送
        try:
            from app.db import get_candidate_email, get_company_config
            from app.email_accounts import EmailDomainError, get_account
            from app.email_sender import DEFAULT_INTERVIEW_INVITE_TEMPLATE, send_interview_invite
            from app.user_mailbox import resolve_user_qr

            # 面试邀请必须使用当前登录 HR 的邮箱账户，不能回退到部署环境中的
            # 固定 SMTP 账号；邮箱授权码只在服务端解密后短暂传入发送器。
            user = require_current_user(request)
            account_row = (
                get_db()
                .execute(
                    "SELECT id FROM email_accounts WHERE owner_user_id=%s AND tenant_id=%s LIMIT 1",
                    (str(user.get("id")), tenant_id_for_user(user)),
                )
                .fetchone()
            )
            if not account_row:
                raise HTTPException(status_code=409, detail="当前账号尚未配置发信邮箱，请在用户与权限中完善邮箱配置")
            try:
                mailbox = get_account(account_row["id"], user, include_secret=True, permission="read")
            except EmailDomainError as exc:
                raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc
            sender_email = str(user.get("hr_contact") or mailbox.get("email_address") or "").strip()
            smtp_config = {
                "host": mailbox.get("smtp_host"),
                "port": mailbox.get("smtp_port"),
                "security": mailbox.get("smtp_security") or "ssl",
                "username": mailbox.get("username") or sender_email,
                "from_email": sender_email,
                "password": mailbox.get("credential") or "",
                "from_name": user.get("display_name", "") or "招聘团队",
            }
            missing = [key for key in ("host", "username", "password") if not str(smtp_config.get(key) or "").strip()]
            if missing:
                raise HTTPException(
                    status_code=409, detail="当前账号邮箱配置不完整，请在用户与权限中填写 SMTP 服务器和授权码"
                )
            logger.info(
                "面试邀请使用当前用户邮箱配置 user=%s account=%s provider=%s host=%s port=%s security=%s",
                user.get("id"),
                account_row["id"],
                mailbox.get("provider"),
                mailbox.get("smtp_host"),
                mailbox.get("smtp_port"),
                mailbox.get("smtp_security"),
            )

            pipeline = get_pipeline(pipeline_id)
            company_config = get_company_config()
            # 公司品牌信息可复用，但投递二维码必须来自当前 HR 的用户级配置。
            user_qr_code = resolve_user_qr(user)
            company_name = company_config.get("company_name", "锅圈食汇")
            role = pipeline.get("role", "") if isinstance(pipeline, dict) else ""
            conn = get_db()

            # 查询邮箱并构建收件人列表
            recipients = []
            skipped_no_email = 0
            for link in invite_links:
                candidate_name = str(link.get("candidate_name", "")).strip()
                # 部分笔试 session 的姓名被模型输出成 "** 陈志远"。邮箱查询沿用
                # dev 的原逻辑，但查询前先去掉 Markdown 装饰字符。
                lookup_name = re.sub(r"^[\s*_#>`~\-]+|[\s*_#>`~\-]+$", "", candidate_name)
                email_addr = get_candidate_email(lookup_name, pipeline_id, str(link.get("candidate_id", "")))
                if not email_addr:
                    skipped_no_email += 1
                    continue
                recipients.append(
                    {
                        "token": link["token"],
                        "invite_type": link.get("invite_type", ""),
                        "email": email_addr,
                        "name": lookup_name,
                        "candidate_name": lookup_name,
                        "role": role,
                        "url": link["url"],
                        "expires_at": link.get("expires_at", ""),
                        "method": "在线笔试" if "/written-test/" in link["url"] else "视频面试",
                    }
                )

            if not recipients:
                return {
                    "method": "email",
                    "count": len(invite_links),
                    "sent": 0,
                    "skipped_no_email": skipped_no_email,
                    "warning": "没有找到候选人邮箱地址，请确认简历中是否包含邮箱",
                    "links": invite_links,
                }

            # 从数据库获取模板
            row = conn.execute(
                "SELECT template FROM communication_templates WHERE id = 'interview_invite_default'"
            ).fetchone()
            template = row["template"] if row else ""
            if not template or "{interview_url}" not in template:
                template = DEFAULT_INTERVIEW_INVITE_TEMPLATE

            # 使用个性化模板分别渲染每封邮件
            sent = 0
            failed = 0
            send_results = []
            for index, recipient in enumerate(recipients):
                result = await send_interview_invite(
                    to_email=recipient["email"],
                    candidate_name=recipient["candidate_name"],
                    role=role,
                    company_name=company_name,
                    company_config=company_config,
                    base_url=base_url,
                    template=template,
                    interview_url=recipient["url"],
                    expires_at=recipient.get("expires_at", ""),
                    method=recipient["method"],
                    hr_qr_code=user_qr_code,
                    smtp_config=smtp_config,
                    # 批量发送复用同一条 SMTP 连接，仅第一封执行 NOOP 健康检查。
                    _check_connection=index == 0,
                )
                send_results.append(
                    {
                        "email": recipient["email"],
                        "candidate_name": recipient["candidate_name"],
                        "success": result.success,
                        "error": result.error,
                    }
                )
                if result.success:
                    sent += 1
                    sent_at = now_db_string()
                    if recipient.get("invite_type") == "written_test" or "/written-test/" in recipient["url"]:
                        conn.execute(
                            "UPDATE written_test_sessions SET invite_sent_at=%s WHERE token=%s",
                            (sent_at, recipient["token"]),
                        )
                    else:
                        update_interview_session(recipient["token"], {"invite_sent_at": sent_at})
                else:
                    failed += 1
            conn.commit()

            error_messages = [item["error"] for item in send_results if item.get("error")]
            warning = "；".join(dict.fromkeys(error_messages)) if error_messages else ""

            return {
                "method": "email",
                "count": len(invite_links),
                "sent": sent,
                "failed": failed,
                "skipped_no_email": skipped_no_email,
                "results": send_results,
                "warning": warning,
                "links": invite_links,
            }
        except HTTPException:
            raise
        except ImportError as e:
            return {
                "method": "link",
                "count": len(invite_links),
                "links": invite_links,
                "warning": f"邮件模块未就绪: {e}，已返回链接列表",
            }
        except Exception as e:
            logger.exception("面试邀请邮件发送失败")
            raise HTTPException(status_code=502, detail=f"邮件发送失败，请检查当前账号邮箱配置：{e}") from e

    else:
        raise HTTPException(400, f"Unknown method: {method}")


# ── 9. 上传视频（候选人录制视频回答）────────────────────────


def _mass_video_dir(pipeline_id: str, candidate_id: str) -> str:
    """Ensure and return the mass interview video directory for a candidate."""
    d = os.path.join(UPLOAD_DIR, pipeline_id, "mass", candidate_id)
    os.makedirs(d, exist_ok=True)
    return d


def _normalize_video_content_type(content_type: str) -> str:
    normalized = (content_type or "video/webm").strip().lower()
    base_type = normalized.split(";", 1)[0].strip()
    if base_type not in _ALLOWED_VIDEO_CONTENT_TYPES:
        raise HTTPException(400, "仅支持 WebM、MP4、OGG 或 MOV 视频")
    return normalized


def _extension_for_video_content_type(content_type: str) -> str:
    return {
        "video/mp4": ".mp4",
        "video/ogg": ".ogv",
        "video/quicktime": ".mov",
    }.get(content_type.split(";", 1)[0], ".webm")


def _direct_upload_secret() -> bytes:
    secret = os.getenv("SECRET_KEY", "").strip()
    if not secret:
        raise RuntimeError("SECRET_KEY 未配置")
    return secret.encode("utf-8")


def _encode_direct_upload_token(payload: dict) -> str:
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    encoded = base64.urlsafe_b64encode(raw).rstrip(b"=")
    signature = hmac.new(_direct_upload_secret(), encoded, hashlib.sha256).digest()
    signature_text = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
    return f"{encoded.decode('ascii')}.{signature_text}"


def _decode_direct_upload_token(value: str) -> dict:
    try:
        encoded_text, signature_text = value.split(".", 1)
        encoded = encoded_text.encode("ascii")
        expected = hmac.new(_direct_upload_secret(), encoded, hashlib.sha256).digest()
        signature = base64.urlsafe_b64decode(signature_text + "=" * (-len(signature_text) % 4))
        if not hmac.compare_digest(signature, expected):
            raise ValueError("signature mismatch")
        raw = base64.urlsafe_b64decode(encoded + b"=" * (-len(encoded) % 4))
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict) or int(payload.get("exp", 0)) < int(time.time()):
            raise ValueError("token expired")
        return payload
    except (
        ValueError,
        TypeError,
        KeyError,
        OverflowError,
        binascii.Error,
        json.JSONDecodeError,
        UnicodeDecodeError,
    ) as exc:
        raise HTTPException(400, "上传凭证无效或已过期，请重新上传") from exc


def _oss_region_from_endpoint(endpoint: str) -> str:
    hostname = urlsplit(endpoint if "://" in endpoint else f"https://{endpoint}").hostname or ""
    match = re.search(r"(?:^|\.)oss-([a-z0-9-]+?)(?:-internal)?\.", hostname.lower())
    if not match:
        raise RuntimeError("无法从 OSS endpoint 推导 region，请配置 ALICLOUD_OSS_REGION")
    return match.group(1)


def _direct_upload_config() -> tuple[str, str, str, str, str]:
    from app.config import (
        ALICLOUD_ACCESS_KEY,
        ALICLOUD_ACCESS_SECRET,
        ALICLOUD_OSS_BUCKET,
        ALICLOUD_OSS_ENDPOINT,
        ALICLOUD_OSS_PUBLIC_ENDPOINT,
        ALICLOUD_OSS_REGION,
        MASS_INTERVIEW_OSS_UPLOAD_HOST,
    )

    if not all((ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT)):
        raise RuntimeError("OSS 直传未配置")

    if MASS_INTERVIEW_OSS_UPLOAD_HOST:
        upload_host = MASS_INTERVIEW_OSS_UPLOAD_HOST.rstrip("/")
    else:
        endpoint = ALICLOUD_OSS_PUBLIC_ENDPOINT.strip().rstrip("/")
        if "://" not in endpoint:
            endpoint = f"https://{endpoint}"
        parsed = urlsplit(endpoint)
        if not parsed.netloc:
            raise RuntimeError("OSS 公网 endpoint 配置无效")
        bucket_prefix = f"{ALICLOUD_OSS_BUCKET}."
        hostname = parsed.netloc if parsed.netloc.startswith(bucket_prefix) else f"{bucket_prefix}{parsed.netloc}"
        upload_host = f"{parsed.scheme or 'https'}://{hostname}"

    upload_hostname = urlsplit(upload_host if "://" in upload_host else f"https://{upload_host}").hostname or ""
    if re.search(r"(?:^|\.)oss-[a-z0-9-]+-internal\.", upload_hostname.lower()):
        raise RuntimeError(
            "浏览器 OSS 直传地址不能使用内网 endpoint，请配置 ALICLOUD_OSS_PUBLIC_ENDPOINT=oss-<region>.aliyuncs.com"
        )

    region = ALICLOUD_OSS_REGION.strip() or _oss_region_from_endpoint(ALICLOUD_OSS_PUBLIC_ENDPOINT)
    return ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, upload_host, region


def _get_mass_interview_oss_bucket():
    import oss2

    from app.config import ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT

    if not all((ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT)):
        raise RuntimeError("OSS AccessKey 未配置")
    auth = oss2.Auth(ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET)
    return oss2.Bucket(auth, ALICLOUD_OSS_ENDPOINT, ALICLOUD_OSS_BUCKET)


def _build_oss_post_policy(object_key: str, content_type: str) -> tuple[dict[str, str], int]:
    access_key, access_secret, bucket_name, _, region = _direct_upload_config()
    now = datetime.now(timezone.utc)
    date = now.strftime("%Y%m%d")
    request_time = now.strftime("%Y%m%dT%H%M%SZ")
    credential = f"{access_key}/{date}/{region}/oss/aliyun_v4_request"
    expires_at = int(time.time()) + _DIRECT_UPLOAD_EXPIRES_SECONDS
    expiration = datetime.fromtimestamp(expires_at, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    policy_document = {
        "expiration": expiration,
        "conditions": [
            {"bucket": bucket_name},
            {"x-oss-signature-version": "OSS4-HMAC-SHA256"},
            {"x-oss-credential": credential},
            {"x-oss-date": request_time},
            ["eq", "$key", object_key],
            ["content-length-range", _VIDEO_MIN_BYTES, _VIDEO_MAX_BYTES],
            ["eq", "$Content-Type", content_type],
            ["eq", "$success_action_status", "200"],
        ],
    }
    policy_json = json.dumps(policy_document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    policy = base64.b64encode(policy_json).decode("ascii")
    date_key = hmac.new(f"aliyun_v4{access_secret}".encode(), date.encode("ascii"), hashlib.sha256).digest()
    region_key = hmac.new(date_key, region.encode("ascii"), hashlib.sha256).digest()
    service_key = hmac.new(region_key, b"oss", hashlib.sha256).digest()
    signing_key = hmac.new(service_key, b"aliyun_v4_request", hashlib.sha256).digest()
    signature = hmac.new(signing_key, policy.encode("ascii"), hashlib.sha256).hexdigest()
    fields = {
        "key": object_key,
        "policy": policy,
        "x-oss-signature-version": "OSS4-HMAC-SHA256",
        "x-oss-credential": credential,
        "x-oss-date": request_time,
        "x-oss-signature": signature,
        "success_action_status": "200",
        "Content-Type": content_type,
    }
    return fields, expires_at


def _direct_upload_token_payload(
    token: str,
    object_key: str,
    content_type: str,
    size_bytes: int,
    expires_at: int,
) -> dict:
    return {
        "session": hashlib.sha256(token.encode("utf-8")).hexdigest(),
        "object_key": object_key,
        "content_type": content_type,
        "size_bytes": size_bytes,
        "exp": expires_at,
    }


async def _verify_direct_upload_object(object_key: str, expected_size: int) -> str:
    bucket = _get_mass_interview_oss_bucket()
    try:
        metadata = await asyncio.to_thread(bucket.get_object_meta, object_key)
    except Exception as exc:
        logger.warning("OSS direct upload verification failed for %s: %s", object_key, exc)
        raise HTTPException(409, "OSS 尚未收到完整视频，请确认上传完成后重试") from exc

    actual_size = int(getattr(metadata, "content_length", 0) or 0)
    if actual_size != expected_size or not (_VIDEO_MIN_BYTES <= actual_size <= _VIDEO_MAX_BYTES):
        try:
            await asyncio.to_thread(bucket.delete_object, object_key)
        except Exception:
            logger.warning("Failed to remove invalid OSS object %s", object_key, exc_info=True)
        raise HTTPException(400, "OSS 视频大小校验失败，请重新上传")

    return bucket.sign_url("GET", object_key, 24 * 60 * 60)


async def _download_direct_upload_and_score(
    token: str,
    object_key: str,
    filepath: str,
    video_path_str: str,
    timestamps: list,
    expected_size: int,
) -> None:
    tmp_path = filepath + ".oss.tmp"
    last_error: Optional[Exception] = None
    try:
        for attempt in range(3):
            try:
                bucket = _get_mass_interview_oss_bucket()
                await asyncio.to_thread(bucket.get_object_to_file, object_key, tmp_path)
                if os.path.getsize(tmp_path) != expected_size:
                    raise RuntimeError("下载后文件大小与 OSS 元数据不一致")
                os.replace(tmp_path, filepath)
                update_interview_session(token, {"video_paths": [video_path_str]})
                _schedule_video_thumbnail(filepath, object_key)
                await _async_score_session(token, filepath, timestamps)
                return
            except Exception as exc:
                last_error = exc
                if os.path.exists(tmp_path):
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass
                if attempt < 2:
                    await asyncio.sleep(2 ** (attempt + 1))
        raise RuntimeError(str(last_error or "OSS 视频下载失败"))
    except Exception as exc:
        logger.exception("Direct-upload video processing failed for session %s", token)
        update_interview_session(
            token,
            {
                "dimension_scores": {
                    "scoring_status": "failed",
                    "media_status": "download_failed",
                    "scoring_error": str(exc)[:200],
                }
            },
        )
        _record_video_scoring_failure(token, exc)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def _schedule_direct_upload_processing(
    token: str,
    object_key: str,
    filepath: str,
    video_path_str: str,
    timestamps: list,
    expected_size: int,
) -> None:
    existing = _direct_upload_tasks.get(token)
    if existing and not existing.done():
        return
    task = asyncio.create_task(
        _download_direct_upload_and_score(token, object_key, filepath, video_path_str, timestamps, expected_size)
    )
    _direct_upload_tasks[token] = task

    def _discard(finished: asyncio.Task) -> None:
        if _direct_upload_tasks.get(token) is finished:
            _direct_upload_tasks.pop(token, None)

    task.add_done_callback(_discard)


def _record_video_assessment_processing(session: dict, questions: list, answers: list) -> None:
    """Expose an uploaded video interview to XiaoPing while async scoring runs."""
    assessment_flow.record_step_result(
        pipeline_id=session["pipeline_id"],
        candidate_id=session["candidate_id"],
        candidate_name=session.get("candidate_name", ""),
        modality="video_interview",
        execution_status="completed",
        scoring_status="processing",
        review_status="not_required",
        result_status="pending",
        score=None,
        evidence={"questions": questions, "answers": answers},
        metadata={"session_token": session.get("token", "")},
        actor_id="video_interview_submitted",
    )


@router.post("/session/{token}/video-upload/prepare")
async def api_prepare_direct_video_upload(
    token: str,
    body: DirectVideoUploadPrepareRequest,
    client_id: str = Header("", alias="X-Session-Client-Id"),
):
    """Create a short-lived, object-scoped OSS POST policy for browser upload."""
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    if _effective_interview_status(session) == "expired":
        update_interview_session(token, {"status": "expired"})
        raise HTTPException(400, "面试已结束")
    _require_interview_lease(session, client_id)
    if session.get("status") in ("completed", "evaluated"):
        raise HTTPException(400, "面试已结束")

    content_type = _normalize_video_content_type(body.content_type)
    extension = _extension_for_video_content_type(content_type)
    object_prefix = join_storage_key(
        settings.oss_video_prefix,
        "interviews",
        _safe_oss_segment(session["pipeline_id"]),
        _safe_oss_segment(session["candidate_id"]),
    )
    existing_object_key = str(session.get("oss_object_key", "") or "")
    object_key = (
        existing_object_key
        if existing_object_key.startswith(f"{object_prefix}/")
        else f"{object_prefix}/full_interview_{secrets.token_hex(12)}{extension}"
    )
    try:
        fields, expires_at = _build_oss_post_policy(object_key, content_type)
        _, _, _, upload_url, _ = _direct_upload_config()
        upload_token = _encode_direct_upload_token(
            _direct_upload_token_payload(
                token,
                object_key,
                content_type,
                body.size_bytes,
                expires_at + _DIRECT_UPLOAD_COMPLETION_GRACE_SECONDS,
            )
        )
        update_interview_session(token, {"oss_object_key": object_key})
    except RuntimeError as exc:
        raise HTTPException(
            503,
            detail={"code": "oss_direct_upload_unavailable", "message": str(exc)},
        ) from exc
    except Exception as exc:
        logger.exception("Failed to create direct upload intent for session %s", token)
        raise HTTPException(500, "服务器创建上传任务失败，请重试") from exc

    return {
        "upload_url": upload_url,
        "method": "POST",
        "fields": fields,
        "object_key": object_key,
        "upload_token": upload_token,
        "expires_at": expires_at,
        "max_size_bytes": _VIDEO_MAX_BYTES,
    }


@router.post("/session/{token}/video-upload/complete")
async def api_complete_direct_video_upload(
    token: str,
    body: DirectVideoUploadCompleteRequest,
    client_id: str = Header("", alias="X-Session-Client-Id"),
):
    """Verify the OSS object, persist it, then reuse the existing local scoring pipeline."""
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    if _effective_interview_status(session) == "expired":
        update_interview_session(token, {"status": "expired"})
        raise HTTPException(400, "面试已结束")
    _require_interview_lease(session, client_id)

    proof = _decode_direct_upload_token(body.upload_token)
    expected_session = hashlib.sha256(token.encode("utf-8")).hexdigest()
    if proof.get("session") != expected_session or proof.get("object_key") != body.object_key:
        raise HTTPException(400, "上传凭证与当前面试不匹配")

    existing_object_key = session.get("oss_object_key", "")
    if session.get("status") in ("completed", "evaluated") and existing_object_key != body.object_key:
        raise HTTPException(409, "本场面试已有已确认的视频")
    if session.get("status") == "evaluated" and existing_object_key == body.object_key:
        return {"status": "uploaded", "message": "视频已确认，AI 评分已完成"}

    expected_size = int(proof.get("size_bytes", 0))
    recording_url = await _verify_direct_upload_object(body.object_key, expected_size)
    timestamps = [item.model_dump(exclude_none=True) for item in body.timestamps]
    questions = _parse_json_field(session, "questions")
    answers = _parse_json_field(session, "answers")
    while len(answers) < len(questions):
        answers.append({})

    filename = os.path.basename(body.object_key)
    video_dir = _mass_video_dir(session["pipeline_id"], session["candidate_id"])
    filepath = os.path.join(video_dir, filename)
    video_path_str = f"{session['pipeline_id']}/mass/{session['candidate_id']}/{filename}"

    update_values = {
        "status": "completed",
        "completed_at": session.get("completed_at") or now_db_string(),
        "timestamps": timestamps,
        "answers": answers,
        "oss_object_key": body.object_key,
        "recording_url": recording_url,
        "dimension_scores": {
            "scoring_status": "processing",
            "media_status": "downloading",
        },
        # Completion and lease release are one atomic database update.
        "active_client_id": "",
        "lease_expires_at": "",
    }
    try:
        updated_session = update_interview_session(token, update_values)
        # Keep callbacks and test doubles that do not return the updated row compatible.
        broadcast_session = updated_session or {**session, **update_values}
        await _broadcast_mass_event(
            broadcast_session.get("pipeline_id", ""),
            "session_updated",
            broadcast_session,
            status="completed",
        )
    except Exception as exc:
        logger.exception("Failed to persist direct upload for session %s", token)
        raise HTTPException(500, "服务器保存上传结果失败，请重试") from exc

    try:
        update_candidate(session["candidate_id"], {"status": "interviewed"})
    except Exception:
        logger.exception("Failed to update candidate interview status for %s", token)
    _record_video_assessment_processing(session, questions, answers)
    _schedule_direct_upload_processing(
        token,
        body.object_key,
        filepath,
        video_path_str,
        timestamps,
        expected_size,
    )
    return {
        "status": "uploaded",
        "message": "视频已直传 OSS，AI 正在评分中，请稍后查看结果",
    }


# ── 9b. 上传完整视频（一次性录制）───────────────────────────


@router.post("/session/{token}/full-video")
async def api_upload_full_video(
    token: str,
    video: UploadFile = File(...),
    timestamps: str = Form(default="[]"),
    client_id: str = Header("", alias="X-Session-Client-Id"),
):
    """Candidate uploads full interview video (one-shot recording mode).

    P0: timestamps stored in DB column (added via migration)
    P1: DB update split into critical + optional, scoring always starts
    P2: streaming write + atomic rename
    P3: async OSS upload with retry
    """
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    if _effective_interview_status(session) == "expired":
        update_interview_session(token, {"status": "expired"})
        raise HTTPException(400, "面试已结束")
    _require_interview_lease(session, client_id)
    if session.get("status") in ("completed", "evaluated"):
        raise HTTPException(400, "面试已结束")

    pipeline_id = session["pipeline_id"]
    candidate_id = session["candidate_id"]

    # 解析时间戳
    try:
        ts_list = json.loads(timestamps) if isinstance(timestamps, str) else timestamps
    except (json.JSONDecodeError, TypeError):
        ts_list = []

    # ── P2：流式写入与原子重命名 ──
    video_dir = _mass_video_dir(pipeline_id, candidate_id)
    ext = _get_video_ext(video.filename or "interview.webm")
    filename = f"full_interview{ext}"
    filepath = os.path.join(video_dir, filename)
    tmp_path = filepath + ".tmp"

    max_size = 30 * 1024 * 1024  # 30MB

    # 流式写入临时文件，避免将完整视频载入内存
    written = 0
    with open(tmp_path, "wb") as f:
        while True:
            chunk = await video.read(1024 * 1024)  # 每块 1MB
            if not chunk:
                break
            written += len(chunk)
            if written > max_size:
                f.close()
                os.remove(tmp_path)
                raise HTTPException(400, f"视频文件不能超过{max_size // 1024 // 1024}MB")
            f.write(chunk)

        # 校验文件大小
    if written < 1024:
        os.remove(tmp_path)
        raise HTTPException(400, "视频文件过小，录制可能失败")

        # 原子重命名：临时文件 → 最终文件
    os.replace(tmp_path, filepath)
    logger.info(f"Video saved: {filepath} ({written} bytes)")

    # ── P1：更新数据库，先写关键字段，可选字段使用异常保护 ──
    video_path_str = f"{pipeline_id}/mass/{candidate_id}/{filename}"

    # 步骤 1：关键更新（必须成功）
    try:
        session = update_interview_session(
            token,
            {
                "status": "completed",
                "completed_at": now_db_string(),
                "video_paths": [video_path_str],
                # Completion and lease release are one atomic database update.
                "active_client_id": "",
                "lease_expires_at": "",
            },
        )
        await _broadcast_mass_event(pipeline_id, "session_updated", session, status="completed")
    except Exception as e:
        logger.error(f"Critical DB update failed for {token}: {e}")
        raise HTTPException(500, "服务器保存失败，请重试")

    questions = _parse_json_field(session, "questions")
    answers = _parse_json_field(session, "answers")
    while len(answers) < len(questions):
        answers.append({})

    # 步骤 2：可选更新（时间戳与回答初始化）
    try:
        update_interview_session(
            token,
            {
                "timestamps": ts_list,
                "answers": answers,
            },
        )
    except Exception as e:
        logger.warning(f"Optional DB update failed for {token}: {e}")
        # 非致命错误：评分任务会重新读取并初始化

        # ── P3：异步上传 OSS（后台执行并支持重试）──
    from app.infrastructure.config import settings
    from app.media_storage import join_storage_key

    oss_key = join_storage_key(settings.oss_video_prefix, "interviews", pipeline_id, candidate_id, filename)
    asyncio.create_task(_upload_video_to_oss_with_retry(filepath, oss_key, token))
    _schedule_video_thumbnail(filepath, oss_key)

    _record_video_assessment_processing(session, questions, answers)
    # ── P1：始终启动评分任务，即使可选数据库更新失败 ──
    asyncio.create_task(_async_score_session(token, filepath, ts_list))

    return {
        "status": "uploaded",
        "message": "视频已上传，AI正在评分中，请稍后查看结果",
    }


async def _async_score_session(token: str, video_path: str, timestamps: list):
    """Async scoring pipeline with idempotency and status tracking.

    Steps:
    1. Mark scoring_status = "processing"
    2. For each question, cut audio segment by timestamps
    3. ffmpeg extract audio → WAV
    4. ASR transcribe → text
    5. score_answer() with scoring_hint (skip if already scored)
    6. evaluate_final() for aggregate
    7. Write results to DB, mark scoring_status = "done"
    """
    try:
        # 标记评分进行中
        try:
            update_interview_session(
                token,
                {
                    "dimension_scores": json.dumps(
                        {"scoring_status": "processing", "scoring_started_at": now_db_string()}
                    )
                },
            )
        except Exception:
            pass

        session = get_interview_session(token)
        if not session:
            return

        questions = _parse_json_field(session, "questions")
        answers = _parse_json_field(session, "answers")
        pipeline_id = session["pipeline_id"]
        candidate_id = session["candidate_id"]

        # 未传入时间戳时从数据库重新读取（重试场景）
        if not timestamps:
            try:
                raw_ts = session.get("timestamps", "[]")
                timestamps = json.loads(raw_ts) if isinstance(raw_ts, str) else (raw_ts or [])
            except Exception:
                timestamps = []

        from hr_harness.agents.mass_interview_agent import VIDEO_SCORING_PRIMARY_DIMENSION, MassInterviewAgent

        agent = MassInterviewAgent()

        pipeline = get_pipeline(pipeline_id)
        role = pipeline.get("role", "") if pipeline else ""
        template = agent.get_template(role)
        scoring_hint = ""

        # 确保回答列表长度足够
        while len(answers) < len(questions):
            answers.append({})

        for i, q in enumerate(questions):
            if not isinstance(q, dict):
                continue

            # ── 幂等处理：已经评分时跳过 ──
            existing = answers[i] if i < len(answers) else {}
            if isinstance(existing, dict) and existing.get("score", 0) > 0:
                logger.info(f"Q{i} already scored ({existing['score']}), skipping")
                continue

            primary_dim = VIDEO_SCORING_PRIMARY_DIMENSION
            dim_description = ""

            # 确定音频片段
            ts_entry = next((t for t in timestamps if t.get("q") == i), None)
            segment_start = ts_entry.get("start", 0) if ts_entry else 0
            segment_end = ts_entry.get("end", 0) if ts_entry else 0

            # 两侧各增加 2 秒缓冲，避免裁剪过紧
            start_cut = max(0, segment_start - 2)
            duration = max(5, (segment_end - segment_start) + 4)

            # 通过 ffmpeg 提取音频片段
            audio_path = video_path.rsplit(".", 1)[0] + f"_q{i}_asr.wav"
            try:
                await _extract_audio_segment(video_path, start_cut, duration, audio_path)
            except Exception as e:
                logger.warning(f"Audio segment extraction failed for q{i}: {e}")
                # 降级处理：从完整视频提取
                try:
                    audio_path = await _extract_audio(video_path)
                except Exception:
                    transcript = "[音频提取失败]"
                    score_result = await agent.score_answer(
                        question=q.get("question", ""),
                        expected_points=q.get("expected_points", []),
                        candidate_name=session.get("candidate_name", "候选人"),
                        answer=transcript,
                        role_name=role,
                        primary_dim=primary_dim,
                        dim_description=dim_description,
                        question_index=i,
                        scoring_hint=scoring_hint,
                        scoring_rubric=q.get("scoring_rubric", {}),
                    )
                    answers[i] = _scored_video_answer(i, q, transcript, score_result, primary_dim, {})
                    continue

            # ASR 转写
            transcript = ""
            audio_features = {}
            try:
                transcript = await _asr_transcribe(audio_path)
                if not transcript:
                    transcript = "[语音识别未完成]"
            except Exception as e:
                transcript = f"[语音转文字失败: {str(e)[:50]}]"

            # 提取音频特征
            try:
                audio_features = await _extract_audio_features(audio_path)
            except Exception:
                pass

            # 评分
            score_result = await agent.score_answer(
                question=q.get("question", ""),
                expected_points=q.get("expected_points", []),
                candidate_name=session.get("candidate_name", "候选人"),
                answer=transcript,
                role_name=role,
                primary_dim=primary_dim,
                dim_description=dim_description,
                audio_features=audio_features,
                question_index=i,
                scoring_hint=scoring_hint,
                scoring_rubric=q.get("scoring_rubric", {}),
            )

            answers[i] = _scored_video_answer(i, q, transcript, score_result, primary_dim, audio_features)

            # 每道题后保存进度，支持崩溃恢复
            try:
                update_interview_session(token, {"answers": answers})
            except Exception as e:
                logger.warning(f"Progress save failed for q{i}: {e}")

            # 触发异步视频分析，不阻塞当前流程
            asyncio.create_task(
                _trigger_video_analysis(
                    token,
                    i,
                    video_path,
                    audio_features,
                    role,
                    q.get("question", ""),
                )
            )

            # 清理临时音频
            try:
                os.remove(audio_path)
            except Exception:
                pass

        # 最终评估
        result = await agent.evaluate_final(
            candidate_name=session.get("candidate_name", ""),
            role=role,
            questions=questions,
            answers=answers,
            template=template,
        )

        # 将最终结果和评分状态更新到会话
        score = result.get("interview_score")
        scoring_status = result.get("scoring_status", "succeeded" if score is not None else "failed")
        red_flags = result.get("red_flags", [])
        assessment_result = assessment_flow.record_step_result(
            pipeline_id=pipeline_id,
            candidate_id=candidate_id,
            candidate_name=session.get("candidate_name", ""),
            modality="video_interview",
            execution_status="completed",
            scoring_status=scoring_status,
            review_status="not_required",
            result_status="passed" if score is not None and score >= 60 else "not_passed",
            score=score,
            evidence={
                "questions": questions,
                "answers": answers,
                "evaluation": result,
                "video_file": os.path.basename(video_path),
            },
            scoring_version=result.get("score_version", ""),
            red_flags=red_flags,
            metadata={"session_token": token},
            actor_id="video_interview_scoring",
        )
        from app.assessment_dispatch import dispatch_next_actions

        dispatch_result = await dispatch_next_actions(pipeline_id, candidate_id, assessment_result["package"])

        dim_scores = dict(result.get("dimension_scores", {}))
        if isinstance(dim_scores, dict):
            dim_scores["scoring_status"] = scoring_status
            dim_scores["score_status"] = result.get("score_status", "final")
            dim_scores["provisional_score"] = result.get("provisional_score")
            dim_scores["failed_questions"] = result.get("failed_questions", [])
            dim_scores["scored_question_count"] = result.get("scored_question_count", len(questions))
            dim_scores["total_question_count"] = result.get("total_question_count", len(questions))
            dim_scores["score_coverage_ratio"] = result.get("score_coverage_ratio", 1)
            dim_scores["scoring_completed_at"] = now_db_string()

        session = update_interview_session(
            token,
            {
                "status": "evaluated",
                "evaluated_at": now_db_string(),
                "answers": answers,
                "interview_score": score,
                "dimension_scores": dim_scores,
                "recommendation": result.get("recommendation", ""),
            },
        )
        await _broadcast_mass_event(
            pipeline_id,
            "score_update",
            session,
            status="evaluated",
            interview_score=score,
            scoring_status=scoring_status,
        )

        # 回写 candidates 表
        try:
            candidate_updates = {"status": "interviewed", "video_assessment": result}
            if score is not None and scoring_status == "succeeded":
                candidate_updates["interview_score"] = score
            update_candidate(candidate_id, candidate_updates)
        except Exception:
            pass

        candidate_reports.schedule_report_generation(pipeline_id, candidate_id)

        logger.info(
            "Async scoring complete for token=%s, score=%s, queue=%s, next=%s",
            token,
            score,
            assessment_result["queue_status"],
            dispatch_result,
        )

    except Exception as e:
        logger.error(f"Async scoring failed for token={token}: {e}")
        await _record_video_scoring_failure(token, e)


async def _record_video_scoring_failure(token: str, error: Exception) -> bool:
    """Persist an unexpected failure as transparent zero-score question results."""
    try:
        session = get_interview_session(token)
        if not session:
            return False
        existing = assessment_flow.get_candidate_assessment(session["pipeline_id"], session["candidate_id"])
        video_result = next(
            (
                result
                for result in (existing or {}).get("step_results", {}).values()
                if result.get("modality") == "video_interview"
            ),
            None,
        )
        if video_result and video_result.get("scoring_status") == "succeeded":
            return False

        from hr_harness.agents.mass_interview_agent import VIDEO_SCORING_PRIMARY_DIMENSION, MassInterviewAgent

        questions = _parse_json_field(session, "questions")
        answers = _parse_json_field(session, "answers")
        role = session.get("role", "")
        agent = MassInterviewAgent()
        template = agent.get_template(role)
        while len(answers) < len(questions):
            answers.append({})
        for index, question in enumerate(questions):
            if isinstance(answers[index], dict) and answers[index].get("criteria"):
                continue
            primary_dim = VIDEO_SCORING_PRIMARY_DIMENSION
            score_result = await agent.score_answer(
                question=question.get("question", ""),
                expected_points=question.get("expected_points", []),
                candidate_name=session.get("candidate_name", "候选人"),
                answer="[音频提取失败]",
                role_name=role,
                primary_dim=primary_dim,
                dim_description="",
                question_index=index,
                scoring_hint="",
                scoring_rubric=question.get("scoring_rubric", {}),
            )
            answers[index] = _scored_video_answer(index, question, "[音频提取失败]", score_result, primary_dim, {})
        evaluation = await agent.evaluate_final(
            candidate_name=session.get("candidate_name", ""),
            role=role,
            questions=questions,
            answers=answers,
            template=template,
        )
        score = evaluation.get("interview_score", 0)
        message = str(error)[:200]
        assessment_result = assessment_flow.record_step_result(
            pipeline_id=session["pipeline_id"],
            candidate_id=session["candidate_id"],
            candidate_name=session.get("candidate_name", ""),
            modality="video_interview",
            execution_status="completed",
            scoring_status="succeeded",
            review_status="not_required",
            result_status="passed" if score is not None and score >= 60 else "not_passed",
            score=score,
            evidence={
                "questions": questions,
                "answers": answers,
                "evaluation": evaluation | {"scoring_error": message},
            },
            scoring_version=evaluation.get("score_version", "video_scoring_exception_v2"),
            metadata={"session_token": token},
            actor_id="video_interview_scoring_failure",
        )
        from app.assessment_dispatch import dispatch_next_actions

        await dispatch_next_actions(session["pipeline_id"], session["candidate_id"], assessment_result["package"])
        dim_scores = dict(evaluation.get("dimension_scores", {}))
        dim_scores.update(
            {
                "scoring_status": "succeeded",
                "score_status": evaluation.get("score_status", "final"),
                "scoring_error": message,
                "scoring_completed_at": now_db_string(),
            }
        )
        session = update_interview_session(
            token,
            {
                "status": "evaluated",
                "evaluated_at": now_db_string(),
                "answers": answers,
                "interview_score": score,
                "dimension_scores": dim_scores,
                "recommendation": evaluation.get("recommendation", "not_recommend"),
            },
        )
        await _broadcast_mass_event(
            session.get("pipeline_id", ""),
            "score_update",
            session,
            status="evaluated",
            interview_score=score,
            scoring_status="succeeded",
        )
        try:
            update_candidate(
                session["candidate_id"],
                {"interview_score": score, "video_assessment": evaluation},
            )
        except Exception:
            pass
        candidate_reports.schedule_report_generation(session["pipeline_id"], session["candidate_id"])
        return True
    except Exception as fallback_error:
        logger.error("Failed to persist video scoring failure for token=%s: %s", token, fallback_error)
        return False


async def _extract_audio_segment(video_path: str, start_sec: float, duration_sec: float, output_path: str):
    """Extract an audio segment from a video file using ffmpeg.

    Args:
        video_path: Path to the source video
        start_sec: Start time in seconds
        duration_sec: Duration in seconds
        output_path: Path for the output WAV file
    """
    if not _check_ffmpeg():
        raise RuntimeError("ffmpeg 未安装")

    cmd = [
        "ffmpeg",
        "-y",
        "-ss",
        str(start_sec),
        "-i",
        video_path,
        "-t",
        str(duration_sec),
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-ar",
        "16000",
        "-ac",
        "1",
        output_path,
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg segment exit {proc.returncode}: {stderr.decode()[:200]}")
    if not os.path.exists(output_path):
        raise RuntimeError("ffmpeg 未生成输出文件")


# ── 11. 视频流（HR 查看候选人视频）─────────────────────────


def _video_thumbnail_path(pipeline_id: str, candidate_id: str, filename: str) -> str:
    """Return the local, sidecar JPG path for a recorded interview video."""
    return os.path.join(UPLOAD_DIR, pipeline_id, "mass", candidate_id, f"{filename}.jpg")


def _video_oss_object_keys(pipeline_id: str, candidate_id: str, filename: str) -> list[str]:
    """Return compatible OSS object keys for both legacy and direct uploads."""
    keys = [join_storage_key(settings.oss_video_prefix, "interviews", pipeline_id, candidate_id, filename)]
    for session in reversed(get_interview_sessions(pipeline_id)):
        if str(session.get("candidate_id", "")) != candidate_id:
            continue
        object_key = str(session.get("oss_object_key", "") or "")
        if object_key and os.path.basename(object_key) == filename and object_key not in keys:
            keys.append(object_key)
    return keys


async def _generate_video_thumbnail(video_source: str, thumbnail_path: str) -> bool:
    """Extract a non-terminal frame without relying on the browser video/canvas stack."""
    if os.path.exists(thumbnail_path):
        return True
    if not _check_ffmpeg():
        logger.warning("Cannot generate interview thumbnail because ffmpeg is unavailable")
        return False

    os.makedirs(os.path.dirname(thumbnail_path), exist_ok=True)
    temporary_path = f"{thumbnail_path}.tmp.jpg"
    # Seek from the end so long recordings do not need to be decoded from the
    # beginning.  Try a few offsets because MediaRecorder files may end with a
    # short black/flush segment; the final fallback handles very short clips.
    seek_attempts = [("-sseof", "-5"), ("-sseof", "-10"), ("-sseof", "-2"), ("-ss", "1")]
    # Keep a cold thumbnail request bounded even when an OSS URL is slow or
    # does not support efficient seeking. Normally covers are generated in the
    # background immediately after upload, so this is only a fallback path.
    deadline = time.monotonic() + 10.0
    for seek_flag, seek_seconds in seek_attempts:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            if os.path.exists(temporary_path):
                os.remove(temporary_path)
            process = await asyncio.create_subprocess_exec(
                "ffmpeg",
                "-y",
                seek_flag,
                seek_seconds,
                "-i",
                video_source,
                "-frames:v",
                "1",
                "-vf",
                "scale=320:-2",
                "-q:v",
                "3",
                temporary_path,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            try:
                await asyncio.wait_for(process.communicate(), timeout=min(6.0, remaining))
            except asyncio.TimeoutError:
                process.kill()
                await process.communicate()
                continue
            if process.returncode == 0 and os.path.getsize(temporary_path) > 1024:
                # MediaRecorder may append a short black/flush segment. Probe
                # a tiny grayscale copy before caching so that frame is not
                # shown as the candidate cover (16x16 pixels is inexpensive).
                usable_frame = True
                try:
                    from PIL import Image, ImageStat

                    with Image.open(temporary_path) as frame:
                        probe = frame.convert("L")
                        probe.thumbnail((16, 16))
                        usable_frame = ImageStat.Stat(probe).mean[0] >= 8.0
                except Exception:
                    # Keep a valid ffmpeg output if optional probing fails.
                    usable_frame = True
                if usable_frame:
                    os.replace(temporary_path, thumbnail_path)
                    return True
        except (OSError, ValueError) as exc:
            logger.warning("Interview thumbnail extraction failed for %s: %s", video_source, exc)
            break
        finally:
            if os.path.exists(temporary_path):
                try:
                    os.remove(temporary_path)
                except OSError:
                    pass
    return False


async def _archive_video_thumbnail(thumbnail_path: str, object_key: str) -> None:
    """Keep the sidecar image in OSS so a redeploy does not lose the cover."""
    try:
        storage = get_media_storage("oss")
        await asyncio.to_thread(storage.write_file, f"{object_key}.jpg", thumbnail_path, "image/jpeg")
    except Exception:
        logger.warning("Failed to archive interview thumbnail for %s", object_key, exc_info=True)


async def _generate_and_archive_video_thumbnail(video_path: str, object_key: str) -> None:
    try:
        thumbnail_path = f"{video_path}.jpg"
        if await _generate_video_thumbnail(video_path, thumbnail_path):
            await _archive_video_thumbnail(thumbnail_path, object_key)
    except Exception:
        # A cover is a presentation enhancement and must never affect the
        # independently scheduled upload, scoring, or report pipeline.
        logger.warning("Interview thumbnail background task failed for %s", video_path, exc_info=True)


def _schedule_video_thumbnail(video_path: str, object_key: str) -> None:
    """Generate the cover outside the upload/scoring critical path."""
    asyncio.create_task(_generate_and_archive_video_thumbnail(video_path, object_key))


@router.get("/thumbnail/{pipeline_id}/{candidate_id}/{filename}")
async def api_video_thumbnail(pipeline_id: str, candidate_id: str, filename: str):
    """Return a persisted interview-video cover, generating it when needed."""
    if os.path.basename(filename) != filename:
        raise HTTPException(404, "视频封面不存在")

    thumbnail_path = _video_thumbnail_path(pipeline_id, candidate_id, filename)
    if os.path.exists(thumbnail_path):
        return FileResponse(thumbnail_path, media_type="image/jpeg")

    video_path = os.path.join(UPLOAD_DIR, pipeline_id, "mass", candidate_id, filename)
    object_keys = _video_oss_object_keys(pipeline_id, candidate_id, filename)
    try:
        storage = get_media_storage("oss")
        for object_key in object_keys:
            thumbnail_key = f"{object_key}.jpg"
            if storage.exists(thumbnail_key):
                return RedirectResponse(storage.sign_url(thumbnail_key), status_code=307)

        source = video_path if os.path.exists(video_path) else ""
        archived_key = next((key for key in object_keys if storage.exists(key)), "")
        if not source and archived_key:
            source = storage.sign_url(archived_key)
        if source and await _generate_video_thumbnail(source, thumbnail_path):
            if archived_key:
                await _archive_video_thumbnail(thumbnail_path, archived_key)
            return FileResponse(thumbnail_path, media_type="image/jpeg")
    except Exception:
        logger.warning(
            "Failed to resolve interview thumbnail pipeline=%s candidate=%s filename=%s",
            pipeline_id,
            candidate_id,
            filename,
            exc_info=True,
        )
    raise HTTPException(404, "视频封面不存在")


@router.get("/video/{pipeline_id}/{candidate_id}/{filename}")
async def api_stream_video(pipeline_id: str, candidate_id: str, filename: str, request: Request):
    """Stream a recorded answer video with Range request support (seekable playback)."""
    if os.path.basename(filename) != filename:
        raise HTTPException(404, "视频文件不存在")

    filepath = os.path.join(UPLOAD_DIR, pipeline_id, "mass", candidate_id, filename)
    if not os.path.exists(filepath):
        # uploads is only a transient cache for scoring.  Re-deploying an
        # application instance must not make a successfully archived video
        # unplayable, so hand the browser a fresh short-lived OSS URL instead.
        try:
            # Interview video archival always uses OSS, independent of the
            # generic media-storage backend used by other features.
            storage = get_media_storage("oss")
            if storage.backend == "oss":
                # Old one-shot uploads did not persist their object key.  Their
                # key is deterministic, so retain playback compatibility.
                candidate_keys = [
                    join_storage_key(settings.oss_video_prefix, "interviews", pipeline_id, candidate_id, filename)
                ]
                # Browser-direct uploads use a nonce in the filename and must
                # be resolved from the persisted OSS object key. Preserve the
                # legacy fast path when the deterministic key already exists.
                if not storage.exists(candidate_keys[0]):
                    candidate_keys = _video_oss_object_keys(pipeline_id, candidate_id, filename)

                for object_key in candidate_keys:
                    if storage.exists(object_key):
                        return RedirectResponse(storage.sign_url(object_key), status_code=307)
        except Exception:
            # OSS may be temporarily unavailable.  Keep the response contract
            # as a normal missing video rather than leaking storage details.
            logger.warning(
                "Failed to resolve archived interview video from OSS pipeline=%s candidate=%s filename=%s",
                pipeline_id,
                candidate_id,
                filename,
                exc_info=True,
            )
        raise HTTPException(404, "视频文件不存在")

    file_size = os.path.getsize(filepath)
    range_header = request.headers.get("range")

    if range_header:
        start, end = _parse_range(range_header, file_size)
        length = end - start + 1
        with open(filepath, "rb") as f:
            f.seek(start)
            data = f.read(length)
        return Response(
            content=data,
            status_code=206,
            headers={
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Accept-Ranges": "bytes",
                "Content-Length": str(length),
                "Content-Type": "video/webm",
            },
        )

    return FileResponse(filepath, media_type="video/webm", headers={"Accept-Ranges": "bytes"})


# ── 12. 批量评估（异步深度分析）────────────────────────────


@router.post("/{pipeline_id}/evaluate")
async def api_batch_evaluate(pipeline_id: str):
    """Trigger batch video deep analysis for completed sessions (async)."""
    sessions = get_interview_sessions(pipeline_id)
    completed = [s for s in sessions if s.get("status") == "completed"]
    if not completed:
        return {"status": "no_sessions", "message": "没有待评估的已完成面试"}
    try:
        assessment_flow.ensure_single_step_plan(pipeline_id, "video_interview", actor_id="video_interview_batch")
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    async def _evaluate_all():
        from hr_harness.agents.mass_interview_agent import MassInterviewAgent

        agent = MassInterviewAgent()
        pipeline = get_pipeline(pipeline_id)
        role = pipeline.get("role", "") if pipeline else ""
        template = agent.get_template(role)
        for s in completed[:30]:  # 为控制成本，仅处理前 30 条
            try:
                answers = _parse_json_field(s, "answers")
                questions = _parse_json_field(s, "questions")
                result = await agent.evaluate_final(
                    candidate_name=s.get("candidate_name", ""),
                    role=role,
                    questions=questions,
                    answers=answers,
                    template=template,
                )
                score = result.get("interview_score")
                scoring_status = result.get("scoring_status", "succeeded" if score is not None else "failed")
                red_flags = result.get("red_flags", [])
                assessment_result = assessment_flow.record_step_result(
                    pipeline_id=pipeline_id,
                    candidate_id=s["candidate_id"],
                    candidate_name=s.get("candidate_name", ""),
                    modality="video_interview",
                    execution_status="completed",
                    scoring_status=scoring_status,
                    review_status="not_required",
                    result_status="passed" if score is not None and score >= 60 else "not_passed",
                    score=score,
                    evidence={"questions": questions, "answers": answers, "evaluation": result},
                    scoring_version=result.get("score_version", ""),
                    red_flags=red_flags,
                    metadata={"session_token": s["token"]},
                    actor_id="video_interview_batch",
                )
                from app.assessment_dispatch import dispatch_next_actions

                await dispatch_next_actions(pipeline_id, s["candidate_id"], assessment_result["package"])
                dimension_scores = dict(result.get("dimension_scores", {}))
                dimension_scores.update(
                    {
                        "scoring_status": scoring_status,
                        "score_status": result.get("score_status", "final"),
                        "provisional_score": result.get("provisional_score"),
                        "failed_questions": result.get("failed_questions", []),
                        "scored_question_count": result.get("scored_question_count", len(questions)),
                        "total_question_count": result.get("total_question_count", len(questions)),
                        "score_coverage_ratio": result.get("score_coverage_ratio", 1),
                    }
                )
                updated_session = update_interview_session(
                    s["token"],
                    {
                        "status": "evaluated",
                        "evaluated_at": now_db_string(),
                        "interview_score": score,
                        "dimension_scores": dimension_scores,
                        "recommendation": result.get("recommendation", ""),
                    },
                )
                await _broadcast_mass_event(
                    pipeline_id,
                    "score_update",
                    updated_session,
                    status="evaluated",
                    interview_score=score,
                    scoring_status=scoring_status,
                )
                # 回写 candidates 表
                candidate_updates = {"status": "interviewed", "video_assessment": result}
                if score is not None and scoring_status == "succeeded":
                    candidate_updates["interview_score"] = score
                update_candidate(s["candidate_id"], candidate_updates)
                candidate_reports.schedule_report_generation(pipeline_id, s["candidate_id"])
            except Exception:
                pass

    asyncio.create_task(_evaluate_all())
    return {"status": "evaluating", "total": len(completed), "max": min(len(completed), 30)}


# ── 辅助函数 ────────────────────────────────────────────────


def _get_tts_urls(pipeline_id: str, session: dict = None) -> list:
    """个性化题目不复用 pipeline 级音频，交由候选人端逐题播报。"""
    questions = (session or {}).get("questions", [])
    if isinstance(questions, str):
        try:
            questions = json.loads(questions)
        except Exception:
            questions = []
    return [""] * len(questions) if questions else []


def _public_questions(questions: list) -> list[dict]:
    """只向候选人返回作答所需字段，避免泄露评分锚点。"""
    allowed = {"id", "type", "question", "tts_prefix", "time_limit_seconds", "answer_mode", "difficulty"}
    return _service_helpers.public_question_payload(questions, allowed)


def _parse_video_paths(raw) -> list:
    """Parse video_paths field to list regardless of input type."""
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
    return raw if isinstance(raw, list) else []


def _get_video_ext(filename: str) -> str:
    """Extract file extension, defaulting to .webm."""
    if "." in filename:
        return "." + filename.rsplit(".", 1)[-1].lower()
    return ".webm"


def _parse_range(range_header: str, file_size: int) -> tuple:
    """Parse HTTP Range header. Returns (start, end)."""
    try:
        unit, ranges = range_header.split("=", 1)
        if unit != "bytes":
            raise ValueError("Only bytes range supported")
        start_str, end_str = ranges.split("-", 1)
        start = int(start_str) if start_str else 0
        end = int(end_str) if end_str else file_size - 1
        return max(0, start), min(end, file_size - 1)
    except Exception:
        return 0, file_size - 1


# ── ASR 基础设施 ──────────────────────────────────────────

_ffmpeg_available = None
_asr_cache: dict = {}  # 文件路径 MD5 → 转写文本
_asr_daily_count = 0
_asr_daily_date = ""
_asr_semaphore = asyncio.Semaphore(10)  # 最多10个并发ASR请求


def _check_ffmpeg() -> bool:
    """启动时检测 ffmpeg 是否可用，结果缓存。"""
    global _ffmpeg_available
    if _ffmpeg_available is not None:
        return _ffmpeg_available
    try:
        r = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            timeout=5,
        )
        _ffmpeg_available = r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        _ffmpeg_available = False
    if not _ffmpeg_available:
        import logging

        logging.getLogger(__name__).warning("ffmpeg not found — video ASR will be unavailable")
    return _ffmpeg_available


def _detect_audio_format(audio_path: str) -> str:
    """检测音频文件格式（通过文件头）"""
    try:
        with open(audio_path, "rb") as f:
            header = f.read(16)

        # WAV 格式：RIFF....WAVE
        if header[:4] == b"RIFF" and header[8:12] == b"WAVE":
            return "wav"
        # MP3 格式：ID3 或 0xFF 0xFB
        if header[:3] == b"ID3" or (header[0] == 0xFF and (header[1] & 0xE0) == 0xE0):
            return "mp3"
        # OGG 格式：OggS
        if header[:4] == b"OggS":
            return "ogg"
        # FLAC 格式：fLaC
        if header[:4] == b"fLaC":
            return "flac"
        # WebM 格式：1A 45 DF A3
        if header[:4] == b"\x1a\x45\xdf\xa3":
            return "webm"
    except Exception:
        pass

    # 回退到扩展名
    ext = audio_path.lower().rsplit(".", 1)[-1] if "." in audio_path else ""
    format_map = {
        "wav": "wav",
        "mp3": "mp3",
        "opus": "opus",
        "ogg": "ogg",
        "flac": "flac",
        "m4a": "m4a",
        "webm": "webm",
    }
    return format_map.get(ext, "wav")


async def _extract_audio(video_path: str) -> str:
    """ffmpeg 从视频提取 16kHz 单声道 WAV，返回 wav 路径。"""
    if not _check_ffmpeg():
        raise RuntimeError("ffmpeg 未安装")

    audio_path = video_path.rsplit(".", 1)[0] + "_asr.wav"
    cmd = [
        "ffmpeg",
        "-y",
        "-i",
        video_path,
        "-vn",
        "-acodec",
        "pcm_s16le",
        "-ar",
        "16000",
        "-ac",
        "1",
        "-t",
        "120",  # 硬截断120秒，防超长音频
        audio_path,
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg exit {proc.returncode}: {stderr.decode()[:200]}")
    if not os.path.exists(audio_path):
        raise RuntimeError("ffmpeg 未生成输出文件")
    return audio_path


async def _upload_to_oss(local_path: str, object_key: str) -> str:
    """上传文件到 OSS，返回签名URL（有效期1小时）。"""
    import mimetypes

    from app.media_storage import get_media_storage

    storage = get_media_storage()
    if not hasattr(storage, "sign_url"):
        raise RuntimeError("Configured media storage does not support signed URLs")

    # 上传（同步，放线程池避免阻塞事件循环）
    content_type = mimetypes.guess_type(local_path)[0] or "application/octet-stream"
    await asyncio.to_thread(storage.write_file, object_key, local_path, content_type)

    # 上传走内网 endpoint，签名下载使用 OSS_PUBLIC_BASE_URL 指定的公网 endpoint。
    return storage.sign_url(object_key)


async def _upload_video_to_oss_with_retry(
    local_path: str,
    oss_key: str,
    token: str,
    max_retries: int = 3,
):
    """Upload video to OSS with exponential backoff retry.

    On success: update session with oss_url.
    On failure: log warning, local file still available for scoring.
    """
    for attempt in range(max_retries):
        try:
            url = await _upload_to_oss(local_path, oss_key)
            if url:
                # 将 OSS URL 存入会话，供后续引用
                try:
                    update_interview_session(
                        token,
                        {
                            "oss_object_key": oss_key,
                            "recording_url": url,
                        },
                    )
                except Exception:
                    pass
                logger.info(f"Video uploaded to OSS: {oss_key}")
                return
        except Exception as e:
            wait = 2 ** (attempt + 1)  # 2s, 4s, 8s
            logger.warning(
                f"OSS upload attempt {attempt + 1}/{max_retries} failed for {oss_key}: {e}, retrying in {wait}s"
            )
            await asyncio.sleep(wait)

    logger.error(f"OSS upload failed after {max_retries} attempts: {oss_key}")


async def _asr_transcribe(audio_path: str) -> str:
    """qwen3-asr-flash ASR 转写（统一打点收口入口，逻辑见 _asr_transcribe_impl）。"""
    # 缓存命中不打点（未发生真实 API 调用）
    import hashlib as _hashlib

    from app.audit.token_tracker import track_llm_call

    _cache_key = _hashlib.md5(audio_path.encode()).hexdigest()
    if _cache_key in _asr_cache:
        return _asr_cache[_cache_key]

    with track_llm_call(
        "qwen3-asr-flash", agent="mass_interview", operation="asr_transcribe", call_type="audio"
    ) as _ctx:
        _ctx.success = False
        result = await _asr_transcribe_impl(audio_path)
        if result and not result.startswith("["):
            _ctx.success = True
            _ctx.usage = {"prompt_tokens": 0, "completion_tokens": len(result), "total_tokens": len(result)}
    return result


async def _asr_transcribe_impl(audio_path: str) -> str:
    """qwen3-asr-flash ASR 转写：上传OSS → 同步Chat调用，带缓存、日计数和并发控制。"""
    global _asr_daily_count, _asr_daily_date

    # 日计数重置
    today = datetime.now().strftime("%Y-%m-%d")
    if _asr_daily_date != today:
        _asr_daily_count = 0
        _asr_daily_date = today

    # 缓存命中
    import hashlib as _hashlib

    cache_key = _hashlib.md5(audio_path.encode()).hexdigest()
    if cache_key in _asr_cache:
        return _asr_cache[cache_key]

    # 日预算保护（500次/天）
    if _asr_daily_count >= 500:
        logger.warning(f"ASR daily limit reached ({_asr_daily_count}), skipping")
        return ""

    # 并发控制
    async with _asr_semaphore:
        oss_key = None
        try:
            import time
            import urllib.error
            import urllib.request

            start_time = time.time()

            # Step 1: 上传音频到 OSS
            filename = os.path.basename(audio_path)
            from app.infrastructure.config import settings
            from app.media_storage import join_storage_key

            oss_key = join_storage_key(settings.oss_video_prefix, "asr-temp", f"{cache_key}_{filename}")

            try:
                audio_url = await _upload_to_oss(audio_path, oss_key)
            except Exception as e:
                logger.error(f"OSS upload failed: {e}")
                return ""

            # Step 2: 调用 qwen3-asr-flash（DashScope Chat Completions，同步返回）
            api_key = os.getenv("DASHSCOPE_API_KEY", "") or os.getenv("OPENAI_API_KEY", "")
            if not api_key:
                logger.error("DASHSCOPE_API_KEY or OPENAI_API_KEY not set")
                return ""

            audio_format = _detect_audio_format(audio_path)

            payload = {
                "model": "qwen3-asr-flash",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_audio", "input_audio": {"data": audio_url, "format": audio_format}}
                        ],
                    }
                ],
            }

            api_url = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"

            req = urllib.request.Request(
                api_url,
                data=json.dumps(payload).encode(),
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )

            resp = await asyncio.wait_for(asyncio.to_thread(urllib.request.urlopen, req, timeout=60), timeout=60.0)

            resp_data = json.loads(resp.read().decode())

            # Step 3: 提取转写文本
            text = ""
            choices = resp_data.get("choices", [])
            if choices:
                message = choices[0].get("message", {})
                content = message.get("content", "")
                if isinstance(content, str):
                    text = content
                elif isinstance(content, list):
                    text = "".join(item.get("text", "") for item in content if isinstance(item, dict))

            elapsed = time.time() - start_time
            logger.info(f"ASR completed in {elapsed:.2f}s: {audio_path}")

            if elapsed > 30:
                logger.warning(f"ASR slow: {elapsed:.2f}s for {audio_path}")

            _asr_daily_count += 1

            if text:
                _asr_cache[cache_key] = text
                return text

            logger.warning(f"ASR returned empty result: {json.dumps(resp_data, ensure_ascii=False)[:200]}")
            return ""

        except TimeoutError:
            logger.error(f"ASR timeout: {audio_path}")
            return "[语音转写超时]"
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ""
            logger.error(f"ASR HTTP error {e.code}: {error_body[:300]}")
            return ""
        except Exception as e:
            logger.error(f"ASR error: {e}")
            return ""
        finally:
            # 清理 OSS 临时文件（异步，不阻塞返回）
            if oss_key:
                try:
                    from app.media_storage import get_media_storage

                    storage = get_media_storage()
                    if hasattr(storage, "bucket") and hasattr(storage.bucket, "delete_object"):
                        await asyncio.to_thread(storage.bucket.delete_object, oss_key)
                except Exception:
                    pass


# ── 音频特征提取 ──────────────────────────────────────────────


def _parse_volume(output: str, key: str) -> float:
    """从 ffmpeg volumedetect 输出解析音量值。"""
    import re

    pattern = rf"{key}:\s*(-?\d+\.?\d*)\s*dB"
    m = re.search(pattern, output)
    return float(m.group(1)) if m else -90.0


async def _extract_audio_features(audio_path: str) -> dict:
    """从 wav 文件提取语音特征（时长/音量/停顿）。"""
    features = {
        "duration_seconds": 0,
        "mean_volume_db": -90.0,
        "max_volume_db": -90.0,
        "silence_count": 0,
        "volume_range": 0,
    }

    if not _check_ffmpeg():
        return features

    try:
        # 获取时长
        proc = await asyncio.create_subprocess_exec(
            "ffprobe",
            "-v",
            "quiet",
            "-show_entries",
            "format=duration",
            "-of",
            "csv=p=0",
            audio_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await proc.communicate()
        if stdout:
            features["duration_seconds"] = round(float(stdout.decode().strip()), 1)

        # 音量检测
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg",
            "-i",
            audio_path,
            "-af",
            "volumedetect",
            "-f",
            "null",
            "-",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        vol_output = stderr.decode()
        features["mean_volume_db"] = _parse_volume(vol_output, "mean_volume")
        features["max_volume_db"] = _parse_volume(vol_output, "max_volume")
        features["volume_range"] = round(features["max_volume_db"] - features["mean_volume_db"], 1)

        # 静音段检测（停顿）
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg",
            "-i",
            audio_path,
            "-af",
            "silencedetect=noise=-30dB:d=0.5",
            "-f",
            "null",
            "-",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        features["silence_count"] = stderr.decode().count("silence_start")

    except Exception as e:
        logger.warning(f"Audio feature extraction failed: {e}")

    return features


# ── 智能截帧 ──────────────────────────────────────────────────


def _frame_quality_score(image_path: str) -> float:
    """评估帧质量：亮度 + 清晰度 + 人脸区域（纯 Pillow，不依赖 OpenCV）。"""
    try:
        from PIL import Image

        img = Image.open(image_path)

        # 亮度检测（太暗或过曝都扣分）
        gray = img.convert("L")
        pixels = list(gray.getdata())
        avg_brightness = sum(pixels) / len(pixels) if pixels else 128
        brightness_score = 1.0 - abs(avg_brightness - 128) / 128

        # 清晰度检测（边缘能量，简单差分）
        width, height = gray.size
        edge_sum = 0
        sample_count = 0
        for y in range(1, height, 4):
            for x in range(1, width, 4):
                diff = abs(gray.getpixel((x, y)) - gray.getpixel((x - 1, y)))
                edge_sum += diff
                sample_count += 1
        sharpness = min(edge_sum / max(sample_count, 1) / 50, 1.0)

        # 肤色区域检测（简单 RGB 阈值）
        rgb = img.convert("RGB")
        skin_pixels = 0
        total = 0
        for y in range(0, height, 8):
            for x in range(0, width, 8):
                r, g, b = rgb.getpixel((x, y))
                total += 1
                if (
                    r > 95
                    and g > 40
                    and b > 20
                    and r > g
                    and r > b
                    and abs(r - g) > 15
                    and max(r, g, b) - min(r, g, b) > 15
                ):
                    skin_pixels += 1
        face_ratio = skin_pixels / total if total > 0 else 0
        face_score = min(face_ratio * 5, 1.0)

        return brightness_score * 0.3 + sharpness * 0.3 + face_score * 0.4
    except Exception:
        return 0.0


async def _extract_smart_frames(video_path: str, max_frames: int = 3) -> list:
    """从视频智能截取人脸清晰帧，返回帧文件路径列表。"""
    if not _check_ffmpeg():
        return []

    tmp_dir = video_path.rsplit(".", 1)[0] + "_frames"
    os.makedirs(tmp_dir, exist_ok=True)

    try:
        # 每2秒截一帧（候选帧池）
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg",
            "-y",
            "-i",
            video_path,
            "-vf",
            "fps=1/2",
            "-q:v",
            "2",
            f"{tmp_dir}/frame_%03d.jpg",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate()

        # 对每帧做质量筛选
        candidates = sorted(glob.glob(f"{tmp_dir}/frame_*.jpg"))
        scored_frames = []
        for frame_path in candidates:
            score = _frame_quality_score(frame_path)
            if score > 0.3:
                scored_frames.append((score, frame_path))

        # 按质量排序，取 top N
        scored_frames.sort(key=lambda x: x[0], reverse=True)
        return [f[1] for f in scored_frames[:max_frames]]

    except Exception as e:
        logger.warning(f"Smart frame extraction failed: {e}")
        return []
    finally:
        # 不清理帧文件，由调用方清理
        pass


# ── 多模态异步评分 ────────────────────────────────────────────


async def _trigger_video_analysis(
    token: str,
    question_index: int,
    video_path: str,
    audio_features: dict,
    role: str,
    question_text: str,
):
    """截帧 + 触发异步多模态分析。"""
    try:
        frame_paths = await _extract_smart_frames(video_path, max_frames=3)
        if not frame_paths:
            logger.info(f"No quality frames for token={token} q{question_index}, skipping video analysis")
            # 标记为 failed（无帧可分析）
            session = get_interview_session(token)
            if session:
                answers = _parse_json_field(session, "answers")
                if question_index < len(answers) and isinstance(answers[question_index], dict):
                    answers[question_index]["video_analysis_status"] = "failed"
                    update_interview_session(token, {"answers": answers})
            return

        await _async_video_evaluate(
            token,
            question_index,
            frame_paths,
            audio_features,
            role,
            question_text,
        )
    except Exception as e:
        logger.error(f"Video analysis trigger failed: {e}")


async def _async_video_evaluate(
    token: str,
    question_index: int,
    frame_paths: list,
    audio_features: dict,
    role: str,
    question_text: str,
):
    """异步执行多模态视频分析，结果写回 answers[qi].video_analysis。"""
    try:
        from hr_harness.agents.mass_interview_agent import MassInterviewAgent

        agent = MassInterviewAgent()

        # 更新状态为 processing
        session = get_interview_session(token)
        if session:
            answers = _parse_json_field(session, "answers")
            if question_index < len(answers) and isinstance(answers[question_index], dict):
                answers[question_index]["video_analysis_status"] = "processing"
                update_interview_session(token, {"answers": answers})

        result = await agent.video_evaluate(
            frame_paths=frame_paths,
            audio_features=audio_features,
            role=role,
            question=question_text,
        )

        # 写回结果
        session = get_interview_session(token)
        if session:
            answers = _parse_json_field(session, "answers")
            if question_index < len(answers) and isinstance(answers[question_index], dict):
                answers[question_index]["video_analysis"] = result
                answers[question_index]["video_analysis_status"] = "done"
                update_interview_session(token, {"answers": answers})

    except Exception as e:
        logger.error(f"Video evaluate failed for token={token} q{question_index}: {e}")
        # 标记失败
        try:
            session = get_interview_session(token)
            if session:
                answers = _parse_json_field(session, "answers")
                if question_index < len(answers) and isinstance(answers[question_index], dict):
                    answers[question_index]["video_analysis_status"] = "failed"
                    update_interview_session(token, {"answers": answers})
        except Exception:
            pass
    finally:
        # 清理截帧文件
        for fp in frame_paths:
            try:
                os.remove(fp)
            except Exception:
                pass
        # 清理帧目录（如果为空）
        if frame_paths:
            frame_dir = os.path.dirname(frame_paths[0])
            try:
                if not os.listdir(frame_dir):
                    os.rmdir(frame_dir)
            except Exception:
                pass


# ── 设备检测 ──────────────────────────────────────────────────


@router.post("/session/{token}/device-check")
async def api_device_check(
    token: str,
    video_file: UploadFile = File(...),
    client_id: str = Header("", alias="X-Session-Client-Id"),
):
    """候选人设备检测：试录3秒视频，检测摄像头/麦克风/光线/人脸。"""
    session = get_interview_session(token)
    if not session:
        raise HTTPException(404, "Session not found")
    if _effective_interview_status(session) == "expired":
        update_interview_session(token, {"status": "expired"})
        raise HTTPException(400, "面试已结束")
    _require_interview_lease(session, client_id)

    # 读取上传文件，限制大小为 5MB
    content = await video_file.read()
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(413, "设备检测视频不能超过5MB，请缩短录制时间或降低分辨率")
    if len(content) < 100:
        raise HTTPException(400, "视频文件过小，录制可能失败，请重试")

    # 保存试录视频到临时位置
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    result = {
        "camera_ok": True,
        "audio_ok": False,
        "lighting_ok": True,
        "face_detected": True,
        "suggestions": [],
    }

    try:
        if not _check_ffmpeg():
            result["suggestions"].append("服务器 ffmpeg 不可用，跳过检测")
            result["audio_ok"] = True
            result["lighting_ok"] = True
            result["face_detected"] = True
            return result

        # 音频检测：提取音频并检查音量
        audio_path = tmp_path + "_check.wav"
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg",
            "-y",
            "-i",
            tmp_path,
            "-vn",
            "-acodec",
            "pcm_s16le",
            "-ar",
            "16000",
            "-ac",
            "1",
            audio_path,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate()

        if os.path.exists(audio_path):
            features = await _extract_audio_features(audio_path)
            if features["mean_volume_db"] > -50:
                result["audio_ok"] = True
            else:
                result["suggestions"].append("声音太小，请靠近手机说话")
            try:
                os.remove(audio_path)
            except Exception:
                pass
        else:
            result["suggestions"].append("无法提取音频，请检查麦克风权限")

        # 光线 + 人脸检测：简化跳过（服务行业候选人不需要复杂检测）
        result["lighting_ok"] = True
        result["face_detected"] = True

    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass

    return result


# ============ Pipeline 选择器 ============


@router.get("/hr-users")
async def api_list_interview_hr_users(request: Request):
    """Return HR accounts available for the interview-center selector.

    HR users can only select themselves. Tenant administrators may select
    active HR accounts and the special "all" option in the UI.
    """
    conn = get_db()
    user = require_current_user(request)
    current_user_id = str(user["id"])
    if is_tenant_admin(user):
        rows = conn.execute(
            """SELECT id, username, display_name, role_id
               FROM auth_users
               WHERE is_active=1 AND role_id='hr_specialist'
               ORDER BY display_name, username """
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT id, username, display_name, role_id
               FROM auth_users
               WHERE id=%s AND is_active=1""",
            (current_user_id,),
        ).fetchall()
    return {
        "users": [
            {
                "id": row["id"],
                "username": row["username"] or "",
                "display_name": row["display_name"] or row["username"] or row["id"],
                "role_id": row["role_id"] or "",
            }
            for row in rows
        ],
        "current_user_id": current_user_id,
        "can_select_all": is_tenant_admin(user),
    }


@router.get("/pipelines")
async def api_list_pipelines(
    request: Request,
    owner_user_id: str = Query(default=""),
    hr_name: str = Query(default=""),
    role: str = Query(default=""),
    start_date: str = Query(default=""),
    end_date: str = Query(default=""),
):
    """返回有面试 session 的 pipeline 列表，供前端下拉选择器使用"""
    from app.db import _table_columns, get_db

    conn = get_db()
    user = require_current_user(request)
    params: list[str] = [tenant_id_for_user(user)]
    # 面试中心需要回看历史批次，因此展示租户内所有可访问流水线，
    # 包括招聘流程已完成的流水线。日期范围只用于候选人数据筛选，
    # 不能导致岗位从下拉框消失。
    clauses = ["p.tenant_id=%s"]
    if role.strip():
        clauses.append("p.role LIKE %s")
        params.append(f"%{role.strip()}%")
    # The account ID is the authoritative selector. Ordinary HR users are
    # always restricted to their own pipelines, regardless of request input.
    selected_owner_id = owner_user_id.strip()
    if not is_tenant_admin(user):
        selected_owner_id = str(user["id"])
    if selected_owner_id:
        clauses.append("p.owner_user_id=%s")
        params.append(selected_owner_id)
    elif hr_name.strip() and is_tenant_admin(user):
        # Temporary compatibility for older clients; new clients must send
        # owner_user_id and must not rely on display-name matching.
        clauses.append("u.display_name LIKE %s")
        params.append(f"%{hr_name.strip()}%")
    where_sql = " AND ".join(clauses)
    # Some long-lived MySQL deployments predate pipelines.type. Do not make
    # the selector unavailable while the startup migration catches up.
    pipeline_columns = set(_table_columns(conn, "pipelines"))
    job_type_expression = "p.type" if "type" in pipeline_columns else "'general'"
    job_type_sql = f"{job_type_expression} AS job_type"
    try:
        rows = conn.execute(
            f"""SELECT p.id, p.role, p.owner_user_id, {job_type_sql}, u.display_name AS hr_name,
                      MAX(s.id) AS latest_session_id
               FROM pipelines p
               LEFT JOIN auth_users u ON u.id = p.owner_user_id
               LEFT JOIN interview_sessions s ON s.pipeline_id = p.id
               WHERE {where_sql}
               GROUP BY p.id, p.role, {job_type_expression}, u.display_name
               ORDER BY latest_session_id DESC""",
            params,
        ).fetchall()
    except Exception:
        # 旧数据库尚未创建笔试表时，仍允许视频面试中心正常打开。
        rows = conn.execute(
            f"""SELECT p.id, p.role, p.owner_user_id, {job_type_sql}, u.display_name AS hr_name,
                      MAX(s.id) AS latest_session_id
               FROM pipelines p
               LEFT JOIN auth_users u ON u.id = p.owner_user_id
               JOIN interview_sessions s ON s.pipeline_id = p.id
               WHERE {where_sql}
               GROUP BY p.id, p.role, {job_type_expression}, u.display_name
               ORDER BY latest_session_id DESC""",
            params,
        ).fetchall()
    pipelines = [
        {
            "id": r["id"],
            "role": r["role"] or r["id"],
            "job_type": r["job_type"] or "general",
            "hr_name": r["hr_name"] or "",
            "owner_user_id": r["owner_user_id"] or "",
        }
        for r in rows
    ]
    return {"pipelines": pipelines}


@router.get("/pipeline-for/{source_pipeline_id}")
async def api_pipeline_for_source(source_pipeline_id: str, request: Request):
    """Resolve a pipeline for the interview center by its stable ID.

    Historical workflows may use separate IDs for the hiring and interview
    pipelines, so authorized callers retain the candidate-overlap fallback.
    """
    conn = get_db()
    user = require_current_user(request)
    require_pipeline_access(request, source_pipeline_id)
    source = conn.execute("SELECT role, tenant_id FROM pipelines WHERE id=%s", (source_pipeline_id,)).fetchone()
    if not source:
        return {"source_pipeline_id": source_pipeline_id, "pipeline_id": ""}

    source_names = {
        row[0]
        for row in conn.execute(
            "SELECT DISTINCT name FROM candidates WHERE pipeline_id=%s AND name IS NOT NULL AND name<>''",
            (source_pipeline_id,),
        ).fetchall()
    }
    if not source_names:
        return {"source_pipeline_id": source_pipeline_id, "pipeline_id": ""}

    if is_tenant_admin(user):
        rows = conn.execute(
            """SELECT s.pipeline_id, p.role, s.candidate_name, MAX(s.created_at) AS latest
               FROM interview_sessions s JOIN pipelines p ON p.id=s.pipeline_id
               WHERE p.tenant_id=%s GROUP BY s.pipeline_id, p.role, s.candidate_name
               ORDER BY latest DESC""",
            (tenant_id_for_user(user),),
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT s.pipeline_id, p.role, s.candidate_name, MAX(s.created_at) AS latest
               FROM interview_sessions s JOIN pipelines p ON p.id=s.pipeline_id
               WHERE p.tenant_id=%s AND p.owner_user_id=%s
               GROUP BY s.pipeline_id, p.role, s.candidate_name
               ORDER BY latest DESC""",
            (tenant_id_for_user(user), str(user["id"])),
        ).fetchall()

    candidates_by_pipeline: dict[str, dict] = {}
    for row in rows:
        item = candidates_by_pipeline.setdefault(row[0], {"role": row[1] or "", "names": set(), "latest": row[3] or ""})
        if row[2]:
            item["names"].add(row[2])
        item["latest"] = max(item["latest"], row[3] or "")

    source_role = source[0] or ""
    ranked = sorted(
        candidates_by_pipeline.items(),
        key=lambda pair: (
            len(source_names & pair[1]["names"]),
            int(bool(source_role and pair[1]["role"] == source_role)),
            pair[1]["latest"],
        ),
        reverse=True,
    )
    target_id = ranked[0][0] if ranked and source_names & ranked[0][1]["names"] else ""
    return {"source_pipeline_id": source_pipeline_id, "pipeline_id": target_id}


# ============ 阿里云直播 — 流管理 + 回调 ============
#
# The implementation lives in mass_interview_streams. These wrappers preserve
# direct imports used by internal dispatches and older tests.


def _stream_routes():
    from app.routers import mass_interview_streams

    return mass_interview_streams


async def api_streams_status(pipeline_id: str, request: Request = None, owner_user_id: str = ""):
    return await _stream_routes().api_streams_status(pipeline_id, request, owner_user_id)


async def api_kick_stream(stream_name: str, request: Request):
    return await _stream_routes().api_kick_stream(stream_name, request)


async def api_stream_snapshot(stream_name: str, request: Request = None):
    return await _stream_routes().api_stream_snapshot(stream_name, request)


async def api_recording_url(stream_name: str, request: Request = None):
    return await _stream_routes().api_recording_url(stream_name, request)


async def api_alicloud_config():
    return await _stream_routes().api_alicloud_config()


async def _verified_live_callback(request: Request) -> dict:
    return await _stream_routes()._verified_live_callback(request)


async def callback_stream_start(request: Request):
    return await _stream_routes().callback_stream_start(request)


async def callback_stream_end(request: Request):
    return await _stream_routes().callback_stream_end(request)


async def callback_recording_complete(request: Request):
    return await _stream_routes().callback_recording_complete(request)
