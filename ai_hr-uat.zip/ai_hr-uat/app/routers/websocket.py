"""WebSocket routes — real-time pipeline communication."""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app import state
from app.access_control import COOKIE_NAME, is_tenant_admin, tenant_id_for_user, user_from_session_token
from app.db import (
    create_pipeline,
    _effective_interview_status,
    get_candidates,
    get_messages,
    get_pipeline_for_user,
    get_stages,
    list_pipelines_for_user,
)

router = APIRouter(tags=["websocket"])

# 日志记录器
from app.audit.logger import get_logger

logger = get_logger("ws")


async def _authorize_pipeline_websocket(websocket: WebSocket, pipeline_id: str) -> dict | None:
    user = user_from_session_token(websocket.cookies.get(COOKIE_NAME, ""))
    if not user:
        await websocket.close(code=4401)
        return None
    pipeline = get_pipeline_for_user(
        pipeline_id,
        str(user["id"]),
        tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
    )
    if not pipeline:
        await websocket.close(code=4404)
        return None
    return pipeline


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    user = user_from_session_token(websocket.cookies.get(COOKIE_NAME, ""))
    await websocket.accept()
    state.connections.append(websocket)

    try:
        # 连接建立后发送现有流水线
        pipelines = (
            list_pipelines_for_user(
                str(user["id"]),
                tenant_id_for_user(user),
                include_all=is_tenant_admin(user),
            )
            if user
            else []
        )
        if pipelines:
            await websocket.send_json({"type": "history", "pipelines": pipelines})

        async def safe_send(data):
            try:
                await websocket.send_json(data)
            except (RuntimeError, Exception):
                pass

        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)

            if not user and msg.get("type") != "unsubscribe_all":
                await websocket.send_json({"type": "auth_required"})
                continue

            if msg.get("type") == "start_pipeline":
                role = msg.get("role", "高级前端工程师")
                hints = msg.get("hints", "")
                quiz_answers = msg.get("quiz_answers", [])

                pipeline_id = f"p_{uuid.uuid4().hex[:8]}"
                create_pipeline(
                    pipeline_id,
                    role,
                    owner_user_id=str(user["id"]),
                    tenant_id=tenant_id_for_user(user),
                )

                _pid_ref = [None]

                async def on_plan_ready(plan, pipeline_id):
                    _pid_ref[0] = pipeline_id
                    state._ws_subscriptions[websocket] = {pipeline_id}
                    stages_list = [s["stage_id"] for s in plan.get("pipeline", [])]
                    stage_names = {s["stage_id"]: s.get("stage_name", s["stage_id"]) for s in plan.get("pipeline", [])}
                    await safe_send(
                        {
                            "type": "pipeline_started",
                            "pipeline_id": pipeline_id,
                            "role": role,
                            "stages": stages_list,
                            "stage_names": stage_names,
                            "plan": plan,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_stage_start(stage_id, stage_name):
                    await safe_send(
                        {
                            "type": "stage_start",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "stage_name": stage_name,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_stage_done(stage_id, stage_name, output):
                    await safe_send(
                        {
                            "type": "stage_done",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "stage_name": stage_name,
                            "output": output,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_stage_card(stage_id, card):
                    await safe_send(
                        {
                            "type": "stage_card",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "card": card,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_pipeline_done(result):
                    await safe_send(
                        {
                            "type": "pipeline_done",
                            "pipeline_id": result["pipeline_id"],
                            "role": result["role"],
                            "status": result.get("status", "completed"),
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_error(stage_id, stage_name, error):
                    await safe_send(
                        {
                            "type": "stage_error",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "stage_name": stage_name,
                            "error": error,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_stage_retrying(stage_id, stage_name, attempt, max_retries):
                    await safe_send(
                        {
                            "type": "stage_retrying",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "stage_name": stage_name,
                            "attempt": attempt,
                            "max_retries": max_retries,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                async def on_stage_progress(stage_id, message):
                    await safe_send(
                        {
                            "type": "stage_progress",
                            "pipeline_id": _pid_ref[0],
                            "stage_id": stage_id,
                            "message": message,
                            "timestamp": datetime.now().isoformat(),
                        }
                    )

                asyncio.create_task(
                    state.get_supervisor().run_pipeline(
                        role=role,
                        user_hints=hints,
                        quiz_answers=quiz_answers,
                        on_stage_start=on_stage_start,
                        on_stage_done=on_stage_done,
                        on_stage_card=on_stage_card,
                        on_stage_retrying=on_stage_retrying,
                        on_stage_progress=on_stage_progress,
                        on_pipeline_done=on_pipeline_done,
                        on_error=on_error,
                        on_plan_ready=on_plan_ready,
                        pipeline_id=pipeline_id,
                    )
                )

            elif msg.get("type") == "unsubscribe_all":
                state._ws_subscriptions.pop(websocket, None)

            elif msg.get("type") == "unload_pipeline":
                pid = msg.get("pipeline_id")
                if pid and websocket in state._ws_subscriptions:
                    state._ws_subscriptions[websocket].discard(pid)

            elif msg.get("type") == "load_pipeline":
                pid = msg.get("pipeline_id")
                if pid:
                    state._ws_subscriptions[websocket] = {pid}
                pipeline = get_pipeline_for_user(
                    pid,
                    str(user["id"]),
                    tenant_id_for_user(user),
                    include_all=is_tenant_admin(user),
                )
                if pipeline:
                    pipeline["context"] = json.loads(pipeline["context"]) if pipeline.get("context") else {}
                    pipeline["stages"] = get_stages(pid)
                    for s in pipeline["stages"]:
                        if isinstance(s.get("output"), str):
                            try:
                                s["output"] = json.loads(s["output"])
                            except (json.JSONDecodeError, TypeError):
                                s["output"] = {}
                        elif not s.get("output"):
                            s["output"] = {}
                    pipeline["candidates"] = get_candidates(pid)
                    pipeline["messages"] = get_messages(pid)
                    await websocket.send_json({"type": "pipeline_loaded", "pipeline": pipeline})

    except WebSocketDisconnect:
        if websocket in state.connections:
            state.connections.remove(websocket)
        state._ws_subscriptions.pop(websocket, None)
    except Exception as e:
        logger.error(f"{e}", extra={"source": "WS"})
        if websocket in state.connections:
            state.connections.remove(websocket)


@router.websocket("/ws/{pipeline_id}")
async def websocket_pipeline_endpoint(websocket: WebSocket, pipeline_id: str):
    """Pipeline-specific WebSocket endpoint for agent pages"""
    pipeline = await _authorize_pipeline_websocket(websocket, pipeline_id)
    if not pipeline:
        return
    await websocket.accept()
    state.connections.append(websocket)
    if not hasattr(state, "_ws_subscriptions"):
        state._ws_subscriptions = {}
    state._ws_subscriptions[websocket] = {pipeline_id}

    try:
        if pipeline:
            stages = get_stages(pipeline_id)
            candidates = get_candidates(pipeline_id)
            messages = get_messages(pipeline_id)
            await websocket.send_json(
                {
                    "type": "pipeline_loaded",
                    "pipeline_id": pipeline_id,
                    "data": {
                        "pipeline": pipeline,
                        "stages": stages,
                        "candidates": candidates,
                        "messages": messages[-20:] if messages else [],
                    },
                }
            )

        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            msg_type = msg.get("type", "")

            if msg_type == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        if websocket in state.connections:
            state.connections.remove(websocket)
        state._ws_subscriptions.pop(websocket, None)
    except Exception as e:
        logger.error(f"Pipeline WS error: {e}", extra={"source": "WS"})
        if websocket in state.connections:
            state.connections.remove(websocket)
        state._ws_subscriptions.pop(websocket, None)


# ============ 百人面试 WebSocket ============


@router.websocket("/ws/mass-interview/{token}")
async def ws_mass_interview_candidate(websocket: WebSocket, token: str):
    """候选人端WebSocket — 接收推流状态通知、超时提醒等"""
    await websocket.accept()

    # 注册到candidate_clients
    state.candidate_clients[token] = websocket

    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            msg_type = msg.get("type", "")

            if msg_type == "heartbeat":
                await websocket.send_json({"type": "pong"})

            elif msg_type == "question_started":
                # 候选人开始回答某题，通知HR监控端
                from app.db import get_interview_session

                session = get_interview_session(token)
                if session:
                    pipeline_id = session.get("pipeline_id", "")
                    await _broadcast_monitor(
                        pipeline_id,
                        {
                            "type": "candidate_progress",
                            "pipeline_id": pipeline_id,
                            "token": token,
                            "candidate_id": session.get("candidate_id", ""),
                            "stream_name": session.get("stream_name", ""),
                            "event": "question_started",
                            "status": session.get("status", ""),
                            "current_question": msg.get("question_index", 0),
                            "total_questions": len(session.get("questions") or []),
                        },
                    )

            elif msg_type == "recording_started":
                from app.db import get_interview_session

                session = get_interview_session(token)
                if session:
                    pipeline_id = session.get("pipeline_id", "")
                    await _broadcast_monitor(
                        pipeline_id,
                        {
                            "type": "candidate_progress",
                            "pipeline_id": pipeline_id,
                            "token": token,
                            "candidate_id": session.get("candidate_id", ""),
                            "stream_name": session.get("stream_name", ""),
                            "event": "recording_started",
                            "status": session.get("status", ""),
                            "current_question": msg.get("question_index", 0),
                            "total_questions": len(session.get("questions") or []),
                        },
                    )

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"Mass interview candidate WS error: {e}", extra={"source": "WS"})
    finally:
        if state.candidate_clients.get(token) is websocket:
            state.candidate_clients.pop(token, None)


@router.websocket("/ws/mass-monitor/{pipeline_id}")
async def ws_mass_monitor(websocket: WebSocket, pipeline_id: str):
    """HR监控端WebSocket — 接收候选人上线/离线/答题等实时事件"""
    if not await _authorize_pipeline_websocket(websocket, pipeline_id):
        return
    await websocket.accept()

    # 注册到monitor_clients
    if pipeline_id not in state.monitor_clients:
        state.monitor_clients[pipeline_id] = set()
    state.monitor_clients[pipeline_id].add(websocket)

    try:
        # 发送初始状态
        from app.db import get_interview_sessions, get_session_stats

        sessions = get_interview_sessions(pipeline_id)
        stats = get_session_stats(pipeline_id, sessions)
        await websocket.send_json(
            {
                "type": "initial_state",
                "sessions": [
                    {
                        "token": s.get("token", ""),
                        "candidate_name": s.get("candidate_name", ""),
                        "stream_name": s.get("stream_name", ""),
                        "status": _effective_interview_status(s),
                        "is_streaming": s.get("is_streaming", 0),
                        "current_question": s.get("current_question", 0),
                        "total_questions": s.get("total_questions", 5),
                    }
                    for s in sessions
                ],
                "stats": stats,
            }
        )

        # 保持连接
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get("type") == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"Mass monitor WS error: {e}", extra={"source": "WS"})
    finally:
        if pipeline_id in state.monitor_clients:
            state.monitor_clients[pipeline_id].discard(websocket)
            if not state.monitor_clients[pipeline_id]:
                state.monitor_clients.pop(pipeline_id, None)


async def _broadcast_monitor(pipeline_id: str, data: dict):
    """广播消息给HR监控端所有WebSocket客户端"""
    clients = state.monitor_clients.get(pipeline_id, set())
    dead = []
    for ws in clients:
        try:
            await ws.send_json(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)
    if not clients:
        state.monitor_clients.pop(pipeline_id, None)


async def broadcast_monitor_event(
    pipeline_id: str,
    event_type: str,
    session: dict | None = None,
    **payload,
):
    """Broadcast one typed mass-interview update to the HR monitor clients."""
    if not pipeline_id:
        return
    data = {"type": event_type, "pipeline_id": pipeline_id}
    if session:
        data.update(
            {
                "token": session.get("token", ""),
                "candidate_id": session.get("candidate_id", ""),
                "candidate_name": session.get("candidate_name", ""),
                "stream_name": session.get("stream_name", ""),
            }
        )
    data.update(payload)
    await _broadcast_monitor(pipeline_id, data)
