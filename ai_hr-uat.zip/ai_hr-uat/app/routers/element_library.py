"""Element library API — list/serve/upload/delete backgrounds and elements."""

from __future__ import annotations

import copy
import json
import time
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response

from app.access_control import has_permission, require_current_user
from app.config import REACT_PUBLIC_DIR
from app.image_thumbnails import create_thumbnail_bytes
from app.infrastructure.config import settings
from app.media_storage import MediaStorage, get_media_storage, join_storage_key, storage_cache_key

router = APIRouter(tags=["element-library"])

ELEMENT_LIBRARY_DIR = Path(REACT_PUBLIC_DIR) / "xiao-hai" / "elements"

_ALLOWED_KINDS = {"backgrounds", "elements"}
_ALLOWED_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
_ID_PREFIX = {"backgrounds": "bg", "elements": "el"}
_MAX_UPLOAD_BYTES = 20 * 1024 * 1024  # 20MB

_MEDIA_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}


def _require_materials_access(request: Request) -> dict:
    user = require_current_user(request)
    if not has_permission(user, "materials:read"):
        raise HTTPException(status_code=403, detail="无权访问此功能")
    return user


def _require_element_read_access(request: Request) -> dict:
    user = require_current_user(request)
    if not has_permission(user, {"materials:read", "pipeline:read"}):
        raise HTTPException(status_code=403, detail="无权访问此功能")
    return user


_OSS_ELEMENTS_PREFIX = join_storage_key(settings.oss_xiao_hai_prefix, "elements")
_OSS_MANIFEST_KEY = join_storage_key(_OSS_ELEMENTS_PREFIX, "manifest.json")
_MANIFEST_CACHE_TTL_SECONDS = 30.0
_MANIFEST_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}


def _storage_key(kind: str, filename: str) -> str:
    return join_storage_key(_OSS_ELEMENTS_PREFIX, kind, filename)


def _thumbnail_filename(entry_id: str) -> str:
    return f"{entry_id}.thumb.webp"


def _thumbnail_storage_key(kind: str, entry_id: str) -> str:
    return _storage_key(kind, _thumbnail_filename(entry_id))


def _is_oss(storage: MediaStorage) -> bool:
    return storage.backend == "oss"


def _load_manifest(storage: MediaStorage | None = None) -> dict[str, Any]:
    storage = storage or get_media_storage()
    cache_key = storage_cache_key(storage)
    if _is_oss(storage):
        cached = _MANIFEST_CACHE.get(cache_key)
        if cached and time.monotonic() - cached[0] < _MANIFEST_CACHE_TTL_SECONDS:
            return copy.deepcopy(cached[1])
    if _is_oss(storage) and storage.exists(_OSS_MANIFEST_KEY):
        try:
            data = json.loads(storage.read(_OSS_MANIFEST_KEY).decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            data = {}
    else:
        manifest_path = ELEMENT_LIBRARY_DIR / "manifest.json"
        if not manifest_path.exists():
            return {"backgrounds": [], "elements": []}
        try:
            with open(manifest_path, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            return {"backgrounds": [], "elements": []}
    if not isinstance(data, dict):
        return {"backgrounds": [], "elements": []}

    existing_keys = set(storage.list_keys(f"{_OSS_ELEMENTS_PREFIX}/")) if _is_oss(storage) else set()

    # 历史清单可能遗留已删除文件，只向前端暴露实际存在的素材。
    for kind in _ALLOWED_KINDS:
        valid_items = []
        for item in data.get(kind, []):
            if not isinstance(item, dict) or not item.get("file"):
                continue
            file_key = item.get("storage_key") or _storage_key(kind, item["file"])
            if _is_oss(storage):
                if file_key not in existing_keys:
                    continue
                item = dict(item)
                thumb = item.get("thumb") or ""
                thumb_key = item.get("thumb_storage_key") or (_storage_key(kind, thumb) if thumb else "")
                if thumb_key and thumb_key not in existing_keys:
                    item.pop("thumb", None)
                    item.pop("thumb_storage_key", None)
            elif not (ELEMENT_LIBRARY_DIR / kind / item["file"]).is_file():
                continue
            valid_items.append(item)
        data[kind] = valid_items
    if _is_oss(storage):
        _MANIFEST_CACHE[cache_key] = (time.monotonic(), copy.deepcopy(data))
    return data


def _save_manifest(manifest: dict[str, Any], storage: MediaStorage | None = None) -> None:
    storage = storage or get_media_storage()
    payload = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
    if _is_oss(storage):
        storage.write(_OSS_MANIFEST_KEY, payload, "application/json")
        _MANIFEST_CACHE.pop(storage_cache_key(storage), None)
        return
    manifest_path = ELEMENT_LIBRARY_DIR / "manifest.json"
    manifest_path.write_bytes(payload)


def _enrich_items(items: list | None, kind: str, storage: MediaStorage | None = None) -> list[dict[str, Any]]:
    """Add url/thumb_url to manifest entries for the frontend grid."""
    storage = storage or get_media_storage()
    enriched = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        file_name = item.get("file") or ""
        thumb = item.get("thumb") or ""
        entry = dict(item)
        file_key = entry.get("storage_key") or (_storage_key(kind, file_name) if file_name else "")
        thumb_key = entry.get("thumb_storage_key") or (_storage_key(kind, thumb) if thumb else "")
        entry["url"] = (
            storage.sign_url(file_key)
            if file_key and _is_oss(storage) and hasattr(storage, "sign_url")
            else f"/api/xiao-hai/elements/{kind}/{file_name}"
            if file_name
            else ""
        )
        entry["thumb_url"] = (
            storage.sign_url(thumb_key)
            if thumb_key and _is_oss(storage) and hasattr(storage, "sign_url")
            else f"/api/xiao-hai/elements/{kind}/{thumb}"
            if thumb
            else ""
        )
        # 没有独立缩略图时，使用原文件作为缩略图
        entry["thumb_url"] = entry["thumb_url"] or entry["url"]
        enriched.append(entry)
    return enriched


@router.get("/api/xiao-hai/elements")
async def list_elements(request: Request):
    """List available backgrounds and composable elements."""
    _require_element_read_access(request)
    storage = get_media_storage()
    if not _is_oss(storage) and not ELEMENT_LIBRARY_DIR.exists():
        raise HTTPException(404, "Element library not found")

    manifest = _load_manifest(storage)
    return {
        "backgrounds": _enrich_items(manifest.get("backgrounds"), "backgrounds", storage),
        "elements": _enrich_items(manifest.get("elements"), "elements", storage),
    }


def _store_entry(
    kind: str,
    data: bytes,
    original_name: str,
    storage: MediaStorage | None = None,
) -> dict[str, Any]:
    """Persist one uploaded file and return its manifest entry."""
    storage = storage or get_media_storage()

    suffix = Path(original_name).suffix.lower() or ".png"
    entry_id = f"{_ID_PREFIX[kind]}_{uuid.uuid4().hex[:8]}"
    filename = f"{entry_id}{suffix}"
    object_key = _storage_key(kind, filename)
    thumbnail_filename = _thumbnail_filename(entry_id)
    thumbnail_key = _thumbnail_storage_key(kind, entry_id)
    thumbnail_data = create_thumbnail_bytes(data)
    if _is_oss(storage):
        storage.write(object_key, data, _MEDIA_TYPES.get(suffix, "application/octet-stream"))
        storage.write(thumbnail_key, thumbnail_data, "image/webp")
    else:
        kind_dir = ELEMENT_LIBRARY_DIR / kind
        kind_dir.mkdir(parents=True, exist_ok=True)
        (kind_dir / filename).write_bytes(data)
        (kind_dir / thumbnail_filename).write_bytes(thumbnail_data)

    entry = {
        "id": entry_id,
        "label": Path(original_name).stem or entry_id,
        "group": "custom",
        "file": filename,
        "thumb": thumbnail_filename,
        "placement_hint": "",
        "size_hint": "",
    }
    if _is_oss(storage):
        entry["storage_key"] = object_key
        entry["thumb_storage_key"] = thumbnail_key
    if kind == "backgrounds":
        entry["placement_hint"] = "铺满整个画幅，作为海报底层背景"
        entry["size_hint"] = "cover"
    return entry


@router.post("/api/xiao-hai/elements/{kind}")
async def upload_elements(
    kind: str,
    request: Request,
    files: list[UploadFile] = File(...),
):
    """Batch-upload backgrounds or elements into the library."""
    _require_materials_access(request)
    if kind not in _ALLOWED_KINDS:
        raise HTTPException(404, "Unknown element kind")

    storage = get_media_storage()
    manifest = _load_manifest(storage)
    kind_entries = manifest.setdefault(kind, [])

    uploaded: list[dict[str, Any]] = []
    skipped: list[str] = []
    for file in files:
        original_name = file.filename or ""
        suffix = Path(original_name).suffix.lower()
        if suffix not in _ALLOWED_EXTS:
            skipped.append(original_name or "(无扩展名)")
            continue

        data = await file.read()
        if not data:
            skipped.append(original_name or "(空文件)")
            continue
        if len(data) > _MAX_UPLOAD_BYTES:
            skipped.append(f"{original_name}（超过 20MB）")
            continue

        try:
            entry = _store_entry(kind, data, original_name, storage)
        except (OSError, ValueError):
            skipped.append(f"{original_name}（无法解析图片）")
            continue
        kind_entries.append(entry)
        uploaded.append(entry)

    _save_manifest(manifest, storage)

    return {
        "ok": True,
        "kind": kind,
        "uploaded": _enrich_items(uploaded, kind, storage),
        "skipped": skipped,
    }


@router.get("/api/xiao-hai/elements/{kind}/{filename}")
async def get_element_file(kind: str, filename: str, request: Request):
    """Serve a background or element image file. Whitelist kinds, block traversal."""
    _require_element_read_access(request)
    if kind not in _ALLOWED_KINDS:
        raise HTTPException(404, "Unknown element kind")

    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(400, "Invalid filename")

    storage = get_media_storage()
    object_key = _storage_key(kind, filename)
    if _is_oss(storage) and storage.exists(object_key):
        return Response(storage.read(object_key), media_type=_MEDIA_TYPES.get(Path(filename).suffix.lower()))

    file_path = ELEMENT_LIBRARY_DIR / kind / filename
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(404, "File not found")

    media_type = _MEDIA_TYPES.get(file_path.suffix.lower(), "application/octet-stream")
    return FileResponse(file_path, media_type=media_type)


@router.delete("/api/xiao-hai/elements/{kind}/{entry_id}")
async def delete_element(kind: str, entry_id: str, request: Request):
    """Delete a background or element from the library (manifest + files)."""
    _require_materials_access(request)
    if kind not in _ALLOWED_KINDS:
        raise HTTPException(404, "Unknown element kind")
    if not entry_id or ".." in entry_id or "/" in entry_id or "\\" in entry_id:
        raise HTTPException(400, "Invalid element id")

    storage = get_media_storage()
    manifest = _load_manifest(storage)
    items = list(manifest.get(kind) or [])
    entry = next((e for e in items if isinstance(e, dict) and e.get("id") == entry_id), None)
    if not entry:
        raise HTTPException(404, "素材不存在")

    deleted_keys: set[str] = set()
    for field, key_field in (("file", "storage_key"), ("thumb", "thumb_storage_key")):
        fname = entry.get(field)
        if not fname:
            continue
        object_key = entry.get(key_field) or _storage_key(kind, fname)
        if object_key in deleted_keys:
            continue
        deleted_keys.add(object_key)
        if _is_oss(storage):
            storage.delete(object_key)
        else:
            try:
                (ELEMENT_LIBRARY_DIR / kind / fname).unlink(missing_ok=True)
            except OSError:
                pass

    manifest[kind] = [e for e in items if not (isinstance(e, dict) and e.get("id") == entry_id)]
    _save_manifest(manifest, storage)

    return {"ok": True, "id": entry_id}
