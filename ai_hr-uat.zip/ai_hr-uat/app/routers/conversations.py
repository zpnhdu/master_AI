"""统一 Agent 会话的 HTTP 与受保护 WebSocket 接口。"""

from fastapi import APIRouter, BackgroundTasks, File, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from app import conversation_store
from app.access_control import COOKIE_NAME, LEGACY_TEST_COOKIE, require_pipeline_access, user_from_session_token
from app.conversation_events import publish, subscribe, unsubscribe
from app.conversation_service import (
    ConversationError,
    cancel_command,
    confirm_command,
    ensure_session,
    get_session_messages,
    get_session_state,
    get_snapshot,
    repreview_command,
    submit_session_message,
    undo_command,
)
from app.poster_jobs import run_generation_job
from app.poster_service import PosterService, PosterServiceError

router = APIRouter(tags=["conversations"])

_AUTHENTICATED_ACTOR = "authenticated"


class EnsureSessionRequest(BaseModel):
    pipeline_id: str
    agent_id: str


class SubmitMessageRequest(BaseModel):
    client_request_id: str
    content: str
    source: str = "text"
    continuation_command_id: str = ""
    selected_candidate_id: str = ""
    selected_schedule_id: str = ""
    attachment_ids: list[str] = []
    base_version_id: str = ""
    background_element_id: str = ""
    element_ids: list[str] = []
    use_default_materials: bool = False


class ConfirmCommandRequest(BaseModel):
    preview_hash: str


def _actor_from_request(request: Request) -> str:
    """将会话归属绑定到真实登录用户，并兼容历史固定测试会话。"""
    token = request.cookies.get(COOKIE_NAME, "")
    user = user_from_session_token(token)
    if not user:
        raise HTTPException(status_code=401, detail={"code": "not_authenticated", "message": "未登录"})
    if token == LEGACY_TEST_COOKIE:
        return _AUTHENTICATED_ACTOR
    return user["id"]


def _actor_from_websocket(websocket: WebSocket) -> str:
    token = websocket.cookies.get(COOKIE_NAME, "")
    user = user_from_session_token(token)
    if not user:
        return ""
    if token != LEGACY_TEST_COOKIE:
        return user["id"]
    return _AUTHENTICATED_ACTOR


def _raise_http(error: ConversationError) -> None:
    status_code = 422
    if error.code.endswith("_not_found"):
        status_code = 404
    elif error.code.endswith("_forbidden"):
        status_code = 403
    elif error.code in {"preview_mismatch", "command_not_confirmable", "revision_conflict", "poster_job_active"}:
        status_code = 409
    detail = {"code": error.code, "message": str(error)}
    if error.job_id:
        detail["job_id"] = error.job_id
    raise HTTPException(status_code=status_code, detail=detail)


def _owned_command(command_id: str, actor_id: str) -> dict:
    command = conversation_store.get_command(command_id)
    if not command:
        raise ConversationError("command_not_found", "命令不存在")
    session = conversation_store.get_session(command["session_id"])
    if not session or session["actor_id"] != actor_id:
        raise ConversationError("command_forbidden", "无权访问该命令")
    return command


def _command_event(response: dict) -> dict:
    command = response["command"]
    latest_data = response.get("latest_data") or {}
    return {
        "type": "conversation_command_updated",
        "session_id": command["session_id"],
        "command_id": command["id"],
        "status": command["status"],
        "revision_map": latest_data.get("revision_map", {}),
    }


@router.post("/api/conversations/sessions/ensure")
def ensure_conversation_session(body: EnsureSessionRequest, request: Request):
    try:
        require_pipeline_access(request, body.pipeline_id)
        session = ensure_session(body.pipeline_id, body.agent_id, _actor_from_request(request))
        return {"session": session}
    except ConversationError as error:
        _raise_http(error)


@router.get("/api/conversations/sessions/{session_id}/messages")
def list_conversation_messages(session_id: str, request: Request, limit: int = 100):
    try:
        return {"messages": get_session_messages(session_id, _actor_from_request(request), limit)}
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/sessions/{session_id}/attachments")
async def upload_conversation_attachment(session_id: str, request: Request, file: UploadFile = File(...)):
    actor_id = _actor_from_request(request)
    session = conversation_store.get_session(session_id)
    if not session or session["actor_id"] != actor_id:
        raise HTTPException(404, detail={"code": "session_not_found", "message": "会话不存在"})
    if session["agent_id"] != "xiao_hai":
        raise HTTPException(422, detail={"code": "attachment_not_supported", "message": "当前 Agent 不支持图片附件"})
    try:
        asset = PosterService().create_image_asset(
            session["pipeline_id"],
            await file.read(),
            filename=file.filename or "reference.png",
            kind="conversation_reference",
        )
        return {"asset": asset}
    except PosterServiceError as error:
        raise HTTPException(400, detail={"code": "invalid_attachment", "message": str(error)}) from error


@router.get("/api/conversations/sessions/{session_id}/state")
def get_conversation_session_state(session_id: str, request: Request, limit: int = 100):
    try:
        return get_session_state(session_id, _actor_from_request(request), limit)
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/sessions/{session_id}/messages")
async def submit_conversation_message(
    session_id: str, body: SubmitMessageRequest, request: Request, background_tasks: BackgroundTasks
):
    try:
        response = await submit_session_message(
            session_id,
            _actor_from_request(request),
            body.client_request_id,
            body.content,
            body.source,
            body.continuation_command_id,
            body.selected_candidate_id,
            body.selected_schedule_id,
            body.attachment_ids,
            body.base_version_id,
            body.background_element_id,
            body.element_ids,
            body.use_default_materials,
        )
        job_id = (response["command"].get("result") or {}).get("job_id")
        if job_id:
            background_tasks.add_task(run_generation_job, job_id)
        await publish(session_id, _command_event(response))
        return response
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/commands/{command_id}/confirm")
async def confirm_conversation_command(
    command_id: str, body: ConfirmCommandRequest, request: Request, background_tasks: BackgroundTasks
):
    try:
        response = confirm_command(command_id, _actor_from_request(request), body.preview_hash)
        job_id = (response["command"].get("result") or {}).get("job_id")
        if job_id:
            background_tasks.add_task(run_generation_job, job_id)
        await publish(response["command"]["session_id"], _command_event(response))
        return response
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/commands/{command_id}/cancel")
async def cancel_conversation_command(command_id: str, request: Request):
    try:
        response = cancel_command(command_id, _actor_from_request(request))
        await publish(response["command"]["session_id"], _command_event(response))
        return response
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/commands/{command_id}/repreview")
async def repreview_conversation_command(command_id: str, request: Request):
    try:
        response = await repreview_command(command_id, _actor_from_request(request))
        await publish(response["command"]["session_id"], _command_event(response))
        return response
    except ConversationError as error:
        _raise_http(error)


@router.post("/api/conversations/commands/{command_id}/undo")
async def undo_conversation_command(command_id: str, request: Request):
    try:
        response = undo_command(command_id, _actor_from_request(request))
        await publish(response["command"]["session_id"], _command_event(response))
        return response
    except ConversationError as error:
        _raise_http(error)


@router.get("/api/conversations/commands/{command_id}")
def get_conversation_command(command_id: str, request: Request):
    try:
        return {"command": _owned_command(command_id, _actor_from_request(request))}
    except ConversationError as error:
        _raise_http(error)


@router.get("/api/conversations/sessions/{session_id}/snapshot")
def get_conversation_snapshot(session_id: str, request: Request):
    try:
        return get_snapshot(session_id, _actor_from_request(request))
    except ConversationError as error:
        _raise_http(error)


@router.websocket("/ws/conversations/{session_id}")
async def conversation_websocket(websocket: WebSocket, session_id: str):
    actor_id = _actor_from_websocket(websocket)
    if not actor_id:
        await websocket.close(code=4401)
        return
    session = conversation_store.get_session(session_id)
    if not session or session["actor_id"] != actor_id or session["status"] != "active":
        await websocket.close(code=4403)
        return

    await websocket.accept()
    subscribe(session_id, websocket)
    await websocket.send_json(
        {
            "type": "conversation_connected",
            "session_id": session_id,
            "agent_id": session["agent_id"],
        }
    )
    try:
        while True:
            message = await websocket.receive_text()
            if message == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        unsubscribe(session_id, websocket)
