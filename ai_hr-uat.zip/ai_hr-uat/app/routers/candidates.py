"""Candidate routes — update, action, score, and generic action handler."""

import json

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from app.access_control import require_candidate_access, require_pipeline_access, require_pipeline_path_access
from app.db import save_learning, update_candidate
from app.state import get_action_handler
from hr_harness.memory.core import MemorySystem

router = APIRouter(tags=["candidates"], dependencies=[Depends(require_pipeline_path_access)])


def _workflow_error(error: ValueError):
    raise HTTPException(400, str(error)) from error


class CandidateActionRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    action: str  # 操作：shortlist、reject、interview
    reason: str = ""


class ActionRequest(BaseModel):
    pipeline_id: str
    action: str
    data: dict = {}


_CANDIDATE_UPDATE_FIELDS = {
    "name",
    "source",
    "years_experience",
    "current_company",
    "current_salary",
    "skills",
    "resume_text",
    "tech_score",
    "experience_score",
    "education_score",
    "major_match_score",
    "culture_score",
    "salary_risk",
    "overall_score",
    "reason",
    "video_assessment",
    "resume_id",
    "status",
    "offered_at",
    "education",
    "major",
    "hr_note",
    "phone",
    "email",
    "contact_status",
    "ragflow_json",
    "match_batch",
    "shortlist_min",
}
_LEGACY_SCORE_FIELDS = {
    "tech_score",
    "experience_score",
    "education_score",
    "major_match_score",
    "culture_score",
    "salary_risk",
    "overall_score",
    "reason",
}


def _validated_candidate_updates(body: object, allowed_fields: set[str]) -> dict:
    if not isinstance(body, dict):
        raise HTTPException(400, "候选人更新内容必须是JSON对象")
    unknown = sorted(set(body) - allowed_fields)
    if unknown:
        raise HTTPException(400, f"不支持更新候选人字段：{', '.join(unknown)}")
    return body


def get_memory(pipeline_id: str = "") -> MemorySystem:
    """Get memory system scoped to a pipeline"""
    return MemorySystem(pipeline_id)


@router.put("/api/candidates/{candidate_id}")
async def api_update_candidate(candidate_id: str, req: Request):
    """Update candidate fields"""
    require_candidate_access(req, candidate_id)
    body = _validated_candidate_updates(
        await req.json(), _CANDIDATE_UPDATE_FIELDS - {"screening_decision", "screening_decision_at"}
    )
    update_candidate(candidate_id, body)
    return {"success": True, "candidate_id": candidate_id}


@router.post("/api/candidates/action")
async def api_candidate_action(req: CandidateActionRequest, request: Request):
    """HR takes action on a candidate (shortlist/reject/interview)"""
    require_pipeline_access(request, req.pipeline_id)
    require_candidate_access(request, req.candidate_id, expected_pipeline_id=req.pipeline_id)
    update_candidate(req.candidate_id, {"status": req.action})

    # 从决策中学习
    get_memory(req.pipeline_id).record_match_feedback(req.candidate_id, req.action, req.reason)

    from app.db import save_message

    save_message(
        req.pipeline_id,
        "system",
        f"候选人 {req.candidate_id} 被标记为: {req.action}" + (f" ({req.reason})" if req.reason else ""),
        card_type="candidate_action",
    )

    return {"status": "updated", "learned": True}


@router.post("/api/candidates/{candidate_id}/score")
async def api_override_score(candidate_id: str, scores: dict, request: Request):
    """HR overrides AI scores"""
    require_candidate_access(request, candidate_id)
    scores = _validated_candidate_updates(scores, _LEGACY_SCORE_FIELDS)
    update_candidate(candidate_id, scores)
    save_learning("feedback", f"score_override_{candidate_id}", json.dumps(scores, ensure_ascii=False))
    return {"status": "updated"}


@router.get("/api/pipelines/{pipeline_id}/screening-workflow")
async def api_screening_workflow(pipeline_id: str):
    """Return one canonical screening state using live candidate decisions."""
    from app.screening_workflow import canonical_screening_workflow

    return canonical_screening_workflow(pipeline_id)


@router.post("/api/pipelines/{pipeline_id}/screening-workflow/preview")
async def api_screening_preview(pipeline_id: str, request: Request):
    from app.screening_workflow import preview_model_screening

    config = await request.json()
    force = bool(config.pop("force", False)) if isinstance(config, dict) else False
    try:
        return await preview_model_screening(pipeline_id, config, force=force)
    except ValueError as error:
        _workflow_error(error)


@router.post("/api/pipelines/{pipeline_id}/screening-workflow/execute")
async def api_screening_execute(pipeline_id: str, request: Request):
    from app.screening_workflow import execute_model_screening

    config = await request.json()
    force = bool(config.pop("force", False)) if isinstance(config, dict) else False
    try:
        return await execute_model_screening(pipeline_id, config, force=force)
    except ValueError as error:
        _workflow_error(error)


@router.post("/api/pipelines/{pipeline_id}/screening-workflow/review/{candidate_id}")
async def api_screening_review(pipeline_id: str, candidate_id: str, request: Request):
    from app.screening_workflow import review_candidate

    body = await request.json()
    try:
        return review_candidate(
            pipeline_id,
            candidate_id,
            body.get("status", "passed"),
            body.get("reason", ""),
            body.get("override_score"),
        )
    except ValueError as error:
        _workflow_error(error)


@router.post("/api/pipelines/{pipeline_id}/screening-workflow/finalize")
async def api_screening_finalize(pipeline_id: str):
    from app.screening_workflow import finalize_screening

    try:
        return finalize_screening(pipeline_id)
    except ValueError as error:
        _workflow_error(error)


@router.post("/api/action")
async def api_action(req: ActionRequest, request: Request):
    """Universal action handler - LLM processes intent"""
    from app.db import save_message

    require_pipeline_access(request, req.pipeline_id)
    # 将用户消息保存到数据库，持久化对话操作
    if req.action == "chat" and req.data.get("message"):
        save_message(req.pipeline_id, "user", req.data["message"])
    result = await get_action_handler().handle_action(req.pipeline_id, req.action, req.data)
    return result
