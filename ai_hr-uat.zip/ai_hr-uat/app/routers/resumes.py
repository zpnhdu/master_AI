"""Resume routes — liepin plugin push/candidates, resume import/upload, pending resumes, process."""

import asyncio
import hashlib
import time
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel

from app import services, state
from app.access_control import require_pipeline_access, require_pipeline_path_access
from app.db import save_message
from app.state import chrome_sessions
from app.talent_pool import save_resume as save_resume_to_pool

router = APIRouter(tags=["resumes"], dependencies=[Depends(require_pipeline_path_access)])


class ResumeImportRequest(BaseModel):
    pipeline_id: str
    candidates: list  # Chrome 扩展传入的候选人字典列表
    source: str = "chrome_extension"


# ============ 猎聘插件 API ============


@router.post("/api/liepin/plugin/push")
async def api_liepin_plugin_push(request: Request):
    """Receive data from Chrome extension content script on liepin.com"""
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")

    session_id = body.get("sessionId", "unknown")
    push_type = body.get("type", "")
    data = body.get("data", {})

    # 跟踪会话
    if session_id not in chrome_sessions:
        chrome_sessions[session_id] = {"candidates": [], "last_seen": datetime.now()}

    chrome_sessions[session_id]["last_seen"] = datetime.now()

    if push_type == "register":
        return {"status": "ok", "message": "registered", "pendingTasks": []}

    elif push_type == "search":
        # 猎聘搜索结果
        candidates = data.get("candidates", [])
        if candidates:
            chrome_sessions[session_id]["candidates"].extend(candidates)
        return {"status": "ok", "count": len(candidates), "pendingTasks": []}

    elif push_type == "resume":
        # 单份简历详情
        candidate = data.get("candidate", data)
        if candidate:
            chrome_sessions[session_id]["candidates"].append(candidate)
        return {"status": "ok", "pendingTasks": []}

    elif push_type == "heartbeat":
        return {"status": "ok", "pendingTasks": []}

    return {"status": "ok", "pendingTasks": []}


@router.get("/api/liepin/plugin/candidates")
async def api_liepin_plugin_candidates(session_id: str = ""):
    """Get candidates collected from Chrome extension"""
    all_candidates = []
    for sid, session in chrome_sessions.items():
        if not session_id or sid == session_id:
            all_candidates.extend(session.get("candidates", []))
    return {"candidates": all_candidates, "count": len(all_candidates)}


# ============ 简历导入 API ============


@router.post("/api/resumes/import")
async def api_import_resumes(req: ResumeImportRequest, request: Request = None):
    """Import resumes from Chrome extension or external source"""
    # HTTP calls always receive Request from FastAPI. The optional value keeps
    # the existing internal/test function-call contract intact.
    if request is not None:
        require_pipeline_access(request, req.pipeline_id)

    # 存储待处理简历
    if req.pipeline_id not in state.pending_resumes:
        state.pending_resumes[req.pipeline_id] = []

    duplicates = 0
    imported = 0
    for c in req.candidates:
        # 规范化候选人数据
        import hashlib as _hash

        _c_name = c.get("name", "")
        _c_company = c.get("currentCompany", "")
        _fallback_id = f"ext_{_hash.md5(f'{_c_name}{_c_company}{time.time()}'.encode()).hexdigest()[:8]}"
        normalized = {
            "id": c.get("id") or c.get("uid") or _fallback_id,
            "name": c.get("name", "未知"),
            "source": req.source,
            "years_experience": services.parse_years(c.get("experience", c.get("years_experience", ""))),
            "current_company": c.get("currentCompany") or c.get("current_company", ""),
            "current_salary": c.get("salaryHint") or c.get("current_salary", ""),
            "skills": c.get("tags") or c.get("skills", []),
            "resume_text": c.get("resume_text") or c.get("resumeText") or c.get("summary", ""),
            "education": c.get("education", ""),
            "location": c.get("geo") or c.get("location", ""),
            "title": c.get("title", ""),
        }
        # Auto-save to global talent pool（重复检测在入库时自动完成）
        # 异常时降级为不判重，保证导入不因人才库抖动丢数据
        try:
            pool_result = save_resume_to_pool(normalized)
        except Exception as e:
            from app.audit.logger import get_logger

            logger = get_logger("resumes")
            logger.warning(f"save_resume_to_pool failed: {e}", extra={"source": "Import"})
            pool_result = {}
        if pool_result.get("duplicate"):
            duplicates += 1
            continue  # 与人才库重复 → 不入 pending，不参与匹配

        state.pending_resumes[req.pipeline_id].append(normalized)
        imported += 1
        # 持久化到数据库，保证重启安全
        from app.db import save_pending

        save_pending(req.pipeline_id, "resumes", normalized)

    count = len(state.pending_resumes[req.pipeline_id])

    msg = f"从{req.source}导入了{imported}份简历（累计{count}份）"
    if duplicates:
        msg += f"，跳过{duplicates}份重复"
    save_message(req.pipeline_id, "system", msg)

    # 不再自动触发匹配，由 HR 手动点击"开始匹配"按钮
    return {"status": "imported", "count": count, "new": imported, "duplicates": duplicates}


@router.post("/api/resumes/upload")
async def api_upload_resumes(
    request: Request,
    pipeline_id: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    text: str = Form(default=""),
):
    """Upload resume files (PDF/text) or paste text"""
    require_pipeline_access(request, pipeline_id)

    if pipeline_id not in state.pending_resumes:
        state.pending_resumes[pipeline_id] = []

    imported = []
    skipped = []
    duplicates = []

    # 处理上传文件
    for f in files:
        content = await f.read()
        filename = f.filename or "unknown"
        ext = filename.lower().split(".")[-1] if "." in filename else ""

        from app.infrastructure.config import settings
        from app.media_storage import get_media_storage, join_storage_key

        storage = get_media_storage()
        safe_filename = Path(filename.replace("\\", "/")).name or "resume"
        content_hash = hashlib.sha256(content).hexdigest()
        stored_filename = f"{content_hash}{Path(safe_filename).suffix.lower()}"
        storage_key = join_storage_key(settings.oss_resume_prefix, pipeline_id, stored_filename)
        try:
            await asyncio.to_thread(
                storage.write,
                storage_key,
                content,
                f.content_type or "application/octet-stream",
            )
        except Exception as exc:
            from app.audit.logger import get_logger

            get_logger("resumes").error(
                f"Resume storage failed for {safe_filename}: {exc}",
                extra={"source": "Upload"},
            )
            skipped.append({"filename": filename, "reason": "原始简历存储失败"})
            continue

        # Extract text via ragflow-style rich extractor (pdfplumber layout-aware)
        from app.utils import extract_text_from_bytes_rich

        text_content = extract_text_from_bytes_rich(content, filename)
        if len(text_content.strip()) < 20:
            from app.audit.logger import get_logger

            logger = get_logger("resumes")
            reason = "PDF无可提取文本（可能是扫描件）" if ext == "pdf" else "文本内容过短"
            logger.warning(f"Empty extraction for {filename}", extra={"source": "Upload"})
            skipped.append({"filename": filename, "reason": reason})
            continue

            # 使用 LLM 解析简历
        parsed = await services.parse_resume_with_llm(text_content, filename)
        if parsed:
            parsed["source"] = f"file:{filename}"
            parsed["storage_backend"] = storage.backend
            parsed["storage_key"] = storage_key
            parsed["original_filename"] = safe_filename
            # Auto-save to global talent pool（重复检测在入库时自动完成）
            # 异常时降级为不判重，保证导入不因人才库抖动丢数据
            try:
                pool_result = save_resume_to_pool(parsed)
            except Exception as e:
                from app.audit.logger import get_logger

                logger = get_logger("resumes")
                logger.warning(f"save_resume_to_pool failed: {e}", extra={"source": "Upload"})
                pool_result = {}
            if pool_result.get("duplicate"):
                duplicates.append(
                    {"source": f"file:{filename}", "filename": filename, "reason": "与人才库已有简历重复"}
                )
                continue
            state.pending_resumes[pipeline_id].append(parsed)
            from app.db import save_pending

            save_pending(pipeline_id, "resumes", parsed)
            imported.append(parsed)
        else:
            skipped.append({"filename": filename, "reason": "LLM未能解析出有效简历信息"})

    # 处理粘贴的文本
    if text.strip():
        # 按常见分隔符拆分
        chunks = services.split_resume_text(text)
        for chunk in chunks:
            parsed = await services.parse_resume_with_llm(chunk, "pasted")
            if parsed:
                parsed["source"] = "paste"
                # Auto-save to global talent pool（重复检测在入库时自动完成）
                # 异常时降级为不判重，保证导入不因人才库抖动丢数据
                try:
                    pool_result = save_resume_to_pool(parsed)
                except Exception as e:
                    from app.audit.logger import get_logger

                    logger = get_logger("resumes")
                    logger.warning(f"save_resume_to_pool failed: {e}", extra={"source": "Paste"})
                    pool_result = {}
                if pool_result.get("duplicate"):
                    duplicates.append({"source": "paste", "filename": "", "reason": "与人才库已有简历重复"})
                    continue
                state.pending_resumes[pipeline_id].append(parsed)
                from app.db import save_pending

                save_pending(pipeline_id, "resumes", parsed)
                imported.append(parsed)

    count = len(state.pending_resumes[pipeline_id])

    msg = f"导入了{len(imported)}份简历（累计{count}份）"
    if duplicates:
        msg += f"，跳过{len(duplicates)}份重复"
    save_message(pipeline_id, "system", msg)

    # 不再自动触发匹配，由 HR 手动点击"开始匹配"按钮
    return {
        "status": "imported",
        "count": count,
        "new": len(imported),
        "candidates": imported,
        "skipped": skipped,
        "duplicates": duplicates,
    }


# ============ 待处理简历 ============


@router.get("/api/resumes/{pipeline_id}")
async def api_get_pending_resumes(pipeline_id: str):
    """Get pending resumes for a pipeline"""
    return {"resumes": state.pending_resumes.get(pipeline_id, [])}


@router.post("/api/resumes/{pipeline_id}/process")
async def api_process_resumes(pipeline_id: str, force: bool = False):
    """Manually trigger resume processing (skip crawl, go to match)"""
    import asyncio

    from app.state import broadcast as _broadcast

    # 强制重置：清除卡住的处理锁和冷却状态
    if force:
        state.processing_locks.pop(pipeline_id, None)
        services._match_cooldowns.pop(pipeline_id, None)
        from app.audit.logger import get_logger

        logger = get_logger("resumes")
        logger.info(f"Force reset lock for {pipeline_id}", extra={"source": "Process"})

    # 先验证是否可以启动匹配
    check = await services.process_imported_resumes(pipeline_id)
    if check and check.get("status") == "skipped":
        return {"error": check.get("reason", "无法启动匹配")}

    # 验证通过，异步启动实际处理（锁在 finally 中释放）
    resumes = state.pending_resumes.get(pipeline_id, [])

    async def _process_with_lock():
        try:
            await services._do_process_imported_resumes(pipeline_id)
        except Exception as e:
            from app.audit.logger import get_logger

            logger = get_logger("resumes")
            logger.error(f"Process error for {pipeline_id}: {e}", exc_info=True)
            await _broadcast(
                {"type": "stage_error", "stage_id": "match", "error": f"匹配异常: {str(e)[:100]}"}, pipeline_id
            )
        finally:
            state.processing_locks.pop(pipeline_id, None)

    asyncio.create_task(_process_with_lock())
    return {"status": "processing", "count": len(resumes)}
