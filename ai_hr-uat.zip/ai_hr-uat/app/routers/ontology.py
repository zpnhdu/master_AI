"""Ontology routes — ontology tree, rules, weights, validation, scoring; memory rules, trace, growth, stats, preferences."""

import json

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from app import state
from app.access_control import require_pipeline_access, require_pipeline_query_access
from app.db import (
    get_learnings,
    get_ontology_rules,
)
from app.db import (
    get_memory_rules as db_get_memory_rules,
)
from app.db import (
    get_memory_stats as db_get_memory_stats,
)
from app.db import (
    reset_memory_rules as db_reset_memory_rules,
)
from app.db import (
    toggle_memory_rule as db_toggle_memory_rule,
)
from hr_harness.memory.core import MemorySystem
from hr_harness.memory.trace import Trace
from ontology.engine import OntologyEngine
from typing import Optional

router = APIRouter(tags=["ontology"], dependencies=[Depends(require_pipeline_query_access)])


def get_memory(pipeline_id: str = "") -> MemorySystem:
    """Get memory system scoped to a pipeline"""
    return MemorySystem(pipeline_id)


# ============ Ontology APIs (招聘本体引擎) ============


class OntologyRuleUpdate(BaseModel):
    pipeline_id: str = ""
    node_id: str
    rule_id: str
    updates: dict


class OntologyWeightsUpdate(BaseModel):
    pipeline_id: str = ""
    weights: dict


@router.get("/api/ontology")
async def api_get_ontology(pipeline_id: str = ""):
    """获取完整本体树"""
    engine = OntologyEngine(pipeline_id)
    return {
        "tree": engine.get_tree(),
        "tree_text": engine.get_tree_text(),
        "conflicts": engine.check_conflicts(),
    }


@router.get("/api/ontology/node/{node_id}")
async def api_get_ontology_node(node_id: str, pipeline_id: str = ""):
    """获取单个本体节点"""
    engine = OntologyEngine(pipeline_id)
    node = engine.get_node(node_id)
    if not node:
        raise HTTPException(404, f"Node {node_id} not found")
    return node


@router.get("/api/ontology/rules")
async def api_get_ontology_rules(pipeline_id: str = ""):
    """获取已配置的本体规则覆盖"""
    db_rules = get_ontology_rules(pipeline_id)
    configured = []
    for r in db_rules:
        rule_data = r.get("rule_data", {})
        if isinstance(rule_data, str):
            try:
                rule_data = json.loads(rule_data)
            except:
                rule_data = {}
        configured.append(
            {
                "id": r.get("id"),
                "node_id": r.get("node_id"),
                "rule_id": rule_data.get("id", ""),
                "field": rule_data.get("field", ""),
                "old_value": rule_data.get("old_value", ""),
                "new_value": rule_data.get("new_value", ""),
                "updated_at": str(r.get("updated_at", "")),
                "pipeline_id": r.get("pipeline_id", ""),
            }
        )
    return {"rules": configured, "count": len(configured)}


@router.put("/api/ontology/rules")
async def api_update_ontology_rule(req: OntologyRuleUpdate, request: Request):
    """HR修改本体规则"""
    if req.pipeline_id:
        require_pipeline_access(request, req.pipeline_id)
    engine = OntologyEngine(req.pipeline_id)
    result = engine.update_rule(req.node_id, req.rule_id, req.updates)
    if "error" in result:
        raise HTTPException(400, result["error"])

    # 失效缓存，下次读取会从 DB 重新加载
    from ontology import invalidate_ontology_cache

    invalidate_ontology_cache(req.pipeline_id)

    # 通知所有WS客户端
    for conn in state.connections:
        try:
            await conn.send_json(
                {"type": "ontology_updated", "rule": result.get("rule"), "conflicts": result.get("conflicts", [])}
            )
        except:
            pass

    return result


@router.put("/api/ontology/weights")
async def api_update_ontology_weights(req: OntologyWeightsUpdate, request: Request):
    """批量更新评分权重"""
    if req.pipeline_id:
        require_pipeline_access(request, req.pipeline_id)
    engine = OntologyEngine(req.pipeline_id)
    result = engine.update_weights(req.weights)
    if "error" in result:
        raise HTTPException(400, result["error"])

    from ontology import invalidate_ontology_cache

    invalidate_ontology_cache(req.pipeline_id)

    return result


@router.post("/api/ontology/validate")
async def api_validate_ontology(pipeline_id: str = ""):
    """检测规则冲突并自动修复"""
    engine = OntologyEngine(pipeline_id)
    result = engine.auto_resolve_conflicts()

    from ontology import invalidate_ontology_cache

    invalidate_ontology_cache(pipeline_id)

    return result


@router.get("/api/ontology/scoring")
async def api_get_scoring_config(pipeline_id: str = "", role: str = ""):
    """获取评分配置（权重+阈值）"""
    engine = OntologyEngine(pipeline_id)
    return {
        "weights": engine.get_scoring_weights(role),
        "thresholds": engine.get_screening_thresholds(),
        "prompt_context": engine.build_match_prompt_context(role),
    }


# ============ Memory APIs (ARON记忆学习库) ============


class MemoryToggleRequest(BaseModel):
    memory_id: str
    is_active: bool


class MemoryResetRequest(BaseModel):
    pipeline_id: str = ""
    scope: str = "pipeline"  # 范围：pipeline / all


class PreferenceRequest(BaseModel):
    key: str
    value: str


@router.get("/api/memory/rules")
async def api_get_memory_rules(pipeline_id: str = "", ontology_node_id: str = "", growth_stage: str = ""):
    """获取学习规则列表"""
    rules = db_get_memory_rules(
        pipeline_id=pipeline_id,
        ontology_node_id=ontology_node_id,
        growth_stage=growth_stage,
    )
    stats = db_get_memory_stats(pipeline_id)
    return {"rules": rules, "stats": stats}


@router.put("/api/memory/rules/toggle")
async def api_toggle_memory_rule(req: MemoryToggleRequest):
    """开关单条学习规则"""
    db_toggle_memory_rule(req.memory_id, req.is_active)
    return {"status": "toggled", "memory_id": req.memory_id, "is_active": req.is_active}


@router.post("/api/memory/reset")
async def api_reset_memory(req: MemoryResetRequest, request: Request):
    """重置学习数据"""
    if req.pipeline_id:
        require_pipeline_access(request, req.pipeline_id)
    count = db_reset_memory_rules(req.pipeline_id, req.scope)
    return {"status": "reset", "deleted_count": count, "scope": req.scope}


@router.get("/api/memory/trace/{memory_id}")
async def api_trace_memory(memory_id: str):
    """追溯单条规则来源"""
    trace = Trace.trace_rule(memory_id)
    if not trace:
        raise HTTPException(404, "Memory rule not found")
    return trace


@router.get("/api/memory/growth")
async def api_memory_growth(pipeline_id: str = ""):
    """获取成长阶段摘要"""
    memory = get_memory(pipeline_id)
    return memory.get_growth_summary()


@router.get("/api/memory/stats")
async def api_memory_stats(pipeline_id: str = ""):
    """获取记忆库统计"""
    return db_get_memory_stats(pipeline_id)


# ============ 记忆 API ============


@router.get("/api/memory")
async def api_get_memory(pipeline_id: Optional[str] = None):
    """Get AI HR's current memory/learnings, scoped to pipeline"""
    mem = get_memory(pipeline_id or "")
    return {
        "optimization_summary": mem.get_optimization_summary(),
        "preferences": mem.preferences,
        "learnings": get_learnings(pipeline_id=pipeline_id),
    }


@router.post("/api/memory/preference")
async def api_set_preference(req: PreferenceRequest):
    """HR teaches AI HR a preference"""
    get_memory().update_preference(req.key, req.value, "user_direct")
    return {"status": "saved"}
