"""Talent pool routes — search, stats, rediscover, resumes CRUD, upload, recommend, candidate assistant."""

import asyncio
import hashlib
import mimetypes
from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse, Response

from app import services, state
from app.access_control import (
    require_current_user,
    require_pipeline_access,
    require_pipeline_path_access,
    require_pipeline_query_access,
    tenant_id_for_user,
)
from app.db import get_pipeline, save_message
from app.upload_workers import get_upload_executor
from app.utils import extract_text_from_file

router = APIRouter(
    tags=["talent-pool"],
    dependencies=[Depends(require_pipeline_path_access), Depends(require_pipeline_query_access)],
)


# ============ 人才库 Search / Stats / Rediscover ============


@router.get("/api/talent-pool")
async def api_talent_pool(q: str = "", skills: str = "", min_score: int = 0, limit: int = 20):
    """搜索人才库"""
    from app.db import get_talent_pool_stats, search_talent_pool

    skill_list = [s.strip() for s in skills.split(",") if s.strip()] if skills else None
    results = search_talent_pool(query=q, skills=skill_list, min_score=min_score, limit=limit)
    stats = get_talent_pool_stats()
    return {"results": results, "total": len(results), "stats": stats}


@router.get("/api/talent-pool/stats")
async def api_talent_pool_stats():
    """人才库统计"""
    from app.db import get_talent_pool_stats

    return get_talent_pool_stats()


@router.post("/api/talent-pool/rediscover")
async def api_rediscover(data: dict):
    """为新岗位从人才库发现候选人"""
    from app.db import rediscover_talents

    role = data.get("role", "")
    skills = data.get("skills", [])
    min_score = data.get("min_score", 60)
    results = rediscover_talents(role=role, skills=skills, min_score=min_score)
    return {"results": results, "total": len(results), "role": role}


# ============ 人才库（简历库）API ============


@router.get("/api/talent-pool/resumes")
async def api_search_resumes(
    request: Request,
    q: str = "",
    skills: str = "",
    location: str = "",
    min_years: int = 0,
    limit: int = 20,
    page: int = 1,
    page_size: int = 0,
    sort_by: str = "",
    sort_order: str = "desc",
):
    """Search the signed-in user's tenant-scoped resume pool."""
    from app.talent_pool import search_resumes

    user = require_current_user(request)
    tenant_id = tenant_id_for_user(user)
    effective_page_size = min(max(page_size or limit, 1), 100)
    effective_page = max(page, 1)
    skill_list = [s.strip() for s in skills.split(",") if s.strip()] if skills else None
    results = search_resumes(
        query=q,
        skills=skill_list,
        location=location,
        min_years=min_years,
        limit=effective_page_size,
        tenant_id=tenant_id,
        offset=(effective_page - 1) * effective_page_size,
        sort_by=sort_by,
        sort_order=sort_order,
    )
    from app.db import get_resume_count

    total = get_resume_count(
        tenant_id=tenant_id,
        query=q,
        skills=skill_list,
        location=location,
        min_years=min_years,
    )
    return {
        "items": results,
        "results": results,
        "page": effective_page,
        "page_size": effective_page_size,
        "total": total,
        "returned": len(results),
    }


@router.get("/api/talent-pool/resumes/{resume_id}")
async def api_get_resume(resume_id: str, request: Request):
    """Return one tenant-scoped resume for candidate detail views."""
    from app.db import get_resume_by_id

    user = require_current_user(request)
    resume = get_resume_by_id(resume_id, tenant_id=tenant_id_for_user(user))
    if not resume:
        raise HTTPException(status_code=404, detail="简历不存在或无权访问")
    return resume


@router.get("/api/talent-pool/resumes/{resume_id}/original")
async def api_get_resume_original(
    resume_id: str,
    request: Request,
    proxy: bool = False,
    download: bool = False,
):
    """Return a tenant-authorized original resume from its configured storage backend."""
    from app.db import get_resume_by_id
    from app.media_storage import get_media_storage

    user = require_current_user(request)
    resume = get_resume_by_id(resume_id, tenant_id=tenant_id_for_user(user))
    if not resume:
        raise HTTPException(status_code=404, detail="简历不存在或无权访问")

    storage_backend = str(resume.get("storage_backend") or "").strip().lower()
    storage_key = str(resume.get("storage_key") or "").strip()
    if not storage_backend or not storage_key:
        raise HTTPException(status_code=404, detail="该简历没有可用的原件文件")

    filename = Path(str(resume.get("original_filename") or "resume").replace("\\", "/")).name or "resume"
    content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    try:
        storage = get_media_storage(storage_backend)
        exists = await asyncio.to_thread(storage.exists, storage_key)
        if not exists:
            raise HTTPException(status_code=404, detail="原件文件不存在或已被移除")
        if hasattr(storage, "sign_url") and not proxy:
            signed_url = storage.sign_url(storage_key, download_filename=filename if download else "")
            return RedirectResponse(signed_url, status_code=307)
        content = await asyncio.to_thread(storage.read, storage_key)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail="原件存储暂时无法访问") from exc

    disposition = "attachment" if download else "inline"
    return Response(
        content=content,
        media_type=content_type,
        headers={"Content-Disposition": f"{disposition}; filename*=UTF-8''{quote(filename)}"},
    )


@router.post("/api/talent-pool/resumes")
async def api_add_resume(data: dict, request: Request):
    """Manually add a resume to the talent pool"""
    from app.talent_pool import save_resume

    user = require_current_user(request)
    data.pop("tenant_id", None)
    tenant_id = tenant_id_for_user(user)
    data["owner_user_id"] = user["id"]
    data["source_type"] = data.get("source_type") or "manual"
    result = save_resume(data, tenant_id=tenant_id)
    if result.get("skipped"):
        raise HTTPException(400, f"Resume rejected: {result.get('reason', 'unknown')}")
    return result


@router.post("/api/talent-pool/upload")
async def api_talent_pool_upload(
    request: Request,
    files: list[UploadFile] = File(default=[]),
    text: str = Form(default=""),
):
    """Upload resume files (PDF/DOCX/MD) directly to the talent pool (no pipeline required)."""
    from app.talent_pool import save_resume

    user = require_current_user(request)
    tenant_id = tenant_id_for_user(user)
    if len(files) > 50:
        raise HTTPException(400, "最多上传50份简历")

    results: list[dict] = [{} for _ in files]
    from app.infrastructure.config import settings
    from app.media_storage import get_media_storage, join_storage_key

    storage = get_media_storage()
    loop = asyncio.get_running_loop()
    # Use the process-wide CPU-bounded executor. Files beyond the available
    # worker count are queued by ThreadPoolExecutor.
    executor = get_upload_executor()

    def read_and_extract(index: int, upload: UploadFile):
        filename = upload.filename or "unknown"
        ext = filename.lower().split(".")[-1] if "." in filename else ""
        safe_filename = Path(filename.replace("\\", "/")).name or "resume"
        try:
            file_obj = getattr(upload, "file", None)
            if file_obj is not None:
                content = file_obj.read()
            else:
                # Keep lightweight test doubles and custom UploadFile adapters
                # compatible while production requests use the sync file handle.
                content = asyncio.run(upload.read())
            text_content = extract_text_from_file(content, ext)
        except Exception:
            return index, None, {"filename": filename, "skipped": True, "reason": "extract_failed"}
        if not text_content.strip():
            return index, None, {"filename": filename, "skipped": True, "reason": "empty_content"}
        return index, (filename, safe_filename, ext, content, upload.content_type, text_content), None

    def persist_parsed(item, parsed):
        filename, safe_filename, _ext, content, content_type, _text_content = item
        parsed = dict(parsed)
        parsed["source"] = f"file:{filename}"
        parsed["source_type"] = "upload"
        parsed["owner_user_id"] = user["id"]
        content_sha256 = hashlib.sha256(content).hexdigest()
        stored_filename = f"{content_sha256}{Path(safe_filename).suffix.lower()}"
        storage_key = join_storage_key(settings.oss_resume_prefix, "talent-pool", tenant_id, stored_filename)
        try:
            storage.write(storage_key, content, content_type or "application/octet-stream")
        except Exception as exc:
            from app.audit.logger import get_logger

            get_logger("talent_pool").error(
                f"Resume storage failed for {safe_filename}: {exc}",
                extra={"source": "Upload"},
            )
            return {"filename": filename, "skipped": True, "reason": "storage_failed"}
        parsed["content_sha256"] = content_sha256
        parsed["storage_backend"] = storage.backend
        parsed["storage_key"] = storage_key
        parsed["original_filename"] = safe_filename
        save_result = save_resume(parsed, tenant_id=tenant_id)
        if save_result.get("duplicate"):
            storage.delete(storage_key)
        save_result["filename"] = filename
        return save_result

    prepared = await asyncio.gather(
        *(loop.run_in_executor(executor, read_and_extract, i, upload) for i, upload in enumerate(files))
    )

    # LLM parsing is network-bound and already async; run several files at
    # once while applying a small cap because each parse fans out internally.
    parse_limit = asyncio.Semaphore(4)

    async def parse_one(index: int, item, error):
        if error:
            results[index] = error
            return None
        async with parse_limit:
            try:
                parsed = await services.parse_resume_with_llm(item[-1], item[0])
            except Exception:
                parsed = None
        if not parsed:
            results[index] = {"filename": item[0], "skipped": True, "reason": "parse_failed"}
            return None
        return index, item, parsed

    parsed_items = await asyncio.gather(*(parse_one(index, item, error) for index, item, error in prepared))
    persist_jobs = [result for result in parsed_items if result is not None]
    stored = await asyncio.gather(
        *(loop.run_in_executor(executor, persist_parsed, item, parsed) for _index, item, parsed in persist_jobs)
    )
    for (index, _item, _parsed), result in zip(persist_jobs, stored):
        results[index] = result

        # 同时支持粘贴文本
    if text.strip():
        chunks = services.split_resume_text(text)
        for chunk in chunks:
            parsed = await services.parse_resume_with_llm(chunk, "pasted")
            if not parsed:
                continue
            parsed["source"] = "paste"
            parsed["source_type"] = "paste"
            parsed["owner_user_id"] = user["id"]
            save_result = save_resume(parsed, tenant_id=tenant_id)
            # 不再自动匹配，由 HR 手动触发
            results.append(save_result)

    return {"results": results, "count": len(results)}


# ============ 人才库推荐 ============


@router.get("/api/talent-pool/recommend/{pipeline_id}")
async def api_recommend(
    pipeline_id: str,
    limit: int = 20,
    scope: str = "balanced",
    keywords: str = "",
    required: str = "",
    excluded: str = "",
    hard_gates: str = "",
):
    """Get broad JD-based recommendations before strict downstream screening.

    hard_gates=1 applies the screening workbench's hard-gate filters up front:
    clearly unqualified resumes are dropped (hard_gate_filtered), while resumes
    missing required fields stay in results with missing_required markers.
    """
    from app.db import get_db
    from app.talent_pool import get_recommendation_context, recommend_for_pipeline, recommend_for_pipeline_gated

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    tenant_id = pipeline.get("tenant_id", "")
    keyword_list = [item.strip() for item in keywords.split(",") if item.strip()]
    required_list = [item.strip() for item in required.split(",") if item.strip()]
    excluded_list = [item.strip() for item in excluded.split(",") if item.strip()]
    apply_hard_gates = str(hard_gates).strip().lower() in {"1", "true", "yes"}
    if apply_hard_gates:
        gated = await recommend_for_pipeline_gated(
            pipeline_id,
            limit=min(max(limit, 1), 100),
            tenant_id=tenant_id,
            scope=scope,
            keywords=keyword_list,
            required_keywords=required_list,
            excluded_conditions=excluded_list,
        )
        results = gated["results"]
        reason = gated["reason"]
        hard_gate_filtered = gated["hard_gate_filtered"]
    else:
        results, reason = await recommend_for_pipeline(
            pipeline_id,
            limit=min(max(limit, 1), 100),
            tenant_id=tenant_id,
            scope=scope,
            keywords=keyword_list,
            required_keywords=required_list,
            excluded_conditions=excluded_list,
        )
        hard_gate_filtered = 0
    level_counts = {"high": 0, "possible": 0, "explore": 0}
    for result in results:
        level = result.get("relevance_level", "explore")
        level_counts[level] = level_counts.get(level, 0) + 1
    pool_total = (
        get_db().execute("SELECT COUNT(*) AS count FROM resumes WHERE tenant_id=%s", (tenant_id,)).fetchone()["count"]
    )
    return {
        "results": results,
        "total": len(results),
        "pool_total": pool_total,
        "pipeline_id": pipeline_id,
        "reason": reason,
        "scope": scope,
        "criteria": get_recommendation_context(pipeline_id, keyword_list, excluded_list),
        "level_counts": level_counts,
        "hard_gate_filtered": hard_gate_filtered,
    }


@router.post("/api/talent-pool/recommend/{pipeline_id}/accept")
async def api_accept_recommend(pipeline_id: str, data: dict):
    """Accept recommended candidates into a pipeline and populate pending_resumes for match"""
    from app.db import save_pending
    from app.talent_pool import link_resume_to_pipeline

    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    resume_ids = data.get("resume_ids", [])
    accepted = []
    for rid in resume_ids:
        candidate = link_resume_to_pipeline(rid, pipeline_id)
        if candidate:
            accepted.append(candidate)

    if accepted:
        # 填充 pending_resumes，供 process_imported_resumes 查找
        if pipeline_id not in state.pending_resumes:
            state.pending_resumes[pipeline_id] = []
        for c in accepted:
            state.pending_resumes[pipeline_id].append(c)
            save_pending(pipeline_id, "resumes", c)

        save_message(pipeline_id, "assistant", f"从人才库添加了{len(accepted)}位候选人到 pipeline")

        # === 同步 crawl 阶段 ===
        from app.db import create_stage, get_candidates, get_stages, update_stage
        from app.state import broadcast

        stages = get_stages(pipeline_id)
        existing_ids = {s["stage_id"] for s in stages}
        if "crawl" not in existing_ids:
            create_stage(pipeline_id, "crawl", "简历获取")

        all_candidates = get_candidates(pipeline_id)
        # 区分来源：文件上传 vs 人才库导入
        pool_count = sum(
            1 for c in all_candidates if c.get("source", "").startswith("talent_pool") or c.get("resume_id")
        )
        file_count = len(all_candidates) - pool_count
        sources = []
        if file_count > 0:
            sources.append("local_import")
        if pool_count > 0:
            sources.append("talent_pool")

        crawl_output = {
            "resume_count": len(all_candidates),
            "pool_import_count": pool_count,
            "file_upload_count": file_count,
            "sources": sources,
            "status": "completed",
            "summary": f"共 {len(all_candidates)} 份简历（文件上传 {file_count}，人才库导入 {pool_count}）",
        }
        update_stage(pipeline_id, "crawl", "done", crawl_output)

        await broadcast(
            {"type": "stage_done", "stage_id": "crawl"},
            pipeline_id,
        )

    return {"accepted": len(accepted), "candidates": accepted}


# ============ 删除 ============


@router.delete("/api/talent-pool/resumes/{resume_id}")
async def api_delete_resume(resume_id: str, request: Request):
    """Permanently delete a resume from the tenant talent pool."""
    from app.db import get_resume_by_id
    from app.talent_pool import delete_resume

    tenant_id = tenant_id_for_user(require_current_user(request))
    if not get_resume_by_id(resume_id, tenant_id=tenant_id):
        raise HTTPException(status_code=404, detail="简历不存在或无权访问")
    delete_resume(resume_id, tenant_id=tenant_id)
    return {"status": "deleted", "id": resume_id}


# ============ 应聘助手 API（参考北森 AI应聘助手）============


@router.post("/api/candidate-assistant/chat")
async def api_candidate_chat(data: dict, request: Request):
    """候选人智能问答（7x24答疑）"""
    from hr_harness.agents.candidate_assistant import CandidateAssistant

    pipeline_id = data.get("pipeline_id", "")
    if pipeline_id:
        require_pipeline_access(request, pipeline_id)
    assistant = CandidateAssistant()
    return await assistant.handle_query(
        query=data.get("query", ""),
        pipeline_id=pipeline_id,
        candidate_name=data.get("candidate_name", ""),
    )


@router.get("/api/candidate-assistant/status")
async def api_candidate_status(pipeline_id: str, candidate_name: str = ""):
    """候选人进度查询"""
    from hr_harness.agents.candidate_assistant import CandidateAssistant

    assistant = CandidateAssistant()
    return await assistant.get_status_update(pipeline_id, candidate_name)


@router.post("/api/candidate-assistant/reminder")
async def api_candidate_reminder(data: dict):
    """生成候选人面试提醒"""
    from hr_harness.agents.candidate_assistant import CandidateAssistant

    assistant = CandidateAssistant()
    return await assistant.generate_reminder(
        candidate_name=data.get("candidate_name", ""),
        role=data.get("role", ""),
        event_type=data.get("event_type", "interview"),
    )
