"""路由包：每个模块注册一组职责独立的 APIRouter。"""

from app.routers.admin import router as admin_router
from app.routers.agents import router as agents_router
from app.routers.analytics import router as analytics_router
from app.routers.assessment_flow import router as assessment_flow_router
from app.routers.auth import router as auth_router
from app.routers.candidates import router as candidates_router
from app.routers.canvas_library import router as canvas_library_router
from app.routers.company_config import router as company_config_router
from app.routers.conversations import router as conversations_router
from app.routers.element_library import router as element_library_router
from app.routers.email_sync import router as email_sync_router
from app.routers.feishu import router as feishu_router
from app.routers.interview import router as interview_router
from app.routers.knowledge import router as knowledge_router
from app.routers.mass_interview import router as mass_interview_router
from app.routers.mass_interview_streams import router as mass_interview_streams_router
from app.routers.ontology import router as ontology_router
from app.routers.pages import router as pages_router
from app.routers.pipelines import jd_router, studio_router
from app.routers.pipelines import router as pipelines_router
from app.routers.question_review import router as question_review_router
from app.routers.resumes import router as resumes_router
from app.routers.rpa import router as rpa_router
from app.routers.talent_pool import router as talent_pool_router
from app.routers.videos import router as videos_router
from app.routers.websocket import router as websocket_router
from app.routers.wiki import router as wiki_router
from app.routers.written_test import page_router as written_test_page_router
from app.routers.written_test import router as written_test_router
from app.routers.xiao_hai import router as xiao_hai_router

__all__ = [
    "pages_router",
    "pipelines_router",
    "studio_router",
    "jd_router",
    "interview_router",
    "company_config_router",
    "candidates_router",
    "conversations_router",
    "resumes_router",
    "videos_router",
    "ontology_router",
    "talent_pool_router",
    "agents_router",
    "admin_router",
    "analytics_router",
    "assessment_flow_router",
    "email_sync_router",
    "rpa_router",
    "feishu_router",
    "mass_interview_router",
    "mass_interview_streams_router",
    "websocket_router",
    "knowledge_router",
    "wiki_router",
    "auth_router",
    "written_test_router",
    "written_test_page_router",
    "xiao_hai_router",
    "canvas_library_router",
    "element_library_router",
    "question_review_router",
]
