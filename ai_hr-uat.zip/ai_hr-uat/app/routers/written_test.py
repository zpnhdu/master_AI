"""Written test routes — online exam mode for mid/senior positions."""

import asyncio
import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, Request, UploadFile
from pydantic import BaseModel

from app import analytics_time_helpers as _analytics_time_helpers
from app import assessment_flow, candidate_reports, state
from app import question_review as qr
from app import service_helpers as _service_helpers
from app.access_control import require_pipeline_access, require_pipeline_path_access
from app.db import (
    _effective_written_test_status,
    get_db,
    get_candidates,
    get_pipeline,
    get_stages,
    now_db_string,
    save_message,
    update_stage,
)
from app.written_scoring import (
    WRITTEN_DIMENSIONS,
    WRITTEN_SCORING_VERSION,
    aggregate_written_dimensions,
    build_written_rubric,
    score_written_model_result,
    technical_failure_written_answer,
    zero_written_answer,
)
from app.infrastructure.config import settings
from app.media_storage import get_media_storage, join_storage_key

router = APIRouter(
    prefix="/api/written-test",
    tags=["written-test"],
    dependencies=[Depends(require_pipeline_path_access)],
)

# 摄像头录像 OSS 直传：只做“浏览器直传 + 后端校验记录”，不参与评分，也暂不回放。
_WT_VIDEO_MIN_BYTES = 1024
_WT_VIDEO_MAX_BYTES = 512 * 1024 * 1024


def _positive_env_int(name: str, default: int, minimum: int) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


_parse_db_ts = _analytics_time_helpers.parse_db_ts

_WT_VIDEO_MAX_BYTES = _positive_env_int("WRITTEN_TEST_VIDEO_MAX_MB", 512, 1) * 1024 * 1024
_WT_DIRECT_UPLOAD_EXPIRES_SECONDS = _positive_env_int("WRITTEN_TEST_UPLOAD_EXPIRES_SECONDS", 1800, 300)
_WT_ALLOWED_VIDEO_CONTENT_TYPES = {"video/webm", "video/mp4", "video/ogg", "video/quicktime"}
# Candidate-facing exam duration remains the original 30 minutes.
WRITTEN_TEST_TIME_LIMIT_MINUTES = 30
# Separate grace threshold used only to classify abandoned in-progress sessions.
WRITTEN_TEST_SESSION_TIMEOUT_MINUTES = 35
SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
WRITTEN_TEST_LEASE_SECONDS = 30
_safe_oss_segment = _service_helpers.safe_oss_segment
_parse_json_list = _service_helpers.parse_json_list
_lease_client_id = _service_helpers.normalize_lease_client_id

# A process-local guard prevents the request task and deterministic worker entry
# from scoring the same submitted session concurrently.
_written_scoring_locks: dict[str, threading.Lock] = {}
_written_scoring_locks_guard = threading.Lock()
_WRITTEN_SCORING_TASKS: dict[str, asyncio.Task] = {}


def _written_scoring_lock(token: str) -> threading.Lock:
    with _written_scoring_locks_guard:
        return _written_scoring_locks.setdefault(token, threading.Lock())


class DirectUploadPrepareRequest(BaseModel):
    filename: str = ""
    content_type: str = "video/webm"
    size_bytes: int


class DirectUploadCompleteRequest(BaseModel):
    object_key: str
    upload_token: str


# 候选人答题页面：React 可用时返回 SPA shell，否则按开关回退旧版 HTML。
# 该路径免登录访问，token 由页面内 API 校验。
page_router = APIRouter(tags=["written-test-page"])


@page_router.get("/written-test/{token}")
async def written_test_page(token: str):
    from app.routers.pages import _serve_app_entry

    return _serve_app_entry("笔试页面不存在")


@page_router.get("/written-test")
async def written_test_page_index():
    from app.routers.pages import _serve_app_entry

    return _serve_app_entry("笔试页面不存在")


# ── 模型 ────────────────────────────────────────────────────


class LaunchRequest(BaseModel):
    pipeline_id: str
    candidate_ids: list[str]
    expires_hours: int = 48
    time_limit_minutes: int = WRITTEN_TEST_TIME_LIMIT_MINUTES
    camera_optional: bool = True


class SubmitRequest(BaseModel):
    answers: list  # [{问题序号: int, 回答文本: str, 作答秒数: int}]


def _lease_expiry() -> str:
    return (datetime.now() + timedelta(seconds=WRITTEN_TEST_LEASE_SECONDS)).strftime("%Y-%m-%d %H:%M:%S")


def _require_lease(session: dict, client_id: str | None) -> None:
    owner = str(session.get("active_client_id") or "")
    expires = _parse_db_ts(session.get("lease_expires_at"))
    if not owner:
        return
    if expires and expires < datetime.now():
        raise HTTPException(409, "考试会话已失去控制权，请重新打开考试链接")
    if _lease_client_id(client_id) != owner:
        raise HTTPException(409, "该考试已在其他设备或窗口答题")


def _claim_session_lease(token: str, client_id: str) -> dict:
    client_id = _lease_client_id(client_id)
    if not client_id:
        raise HTTPException(400, "缺少考试客户端标识")
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token=%s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "面试链接无效")
    session = dict(row)
    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    expiry = _lease_expiry()
    now = datetime.now(SHANGHAI_TZ).replace(tzinfo=None)
    result = conn.execute(
        "UPDATE written_test_sessions SET active_client_id=%s, lease_expires_at=%s, status=CASE WHEN status='pending' THEN 'in_progress' ELSE status END, started_at=CASE WHEN COALESCE(started_at,'')='' THEN %s ELSE started_at END WHERE token=%s AND (COALESCE(active_client_id,'')='' OR lease_expires_at < %s OR active_client_id=%s)",
        (client_id, expiry, now_db_string(), token, now.strftime("%Y-%m-%d %H:%M:%S"), client_id),
    )
    if getattr(result, "rowcount", 1) == 0:
        conn.rollback()
        raise HTTPException(409, "该考试已在其他设备或窗口答题")
    conn.commit()
    return {"status": "claimed", "client_id": client_id, "lease_expires_at": expiry}


# ── 数据库辅助函数 ──────────────────────────────────────────


def _ensure_table():
    conn = get_db()
    conn.execute(
        """CREATE TABLE IF NOT EXISTS written_test_sessions (
            token VARCHAR(191) PRIMARY KEY,
            pipeline_id VARCHAR(191) NOT NULL,
            candidate_id VARCHAR(191) NOT NULL,
            candidate_name VARCHAR(191) DEFAULT '',
            questions LONGTEXT,
            answers LONGTEXT,
            status VARCHAR(191) DEFAULT 'pending',
            camera_enabled INTEGER DEFAULT 0,
            video_filename VARCHAR(191) DEFAULT '',
            oss_object_key VARCHAR(191) DEFAULT '',
            video_storage_key VARCHAR(191) DEFAULT '',
            started_at VARCHAR(191) DEFAULT '',
            submitted_at VARCHAR(191) DEFAULT '',
            expires_at VARCHAR(191) DEFAULT '',
            invite_sent_at VARCHAR(191) DEFAULT '',
            score INTEGER DEFAULT 0,
            evaluation LONGTEXT,
            scoring_status VARCHAR(191) DEFAULT '',
            scoring_error VARCHAR(191) DEFAULT '',
            scoring_owner VARCHAR(191) DEFAULT '',
            scoring_started_at VARCHAR(191) DEFAULT '',
            scoring_completed_at VARCHAR(191) DEFAULT '',
            scoring_attempts INTEGER DEFAULT 0,
            voice_answers LONGTEXT,
            active_client_id VARCHAR(191) DEFAULT '',
            lease_expires_at VARCHAR(191) DEFAULT '',
            created_at VARCHAR(191) DEFAULT (NOW())
        )"""
    )
    for column, definition in (
        ("video_storage_key", "VARCHAR(191) DEFAULT ''"),
        ("invite_sent_at", "VARCHAR(191) DEFAULT ''"),
        ("scoring_status", "VARCHAR(191) DEFAULT ''"),
        ("scoring_error", "VARCHAR(191) DEFAULT ''"),
        ("scoring_owner", "VARCHAR(191) DEFAULT ''"),
        ("scoring_started_at", "VARCHAR(191) DEFAULT ''"),
        ("scoring_completed_at", "VARCHAR(191) DEFAULT ''"),
        ("scoring_attempts", "INTEGER DEFAULT 0"),
        ("active_client_id", "VARCHAR(191) DEFAULT ''"),
        ("lease_expires_at", "VARCHAR(191) DEFAULT ''"),
    ):
        try:
            conn.execute(f"ALTER TABLE written_test_sessions ADD COLUMN {column} {definition}")
        except Exception:
            pass
    # Legacy submitted rows need a durable state before a worker can resume them.
    conn.execute(
        """UPDATE written_test_sessions
           SET scoring_status = CASE
               WHEN COALESCE(evaluation, '') NOT IN ('', '{}', 'null') THEN 'succeeded'
               ELSE 'queued'
           END
           WHERE status = 'submitted' AND COALESCE(scoring_status, '') = ''"""
    )
    for statement in (
        "CREATE INDEX idx_written_sessions_pipeline_candidate_status ON written_test_sessions(pipeline_id, candidate_id, status)",
        "CREATE INDEX idx_written_sessions_invite_expiry ON written_test_sessions(pipeline_id, invite_sent_at, expires_at)",
    ):
        try:
            conn.execute(statement)
        except Exception:
            pass
    conn.commit()


def _ensure_oss_object_key_column(conn) -> None:
    """兼容旧库：补 oss_object_key 列。"""
    try:
        conn.execute("ALTER TABLE written_test_sessions ADD COLUMN oss_object_key VARCHAR(191) DEFAULT ''")
        conn.commit()
    except Exception:
        pass


def _build_invite_url(token: str) -> str:
    return f"/written-test/{token}"


def _clean_candidate_name(value: str) -> str:
    """Keep display names free of Markdown markers emitted by model output."""
    return re.sub(r"^[\s*_#·>`~\-]+|[\s*_#·>`~\-]+$", "", str(value or "")).strip()


def parse_stage_output(stage: dict) -> dict:
    """Parse stage output from JSON string to dict."""
    output = stage.get("output", "{}")
    if isinstance(output, str):
        try:
            return json.loads(output)
        except (json.JSONDecodeError, TypeError):
            return {}
    return output if isinstance(output, dict) else {}


def _public_questions(questions: list) -> list[dict]:
    """候选人只能看到作答字段，评分要点和锚点保留在服务端。"""
    allowed = {"id", "type", "question", "difficulty", "time_limit_seconds", "answer_mode"}
    return _service_helpers.public_question_payload(questions, allowed)


def _written_test_is_expired(session: dict, now: datetime | None = None) -> bool:
    """Return whether a link or an active attempt has passed its deadline."""
    current = now or datetime.now(SHANGHAI_TZ).replace(tzinfo=None)
    expires_at = _parse_db_ts(session.get("expires_at"))
    if expires_at and expires_at < current:
        return True
    if str(session.get("status") or "") == "in_progress":
        started_at = _parse_db_ts(session.get("started_at"))
        if started_at and started_at + timedelta(minutes=WRITTEN_TEST_SESSION_TIMEOUT_MINUTES) <= current:
            return True
    return False


async def _broadcast_written_event(session: dict, event_type: str, **payload) -> None:
    """Send written-test updates through the shared mass-interview monitor channel."""
    pipeline_id = str(session.get("pipeline_id") or "")
    if not pipeline_id:
        return
    try:
        from app.routers.websocket import broadcast_monitor_event

        await broadcast_monitor_event(pipeline_id, event_type, session, **payload)
    except Exception:
        # Monitoring must never make candidate submission or scoring fail.
        pass


# ── 路由 ────────────────────────────────────────────────────


@router.post("/launch")
async def api_launch_written_test(req: LaunchRequest, request: Request):
    """为入围候选人生成笔试链接"""
    _ensure_table()

    require_pipeline_access(request, req.pipeline_id)

    # 面试方式是流水线级别的选择：一旦该流水线生成过视频链接，后续批次不能切换为笔试。
    if (
        get_db()
        .execute(
            "SELECT 1 FROM interview_sessions WHERE pipeline_id=%s LIMIT 1",
            (req.pipeline_id,),
        )
        .fetchone()
    ):
        raise HTTPException(400, "该流水线已选择视频面试，后续批次只能继续生成视频面试链接")

    stages = get_stages(req.pipeline_id)
    from app.screening_workflow import confirmed_screening_candidates

    live_candidates = get_candidates(req.pipeline_id)
    confirmed_candidates, screening_context = confirmed_screening_candidates(req.pipeline_id, live_candidates)
    if screening_context["is_modern"] and screening_context["workflow_status"] != "confirmed":
        raise HTTPException(400, "小筛尚未确认，请先完成候选人复核和定版")
    interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
    if not interview_stage:
        raise HTTPException(400, "面试阶段不存在，请先在小面页面生成面试题")

    stage_output = parse_stage_output(interview_stage)
    interviews = stage_output.get("interviews", [])
    # Candidate IDs can come from JSON as either strings or numbers. Normalize
    # them so the saved 小面 question snapshot is always found.
    interview_map = {str(i["candidate_id"]): i for i in interviews if isinstance(i, dict) and i.get("candidate_id")}

    try:
        assessment_flow.ensure_single_step_plan(req.pipeline_id, "written_test", actor_id="written_test_launch")
    except ValueError as error:
        raise HTTPException(400, str(error)) from error

    # 去重：已有未过期笔试 session 的候选人不重复生成（对齐视频面试的 launch 逻辑）。
    conn = get_db()
    existing_rows = conn.execute(
        "SELECT candidate_id, expires_at FROM written_test_sessions WHERE pipeline_id=%s",
        (req.pipeline_id,),
    ).fetchall()
    existing_cids: set[str] = set()
    now = datetime.now(SHANGHAI_TZ).replace(tzinfo=None)
    for row in existing_rows:
        if not _written_test_is_expired(dict(row), now):
            existing_cids.add(row["candidate_id"])
    # A candidate has exactly one invitation path in a pipeline. Do not create
    # a written-test session when a video session already exists.
    video_rows = conn.execute(
        "SELECT candidate_id, status, expires_at FROM interview_sessions WHERE pipeline_id=%s",
        (req.pipeline_id,),
    ).fetchall()
    video_cids: set[str] = set()
    for row in video_rows:
        if not row["candidate_id"] or str(row["status"] or "").lower() == "expired":
            continue
        if row["expires_at"]:
            try:
                if now > datetime.fromisoformat(row["expires_at"]):
                    continue
            except (ValueError, TypeError):
                pass
        video_cids.add(str(row["candidate_id"]))
    if screening_context["is_modern"]:
        passed_ids = {str(candidate.get("id")) for candidate in (confirmed_candidates or [])}
        requested_ids = [str(cid) for cid in req.candidate_ids]
        ineligible_requested = [cid for cid in requested_ids if cid not in passed_ids]
        if ineligible_requested:
            raise HTTPException(400, "仅已确认通过筛选的候选人可以发起笔试")
        new_cids = [cid for cid in requested_ids if cid not in existing_cids and cid not in video_cids]
    else:
        new_cids = [cid for cid in req.candidate_ids if cid not in existing_cids and str(cid) not in video_cids]
    skipped = len(req.candidate_ids) - len(new_cids)
    if not new_cids:
        raise HTTPException(400, f"所有候选人已有笔试链接（{skipped}人已有），请勿重复发起")

    # 强制人工审核：候选人题目未审核（review_status=pending）禁止发起
    pending = await qr.check_reviewed_for(req.pipeline_id, new_cids)
    if pending:
        names = "、".join(n for _, n in pending)
        raise HTTPException(
            400,
            f"以下候选人题目未通过人工审核，请先到小面完成题目审核后再发起笔试：{names}",
        )
    expires_hours = max(1, min(int(req.expires_hours or 48), 168))
    expires_at = (datetime.now() + timedelta(hours=expires_hours)).strftime("%Y-%m-%d %H:%M:%S")
    sessions = []

    for cid in new_cids:
        interview = interview_map.get(str(cid))
        if not interview:
            continue

        candidate_name = _clean_candidate_name(interview.get("candidate_name", ""))

        token = secrets.token_urlsafe(24)
        questions = []
        for raw_question in interview.get("questions", []):
            if not isinstance(raw_question, dict):
                continue
            question = dict(raw_question)
            question["written_scoring_rubric"] = build_written_rubric(question)
            questions.append(question)

        conn.execute(
            """REPLACE INTO written_test_sessions
               (token, pipeline_id, candidate_id, candidate_name, questions, expires_at, invite_sent_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            (
                token,
                req.pipeline_id,
                cid,
                candidate_name,
                json.dumps(questions, ensure_ascii=False),
                expires_at,
                "",
            ),
        )

        sessions.append(
            {
                "token": token,
                "candidate_id": cid,
                "candidate_name": candidate_name,
                "invite_url": _build_invite_url(token),
                "expires_at": expires_at,
                "question_count": len(questions),
            }
        )

    conn.commit()

    save_message(
        req.pipeline_id,
        "assistant",
        f"已为 {len(sessions)} 位候选人生成笔试链接",
    )

    return {"sessions": sessions, "total": len(sessions)}


@router.post("/session/{token}/claim")
async def api_claim_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    _ensure_table()
    return _claim_session_lease(token, client_id)


@router.post("/session/{token}/heartbeat")
async def api_heartbeat_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token=%s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "面试链接无效")
    session = dict(row)
    _require_lease(session, client_id)
    if not session.get("active_client_id"):
        raise HTTPException(409, "请先获取考试会话控制权")
    expiry = _lease_expiry()
    conn.execute("UPDATE written_test_sessions SET lease_expires_at=%s WHERE token=%s", (expiry, token))
    conn.commit()
    return {"status": "ok", "lease_expires_at": expiry}


@router.post("/session/{token}/release")
async def api_release_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token=%s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "面试链接无效")
    session = dict(row)
    owner = str(session.get("active_client_id") or "")
    if owner and owner != _lease_client_id(client_id):
        raise HTTPException(409, "该考试已在其他设备或窗口答题")
    conn.execute("UPDATE written_test_sessions SET active_client_id='', lease_expires_at='' WHERE token=%s", (token,))
    conn.commit()
    return {"status": "released"}


@router.get("/session/{token}")
async def api_get_session(token: str, client_id: str = Header("", alias="X-Session-Client-Id")):
    """候选人打开笔试页面时获取题目"""
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()

    if not row:
        raise HTTPException(404, "面试链接无效")

    session = dict(row)

    # 复制链接发送时没有邮件回执；候选人首次打开链接即记为已邀请，
    # 让无邮箱候选人进入面试中心，同时纯生成但未打开的链接仍保持隐藏。
    if not str(session.get("invite_sent_at") or "").strip():
        invited_at = now_db_string()
        conn.execute("UPDATE written_test_sessions SET invite_sent_at=%s WHERE token=%s", (invited_at, token))
        conn.commit()
        session["invite_sent_at"] = invited_at

    if _lease_client_id(client_id) and session.get("status") != "submitted":
        _claim_session_lease(token, client_id)
        row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()
        session = dict(row)

    # 检查过期；读路径只返回有效状态，不回写数据库。
    if _written_test_is_expired(session):
        return {"error": "expired", "message": "面试链接已过期"}

    if session["status"] == "submitted":
        return {"error": "already_submitted", "message": "您已提交答案，无需重复作答"}

    if session["status"] == "pending":
        conn.execute(
            "UPDATE written_test_sessions SET status = 'in_progress', started_at = %s WHERE token = %s",
            (now_db_string(), token),
        )
        conn.commit()

    from app.db import get_company_config

    company = get_company_config()
    pipeline = get_pipeline(session["pipeline_id"])

    questions = json.loads(session["questions"]) if isinstance(session["questions"], str) else session["questions"]

    return {
        "candidate_name": session["candidate_name"],
        "role": pipeline.get("role", "") if pipeline else "",
        "company_name": company.get("company_name", ""),
        "company_logo": company.get("company_logo", ""),
        "questions": _public_questions(questions),
        "time_limit_minutes": WRITTEN_TEST_TIME_LIMIT_MINUTES,
        "camera_optional": True,
        "expires_at": session.get("expires_at", ""),
    }


@router.post("/session/{token}/submit")
async def api_submit_answers(token: str, req: SubmitRequest, client_id: str = Header("", alias="X-Session-Client-Id")):
    """候选人提交答案 → 保存 + AI 自动评分（文本提取 + 评分 + 评语）"""
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()

    if not row:
        raise HTTPException(404, "面试链接无效")

    session = dict(row)
    _require_lease(session, client_id)

    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    if session["status"] == "submitted":
        return {"status": "already_submitted", "message": "您已提交过答案"}

    answers_raw = [a.dict() if hasattr(a, "dict") else a for a in req.answers]
    answers_json = json.dumps(answers_raw, ensure_ascii=False)
    answered = sum(
        1
        for a in req.answers
        if (a.get("answer_text", "") if isinstance(a, dict) else getattr(a, "answer_text", "")).strip()
    )

    pipeline_id = session["pipeline_id"]
    candidate_id = session["candidate_id"]
    try:
        questions = (
            json.loads(session.get("questions", "[]"))
            if isinstance(session.get("questions"), str)
            else (session.get("questions") or [])
        )
    except (json.JSONDecodeError, TypeError):
        questions = []

    formatted_answers = []
    for a in req.answers:
        question_index = a.get("question_index", 0) if isinstance(a, dict) else getattr(a, "question_index", 0)
        question = questions[question_index] if question_index < len(questions) else {}
        formatted_answers.append(
            {
                "question_index": question_index,
                "question": question.get("question", "") if isinstance(question, dict) else "",
                "answer": a.get("answer_text", "") if isinstance(a, dict) else getattr(a, "answer_text", ""),
            }
        )

    # 先保存答案并登记处理中；评分在后台完成，面试中心在 succeeded 前不展示分数。
    submitted_at = now_db_string()
    processing_payload = {
        "scoring_status": "queued",
        "score_status": "unavailable",
        "scoring_started_at": "",
    }
    conn.execute(
        """UPDATE written_test_sessions
               SET answers = %s, status = 'submitted', submitted_at = %s,
                   active_client_id = '', lease_expires_at = '',
                   score = NULL, evaluation = %s, scoring_status = 'queued',
                   scoring_error = '', scoring_owner = '', scoring_started_at = '',
                   scoring_completed_at = '', scoring_attempts = 0
           WHERE token = %s""",
        (answers_json, submitted_at, json.dumps(processing_payload, ensure_ascii=False), token),
    )
    conn.commit()

    flow_result = assessment_flow.record_step_result(
        pipeline_id=pipeline_id,
        candidate_id=candidate_id,
        candidate_name=session["candidate_name"],
        modality="written_test",
        execution_status="submitted",
        scoring_status="processing",
        review_status="pending",
        result_status="pending",
        score=None,
        scoring_version=WRITTEN_SCORING_VERSION,
        evidence={
            "questions": questions,
            "answers": formatted_answers,
            "evaluation": processing_payload,
        },
        metadata={"submitted_at": submitted_at, "answered": answered},
    )
    await _broadcast_written_event(
        {**session, "status": "submitted", "submitted_at": submitted_at},
        "session_updated",
        status="completed",
        scoring_status="queued",
    )
    save_message(
        pipeline_id,
        "assistant",
        f"📝 {session['candidate_name']} 已完成在线笔试：{answered}/{len(req.answers)} 题，AI 正在评分中",
    )
    _schedule_written_test_scoring(token)

    return {
        "status": "submitted",
        "message": f"提交成功，共作答 {answered}/{len(req.answers)} 题",
        "score": None,
        "evaluation": processing_payload,
        "scoring_status": "queued",
        "assessment_flow": flow_result,
        "next_action_dispatch": None,
    }


def _written_answers_for_stage(questions: list, answers: list) -> list[dict]:
    formatted = []
    for answer in answers:
        if not isinstance(answer, dict):
            continue
        question_index = answer.get("question_index", 0)
        question = (
            questions[question_index]
            if isinstance(question_index, int) and 0 <= question_index < len(questions)
            else {}
        )
        formatted.append(
            {
                "question_index": question_index,
                "question": question.get("question", "") if isinstance(question, dict) else "",
                "answer": answer.get("answer_text", ""),
            }
        )
    return formatted


def _technical_failure_evaluation(session: dict, error: Exception) -> dict:
    """Return a reviewable zero-result if the scoring worker itself fails."""
    questions = _parse_json_list(session.get("questions", []))
    reason = f"笔试评分任务异常：{str(error)[:160] or type(error).__name__}"
    results = []
    for index, question in enumerate(questions):
        rubric = build_written_rubric(question if isinstance(question, dict) else {})
        results.append({"question_index": index, **technical_failure_written_answer(rubric, reason)})
    aggregated = aggregate_written_dimensions(results)
    detail_fields = (
        "question_index",
        "score",
        "comment",
        "candidate_feedback",
        "hit_points",
        "missed_points",
        "criteria",
        "scoring_confidence",
        "rubric_version",
        "technical_failure",
        "failure_reason",
    )
    return {
        **aggregated,
        "detail": [{key: result.get(key) for key in detail_fields} for result in results],
        "comment": reason,
        "scoring_version": WRITTEN_SCORING_VERSION,
    }


def _claim_written_scoring(token: str, owner: str) -> dict | None:
    conn = get_db()
    conn.execute(
        """UPDATE written_test_sessions
           SET scoring_status='processing', scoring_owner=%s, scoring_started_at=%s,
               scoring_error='', scoring_attempts=COALESCE(scoring_attempts, 0)+1
           WHERE token=%s AND status='submitted' AND scoring_status IN ('queued', '')""",
        (owner, now_db_string(), token),
    )
    conn.commit()
    row = conn.execute(
        "SELECT * FROM written_test_sessions WHERE token=%s AND scoring_status='processing' AND scoring_owner=%s",
        (token, owner),
    ).fetchone()
    return dict(row) if row else None


async def _complete_written_scoring(
    session: dict,
    answers: list,
    questions: list,
    formatted_answers: list,
    answered: int,
    owner: str,
) -> None:
    """Evaluate one claimed session and publish its durable result."""
    token = session["token"]
    pipeline_id = session["pipeline_id"]
    candidate_id = session["candidate_id"]
    try:
        try:
            evaluation = await _evaluate_written_answers(session, answers)
        except Exception as exc:
            evaluation = _technical_failure_evaluation(session, exc)
        score = evaluation.get("total_score")
        completed_at = now_db_string()
        evaluation_payload = {key: value for key, value in evaluation.items() if key != "total_score"}
        evaluation_payload.update(
            {"scoring_status": "succeeded", "score_status": "final", "scoring_completed_at": completed_at}
        )
        conn = get_db()
        conn.execute(
            "UPDATE written_test_sessions SET score = %s, evaluation = %s, scoring_status = 'scored' WHERE token = %s AND scoring_status = 'processing' AND scoring_owner = %s",
            (score, json.dumps(evaluation_payload, ensure_ascii=False), token, owner),
        )
        conn.commit()

        stages = get_stages(pipeline_id)
        interview_stage = next((s for s in stages if s["stage_id"] == "interview_gen"), None)
        if interview_stage:
            stage_output = parse_stage_output(interview_stage)
            records = stage_output.setdefault("interview_records", [])
            record = next((item for item in records if item.get("candidate_id") == candidate_id), None)
            if record is None:
                record = {"candidate_id": candidate_id, "candidate_name": session["candidate_name"]}
                records.append(record)
            record.update(
                {
                    "answers": formatted_answers,
                    "interviewer": "在线笔试",
                    "interview_date": datetime.now().strftime("%Y-%m-%d"),
                    "written_test_score": score,
                    "written_test_evaluation": evaluation_payload,
                }
            )
            update_stage(pipeline_id, "interview_gen", "done", stage_output)

        flow_result = assessment_flow.record_step_result(
            pipeline_id=pipeline_id,
            candidate_id=candidate_id,
            candidate_name=session["candidate_name"],
            modality="written_test",
            execution_status="submitted",
            scoring_status="succeeded",
            review_status="not_required",
            result_status="passed" if score is not None and score >= 60 else "not_passed",
            score=score,
            scoring_version=evaluation.get("scoring_version", WRITTEN_SCORING_VERSION),
            evidence={"questions": questions, "answers": formatted_answers, "evaluation": evaluation_payload},
            metadata={"submitted_at": session.get("submitted_at") or now_db_string(), "answered": answered},
        )
        from app.assessment_dispatch import dispatch_next_actions

        await dispatch_next_actions(pipeline_id, candidate_id, flow_result["package"])
        candidate_reports.schedule_report_generation(pipeline_id, candidate_id)
        await _broadcast_written_event(
            {**session, "status": "submitted", "score": score},
            "score_update",
            status="completed",
            score=score,
            scoring_status="succeeded",
        )
        save_message(pipeline_id, "assistant", f"📝 {session['candidate_name']} 笔试 AI 评分完成：{score} 分")
        conn.execute(
            """UPDATE written_test_sessions
               SET scoring_status='succeeded', scoring_owner='', scoring_error='', scoring_completed_at=%s
               WHERE token=%s AND scoring_status='scored' AND scoring_owner=%s""",
            (completed_at, token, owner),
        )
        conn.commit()
    except Exception as exc:
        failed_payload = {
            "scoring_status": "failed",
            "score_status": "unavailable",
            "scoring_error": str(exc)[:200],
            "scoring_failed_at": now_db_string(),
        }
        try:
            conn = get_db()
            conn.execute(
                """UPDATE written_test_sessions
                   SET score=NULL, evaluation=%s, scoring_status='failed', scoring_owner='', scoring_error=%s
                   WHERE token=%s AND scoring_owner=%s""",
                (json.dumps(failed_payload, ensure_ascii=False), str(exc)[:200], token, owner),
            )
            conn.commit()
            assessment_flow.record_step_result(
                pipeline_id=pipeline_id,
                candidate_id=candidate_id,
                candidate_name=session["candidate_name"],
                modality="written_test",
                execution_status="submitted",
                scoring_status="failed",
                review_status="pending",
                result_status="not_passed",
                score=None,
                scoring_version=WRITTEN_SCORING_VERSION,
                evidence={"questions": questions, "answers": formatted_answers, "evaluation": failed_payload},
                metadata={"answered": answered},
            )
            await _broadcast_written_event(
                {**session, "status": "submitted"},
                "score_update",
                status="completed",
                score=None,
                scoring_status="failed",
            )
        except Exception:
            pass


async def _run_written_test_scoring(token: str) -> None:
    """Run one queued written-test job; the DB claim makes retries idempotent."""
    lock = _written_scoring_lock(token)
    with lock:
        owner = secrets.token_urlsafe(12)
        session = _claim_written_scoring(token, owner)
    if not session:
        return
    questions = _parse_json_list(session.get("questions", []))
    answers = _parse_json_list(session.get("answers", []))
    formatted_answers = _written_answers_for_stage(questions, answers)
    answered = sum(1 for answer in answers if str(answer.get("answer_text", "") or "").strip())
    await _complete_written_scoring(session, answers, questions, formatted_answers, answered, owner)


def _schedule_written_test_scoring(token: str) -> bool:
    existing = _WRITTEN_SCORING_TASKS.get(token)
    if existing and not existing.done():
        return True
    try:
        task = asyncio.create_task(_run_written_test_scoring(token))
    except RuntimeError:
        return False
    _WRITTEN_SCORING_TASKS[token] = task

    def _discard(done: asyncio.Task) -> None:
        if _WRITTEN_SCORING_TASKS.get(token) is done:
            _WRITTEN_SCORING_TASKS.pop(token, None)

    task.add_done_callback(_discard)
    return True


def resume_pending_written_test_scoring() -> int:
    """Resume submitted jobs left queued or in-flight across a process restart."""
    _ensure_table()
    conn = get_db()
    conn.execute(
        """UPDATE written_test_sessions
           SET scoring_status='queued', scoring_owner='', scoring_error=''
           WHERE status='submitted' AND scoring_status IN ('processing', 'finalizing', 'scored')"""
    )
    conn.commit()
    rows = conn.execute(
        "SELECT token FROM written_test_sessions WHERE status='submitted' AND scoring_status='queued'"
    ).fetchall()
    return sum(1 for row in rows if _schedule_written_test_scoring(row["token"]))


async def _evaluate_written_answers(session: dict, answers: list) -> dict:
    """Score all written answers with deterministic 0-4 behavioral anchors."""
    try:
        questions_raw = session.get("questions", "[]")
        questions = json.loads(questions_raw) if isinstance(questions_raw, str) else (questions_raw or [])
    except Exception:
        questions = []

    if not questions:
        return {
            "total_score": 0,
            "detail": [],
            "comment": "未生成可评分题目，按 0 分处理。",
            "dimension_scores": {dimension: 0 for dimension in WRITTEN_DIMENSIONS},
            "dimension_coverage": {
                "covered": list(WRITTEN_DIMENSIONS),
                "uncovered": [],
                "ratio": 1.0,
                "status": "complete",
            },
            "dimension_detail": {dimension: [] for dimension in WRITTEN_DIMENSIONS},
            "scoring_version": WRITTEN_SCORING_VERSION,
        }

    handler = state.get_action_handler()
    pipeline_id = session.get("pipeline_id", "")

    # 从面试题拿岗位信息（若有）
    role = ""
    try:
        pipeline = get_pipeline(pipeline_id)
        if pipeline:
            role = pipeline.get("role", "")
    except Exception:
        pass

    answer_map = {}
    for answer in answers:
        question_index = (
            answer.get("question_index", 0) if isinstance(answer, dict) else getattr(answer, "question_index", 0)
        )
        answer_text = answer.get("answer_text", "") if isinstance(answer, dict) else getattr(answer, "answer_text", "")
        if isinstance(question_index, int) and 0 <= question_index < len(questions):
            answer_map[question_index] = str(answer_text or "").strip()

    sem = asyncio.Semaphore(3)

    async def _evaluate_one(question_index: int, question: dict) -> dict:
        """Score one answer and return a complete written_v2 detail item."""
        answer_text = answer_map.get(question_index, "")
        expected_points = question.get("expected_points", [])
        question_text = question.get("question", "")
        rubric = build_written_rubric(question)

        if not answer_text:
            return {"question_index": question_index, **zero_written_answer(rubric)}

        try:
            async with sem:
                result = await handler.quick_evaluate_written(
                    pipeline_id=pipeline_id,
                    candidate_id=session.get("candidate_id", ""),
                    question_index=question_index,
                    question=question_text or f"第{question_index + 1}题",
                    question_type=str(question.get("type") or "综合题"),
                    difficulty=str(question.get("difficulty") or "中等"),
                    expected_points=expected_points,
                    scoring_rubric=rubric,
                    answer=answer_text,
                    jd_role=role,
                )
            scored = score_written_model_result(rubric, result)
            return {"question_index": question_index, **scored}
        except Exception:
            return {
                "question_index": question_index,
                **technical_failure_written_answer(rubric, "AI 评分服务或结果校验异常"),
            }

    results = await asyncio.gather(
        *[
            _evaluate_one(index, question if isinstance(question, dict) else {})
            for index, question in enumerate(questions)
        ]
    )
    detail_fields = (
        "question_index",
        "score",
        "comment",
        "candidate_feedback",
        "hit_points",
        "missed_points",
        "criteria",
        "scoring_confidence",
        "rubric_version",
        "technical_failure",
        "failure_reason",
    )
    detail = [{key: result.get(key) for key in detail_fields} for result in results]

    aggregated = aggregate_written_dimensions(results)
    total = aggregated["total_score"]
    comment = f"共 {len(questions)} 题，五维综合 {total} 分"
    if total >= 80:
        comment += "，表现优秀，建议进入下一轮。"
    elif total >= 60:
        comment += "，基本达标，可进入下一轮评估。"
    else:
        comment += "，未达到岗位要求，建议不通过。"
    return {
        **aggregated,
        "detail": detail,
        "comment": comment,
        "scoring_version": WRITTEN_SCORING_VERSION,
    }


@router.post("/session/{token}/upload-video")
async def api_upload_video(
    token: str, file: UploadFile = File(...), client_id: str = Header("", alias="X-Session-Client-Id")
):
    """候选人上传摄像头录制视频（可选）"""
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()

    if not row:
        raise HTTPException(404, "面试链接无效")

    session = dict(row)
    _require_lease(session, client_id)
    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    if session.get("status") == "submitted":
        raise HTTPException(400, "笔试已提交，无法再上传录像")

    filename = f"wt_{session['candidate_id']}_{int(time.time())}.webm"
    content = await file.read()
    storage = get_media_storage()
    storage_key = join_storage_key(
        settings.oss_written_test_prefix, session["pipeline_id"], session["candidate_id"], filename
    )
    if storage.backend == "oss":
        await asyncio.to_thread(storage.write, storage_key, content, file.content_type or "video/webm")
    else:
        upload_dir = os.path.join("uploads", "written_test", session["pipeline_id"])
        os.makedirs(upload_dir, exist_ok=True)
        filepath = os.path.join(upload_dir, filename)
        with open(filepath, "wb") as f:
            f.write(content)

    conn.execute(
        "UPDATE written_test_sessions SET camera_enabled = 1, video_filename = %s, video_storage_key = %s WHERE token = %s",
        (filename, storage_key if storage.backend == "oss" else "", token),
    )
    conn.commit()
    await _broadcast_written_event(
        session,
        "session_updated",
        status="in_progress",
        camera_enabled=True,
    )

    return {"status": "uploaded", "filename": filename}


# ── 摄像头录像 OSS 直传（复用视频面试的策略签发思路，仅存档不评分）──────


def _direct_upload_secret() -> bytes:
    secret = os.getenv("SECRET_KEY", "").strip()
    if not secret:
        raise RuntimeError("SECRET_KEY 未配置")
    return secret.encode("utf-8")


def _encode_direct_upload_token(payload: dict) -> str:
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    encoded = base64.urlsafe_b64encode(raw).rstrip(b"=")
    signature = hmac.new(_direct_upload_secret(), encoded, hashlib.sha256).digest()
    signature_text = base64.urlsafe_b64encode(signature).rstrip(b"=").decode("ascii")
    return f"{encoded.decode('ascii')}.{signature_text}"


def _decode_direct_upload_token(value: str) -> dict:
    try:
        encoded_text, signature_text = value.split(".", 1)
        encoded = encoded_text.encode("ascii")
        expected = hmac.new(_direct_upload_secret(), encoded, hashlib.sha256).digest()
        signature = base64.urlsafe_b64decode(signature_text + "=" * (-len(signature_text) % 4))
        if not hmac.compare_digest(signature, expected):
            raise ValueError("signature mismatch")
        raw = base64.urlsafe_b64decode(encoded + b"=" * (-len(encoded) % 4))
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict) or int(payload.get("exp", 0)) < int(time.time()):
            raise ValueError("token expired")
        return payload
    except (
        ValueError,
        TypeError,
        KeyError,
        OverflowError,
        binascii.Error,
        json.JSONDecodeError,
        UnicodeDecodeError,
    ) as exc:
        raise HTTPException(400, "上传凭证无效或已过期，请重新上传") from exc


def _oss_region_from_endpoint(endpoint: str) -> str:
    hostname = urlsplit(endpoint if "://" in endpoint else f"https://{endpoint}").hostname or ""
    match = re.search(r"(?:^|\.)oss-([a-z0-9-]+?)(?:-internal)?\.", hostname.lower())
    if not match:
        raise RuntimeError("无法从 OSS endpoint 推导 region，请配置 ALICLOUD_OSS_REGION")
    return match.group(1)


def _direct_upload_config() -> tuple[str, str, str, str, str]:
    from app.config import (
        ALICLOUD_ACCESS_KEY,
        ALICLOUD_ACCESS_SECRET,
        ALICLOUD_OSS_BUCKET,
        ALICLOUD_OSS_ENDPOINT,
        ALICLOUD_OSS_PUBLIC_ENDPOINT,
        ALICLOUD_OSS_REGION,
    )

    if not all((ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT)):
        raise RuntimeError("OSS 直传未配置")

    endpoint = ALICLOUD_OSS_PUBLIC_ENDPOINT.strip().rstrip("/")
    if "://" not in endpoint:
        endpoint = f"https://{endpoint}"
    parsed = urlsplit(endpoint)
    if not parsed.netloc:
        raise RuntimeError("OSS 公网 endpoint 配置无效")
    bucket_prefix = f"{ALICLOUD_OSS_BUCKET}."
    hostname = parsed.netloc if parsed.netloc.startswith(bucket_prefix) else f"{bucket_prefix}{parsed.netloc}"
    upload_host = f"{parsed.scheme or 'https'}://{hostname}"

    region = ALICLOUD_OSS_REGION.strip() or _oss_region_from_endpoint(ALICLOUD_OSS_PUBLIC_ENDPOINT)
    return ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, upload_host, region


def _get_written_test_oss_bucket():
    import oss2

    from app.config import ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT

    if not all((ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET, ALICLOUD_OSS_BUCKET, ALICLOUD_OSS_ENDPOINT)):
        raise RuntimeError("OSS AccessKey 未配置")
    auth = oss2.Auth(ALICLOUD_ACCESS_KEY, ALICLOUD_ACCESS_SECRET)
    return oss2.Bucket(auth, ALICLOUD_OSS_ENDPOINT, ALICLOUD_OSS_BUCKET)


def _build_oss_post_policy(object_key: str, content_type: str) -> tuple[dict[str, str], int]:
    access_key, access_secret, bucket_name, _, region = _direct_upload_config()
    now = datetime.now(timezone.utc)
    date = now.strftime("%Y%m%d")
    request_time = now.strftime("%Y%m%dT%H%M%SZ")
    credential = f"{access_key}/{date}/{region}/oss/aliyun_v4_request"
    expires_at = int(time.time()) + _WT_DIRECT_UPLOAD_EXPIRES_SECONDS
    expiration = datetime.fromtimestamp(expires_at, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    policy_document = {
        "expiration": expiration,
        "conditions": [
            {"bucket": bucket_name},
            {"x-oss-signature-version": "OSS4-HMAC-SHA256"},
            {"x-oss-credential": credential},
            {"x-oss-date": request_time},
            ["eq", "$key", object_key],
            ["content-length-range", _WT_VIDEO_MIN_BYTES, _WT_VIDEO_MAX_BYTES],
            ["eq", "$Content-Type", content_type],
            ["eq", "$success_action_status", "200"],
        ],
    }
    policy_json = json.dumps(policy_document, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    policy = base64.b64encode(policy_json).decode("ascii")
    date_key = hmac.new(f"aliyun_v4{access_secret}".encode("utf-8"), date.encode("ascii"), hashlib.sha256).digest()
    region_key = hmac.new(date_key, region.encode("ascii"), hashlib.sha256).digest()
    service_key = hmac.new(region_key, b"oss", hashlib.sha256).digest()
    signing_key = hmac.new(service_key, b"aliyun_v4_request", hashlib.sha256).digest()
    signature = hmac.new(signing_key, policy.encode("ascii"), hashlib.sha256).hexdigest()
    fields = {
        "key": object_key,
        "policy": policy,
        "x-oss-signature-version": "OSS4-HMAC-SHA256",
        "x-oss-credential": credential,
        "x-oss-date": request_time,
        "x-oss-signature": signature,
        "success_action_status": "200",
        "Content-Type": content_type,
    }
    return fields, expires_at


def _direct_upload_token_payload(token: str, object_key: str, size_bytes: int, expires_at: int) -> dict:
    return {
        "session": hashlib.sha256(token.encode("utf-8")).hexdigest(),
        "object_key": object_key,
        "size_bytes": size_bytes,
        "exp": expires_at,
    }


@router.post("/session/{token}/video-upload/prepare")
async def api_prepare_written_video_upload(
    token: str, body: DirectUploadPrepareRequest, client_id: str = Header("", alias="X-Session-Client-Id")
):
    """为摄像头录像签发短时效、绑对象路径的 OSS POST 策略，浏览器直接上传。"""
    _ensure_table()
    _ensure_oss_object_key_column(get_db())
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "面试链接无效")
    session = dict(row)
    _require_lease(session, client_id)
    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    if session.get("status") == "submitted":
        raise HTTPException(400, "笔试已提交，无法再上传录像")

    content_type = (body.content_type or "video/webm").strip().lower().split(";", 1)[0]
    if content_type not in _WT_ALLOWED_VIDEO_CONTENT_TYPES:
        raise HTTPException(400, "仅支持 WebM、MP4、OGG 或 MOV 视频")
    if not (_WT_VIDEO_MIN_BYTES <= body.size_bytes <= _WT_VIDEO_MAX_BYTES):
        raise HTTPException(
            400, f"视频大小需在 {_WT_VIDEO_MIN_BYTES // 1024}KB 到 {_WT_VIDEO_MAX_BYTES // 1024 // 1024}MB 之间"
        )

    extension = (
        "webm"
        if content_type == "video/webm"
        else {"video/mp4": "mp4", "video/ogg": "ogv", "video/quicktime": "mov"}[content_type]
    )
    object_prefix = "/".join(
        (
            "written-test",
            _safe_oss_segment(session["pipeline_id"]),
            _safe_oss_segment(session["candidate_id"]),
        )
    )
    existing_object_key = str(session.get("oss_object_key", "") or "")
    object_key = (
        existing_object_key
        if existing_object_key.startswith(f"{object_prefix}/")
        else f"{object_prefix}/recording_{secrets.token_hex(12)}.{extension}"
    )
    try:
        fields, expires_at = _build_oss_post_policy(object_key, content_type)
        _, _, _, upload_url, _ = _direct_upload_config()
        upload_token = _encode_direct_upload_token(
            _direct_upload_token_payload(token, object_key, body.size_bytes, expires_at + 15 * 60)
        )
    except RuntimeError as exc:
        raise HTTPException(
            503,
            detail={"code": "oss_direct_upload_unavailable", "message": str(exc)},
        ) from exc
    except Exception as exc:
        raise HTTPException(500, "服务器创建上传任务失败，请重试") from exc

    return {
        "upload_url": upload_url,
        "method": "POST",
        "fields": fields,
        "object_key": object_key,
        "upload_token": upload_token,
        "expires_at": expires_at,
        "max_size_bytes": _WT_VIDEO_MAX_BYTES,
    }


@router.post("/session/{token}/video-upload/complete")
async def api_complete_written_video_upload(
    token: str, body: DirectUploadCompleteRequest, client_id: str = Header("", alias="X-Session-Client-Id")
):
    """校验 OSS 对象并记录 object_key（仅存档，不评分、不回放）。"""
    _ensure_table()
    _ensure_oss_object_key_column(get_db())
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()
    if not row:
        raise HTTPException(404, "面试链接无效")

    session = dict(row)
    _require_lease(session, client_id)
    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    if session.get("status") == "submitted":
        raise HTTPException(400, "笔试已提交，无法再上传录像")

    proof = _decode_direct_upload_token(body.upload_token)
    expected_session = hashlib.sha256(token.encode("utf-8")).hexdigest()
    if proof.get("session") != expected_session or proof.get("object_key") != body.object_key:
        raise HTTPException(400, "上传凭证与当前笔试不匹配")

    expected_size = int(proof.get("size_bytes", 0))
    bucket = _get_written_test_oss_bucket()
    try:
        header = bucket.head_object(body.object_key)
    except Exception as exc:
        raise HTTPException(409, "OSS 尚未收到完整视频，请确认上传完成后重试") from exc

    actual_size = int(getattr(header, "content_length", 0) or 0)
    if actual_size != expected_size or not (_WT_VIDEO_MIN_BYTES <= actual_size <= _WT_VIDEO_MAX_BYTES):
        try:
            bucket.delete_object(body.object_key)
        except Exception:
            pass
        raise HTTPException(400, "OSS 视频大小校验失败，请重新上传")

    conn.execute(
        "UPDATE written_test_sessions SET camera_enabled = 1, oss_object_key = %s WHERE token = %s",
        (body.object_key, token),
    )
    conn.commit()
    await _broadcast_written_event(
        session,
        "session_updated",
        status="in_progress",
        camera_enabled=True,
    )
    return {"status": "uploaded", "object_key": body.object_key}


@router.post("/session/{token}/transcribe")
async def api_transcribe_audio(
    token: str,
    file: UploadFile = File(...),
    question_index: int = Form(0),
    client_id: str = Header("", alias="X-Session-Client-Id"),
):
    """候选人上传某题的语音回答 → 保存录音 + 语音转文字（ASR）。

    每题独立：录音文件保留，转写文字返回给前端填入该题文字框（候选人可修改后提交）。
    """
    _ensure_table()
    conn = get_db()
    row = conn.execute("SELECT * FROM written_test_sessions WHERE token = %s", (token,)).fetchone()

    if not row:
        raise HTTPException(404, "面试链接无效")

    session = dict(row)
    _require_lease(session, client_id)
    if _written_test_is_expired(session):
        raise HTTPException(410, "笔试链接已过期")
    if session.get("status") == "submitted":
        raise HTTPException(400, "笔试已提交，无法再转写")

    filename = f"wt_{session['candidate_id']}_q{question_index}_{int(time.time())}.webm"
    content = await file.read()
    storage = get_media_storage()
    storage_key = join_storage_key(
        settings.oss_written_test_prefix, session["pipeline_id"], session["candidate_id"], filename
    )
    if storage.backend == "oss":
        await asyncio.to_thread(storage.write, storage_key, content, file.content_type or "audio/webm")
    else:
        upload_dir = os.path.join("uploads", "written_test", session["pipeline_id"])
        os.makedirs(upload_dir, exist_ok=True)
        filepath = os.path.join(upload_dir, filename)
        with open(filepath, "wb") as f:
            f.write(content)

    # 语音转文字（ASR）：百炼 paraformer / qwen3-asr，失败时返回可读错误
    # 注意：transcribe_audio 内部是同步 requests 调用（最长 180s），必须在线程池执行，
    # 避免阻塞 FastAPI 事件循环（否则其他请求会全部卡住）。
    transcript = ""
    try:
        from app.multimodal import transcribe_audio

        transcript = await asyncio.to_thread(transcribe_audio, filename, content)
    except Exception as e:
        transcript = f"[转写失败: {e}]"

    # 记录到 session（题目隔离：存每题语音文件名 + 转写文字）
    try:
        import json as _json

        from app.db import get_db as _get_db

        c2 = _get_db()
        row2 = c2.execute("SELECT voice_answers FROM written_test_sessions WHERE token = %s", (token,)).fetchone()
        voice = {}
        if row2 and row2[0]:
            try:
                voice = _json.loads(row2[0]) if isinstance(row2[0], str) else (row2[0] or {})
            except Exception:
                voice = {}
        voice[str(question_index)] = {
            "filename": filename,
            "transcript": transcript,
            "storage_backend": storage.backend,
            "storage_key": storage_key if storage.backend == "oss" else "",
        }
        c2.execute(
            "UPDATE written_test_sessions SET voice_answers = %s WHERE token = %s",
            (_json.dumps(voice, ensure_ascii=False), token),
        )
        c2.commit()
    except Exception:
        pass

    return {"status": "ok", "transcript": transcript, "filename": filename}


@router.get("/{pipeline_id}/status")
async def api_written_test_status(pipeline_id: str):
    """查看笔试进度"""
    _ensure_table()
    conn = get_db()
    # 兼容旧库：补 evaluation 列
    try:
        conn.execute("ALTER TABLE written_test_sessions ADD COLUMN evaluation VARCHAR(191) DEFAULT '{}'")
        conn.commit()
    except Exception:
        pass
    # 兼容旧库：补 voice_answers 列
    try:
        conn.execute("ALTER TABLE written_test_sessions ADD COLUMN voice_answers LONGTEXT")
        conn.commit()
    except Exception:
        pass
    _ensure_oss_object_key_column(conn)
    rows = conn.execute(
        "SELECT * FROM written_test_sessions WHERE pipeline_id = %s ORDER BY created_at DESC",
        (pipeline_id,),
    ).fetchall()

    sessions = []
    for r in rows:
        d = dict(r)
        eval_raw = d.get("evaluation", "{}")
        try:
            evaluation = json.loads(eval_raw) if isinstance(eval_raw, str) else (eval_raw or {})
        except Exception:
            evaluation = {}
        voice_raw = d.get("voice_answers", "{}")
        try:
            voice_answers = json.loads(voice_raw) if isinstance(voice_raw, str) else (voice_raw or {})
        except Exception:
            voice_answers = {}
        display_status = _effective_written_test_status(d)
        sessions.append(
            {
                "token": d.get("token", ""),
                "invite_url": _build_invite_url(d.get("token", "")),
                "candidate_id": d["candidate_id"],
                "candidate_name": d["candidate_name"],
                "status": display_status,
                "started_at": d["started_at"],
                "submitted_at": d["submitted_at"],
                "camera_enabled": bool(d["camera_enabled"]),
                "oss_object_key": d.get("oss_object_key", ""),
                "score": d.get("score", 0),
                "expires_at": d.get("expires_at", ""),
                "invite_sent_at": d.get("invite_sent_at", ""),
                "evaluation": evaluation,
                "voice_answers": voice_answers,
            }
        )

    return {
        "sessions": sessions,
        "total": len(sessions),
        "submitted": sum(1 for s in sessions if s["status"] == "completed"),
        "pending": sum(1 for s in sessions if s["status"] in ("invited", "in_progress")),
    }
