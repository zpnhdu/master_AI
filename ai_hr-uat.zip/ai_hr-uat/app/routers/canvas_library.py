"""Canvas library API — list canvases, browse library images, serve files."""

from __future__ import annotations

import copy
import json
import time
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, Response

from app.access_control import has_permission, require_current_user
from app.config import REACT_PUBLIC_DIR
from app.infrastructure.config import settings
from app.media_storage import MediaStorage, get_media_storage, join_storage_key, storage_cache_key

router = APIRouter(tags=["canvas-library"])

CANVAS_LIBRARY_DIR = Path(REACT_PUBLIC_DIR) / "xiao-hai" / "canvas-library"
OSS_CANVAS_PREFIX = join_storage_key(settings.oss_xiao_hai_prefix, "canvas")
_CANVAS_IMAGE_CACHE_TTL_SECONDS = 30.0
_CANVAS_IMAGE_CACHE: dict[tuple[str, str], tuple[float, list[dict[str, str]]]] = {}


def _require_canvas_access(request: Request) -> dict:
    user = require_current_user(request)
    if not has_permission(user, {"materials:read", "pipeline:read"}):
        raise HTTPException(status_code=403, detail="无权访问此功能")
    return user


def _validate_canvas_folder(canvas_folder: str) -> str:
    if (
        not canvas_folder
        or canvas_folder in {".", ".."}
        or "/" in canvas_folder
        or "\\" in canvas_folder
        or Path(canvas_folder).name != canvas_folder
    ):
        raise HTTPException(status_code=400, detail="Invalid canvas folder")
    return canvas_folder


def _canvas_key(canvas_folder: str, *parts: str) -> str:
    return join_storage_key(OSS_CANVAS_PREFIX, canvas_folder, *parts)


def _canvas_thumbnail_key(canvas_folder: str, filename: str) -> str:
    return _canvas_key(canvas_folder, "library", "thumbs", f"{Path(filename).stem}.webp")


def _is_oss(storage: MediaStorage) -> bool:
    return storage.backend == "oss"


def _load_canvas_manifest(canvas_folder: str, storage: MediaStorage | None = None) -> dict[str, Any] | None:
    """Load manifest.json for a canvas type."""
    storage = storage or get_media_storage()
    if _is_oss(storage):
        manifest_key = _canvas_key(canvas_folder, "manifest.json")
        if not storage.exists(manifest_key):
            return None
        try:
            data = json.loads(storage.read(manifest_key).decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            return None
        return data if isinstance(data, dict) else None

    manifest_path = CANVAS_LIBRARY_DIR / canvas_folder / "manifest.json"
    if not manifest_path.exists():
        return None
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _list_library_images(canvas_folder: str, storage: MediaStorage | None = None) -> list[dict[str, str]]:
    """List all images in the library folder."""
    storage = storage or get_media_storage()
    if _is_oss(storage):
        cache_key = (storage_cache_key(storage), canvas_folder)
        cached = _CANVAS_IMAGE_CACHE.get(cache_key)
        if cached and time.monotonic() - cached[0] < _CANVAS_IMAGE_CACHE_TTL_SECONDS:
            return copy.deepcopy(cached[1])
        prefix = _canvas_key(canvas_folder, "library") + "/"
        images = []
        keys = storage.list_keys(prefix)
        existing_keys = set(keys)
        for key in keys:
            filename = key.rsplit("/", 1)[-1]
            if "/thumbs/" in key:
                continue
            if Path(filename).suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp"):
                continue
            url = (
                storage.sign_url(key)
                if hasattr(storage, "sign_url")
                else f"/api/xiao-hai/canvases/{canvas_folder}/library/{filename}"
            )
            thumbnail_key = _canvas_thumbnail_key(canvas_folder, filename)
            thumbnail_url = (
                storage.sign_url(thumbnail_key)
                if thumbnail_key in existing_keys and hasattr(storage, "sign_url")
                else url
            )
            images.append({"filename": filename, "url": url, "thumb_url": thumbnail_url})
        _CANVAS_IMAGE_CACHE[cache_key] = (time.monotonic(), copy.deepcopy(images))
        return images

    library_dir = CANVAS_LIBRARY_DIR / canvas_folder / "library"
    if not library_dir.exists():
        return []

    images = []
    for filename in sorted(library_dir.iterdir()):
        if filename.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
            images.append(
                {
                    "filename": filename.name,
                    "url": f"/api/xiao-hai/canvases/{canvas_folder}/library/{filename.name}",
                    "thumb_url": f"/api/xiao-hai/canvases/{canvas_folder}/library/{filename.name}?thumb=1",
                }
            )
    return images


@router.get("/api/xiao-hai/canvases")
async def list_canvases(request: Request):
    """List all canvas types with their reference images."""
    _require_canvas_access(request)
    storage = get_media_storage()
    if not _is_oss(storage) and not CANVAS_LIBRARY_DIR.exists():
        raise HTTPException(404, "Canvas library not found")

    canvases = []
    if _is_oss(storage):
        prefix_parts = len(OSS_CANVAS_PREFIX.split("/"))
        canvas_folders = sorted(
            {
                key.split("/")[prefix_parts]
                for key in storage.list_keys(OSS_CANVAS_PREFIX + "/")
                if len(key.split("/")) > prefix_parts
            }
        )
    else:
        canvas_folders = [path.name for path in sorted(CANVAS_LIBRARY_DIR.iterdir()) if path.is_dir()]

    for canvas_folder in canvas_folders:
        manifest = _load_canvas_manifest(canvas_folder, storage)
        if not manifest:
            continue

        library_images = _list_library_images(canvas_folder, storage)

        canvases.append(
            {
                "id": manifest.get("id"),
                "name": manifest.get("name"),
                "folder": canvas_folder,
                "width": manifest.get("width"),
                "height": manifest.get("height"),
                "ratio": manifest.get("ratio"),
                "reference_image_url": f"/api/xiao-hai/canvases/{canvas_folder}/reference",
                "library_count": len(library_images),
                "library_images": library_images,
            }
        )

    return {"canvases": canvases}


@router.get("/api/xiao-hai/canvases/{canvas_folder}/reference")
async def get_reference_image(canvas_folder: str, request: Request):
    """Get the reference image for a canvas type.
    Uses the first image in the library as reference (reference.png removed).
    """
    _require_canvas_access(request)
    _validate_canvas_folder(canvas_folder)
    storage = get_media_storage()
    if _is_oss(storage):
        images = _list_library_images(canvas_folder, storage)
        if not images:
            raise HTTPException(404, "No library images available")
        filename = images[0]["filename"]
        return Response(storage.read(_canvas_key(canvas_folder, "library", filename)), media_type="image/png")

    library_dir = CANVAS_LIBRARY_DIR / canvas_folder / "library"
    if not library_dir.exists():
        raise HTTPException(404, "Library not found")

    images = [f for f in sorted(library_dir.iterdir()) if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")]
    if not images:
        raise HTTPException(404, "No library images available")

    # 使用第一张图片作为参考图
    ref_path = images[0]
    return FileResponse(ref_path, media_type="image/png")


@router.get("/api/xiao-hai/canvases/{canvas_folder}/library")
async def list_library_images(canvas_folder: str, request: Request):
    """List all images in a canvas type's library."""
    _require_canvas_access(request)
    _validate_canvas_folder(canvas_folder)
    storage = get_media_storage()
    if _is_oss(storage):
        manifest = _load_canvas_manifest(canvas_folder, storage)
        if not manifest:
            raise HTTPException(404, "Canvas type not found")
        images = _list_library_images(canvas_folder, storage)
        return {
            "canvas_id": manifest.get("id"),
            "canvas_name": manifest.get("name"),
            "images": images,
            "count": len(images),
        }

    canvas_dir = CANVAS_LIBRARY_DIR / canvas_folder
    if not canvas_dir.exists():
        raise HTTPException(404, "Canvas type not found")

    manifest = _load_canvas_manifest(canvas_folder)
    if not manifest:
        raise HTTPException(404, "Manifest not found")

    images = _list_library_images(canvas_folder)

    return {
        "canvas_id": manifest.get("id"),
        "canvas_name": manifest.get("name"),
        "images": images,
        "count": len(images),
    }


@router.get("/api/xiao-hai/canvases/{canvas_folder}/library/{filename}")
async def get_library_image(canvas_folder: str, filename: str, request: Request, thumb: int = 0):
    """Get a library image file, using a persisted thumbnail when requested."""
    _require_canvas_access(request)
    _validate_canvas_folder(canvas_folder)
    # 安全检查：防止路径遍历
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(400, "Invalid filename")

    storage = get_media_storage()
    if _is_oss(storage):
        key = (
            _canvas_thumbnail_key(canvas_folder, filename) if thumb else _canvas_key(canvas_folder, "library", filename)
        )
        if not storage.exists(key):
            if not thumb:
                raise HTTPException(404, "Image not found")
            key = _canvas_key(canvas_folder, "library", filename)
            if not storage.exists(key):
                raise HTTPException(404, "Image not found")
        suffix = Path(filename).suffix.lower()
        media_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
        }.get(suffix, "image/png")
        return Response(storage.read(key), media_type=media_type)

    image_path = CANVAS_LIBRARY_DIR / canvas_folder / "library" / filename
    if thumb:
        thumbnail_path = CANVAS_LIBRARY_DIR / canvas_folder / "library" / "thumbs" / f"{Path(filename).stem}.webp"
        if thumbnail_path.is_file():
            image_path = thumbnail_path
    if not image_path.exists():
        raise HTTPException(404, "Image not found")

    # 判断媒体类型
    suffix = image_path.suffix.lower()
    media_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
    }
    media_type = media_types.get(suffix, "image/png")

    return FileResponse(image_path, media_type=media_type)
