"""Administrative APIs for user accounts and product access roles."""

import asyncio
import os
import uuid
from datetime import datetime
from typing import Optional

import pymysql.err
from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field

from app.access_control import require_permission, strict_rbac_enabled
from app.db import (
    active_auth_user_count,
    auth_role_user_count,
    create_auth_user,
    delete_auth_sessions_for_user,
    delete_auth_user,
    get_auth_role,
    get_auth_user,
    get_auth_user_by_username,
    get_db,
    list_auth_roles,
    list_auth_users,
    update_auth_role,
    update_auth_user,
)
from app.email_providers import provider_presets
from app.security import hash_password
from app.user_validators import ensure_email_available, validate_email, validate_username
from app.user_mailbox import delete_oss_object, delete_user_mailbox, resolve_user_qr, sync_user_mailbox

router = APIRouter(prefix="/api/admin", tags=["admin"])

PERMISSIONS = [
    {"id": "pipeline:read", "label": "查看招聘流水线"},
    {"id": "talent:read", "label": "查看人才库"},
    {"id": "interview:read", "label": "查看面试"},
    {"id": "analytics:read", "label": "查看数据看板"},
    {"id": "knowledge:read", "label": "查看知识库"},
    {"id": "materials:read", "label": "查看素材库"},
    {"id": "system:manage", "label": "管理 Agent、公司和规则配置"},
    {"id": "user:manage", "label": "管理用户与权限"},
]
VALID_PERMISSION_IDS = {item["id"] for item in PERMISSIONS}


class UserCreateRequest(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    display_name: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=8, max_length=128)
    role_id: str
    is_active: bool = True
    hr_contact: str
    email_provider: str = "custom"
    credential: str = ""
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_security: Optional[str] = None
    imap_host: Optional[str] = None
    imap_port: Optional[int] = None
    imap_security: Optional[str] = None
    hr_qr_code_storage_key: str = ""


class UserUpdateRequest(BaseModel):
    display_name: Optional[str] = Field(default=None, min_length=1, max_length=50)
    password: Optional[str] = Field(default=None, min_length=8, max_length=128)
    role_id: Optional[str] = None
    is_active: Optional[bool] = None
    hr_contact: Optional[str] = None
    email_provider: Optional[str] = None
    credential: Optional[str] = None
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_security: Optional[str] = None
    imap_host: Optional[str] = None
    imap_port: Optional[int] = None
    imap_security: Optional[str] = None
    hr_qr_code_storage_key: Optional[str] = None


class RoleUpdateRequest(BaseModel):
    description: Optional[str] = Field(default=None, max_length=200)
    permissions: Optional[list[str]] = None


def _admin_user(request: Request) -> dict:
    return require_permission(request, "user:manage")


def _administrator(request: Request) -> dict:
    user = _admin_user(request)
    if strict_rbac_enabled() and user.get("role_id") != "admin":
        raise HTTPException(status_code=403, detail="仅管理员可以执行此操作")
    return user


def _integrity_conflict(exc: pymysql.err.IntegrityError) -> HTTPException:
    """唯一索引兜底拦截（1062 duplicate entry）翻译为业务冲突响应。

    预检 ensure_email_available 是 check-then-act，并发窗口下会漏判；
    捕获数据库层报错，转成与预检一致的 409 文案。
    """
    message = str(exc)
    if exc.args and exc.args[0] == 1062:
        if "username" in message:
            return HTTPException(status_code=409, detail="账号已存在")
        return HTTPException(status_code=409, detail="该 HR 联系邮箱已被其他用户使用")
    return HTTPException(status_code=409, detail="数据冲突，请稍后重试")


def _validate_permissions(permissions: list[str]) -> list[str]:
    normalized = list(dict.fromkeys(permission.strip() for permission in permissions if permission.strip()))
    invalid = [permission for permission in normalized if permission not in VALID_PERMISSION_IDS and permission != "*"]
    if invalid:
        raise HTTPException(status_code=422, detail=f"未知权限: {', '.join(invalid)}")
    return normalized


def _ensure_role_exists(role_id: str) -> dict:
    role = get_auth_role(role_id)
    if not role:
        raise HTTPException(status_code=422, detail="所选角色不存在")
    return role


def _ensure_admin_remains_active(target: dict, updates: dict) -> None:
    # 禁用或降级管理员前，必须保证仍至少有一个可登录的管理员账号。
    is_removing_admin = target["role_id"] == "admin" and updates.get("role_id", "admin") != "admin"
    is_disabling = target["role_id"] == "admin" and updates.get("is_active") is False
    if (is_removing_admin or is_disabling) and active_auth_user_count("admin") <= 1:
        raise HTTPException(status_code=409, detail="至少需要保留一个启用状态的管理员账号")


def _with_qr_url(user: dict) -> dict:
    user["hr_qr_code_url"] = resolve_user_qr(user)
    return user


@router.get("/permissions")
async def api_list_permissions(request: Request):
    _admin_user(request)
    return {"permissions": PERMISSIONS}


@router.get("/email-providers")
async def api_list_email_providers(request: Request):
    _admin_user(request)
    return {"providers": provider_presets()}


@router.post("/hr-qr")
async def api_upload_hr_qr(
    request: Request,
    file: UploadFile = File(...),
    old_storage_key: str = Form(""),
):
    _admin_user(request)
    from app.brand_assets import brand_asset_url, write_brand_asset

    ext = os.path.splitext(file.filename or "hr-qr.png")[1].lower() or ".png"
    if ext not in {".jpg", ".jpeg", ".png", ".svg", ".webp", ".gif"}:
        raise HTTPException(status_code=422, detail="仅支持 jpg/png/svg/webp/gif 格式的二维码图片")
    content = await file.read()
    if not content:
        raise HTTPException(status_code=422, detail="上传的二维码图片为空")
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(status_code=422, detail="二维码图片不能超过 5MB")

    # 每个 HR 一个独立对象，文件名用 uuid 保证互不覆盖（区别于公司级固定名 hr-qr）。
    safe_name = f"hr-qr-{uuid.uuid4().hex}{ext}"
    storage_key = write_brand_asset(safe_name, content, file.content_type or "application/octet-stream")
    url = brand_asset_url(safe_name, storage_key=storage_key)

    # 重传时清理旧对象，避免留下孤儿文件。
    if (old_storage_key or "").strip():
        delete_oss_object(old_storage_key.strip())

    return {"storage_key": storage_key, "url": url}


@router.get("/roles")
async def api_list_access_roles(request: Request):
    _admin_user(request)
    roles = list_auth_roles()
    for role in roles:
        role["permissions"] = _validate_permissions(role["permissions"])
        role["user_count"] = auth_role_user_count(role["id"])
    return {"roles": roles}


@router.put("/roles/{role_id}")
async def api_update_access_role(request: Request, role_id: str, body: RoleUpdateRequest):
    admin = _admin_user(request)
    role = get_auth_role(role_id)
    if not role:
        raise HTTPException(status_code=404, detail="角色不存在")

    updates = body.model_dump(exclude_none=True)
    if "permissions" in updates:
        updates["permissions"] = _validate_permissions(updates["permissions"])
    if role_id == "admin" and "permissions" in updates:
        updates["permissions"] = ["*"]
    if "description" in updates:
        updates["description"] = updates["description"].strip()
    try:
        updated = update_auth_role(role_id, updates)
    except Exception as exc:
        if "UNIQUE constraint failed" in str(exc):
            raise HTTPException(status_code=409, detail="角色名称已存在") from exc
        raise
    access_revoked = (
        admin.get("role_id") == role_id
        and "user:manage" not in set(updated.get("permissions") or [])
        and "*" not in set(updated.get("permissions") or [])
    )
    return {"role": updated, "current_user_access_revoked": access_revoked}


@router.delete("/roles/{role_id}")
async def api_delete_access_role(request: Request, role_id: str):
    _admin_user(request)
    role = get_auth_role(role_id)
    if not role:
        raise HTTPException(status_code=404, detail="角色不存在")
    # 产品角色固定为管理员和 HR 专员；角色定义只能调整权限，不能新增或删除。
    raise HTTPException(status_code=409, detail="当前仅保留管理员和 HR 专员，不支持删除角色")


@router.get("/users")
async def api_list_users(request: Request):
    _admin_user(request)
    return {"users": [_with_qr_url(user) for user in list_auth_users()]}


@router.post("/users", status_code=201)
async def api_create_user(request: Request, body: UserCreateRequest):
    _administrator(request)
    username = validate_username(body.username)
    _ensure_role_exists(body.role_id)
    if get_auth_user_by_username(username):
        raise HTTPException(status_code=409, detail="账号已存在")

    hr_contact = validate_email(body.hr_contact)
    ensure_email_available(hr_contact)

    try:
        user = create_auth_user(
            user_id=f"user_{uuid.uuid4().hex[:16]}",
            username=username,
            display_name=body.display_name.strip(),
            password_hash=hash_password(body.password),
            role_id=body.role_id,
            is_active=body.is_active,
            hr_contact=hr_contact,
            hr_qr_code_storage_key=(body.hr_qr_code_storage_key or "").strip(),
        )
        sync_user_mailbox(
            user["id"],
            email=hr_contact,
            provider=body.email_provider,
            credential=body.credential,
            smtp_host=body.smtp_host,
            smtp_port=body.smtp_port,
            smtp_security=body.smtp_security,
            imap_host=body.imap_host,
            imap_port=body.imap_port,
            imap_security=body.imap_security,
        )
    except pymysql.err.IntegrityError as exc:
        # 并发窗口下预检漏判（check-then-act 竞态），由唯一索引兜底拦截
        raise _integrity_conflict(exc) from exc
    return {"user": _with_qr_url(user)}


@router.put("/users/{user_id}")
async def api_update_user(request: Request, user_id: str, body: UserUpdateRequest):
    admin = _admin_user(request)
    target = get_auth_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="用户不存在")

    updates = body.model_dump(exclude_none=True)
    # 邮箱收发字段不在 auth_users 上，拆出交给 sync_user_mailbox 落进 email_accounts。
    mailbox_fields = {
        "email_provider",
        "credential",
        "smtp_host",
        "smtp_port",
        "smtp_security",
        "imap_host",
        "imap_port",
        "imap_security",
    }
    mailbox_updates = {key: value for key, value in updates.items() if key in mailbox_fields}
    updates = {key: value for key, value in updates.items() if key not in mailbox_fields}

    hr_contact_changed = "hr_contact" in updates
    if hr_contact_changed:
        hr_contact = validate_email(updates["hr_contact"])
        ensure_email_available(hr_contact, exclude_user_id=user_id)
        updates["hr_contact"] = hr_contact
    else:
        hr_contact = (target.get("hr_contact") or "").strip()

    # 换/清二维码时清理旧 OSS 对象。
    if "hr_qr_code_storage_key" in updates:
        new_key = (updates["hr_qr_code_storage_key"] or "").strip()
        old_key = (target.get("hr_qr_code_storage_key") or "").strip()
        if new_key != old_key:
            delete_oss_object(old_key)
        updates["hr_qr_code_storage_key"] = new_key

    if "password" in updates:
        if strict_rbac_enabled() and admin.get("role_id") != "admin":
            raise HTTPException(status_code=403, detail="仅管理员可以修改用户密码")
    if "role_id" in updates:
        _ensure_role_exists(updates["role_id"])
    _ensure_admin_remains_active(target, updates)
    if target["id"] == admin["id"] and (
        updates.get("is_active") is False or updates.get("role_id") not in (None, "admin")
    ):
        raise HTTPException(status_code=409, detail="不能禁用自己或移除自己的管理员权限")
    if "password" in updates:
        updates["password_hash"] = hash_password(updates.pop("password"))
    if "display_name" in updates:
        updates["display_name"] = updates["display_name"].strip()

    updated = update_auth_user(user_id, updates)

    # 联系人邮箱或收发参数变化时，同步 email_accounts；credential 为空=不改授权码。
    if hr_contact_changed or mailbox_updates:
        try:
            sync_user_mailbox(
                user_id,
                email=hr_contact,
                provider=mailbox_updates.get("email_provider") or target.get("email_provider") or "custom",
                credential=mailbox_updates.get("credential", ""),
                smtp_host=mailbox_updates.get("smtp_host") or "",
                smtp_port=mailbox_updates.get("smtp_port"),
                smtp_security=mailbox_updates.get("smtp_security") or "",
                imap_host=mailbox_updates.get("imap_host") or "",
                imap_port=mailbox_updates.get("imap_port"),
                imap_security=mailbox_updates.get("imap_security") or "",
            )
        except pymysql.err.IntegrityError as exc:
            # 并发窗口下预检漏判（check-then-act 竞态），由唯一索引兜底拦截
            raise _integrity_conflict(exc) from exc

    if any(key in updates for key in ("password_hash", "role_id", "is_active")):
        # 角色、状态或密码变化后立即失效旧 session，防止已登录设备继续保留旧权限。
        delete_auth_sessions_for_user(user_id)
    return {"user": _with_qr_url(updated)}


@router.delete("/users/{user_id}")
async def api_delete_user(request: Request, user_id: str):
    admin = _admin_user(request)
    target = get_auth_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="用户不存在")
    if target["id"] == admin["id"]:
        raise HTTPException(status_code=409, detail="不能删除当前登录账号")
    if target["role_id"] == "admin" and active_auth_user_count("admin") <= 1:
        raise HTTPException(status_code=409, detail="至少需要保留一个管理员账号")
    delete_oss_object((target.get("hr_qr_code_storage_key") or "").strip())
    delete_user_mailbox(user_id)
    delete_auth_user(user_id)
    return {"ok": True, "deleted_at": datetime.now().isoformat(timespec="seconds")}


@router.post("/wecom/sync-contacts")
async def api_wecom_sync_contacts(request: Request):
    """手动触发一次企微通讯录同步（定时循环之外的补充入口）。"""
    from fastapi.responses import JSONResponse

    from app.wecom.client import WeComError
    from app.wecom.contacts import sync_contacts

    _administrator(request)
    try:
        result = await asyncio.to_thread(sync_contacts)
    except WeComError as exc:
        raise HTTPException(status_code=502, detail=f"企业微信接口调用失败: {exc}") from exc
    if result.get("status") == "disabled":
        return JSONResponse(status_code=400, content={"detail": "通讯录同步未启用（缺少 WECOM_CONTACT_SECRET）"})
    return result
