"""Pipeline routes — CRUD, stages, screening, hiring, and batch operations."""

import asyncio
import hashlib
import json
import logging
import os
import re
import tempfile
import time
from datetime import datetime
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, Request, UploadFile
from pydantic import BaseModel

from app import assessment_flow, db, jd_workspace, resume_parser as _resume_parser, services, state
from app.access_control import (
    is_tenant_admin,
    require_current_user,
    require_pipeline_access,
    require_pipeline_path_access,
    tenant_id_for_user,
)
from app.db import (
    claim_pipeline_run,
    create_pipeline as db_create_pipeline,
    create_stage,
    delete_pipeline,
    get_candidates,
    get_db,
    get_elimination_records,
    get_interview_schedules,
    get_messages,
    get_pipeline,
    get_resume_by_id,
    get_stages,
    lock_pipeline_jd,
    list_pipelines_for_user,
    save_candidate,
    save_simple_candidate,
    save_interview_schedule,
    save_message,
    update_candidate,
    update_pipeline,
    update_pipeline_agents,
    update_stage,
    normalize_role_name,
)
from app.infrastructure.config import settings
from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline, get_agent_timeout
from app.job_types import normalize_job_type
from app.media_storage import get_media_storage, join_storage_key
from app.upload_workers import get_upload_executor
from app.poster_service import PosterService
from app.resume_contact import (
    classify_contact,
    extract_contact_with_llm,
)
from app.state import broadcast, connections
from app.utils import parse_stage_output
from app.xiao_wen_context import attach_agent_runtime_config, build_xiao_wen_context
from hr_harness.memory.core import MemorySystem

router = APIRouter(
    prefix="/api/pipelines",
    tags=["pipelines"],
    dependencies=[Depends(require_pipeline_path_access)],
)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

RESUME_UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "uploads", "resumes")


def get_memory(pipeline_id: str = "") -> MemorySystem:
    """Get memory system scoped to a pipeline"""
    return MemorySystem(pipeline_id)


# ============ Pydantic 模型 ============


class PipelineRequest(BaseModel):
    role: str
    hints: str = ""
    location: str = ""
    quiz_answers: list = []
    type: str = "tech"
    enabled_agents: list = []
    agents: list = []
    screen_template_id: str = ""


class JDEditRequest(BaseModel):
    pipeline_id: str
    jd: dict
    expected_revision: Optional[int] = None
    source: str = "manual"


class JDGenerateRequest(BaseModel):
    message: str = ""
    expected_revision: Optional[int] = None
    source: str = "generated"


class JDRevisionRequest(BaseModel):
    instruction: str
    expected_revision: Optional[int] = None


class JDApproveRequest(BaseModel):
    expected_revision: Optional[int] = None


class UpdateAgentsRequest(BaseModel):
    enabled_agents: list  # stage_id 字符串列表


class PassArtifactRequest(BaseModel):
    from_agent: str = ""
    to_agent: str = ""
    artifacts: dict = {}


class CompletePipelineRequest(BaseModel):
    actor_id: str = "hr"


class BatchResumeImportRequest(BaseModel):
    resumes: list[dict]  # 解析后的简历字典列表


class InterviewGenerateRequest(BaseModel):
    candidate_id: str = ""
    batch: bool = False


class InterviewScheduleRequest(BaseModel):
    candidate_id: str
    candidate_name: str = ""
    date: str
    time: str
    interviewer: str = ""
    method: str = "online"
    round: str = "一面"
    notes: str = ""


class BatchDeleteRequest(BaseModel):
    ids: list[str] = []


def _pipeline_completion_blockers(pipeline_id: str) -> tuple[list[str], dict, dict]:
    stages = {stage["stage_id"]: stage for stage in get_stages(pipeline_id)}
    report_stage = stages.get("report") or {}
    report_output = parse_stage_output(report_stage)
    report = report_output.get("report") if isinstance(report_output.get("report"), dict) else report_output
    blockers: list[str] = []

    if report_stage.get("status") != "done" or not report:
        blockers.append("评估报告尚未生成")

    queue = assessment_flow.list_decision_queue(pipeline_id)
    expired_candidate_ids = {
        str(item.get("candidate_id"))
        for item in db.get_session_ranking(pipeline_id)
        if item.get("candidate_id") and item.get("status") == "expired" and not item.get("assessment_completed")
    }
    if not queue.get("plan"):
        blockers.append("评估方案尚未启用")
    counts = queue.get("counts", {})
    incomplete = [
        item for item in queue.get("incomplete", []) if str(item.get("candidate_id") or "") not in expired_candidate_ids
    ]
    if not counts.get("ready_for_decision") and not expired_candidate_ids:
        blockers.append("没有可进入正式决策的候选人")
    if incomplete:
        blockers.append(f"仍有{len(incomplete)}位候选人评估未完成")

    match_output = parse_stage_output(stages.get("match"))
    shortlisted = {str(item) for item in match_output.get("shortlisted", [])}
    queued = {
        str(item.get("candidate_id"))
        for status in ("ready_for_decision", "incomplete")
        for item in queue.get(status, [])
        if item.get("candidate_id")
    }
    missing = shortlisted - queued - expired_candidate_ids
    if missing:
        blockers.append(f"仍有{len(missing)}位入围候选人尚未发起评估")

    return blockers, report_output, queue


# ============ 流水线增删改查 ============


@router.get("")
async def api_list_pipelines(
    request: Request,
    q: Optional[str] = Query(default=None),
    created_from: Optional[str] = Query(default=None),
    created_to: Optional[str] = Query(default=None),
    owner_user_id: Optional[str] = Query(default=None),
):
    """List all pipelines with stages for progress calculation"""
    user = require_current_user(request)

    def normalize_date_bound(value: Optional[str], end_of_day: bool = False) -> Optional[str]:
        if not value:
            return None
        value = value.strip()
        if len(value) == 10:
            return f"{value} {'23:59:59' if end_of_day else '00:00:00'}"
        return value

    # 按 HR 筛选只对租户管理员开放：管理员可以看到所有 HR 创建的流水线，
    # 普通 HR 传任何 owner_user_id 都会被忽略，始终只能看到自己的流水线。
    selected_owner_id = owner_user_id.strip() if is_tenant_admin(user) and owner_user_id else None
    pipelines = list_pipelines_for_user(
        str(user["id"]),
        tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
        q=q.strip() if q else None,
        created_from=normalize_date_bound(created_from),
        created_to=normalize_date_bound(created_to, end_of_day=True),
        owner_user_id=selected_owner_id,
    )
    for p in pipelines:
        p["context"] = json.loads(p["context"]) if p.get("context") else {}
        p["candidate_count"] = len(get_candidates(p["id"]))
        # 附加阶段数据，供前端计算 Agent 进度
        p["stages"] = get_stages(p["id"])
    return pipelines


@router.get("/hr-users")
async def api_list_hr_users(request: Request):
    """List HR accounts available for the job-management selector.

    Tenant administrators see every active HR specialist in their tenant and
    may filter the pipeline list by owner. Ordinary HR users only see
    themselves, mirroring their data scope.
    """
    conn = get_db()
    user = require_current_user(request)
    current_user_id = str(user["id"])
    if is_tenant_admin(user):
        rows = conn.execute(
            """SELECT id, username, display_name, role_id
               FROM auth_users
               WHERE is_active=1 AND role_id='hr_specialist' AND tenant_id=%s
               ORDER BY display_name , username """,
            (tenant_id_for_user(user),),
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT id, username, display_name, role_id
               FROM auth_users
               WHERE id=%s AND is_active=1""",
            (current_user_id,),
        ).fetchall()
    return {
        "users": [
            {
                "id": row["id"],
                "username": row["username"] or "",
                "display_name": row["display_name"] or row["username"] or row["id"],
                "role_id": row["role_id"] or "",
            }
            for row in rows
        ],
        "current_user_id": current_user_id,
        "can_select_all": is_tenant_admin(user),
    }


@router.get("/{pipeline_id}")
async def api_get_pipeline(pipeline_id: str):
    """Get pipeline detail with stages, candidates, messages"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    pipeline["context"] = json.loads(pipeline["context"]) if pipeline.get("context") else {}
    pipeline["stages"] = get_stages(pipeline_id)
    # get_stages 已解析输出 JSON，包括二次编码情况
    for s in pipeline["stages"]:
        if isinstance(s.get("output"), str):
            try:
                s["output"] = json.loads(s["output"])
            except (json.JSONDecodeError, TypeError):
                s["output"] = {}
        elif not s.get("output"):
            s["output"] = {}
    pipeline["candidates"] = get_candidates(pipeline_id)
    pipeline["messages"] = get_messages(pipeline_id)

    return pipeline


@router.post("")
async def api_create_pipeline(req: PipelineRequest, request: Request):
    """Create a pipeline record (no execution). User triggers auto-run separately."""
    import uuid

    from app.audit.audit_trail import audit
    from app.db import create_pipeline as db_create_pipeline
    from app.db import get_db

    try:
        job_type = normalize_job_type(req.type)
    except ValueError as error:
        raise HTTPException(422, str(error)) from error

    user = require_current_user(request)
    normalized_role = normalize_role_name(req.role)
    if not normalized_role:
        raise HTTPException(422, "岗位名称不能为空")
    conn = get_db()
    duplicate = conn.execute(
        "SELECT id FROM pipelines WHERE tenant_id=%s AND owner_user_id=%s AND role=%s AND status NOT IN ('completed') LIMIT 1",
        (tenant_id_for_user(user), str(user["id"]), normalized_role),
    ).fetchone()
    if duplicate:
        raise HTTPException(409, "同名岗位已有进行中的流水线")

    pipeline_id = f"p_{uuid.uuid4().hex[:8]}"
    audit(
        "pipeline.created",
        f"创建招聘流水线: {normalized_role}",
        entity_type="pipeline",
        entity_id=pipeline_id,
        details={"role": normalized_role, "job_type": job_type, "hints": req.hints, "location": req.location},
    )
    # 计算 enabled_agents
    enabled_agents = req.enabled_agents if req.enabled_agents else None
    # 仅创建数据库记录
    try:
        db_create_pipeline(
            pipeline_id,
            normalized_role,
            pipeline_type=job_type,
            enabled_agents=enabled_agents,
            owner_user_id=str(user["id"]),
            tenant_id=tenant_id_for_user(user),
        )
    except Exception as error:
        message = str(error).lower()
        if "duplicate" in message or "unique" in message or "uq_pipelines_active_role" in message:
            raise HTTPException(409, "同名岗位已有进行中的流水线") from error
        raise
    # 保存扩展字段（agents、screen_template_id 等）
    extra_fields = {}
    if req.agents:
        extra_fields["agents"] = req.agents
    if req.screen_template_id:
        extra_fields["screen_template_id"] = req.screen_template_id
    # 写入扩展字段
    if extra_fields:
        conn = get_db()
        for k, v in extra_fields.items():
            val = json.dumps(v) if isinstance(v, (list, dict)) else str(v)
            conn.execute(f"UPDATE pipelines SET {k}=%s WHERE id=%s", (val, pipeline_id))
        conn.commit()
    # 将提示信息存入上下文，供后续自动运行使用
    update_pipeline(
        pipeline_id,
        "pending",
        {"user_hints": req.hints, "location": req.location.strip(), "quiz_answers": req.quiz_answers},
    )
    return {
        "status": "created",
        "role": normalized_role,
        "type": job_type,
        "pipeline_id": pipeline_id,
    }


# ============ 更新流水线上下文 ============


@router.patch("/{pipeline_id}/context")
async def api_update_pipeline_context(pipeline_id: str, req: Request):
    """更新 pipeline 的 context（hints、quiz_answers 等）"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    # 只允许 pending 或 waiting_for_resumes 状态修改
    if pipeline.get("status") not in ("pending", "waiting_for_resumes"):
        raise HTTPException(400, "流水线已开始运行，无法修改配置")

    data = await req.json()

    # 获取现有 context
    context = pipeline.get("context")
    if isinstance(context, str):
        try:
            context = json.loads(context)
        except (json.JSONDecodeError, TypeError):
            context = {}
    elif not context:
        context = {}

    # 合并更新（只允许白名单字段）
    allowed_keys = {"user_hints", "quiz_answers"}
    for key in allowed_keys:
        if key in data:
            context[key] = data[key]

    # 写回 DB
    update_pipeline(pipeline_id, pipeline.get("status", "pending"), context)

    return {"status": "updated", "context": context}


# ============ 自动运行流水线 ============


@router.post("/{pipeline_id}/auto-run")
async def api_auto_run_pipeline(pipeline_id: str, background_tasks: BackgroundTasks):
    """Trigger pipeline execution (JD generation etc.) for a previously created pipeline."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    if pipeline.get("status") in {"starting", "running", "running_auto"}:
        raise HTTPException(400, "流水线已在运行中")
    if not claim_pipeline_run(pipeline_id):
        raise HTTPException(400, "流水线已在运行中")
    # 从上下文提取 hints 和 quiz_answers
    context = pipeline.get("context")
    if isinstance(context, str):
        try:
            context = json.loads(context)
        except (json.JSONDecodeError, TypeError):
            context = {}
    elif not context:
        context = {}
    user_hints = context.get("user_hints", "")
    quiz_answers = context.get("quiz_answers", [])
    # 解析 enabled_agents
    enabled_agents = pipeline.get("enabled_agents")
    if isinstance(enabled_agents, str):
        try:
            enabled_agents = json.loads(enabled_agents)
        except (json.JSONDecodeError, TypeError):
            enabled_agents = None
    # 解析扩展字段
    extra_fields = {}
    agents_raw = pipeline.get("agents")
    if agents_raw:
        if isinstance(agents_raw, str):
            try:
                extra_fields["agents"] = json.loads(agents_raw)
            except (json.JSONDecodeError, TypeError):
                pass
        else:
            extra_fields["agents"] = agents_raw
    screen_tpl = pipeline.get("screen_template_id")
    if screen_tpl:
        extra_fields["screen_template_id"] = screen_tpl
    try:
        engine_version = int(pipeline.get("engine_version") or 2)
    except (TypeError, ValueError):
        engine_version = 2
    base_exclude_stages = {"profile_build", "match", "interview_gen", "video_assess", "report"}
    exclude_stages = base_exclude_stages | ({"jd_write"} if pipeline.get("jd_locked_at") else set())
    # 响应发送后再执行，避免同步 Agent 调用阻塞创建流水线请求。
    # JD 确认前不得自动生成候选人画像或进入任何人工复核阶段。
    background_tasks.add_task(
        services.run_pipeline_bg,
        pipeline["role"],
        user_hints,
        quiz_answers,
        pipeline_type=pipeline.get("type", "tech"),
        enabled_agents=enabled_agents if enabled_agents else None,
        extra_fields=extra_fields if extra_fields else None,
        pipeline_id=pipeline_id,
        exclude_stages=exclude_stages,
        engine_version=engine_version,
        skip_planning=True,
    )
    return {"status": "started", "pipeline_id": pipeline_id}


# ============ 更新 Agent ============


@router.put("/{pipeline_id}/agents")
async def api_update_agents(pipeline_id: str, req: UpdateAgentsRequest):
    """更新流水线启用的Agent列表"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    update_pipeline_agents(pipeline_id, req.enabled_agents)
    return {"status": "updated", "enabled_agents": req.enabled_agents}


# ============ 通过阶段产物 ============


def _screening_handoff_ids(value, field_name: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise HTTPException(400, f"小筛下游传递缺少{field_name}")
    ids = []
    for item in value:
        raw_id = item.get("id") if isinstance(item, dict) else item
        candidate_id = str(raw_id or "").strip()
        if not candidate_id:
            raise HTTPException(400, f"小筛下游传递包含无效候选人ID")
        if isinstance(item, dict):
            supplied_status = str(item.get("screening_decision") or item.get("status") or "").strip().lower()
            if supplied_status and supplied_status != "passed":
                raise HTTPException(400, "只能传递已确认通过筛选的候选人")
        ids.append(candidate_id)
    if len(ids) != len(set(ids)):
        raise HTTPException(400, f"小筛下游传递的{field_name}存在重复候选人")
    return ids


def _validate_xiao_shai_handoff(pipeline_id: str, artifact_payload: dict) -> dict:
    from app.screening_workflow import confirmed_screening_candidates, get_screening_context

    context = get_screening_context(pipeline_id)
    if (
        not context["is_modern"]
        or context["workflow_status"] != "confirmed"
        or context["stage"].get("status") != "done"
    ):
        raise HTTPException(400, "小筛尚未定版，请先完成候选人复核和定版")

    eligible_candidates, _ = confirmed_screening_candidates(pipeline_id)
    eligible_by_id = {
        str(candidate.get("id")): candidate for candidate in (eligible_candidates or []) if candidate.get("id")
    }
    if not eligible_by_id:
        raise HTTPException(400, "没有已确认通过筛选的候选人，不能进入下游")

    requested_candidates = _screening_handoff_ids(artifact_payload.get("candidates"), "候选人")
    invalid_candidates = sorted(set(requested_candidates) - set(eligible_by_id))
    if invalid_candidates:
        raise HTTPException(400, "只能传递已确认通过筛选的候选人")

    match = artifact_payload.get("match")
    if not isinstance(match, dict):
        raise HTTPException(400, "小筛下游传递缺少筛选结果")
    handoff_lists = []
    for field_name in ("shortlisted", "passed_ids"):
        if field_name in match:
            ids = _screening_handoff_ids(match[field_name], field_name)
            invalid_ids = sorted(set(ids) - set(eligible_by_id))
            if invalid_ids:
                raise HTTPException(400, "筛选通过名单包含未通过小筛的候选人")
            handoff_lists.append((field_name, ids))
    if not handoff_lists:
        raise HTTPException(400, "小筛下游传递缺少通过名单")
    if any(set(ids) != set(requested_candidates) for _, ids in handoff_lists):
        raise HTTPException(400, "候选人清单与筛选通过名单不一致")

    return artifact_payload


@router.post("/{pipeline_id}/pass-artifact")
async def api_pass_artifact(pipeline_id: str, req: PassArtifactRequest):
    """Pass a stage artifact downstream and lock JD after XiaoWen handoff."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    downstream = jd_workspace.next_downstream(pipeline, req.from_agent)
    to_agent = downstream["agent_id"] if req.to_agent == "next" and downstream else req.to_agent
    if not to_agent or to_agent not in jd_workspace.AGENT_DETAILS:
        raise HTTPException(400, "没有可传递的下游Agent")

    jd_revision = 0
    artifact_payload = req.artifacts or {}
    if req.from_agent == "xiao_shai":
        artifact_payload = _validate_xiao_shai_handoff(pipeline_id, artifact_payload)
    if req.from_agent == "xiao_wen":
        workspace = jd_workspace.workspace(pipeline_id)
        if workspace["approval_status"] != "approved":
            raise HTTPException(400, "请先确认当前JD")
        if not workspace["profile_is_current"]:
            raise HTTPException(400, "请先生成候选人画像")
        if downstream and to_agent != downstream["agent_id"]:
            raise HTTPException(400, "只能传递给当前流水线的下一位Agent")
        # 以服务端当前版本为准，避免前端缓存把旧 JD/画像传给下游。
        jd_revision = workspace["revision"]
        artifact_payload = {
            "jd_write": {
                "jd": workspace["jd"],
                "revision": workspace["revision"],
                "approved_revision": workspace["approved_revision"],
            },
            "profile_build": {
                "profile": workspace["profile"],
                "jd_revision": workspace["profile_revision"],
            },
        }
        lock = lock_pipeline_jd(pipeline_id, req.from_agent, expected_revision=workspace["revision"])
        if not lock:
            current = jd_workspace.workspace(pipeline_id)
            raise HTTPException(
                409,
                {
                    "message": "JD已被更新，请刷新后重试",
                    "current_revision": current["revision"],
                },
            )

    if req.from_agent == "xiao_hai":
        selected = next(
            (version for version in PosterService().list_versions(pipeline_id) if version["status"] == "selected"),
            None,
        )
        if not selected or not selected.get("approved_at"):
            raise HTTPException(400, "请先确认当前海报版本")
        if downstream and to_agent != downstream["agent_id"]:
            raise HTTPException(400, "只能传递给当前流水线的下一位Agent")

    from_name = jd_workspace.AGENT_DETAILS.get(req.from_agent, {}).get("name", req.from_agent)
    to_name = jd_workspace.AGENT_DETAILS[to_agent]["name"]

    save_message(
        pipeline_id,
        "system",
        f"产物已从{from_name}传递给{to_name}",
        card_type="artifact_pass",
        card_data={
            "from_agent": req.from_agent,
            "to_agent": to_agent,
            "jd_revision": jd_revision,
            "artifact_keys": list(artifact_payload),
            "artifacts": artifact_payload,
            "timestamp": datetime.now().isoformat(),
        },
        stage_id="jd_write" if req.from_agent == "xiao_wen" else "",
    )

    # 通过 WebSocket 广播
    await broadcast(
        {
            "type": "artifact_passed",
            "pipeline_id": pipeline_id,
            "from_agent": req.from_agent,
            "to_agent": to_agent,
        },
        pipeline_id,
    )

    return {
        "success": True,
        "audit_only": False if req.from_agent == "xiao_wen" else True,
        "state_changed": req.from_agent == "xiao_wen",
        "from_agent": req.from_agent,
        "to_agent": to_agent,
        "to_name": to_name,
        "jd_revision": jd_revision,
        "jd_locked": bool(req.from_agent == "xiao_wen"),
        "jd_locked_at": lock["jd_locked_at"] if req.from_agent == "xiao_wen" else "",
        "jd_locked_by_stage": lock["jd_locked_by_stage"] if req.from_agent == "xiao_wen" else "",
        "artifacts": artifact_payload,
    }


@router.post("/{pipeline_id}/complete")
async def api_complete_pipeline(pipeline_id: str, req: CompletePipelineRequest = CompletePipelineRequest()):
    """Confirm the final report and close a pipeline after all human gates pass."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    if pipeline.get("status") == "completed":
        return {"status": "completed", "pipeline_id": pipeline_id, "already_completed": True}

    blockers, report_output, queue = _pipeline_completion_blockers(pipeline_id)
    if blockers:
        raise HTTPException(409, "；".join(blockers))

    conn = get_db()
    try:
        update_stage(pipeline_id, "report", "done", report_output, conn=conn)
        update_pipeline(pipeline_id, "completed", conn=conn)
        save_message(
            pipeline_id,
            "system",
            "流水线已完成：评估报告和候选人决策已确认。",
            card_type="pipeline_completion",
            card_data={
                "actor_id": req.actor_id,
                "ready_candidates": queue["counts"]["ready_for_decision"],
                "completed_at": datetime.now().isoformat(),
            },
            stage_id="report",
            conn=conn,
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    await broadcast(
        {"type": "stage_done", "pipeline_id": pipeline_id, "stage_id": "report", "stage_name": "录用报告"},
        pipeline_id,
    )
    await broadcast({"type": "pipeline_completed", "pipeline_id": pipeline_id, "role": pipeline["role"]}, pipeline_id)
    return {"status": "completed", "pipeline_id": pipeline_id}


# ============ 确认阶段 ============


@router.post("/{pipeline_id}/stages/{stage_id}/confirm")
async def api_confirm_stage(pipeline_id: str, stage_id: str):
    """Confirm a stage is done and trigger downstream"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    if stage_id == "report":
        return await api_complete_pipeline(pipeline_id)

    stages = get_stages(pipeline_id)
    stage = None
    for s in stages:
        if s["stage_id"] == stage_id:
            stage = s
            break

    if not stage:
        raise HTTPException(404, f"Stage {stage_id} not found")

    if stage_id == "jd_write":
        try:
            jd_workspace.approve_draft(pipeline_id)
        except jd_workspace.JdLockedError as error:
            raise HTTPException(423, str(error))
        except ValueError as error:
            raise HTTPException(400, str(error))
    else:
        update_stage(pipeline_id, stage_id, "done", stage.get("output"))

    # 保存系统消息
    stage_names = {
        "jd_write": "JD撰写",
        "profile_build": "候选人画像",
        "poster_gen": "招聘海报",
        "crawl": "简历获取",
        "match": "简历筛查",
        "interview_gen": "面试出题",
        "video_assess": "视频评估",
        "report": "录用报告",
    }
    name = stage_names.get(stage_id, stage_id)
    save_message(
        pipeline_id,
        "system",
        f"{name}已完成",
        card_type="info_card",
        card_data={"message": f"{name}阶段已完成，可以传递给下一个Agent"},
        stage_id=stage_id,
    )

    # 通过 WebSocket 广播
    await broadcast(
        {
            "type": "stage_done",
            "pipeline_id": pipeline_id,
            "stage_id": stage_id,
        },
        pipeline_id,
    )

    return {"success": True, "stage_id": stage_id, "status": "done"}


# ============ 构建候选人画像 ============


def _profile_run_is_current(pipeline_id: str, run_id: str) -> bool:
    stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "profile_build"), None)
    output = parse_stage_output(stage) if stage else {}
    return bool(stage and stage.get("status") == "running" and output.get("run_id") == run_id)


def _finish_profile_run(pipeline_id: str, run_id: str, status: str, output: dict) -> bool:
    if not _profile_run_is_current(pipeline_id, run_id):
        return False
    update_stage(pipeline_id, "profile_build", status, output)
    return True


@router.post("/{pipeline_id}/stages/profile_build/run")
async def api_run_profile_build(pipeline_id: str):
    """Trigger ProfileAgent to build a structured candidate profile from JD."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if not jd_stage or jd_stage.get("status") != "done":
        raise HTTPException(400, "请先完成JD撰写")

    # 幂等保护：运行中的任务不重复触发；已完成结果直接复用当前画像。
    profile_stage = next((s for s in stages if s["stage_id"] == "profile_build"), None)
    if profile_stage and profile_stage.get("status") == "running":
        raise HTTPException(409, "候选人画像正在生成中，请稍候...")

    jd_output = parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})
    jd_revision = int(jd_output.get("revision") or 0)
    jd_source_fingerprint = jd_workspace.jd_fingerprint(jd)
    role = pipeline.get("role", "未知岗位")

    if jd_output.get("approval_status") == "draft":
        raise HTTPException(400, "请先确认当前JD")

    if profile_stage and profile_stage.get("status") == "done":
        profile_output = parse_stage_output(profile_stage)
        profile = profile_output.get("profile", profile_output)
        if jd_workspace.is_profile_current(profile_stage, profile_output, jd, jd_revision):
            return {
                "success": True,
                "stage_id": "profile_build",
                "status": "done",
                "profile": profile,
                "cached": True,
            }

    # 确保 profile_build 阶段存在
    stage_ids = {s["stage_id"] for s in stages}
    if "profile_build" not in stage_ids:
        create_stage(pipeline_id, "profile_build", "候选人画像")

    # 运行标识防止旧任务完成时覆盖后续生成任务。
    profile_run_id = uuid4().hex
    update_stage(
        pipeline_id,
        "profile_build",
        "running",
        {"run_id": profile_run_id, "jd_revision": jd_revision, "jd_fingerprint": jd_source_fingerprint},
    )

    # 运行 ProfileAgent
    from hr_harness.agents.profile_agent import ProfileAgent
    from hr_harness.tool_protocol import ToolInput

    memory = MemorySystem(pipeline_id)
    memory_context = memory.build_system_context()
    profile_context = build_xiao_wen_context(
        pipeline_id=pipeline_id,
        role=role,
        pipeline_type=pipeline.get("type", "general"),
        memory_context=memory_context,
    )
    profile_context["jd"] = jd
    profile_context = attach_agent_runtime_config(profile_context, "profile_build")

    agent = ProfileAgent()
    deadline = TimeoutDeadline(get_agent_timeout("profile_build"), agent_id="profile_build")
    try:
        result = await agent.run_with_deadline(
            ToolInput(
                pipeline_id=pipeline_id,
                params=profile_context,
            ),
            deadline,
        )
        if result.status.value != "success":
            _finish_profile_run(pipeline_id, profile_run_id, "pending", {})
            raise HTTPException(502, result.error or "画像生成失败，请重试")
        profile_data = result.data
    except BusinessTimeoutError:
        _finish_profile_run(pipeline_id, profile_run_id, "failed", {"error": "backend_timeout"})
        raise
    except HTTPException:
        raise
    except Exception as e:
        import logging

        logging.getLogger("main").error(f"ProfileAgent failed: {e}")
        _finish_profile_run(pipeline_id, profile_run_id, "pending", {})
        raise HTTPException(500, f"画像生成失败: {str(e)}")

    # 持久化结果
    profile_data = dict(profile_data) if isinstance(profile_data, dict) else {}
    profile = profile_data.get("profile", profile_data)
    if not isinstance(profile, dict) or not profile.get("dimensions"):
        _finish_profile_run(pipeline_id, profile_run_id, "pending", {})
        raise HTTPException(502, "画像生成结果不完整，请重试")

    latest_stages = get_stages(pipeline_id)
    latest_jd_stage = next((stage for stage in latest_stages if stage["stage_id"] == "jd_write"), None)
    latest_jd_output = parse_stage_output(latest_jd_stage) if latest_jd_stage else {}
    latest_jd = latest_jd_output.get("jd") if isinstance(latest_jd_output.get("jd"), dict) else {}
    latest_revision = int(latest_jd_output.get("revision") or 0)
    source_changed = bool(
        not latest_jd_stage
        or latest_jd_stage.get("status") != "done"
        or latest_jd_output.get("approval_status") == "draft"
        or latest_revision != jd_revision
        or jd_workspace.jd_fingerprint(latest_jd) != jd_source_fingerprint
    )
    if source_changed:
        _finish_profile_run(pipeline_id, profile_run_id, "pending", {})
        raise HTTPException(
            409,
            detail={
                "code": "profile_source_changed",
                "message": "JD在画像生成期间已更新，请重新确认并生成画像",
                "current_revision": latest_revision,
            },
        )
    if not _profile_run_is_current(pipeline_id, profile_run_id):
        raise HTTPException(
            409,
            detail={"code": "profile_build_superseded", "message": "已有更新的画像生成任务，请稍候"},
        )

    profile_data["jd_revision"] = jd_revision
    profile_data["jd_fingerprint"] = jd_source_fingerprint
    update_stage(pipeline_id, "profile_build", "done", profile_data)
    save_message(
        pipeline_id,
        "assistant",
        "22维候选人画像已生成",
        card_type="profile_card",
        card_data=profile_data,
        stage_id="jd_write",
    )

    # 广播结果
    await broadcast(
        {
            "type": "stage_done",
            "pipeline_id": pipeline_id,
            "stage_id": "profile_build",
        },
        pipeline_id,
    )

    return {
        "success": True,
        "stage_id": "profile_build",
        "status": "done",
        "profile": profile_data.get("profile", profile_data),
    }


# ============ 导入简历 ============


@router.post("/{pipeline_id}/import-resumes")
async def api_batch_import_resumes(pipeline_id: str, req: BatchResumeImportRequest):
    """Batch import parsed resumes into pipeline."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    stages = get_stages(pipeline_id)
    existing_stage_ids = {s["stage_id"] for s in stages}

    # 确保 crawl 阶段存在
    if "crawl" not in existing_stage_ids:
        create_stage(pipeline_id, "crawl", "简历获取")

    # Save all resumes as candidates（先去重闸门：与人才库已有简历重复 → 跳过）
    from app.talent_pool import save_resume as _pool_save

    imported = []
    duplicate_count = 0
    for r in req.resumes:
        if not r.get("id"):
            r["id"] = f"imp_{hashlib.md5(r.get('name', '').encode()).hexdigest()[:8]}"
        r["source"] = r.get("source", "local_import")
        r["status"] = "new"
        # 去重闸门：save_resume 同时写入全局人才库（全入口统一去重的一部分）。
        # 异常时降级为不判重（照常入候选），保证导入不因人才库抖动而失败。
        try:
            pool_result = _pool_save(r)
        except Exception as e:
            from app.audit.logger import get_logger

            logger = get_logger("resumes")
            logger.warning(f"save_resume failed: {e}", extra={"source": "ImportResumes"})
            pool_result = {}
        if pool_result.get("duplicate"):
            duplicate_count += 1
            continue
        save_candidate(pipeline_id, r)
        imported.append(r)

    # 更新 crawl 阶段
    summary_text = f"本地导入{len(imported)}份简历"
    if duplicate_count:
        summary_text += f"，{duplicate_count}份重复跳过"
    crawl_output = {
        "resumes": imported,
        "resume_count": len(imported),
        "sources": ["local_import"],
        "status": "completed",
        "summary": summary_text,
    }
    update_stage(pipeline_id, "crawl", "done", crawl_output)

    # 广播结果
    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "crawl",
            "card": {"type": "crawl_card", "data": crawl_output, "summary": crawl_output["summary"]},
        },
        pipeline_id,
    )

    save_message(
        pipeline_id,
        "assistant",
        f"已导入{len(imported)}份简历，可以开始筛查。"
        + (f"（{duplicate_count}份与人才库重复，已跳过）" if duplicate_count else ""),
        card_type="crawl_card",
        card_data=crawl_output,
    )

    return {"success": True, "imported": len(imported), "duplicates": duplicate_count, "resumes": imported}


# ============ 生成面试问题 ============


@router.post("/{pipeline_id}/interview-questions/generate")
async def api_generate_interview_questions(pipeline_id: str, req: InterviewGenerateRequest):
    """结构化出题入口；与自然语言改题命令分离，避免绕过确认边界。"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    stages = get_stages(pipeline_id)
    from app.screening_workflow import get_screening_context

    screening_context = get_screening_context(pipeline_id)
    stages_dict = {stage["stage_id"]: stage["status"] for stage in stages}
    if screening_context["is_modern"]:
        if screening_context["workflow_status"] != "confirmed":
            raise HTTPException(400, "请先完成小筛复核和定版，再生成面试题")
    elif "match" in stages_dict and stages_dict["match"] != "done":
        raise HTTPException(400, "请先完成简历筛查，再生成面试题")

    message = "为所有通过筛查的候选人生成面试题"
    context = {"batch": True}
    if req.candidate_id and not req.batch:
        message = f"为候选人{req.candidate_id}生成面试题"
        context = {"candidate_id": req.candidate_id}
    handler = state.get_action_handler()
    return await handler.handle_action(
        pipeline_id,
        "chat",
        {"message": message, "stage_id": "interview_gen", "context": context},
    )


@router.get("/{pipeline_id}/interview-questions/generation/{task_id}")
async def api_interview_generation_status(pipeline_id: str, task_id: str):
    """查询批量出题任务，避免前端用旧 stage 状态误判本次生成已完成。"""
    task = services.get_interview_generation_task(task_id, pipeline_id)
    if not task:
        stage = next((item for item in get_stages(pipeline_id) if item["stage_id"] == "interview_gen"), None)
        output = parse_stage_output(stage) if stage else {}
        if not stage or output.get("generation_job_id") != task_id:
            raise HTTPException(404, "Generation task not found")
        status = stage.get("status") or "queued"
        interviews = output.get("interviews", [])
        if not isinstance(interviews, list):
            interviews = []
        task = {
            "id": task_id,
            "pipeline_id": pipeline_id,
            "status": "done" if status == "done" else "failed" if status == "failed" else status,
            "progress": 100 if status in {"done", "failed"} else 10,
            "candidate_count": len(interviews),
            "question_count": output.get("generated_count"),
            "message": output.get("error") or ("面试题生成完成" if status == "done" else "面试题仍在生成中"),
            "error": output.get("error", ""),
        }
    return task


# ============ 候选人 ============


@router.get("/{pipeline_id}/candidates")
async def api_get_pipeline_candidates(pipeline_id: str):
    """Get all candidates for a pipeline（手机号脱敏）"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    candidates = get_candidates(pipeline_id)
    # 联系方式可能只保存在人才库 resumes 表，详情接口需要合并两处数据。
    # 候选人表优先，简历字段作为缺失值的回退来源。
    for candidate in candidates:
        resume_id = str(candidate.get("resume_id") or "")
        if not resume_id:
            continue
        resume = get_resume_by_id(resume_id, tenant_id=str(pipeline.get("tenant_id") or "tenant_default"))
        if not resume:
            continue
        for field in ("phone", "email", "candidate_email", "original_filename", "storage_backend", "storage_key"):
            if not candidate.get(field) and resume.get(field):
                candidate[field] = resume[field]
    # 面试中心详情由已授权 HR 查看，需要返回完整联系方式用于联系候选人。
    return candidates


@router.get("/{pipeline_id}/candidates/{candidate_id}/resume")
async def api_get_candidate_resume(pipeline_id: str, candidate_id: str):
    """Load a candidate's persisted resume, preferring the talent-pool source record."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    candidate = next((item for item in get_candidates(pipeline_id) if item.get("id") == candidate_id), None)
    if not candidate:
        raise HTTPException(404, "Candidate not found")

    resume_id = str(candidate.get("resume_id") or "")
    if resume_id:
        resume = get_resume_by_id(resume_id, tenant_id=str(pipeline.get("tenant_id") or "tenant_default"))
        if resume:
            resume["candidate_id"] = candidate_id
            return resume

    return {**candidate, "candidate_id": candidate_id, "storage_source": "candidate_snapshot"}


@router.post("/{pipeline_id}/candidates/simple-import")
async def api_simple_import_candidates(pipeline_id: str, req: Request):
    """兼容存量调用：批量导入仅包含姓名和手机号的候选人。"""
    from app.audit.audit_trail import audit

    if not get_pipeline(pipeline_id):
        raise HTTPException(404, "Pipeline not found")

    data = await req.json()
    candidates = data.get("candidates", [])
    if not candidates:
        raise HTTPException(400, "候选人列表不能为空")
    if len(candidates) > 100:
        raise HTTPException(400, "单次最多导入 100 人")

    created = []
    errors = []
    for index, candidate in enumerate(candidates):
        name = str(candidate.get("name", "")).strip()
        phone = str(candidate.get("phone", "")).strip()
        if not name:
            errors.append(f"第{index + 1}行：姓名不能为空")
            continue
        if not re.match(r"^1[3-9]\d{9}$", phone):
            errors.append(f"第{index + 1}行：手机号格式不正确 ({phone})")
            continue
        try:
            candidate_id = save_simple_candidate(pipeline_id, name, phone)
            created.append({"id": candidate_id, "name": name, "phone": f"{phone[:3]}****{phone[7:]}"})
        except Exception as error:
            errors.append(f"第{index + 1}行：导入失败 - {error}")

    audit(
        "candidates.simple_import",
        f"兼容导入 {len(created)} 人",
        entity_type="pipeline",
        entity_id=pipeline_id,
        details={"created": len(created), "errors": len(errors)},
    )
    return {"created": len(created), "candidates": created, "errors": errors}


# ============ 面试日程 ============


@router.get("/{pipeline_id}/interview-schedules")
async def api_get_interview_schedules(pipeline_id: str):
    return get_interview_schedules(pipeline_id)


@router.post("/{pipeline_id}/interview-schedules")
async def api_create_interview_schedule(pipeline_id: str, req: InterviewScheduleRequest):
    sid = "sch_" + hashlib.md5(f"{pipeline_id}_{req.candidate_id}_{req.date}".encode()).hexdigest()[:8]
    schedule = {
        "id": sid,
        "pipeline_id": pipeline_id,
        "candidate_id": req.candidate_id,
        "candidate_name": req.candidate_name,
        "date": req.date,
        "time": req.time,
        "interviewer": req.interviewer,
        "method": req.method,
        "round": req.round,
        "notes": req.notes,
        "status": "scheduled",
    }
    save_interview_schedule(schedule)
    return {"success": True, "id": sid}


# ============ 淘汰记录 ============


@router.get("/{pipeline_id}/elimination-records")
async def api_get_elimination_records(pipeline_id: str):
    return get_elimination_records(pipeline_id)


# ============ 进度 ============


@router.get("/{pipeline_id}/progress")
async def api_pipeline_progress(pipeline_id: str):
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    stages = get_stages(pipeline_id)
    candidates = get_candidates(pipeline_id)
    agents = (
        json.loads(pipeline.get("agents", "[]"))
        if isinstance(pipeline.get("agents"), str) and pipeline.get("agents")
        else (pipeline.get("agents") or [])
    )

    stage_summary = []
    for s in stages:
        output = s.get("output")
        if isinstance(output, str):
            try:
                output = json.loads(output)
            except:
                output = {}
        stage_summary.append(
            {
                "stage_id": s["stage_id"],
                "name": s.get("name", s["stage_id"]),
                "status": s.get("status", "pending"),
                "summary": output.get("summary", "") if isinstance(output, dict) else "",
            }
        )

    passed = len([c for c in candidates if c.get("status") == "passed"])
    rejected = len([c for c in candidates if c.get("status") == "rejected"])

    progress_text = f"{pipeline.get('role', '')}招聘进展："
    for s in stage_summary:
        if s["status"] == "done":
            progress_text += f"{s['name']}已完成；"
    progress_text += f"共{len(candidates)}位候选人，{passed}人通过，{rejected}人淘汰。"

    return {
        "pipeline_id": pipeline_id,
        "role": pipeline.get("role", ""),
        "agents": agents,
        "stages": stage_summary,
        "candidate_count": len(candidates),
        "passed": passed,
        "rejected": rejected,
        "progress_text": progress_text,
    }


# ============ 完成流水线 ============


@router.post("/{pipeline_id}/finalize")
async def api_finalize_pipeline(pipeline_id: str):
    """HR 手动关闭流水线：若有未处理简历则运行完整匹配+总结，否则直接标记完成。"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    if pipeline["status"] not in ("waiting_for_resumes", "running"):
        raise HTTPException(400, f"流水线状态 {pipeline['status']} 不允许关闭")

    has_pending = bool(state.pending_resumes.get(pipeline_id))

    if has_pending:
        # 有未处理简历 → 验证后异步启动匹配流程（finally 释放锁）
        check = await services.process_imported_resumes(pipeline_id)
        if check and check.get("status") == "skipped":
            raise HTTPException(400, check.get("reason", "无法启动匹配"))

        async def _finalize_with_lock():
            try:
                await services._do_process_imported_resumes(pipeline_id)
            except Exception as e:
                import logging

                logging.getLogger("main").error(f"Finalize error for {pipeline_id}: {e}", exc_info=True)
            finally:
                state.processing_locks.pop(pipeline_id, None)

        asyncio.create_task(_finalize_with_lock())
        return {"status": "finalizing", "message": "正在运行最终匹配并生成报告..."}
    else:
        # 无待处理简历 → 直接标记完成
        update_pipeline(pipeline_id, "completed")
        save_message(pipeline_id, "assistant", "✅ 流水线已关闭")
        await state.broadcast({"type": "pipeline_completed", "pipeline_id": pipeline_id}, pipeline_id)
        await state.broadcast(
            {"type": "pipeline_done", "pipeline_id": pipeline_id, "role": pipeline["role"]}, pipeline_id
        )
        return {"status": "completed", "message": "流水线已关闭"}


# ============ 录用 ============


@router.post("/{pipeline_id}/hire")
async def api_hire_candidate(pipeline_id: str, req: Request):
    """录用候选人：生成录用报告并关闭流水线"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    if pipeline["status"] == "completed":
        raise HTTPException(400, "流水线已完成")

    body = await req.json()
    candidate_id = body.get("candidate_id", "")

    # 获取候选人和阶段数据
    candidates = get_candidates(pipeline_id)
    stages = get_stages(pipeline_id)

    # 获取 JD
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    jd_output = parse_stage_output(jd_stage)
    jd = jd_output.get("jd", {})

    # 获取面试评估数据（从 messages 和 candidates 两个来源）
    messages = get_messages(pipeline_id)
    assessments = []
    # 优先从 candidates 的 video_assessment 字段读取（submit-answers 流程写入）
    for c in candidates:
        va = c.get("video_assessment")
        if va and isinstance(va, dict) and va.get("dimensions"):
            assessments.append(va)
    # 补充从 messages 中 interview_eval_card 读取（旧流程兼容）
    for m in messages:
        if m.get("card_type") in ("interview_eval_card", "assessment_card") and m.get("card_data"):
            try:
                data = json.loads(m["card_data"]) if isinstance(m["card_data"], str) else m["card_data"]
                # assessment_card 的数据结构是 {"assessments": [...]}
                if data.get("assessments"):
                    for a in data["assessments"]:
                        if isinstance(a, dict) and a.get("dimensions") and a not in assessments:
                            assessments.append(a)
                elif isinstance(data, dict) and data.get("dimensions") and data not in assessments:
                    assessments.append(data)
            except (json.JSONDecodeError, TypeError):
                pass

    # 确保 report stage 存在
    stage_ids = {s["stage_id"] for s in stages}
    if "report" not in stage_ids:
        create_stage(pipeline_id, "report", "录用报告")

    # 标记候选人
    if candidate_id:
        update_candidate(candidate_id, {"status": "offered"})
        candidate_name = next((c["name"] for c in candidates if c["id"] == candidate_id), candidate_id)
        save_message(pipeline_id, "system", f"🎯 {candidate_name} 已录用，正在生成录用报告...")

    # 异步生成报告并完成流水线
    context = {
        "candidates": candidates,
        "assessments": assessments,
        "jd": jd,
        "role": pipeline["role"],
        "pipeline_id": pipeline_id,
    }
    asyncio.create_task(services.run_report(pipeline_id, context, pipeline))
    return {"status": "hired", "candidate_id": candidate_id}


# ============ 批量删除 ============


@router.delete("/batch")
async def api_batch_delete_pipelines(req: BatchDeleteRequest, request: Request):
    """Batch delete pipelines"""
    deleted = []
    failed = []
    for pid in req.ids:
        try:
            require_pipeline_access(request, pid)
        except HTTPException as error:
            if error.status_code != 404:
                raise
            failed.append(pid)
            continue
        state.pending_resumes.pop(pid, None)
        state.pending_videos.pop(pid, None)
        ok = delete_pipeline(pid)
        if ok:
            deleted.append(pid)
        else:
            failed.append(pid)
    return {"deleted": deleted, "failed": failed, "count": len(deleted)}


@router.delete("/{pipeline_id}")
async def api_delete_pipeline(pipeline_id: str):
    """Delete a pipeline and all its data"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    # 清理待处理简历内存状态；数据库记录由 delete_pipeline() 在同一删除事务中清理。
    state.pending_resumes.pop(pipeline_id, None)
    state.pending_videos.pop(pipeline_id, None)

    # 从数据库删除（级联删除阶段、候选人和消息）
    ok = delete_pipeline(pipeline_id)
    if not ok:
        raise HTTPException(500, "Failed to delete pipeline")

    # 通知所有 WebSocket 客户端
    for conn in connections:
        try:
            await conn.send_json({"type": "pipeline_deleted", "pipeline_id": pipeline_id})
        except:
            pass

    from app.audit.audit_trail import audit

    audit(
        "pipeline.deleted",
        f"删除流水线: {pipeline.get('role', '')} ({pipeline_id})",
        entity_type="pipeline",
        entity_id=pipeline_id,
    )
    return {"status": "deleted", "pipeline_id": pipeline_id}


# ============ 上传简历（仅存储文件，不调用 LLM） ============


@router.post("/{pipeline_id}/upload-resumes")
async def api_upload_resumes_files(pipeline_id: str, files: list[UploadFile] = File(...)):
    """Batch upload resume files (pure storage, no LLM parsing)"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    if len(files) > 50:
        raise HTTPException(400, "最多上传50份简历")

    # 上游检查：上传简历前必须存在 JD
    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if not jd_stage or jd_stage.get("status") != "done":
        raise HTTPException(400, "请先完成JD撰写，再导入简历")

    storage = get_media_storage()
    raw_dir = os.path.join(RESUME_UPLOAD_DIR, pipeline_id, "raw")
    if storage.backend != "oss":
        os.makedirs(raw_dir, exist_ok=True)

    results: list[dict] = [{} for _ in files]
    existing_md5 = set()
    # 检查现有文件并去重
    if storage.backend == "oss":
        raw_prefix = join_storage_key(settings.oss_resume_prefix, "raw", pipeline_id)
        for key in storage.list_keys(raw_prefix):
            existing_md5.add(hashlib.md5(storage.read(key)).hexdigest())
    else:
        for f in os.listdir(raw_dir):
            fp = os.path.join(raw_dir, f)
            if os.path.isfile(fp):
                with open(fp, "rb") as fh:
                    existing_md5.add(hashlib.md5(fh.read()).hexdigest())

    def prepare_file(index: int, upload: UploadFile):
        """Read, validate, and hash one file in its own worker thread."""
        ext = os.path.splitext(upload.filename or "")[1].lower()
        if ext not in (".pdf", ".docx", ".doc", ".md", ".txt"):
            return index, None, {"name": upload.filename, "status": "error", "error": f"不支持的格式: {ext}"}
        # UploadFile.file is the underlying synchronous spooled file. Reading
        # it in the worker keeps the complete per-file path off the event loop.
        content = upload.file.read()
        if len(content) > 10 * 1024 * 1024:
            return index, None, {"name": upload.filename, "status": "error", "error": "文件超过10MB"}
        return index, (upload, ext, content, hashlib.md5(content).hexdigest()), None

    def store_file(index: int, upload: UploadFile, ext: str, content: bytes, md5: str):
        """Persist one validated file entirely inside its worker thread."""
        safe_name = (upload.filename or "resume").replace("/", "_").replace("\\", "_")
        stored_name = f"{md5[:16]}_{safe_name}"
        try:
            if storage.backend == "oss":
                storage_key = join_storage_key(settings.oss_resume_prefix, "raw", pipeline_id, stored_name)
                storage.write(storage_key, content, upload.content_type or "application/octet-stream")
            else:
                filepath = os.path.join(raw_dir, safe_name)
                with open(filepath, "wb") as fh:
                    fh.write(content)
        except Exception as exc:
            return index, {"name": safe_name, "status": "error", "error": f"文件存储失败: {str(exc)[:120]}"}
        return index, {
            "name": safe_name,
            "stored_name": stored_name,
            "size": len(content),
            "format": ext,
            "md5": md5,
            "storage_backend": storage.backend,
            "status": "success",
        }

    # Use the process-wide CPU-bounded executor. Files beyond the available
    # worker count are queued by ThreadPoolExecutor.
    loop = asyncio.get_running_loop()

    async def run_workers():
        executor = get_upload_executor()
        prepared = await asyncio.gather(
            *(loop.run_in_executor(executor, prepare_file, i, upload) for i, upload in enumerate(files))
        )
        to_store = []
        for index, item, error in prepared:
            if error:
                results[index] = error
                continue
            upload, ext, content, md5 = item
            if md5 in existing_md5:
                results[index] = {"name": upload.filename, "status": "duplicate", "error": "文件已存在"}
                continue
            existing_md5.add(md5)
            to_store.append((index, upload, ext, content, md5))

        stored = await asyncio.gather(*(loop.run_in_executor(executor, store_file, *item) for item in to_store))
        for index, result in stored:
            results[index] = result

    await run_workers()
    success_count = sum(1 for r in results if r["status"] == "success")
    return {"success": True, "uploaded": success_count, "total": len(files), "files": results}


@router.get("/{pipeline_id}/raw-files")
async def api_list_raw_files(pipeline_id: str):
    """List uploaded raw resume files (even before parse)"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    storage = get_media_storage()
    raw_dir = os.path.join(RESUME_UPLOAD_DIR, pipeline_id, "raw")
    if storage.backend == "oss":
        prefix = join_storage_key(settings.oss_resume_prefix, "raw", pipeline_id)
        files = []
        for key in storage.list_keys(prefix):
            fname = key.rsplit("/", 1)[-1]
            ext = os.path.splitext(fname)[1].lower()
            content = storage.read(key)
            files.append(
                {
                    "name": fname,
                    "ext": ext,
                    "size_kb": round(len(content) / 1024, 1),
                    "storage_backend": storage.backend,
                    "storage_key": key,
                }
            )
        return {"files": files, "count": len(files)}
    if not os.path.exists(raw_dir):
        return {"files": [], "count": 0}
    files = []
    for fname in sorted(os.listdir(raw_dir)):
        fpath = os.path.join(raw_dir, fname)
        if os.path.isfile(fpath):
            ext = os.path.splitext(fname)[1].lower()
            size = os.path.getsize(fpath)
            files.append({"name": fname, "ext": ext, "size_kb": round(size / 1024, 1)})
    return {"files": files, "count": len(files)}


# ============ 解析简历（基于规则，不调用 LLM） ============


@router.post("/{pipeline_id}/parse-resumes")
async def api_parse_resumes(pipeline_id: str):
    """Parse uploaded resumes using rule-based extraction (no LLM)"""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    raw_dir = os.path.join(RESUME_UPLOAD_DIR, pipeline_id, "raw")
    parsed_dir = os.path.join(RESUME_UPLOAD_DIR, pipeline_id, "parsed")
    os.makedirs(parsed_dir, exist_ok=True)
    storage = get_media_storage()

    # 无上传文件时不再报错：检测 candidates 表（人才库导入的候选人在这里），
    # 返回 from_pool 计数让前端跳过解析直接筛查；两者都没有才提示无简历。
    raw_items: list[tuple[str, str]] = []
    if storage.backend == "oss":
        prefix = join_storage_key(settings.oss_resume_prefix, "raw", pipeline_id)
        raw_items = [(key.rsplit("/", 1)[-1], key) for key in storage.list_keys(prefix)]
    elif os.path.isdir(raw_dir):
        raw_items = [(f, "") for f in os.listdir(raw_dir) if os.path.isfile(os.path.join(raw_dir, f))]
    if not raw_items:
        pool_count = len(get_candidates(pipeline_id))
        message = (
            f"未发现上传文件，检测到 {pool_count} 位人才库候选人，跳过文件解析"
            if pool_count
            else "未发现简历文件，请先上传或从人才库导入"
        )
        return {
            "success": True,
            "parsed": 0,
            "total": 0,
            "results": [],
            "from_pool": pool_count,
            "message": message,
        }

    results = []
    duplicate_count = 0
    temporary_paths: list[str] = []
    for fname, storage_key in raw_items:
        ext = os.path.splitext(fname)[1].lower()
        fpath = os.path.join(raw_dir, fname)
        text = ""
        try:
            if storage_key:
                fd, fpath = tempfile.mkstemp(prefix="resume-", suffix=ext)
                os.close(fd)
                with open(fpath, "wb") as raw_file:
                    raw_file.write(storage.read(storage_key))
                temporary_paths.append(fpath)
            if ext == ".md" or ext == ".txt":
                text = _read_text_file(fpath)
            elif ext == ".pdf":
                text, text_source, pdf_error = _parse_pdf_file(fpath)
                if pdf_error:
                    results.append(
                        {"file": fname, "status": "error", "error": pdf_error["msg"], "error_type": pdf_error["type"]}
                    )
                    continue
            elif ext in (".docx", ".doc"):
                try:
                    from docx import Document

                    doc = Document(fpath)
                    text = "\n".join(p.text for p in doc.paragraphs)
                except ImportError:
                    results.append(
                        {
                            "file": fname,
                            "status": "error",
                            "error": "python-docx 未安装，无法解析DOCX文件",
                            "error_type": "dependency_missing",
                        }
                    )
                    continue
                except Exception as e:
                    results.append(
                        {
                            "file": fname,
                            "status": "error",
                            "error": f"DOCX解析失败: {str(e)[:100]}",
                            "error_type": "docx_parse_error",
                        }
                    )
                    continue
        except Exception as e:
            results.append(
                {
                    "file": fname,
                    "status": "error",
                    "error": f"文件读取失败: {str(e)[:120]}",
                    "error_type": "file_read_error",
                }
            )
            continue

        if not text or len(text.strip()) < 20:
            results.append(
                {
                    "file": fname,
                    "status": "error",
                    "error": f"文本内容不足（仅{len(text.strip())}字符），无法提取简历信息",
                    "error_type": "insufficient_text",
                }
            )
            continue

        # 基于规则提取
        parsed = _extract_resume_rules(text, fname)
        # 联系方式：规则双空（异常）时 LLM 兜底再试一次，尽量抓全
        if parsed.get("contact_status") == "missing":
            llm_phone, llm_email = await extract_contact_with_llm(text)
            if llm_phone or llm_email:
                parsed["phone"] = llm_phone
                parsed["email"] = llm_email
                parsed["contact_status"] = classify_contact(llm_phone, llm_email)
        # 保存解析后的 JSON
        parsed_path = os.path.join(parsed_dir, fname + ".json")
        with open(parsed_path, "w", encoding="utf-8") as f:
            json.dump(parsed, f, ensure_ascii=False, indent=2)

        # Save as candidate（先去重闸门：与人才库已有简历重复 → 跳过不入流水线）
        # 说明：本地导入经 save_resume 同时写入全局人才库（全入口统一去重闸门的一部分），
        # 与库中已有简历重复时跳过、不入流水线；save_resume 异常时降级为不判重（照常入候选）。
        from app.talent_pool import save_resume as _pool_save

        try:
            pool_result = _pool_save(parsed)
        except Exception as e:
            from app.audit.logger import get_logger

            logger = get_logger("resumes")
            logger.warning(f"save_resume failed: {e}", extra={"source": "ParseResumes"})
            pool_result = {}
        if pool_result.get("duplicate"):
            duplicate_count += 1
            results.append(
                {"file": fname, "status": "duplicate", "error": "与人才库已有简历重复", "error_type": "duplicate"}
            )
            continue
        save_candidate(pipeline_id, parsed)

        # 更新 crawl 阶段
        results.append({"file": fname, "status": "success", "data": parsed})

        # 更新 crawl 阶段输出
    for temporary_path in temporary_paths:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass

    stages = get_stages(pipeline_id)
    existing_ids = {s["stage_id"] for s in stages}
    if "crawl" not in existing_ids:
        create_stage(pipeline_id, "crawl", "简历获取")

    all_candidates = get_candidates(pipeline_id)
    success_parsed = sum(1 for r in results if r["status"] == "success")
    summary_text = f"解析完成：{len(results)}份文件，{success_parsed}份成功"
    if duplicate_count:
        summary_text += f"，{duplicate_count}份重复跳过"
    crawl_output = {
        "resumes": all_candidates,
        "resume_count": len(all_candidates),
        "sources": ["local_import"],
        "status": "completed",
        "summary": summary_text,
    }
    update_stage(pipeline_id, "crawl", "done", crawl_output)

    save_message(pipeline_id, "assistant", crawl_output["summary"], card_type="crawl_card", card_data=crawl_output)

    await broadcast(
        {
            "type": "stage_card",
            "stage_id": "crawl",
            "card": {"type": "crawl_card", "data": crawl_output, "summary": crawl_output["summary"]},
        },
        pipeline_id,
    )

    success_results = [r for r in results if r["status"] == "success"]
    missing_count = sum(1 for r in success_results if r["data"].get("contact_status") == "missing")
    manual_count = sum(1 for r in success_results if r["data"].get("contact_status") == "manual")

    # 联系方式提醒：同步写入对话留存（前端另行弹窗/toast，服务端消息留痕）
    if missing_count:
        missing_names = [
            r["data"].get("name") or r["file"] for r in success_results if r["data"].get("contact_status") == "missing"
        ]
        save_message(
            pipeline_id,
            "system",
            f"⚠️ {missing_count}份简历无有效联系方式（无电话且无邮箱），可能无法联系候选人，请核实补充："
            + "、".join(missing_names[:10]),
        )
    if manual_count:
        manual_names = [
            r["data"].get("name") or r["file"] for r in success_results if r["data"].get("contact_status") == "manual"
        ]
        save_message(
            pipeline_id,
            "system",
            f"🟠 {manual_count}份简历仅有电话、无邮箱，系统无法自动发送面试邀请，需人工电话联系："
            + "、".join(manual_names[:10]),
        )

    return {
        "success": True,
        "parsed": len(success_results),
        "total": len(results),
        "results": results,
        "duplicates": duplicate_count,
        "missing_contact_count": missing_count,
        "manual_contact_count": manual_count,
    }


# ============ DAG 与重试 ============


@router.get("/{pipeline_id}/dag")
async def api_get_pipeline_dag(pipeline_id: str):
    """Return pipeline DAG state for visualization."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    stages = get_stages(pipeline_id)
    return {
        "pipeline_id": pipeline_id,
        "role": pipeline.get("role", ""),
        "engine_version": pipeline.get("engine_version", 1),
        "stages": [
            {
                "stage_id": s["stage_id"],
                "status": s.get("status", "pending"),
                "output_summary": s.get("output_summary", ""),
            }
            for s in stages
        ],
    }


@router.post("/{pipeline_id}/retry/{stage_id}")
async def api_retry_stage(pipeline_id: str, stage_id: str):
    """Retry a failed pipeline stage."""
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return {"status": "retrying", "pipeline_id": pipeline_id, "stage_id": stage_id}


# ============ 工作室统计（使用独立前缀，但集中在此处组织） ============

studio_router = APIRouter(prefix="/api/studio", tags=["studio"])


@studio_router.get("/stats")
async def api_studio_stats(request: Request):
    """工作室统计卡片数据"""
    user = require_current_user(request)
    pipelines = list_pipelines_for_user(
        str(user["id"]),
        tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
    )
    total = len(pipelines)
    running_statuses = {"running", "running_auto", "waiting_human", "waiting_for_resumes", "waiting_for_videos"}
    running = sum(1 for p in pipelines if p.get("status") in running_statuses)
    completed = sum(1 for p in pipelines if p.get("status") == "completed")
    # 总候选人数
    total_candidates = 0
    for p in pipelines:
        cands = get_candidates(p["id"])
        total_candidates += len(cands)
    return {
        "total_pipelines": total,
        "running_pipelines": running,
        "completed_pipelines": completed,
        "total_candidates": total_candidates,
    }


# ============ JD 路由（位于 /api/jd 前缀下） ============

jd_router = APIRouter(
    prefix="/api/jd",
    tags=["jd"],
    dependencies=[Depends(require_pipeline_path_access)],
)


@jd_router.post("/edit")
async def api_edit_jd(req: JDEditRequest, request: Request):
    """保存结构化 JD 草稿，不提前确认阶段。"""
    pipeline = require_pipeline_access(request, req.pipeline_id)

    try:
        output = jd_workspace.save_draft(
            req.pipeline_id,
            req.jd,
            expected_revision=req.expected_revision,
            source=req.source,
        )
    except jd_workspace.RevisionConflictError as error:
        raise HTTPException(409, {"message": "JD已被更新，请刷新后重试", "current_revision": error.current_revision})
    except jd_workspace.JdLockedError as error:
        raise HTTPException(
            423,
            {
                "message": str(error),
                "locked_at": error.locked_at,
                "locked_by_stage": error.locked_by_stage,
            },
        )
    except (LookupError, ValueError) as error:
        raise HTTPException(400, str(error))

    saved_jd = output["jd"]
    get_memory(req.pipeline_id).record_jd_feedback(pipeline["role"], "manual_edit", saved_jd)
    save_message(
        req.pipeline_id,
        "system",
        "HR修改了JD",
        card_type="jd_edited",
        card_data=saved_jd,
        stage_id="jd_write",
    )

    return {
        "status": "saved",
        "learned": True,
        "revision": output["revision"],
        "approval_status": output["approval_status"],
        "quality_checks": jd_workspace.quality_checks(saved_jd),
        "workflow": jd_workspace.workflow(
            get_stages(req.pipeline_id), output, enabled_agents=jd_workspace.configured_agents(pipeline)
        ),
    }


@jd_router.get("/{pipeline_id}/workspace")
async def api_get_jd_workspace(pipeline_id: str):
    try:
        return jd_workspace.workspace(pipeline_id)
    except LookupError as error:
        raise HTTPException(404, str(error))


@jd_router.post("/{pipeline_id}/generate")
async def api_generate_jd_draft(pipeline_id: str, req: JDGenerateRequest):
    request_started = time.perf_counter()
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")
    if pipeline.get("jd_locked_at"):
        raise HTTPException(
            423,
            {
                "message": "JD已锁定，请新建岗位后修改",
                "locked_at": pipeline["jd_locked_at"],
                "locked_by_stage": pipeline.get("jd_locked_by_stage", ""),
            },
        )
    pipeline_context = pipeline.get("context") or {}
    if isinstance(pipeline_context, str):
        try:
            pipeline_context = json.loads(pipeline_context)
        except (json.JSONDecodeError, TypeError):
            pipeline_context = {}
    if not isinstance(pipeline_context, dict):
        pipeline_context = {}
    pipeline_hints = str(pipeline_context.get("user_hints") or "").strip()
    pipeline_location = str(pipeline_context.get("location") or "").strip()
    stages = get_stages(pipeline_id)
    jd_stage = next((stage for stage in stages if stage["stage_id"] == "jd_write"), None)
    if jd_stage and jd_stage.get("status") == "running":
        raise HTTPException(
            409,
            detail={"code": "jd_generation_in_progress", "message": "JD正在生成，请稍候"},
        )
    if not jd_stage:
        create_stage(pipeline_id, "jd_write", "JD撰写")
    source = "auto_entry" if req.source == "auto_entry" else "generated"
    current = jd_workspace.workspace(pipeline_id)
    if req.expected_revision is not None and req.expected_revision != current["revision"]:
        raise HTTPException(
            409,
            {"message": "JD已被更新，请刷新后重试", "current_revision": current["revision"]},
        )

    if source == "auto_entry" and current["jd"]:
        return {
            "status": "existing",
            "jd": current["jd"],
            "revision": current["revision"],
            "quality_checks": current["quality_checks"],
            "workflow": current["workflow"],
            "reply": "当前已有 JD 草稿。",
        }

    update_stage(pipeline_id, "jd_write", "running")

    if source != "auto_entry":
        save_message(pipeline_id, "user", req.message, stage_id="jd_write")

    from hr_harness.agents.jd_agent import JDAgent
    from hr_harness.tool_protocol import ToolInput

    memory_started = time.perf_counter()
    memory = MemorySystem(pipeline_id)
    memory_ms = int((time.perf_counter() - memory_started) * 1000)
    deadline = TimeoutDeadline(get_agent_timeout("jd_write"), agent_id="jd_write")
    generation_hints = req.message
    location_hint = ""
    if source == "auto_entry":
        generation_hints = pipeline_hints or req.message
        location_hint = pipeline_location
    context_started = time.perf_counter()
    jd_context = build_xiao_wen_context(
        pipeline_id=pipeline_id,
        role=pipeline.get("role") or "未知岗位",
        pipeline_type=pipeline.get("type", "general"),
        user_hints=generation_hints,
        location_hint=location_hint,
        quiz_answers=pipeline_context.get("quiz_answers", []),
        memory_context=memory.build_system_context(),
    )
    context_ms = int((time.perf_counter() - context_started) * 1000)
    jd_context = attach_agent_runtime_config(jd_context, "jd_write")
    agent_started = time.perf_counter()
    try:
        result = await JDAgent().run_with_deadline(
            ToolInput(
                pipeline_id=pipeline_id,
                params=jd_context,
            ),
            deadline,
        )
    except BusinessTimeoutError:
        update_stage(pipeline_id, "jd_write", "failed", {"error": "backend_timeout"})
        raise
    except Exception as error:
        update_stage(pipeline_id, "jd_write", "failed", {"error": str(error)[:500]})
        raise HTTPException(502, f"JD生成失败，请重试：{str(error)[:100]}") from error
    agent_ms = int((time.perf_counter() - agent_started) * 1000)
    logging.getLogger("app.pipelines").info(
        "Xiao Wen JD timing",
        extra={
            "source": "XiaoWen",
            "pipeline_id": pipeline_id,
            "model": jd_context.get("model", ""),
            "memory_ms": memory_ms,
            "context_ms": context_ms,
            "agent_ms": agent_ms,
            "total_ms": int((time.perf_counter() - request_started) * 1000),
            "retries": jd_context.get("llm_max_retries", 0),
        },
    )
    generated_jd = result.data.get("jd") if isinstance(result.data, dict) else None
    generation_error = result.error or (generated_jd.get("error") if isinstance(generated_jd, dict) else None)
    if result.status.value != "success" or not jd_workspace.is_valid_jd(generated_jd):
        error_message = str(generation_error or "JD生成失败")
        update_stage(pipeline_id, "jd_write", "failed", {"error": error_message[:500]})
        raise HTTPException(502, error_message)

    try:
        output = jd_workspace.save_draft(
            pipeline_id,
            result.data["jd"],
            expected_revision=current["revision"],
            source=source,
        )
    except jd_workspace.RevisionConflictError as error:
        raise HTTPException(
            409,
            {"message": "JD已被更新，本次生成结果未覆盖新版本", "current_revision": error.current_revision},
        )
    except jd_workspace.JdLockedError as error:
        raise HTTPException(
            423,
            {
                "message": str(error),
                "locked_at": error.locked_at,
                "locked_by_stage": error.locked_by_stage,
            },
        )
    save_message(
        pipeline_id,
        "assistant",
        "JD初稿已生成，等待确认",
        card_type="jd_card",
        card_data={"jd": output["jd"]},
        stage_id="jd_write",
    )
    return {
        "status": "draft",
        "jd": output["jd"],
        "revision": output["revision"],
        "quality_checks": jd_workspace.quality_checks(output["jd"]),
        "workflow": jd_workspace.workflow(
            get_stages(pipeline_id), output, enabled_agents=jd_workspace.configured_agents(pipeline)
        ),
        "reply": f"已为「{pipeline.get('role') or '该岗位'}」生成初稿。你可以继续告诉我如何调整。",
    }


@jd_router.post("/{pipeline_id}/revise-preview")
async def api_preview_jd_revision(pipeline_id: str, req: JDRevisionRequest):
    try:
        current = jd_workspace.workspace(pipeline_id)
    except LookupError as error:
        raise HTTPException(404, str(error))
    if current.get("jd_locked"):
        raise HTTPException(
            423,
            {
                "message": "JD已锁定，请新建岗位后修改",
                "locked_at": current.get("jd_locked_at", ""),
                "locked_by_stage": current.get("jd_locked_by_stage", ""),
            },
        )
    if req.expected_revision is not None and req.expected_revision != current["revision"]:
        raise HTTPException(
            409,
            {"message": "JD已被更新，请刷新后重试", "current_revision": current["revision"]},
        )

    save_message(pipeline_id, "user", req.instruction, stage_id="jd_write")
    result = await state.get_action_handler().preview_jd_edit(pipeline_id, req.instruction)
    if result.get("error"):
        raise HTTPException(502, result["error"])
    if result.get("status") == "no_op":
        save_message(
            pipeline_id,
            "assistant",
            result.get("message", "没有检测到可修改的JD字段"),
            stage_id="jd_write",
        )
        return {
            "status": "no_op",
            "jd": result.get("jd", current["jd"]),
            "changed_fields": [],
            "no_op_reason": result.get("no_op_reason", "unclear"),
            "message": result.get(
                "message",
                "我明白你想继续调整这份 JD，不过还不确定你想改哪部分。",
            ),
        }
    save_message(
        pipeline_id,
        "assistant",
        "修改建议已生成，确认后才会覆盖当前草稿",
        card_type="jd_revision_preview",
        card_data={"changed_fields": result.get("changed_fields") or []},
        stage_id="jd_write",
    )
    return {
        "status": result.get("status", "preview"),
        "jd": result["jd"],
        "changed_fields": result.get("changed_fields") or [],
    }


@jd_router.post("/{pipeline_id}/approve")
async def api_approve_jd(pipeline_id: str, req: JDApproveRequest):
    try:
        output = jd_workspace.approve_draft(pipeline_id, expected_revision=req.expected_revision)
    except jd_workspace.RevisionConflictError as error:
        raise HTTPException(409, {"message": "JD已被更新，请刷新后重试", "current_revision": error.current_revision})
    except jd_workspace.JdLockedError as error:
        raise HTTPException(
            423,
            {
                "message": str(error),
                "locked_at": error.locked_at,
                "locked_by_stage": error.locked_by_stage,
            },
        )
    except LookupError as error:
        raise HTTPException(404, str(error))
    except ValueError as error:
        raise HTTPException(400, str(error))

    pipeline = get_pipeline(pipeline_id) or {}

    save_message(
        pipeline_id,
        "system",
        "JD 已确认",
        card_type="info_card",
        card_data={},
        stage_id="jd_write",
    )
    return {
        "status": "approved",
        "revision": output["revision"],
        "approved_revision": output["approved_revision"],
        "approval_status": output["approval_status"],
        "workflow": jd_workspace.workflow(
            get_stages(pipeline_id), output, enabled_agents=jd_workspace.configured_agents(pipeline)
        ),
    }


@jd_router.post("/{pipeline_id}/clone")
async def api_clone_jd_pipeline(pipeline_id: str, request: Request):
    """Clone a locked pipeline into a new editable JD workspace."""
    source_pipeline = require_pipeline_access(request, pipeline_id)
    if not source_pipeline.get("jd_locked_at"):
        raise HTTPException(409, "请先将JD传递给下游Agent后再复制岗位")

    source_workspace = jd_workspace.workspace(pipeline_id)
    if not source_workspace.get("jd"):
        raise HTTPException(400, "当前岗位没有可复制的JD")

    new_pipeline_id = f"p_{uuid4().hex[:8]}"
    db_create_pipeline(
        new_pipeline_id,
        source_pipeline.get("role") or "未命名岗位",
        pipeline_type=source_pipeline.get("type") or "tech",
        enabled_agents=source_pipeline.get("enabled_agents") or [],
        owner_user_id=source_pipeline.get("owner_user_id") or "",
        tenant_id=source_pipeline.get("tenant_id") or "tenant_default",
    )
    try:
        context = source_pipeline.get("context") or {}
        if isinstance(context, str):
            try:
                context = json.loads(context)
            except (TypeError, json.JSONDecodeError):
                context = {}
        if not isinstance(context, dict):
            context = {}
        update_pipeline(new_pipeline_id, "pending", context)

        conn = get_db()
        conn.execute(
            """UPDATE pipelines
               SET agents=%s, screen_template_id=%s, auto_pass=%s, import_mode=%s, tts_urls=%s,
                   cloned_from_pipeline_id=%s
               WHERE id=%s""",
            (
                source_pipeline.get("agents") or "",
                source_pipeline.get("screen_template_id") or "",
                source_pipeline.get("auto_pass") or "",
                source_pipeline.get("import_mode") or "full",
                source_pipeline.get("tts_urls") or "",
                pipeline_id,
                new_pipeline_id,
            ),
        )
        conn.commit()

        create_stage(new_pipeline_id, "jd_write", "JD撰写")
        draft = jd_workspace.save_draft(
            new_pipeline_id,
            source_workspace["jd"],
            expected_revision=0,
            source="cloned",
        )
    except jd_workspace.JdLockedError as error:
        delete_pipeline(new_pipeline_id)
        raise HTTPException(423, str(error)) from error
    except Exception:
        delete_pipeline(new_pipeline_id)
        raise

    from app.audit.audit_trail import audit

    try:
        audit(
            "pipeline.jd_cloned",
            f"复制岗位: {source_pipeline.get('role') or '未命名岗位'}",
            entity_type="pipeline",
            entity_id=new_pipeline_id,
            details={"source_pipeline_id": pipeline_id},
        )
    except Exception:
        delete_pipeline(new_pipeline_id)
        raise
    return {
        "status": "cloned",
        "pipeline_id": new_pipeline_id,
        "source_pipeline_id": pipeline_id,
        "role": source_pipeline.get("role") or "未命名岗位",
        "revision": draft["revision"],
        "approval_status": draft["approval_status"],
        "jd_locked": False,
    }


@jd_router.get("/{pipeline_id}/copy")
async def api_copy_jd(pipeline_id: str):
    """Get JD as formatted text for copying to platforms"""
    stages = get_stages(pipeline_id)
    jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
    if not jd_stage:
        raise HTTPException(404, "JD not found")

    output = parse_stage_output(jd_stage)
    jd = output.get("jd", {})

    # 格式化为可复制文本
    lines = []
    lines.append(f"【{jd.get('title', '')}】")
    lines.append(f"部门：{jd.get('department', '')}")
    lines.append(f"地点：{jd.get('location', '')}")
    lines.append(f"薪资：{jd.get('salary_range', '')}")
    lines.append("")
    lines.append("岗位职责：")
    for i, r in enumerate(jd.get("responsibilities", []), 1):
        lines.append(f"{i}. {r}")
    lines.append("")
    lines.append("任职要求：")
    for i, r in enumerate(jd.get("requirements", []), 1):
        lines.append(f"{i}. {r}")
    lines.append("")
    if jd.get("tech_stack"):
        lines.append(f"技术栈：{'、'.join(jd['tech_stack'])}")
        lines.append("")
    if jd.get("benefits"):
        lines.append("福利待遇：")
        for b in jd["benefits"]:
            lines.append(f"• {b}")
    if jd.get("team_intro"):
        lines.append("")
        lines.append(f"团队介绍：{jd['team_intro']}")

    return {"text": "\n".join(lines), "jd": jd}


# ==========================================================================
# 简历解析辅助函数（仅供 parse-resumes 路由使用）
# ==========================================================================


# ==========================================================================
# 简历解析辅助函数（仅供 parse-resumes 路由使用）
# ==========================================================================


def _parse_pdf_file(fpath: str) -> tuple:
    return _resume_parser.parse_pdf_file(fpath, ocr_func=_try_ocr_pdf)


def _try_ocr_pdf(fpath: str) -> str:
    return _resume_parser.try_ocr_pdf(fpath)


def _read_text_file(fpath: str) -> str:
    return _resume_parser.read_text_file(fpath)


def _extract_resume_rules(text: str, filename: str) -> dict:
    return _resume_parser.extract_resume_rules(text, filename)
