"""Pure data helpers shared by pipeline processing services.

These functions intentionally have no database, network, or application-state
dependencies so their merge and parsing behavior can be tested independently.
"""

import hashlib
import json
import re


def parse_stage_output(stage_row):
    """Safely parse a stage output into a dictionary."""
    if not stage_row:
        return {}
    raw = stage_row.get("output")
    if not raw:
        return {}
    try:
        if isinstance(raw, str):
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        if isinstance(raw, dict):
            return raw
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return {}


def candidate_id(item: dict) -> str:
    return str(item.get("id") or item.get("candidate_id") or "")


def merge_match_output(existing_output: dict, new_result: dict, batch_id: str) -> dict:
    """Merge one match batch without dropping older candidates or review state."""
    existing = dict(existing_output or {})
    merged = dict(existing)
    old_candidates = existing.get("candidates") if isinstance(existing.get("candidates"), list) else []
    new_candidates = new_result.get("candidates") if isinstance(new_result.get("candidates"), list) else []
    by_id = {candidate_id(item): item for item in old_candidates if candidate_id(item)}
    for item in new_candidates:
        if candidate_id(item):
            by_id[candidate_id(item)] = item
    merged.update({key: value for key, value in new_result.items() if key != "candidates"})
    merged["candidates"] = list(by_id.values())
    thresholds = dict(new_result.get("thresholds") or {})
    batch_thresholds = dict(existing.get("batch_thresholds") or {})
    batch_thresholds[batch_id] = thresholds
    merged["batch_thresholds"] = batch_thresholds
    if existing.get("workflow_status") in {"review_pending", "confirmed"}:
        merged["workflow_status"] = existing["workflow_status"]
        for key in (
            "config",
            "input_signature",
            "version",
            "versions",
            "manual_adjustments",
            "created_at",
            "confirmed_at",
            "shortlisted",
            "rejected",
            "counts",
        ):
            if key in existing:
                merged[key] = existing[key]
    return merged


def merge_interview_output(existing_output: dict, generated_output: dict) -> dict:
    """Merge generated interviews without replacing unaffected drafts."""
    merged = dict(existing_output or {})
    existing_interviews = merged.get("interviews") if isinstance(merged.get("interviews"), list) else []
    generated_interviews = (
        generated_output.get("interviews") if isinstance(generated_output.get("interviews"), list) else []
    )
    by_candidate = {
        str(item.get("candidate_id")): item
        for item in existing_interviews
        if isinstance(item, dict) and item.get("candidate_id")
    }
    unkeyed = [item for item in existing_interviews if not isinstance(item, dict) or not item.get("candidate_id")]
    for item in generated_interviews:
        if isinstance(item, dict) and item.get("candidate_id"):
            by_candidate[str(item["candidate_id"])] = item
        else:
            unkeyed.append(item)
    merged.update({key: value for key, value in generated_output.items() if key != "interviews"})
    merged["interviews"] = [*by_candidate.values(), *unkeyed]
    merged["generated_candidate_count"] = len(generated_interviews)
    return merged


def parse_json_field(session: dict, field: str, default=None):
    """Parse a JSON-backed session field while preserving legacy fallback semantics."""
    fallback = default if default is not None else []
    value = session.get(field)
    if value is None:
        return fallback
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return fallback if parsed is None else parsed
        except (json.JSONDecodeError, TypeError):
            return fallback
    return value


def safe_oss_segment(value: str) -> str:
    """Normalize an identifier for use as a bounded OSS object-key segment."""
    cleaned = re.sub(r"[^A-Za-z0-9_.-]", "_", str(value)).strip("._")
    return cleaned[:100] or hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:20]


def parse_json_list(value) -> list:
    """Parse a value as a list while rejecting non-list JSON values."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else []
        except (json.JSONDecodeError, TypeError):
            return []
    return []


def public_question_payload(questions: list, allowed_fields) -> list[dict]:
    """Keep only candidate-facing fields from question dictionaries."""
    return [
        {key: value for key, value in question.items() if key in allowed_fields}
        for question in questions
        if isinstance(question, dict)
    ]


def normalize_lease_client_id(client_id: str | None) -> str:
    """Normalize the bounded client identifier used for interview leases."""
    return str(client_id or "").strip()[:128]


def scored_video_answer(
    question_index: int,
    question: dict,
    transcript: str,
    score_result: dict,
    primary_dim: str,
    audio_features: dict,
) -> dict:
    """Preserve per-question video scoring evidence for reports and final scoring."""
    return {
        "question_index": question_index,
        "question": question.get("question", ""),
        "answer": transcript,
        "answer_type": "video",
        "score": score_result.get("score"),
        "level": score_result.get("level", "average"),
        "primary_dim_score": score_result.get("primary_dim_score", score_result.get("score")),
        "primary_dim": score_result.get("primary_dim", primary_dim),
        "hit_points": score_result.get("hit_points", []),
        "missed_points": score_result.get("missed_points", []),
        "comment": score_result.get("comment", ""),
        "candidate_feedback": score_result.get("candidate_feedback", ""),
        "red_flag": score_result.get("red_flag", False),
        "red_flag_reason": score_result.get("red_flag_reason", ""),
        "red_flags": score_result.get("red_flags", []),
        "risk_signals": score_result.get("risk_signals", []),
        "criteria": score_result.get("criteria", []),
        "scoring_confidence": score_result.get("scoring_confidence", 0),
        "rubric_version": score_result.get("rubric_version", ""),
        "audio_features": audio_features,
        "should_follow_up": False,
        "scoring_failed": score_result.get("scoring_failed", False),
        "asr_failed": score_result.get("asr_failed", False),
        "technical_failure": score_result.get("technical_failure", False),
        "failure_reason": score_result.get("failure_reason", ""),
    }


def generate_match_summary(match_result: dict, role: str) -> dict:
    """生成匹配结果丰富总结卡片数据"""
    candidates = match_result.get("candidates", [])
    shortlisted = match_result.get("shortlisted", [])
    rejected = match_result.get("rejected", match_result.get("eliminated", []))
    weights = match_result.get("weights", {})
    thresholds = match_result.get("thresholds", {})

    if not candidates:
        return None

    ranked = sorted(candidates, key=lambda c: c.get("overall_score", 0), reverse=True)

    # 分数统计
    scores = [c.get("overall_score", 0) for c in ranked]
    avg_score = round(sum(scores) / len(scores)) if scores else 0
    max_score = max(scores) if scores else 0
    min_score = min(scores) if scores else 0
    median_score = sorted(scores)[len(scores) // 2] if scores else 0

    # 分数段分布: [0-40, 40-60, 60-80, 80-100]
    distribution = [
        {"range": "0-40", "label": "不匹配", "count": sum(1 for s in scores if s < 40)},
        {"range": "40-60", "label": "待提升", "count": sum(1 for s in scores if 40 <= s < 60)},
        {"range": "60-80", "label": "基本匹配", "count": sum(1 for s in scores if 60 <= s < 80)},
        {"range": "80-100", "label": "优秀", "count": sum(1 for s in scores if s >= 80)},
    ]

    # 六维名称映射
    dim_labels = {
        "tech_score": "技术匹配",
        "experience_score": "经验匹配",
        "education_score": "学历背景",
        "major_match_score": "专业匹配",
        "culture_score": "文化匹配",
        "salary_risk": "薪资风险",
    }

    # 每位候选人的详细数据（含六维分数）
    ranking = []
    for c in ranked:
        dims = {}
        for dim_key, dim_label in dim_labels.items():
            dims[dim_key] = {
                "score": c.get(dim_key, 0),
                "label": dim_label,
            }
        ranking.append(
            {
                "name": c.get("name", "未知"),
                "score": c.get("overall_score", 0),
                "status": "shortlisted" if c in shortlisted else ("eliminated" if c in rejected else "pending"),
                "reason": c.get("reason", ""),
                "dimensions": dims,
                "company": c.get("current_company", ""),
                "years": c.get("years_experience", 0),
                "red_flags": c.get("red_flags", []),
            }
        )

    # 六维对比数据（雷达图用）
    radar_data = []
    for c in ranked[:5]:
        radar_data.append(
            {
                "name": c.get("name", ""),
                "values": [c.get(k, 0) for k in dim_labels.keys()],
            }
        )

    # 各维度平均分
    dim_averages = {}
    for dim_key, dim_label in dim_labels.items():
        vals = [c.get(dim_key, 0) for c in candidates]
        dim_averages[dim_key] = {
            "label": dim_label,
            "average": round(sum(vals) / len(vals)) if vals else 0,
            "max": max(vals) if vals else 0,
            "min": min(vals) if vals else 0,
        }

    # 权重信息
    weight_info = []
    for k, v in weights.items():
        weight_info.append(
            {
                "dimension": dim_labels.get(k, k),
                "weight": round(v * 100) if isinstance(v, float) and v <= 1 else round(v),
            }
        )
    weight_info.sort(key=lambda x: x["weight"], reverse=True)

    # 关键洞察
    insights = []
    shortlisted_count = len(shortlisted)
    total = len(candidates)
    pass_rate = round(shortlisted_count / total * 100) if total else 0

    if pass_rate >= 60:
        insights.append({"icon": "🎯", "text": f"候选人整体质量较高，入围率 {pass_rate}%"})
    elif pass_rate >= 30:
        insights.append({"icon": "⚖️", "text": f"候选人质量中等，入围率 {pass_rate}%，建议扩大渠道"})
    else:
        insights.append({"icon": "⚠️", "text": f"候选人整体偏弱，入围率仅 {pass_rate}%，建议优化 JD 或渠道"})

    if max_score - min_score >= 30:
        insights.append({"icon": "📊", "text": f"分数极差 {max_score - min_score} 分，候选人差异化明显"})

    # 找出最强维度与最弱维度
    if dim_averages:
        best_dim = max(dim_averages.items(), key=lambda x: x[1]["average"])
        worst_dim = min(dim_averages.items(), key=lambda x: x[1]["average"])
        insights.append({"icon": "💪", "text": f"最强维度：{best_dim[1]['label']}（均分 {best_dim[1]['average']}）"})
        insights.append({"icon": "🔍", "text": f"最弱维度：{worst_dim[1]['label']}（均分 {worst_dim[1]['average']}）"})

    summary_text = (
        f"📊 **匹配总结**\n"
        f"共评估 {total} 人，入围 {shortlisted_count} 人，淘汰 {len(rejected)} 人\n\n"
        f"**候选人排名：**\n"
    )
    for idx, c in enumerate(ranking[:5], 1):
        emoji = "🟢" if c["status"] == "shortlisted" else "🔴" if c["status"] == "eliminated" else "⚪"
        summary_text += f"{emoji} {idx}. {c['name']} — {c['score']}分\n"

    return {
        "text": summary_text,
        "data": {
            "role": role,
            "total": total,
            "shortlisted_count": shortlisted_count,
            "eliminated_count": len(rejected),
            "avg_score": avg_score,
            "max_score": max_score,
            "min_score": min_score,
            "median_score": median_score,
            "pass_rate": pass_rate,
            "ranking": ranking,
            "radar_data": radar_data,
            "radar_indicators": list(dim_labels.keys()),
            "distribution": distribution,
            "dim_averages": dim_averages,
            "weights": weight_info,
            "insights": insights,
            "thresholds": {
                "shortlist_min": thresholds.get("shortlist_min", 70),
                "reject_below": thresholds.get("reject_below", 50),
            },
            "timing": match_result.get("timing", {}),
        },
    }


def parse_years(exp) -> int:
    """Extract years of experience from common scalar formats."""
    if isinstance(exp, (int, float)):
        return int(exp)
    match = re.search(r"(\d+)", str(exp))
    return int(match.group(1)) if match else 0


def split_resume_text(text: str) -> list:
    """Split pasted text into individual resume chunks."""
    chunks = re.split(r"(?:={3,}|-{3,}|\*{3,}|简历\s*\d+)", text)
    chunks = [chunk.strip() for chunk in chunks if chunk.strip() and len(chunk.strip()) > 20]
    if len(chunks) <= 1:
        return [text]
    return chunks
