"""Pure grouping and growth-trend helpers for talent-pool analytics."""

from datetime import date, datetime, timedelta


def gender_bucket(value: str | None) -> str:
    text = (value or "").strip().lower()
    if text in ("男", "m", "male"):
        return "男"
    if text in ("女", "f", "female"):
        return "女"
    if not text:
        return "未填写"
    return "其他"


def education_bucket(value: str | None) -> str:
    text = (value or "").strip().lower()
    if not text:
        return "未填写"
    if "博士" in text or "phd" in text or "doctor" in text:
        return "博士"
    if "硕士" in text or "master" in text:
        return "硕士"
    if "本科" in text or "bachelor" in text or "学士" in text:
        return "本科"
    if "大专" in text or "专科" in text or "associate" in text:
        return "大专"
    if "高中" in text or "中专" in text or "职高" in text or "技校" in text or "high school" in text:
        return "高中"
    return "其他"


def years_bucket(value: int | None) -> str:
    if value is None:
        return "未填写"
    try:
        years = int(value)
    except (TypeError, ValueError):
        return "未填写"
    if years < 0:
        return "未填写"
    if years < 1:
        return "应届/0-1年"
    if years < 3:
        return "1-3年"
    if years < 5:
        return "3-5年"
    if years < 10:
        return "5-10年"
    return "10年以上"


def rank_items(counter: dict[str, int], top_n: int) -> list[dict]:
    """Sort grouped counts descending and fold the tail into 「其他」."""
    ordered = sorted(counter.items(), key=lambda item: (-item[1], item[0]))
    if len(ordered) <= top_n:
        return [{"name": name, "value": count} for name, count in ordered]
    head = ordered[: top_n - 1]
    tail = sum(count for _, count in ordered[top_n - 1 :])
    return [{"name": name, "value": count} for name, count in head] + [{"name": "其他", "value": tail}]


def _as_date(value) -> date:
    if value is None:
        return datetime.now().date()
    if isinstance(value, datetime):
        return value.date()
    return value


def talent_pool_growth_window(days: int, today=None) -> tuple[date, date]:
    """Return (window_start, pre_start) for the daily growth buckets.

    ``pre_start`` is the day before the window so the first visible day has a
    real period-over-period rate.
    """
    anchor = _as_date(today)
    window_start = anchor - timedelta(days=days - 1)
    return window_start, window_start - timedelta(days=1)


def talent_pool_growth_series(
    new_by_day: dict[str, int],
    before_count: int,
    total: int,
    days: int = 30,
    today=None,
) -> dict:
    """Build the leader-cabin growth trend from daily new-resume counts.

    ``before_count`` is the pool size accumulated before the
    window; ``total`` is the current pool size. Growth rate is
    (today's new − yesterday's new) ÷ yesterday's new, or ``None`` when
    yesterday's new is 0.
    """
    anchor = _as_date(today)
    _, pre_start = talent_pool_growth_window(days, today=anchor)

    days_axis, daily_new, cumulative_total, growth_rate = [], [], [], []
    cumulative = before_count
    recent_new = 0
    prev_axis = pre_start.strftime("%Y-%m-%d")
    for offset in range(days - 1, -1, -1):
        day = (anchor - timedelta(days=offset)).strftime("%Y-%m-%d")
        new_count = new_by_day.get(day, 0)
        prev_count = new_by_day.get(prev_axis, 0)
        cumulative += new_count
        recent_new += new_count
        days_axis.append(day)
        daily_new.append(new_count)
        cumulative_total.append(cumulative)
        growth_rate.append(round((new_count - prev_count) / prev_count, 4) if prev_count > 0 else None)
        prev_axis = day

    return {
        "days": days_axis,
        "daily_new": daily_new,
        "cumulative_total": cumulative_total,
        "growth_rate": growth_rate,
        "summary": {
            "total": total,
            "recent_new": recent_new,
            "latest_growth_rate": growth_rate[-1],
        },
    }
