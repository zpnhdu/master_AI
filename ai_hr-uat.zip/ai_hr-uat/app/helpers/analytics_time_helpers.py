"""Pure timestamp and cohort-day-axis helpers for analytics."""

from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")

STAGE_TREND_OBSERVATION_DAYS = 7


def parse_db_ts(value) -> datetime | None:
    """Parse timestamps as Asia/Shanghai-naive values for legacy SQL compares."""
    text = str(value).strip() if value else ""
    if not text:
        return None
    try:
        raw = text.replace("T", " ")
        if raw.endswith("Z"):
            parsed = datetime.fromisoformat(raw[:-1] + "+00:00")
        else:
            parsed = datetime.fromisoformat(raw)
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone(SHANGHAI_TZ).replace(tzinfo=None)
        return parsed
    except ValueError:
        return None


def stage_pass_rate_trend_window(days: int, now: datetime | None = None) -> date:
    """Return the first cohort day for the stage pass-rate trend."""
    anchor = now or datetime.now()
    return (anchor - timedelta(days=days - 1)).date()


def stage_pass_rate_trend_series(
    cohorts: dict[str, set[str]],
    screened_events: dict[str, datetime],
    participated_events: dict[str, datetime],
    passed_events: dict[str, datetime],
    days: int = 30,
    now: datetime | None = None,
    observation_days: int = STAGE_TREND_OBSERVATION_DAYS,
) -> dict:
    """Build the daily cohort pass-rate series for the leader cabin trend.

    A cohort day's rates are only reported once its observation window has
    fully elapsed; recent or empty cohorts return ``None`` so incomplete
    windows are not misread as low-performing cohorts.
    """
    anchor = now or datetime.now()
    days_axis = []
    screening_pass_rate = []
    interview_pass_rate = []
    for offset in range(days - 1, -1, -1):
        cohort_date = (anchor - timedelta(days=offset)).date()
        cohort_day = cohort_date.strftime("%Y-%m-%d")
        days_axis.append(cohort_day)
        identities = cohorts.get(cohort_day, set())
        if (anchor.date() - cohort_date).days < observation_days or not identities:
            screening_pass_rate.append(None)
            interview_pass_rate.append(None)
            continue
        window_end = datetime.combine(cohort_date + timedelta(days=observation_days), datetime.max.time())
        screened = {
            identity
            for identity in identities
            if identity in screened_events and screened_events[identity] <= window_end
        }
        participated = {
            identity
            for identity in identities
            if identity in participated_events and participated_events[identity] <= window_end
        }
        interviewed = {
            identity for identity in identities if identity in passed_events and passed_events[identity] <= window_end
        }
        screening_pass_rate.append(round(len(screened) / len(identities), 4))
        interview_pass_rate.append(round(len(interviewed) / len(participated), 4) if participated else None)

    return {
        "days": days_axis,
        "screening_pass_rate": screening_pass_rate,
        "interview_pass_rate": interview_pass_rate,
        "observation_window_days": observation_days,
        "cohort_basis": "resume_created_at_or_candidate_created_at",
    }
