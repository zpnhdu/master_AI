"""纯函数 helper 领域包（目录整理 R1）。

原 `app/analytics_time_helpers.py`、`app/talent_pool_helpers.py`、
`app/role_overview_helpers.py`、`app/service_helpers.py` 四个顶层模块
按 `docs/directory-reorganization-plan.md` 归入本包，实现原样保留。

旧导入路径 `from app.service_helpers import X`、`from app import
service_helpers`、`import app.service_helpers` 通过下方 sys.modules
别名注册保持兼容；`app.X.attr` 属性访问同样解析到包内模块。
"""

import importlib
import sys

_MODULES = (
    "analytics_time_helpers",
    "role_overview_helpers",
    "service_helpers",
    "talent_pool_helpers",
)

for _name in _MODULES:
    _mod = importlib.import_module(f"app.helpers.{_name}")
    # app.X 旧路径别名：指向同一模块对象，monkeypatch / 属性访问语义不变
    sys.modules.setdefault(f"app.{_name}", _mod)
    setattr(sys.modules[__name__], _name, _mod)

import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    # 同步注册到 app 包属性上，from app import X 与 app.X.y 均可解析
    setattr(_app_pkg, _name, getattr(sys.modules[__name__], _name))

__all__ = list(_MODULES)
