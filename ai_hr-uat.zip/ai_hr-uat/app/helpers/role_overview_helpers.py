"""Pure aggregation helpers for role overview analytics."""

import json


def normalize_role_name(value: str | None) -> str:
    """Normalize role names for duplicate checks and overview grouping."""
    return str(value or "").replace("\u3000", " ").strip()


def numeric_score(value) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def interview_candidate_key(record: dict, fallback: str) -> str:
    return str(record.get("candidate_id") or record.get("candidate_name") or fallback)


def record_passes_interview(
    record: dict,
    fallback: str,
    completed: bool = False,
    threshold: float = 60,
) -> tuple[str, bool]:
    """Return a stable candidate key and whether the record passes the score threshold."""
    key = interview_candidate_key(record, fallback)
    score = None
    for field in ("overall_score", "final_score", "interview_score", "score"):
        score = numeric_score(record.get(field))
        if score is not None:
            break
    if score is not None:
        return key, score >= threshold
    return key, False


def stage_interview_records(output) -> list[dict]:
    if not isinstance(output, dict):
        return []
    records: list[dict] = []
    for field in ("assessments", "evaluations", "results", "interviews"):
        values = output.get(field)
        if isinstance(values, list):
            for item in values:
                if not isinstance(item, dict):
                    continue
                records.append(item)
                for nested_field in ("assessment", "evaluation", "result"):
                    nested = item.get(nested_field)
                    if isinstance(nested, dict):
                        records.append({**item, **nested})
    if any(output.get(field) is not None for field in ("candidate_id", "candidate_name")):
        records.append(output)
    return records


def row_value(row, key: str, index: int = 0):
    if isinstance(row, dict) or hasattr(row, "keys"):
        return row[key]
    return row[index]


def _decode_json_value(value):
    if isinstance(value, str):
        try:
            value = json.loads(value)
            if isinstance(value, str):
                value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return {}
    return value


def count_interview_passed_from_rows(
    pipeline_id: str,
    assessment_rows: list,
    stage_rows: list,
    session_rows: list,
    threshold: float = 60,
    eligible_keys: set[str] | None = None,
    alias_to_key: dict[str, str] | None = None,
) -> int:
    """Count candidates passed by the *small review* decision.

    ``assessment_candidate_states`` is the source of truth for the current flow:
    a ready package with an overall score of at least the pass threshold is a
    small-review pass.  The stage/session rows are only a compatibility fallback
    for legacy pipelines that predate the assessment-flow table.  Keeping the
    sources mutually exclusive is important; otherwise one candidate can be
    counted from a session while another is counted from a small-review package,
    which makes the numerator drift away from the small-screened cohort.
    """
    passed: set[str] = set()

    def canonical_key(record: dict, fallback: str) -> str | None:
        raw_key = interview_candidate_key(record, fallback)
        if eligible_keys is None:
            return raw_key
        aliases = alias_to_key or {}
        key = aliases.get(raw_key, raw_key)
        if key in eligible_keys:
            return key
        # Some legacy stage records carry only candidate_name while session rows
        # carry candidate_id (or vice versa).  Resolve that representation by name
        # before dropping it from the screened cohort.
        name = str(record.get("candidate_name") or record.get("name") or "").strip()
        if name:
            key = aliases.get(name)
            if key in eligible_keys:
                return key
        return None

    if assessment_rows:
        # Modern 小评数据 exists for this pipeline.  Do not supplement it with
        # legacy session/stage rows, even if those rows contain high scores.
        for row in assessment_rows:
            package = _decode_json_value(row_value(row, "package", 2))
            if not isinstance(package, dict) or package.get("queue_status") != "ready_for_decision":
                continue
            key, is_passed = record_passes_interview(
                package,
                f"assessment:{row_value(row, 'id', 0)}",
                threshold=threshold,
            )
            key = canonical_key(package, key)
            if key and is_passed:
                passed.add(key)
        return len(passed)

    for row in stage_rows:
        output = _decode_json_value(row_value(row, "output", 0))
        for index, record in enumerate(stage_interview_records(output)):
            completed = bool(record.get("answers_submitted") or record.get("status") in ("completed", "evaluated"))
            key, is_passed = record_passes_interview(
                record,
                f"stage:{pipeline_id}:{index}",
                completed=completed,
                threshold=threshold,
            )
            key = canonical_key(record, key)
            if key and is_passed:
                passed.add(key)

    for index, row in enumerate(session_rows):
        record = dict(row) if isinstance(row, dict) or hasattr(row, "keys") else {}
        status = record.get("status")
        if status not in ("completed", "evaluated"):
            continue
        key, is_passed = record_passes_interview(
            record,
            f"session:{pipeline_id}:{index}",
            completed=True,
            threshold=threshold,
        )
        key = canonical_key(record, key)
        if key and is_passed:
            passed.add(key)
    return len(passed)


def aggregate_role_overview(
    pipelines: list[dict],
    screened_map: dict[str, int],
    assessment_map: dict[str, list],
    stage_map: dict[str, list],
    session_map: dict[str, list],
    type_label,
    interview_pass_score_threshold: float = 60,
    screened_keys: dict[str, set[str]] | None = None,
    screened_aliases: dict[str, dict[str, str]] | None = None,
) -> list[dict]:
    """Group visible pipeline rows into role overview cards."""
    groups: dict[tuple[str, str], dict] = {}
    for pipeline in pipelines:
        pipeline_id = str(pipeline["id"])
        role = normalize_role_name(pipeline.get("role"))
        type_code = str(pipeline.get("type") or "general")
        screened = screened_map.get(pipeline_id, 0)
        interview_passed = count_interview_passed_from_rows(
            pipeline_id,
            assessment_map.get(pipeline_id, []),
            stage_map.get(pipeline_id, []),
            session_map.get(pipeline_id, []),
            threshold=interview_pass_score_threshold,
            eligible_keys=(screened_keys or {}).get(pipeline_id, set()),
            alias_to_key=(screened_aliases or {}).get(pipeline_id, {}),
        )
        key = (role, type_code)
        group = groups.setdefault(
            key,
            {
                "role": role,
                "type_code": type_code,
                "type_label": type_label(type_code),
                "candidate_count": 0,
                "interview_passed_count": 0,
                "pipelines": [],
            },
        )
        group["pipelines"].append(
            {
                "id": pipeline_id,
                "status": pipeline.get("status", ""),
                "screened_count": screened,
                "interview_passed_count": interview_passed,
            }
        )
        if screened > 0:
            group["candidate_count"] += screened
        group["interview_passed_count"] += interview_passed

    result = []
    for group in groups.values():
        if group["candidate_count"] <= 0:
            continue
        # The numerator is explicitly restricted to the screened cohort above;
        # retain a defensive clamp for malformed legacy data.
        group["interview_passed_count"] = min(group["interview_passed_count"], group["candidate_count"])
        group["pass_rate"] = round(group["interview_passed_count"] / group["candidate_count"], 4)
        result.append(group)
    return result
