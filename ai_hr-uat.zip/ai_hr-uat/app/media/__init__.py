"""``app/brand_assets.py``、``app/image_thumbnails.py``、``app/media_storage.py``、``app/upload_workers.py``、``app/multimodal.py``（目录整理）。

原 ``app/``app/brand_assets.py``, ``app/image_thumbnails.py``, ``app/media_storage.py``, ``app/upload_workers.py``, ``app/multimodal.py```` 按 ``docs/directory-reorganization-plan.md`` 归入本包，
实现原样保留。旧导入路径 ``from app.X import y`` / ``from app import X`` /
``import app.X`` 经 sys.modules 别名与 app 包属性注册保持兼容。
"""

import importlib
import sys

_MODULES = (
    # 顺序约束：brand_assets 顶层 import app.image_thumbnails /
    # app.media_storage，须先完成它们的旧名注册
    "image_thumbnails",
    "media_storage",
    "brand_assets",
    "upload_workers",
    "multimodal",
)

import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    _mod = importlib.import_module("app.media." + _name)
    # app.X 旧路径别名：指向同一模块对象，monkeypatch / 属性访问语义不变
    sys.modules.setdefault("app." + _name, _mod)
    setattr(sys.modules[__name__], _name, _mod)
    setattr(_app_pkg, _name, _mod)

__all__ = list(_MODULES)
