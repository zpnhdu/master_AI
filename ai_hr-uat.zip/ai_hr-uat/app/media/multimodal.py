"""Multimodal Processing — audio transcription and image analysis for HR.

Supports:
- Audio transcription: interview recordings → text (Qwen3-ASR-Flash via DashScope API)
- Image analysis: certificates, resumes, ID photos (Qwen-VL)
- Video analysis: interview videos (Qwen-VL)

Vision models available via proxy (qwen-vl-max) or DashScope SDK fallback.
Audio transcription uses DashScope /api/v1 endpoint via MaaS gateway.

Usage:
    from app.multimodal import transcribe_audio, analyze_image

    text = transcribe_audio("interview.mp3", audio_bytes)
    description = analyze_image("certificate.jpg", image_bytes)
"""

import base64
import json
import logging
import os

import requests

logger = logging.getLogger("app.multimodal")

_API_BASE = os.getenv("OPENAI_API_BASE", "https://ws-dax6bh2yg3o6dbkb.cn-beijing.maas.aliyuncs.com/compatible-mode/v1")
_API_KEY = os.getenv("OPENAI_API_KEY", "")
_DASHSCOPE_KEY = os.getenv("DASHSCOPE_API_KEY", "")

# DashScope 原生 API 地址（从兼容模式地址推导）
_DASHSCOPE_BASE = _API_BASE.replace("/compatible-mode/v1", "/api/v1")


# ── 音频转写 ────────────────────────────────────────────────


def transcribe_audio(
    filename: str,
    audio_data: bytes,
    model: str = "qwen3-asr-flash",
    language: str = "zh",
) -> str:
    """转写音频（统一打点收口入口，fallback 链见 _transcribe_audio_impl）。"""
    from app.audit.token_tracker import track_llm_call

    with track_llm_call(model, agent="multimodal", operation="transcribe_audio", call_type="audio") as _ctx:
        _ctx.success = False
        result = _transcribe_audio_impl(filename, audio_data, model, language)
        if result and not result.startswith("["):
            _ctx.success = True
            _ctx.usage = {"prompt_tokens": 0, "completion_tokens": len(result), "total_tokens": len(result)}
    return result


def _transcribe_audio_impl(
    filename: str,
    audio_data: bytes,
    model: str = "qwen3-asr-flash",
    language: str = "zh",
) -> str:
    """
    Transcribe audio file to text.

    Tries multiple methods in order, with detailed error logging.
    Falls back through different model names and API formats.

    Args:
        filename: Original filename (for format detection)
        audio_data: Raw audio bytes
        model: Preferred transcription model
        language: Language hint (zh, en)

    Returns:
        Transcribed text, or error message starting with "[转录失败:"
    """
    errors = []

    # 方式 0：专用 Qwen ASR 模型与 OpenAI 兼容的 input_audio 格式
    result = _transcribe_via_qwen_asr(filename, audio_data)
    if result and not result.startswith("["):
        return result
    if result:
        errors.append(f"qwen-asr: {result}")

    # 模型降级链：首选模型 → paraformer → whisper-1
    models_to_try = [model]
    if model != "paraformer-v2":
        models_to_try.append("paraformer-v2")
    if "whisper-1" not in models_to_try:
        models_to_try.append("whisper-1")

    for try_model in models_to_try:
        # 方式 1：向兼容模式接口发送 multipart form-data（兼容性最好）
        result = _transcribe_via_proxy(filename, audio_data, try_model)
        if result and not result.startswith("["):
            return result
        if result:
            errors.append(f"{try_model}/proxy: {result}")

        # 方式 2：向 DashScope 基础地址发送 multipart form-data
        result = _transcribe_via_dashscope_form(filename, audio_data, try_model)
        if result and not result.startswith("["):
            return result
        if result:
            errors.append(f"{try_model}/ds-form: {result}")

        # 方式 3：通过 DashScope JSON API 发送 base64 数据
        result = _transcribe_via_dashscope_http(filename, audio_data, try_model)
        if result and not result.startswith("["):
            return result
        if result:
            errors.append(f"{try_model}/ds-json: {result}")

    # 方式 4：使用 DashScope SDK（最后手段，需要文件上传支持）
    result = _transcribe_via_dashscope(filename, audio_data, model, language)
    if result and not result.startswith("["):
        return result
    if result:
        errors.append(f"{model}/sdk: {result}")

    # 所有方式均失败时返回详细错误
    error_detail = "; ".join(errors) if errors else "所有转录方法均失败"
    logger.error(f"ASR all methods failed: {error_detail}", extra={"source": "multimodal"})
    return f"[转录失败: {error_detail}]"


def _transcribe_via_qwen_asr(filename: str, audio_data: bytes) -> str:
    """通过 Qwen3-ASR-Flash 专用语音识别模型转写音频。"""
    audio_b64 = base64.b64encode(audio_data).decode("ascii")
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "webm"
    mime = {
        "webm": "audio/webm",
        "wav": "audio/wav",
        "mp3": "audio/mpeg",
        "m4a": "audio/mp4",
        "ogg": "audio/ogg",
    }.get(ext, "audio/webm")
    payload = {
        "model": "qwen3-asr-flash",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_audio",
                        "input_audio": {"data": f"data:{mime};base64,{audio_b64}"},
                    }
                ],
            }
        ],
    }
    try:
        response = requests.post(
            f"{_API_BASE}/chat/completions",
            headers={
                "Authorization": f"Bearer {_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=120,
        )
        if response.status_code != 200:
            return f"[转录失败: qwen-asr HTTP {response.status_code} {response.text[:150]}]"
        data = response.json()
        text = (data.get("choices", [{}])[0].get("message", {}).get("content") or "").strip()
        return text or "[转录失败: qwen-asr 返回空文本]"
    except Exception as error:
        return f"[转录失败: qwen-asr 请求异常 {error}]"


def _transcribe_via_omni_video(filename: str, audio_data: bytes) -> str:
    """通过网关 omni 多模态模型转写语音（video 类型承载音频）。

    实测：网关 ws-dax6bh2yg3o6dbkb（new-api 风格）不提供 /audio/transcriptions 接口，
    但 chat/completions 支持 video 类型。qwen3.5-omni-flash 可接收
    data:video/webm;base64 或 data:audio/mpeg;base64 并转写其中的语音。

    返回转写文本；失败返回以 "[转录失败:" 开头的错误信息。
    """
    import base64 as _b64

    b64 = _b64.b64encode(audio_data).decode()
    # 根据扩展名推断 mime（webm/mp3/mp4/wav 常见）
    ext = (filename or "").lower().rsplit(".", 1)[-1] if "." in (filename or "") else "webm"
    mime = {
        "webm": "video/webm",
        "mp3": "audio/mpeg",
        "mp4": "video/mp4",
        "wav": "audio/wav",
        "m4a": "audio/mp4",
        "ogg": "audio/ogg",
        "oga": "audio/ogg",
    }.get(ext, "video/webm")

    payload = {
        "model": "qwen3.5-omni-flash",
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "video", "video": {"url": f"data:{mime};base64,{b64}"}},
                    {
                        "type": "text",
                        "text": "请把这段语音/视频中人物所说的内容逐字转写成中文文本，只输出转写结果，不要任何解释、不要重复指令。",
                    },
                ],
            }
        ],
        "temperature": 0.1,
    }
    try:
        resp = requests.post(
            f"{_API_BASE}/chat/completions",
            json=payload,
            headers={"Authorization": f"Bearer {_API_KEY}"},
            timeout=180,
        )
        if resp.status_code != 200:
            return f"[转录失败: omni HTTP {resp.status_code} {resp.text[:150]}]"
        data = resp.json()
        content = ""
        try:
            content = (data["choices"][0]["message"].get("content") or "").strip()
        except (KeyError, IndexError, TypeError):
            pass
        if not content:
            return "[转录失败: omni 返回空文本]"
        # 过滤掉模型回显指令的情况（模型偶尔只回显 prompt，不输出真实转写）。
        # 策略：只有当内容很短（< 20 字）且命中了 prompt 指令短语时才算回显；
        # 长文本中自然出现"转写"等词是正常的。
        prompt_echo_markers = ("只输出转写结果", "不要任何解释", "不要重复指令")
        if len(content) < 12 and any(m in content for m in prompt_echo_markers):
            return "[转录失败: omni 未识别到有效语音]"
        return content
    except Exception as e:
        return f"[转录失败: omni 请求异常 {e}]"


def _transcribe_via_dashscope_form(filename: str, audio_data: bytes, model: str) -> str:
    """Transcribe via DashScope base URL using multipart form-data (OpenAI-compatible format).

    Tries the /api/v1 base with the same /audio/transcriptions path pattern,
    which some MaaS gateways support.
    """
    try:
        resp = requests.post(
            f"{_DASHSCOPE_BASE}/audio/transcriptions",
            headers={"Authorization": f"Bearer {_API_KEY}"},
            files={"file": (filename, audio_data)},
            data={"model": model},
            timeout=120,
        )
        if resp.status_code == 200:
            data = resp.json()
            text = data.get("text", "")
            if text:
                logger.info(f"DashScope form ASR success with {model}: {len(text)} chars")
                return text
        # 接口不存在时 404 属于预期情况，无需记录日志
        if resp.status_code not in (404, 405):
            logger.warning(f"DashScope form ASR failed ({resp.status_code}): {resp.text[:200]}")
        return ""
    except Exception as e:
        logger.warning(f"DashScope form ASR error: {e}")
        return ""


def _transcribe_via_dashscope_http(filename: str, audio_data: bytes, model: str) -> str:
    """Transcribe via DashScope native HTTP API (/api/v1) through MaaS gateway.

    Uses the DashScope file transcription API with base64-encoded audio.
    Tries multiple API path patterns.
    """
    # 根据文件扩展名识别格式
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "webm"
    format_map = {
        "wav": "wav",
        "mp3": "mp3",
        "m4a": "m4a",
        "webm": "webm",
        "ogg": "ogg",
        "opus": "opus",
        "flac": "flac",
        "aac": "aac",
        "wma": "wma",
    }
    audio_format = format_map.get(ext, "webm")

    # 将音频编码为 base64
    audio_b64 = base64.b64encode(audio_data).decode("ascii")

    # 尝试多种 API 路径格式
    paths = [
        "/services/audio/asr/transcription",
        "/services/aigc/audio/transcription",
    ]

    for path in paths:
        try:
            payload = {
                "model": model,
                "input": {
                    "audio": audio_b64,
                    "format": audio_format,
                },
                "parameters": {},
            }

            resp = requests.post(
                f"{_DASHSCOPE_BASE}{path}",
                headers={
                    "Authorization": f"Bearer {_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=120,
            )

            if resp.status_code == 200:
                data = resp.json()
                output = data.get("output", {})
                results = output.get("results", [])
                if results:
                    text = results[0].get("text", "")
                    if text:
                        logger.info(f"DashScope HTTP ASR success ({path}): {len(text)} chars")
                        return text
                text = output.get("text", "")
                if text:
                    return text
                logger.warning(f"DashScope HTTP empty result ({path}): {json.dumps(data, ensure_ascii=False)[:300]}")

            if resp.status_code not in (404, 405):
                logger.warning(f"DashScope HTTP ASR failed ({path}, {resp.status_code}): {resp.text[:200]}")

        except requests.exceptions.Timeout:
            logger.warning(f"DashScope HTTP ASR timed out ({path})")
        except Exception as e:
            logger.warning(f"DashScope HTTP ASR error ({path}): {e}")

    return ""


def _transcribe_via_proxy(filename: str, audio_data: bytes, model: str) -> str:
    """Try transcription via OpenAI-compatible proxy."""
    try:
        resp = requests.post(
            f"{_API_BASE}/audio/transcriptions",
            headers={"Authorization": f"Bearer {_API_KEY}"},
            files={"file": (filename, audio_data)},
            data={"model": model},
            timeout=120,
        )
        if resp.status_code == 200:
            data = resp.json()
            text = data.get("text", "")
            if text:
                return text
        if resp.status_code not in (404, 405):
            logger.warning(f"Proxy transcription failed ({resp.status_code}): {resp.text[:200]}")
        return ""
    except Exception as e:
        logger.warning(f"Proxy transcription error: {e}")
        return ""


def _transcribe_via_dashscope(filename: str, audio_data: bytes, model: str, language: str) -> str:
    """Try transcription via DashScope SDK (with MaaS gateway or official endpoint)."""
    try:
        import dashscope
        from dashscope.audio.asr import Transcription

        # 使用相同 API Key 尝试 MaaS 网关
        temp_path = None
        try:
            import tempfile

            with tempfile.NamedTemporaryFile(suffix=f"_{filename}", delete=False) as f:
                f.write(audio_data)
                temp_path = f.name

            # 使用 MaaS DashScope 网关
            dashscope.base_http_api_url = _DASHSCOPE_BASE
            dashscope.api_key = _API_KEY

            result = Transcription.call(
                model=model,
                file_urls=[f"file://{temp_path}"],
                language_hints=[language],
            )
            if result.status_code == 200:
                transcripts = result.output.get("results", [])
                if transcripts:
                    return transcripts[0].get("text", "")
            logger.warning(f"DashScope SDK via MaaS failed: code={result.code}, msg={result.message}")

            # 降级处理：尝试专用 DASHSCOPE_API_KEY
            if _DASHSCOPE_KEY:
                dashscope.api_key = _DASHSCOPE_KEY
                # 将基础地址恢复为默认值
                dashscope.base_http_api_url = "https://dashscope.aliyuncs.com/api/v1"
                result = Transcription.call(
                    model=model,
                    file_urls=[f"file://{temp_path}"],
                    language_hints=[language],
                )
                if result.status_code == 200:
                    transcripts = result.output.get("results", [])
                    if transcripts:
                        return transcripts[0].get("text", "")
                logger.warning(f"DashScope SDK direct failed: code={result.code}")

            return ""
        finally:
            if temp_path and os.path.exists(temp_path):
                os.unlink(temp_path)

    except ImportError:
        logger.warning("dashscope SDK not installed")
        return ""
    except Exception as e:
        logger.warning(f"DashScope transcription error: {e}")
        return ""


# ── 图片分析 ────────────────────────────────────────────────


def analyze_image(
    filename: str,
    image_data: bytes,
    prompt: str = "",
    model: str = "qwen-vl-max",
) -> str:
    """分析图片（统一打点收口入口，fallback 链见 _analyze_image_impl）。"""
    from app.audit.token_tracker import track_llm_call

    with track_llm_call(model, agent="multimodal", operation="analyze_image", call_type="text") as _ctx:
        _ctx.success = False
        result = _analyze_image_impl(filename, image_data, prompt, model)
        if result and not result.startswith("["):
            _ctx.success = True
            _ctx.usage = {"prompt_tokens": 0, "completion_tokens": len(result), "total_tokens": len(result)}
    return result


def _analyze_image_impl(
    filename: str,
    image_data: bytes,
    prompt: str = "",
    model: str = "qwen-vl-max",
) -> str:
    """
    Analyze an image using vision-language model.

    Tries in order:
    1. Proxy chat/completions with image_url (base64)
    2. DashScope SDK direct call
    3. Returns error message

    Args:
        filename: Original filename
        image_data: Raw image bytes
        prompt: Analysis prompt (default: describe the image)
        model: Vision model name

    Returns:
        Image description/analysis text
    """
    if not prompt:
        prompt = _default_prompt_for_file(filename)

    # 优先尝试代理接口
    result = _analyze_via_proxy(filename, image_data, prompt, model)
    if result and not result.startswith("[分析失败"):
        return result

    # 尝试 DashScope SDK
    result = _analyze_via_dashscope(filename, image_data, prompt, model)
    if result and not result.startswith("[分析失败"):
        return result

    return f"[分析失败: 视觉模型({model})未配置。请在代理上添加视觉模型，或设置 DASHSCOPE_API_KEY]"


def _default_prompt_for_file(filename: str) -> str:
    """Generate appropriate prompt based on filename."""
    name_lower = filename.lower()
    if any(kw in name_lower for kw in ["证书", "certificate", "diploma", "学位"]):
        return "这是一份证书图片。请提取以下信息：证书类型、持有人姓名、颁发机构、颁发日期、证书编号。用JSON格式输出。"
    elif any(kw in name_lower for kw in ["身份证", "id_card", "passport", "护照"]):
        return "这是一份身份证件。请提取：姓名、证件号码、有效期。注意保护隐私，只输出必要信息。"
    elif any(kw in name_lower for kw in ["简历", "resume", "cv"]):
        return "这是一份简历图片。请提取结构化信息：姓名、联系方式、教育背景、工作经历、技能。用JSON格式输出。"
    elif any(kw in name_lower for kw in ["面试", "interview"]):
        return "这是面试相关的图片。请描述图片内容，如果是白板/笔记请提取关键信息。"
    else:
        return "请详细描述这张图片的内容。如果是文档，请提取文字信息。"


def _analyze_via_proxy(filename: str, image_data: bytes, prompt: str, model: str) -> str:
    """Try image analysis via OpenAI-compatible proxy."""
    try:
        # 将图片编码为 base64 Data URL
        ext = filename.rsplit(".", 1)[-1] if "." in filename else "png"
        mime = {
            "jpg": "image/jpeg",
            "jpeg": "image/jpeg",
            "png": "image/png",
            "gif": "image/gif",
            "webp": "image/webp",
        }.get(ext.lower(), "image/png")
        b64 = base64.b64encode(image_data).decode()
        data_url = f"data:{mime};base64,{b64}"

        resp = requests.post(
            f"{_API_BASE}/chat/completions",
            headers={
                "Authorization": f"Bearer {_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": data_url}},
                        ],
                    }
                ],
                "max_tokens": 2048,
            },
            timeout=60,
        )

        if resp.status_code == 200:
            data = resp.json()
            return data["choices"][0]["message"]["content"]

        logger.warning(f"Proxy vision failed ({resp.status_code}): {resp.text[:200]}")
        return ""

    except Exception as e:
        logger.warning(f"Proxy vision error: {e}")
        return ""


def _analyze_via_dashscope(filename: str, image_data: bytes, prompt: str, model: str) -> str:
    """Try image analysis via DashScope SDK — MaaS gateway first, then official."""
    if not _API_KEY:
        return ""

    try:
        # 保存到临时文件
        import tempfile

        import dashscope
        from dashscope import MultiModalConversation

        ext = filename.rsplit(".", 1)[-1] if "." in filename else "png"
        with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as f:
            f.write(image_data)
            temp_path = f.name

        try:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"image": f"file://{temp_path}"},
                        {"text": prompt},
                    ],
                }
            ]

            # 方式 1：通过 DashScope SDK 调用 MaaS 网关
            dashscope.base_http_api_url = _DASHSCOPE_BASE
            dashscope.api_key = _API_KEY

            resp = MultiModalConversation.call(model=model, messages=messages)

            if resp.status_code == 200:
                content = resp.output.choices[0].message.content
                if isinstance(content, list):
                    return " ".join(item.get("text", "") for item in content)
                return str(content)

            logger.warning(f"DashScope vision via MaaS failed: code={resp.code}, msg={resp.message}")

            # 方式 2：使用专用密钥调用 DashScope 官方接口
            if _DASHSCOPE_KEY and _DASHSCOPE_KEY != _API_KEY:
                dashscope.api_key = _DASHSCOPE_KEY
                dashscope.base_http_api_url = "https://dashscope.aliyuncs.com/api/v1"
                resp = MultiModalConversation.call(model=model, messages=messages)

                if resp.status_code == 200:
                    content = resp.output.choices[0].message.content
                    if isinstance(content, list):
                        return " ".join(item.get("text", "") for item in content)
                    return str(content)

                logger.warning(f"DashScope vision direct failed: code={resp.code}, msg={resp.message}")

            return ""
        finally:
            os.unlink(temp_path)

    except ImportError:
        logger.warning("dashscope SDK not installed")
        return ""
    except Exception as e:
        logger.warning(f"DashScope vision error: {e}")
        return ""


# ── 视频分析（qwen-vl-max）─────────────────────────────────


def _analyze_video_via_proxy(filename: str, video_data: bytes, prompt: str, model: str, mime: str) -> str:
    """Analyze video via proxy using key frames (image_url) + audio transcription.

    OpenAI-compatible proxies don't support video_url content type.
    Instead we: extract key frames → send as image_url → combine with audio transcript.
    """
    import glob
    import subprocess
    import tempfile

    temp_dir = tempfile.mkdtemp(prefix="video_analysis_")
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "mp4"
    video_path = os.path.join(temp_dir, f"input.{ext}")

    try:
        # 1. 保存视频到临时文件
        with open(video_path, "wb") as f:
            f.write(video_data)
        logger.info(f"[Video] Saved {filename} to {video_path} ({len(video_data) / 1024 / 1024:.1f}MB)")

        # 2. 提取关键帧：每10秒1帧，最多8帧
        frames_dir = os.path.join(temp_dir, "frames")
        os.makedirs(frames_dir, exist_ok=True)
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i",
                video_path,
                "-vf",
                "fps=1/10,select='lt(n,8)'",
                "-vsync",
                "vfr",
                os.path.join(frames_dir, "frame_%03d.jpg"),
            ],
            capture_output=True,
            timeout=60,
        )
        frame_files = sorted(glob.glob(os.path.join(frames_dir, "frame_*.jpg")))
        logger.info(f"[Video] Extracted {len(frame_files)} key frames from {filename}")

        # 3. 提取音频并转录
        audio_path = os.path.join(temp_dir, "audio.wav")
        subprocess.run(
            ["ffmpeg", "-y", "-i", video_path, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", audio_path],
            capture_output=True,
            timeout=60,
        )
        transcript = ""
        if os.path.exists(audio_path) and os.path.getsize(audio_path) > 0:
            with open(audio_path, "rb") as af:
                transcript = transcribe_audio(f"{filename}.wav", af.read())
            if transcript.startswith("["):
                transcript = ""
        logger.info(f"[Video] Audio transcript: {len(transcript)} chars")

        # 4. 通过 proxy 发送关键帧给 qwen-vl-max（image_url 格式）
        if not frame_files and not transcript:
            logger.warning(f"[Video] No frames or transcript extracted from {filename}")
            return ""

        content_parts = []
        # 添加关键帧图片
        for frame_path in frame_files[:8]:
            with open(frame_path, "rb") as img_f:
                img_b64 = base64.b64encode(img_f.read()).decode()
            content_parts.append(
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"},
                }
            )

        # 构建综合分析 prompt
        transcript_section = f"同时以下是视频中的音频转录内容：\n{transcript}\n" if transcript else ""
        combined_prompt = f"""以下是从面试视频中提取的关键帧截图（按时间顺序排列）。
请根据这些画面分析面试场景，包括：候选人的表情、肢体语言、自信程度、白板/屏幕内容等。

{transcript_section}
请结合画面和音频转录，给出完整的面试分析。

原始分析要求：
{prompt}"""

        content_parts.append({"type": "text", "text": combined_prompt})

        resp = requests.post(
            f"{_API_BASE}/chat/completions",
            headers={
                "Authorization": f"Bearer {_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [{"role": "user", "content": content_parts}],
                "max_tokens": 4096,
            },
            timeout=120,
        )

        if resp.status_code == 200:
            data = resp.json()
            result = data["choices"][0]["message"]["content"]
            logger.info(f"[Video] qwen-vl-max analyzed {filename}: {len(result)} chars ({len(frame_files)} frames)")
            return result

        logger.warning(f"Proxy frame-based analysis failed ({resp.status_code}): {resp.text[:200]}")
        return ""

    except subprocess.TimeoutExpired:
        logger.warning(f"[Video] ffmpeg timed out for {filename}")
        return ""
    except requests.exceptions.Timeout:
        logger.warning(f"[Video] Proxy frame analysis timed out for {filename}")
        return ""
    except Exception as e:
        logger.warning(f"[Video] Frame-based analysis error: {e}")
        return ""
    finally:
        # 清理临时文件
        import shutil

        shutil.rmtree(temp_dir, ignore_errors=True)


def _analyze_video_via_dashscope(filename: str, video_data: bytes, prompt: str, model: str) -> str:
    """Analyze video via DashScope SDK (file-based, more reliable than base64 proxy)."""
    if not _DASHSCOPE_KEY:
        return ""

    try:
        import dashscope
        from dashscope import MultiModalConversation

        dashscope.api_key = _DASHSCOPE_KEY

        import tempfile

        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "mp4"
        with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as f:
            f.write(video_data)
            temp_path = f.name

        try:
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"video": f"file://{temp_path}"},
                        {"text": prompt},
                    ],
                }
            ]

            logger.info(f"[Video] DashScope SDK analyzing {filename} ({len(video_data) / 1024 / 1024:.1f}MB)")
            resp = MultiModalConversation.call(model=model, messages=messages)

            if resp.status_code == 200:
                content = resp.output.choices[0].message.content
                if isinstance(content, list):
                    text = " ".join(item.get("text", "") for item in content)
                else:
                    text = str(content)
                logger.info(f"[Video] DashScope SDK analyzed {filename}: {len(text)} chars")
                return text

            logger.warning(f"DashScope video analysis failed: code={resp.code}, msg={resp.message}")
            return ""
        finally:
            os.unlink(temp_path)

    except ImportError:
        logger.warning("dashscope SDK not installed for video analysis")
        return ""
    except Exception as e:
        logger.warning(f"DashScope video analysis error: {e}")
        return ""


def _fallback_audio_transcribe(filename: str, video_data: bytes, prompt: str) -> str:
    """Fallback: extract audio from video and transcribe, then analyze text."""
    import subprocess
    import tempfile

    try:
        # 1. 保存视频到临时文件
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else "mp4"
        with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as f:
            f.write(video_data)
            video_path = f.name

        # 2. 用 ffmpeg 提取音频
        audio_path = video_path + ".wav"
        subprocess.run(
            ["ffmpeg", "-y", "-i", video_path, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", audio_path],
            capture_output=True,
            timeout=60,
        )

        # 3. 读取音频并转录
        with open(audio_path, "rb") as af:
            audio_bytes = af.read()

        transcript = transcribe_audio(filename.replace(f".{ext}", ".wav"), audio_bytes)

        # 4. 清理临时文件
        for p in [video_path, audio_path]:
            try:
                os.unlink(p)
            except OSError:
                pass

        if transcript and not transcript.startswith("["):
            return f"[音频转录]\n{transcript}"

        return f"[视频分析失败: 音频转录未成功。{transcript}]"

    except FileNotFoundError:
        return "[视频分析失败: ffmpeg 未安装。请安装 ffmpeg 以支持音频提取]"
    except subprocess.TimeoutExpired:
        return "[视频分析失败: ffmpeg 处理超时]"
    except Exception as e:
        return f"[视频分析失败: {str(e)[:100]}]"
