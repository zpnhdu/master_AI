"""品牌素材的统一读写和签名 URL 适配。"""

from __future__ import annotations

from pathlib import Path

from app.config import REACT_PUBLIC_DIR
from app.image_thumbnails import create_thumbnail_bytes
from app.infrastructure.config import settings
from app.media_storage import MediaStorage, get_media_storage, join_storage_key

PROJECT_ROOT = Path(__file__).resolve().parents[1]
_THUMBNAIL_EXTENSIONS = {".gif", ".jpg", ".jpeg", ".png", ".webp"}


def brand_storage_key(filename: str) -> str:
    """Return a stable key for a canonical brand filename."""
    normalized = filename.replace("\\", "/")
    safe_name = Path(normalized).name
    if not safe_name or normalized != safe_name or safe_name in {".", ".."}:
        raise ValueError("invalid brand filename")
    return join_storage_key(settings.oss_brand_prefix, safe_name)


def brand_thumbnail_storage_key(storage_key: str) -> str:
    """Return the deterministic thumbnail key for a raster brand asset."""
    parent, separator, filename = storage_key.rpartition("/")
    if not separator or not parent or not filename:
        raise ValueError("invalid brand storage key")
    source_suffix = Path(filename).suffix.lower().lstrip(".")
    return join_storage_key(parent, "thumbs", f"{Path(filename).stem}.{source_suffix}.webp")


def is_thumbnailable_brand_asset(storage_key: str) -> bool:
    return Path(storage_key).suffix.lower() in _THUMBNAIL_EXTENSIONS


def write_brand_asset(
    filename: str,
    data: bytes,
    content_type: str,
    *,
    storage: MediaStorage | None = None,
) -> str:
    storage = storage or get_media_storage()
    key = brand_storage_key(filename)
    storage.write(key, data, content_type)
    if is_thumbnailable_brand_asset(key):
        try:
            thumbnail_data = create_thumbnail_bytes(data)
        except (OSError, ValueError):
            thumbnail_data = None
        if thumbnail_data:
            storage.write(brand_thumbnail_storage_key(key), thumbnail_data, "image/webp")
    return key


def read_brand_asset(
    filename: str,
    *,
    storage: MediaStorage | None = None,
    storage_key: str = "",
) -> bytes | None:
    storage = storage or get_media_storage()
    key = storage_key or brand_storage_key(filename)
    if storage.exists(key):
        return storage.read(key)
    if storage.backend == "local":
        public_path = Path(REACT_PUBLIC_DIR) / "brand" / Path(filename).name
        if public_path.is_file():
            return public_path.read_bytes()
    return None


def brand_asset_url(
    filename: str,
    *,
    storage: MediaStorage | None = None,
    storage_key: str = "",
    fallback_url: str = "",
    thumbnail: bool = False,
) -> str:
    storage = storage or get_media_storage()
    key = storage_key or brand_storage_key(filename)
    if thumbnail and is_thumbnailable_brand_asset(key):
        key = brand_thumbnail_storage_key(key)
    if hasattr(storage, "sign_url"):
        return storage.sign_url(key)
    return fallback_url or f"/brand/{Path(filename).name}"
