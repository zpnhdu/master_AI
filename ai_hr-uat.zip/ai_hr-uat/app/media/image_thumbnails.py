"""Image thumbnail generation shared by OSS-backed asset libraries."""

from __future__ import annotations

from io import BytesIO

from PIL import Image

THUMBNAIL_MAX_SIZE = 480
THUMBNAIL_QUALITY = 82


def create_thumbnail_bytes(data: bytes, max_size: int = THUMBNAIL_MAX_SIZE) -> bytes:
    """Create a bounded WebP thumbnail while preserving transparency."""
    with Image.open(BytesIO(data)) as image:
        image.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
        output = image.convert("RGBA" if "transparency" in image.info or image.mode in {"RGBA", "LA"} else "RGB")
        buffer = BytesIO()
        output.save(buffer, format="WEBP", quality=THUMBNAIL_QUALITY, method=6)
        return buffer.getvalue()
