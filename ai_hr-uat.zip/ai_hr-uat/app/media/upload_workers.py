"""Shared worker pool for resume upload I/O.

The pool is process-local and deliberately bounded by the host CPU count.
Tasks submitted after all workers are busy remain queued in the executor.
"""

import os
from concurrent.futures import ThreadPoolExecutor


UPLOAD_WORKER_COUNT = max(1, os.cpu_count() or 1)
upload_executor = ThreadPoolExecutor(
    max_workers=UPLOAD_WORKER_COUNT,
    thread_name_prefix="resume-upload",
)


def get_upload_executor() -> ThreadPoolExecutor:
    """Return the process-wide bounded executor used by upload endpoints."""
    return upload_executor
