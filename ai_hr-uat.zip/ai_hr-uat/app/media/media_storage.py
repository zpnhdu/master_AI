"""小海媒体文件存储适配层。"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable, Protocol, TypeVar
from urllib.parse import quote, urlsplit

from app.config import UPLOAD_DIR
from app.infrastructure.config import settings

logger = logging.getLogger(__name__)
_T = TypeVar("_T")
_IMAGE_EXTENSIONS = {".gif", ".jpg", ".jpeg", ".png", ".webp"}


def _object_headers(content_type: str) -> dict[str, str]:
    headers = {"Content-Type": content_type}
    if content_type.lower().startswith("image/"):
        headers["Cache-Control"] = "public, max-age=3600"
    return headers


class MediaStorage(Protocol):
    backend: str

    def write(self, key: str, data: bytes, content_type: str) -> None: ...

    def write_file(self, key: str, path: str | Path, content_type: str) -> None: ...

    def read(self, key: str) -> bytes: ...

    def exists(self, key: str) -> bool: ...

    def delete(self, key: str) -> bool: ...

    def list_keys(self, prefix: str = "") -> list[str]: ...


def storage_cache_key(storage: MediaStorage) -> str:
    """Return a stable non-secret key for process-local asset caches."""
    return str(getattr(storage, "cache_key", f"id:{id(storage)}"))


class LocalMediaStorage:
    backend = "local"

    def __init__(self, root: str | Path | None = None):
        self.root = Path(root or Path(UPLOAD_DIR) / "media").resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        path = (self.root / key).resolve()
        if self.root != path and self.root not in path.parents:
            raise ValueError("invalid storage key")
        return path

    def write(self, key: str, data: bytes, content_type: str) -> None:
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    def write_file(self, key: str, path: str | Path, content_type: str) -> None:
        self.write(key, Path(path).read_bytes(), content_type)

    def read(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()

    def delete(self, key: str) -> bool:
        path = self._path(key)
        if not path.is_file():
            return False
        path.unlink()
        return True

    def list_keys(self, prefix: str = "") -> list[str]:
        prefix_path = self._path(prefix) if prefix else self.root
        if not prefix_path.exists():
            return []
        return sorted(
            str(path.relative_to(self.root)).replace("\\", "/") for path in prefix_path.rglob("*") if path.is_file()
        )


class OssMediaStorage:
    backend = "oss"

    def __init__(self):
        import oss2

        endpoint = settings.oss_endpoint.strip()
        bucket_name = settings.oss_bucket.strip()
        access_key = settings.oss_access_key_id.strip()
        access_secret = settings.oss_access_key_secret.strip()
        if not all((endpoint, bucket_name, access_key, access_secret)):
            raise RuntimeError("OSS media storage is not fully configured")
        self._auth = oss2.Auth(access_key, access_secret)
        self.cache_key = f"oss:{endpoint}:{bucket_name}"
        self._bucket_name = bucket_name
        self._connect_timeout = max(float(getattr(settings, "oss_connect_timeout_seconds", 5.0)), 1.0)
        self.bucket = oss2.Bucket(self._auth, endpoint, bucket_name, connect_timeout=self._connect_timeout)
        self.public_bucket = self._create_public_bucket(oss2)

    def _create_public_bucket(self, oss2):
        public_base = settings.oss_public_base_url.strip().rstrip("/")
        if not public_base:
            return self.bucket

        parsed = urlsplit(public_base)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.path not in {"", "/"}:
            raise RuntimeError("OSS_PUBLIC_BASE_URL must be an HTTP(S) origin without a path")

        bucket_prefix = f"{self._bucket_name}."
        if parsed.hostname and parsed.hostname.startswith(bucket_prefix):
            endpoint_host = parsed.hostname[len(bucket_prefix) :]
            endpoint = f"{parsed.scheme}://{endpoint_host}"
            return oss2.Bucket(self._auth, endpoint, self._bucket_name, connect_timeout=self._connect_timeout)

        return oss2.Bucket(
            self._auth,
            public_base,
            self._bucket_name,
            is_cname=True,
            connect_timeout=self._connect_timeout,
        )

    def _request_with_retry(self, operation: str, request: Callable[[], _T]) -> _T:
        import oss2

        max_attempts = max(1, settings.oss_request_max_attempts)
        backoff_seconds = max(0.0, settings.oss_request_retry_backoff_seconds)
        for attempt in range(1, max_attempts + 1):
            try:
                return request()
            except oss2.exceptions.OssError as exc:
                status = getattr(exc, "status", None)
                retryable = (
                    isinstance(exc, oss2.exceptions.RequestError)
                    or status == 429
                    or (isinstance(status, int) and status >= 500)
                )
                if not retryable or attempt >= max_attempts:
                    raise
                delay = backoff_seconds * (2 ** (attempt - 1))
                logger.warning(
                    "OSS %s failed, retrying attempt=%s/%s delay_seconds=%s status=%s error=%s",
                    operation,
                    attempt + 1,
                    max_attempts,
                    delay,
                    status,
                    type(exc).__name__,
                )
                time.sleep(delay)
        raise RuntimeError("unreachable OSS retry state")

    def write(self, key: str, data: bytes, content_type: str) -> None:
        self._request_with_retry(
            "put_object",
            lambda: self.bucket.put_object(key, data, headers=_object_headers(content_type)),
        )

    def write_file(self, key: str, path: str | Path, content_type: str) -> None:
        self._request_with_retry(
            "put_object_from_file",
            lambda: self.bucket.put_object_from_file(key, str(path), headers=_object_headers(content_type)),
        )

    def read(self, key: str) -> bytes:
        return self.bucket.get_object(key).read()

    def exists(self, key: str) -> bool:
        return self.bucket.object_exists(key)

    def delete(self, key: str) -> bool:
        result = self.bucket.delete_object(key)
        return result.status == 204

    def list_keys(self, prefix: str = "") -> list[str]:
        import oss2

        normalized_prefix = join_storage_key(prefix) if prefix else ""
        if normalized_prefix and not normalized_prefix.endswith("/"):
            normalized_prefix += "/"
        return sorted(obj.key for obj in oss2.ObjectIterator(self.bucket, prefix=normalized_prefix))

    def sign_url(self, key: str, expires: int | None = None, download_filename: str = "") -> str:
        expire_seconds = expires or settings.oss_presign_expire_seconds
        params = (
            {"response-cache-control": "public, max-age=3600"}
            if Path(key).suffix.lower() in _IMAGE_EXTENSIONS
            else None
        )
        if download_filename:
            safe_filename = Path(download_filename.replace("\\", "/")).name or "resume"
            params = params or {}
            params["response-content-disposition"] = f"attachment; filename*=UTF-8''{quote(safe_filename)}"
        return self.public_bucket.sign_url("GET", key, expire_seconds, params=params, slash_safe=True)


def join_storage_key(prefix: str, *parts: str) -> str:
    """Join trusted object-key parts while rejecting path traversal."""
    segments: list[str] = []
    for value in (prefix, *parts):
        normalized = str(value).replace("\\", "/").strip("/")
        if not normalized:
            continue
        pieces = normalized.split("/")
        if any(piece in {"", ".", ".."} for piece in pieces):
            raise ValueError("invalid storage key segment")
        segments.extend(pieces)
    return "/".join(segments)


def get_media_storage(backend: str | None = None) -> MediaStorage:
    storage_backend = (backend or settings.storage_backend).strip().lower()
    if storage_backend in {"oss", "aliyun"}:
        return OssMediaStorage()
    if storage_backend != "local":
        raise RuntimeError(f"unsupported media storage backend: {storage_backend}")
    return LocalMediaStorage()
