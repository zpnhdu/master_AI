"""项目环境配置加载器。"""

from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path

from dotenv import dotenv_values

SUPPORTED_ENVIRONMENTS = ("local", "dev", "uat", "prod")


def project_root() -> Path:
    """返回项目根目录。"""
    return Path(__file__).resolve().parent.parent


def _read_env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    return {key: value for key, value in dotenv_values(path).items() if key and value is not None}


def resolve_environment_name(root: Path | None = None, environ: Mapping[str, str] | None = None) -> str:
    """从系统环境变量解析运行环境；未指定时使用本地开发配置。"""
    environ = os.environ if environ is None else environ
    name = environ.get("APP_ENV", "local").strip().lower()
    if name not in SUPPORTED_ENVIRONMENTS:
        supported = ", ".join(SUPPORTED_ENVIRONMENTS)
        raise ValueError(f"APP_ENV={name!r} 无效，必须是: {supported}")
    return name


def load_environment(root: Path | None = None) -> str:
    """加载对应环境配置，且不覆盖系统注入的具体变量。

    ``local.env`` 是可选的本机密钥覆盖文件，已被 Git 忽略。它会覆盖
    ``config/environments/.env.*`` 中的模板值，但仍不覆盖进程环境变量。
    """
    root = root or project_root()
    environment_name = resolve_environment_name(root)
    environment_file = root / "config" / "environments" / f".env.{environment_name}"
    template_values = _read_env_file(environment_file)
    if not template_values:
        raise FileNotFoundError(f"缺少运行配置文件: {environment_file}")

    local_override_values = _read_env_file(root / "local.env")
    values = {**template_values, **local_override_values}

    for key, value in values.items():
        if key not in os.environ:
            os.environ[key] = value
    os.environ["APP_ENV"] = environment_name
    return environment_name
