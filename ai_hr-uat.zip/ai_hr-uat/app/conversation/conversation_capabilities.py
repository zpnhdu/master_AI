"""Agent 自然语言能力注册表。"""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Optional

# (pipeline_id, content, source, previous_command, default_candidate_id)
PreviewBuilder = Callable[[str, str, str, Optional[dict], str], Awaitable[dict]]
LatestReader = Callable[[str], dict]
Executor = Callable[[object, dict], tuple[bool, dict, str]]
Undoer = Callable[[object, dict], tuple[bool, dict, str]]


@dataclass(frozen=True)
class ConversationCapability:
    agent_id: str
    build_preview: PreviewBuilder
    read_latest: LatestReader
    execute: Executor
    undo: Optional[Undoer] = None


_CAPABILITIES: dict[str, ConversationCapability] = {}
_DEFAULTS_LOADED = False


def register_capability(capability: ConversationCapability) -> None:
    if capability.agent_id in _CAPABILITIES:
        raise ValueError(f"Duplicate conversation capability: {capability.agent_id}")
    _CAPABILITIES[capability.agent_id] = capability


def _load_defaults() -> None:
    global _DEFAULTS_LOADED
    if _DEFAULTS_LOADED:
        return
    from app.xiao_hai_conversation import CAPABILITY as XIAO_HAI_CAPABILITY
    from app.xiao_mian_conversation import CAPABILITY as XIAO_MIAN_CAPABILITY

    register_capability(XIAO_HAI_CAPABILITY)
    register_capability(XIAO_MIAN_CAPABILITY)
    _DEFAULTS_LOADED = True


def get_capability(agent_id: str) -> Optional[ConversationCapability]:
    _load_defaults()
    return _CAPABILITIES.get(agent_id)
