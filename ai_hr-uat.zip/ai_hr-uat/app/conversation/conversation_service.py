"""六 Agent 独立会话的统一命令入口；首期接入小面能力。"""

from __future__ import annotations

import asyncio
import hashlib
import json

from app import conversation_store
from app.conversation_capabilities import get_capability
from app.conversation_store import add_message, get_command, update_command
from app.db import get_db, get_pipeline, transaction
from app.agents.poster_progress import PosterJobConflictError
from app.state import broadcast
from hr_harness.roles.registry import ROLE_REGISTRY

AGENT_IDS = set(ROLE_REGISTRY.keys())
PENDING_STATUSES = ("clarifying", "awaiting_confirm", "stale")

_PREVIEW_FAILURES = (
    ("不允许修改面试题", "question_edit_locked", "该候选人的面试已开始或结束，不能再修改面试题。"),
    ("题目索引不存在", "question_not_found", "题号不存在，请确认当前题目数量后重试。"),
    ("没有面试题", "candidate_questions_not_found", "该候选人还没有面试题，请先生成题目。"),
    ("整套改题必须保持题目数量", "question_count_mismatch", "整套改题结果数量异常，请重新生成预览。"),
    ("题目生成结果无效", "question_generation_invalid", "题目生成结果不完整，请重新生成预览。"),
    ("没有待进行面试", "schedule_not_found", "该候选人没有待进行面试，请检查最新排期。"),
)


class ConversationError(ValueError):
    """可稳定映射为 API 错误码的会话异常。"""

    def __init__(self, code: str, message: str, *, job_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.job_id = job_id


def _revision(data) -> str:
    serialized = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _require_session(session_id: str, actor_id: str) -> dict:
    session = conversation_store.get_session(session_id)
    if not session:
        raise ConversationError("session_not_found", "会话不存在")
    if session["actor_id"] != actor_id:
        raise ConversationError("session_forbidden", "无权访问该会话")
    if session["status"] != "active":
        raise ConversationError("session_archived", "会话已归档")
    return session


def ensure_session(pipeline_id: str, agent_id: str, actor_id: str) -> dict:
    if not get_pipeline(pipeline_id):
        raise ConversationError("pipeline_not_found", "流水线不存在")
    if agent_id not in AGENT_IDS:
        raise ConversationError("agent_not_supported", "Agent 不在允许范围内")
    return conversation_store.ensure_session(pipeline_id, agent_id, actor_id)


def get_session_messages(session_id: str, actor_id: str, limit: int = 100) -> list[dict]:
    _require_session(session_id, actor_id)
    return conversation_store.get_messages(session_id, limit)


def _snapshot(session: dict) -> dict:
    capability = get_capability(session["agent_id"])
    return capability.read_latest(session["pipeline_id"]) if capability else {"resources": [], "revision_map": {}}


def get_snapshot(session_id: str, actor_id: str) -> dict:
    return _snapshot(_require_session(session_id, actor_id))


def get_session_state(session_id: str, actor_id: str, limit: int = 100) -> dict:
    """恢复消息、未完成命令和权威业务数据。"""
    session = _require_session(session_id, actor_id)
    pending_commands = conversation_store.get_commands(session_id, PENDING_STATUSES)
    recent_commands = conversation_store.get_commands(session_id, limit=min(limit, 50))
    return {
        "session": session,
        "messages": conversation_store.get_messages(session_id, limit),
        "recent_commands": recent_commands,
        "pending_commands": pending_commands,
        "active_command": pending_commands[-1] if pending_commands else None,
        "latest_data": _snapshot(session),
    }


def _response(command: dict) -> dict:
    result = command.get("result") or {}
    return {
        "reply": result.get("reply", ""),
        "command": command,
        "latest_data": command.get("latest_data") or {},
        "outcome_code": command.get("outcome_code", ""),
    }


def _preview_failure(error: Exception) -> tuple[str, str]:
    message = str(error)
    for fragment, code, reply in _PREVIEW_FAILURES:
        if fragment in message:
            return code, reply
    return "preview_failed", "暂时无法生成操作预览，请稍后重试或调整描述。"


def _save_preview(command: dict, session: dict, preview_result: dict) -> dict:
    preview = preview_result["preview"]
    reply = preview_result["reply"]
    return update_command(
        command["id"],
        intent=preview_result["intent"],
        status=preview_result["status"],
        payload=preview_result["payload"],
        preview=preview,
        preview_hash=_revision(preview) if preview else "",
        latest_data=_snapshot(session),
        outcome_code="",
        result={
            "reply": reply,
            "missing_fields": preview_result.get("missing_fields", []),
            "candidate_options": preview_result.get("candidate_options", []),
            "schedule_options": preview_result.get("schedule_options", []),
        },
    )


def _execute_command(command: dict, session: dict, capability) -> dict:
    """执行已解析的命令，并把执行结果写回会话时间线。"""
    try:
        with transaction() as conn:
            applied, result, reply = capability.execute(conn, command)
            next_status = "queued" if applied and result.get("job_id") else "succeeded" if applied else "stale"
            update_command(
                command["id"],
                conn=conn,
                status=next_status,
                outcome_code="success" if applied else "revision_conflict",
                result={**result, "reply": reply},
            )
    except PosterJobConflictError as error:
        raise ConversationError("poster_job_active", str(error), job_id=error.job_id) from error
    except ValueError as error:
        raise ConversationError("execution_failed", str(error)) from error

    if command.get("intent") == "modify_questions":
        asyncio.create_task(
            broadcast(
                {"type": "questions_updated", "pipeline_id": session["pipeline_id"]},
                session["pipeline_id"],
            )
        )
    latest_data = _snapshot(session)
    command = update_command(command["id"], latest_data=latest_data)
    add_message(session["id"], command["id"], "assistant", command["result"]["reply"])
    return _response(command)


async def submit_session_message(
    session_id: str,
    actor_id: str,
    client_request_id: str,
    content: str,
    source: str = "text",
    continuation_command_id: str = "",
    selected_candidate_id: str = "",
    selected_schedule_id: str = "",
    attachment_ids: list[str] | None = None,
    base_version_id: str = "",
    background_element_id: str = "",
    element_ids: list[str] | None = None,
    use_default_materials: bool = False,
) -> dict:
    session = _require_session(session_id, actor_id)
    if not client_request_id or not content.strip():
        raise ConversationError("invalid_message", "请求 ID 和消息内容不能为空")

    previous_command = None
    if continuation_command_id:
        previous_command = get_command(continuation_command_id)
        if not previous_command or previous_command["session_id"] != session_id:
            raise ConversationError("continuation_not_found", "追问命令不存在或不属于当前会话")
        if previous_command["status"] != "clarifying":
            raise ConversationError("continuation_invalid", "该命令当前不能继续补充")

    request_context = {
        "selected_candidate_id": selected_candidate_id,
        "attachment_ids": attachment_ids or [],
        "base_version_id": base_version_id,
        "background_element_id": background_element_id,
        "element_ids": element_ids or [],
        "use_default_materials": use_default_materials,
    }
    for asset_id in request_context["attachment_ids"]:
        row = (
            get_db()
            .execute(
                "SELECT id FROM media_assets WHERE id=%s AND pipeline_id=%s",
                (asset_id, session["pipeline_id"]),
            )
            .fetchone()
        )
        if not row:
            raise ConversationError("attachment_not_found", "图片附件不存在或不属于当前流水线")
    command, created = conversation_store.reserve_command(
        session,
        client_request_id,
        source,
        content.strip(),
        request_context,
    )
    if not created:
        return _response(command)
    capability = get_capability(session["agent_id"])
    if not capability:
        command = update_command(
            command["id"],
            status="failed",
            outcome_code="capability_not_available",
            result={"reply": "该 Agent 的自然语言修改能力将在后续增量接入。"},
        )
        add_message(session_id, command["id"], "assistant", command["result"]["reply"])
        return _response(command)

    try:
        preview_context = previous_command
        if session["agent_id"] == "xiao_hai" and not previous_command:
            preview_context = command
        if previous_command and (selected_candidate_id or selected_schedule_id):
            selected_payload = {**(previous_command.get("payload") or {})}
            if selected_candidate_id:
                selected_payload["candidate_id"] = selected_candidate_id
            if selected_schedule_id:
                selected_payload["schedule_id"] = selected_schedule_id
            preview_context = {
                **previous_command,
                "payload": selected_payload,
            }
        # 新指令（非澄清续聊）时，selected_candidate_id 作为默认候选人上下文传入，
        # 指令未提及候选人时免去一轮澄清；显式点名仍然优先。
        default_candidate_id = "" if previous_command else selected_candidate_id
        preview_result = await capability.build_preview(
            session["pipeline_id"], content, source, preview_context, default_candidate_id
        )
        command = _save_preview(command, session, preview_result)
        if session["agent_id"] == "xiao_hai" and command["status"] == "awaiting_confirm":
            if previous_command:
                update_command(
                    previous_command["id"],
                    status="cancelled",
                    outcome_code="superseded_by_continuation",
                    result={"reply": "已由后续补充信息继续处理。"},
                )
            return _execute_command(command, session, capability)
        reply = command["result"]["reply"]
        add_message(session_id, command["id"], "assistant", reply)
        if previous_command and command["status"] != "failed":
            update_command(
                previous_command["id"],
                status="cancelled",
                outcome_code="superseded_by_continuation",
                result={"reply": "已由后续补充信息继续处理。"},
            )
        return _response(command)
    except ConversationError:
        raise
    except Exception as error:
        outcome_code, reply = _preview_failure(error)
        command = update_command(
            command["id"],
            status="failed",
            outcome_code=outcome_code,
            latest_data=_snapshot(session),
            result={"reply": reply},
        )
        add_message(session_id, command["id"], "assistant", reply)
        return _response(command)


def confirm_command(command_id: str, actor_id: str, preview_hash: str) -> dict:
    command = get_command(command_id)
    if not command:
        raise ConversationError("command_not_found", "命令不存在")
    session = _require_session(command["session_id"], actor_id)
    if command["status"] in {"queued", "running", "succeeded", "stale"}:
        return _response(command)
    if command["status"] != "awaiting_confirm":
        raise ConversationError("command_not_confirmable", "命令当前不可确认")
    if not preview_hash or preview_hash != command["preview_hash"]:
        raise ConversationError("preview_mismatch", "预览已变化，请重新发起命令")

    capability = get_capability(session["agent_id"])
    if not capability:
        raise ConversationError("capability_not_available", "该 Agent 的执行能力尚未接入")
    return _execute_command(command, session, capability)


def cancel_command(command_id: str, actor_id: str) -> dict:
    command = get_command(command_id)
    if not command:
        raise ConversationError("command_not_found", "命令不存在")
    session = _require_session(command["session_id"], actor_id)
    if command["status"] == "cancelled":
        return _response(command)
    if command["status"] not in PENDING_STATUSES:
        raise ConversationError("command_not_cancellable", "命令已结束，不能取消")
    reply = "操作已取消，业务数据未发生变化。"
    command = update_command(
        command_id,
        status="cancelled",
        outcome_code="cancelled_by_user",
        latest_data=_snapshot(session),
        result={**(command.get("result") or {}), "reply": reply},
    )
    return _response(command)


async def repreview_command(command_id: str, actor_id: str) -> dict:
    command = get_command(command_id)
    if not command:
        raise ConversationError("command_not_found", "命令不存在")
    session = _require_session(command["session_id"], actor_id)
    if command["status"] != "stale":
        raise ConversationError("command_not_repreviewable", "只有数据已变化的命令可以重新预览")
    capability = get_capability(session["agent_id"])
    if not capability:
        raise ConversationError("capability_not_available", "该 Agent 的预览能力尚未接入")

    update_command(command_id, status="previewing", outcome_code="")
    try:
        preview_result = await capability.build_preview(
            session["pipeline_id"], command["source_text"], command["source"], command
        )
        refreshed = _save_preview(command, session, preview_result)
        add_message(session["id"], command_id, "assistant", refreshed["result"]["reply"])
        return _response(refreshed)
    except Exception as error:
        outcome_code, reply = _preview_failure(error)
        failed = update_command(
            command_id,
            status="failed",
            outcome_code=outcome_code,
            latest_data=_snapshot(session),
            result={"reply": reply},
        )
        add_message(session["id"], command_id, "assistant", reply)
        return _response(failed)


def undo_command(command_id: str, actor_id: str) -> dict:
    command = get_command(command_id)
    if not command:
        raise ConversationError("command_not_found", "命令不存在")
    session = _require_session(command["session_id"], actor_id)
    if command["status"] == "undone":
        return _response(command)
    if command["status"] != "succeeded":
        raise ConversationError("command_not_undoable", "只有已完成操作可以撤销")
    capability = get_capability(session["agent_id"])
    if not capability or not capability.undo:
        raise ConversationError("undo_not_available", "该操作暂不支持撤销")

    with transaction() as conn:
        applied, undo_result, reply = capability.undo(conn, command)
        command = update_command(
            command_id,
            conn=conn,
            status="undone" if applied else "undo_failed",
            outcome_code="undo_success" if applied else "undo_conflict",
            result={**(command.get("result") or {}), **undo_result, "reply": reply},
        )
    command = update_command(command_id, latest_data=_snapshot(session))
    add_message(session["id"], command_id, "assistant", reply)
    return _response(command)
