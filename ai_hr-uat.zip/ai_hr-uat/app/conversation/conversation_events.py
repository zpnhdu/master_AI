"""会话命令的轻量 WebSocket 通知。"""

from fastapi import WebSocket

_subscribers: dict[str, set[WebSocket]] = {}


def subscribe(session_id: str, websocket: WebSocket) -> None:
    _subscribers.setdefault(session_id, set()).add(websocket)


def unsubscribe(session_id: str, websocket: WebSocket) -> None:
    subscribers = _subscribers.get(session_id)
    if not subscribers:
        return
    subscribers.discard(websocket)
    if not subscribers:
        _subscribers.pop(session_id, None)


async def publish(session_id: str, event: dict) -> None:
    disconnected = []
    for websocket in list(_subscribers.get(session_id, set())):
        try:
            await websocket.send_json(event)
        except Exception:
            disconnected.append(websocket)
    for websocket in disconnected:
        unsubscribe(session_id, websocket)
