"""统一 Agent 会话与命令账本的数据库持久化。"""

import json
import uuid
from typing import Optional

from app.db import get_db, transaction

_COMMAND_JSON_FIELDS = {"payload", "preview", "result", "latest_data"}
_COMMAND_UPDATE_FIELDS = {
    "intent",
    "status",
    "payload",
    "preview",
    "preview_hash",
    "result",
    "latest_data",
    "outcome_code",
}


def _parse_command(row) -> Optional[dict]:
    if not row:
        return None
    command = dict(row)
    for field in _COMMAND_JSON_FIELDS:
        raw_value = command.get(field)
        if isinstance(raw_value, str):
            try:
                command[field] = json.loads(raw_value)
            except (json.JSONDecodeError, TypeError):
                command[field] = {}
    return command


def ensure_session(pipeline_id: str, agent_id: str, actor_id: str) -> dict:
    """原子获取或创建指定流水线、Agent、操作者的活动会话。"""
    with transaction() as conn:
        row = conn.execute(
            """SELECT sessions.*
               FROM active_conversation_sessions active
               JOIN conversation_sessions sessions ON sessions.id = active.session_id
               WHERE active.pipeline_id=%s AND active.agent_id=%s AND active.actor_id=%s
                 AND sessions.status='active'""",
            (pipeline_id, agent_id, actor_id),
        ).fetchone()
        if row:
            return dict(row)

        session_id = f"session_{uuid.uuid4().hex}"
        conn.execute(
            """INSERT INTO conversation_sessions (id, pipeline_id, agent_id, actor_id)
               VALUES (%s, %s, %s, %s)""",
            (session_id, pipeline_id, agent_id, actor_id),
        )
        conn.execute(
            """INSERT INTO active_conversation_sessions
               (pipeline_id, agent_id, actor_id, session_id) VALUES (%s, %s, %s, %s)""",
            (pipeline_id, agent_id, actor_id, session_id),
        )
        row = conn.execute("SELECT * FROM conversation_sessions WHERE id=%s", (session_id,)).fetchone()
        return dict(row)


def get_session(session_id: str) -> Optional[dict]:
    row = get_db().execute("SELECT * FROM conversation_sessions WHERE id=%s", (session_id,)).fetchone()
    return dict(row) if row else None


def get_messages(session_id: str, limit: int = 100) -> list[dict]:
    rows = (
        get_db()
        .execute(
            """SELECT * FROM conversation_messages
           WHERE session_id=%s ORDER BY id DESC LIMIT %s""",
            (session_id, limit),
        )
        .fetchall()
    )
    messages = [dict(row) for row in reversed(rows)]
    for message in messages:
        attachments = (
            get_db()
            .execute(
                """SELECT assets.* FROM conversation_message_attachments links
                   JOIN media_assets assets ON assets.id=links.asset_id
                   WHERE links.message_id=%s ORDER BY assets.created_at, assets.id""",
                (message["id"],),
            )
            .fetchall()
        )
        message["attachments"] = []
        for asset in attachments:
            item = dict(asset)
            item["url"] = f"/api/xiao-hai/{item['pipeline_id']}/assets/{item['id']}"
            message["attachments"].append(item)
    return messages


def add_message(session_id: str, command_id: str, role: str, content: str, conn=None) -> int:
    database = conn or get_db()
    cursor = database.execute(
        """INSERT INTO conversation_messages (session_id, command_id, role, content)
           VALUES (%s, %s, %s, %s)""",
        (session_id, command_id, role, content),
    )
    if conn is None:
        database.commit()
    return cursor.lastrowid


def add_message_attachments(message_id: int, asset_ids: list[str], conn=None) -> None:
    database = conn or get_db()
    for asset_id in asset_ids:
        database.execute(
            """INSERT IGNORE INTO conversation_message_attachments (message_id, asset_id)
               VALUES (%s, %s)""",
            (message_id, asset_id),
        )
    if conn is None:
        database.commit()


def reserve_command(
    session: dict,
    client_request_id: str,
    source: str,
    source_text: str,
    request_payload: Optional[dict] = None,
) -> tuple[dict, bool]:
    """按 session + client_request_id 原子预留命令，并同时保存用户消息。"""
    with transaction() as conn:
        existing = conn.execute(
            """SELECT * FROM conversation_commands
               WHERE session_id=%s AND client_request_id=%s""",
            (session["id"], client_request_id),
        ).fetchone()
        if existing:
            return _parse_command(existing), False

        command_id = f"command_{uuid.uuid4().hex}"
        payload_value = (
            json.dumps({"request_context": request_payload}, ensure_ascii=False) if request_payload else "{}"
        )
        empty_json = "{}"
        conn.execute(
            """INSERT INTO conversation_commands
               (id, session_id, pipeline_id, agent_id, client_request_id, source, source_text, payload, preview, result, latest_data)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                command_id,
                session["id"],
                session["pipeline_id"],
                session["agent_id"],
                client_request_id,
                source,
                source_text,
                payload_value,
                empty_json,
                empty_json,
                empty_json,
            ),
        )
        message_id = add_message(session["id"], command_id, "user", source_text, conn=conn)
        add_message_attachments(message_id, (request_payload or {}).get("attachment_ids", []), conn=conn)
        row = conn.execute("SELECT * FROM conversation_commands WHERE id=%s", (command_id,)).fetchone()
        return _parse_command(row), True


def get_command(command_id: str) -> Optional[dict]:
    row = get_db().execute("SELECT * FROM conversation_commands WHERE id=%s", (command_id,)).fetchone()
    return _parse_command(row)


def get_commands(session_id: str, statuses: tuple[str, ...] = (), limit: int = 100) -> list[dict]:
    """按创建顺序读取会话命令，可限定状态。"""
    parameters: list[object] = [session_id]
    where = "session_id=%s"
    if statuses:
        placeholders = ",".join("%s" for _ in statuses)
        where += f" AND status IN ({placeholders})"
        parameters.extend(statuses)
    parameters.append(max(1, min(limit, 200)))
    rows = (
        get_db()
        .execute(
            f"SELECT * FROM conversation_commands WHERE {where} ORDER BY created_at, id LIMIT %s",
            parameters,
        )
        .fetchall()
    )
    return [_parse_command(row) for row in rows]


def update_command(command_id: str, conn=None, **updates) -> Optional[dict]:
    assignments = []
    values = []
    for field, value in updates.items():
        if field not in _COMMAND_UPDATE_FIELDS:
            continue
        if field in _COMMAND_JSON_FIELDS:
            value = json.dumps(value, ensure_ascii=False)
        assignments.append(f"{field}=%s")
        values.append(value)
    if not assignments:
        return get_command(command_id)

    if updates.get("status") == "succeeded":
        assignments.append("executed_at=NOW()")
    assignments.append("updated_at=NOW()")
    values.append(command_id)
    database = conn or get_db()
    database.execute(f"UPDATE conversation_commands SET {', '.join(assignments)} WHERE id=%s", values)
    if conn is None:
        database.commit()
        return get_command(command_id)
    row = database.execute("SELECT * FROM conversation_commands WHERE id=%s", (command_id,)).fetchone()
    return _parse_command(row)
