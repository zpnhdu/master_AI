"""``app/conversation_capabilities.py``、``app/conversation_store.py``、``app/conversation_service.py``、``app/conversation_events.py``（目录整理）。

原 ``app/``app/conversation_capabilities.py``, ``app/conversation_store.py``, ``app/conversation_service.py``, ``app/conversation_events.py```` 按 ``docs/directory-reorganization-plan.md`` 归入本包，
实现原样保留。旧导入路径 ``from app.X import y`` / ``from app import X`` /
``import app.X`` 经 sys.modules 别名与 app 包属性注册保持兼容。
"""

import importlib
import sys

_MODULES = (
    # 顺序约束：conversation_service 顶层 import capabilities / store
    "conversation_capabilities",
    "conversation_store",
    "conversation_service",
    "conversation_events",
)

import app as _app_pkg  # noqa: E402

for _name in _MODULES:
    _mod = importlib.import_module("app.conversation." + _name)
    # app.X 旧路径别名：指向同一模块对象，monkeypatch / 属性访问语义不变
    sys.modules.setdefault("app." + _name, _mod)
    setattr(sys.modules[__name__], _name, _mod)
    setattr(_app_pkg, _name, _mod)

__all__ = list(_MODULES)
