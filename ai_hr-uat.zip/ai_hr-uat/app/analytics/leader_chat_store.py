"""Persistence helpers for tenant-scoped leader analytics conversations."""

from __future__ import annotations

import hashlib
import json
import uuid

from app.db import get_db, transaction

LEASE_SECONDS = 120
PUBLIC_FAILURE_MESSAGE = "本次分析暂时无法完成，请稍后重试"


def _json(value, fallback):
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed
        except (TypeError, json.JSONDecodeError):
            return fallback
    return value if value is not None else fallback


def _request_payload_hash(message: str) -> str:
    return hashlib.sha256(message.encode("utf-8")).hexdigest()


def create_session(tenant_id: str, actor_user_id: str) -> dict:
    session_id = f"leader_session_{uuid.uuid4().hex}"
    with transaction() as conn:
        conn.execute(
            """INSERT INTO leader_chat_sessions (id, tenant_id, actor_user_id)
               VALUES (%s, %s, %s)""",
            (session_id, tenant_id, actor_user_id),
        )
        row = conn.execute("SELECT * FROM leader_chat_sessions WHERE id=%s", (session_id,)).fetchone()
    return dict(row)


def get_session_for_actor(session_id: str, tenant_id: str, actor_user_id: str) -> dict | None:
    row = (
        get_db()
        .execute(
            """SELECT * FROM leader_chat_sessions
           WHERE id=%s AND tenant_id=%s AND actor_user_id=%s""",
            (session_id, tenant_id, actor_user_id),
        )
        .fetchone()
    )
    return dict(row) if row else None


def list_active_sessions(tenant_id: str, actor_user_id: str, limit: int = 20) -> list[dict]:
    rows = (
        get_db()
        .execute(
            """SELECT * FROM leader_chat_sessions
           WHERE tenant_id=%s AND actor_user_id=%s AND status='active'
           ORDER BY updated_at DESC, id DESC LIMIT %s""",
            (tenant_id, actor_user_id, max(1, min(limit, 100))),
        )
        .fetchall()
    )
    return [dict(row) for row in rows]


def archive_session(session_id: str, tenant_id: str, actor_user_id: str) -> dict | None:
    with transaction() as conn:
        row = conn.execute(
            """SELECT * FROM leader_chat_sessions
               WHERE id=%s AND tenant_id=%s AND actor_user_id=%s""",
            (session_id, tenant_id, actor_user_id),
        ).fetchone()
        if not row:
            return None
        if row["status"] == "active":
            conn.execute(
                """UPDATE leader_chat_sessions
                   SET status='archived', archived_at=NOW(), updated_at=NOW()
                   WHERE id=%s AND status='active'""",
                (session_id,),
            )
        row = conn.execute("SELECT * FROM leader_chat_sessions WHERE id=%s", (session_id,)).fetchone()
    return dict(row)


def list_messages(session_id: str, limit: int = 100) -> list[dict]:
    rows = (
        get_db()
        .execute(
            """SELECT * FROM leader_chat_messages
           WHERE session_id=%s ORDER BY id DESC LIMIT %s""",
            (session_id, max(1, min(limit, 200))),
        )
        .fetchall()
    )
    messages = [dict(row) for row in reversed(rows)]
    for message in messages:
        for field in ("tool_calls", "tool_results", "chart_spec"):
            message[field] = _json(message.get(field), [] if field != "chart_spec" else {})
    return messages


def reserve_request(
    session: dict,
    client_request_id: str,
    message: str,
) -> tuple[dict, bool]:
    """Reserve an idempotent request and lease it to the winning caller."""
    request_id = f"leader_request_{uuid.uuid4().hex}"
    lease_token = uuid.uuid4().hex
    request_hash = _request_payload_hash(message)
    with transaction() as conn:
        try:
            conn.execute(
                """INSERT INTO leader_chat_requests
                   (id, session_id, client_request_id, message, status,
                    response_text, response_chart, error_code_internal,
                    error_message_internal, public_error_message,
                    started_at, lease_token, lease_expires_at)
                   VALUES (%s, %s, %s, %s, 'running', '', '{}', '', '', '',
                           NOW(), %s, DATE_ADD(NOW(), INTERVAL 120 SECOND))""",
                (request_id, session["id"], client_request_id, message, lease_token),
            )
            conn.execute(
                """UPDATE leader_chat_sessions SET updated_at=NOW() WHERE id=%s""",
                (session["id"],),
            )
            row = conn.execute("SELECT * FROM leader_chat_requests WHERE id=%s", (request_id,)).fetchone()
            result = dict(row)
            result["request_hash"] = request_hash
            return result, True
        except Exception as exc:
            if "unique" not in str(exc).lower() and "duplicate" not in str(exc).lower():
                raise
            row = conn.execute(
                """SELECT * FROM leader_chat_requests
                   WHERE session_id=%s AND client_request_id=%s""",
                (session["id"], client_request_id),
            ).fetchone()
            if not row:
                raise
            result = dict(row)
            result["response_chart"] = _json(result.get("response_chart"), {})
            result["request_hash"] = _request_payload_hash(str(result.get("message") or ""))
            result["same_payload"] = result["request_hash"] == request_hash
            return result, False


def try_takeover_expired(request_id: str) -> dict | None:
    new_token = uuid.uuid4().hex
    with transaction() as conn:
        cursor = conn.execute(
            """UPDATE leader_chat_requests
               SET lease_token=%s, lease_expires_at=DATE_ADD(NOW(), INTERVAL 120 SECOND), started_at=NOW(), status='running'
               WHERE id=%s AND status='running' AND lease_expires_at IS NOT NULL
                 AND lease_expires_at < NOW()""",
            (new_token, request_id),
        )
        if cursor.rowcount != 1:
            return None
        row = conn.execute("SELECT * FROM leader_chat_requests WHERE id=%s", (request_id,)).fetchone()
    return dict(row)


def update_request_result(
    request_id: str,
    lease_token: str,
    status: str,
    response_text: str = "",
    response_chart: dict | None = None,
    error_code_internal: str = "",
    error_message_internal: str = "",
    public_error_message: str = PUBLIC_FAILURE_MESSAGE,
) -> bool:
    if status not in {"succeeded", "failed"}:
        raise ValueError("invalid leader request terminal status")
    chart_json = json.dumps(response_chart or {}, ensure_ascii=False)
    with transaction() as conn:
        cursor = conn.execute(
            """UPDATE leader_chat_requests
               SET status=%s, response_text=%s, response_chart=%s, error_code_internal=%s,
                   error_message_internal=%s, public_error_message=%s, completed_at=NOW(),
                   lease_expires_at=NULL
               WHERE id=%s AND status='running' AND lease_token=%s""",
            (
                status,
                response_text,
                chart_json,
                error_code_internal,
                error_message_internal,
                public_error_message,
                request_id,
                lease_token,
            ),
        )
    return cursor.rowcount == 1


def _insert_messages(
    conn,
    session_id: str,
    request_id: str,
    user_message: str,
    assistant_message: str,
    tool_calls: list | None = None,
    tool_results: list | None = None,
    chart_spec: dict | None = None,
) -> None:
    conn.execute(
        """INSERT INTO leader_chat_messages
           (session_id, request_id, role, content, tool_calls, tool_results, chart_spec)
           VALUES (%s, %s, 'user', %s, '[]', '[]', '{}')""",
        (session_id, request_id, user_message),
    )
    conn.execute(
        """INSERT INTO leader_chat_messages
           (session_id, request_id, role, content, tool_calls, tool_results, chart_spec)
           VALUES (%s, %s, 'assistant', %s, %s, %s, %s)""",
        (
            session_id,
            request_id,
            assistant_message,
            json.dumps(tool_calls or [], ensure_ascii=False),
            json.dumps(tool_results or [], ensure_ascii=False),
            json.dumps(chart_spec or {}, ensure_ascii=False),
        ),
    )
    conn.execute("UPDATE leader_chat_sessions SET updated_at=NOW() WHERE id=%s", (session_id,))


def complete_request_with_messages(
    request_id: str,
    lease_token: str,
    session_id: str,
    user_message: str,
    assistant_message: str,
    tool_calls: list | None = None,
    tool_results: list | None = None,
    chart_spec: dict | None = None,
) -> bool:
    """Commit the terminal response and its history only for the active lease owner."""
    chart_json = json.dumps(chart_spec or {}, ensure_ascii=False)
    with transaction() as conn:
        cursor = conn.execute(
            """UPDATE leader_chat_requests
               SET status='succeeded', response_text=%s, response_chart=%s,
                   completed_at=NOW(), lease_expires_at=NULL
               WHERE id=%s AND status='running' AND lease_token=%s""",
            (assistant_message, chart_json, request_id, lease_token),
        )
        if cursor.rowcount != 1:
            return False
        _insert_messages(
            conn,
            session_id,
            request_id,
            user_message,
            assistant_message,
            tool_calls,
            tool_results,
            chart_spec,
        )
    return True


def get_request(request_id: str) -> dict | None:
    row = get_db().execute("SELECT * FROM leader_chat_requests WHERE id=%s", (request_id,)).fetchone()
    if not row:
        return None
    result = dict(row)
    result["response_chart"] = _json(result.get("response_chart"), {})
    return result
