"""Allow-listed, tenant-scoped analytics tools for leader chat."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Callable

from app.db import (
    get_dashboard_extra,
    get_funnel_data_for_user,
    get_owner_overview_for_user,
    get_role_overview_for_user,
    get_talent_pool_growth,
)

Handler = Callable[[str, str, dict], dict]


def _json_safe(value):
    """Normalize SQL driver types so results can be JSON-serialized anywhere.

    pymysql returns Decimal for aggregates; the same dict later feeds LLM
    prompts and history persistence, which both require plain JSON types.
    """
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


@dataclass(frozen=True)
class ToolDefinition:
    name: str
    description: str
    handler: Handler


def _funnel(user_id: str, tenant_id: str, args: dict) -> dict:
    return get_funnel_data_for_user(user_id, tenant_id, include_all=True)


def _roles(user_id: str, tenant_id: str, args: dict) -> dict:
    return {"items": get_role_overview_for_user(user_id, tenant_id, include_all=True)}


def _dashboard_extra(user_id: str, tenant_id: str, args: dict) -> dict:
    return get_dashboard_extra(user_id, tenant_id, include_all=True)


def _owners(user_id: str, tenant_id: str, args: dict) -> dict:
    return {"items": get_owner_overview_for_user(user_id, tenant_id, include_all=True)}


def _talent_pool(user_id: str, tenant_id: str, args: dict) -> dict:
    # 与领导数据舱「人才库增长趋势」面板同口径：当前租户简历总量。
    return get_talent_pool_growth(tenant_id)


TOOL_REGISTRY: dict[str, ToolDefinition] = {
    "recruiting_overview": ToolDefinition(
        "recruiting_overview", "招聘总览，包括岗位、候选人、完成率和平均评分", _funnel
    ),
    "role_overview": ToolDefinition("role_overview", "按岗位聚合候选人和面试通过情况", _roles),
    "dashboard_extra": ToolDefinition("dashboard_extra", "漏斗、渠道、周统计、趋势和实时面试数据", _dashboard_extra),
    "owner_overview": ToolDefinition("owner_overview", "按 HR 负责人对比岗位、候选人和录用转化率", _owners),
    "talent_pool_overview": ToolDefinition("talent_pool_overview", "人才库简历总量（当前租户简历数）", _talent_pool),
}


def tool_descriptions() -> list[dict[str, str]]:
    return [{"name": item.name, "description": item.description} for item in TOOL_REGISTRY.values()]


ALLOWED_ARG_KEYS = {"from", "to"}


def validate_tool_calls(raw_calls: object) -> list[dict]:
    if not isinstance(raw_calls, list) or not 1 <= len(raw_calls) <= 3:
        raise ValueError("tool_calls must contain one to three items")
    calls: list[dict] = []
    names: set[str] = set()
    for item in raw_calls:
        if not isinstance(item, dict) or set(item) - {"name", "args"}:
            raise ValueError("invalid tool call shape")
        name = item.get("name")
        if name not in TOOL_REGISTRY or name in names:
            raise ValueError("unknown or duplicate tool")
        args = item.get("args", {})
        if not isinstance(args, dict):
            raise ValueError("invalid tool arguments")
        # 工具本身不接收业务参数（时间范围由系统统一口径），模型偶尔会
        # 自行添加 time_range 等字段，直接拒绝会让可用问题整体失败，因此
        # 仅保留受支持键、丢弃未知键，names 白名单与结构校验仍严格不变。
        clean_args = {key: value for key, value in args.items() if key in ALLOWED_ARG_KEYS and isinstance(value, str)}
        names.add(name)
        calls.append({"name": name, "args": clean_args})
    return calls


def execute_tool_calls(user_id: str, tenant_id: str, calls: list[dict]) -> list[dict]:
    results = []
    for call in calls:
        definition = TOOL_REGISTRY[call["name"]]
        try:
            data = _json_safe(definition.handler(user_id, tenant_id, call["args"]))
            results.append({"name": call["name"], "ok": True, "data": data})
        except Exception:
            results.append({"name": call["name"], "ok": False, "data": None})
    return results
