"""Leader analytics chat orchestration, validation and response shaping."""

from __future__ import annotations

import asyncio
import json
import math
import os
import re
from collections.abc import AsyncGenerator
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline
from app.leader_chat_store import (
    PUBLIC_FAILURE_MESSAGE,
    complete_request_with_messages,
    list_messages,
    reserve_request,
    try_takeover_expired,
    update_request_result,
)
from app.leader_chat_tools import execute_tool_calls, tool_descriptions, validate_tool_calls
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput

MAX_CONTEXT_MESSAGES = 10
MAX_CONTEXT_CHARS = 12000
MAX_CHART_BYTES = 32768
MAX_CHART_POINTS = 50

# 统一的不支持回绝文案，附带可问方向，避免一句生硬的“不支持”让用户摸不着头脑。
UNSUPPORTED_REPLY = "当前暂不支持这类数据。你可以询问招聘总览、岗位对比、招聘漏斗、HR 转化率对比或人才库简历总量。"


class LeaderChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    session_id: str = Field(min_length=1, max_length=128)
    message: str = Field(min_length=1, max_length=2000)
    client_request_id: str = Field(min_length=1, max_length=128)


def _compact_context(messages: list[dict]) -> list[dict]:
    context: list[dict] = []
    total = 0
    for message in reversed(messages):
        content = str(message.get("content") or "")
        if not content:
            continue
        if total + len(content) > MAX_CONTEXT_CHARS:
            break
        context.append({"role": message.get("role", "assistant"), "content": content})
        total += len(content)
    return list(reversed(context))


def _json_data(value: Any) -> dict:
    return value if isinstance(value, dict) else {}


def _contains_number(value: str) -> bool:
    return bool(re.search(r"(?:\d|\d+[年月日天周小时分钟秒%％]|人民币|万元|美元|¥|＄|\$)", value))


def _validate_chart(value: Any) -> dict | None:
    if not isinstance(value, dict) or value.get("kind") not in {"line", "bar", "pie", "radar"}:
        return None
    try:
        if len(json.dumps(value, ensure_ascii=False).encode("utf-8")) > MAX_CHART_BYTES:
            return None
    except (TypeError, ValueError):
        return None
    allowed_common = {"kind", "title"}
    title = value.get("title", "")
    if not isinstance(title, str) or len(title) > 100:
        return None
    kind = value["kind"]
    if kind in {"line", "bar"}:
        if set(value) - allowed_common - {"categories", "series"}:
            return None
        categories = value.get("categories")
        series = value.get("series")
        if not isinstance(categories, list) or not isinstance(series, list) or not series:
            return None
        if len(categories) > MAX_CHART_POINTS or any(not isinstance(item, str) for item in categories):
            return None
        normalized = []
        for item in series:
            if not isinstance(item, dict) or set(item) - {"name", "values", "unit"}:
                return None
            if not isinstance(item.get("name"), str) or not isinstance(item.get("values"), list):
                return None
            values = item["values"]
            if len(values) != len(categories) or len(values) > MAX_CHART_POINTS:
                return None
            if any(
                not isinstance(number, (int, float)) or isinstance(number, bool) or not math.isfinite(number)
                for number in values
            ):
                return None
            unit = item.get("unit")
            if unit is not None and (not isinstance(unit, str) or len(unit) > 20):
                return None
            normalized.append({"name": item["name"], "values": values, **({"unit": unit} if unit else {})})
        return {"kind": kind, "title": title, "categories": categories, "series": normalized}
    if kind == "pie":
        if set(value) - allowed_common - {"items"}:
            return None
        items = value.get("items")
        if not isinstance(items, list) or len(items) > MAX_CHART_POINTS:
            return None
        normalized = []
        for item in items:
            if not isinstance(item, dict) or set(item) != {"name", "value"}:
                return None
            if (
                not isinstance(item["name"], str)
                or not isinstance(item["value"], (int, float))
                or isinstance(item["value"], bool)
            ):
                return None
            if not math.isfinite(item["value"]):
                return None
            normalized.append(item)
        return {"kind": "pie", "title": title, "items": normalized}
    if set(value) - allowed_common - {"indicators", "series"}:
        return None
    indicators = value.get("indicators")
    series = value.get("series")
    if not isinstance(indicators, list) or not isinstance(series, list) or not series:
        return None
    if len(indicators) > MAX_CHART_POINTS:
        return None
    normalized_indicators = []
    for item in indicators:
        if not isinstance(item, dict) or set(item) != {"name", "max"}:
            return None
        if (
            not isinstance(item["name"], str)
            or not isinstance(item["max"], (int, float))
            or isinstance(item["max"], bool)
        ):
            return None
        if not math.isfinite(item["max"]):
            return None
        normalized_indicators.append(item)
    normalized_series = []
    for item in series:
        if not isinstance(item, dict) or set(item) - {"name", "values"}:
            return None
        values = item.get("values")
        if not isinstance(item.get("name"), str) or not isinstance(values, list) or len(values) != len(indicators):
            return None
        if any(
            not isinstance(number, (int, float)) or isinstance(number, bool) or not math.isfinite(number)
            for number in values
        ):
            return None
        normalized_series.append({"name": item["name"], "values": values})
    return {"kind": "radar", "title": title, "indicators": normalized_indicators, "series": normalized_series}


async def _call_json(prompt: str, system: str, timeout: float = 55.0) -> dict:
    deadline = TimeoutDeadline(timeout, agent_id="leader_analytics")
    agent = BaseAgent()
    output = await agent.run_with_deadline(
        ToolInput(
            pipeline_id="leader_analytics",
            params={
                "raw_prompt": prompt,
                "raw_system": system,
                "model": "qwen3.6-flash",
                "timeout": timeout,
                "temperature": 0.2,
                "json_mode": True,
                "agent_id": "leader_analytics",
                "operation": "leader_chat",
                # qwen3.6-flash 是推理模型，默认先产出 reasoning_content；意图路由只是
                # 分类任务，关闭思考可把首帧延迟从数秒降到亚秒级。
                "enable_thinking": False,
            },
        ),
        deadline,
    )
    if output.status != AgentStatus.SUCCESS or not isinstance(output.data, dict):
        raise RuntimeError(output.error or "leader analytics LLM call failed")
    return output.data


def _stream_llm_config() -> tuple[str, str]:
    """流式调用只连主网关：OPENAI_API_BASE/OPENAI_API_KEY 优先，缺失时复用 DASHSCOPE_*。"""
    from hermes_wrapper.client import DEFAULT_WORKSPACE_API_BASE

    api_base = (os.getenv("OPENAI_API_BASE") or DEFAULT_WORKSPACE_API_BASE).strip().rstrip("/")
    api_key = os.getenv("OPENAI_API_KEY", "").strip() or os.getenv("DASHSCOPE_API_KEY", "").strip()
    return api_base, api_key


async def _stream_text(
    system: str,
    prompt: str,
    model: str = "qwen3.6-flash",
) -> AsyncGenerator[str, None]:
    """OpenAI 兼容网关的 SSE 流式调用，逐段产出 delta 文本。

    仅在 leader_chat 内使用，复刻 knowledge.py 的 aiohttp 流式路径（含 ThreadedResolver
    规避本机 DNS 解析异常）。usage 通过 stream_options.include_usage 收集并按真实值记账。
    """
    import time as _time

    from aiohttp import ClientSession, ClientTimeout, TCPConnector
    from aiohttp.resolver import ThreadedResolver

    from app.audit.token_tracker import record_usage

    api_base, api_key = _stream_llm_config()
    if not api_key:
        raise RuntimeError("leader analytics streaming API key not configured")

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
        "stream": True,
        "temperature": 0.2,
        "stream_options": {"include_usage": True},
        # 洞察/闲聊是短文本总结，无需推理模型思考，关闭后首字延迟大幅下降。
        "enable_thinking": False,
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    url = f"{api_base}/chat/completions"
    start = _time.time()
    usage: dict = {}
    completed = False

    connector = TCPConnector(resolver=ThreadedResolver())
    try:
        async with ClientSession(connector=connector, timeout=ClientTimeout(total=60)) as session:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    body = (await resp.text())[:200]
                    raise RuntimeError(f"AI 服务返回错误 ({resp.status}): {body}")
                async for line in resp.content:
                    line_text = line.decode("utf-8").strip()
                    if not line_text or line_text.startswith(":"):
                        continue
                    if line_text == "data: [DONE]":
                        completed = True
                        break
                    if not line_text.startswith("data: "):
                        continue
                    try:
                        chunk = json.loads(line_text[6:])
                    except json.JSONDecodeError:
                        continue
                    if isinstance(chunk, dict) and isinstance(chunk.get("usage"), dict):
                        usage = chunk["usage"]
                    choices = chunk.get("choices") or []
                    if choices:
                        delta = choices[0].get("delta") or {}
                        content = delta.get("content")
                        if content:
                            yield content
    finally:
        await connector.close()
        await asyncio.to_thread(
            record_usage,
            model=model,
            token_usage=usage if completed else {},
            agent="leader_analytics",
            operation="leader_chat_stream",
            pipeline_id="leader_analytics",
            latency_ms=int((_time.time() - start) * 1000),
            success=completed,
        )


def _chat_stream_system() -> str:
    return (
        "你是招聘系统中的日常对话助手。只回答日常闲聊，不生成任何招聘业务数字。"
        "直接输出自然语言回答，不要 Markdown、不要 JSON、不要引用任何数据。"
    )


def _insight_stream_system() -> str:
    return (
        "你是招聘数据分析总结助手。只写定性观察，直接输出一段简短的分析文字，"
        "不要 Markdown、不要 JSON，不得输出任何数字、百分号、日期、金额或自行推算的数据；"
        "数字结论由系统另行提供。"
    )


def _intent_system() -> str:
    tools = "\n".join(f"- {item['name']}: {item['description']}" for item in tool_descriptions())
    return (
        "你是招聘数据分析路由器。只能输出 JSON，不要输出 Markdown。"
        '与招聘数据无关的问题输出 {"mode":"chat","tool_calls":[]}。'
        '招聘数据问题必须输出 {"mode":"analytics","tool_calls":[{"name":工具名,"args":{}}]}。'
        "args 必须恒为空对象 {}，禁止添加 time_range、from、to 或任何时间/筛选参数，统计时间范围由系统统一决定。"
        "tool_calls 最多3个且同一工具最多一次。未提供的内部数据（费用、薪资、token等）不能假装支持，输出 chat 模式让上层提示不支持。"
        f"\n可用工具：\n{tools}"
    )


def _unsupported_question(message: str) -> bool:
    lowered = message.lower()
    return any(word in lowered for word in ("token", "费用", "成本", "薪资总额"))


def _deterministic_text(results: list[dict], message: str) -> str:
    parts: list[str] = []
    for result in results:
        if not result.get("ok"):
            parts.append("该项数据暂时不可用")
            continue
        name = result["name"]
        data = _json_data(result.get("data"))
        if name == "recruiting_overview":
            total = int(data.get("total_candidates") or 0)
            pipelines = int(data.get("total_pipelines") or 0)
            completed = int(data.get("completed_pipelines") or 0)
            rate = data.get("completion_rate", 0)
            parts.append(
                f"当前租户共有 {pipelines} 个岗位、{total} 位候选人，已完成岗位 {completed} 个，完成率 {rate}%。"
            )
        elif name == "owner_overview":
            items = data.get("items") or []
            if items:
                top = items[0]
                parts.append(
                    f"按录用转化率看，{top.get('owner_name', '未知 HR')} 当前最高，转化率 {top.get('conversion_rate', 0)}%，"
                    f"覆盖 {top.get('candidate_count', 0)} 位候选人。"
                )
            else:
                parts.append("当前租户暂无可用于 HR 对比的招聘数据。")
        elif name == "role_overview":
            items = data.get("items") or []
            parts.append(f"当前租户共有 {len(items)} 类岗位有有效面试数据。")
        elif name == "dashboard_extra":
            summary = _json_data(data.get("summary_extra"))
            parts.append(
                f"最近一周新增候选人 {summary.get('weekly_new', 0)} 人、面试 {summary.get('weekly_interviews', 0)} 场、面试通过 {summary.get('weekly_interview_passed', 0)} 人。"
            )
        elif name == "talent_pool_overview":
            summary = _json_data(data.get("summary"))
            parts.append(f"当前租户人才库共有 {int(summary.get('total') or 0)} 份简历。")
    if not parts:
        return "当前暂时没有可用的招聘数据。"
    return "".join(parts) + " 数据口径：当前登录管理员所属租户内的全量招聘数据，实时查询。"


def _chart_from_results(results: list[dict]) -> dict | None:
    for result in results:
        if not result.get("ok"):
            continue
        data = _json_data(result.get("data"))
        if result["name"] == "owner_overview":
            items = data.get("items") or []
            chart = {
                "kind": "bar",
                "title": "各 HR 录用转化率",
                "categories": [str(item.get("owner_name", "未知 HR")) for item in items[:MAX_CHART_POINTS]],
                "series": [
                    {
                        "name": "转化率",
                        "values": [float(item.get("conversion_rate") or 0) for item in items[:MAX_CHART_POINTS]],
                        "unit": "%",
                    }
                ],
            }
            return _validate_chart(chart)
        if result["name"] == "dashboard_extra":
            trend = _json_data(data.get("summary_extra")).get("daily_trend") or {}
            chart = {
                "kind": "line",
                "title": "近 30 天招聘趋势",
                "categories": list(trend.get("days") or [])[:MAX_CHART_POINTS],
                "series": [
                    {"name": "投递", "values": list(trend.get("applied") or [])[:MAX_CHART_POINTS]},
                    {"name": "筛选通过", "values": list(trend.get("screened") or [])[:MAX_CHART_POINTS]},
                    {"name": "面试", "values": list(trend.get("interviewed") or [])[:MAX_CHART_POINTS]},
                    {"name": "面试通过", "values": list(trend.get("interview_passed") or [])[:MAX_CHART_POINTS]},
                ],
            }
            return _validate_chart(chart)
    return None


async def _process_message(
    user_id: str, tenant_id: str, message: str, context: list[dict]
) -> tuple[str, dict | None, list[dict], list[dict]]:
    if _unsupported_question(message):
        return UNSUPPORTED_REPLY, None, [], []
    intent_prompt = json.dumps({"message": message, "history": context}, ensure_ascii=False)
    intent = await _call_json(intent_prompt, _intent_system())
    mode = intent.get("mode")
    raw_calls = intent.get("tool_calls", [])
    if mode == "chat":
        if raw_calls:
            return UNSUPPORTED_REPLY, None, [], []
        chat = await _call_json(
            json.dumps({"message": message, "history": context}, ensure_ascii=False),
            '你是招聘系统中的日常对话助手。只回答日常闲聊，不生成任何招聘业务数字；只输出 JSON {"insight":"..."}。',
        )
        insight = str(chat.get("insight") or "")
        if not insight or _contains_number(insight):
            insight = "好的，我可以陪你聊聊；涉及招聘数据时请直接询问可用的看板指标。"
        return insight, None, [], []
    if mode != "analytics":
        return UNSUPPORTED_REPLY, None, [], []
    try:
        calls = validate_tool_calls(raw_calls)
    except ValueError:
        return UNSUPPORTED_REPLY, None, [], []
    results = execute_tool_calls(user_id, tenant_id, calls)
    numeric_text = _deterministic_text(results, message)
    insight_result = await _call_json(
        json.dumps({"question": message, "data": results}, ensure_ascii=False),
        '你是招聘数据分析总结助手。只能输出 JSON {"insight":"..."}。只写定性观察，不得输出任何数字、百分号、日期、金额或自行推算的数据；数字结论由系统另行提供。',
    )
    insight = str(insight_result.get("insight") or "")
    if not insight or _contains_number(insight):
        insight = "详见上方数据，建议结合岗位和 HR 维度进一步比较。"
    chart = _chart_from_results(results)
    return numeric_text + insight, chart, calls, results


async def handle_leader_chat(user_id: str, tenant_id: str, request: LeaderChatRequest) -> dict:
    session = __import__("app.leader_chat_store", fromlist=["get_session_for_actor"]).get_session_for_actor(
        request.session_id, tenant_id, user_id
    )
    if not session:
        raise LookupError("session not found")
    if session.get("status") != "active":
        raise ValueError("session archived")

    reserved, owner = reserve_request(session, request.client_request_id, request.message)
    if not owner:
        if not reserved.get("same_payload"):
            raise ValueError("client request id already used")
        if reserved.get("status") == "succeeded":
            replay_chart = reserved.get("response_chart")
            if not isinstance(replay_chart, dict) or not replay_chart:
                replay_chart = None
            return {
                "text": reserved.get("response_text") or "",
                "chart": replay_chart,
                "status": "succeeded",
                "request_id": reserved.get("id"),
            }
        if reserved.get("status") == "failed":
            return {
                "text": reserved.get("public_error_message") or PUBLIC_FAILURE_MESSAGE,
                "status": "failed",
                "request_id": reserved.get("id"),
            }
        if reserved.get("lease_expires_at"):
            taken = try_takeover_expired(str(reserved["id"]))
            if taken:
                reserved = taken
                owner = True
        if not owner:
            return {"text": "正在分析，请稍候", "status": "processing", "request_id": reserved.get("id")}

    request_id = str(reserved["id"])
    lease_token = str(reserved.get("lease_token") or "")
    previous = _compact_context(list_messages(request.session_id, MAX_CONTEXT_MESSAGES))
    try:
        text, chart, calls, results = await asyncio.wait_for(
            _process_message(user_id, tenant_id, request.message, previous), timeout=60
        )
        if not complete_request_with_messages(
            request_id,
            lease_token,
            request.session_id,
            request.message,
            text,
            calls,
            results,
            chart,
        ):
            return {"text": text, "chart": chart, "status": "succeeded", "request_id": request_id}
        return {"text": text, "chart": chart, "status": "succeeded", "request_id": request_id}
    except (asyncio.TimeoutError, BusinessTimeoutError) as exc:
        update_request_result(
            request_id, lease_token, "failed", error_code_internal="timeout", error_message_internal=str(exc)
        )
        return {"text": PUBLIC_FAILURE_MESSAGE, "status": "failed", "request_id": request_id}
    except Exception as exc:
        update_request_result(
            request_id, lease_token, "failed", error_code_internal="internal_error", error_message_internal=str(exc)
        )
        return {"text": PUBLIC_FAILURE_MESSAGE, "status": "failed", "request_id": request_id}


async def stream_leader_chat(
    user_id: str,
    tenant_id: str,
    request: LeaderChatRequest,
    session: dict,
    reserved: dict,
) -> AsyncGenerator[dict, None]:
    """流式版 leader chat 编排：首帧发确定性数字+图表，随后逐字发 insight/闲聊。

    幂等与持久化复用 leader_chat_store：调用方负责 reserve_request（拿到 reserved 与
    租约）与重放判定；本生成器只负责在拿到 owner 租约后产出事件，并在结束时
    complete_request_with_messages、失败时 update_request_result(failed)。
    """
    request_id = str(reserved["id"])
    lease_token = str(reserved.get("lease_token") or "")
    message = request.message
    previous = _compact_context(list_messages(request.session_id, MAX_CONTEXT_MESSAGES))
    final_text = ""
    chart: dict | None = None
    calls: list[dict] = []
    results: list[dict] = []

    try:
        # 1. 不支持的问题：确定性短答复，不调工具。
        if _unsupported_question(message):
            final_text = UNSUPPORTED_REPLY
            yield {"phase": "data", "text": final_text, "chart": None}
            complete_request_with_messages(
                request_id, lease_token, request.session_id, message, final_text, [], [], None
            )
            yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": None}
            return

        # 2. 意图路由（仍需先拿到完整 mode / tool_calls 才能决定路径）。
        intent_prompt = json.dumps({"message": message, "history": previous}, ensure_ascii=False)
        intent = await _call_json(intent_prompt, _intent_system())
        mode = intent.get("mode")
        raw_calls = intent.get("tool_calls", [])

        if mode == "chat":
            if raw_calls:
                final_text = UNSUPPORTED_REPLY
                yield {"phase": "data", "text": final_text, "chart": None}
                complete_request_with_messages(
                    request_id, lease_token, request.session_id, message, final_text, [], [], None
                )
                yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": None}
                return
            # 闲聊：首帧空数据，随后逐字流式。
            yield {"phase": "data", "text": "", "chart": None}
            insight_parts: list[str] = []
            chat_prompt = json.dumps({"message": message, "history": previous}, ensure_ascii=False)
            async for token in _stream_text(_chat_stream_system(), chat_prompt):
                insight_parts.append(token)
                yield {"content": token}
            insight = "".join(insight_parts).strip()
            if not insight:
                insight = "好的，我可以陪你聊聊；涉及招聘数据时请直接询问可用的看板指标。"
                yield {"content": insight}
            final_text = insight
            complete_request_with_messages(
                request_id, lease_token, request.session_id, message, final_text, [], [], None
            )
            yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": None}
            return

        if mode != "analytics":
            final_text = UNSUPPORTED_REPLY
            yield {"phase": "data", "text": final_text, "chart": None}
            complete_request_with_messages(
                request_id, lease_token, request.session_id, message, final_text, [], [], None
            )
            yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": None}
            return

        # 3. analytics：执行工具 → 确定性数字文本 + 图表作为首帧。
        try:
            calls = validate_tool_calls(raw_calls)
        except ValueError:
            final_text = UNSUPPORTED_REPLY
            yield {"phase": "data", "text": final_text, "chart": None}
            complete_request_with_messages(
                request_id, lease_token, request.session_id, message, final_text, [], [], None
            )
            yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": None}
            return
        results = execute_tool_calls(user_id, tenant_id, calls)
        numeric_text = _deterministic_text(results, message)
        chart = _chart_from_results(results)
        yield {"phase": "data", "text": numeric_text, "chart": chart}

        # 4. 定性洞察逐字流式；为空则补兜底句。
        insight_parts = []
        insight_prompt = json.dumps({"question": message, "data": results}, ensure_ascii=False)
        async for token in _stream_text(_insight_stream_system(), insight_prompt):
            insight_parts.append(token)
            yield {"content": token}
        insight = "".join(insight_parts).strip()
        if not insight:
            insight = "详见上方数据，建议结合岗位和 HR 维度进一步比较。"
            yield {"content": insight}
        final_text = numeric_text + insight
        complete_request_with_messages(
            request_id, lease_token, request.session_id, message, final_text, calls, results, chart
        )
        yield {"done": True, "status": "succeeded", "request_id": request_id, "chart": chart}
    except (asyncio.TimeoutError, BusinessTimeoutError) as exc:
        update_request_result(
            request_id, lease_token, "failed", error_code_internal="timeout", error_message_internal=str(exc)
        )
        yield {"error": PUBLIC_FAILURE_MESSAGE, "request_id": request_id}
    except Exception as exc:
        update_request_result(
            request_id, lease_token, "failed", error_code_internal="internal_error", error_message_internal=str(exc)
        )
        yield {"error": PUBLIC_FAILURE_MESSAGE, "request_id": request_id}
