"""Application configuration constants."""

import os

# 基础目录
_BASE_DIR = os.path.dirname(__file__)
_PROJECT_DIR = os.path.join(_BASE_DIR, "..")

# React 构建产物
REACT_FRONTEND_DIR = os.getenv(
    "REACT_FRONTEND_DIR",
    os.path.join(_PROJECT_DIR, "frontend-react", "dist"),
)
REACT_PUBLIC_DIR = os.getenv(
    "REACT_PUBLIC_DIR",
    os.path.join(_PROJECT_DIR, "frontend-react", "public"),
)

_TRUE_VALUES = {"1", "true", "yes", "on"}


def _env_flag(name: str, default: bool) -> bool:
    fallback = "1" if default else "0"
    return os.getenv(name, fallback).strip().lower() in _TRUE_VALUES


def react_frontend_build_exists() -> bool:
    index_path = os.path.join(REACT_FRONTEND_DIR, "index.html")
    assets_dir = os.path.join(REACT_FRONTEND_DIR, "assets")
    if not os.path.isfile(index_path) or not os.path.isdir(assets_dir):
        return False

    try:
        with os.scandir(assets_dir) as entries:
            return any(
                entry.is_file() and os.path.splitext(entry.name)[1].lower() in {".js", ".mjs"} for entry in entries
            )
    except OSError:
        return False


def react_frontend_enabled() -> bool:
    """React 是否作为当前产品前端。"""
    return _env_flag("FRONTEND_APP_ENABLED", True)


def react_frontend_external() -> bool:
    """React 是否由 FastAPI 之外的 Web 容器托管。"""
    return _env_flag("REACT_FRONTEND_EXTERNAL", False)


def react_frontend_available() -> bool:
    """React 是否能由当前 FastAPI 进程或外部 Web 容器提供。"""
    return react_frontend_enabled() and (react_frontend_external() or react_frontend_build_exists())


# 文件上传目录
UPLOAD_DIR = os.path.join(_PROJECT_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Agent 配置与前端 AGENT_CONFIG 保持一致，用于阶段查询
PIPELINE_AGENT_CONFIG = {
    "xiao_wen": ["jd_write", "profile_build"],
    "xiao_hai": ["poster_gen"],
    "xiao_xun": ["crawl"],
    "xiao_shai": ["match"],
    "xiao_mian": ["interview_gen"],
    "xiao_ping": ["report"],
}

# 阶段显示名称
STAGE_NAMES = {
    "jd_write": "JD撰写",
    "profile_build": "候选人画像",
    "poster_gen": "招聘海报",
    "crawl": "简历获取",
    "match": "简历筛查",
    "interview_gen": "面试出题",
    "video_assess": "视频评估",
    "report": "录用报告",
}

# ── 阿里云直播配置 ──────────────────────────────────────────
ALICLOUD_ACCESS_KEY = os.getenv("ALICLOUD_ACCESS_KEY", "") or os.getenv("OSS_ACCESS_KEY_ID", "")
ALICLOUD_ACCESS_SECRET = os.getenv("ALICLOUD_ACCESS_SECRET", "") or os.getenv("OSS_ACCESS_KEY_SECRET", "")
ALICLOUD_PUSH_DOMAIN = os.getenv("ALICLOUD_PUSH_DOMAIN", "aly-push.astrakairos.com")
ALICLOUD_PLAY_DOMAIN = os.getenv("ALICLOUD_PLAY_DOMAIN", "aly-live.astrakairos.com")
ALICLOUD_AUTH_KEY = os.getenv("ALICLOUD_AUTH_KEY", "")
ALICLOUD_PLAY_AUTH_KEY = os.getenv("ALICLOUD_PLAY_AUTH_KEY", os.getenv("ALICLOUD_AUTH_KEY", ""))
ALICLOUD_OSS_BUCKET = os.getenv("ALICLOUD_OSS_BUCKET", "") or os.getenv("OSS_BUCKET", "aihr-recordings")
ALICLOUD_OSS_ENDPOINT = os.getenv("ALICLOUD_OSS_ENDPOINT", "") or os.getenv(
    "OSS_ENDPOINT", "oss-cn-hangzhou.aliyuncs.com"
)
# 浏览器直传必须使用公网可达地址；后端仍可通过上面的内网 endpoint 访问 OSS。
ALICLOUD_OSS_PUBLIC_ENDPOINT = os.getenv("ALICLOUD_OSS_PUBLIC_ENDPOINT", ALICLOUD_OSS_ENDPOINT)
ALICLOUD_OSS_REGION = os.getenv("ALICLOUD_OSS_REGION", "")
MASS_INTERVIEW_OSS_UPLOAD_HOST = os.getenv("MASS_INTERVIEW_OSS_UPLOAD_HOST", "")

# ── TTS 配置 ──────────────────────────────────────────────
TTS_MODEL = os.getenv("TTS_MODEL", "cosyvoice-v2")
TTS_VOICE = os.getenv("TTS_VOICE", "longxiaochun_v2")  # 亲和女声，适合服务行业面试
TTS_SAMPLE_RATE = int(os.getenv("TTS_SAMPLE_RATE", "24000"))
TTS_FORMAT = os.getenv("TTS_FORMAT", "mp3")
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "")

# ── 服务器公网 URL ──────────────────────────────────────────
SERVER_URL = os.getenv("SERVER_URL", "https://ai_hr_demo.shanghai.work")

# ── 企业微信扫码登录（Web 登录 SSO）──────────────────────────
WECOM_CORP_ID = os.getenv("WECOM_CORP_ID", "")
WECOM_AGENT_ID = os.getenv("WECOM_AGENT_ID", "")
WECOM_AGENT_SECRET = os.getenv("WECOM_AGENT_SECRET", "")
WECOM_CONTACT_SECRET = os.getenv("WECOM_CONTACT_SECRET", "")


def wecom_login_enabled() -> bool:
    """扫码登录可用性：自建应用三要素齐备才启用。"""
    return bool(WECOM_CORP_ID and WECOM_AGENT_ID and WECOM_AGENT_SECRET)


def wecom_contacts_sync_enabled() -> bool:
    """通讯录同步可用性：CorpId + 通讯录 Secret 齐备才启用。"""
    return bool(WECOM_CORP_ID and WECOM_CONTACT_SECRET)
