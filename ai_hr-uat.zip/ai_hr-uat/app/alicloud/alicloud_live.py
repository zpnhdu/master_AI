"""阿里云视频直播服务封装 — 推流地址生成、拉流地址、流状态查询、踢流、录制、截图。

依赖:
  pip install alibabacloud_live20161101 oss2

配置(config/environments/.env.{APP_ENV}):
  ALICLOUD_ACCESS_KEY=xxx
  ALICLOUD_ACCESS_SECRET=***
  ALICLOUD_PUSH_DOMAIN=aly-push.astrakairos.com
  ALICLOUD_PLAY_DOMAIN=aly-live.astrakairos.com
  ALICLOUD_AUTH_KEY=***
  ALICLOUD_OSS_BUCKET=aihr-recordings
  ALICLOUD_OSS_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
"""

import hashlib
import hmac
import logging
import time
from typing import Optional

from app.config import (
    ALICLOUD_ACCESS_KEY,
    ALICLOUD_ACCESS_SECRET,
    ALICLOUD_AUTH_KEY,
    ALICLOUD_PLAY_AUTH_KEY,
    ALICLOUD_PLAY_DOMAIN,
    ALICLOUD_PUSH_DOMAIN,
)

logger = logging.getLogger("app.alicloud_live")


class AlicloudLiveService:
    """阿里云视频直播服务封装"""

    def __init__(self):
        self._client = None
        self._oss_bucket = None

    # ── 延迟初始化 ──────────────────────────────────────────

    def _get_client(self):
        """Lazy-init 阿里云直播 SDK client"""
        if self._client is None:
            try:
                from alibabacloud_live20161101.client import Client as LiveClient
                from alibabacloud_tea_openapi import models as open_api_models

                config = open_api_models.Config(
                    access_key_id=ALICLOUD_ACCESS_KEY,
                    access_key_secret=ALICLOUD_ACCESS_SECRET,
                )
                config.endpoint = "live.aliyuncs.com"
                self._client = LiveClient(config)
            except ImportError:
                logger.error("alibabacloud_live20161101 not installed. pip install alibabacloud_live20161101")
                raise
        return self._client

    def _get_oss_bucket(self):
        """Lazy-init OSS bucket"""
        if self._oss_bucket is None:
            from app.media_storage import get_media_storage

            # 直播录制必须落 OSS，属业务约束而非环境配置。
            self._oss_bucket = get_media_storage("oss").bucket
        return self._oss_bucket

    # ── 推流地址 ─────────────────────────────────────────────

    def generate_push_url(self, stream_name: str, expire_hours: int = 72) -> str:
        """生成RTMP推流地址（带鉴权）

        Args:
            stream_name: 流名称，如 candidate_c_001
            expire_hours: 过期时间（小时），默认72

        Returns:
            rtmp://aly-push.astrakairos.com/live/{stream_name}?auth_key=xxx
        """
        timestamp = int(time.time()) + expire_hours * 3600
        # 阿里云鉴权格式: /{AppName}/{StreamName}-{Timestamp}-0-0-{AuthKey}
        auth_str = f"/live/{stream_name}-{timestamp}-0-0-{ALICLOUD_AUTH_KEY}"
        auth_hash = hashlib.md5(auth_str.encode()).hexdigest()
        return f"rtmp://{ALICLOUD_PUSH_DOMAIN}/live/{stream_name}?auth_key={timestamp}-0-0-{auth_hash}"

    # ── 拉流地址 ─────────────────────────────────────────────

    def generate_play_urls(self, stream_name: str, expire_hours: int = 72) -> dict[str, str]:
        """生成拉流地址（HLS + FLV，带鉴权）

        Returns:
            {"hls": "http://...m3u8?auth_key=xxx", "flv": "http://...flv?auth_key=xxx"}
        """
        base_urls = {
            "hls": f"http://{ALICLOUD_PLAY_DOMAIN}/live/{stream_name}.m3u8",
            "flv": f"http://{ALICLOUD_PLAY_DOMAIN}/live/{stream_name}.flv",
        }
        if not ALICLOUD_PLAY_AUTH_KEY:
            return base_urls

        timestamp = int(time.time()) + expire_hours * 3600
        auth_str = f"/live/{stream_name}-{timestamp}-0-0-{ALICLOUD_PLAY_AUTH_KEY}"
        auth_hash = hashlib.md5(auth_str.encode()).hexdigest()
        auth_param = f"auth_key={timestamp}-0-0-{auth_hash}"
        return {name: f"{url}?{auth_param}" for name, url in base_urls.items()}

    # ── 流状态查询 ───────────────────────────────────────────

    def describe_online_streams(self) -> list[dict]:
        """查询当前在线的直播流

        Returns:
            [{"stream_name": "xxx", "publish_time": "xxx"}, ...]
        """
        try:
            from alibabacloud_live20161101 import models as live_models

            client = self._get_client()
            request = live_models.DescribeLiveStreamsOnlineListRequest(
                domain_name=ALICLOUD_PUSH_DOMAIN,
                app_name="live",
                page_num=1,
                page_size=200,
            )
            response = client.describe_live_streams_online_list(request)
            streams = response.body.online_info.live_stream_online_info or []
            return [
                {
                    "stream_name": s.stream_name,
                    "publish_time": s.publish_time,
                    "client_addr": getattr(s, "client_addr", ""),
                }
                for s in streams
            ]
        except Exception as e:
            logger.error(f"describe_online_streams failed: {e}")
            return []

    # ── 踢流 ─────────────────────────────────────────────────

    def forbid_stream(self, stream_name: str, resume_time: int = 0) -> bool:
        """禁止推流（踢流）

        Args:
            stream_name: 流名称
            resume_time: 恢复时间戳，0=永久禁止

        Returns:
            True if success
        """
        try:
            from alibabacloud_live20161101 import models as live_models

            client = self._get_client()
            request = live_models.ForbidLiveStreamRequest(
                domain_name=ALICLOUD_PUSH_DOMAIN,
                app_name="live",
                stream_name=stream_name,
                live_stream_type="publisher",
                resume_time=resume_time,
            )
            client.forbid_live_stream(request)
            logger.info(f"Stream forbidden: {stream_name}")
            return True
        except Exception as e:
            logger.error(f"forbid_stream failed for {stream_name}: {e}")
            return False

    # ── 录制文件 ─────────────────────────────────────────────

    def get_recording_url(self, stream_name: str, expire_seconds: int = 7 * 24 * 3600) -> Optional[str]:
        """获取录制文件签名URL

        Args:
            stream_name: 流名称
            expire_seconds: URL有效期（秒），默认7天

        Returns:
            签名URL 或 None
        """
        try:
            import oss2

            from app.infrastructure.config import settings
            from app.media_storage import get_media_storage, join_storage_key

            # 直播录制必须落 OSS，属业务约束而非环境配置。
            storage = get_media_storage("oss")
            bucket = storage.bucket
            prefix = f"{join_storage_key(settings.oss_video_prefix, 'live', stream_name)}/"
            objects = list(oss2.ObjectIterator(bucket, prefix=prefix, max_keys=10))
            if not objects:
                return None
            # 取最新的录制文件
            latest = sorted(objects, key=lambda o: o.key, reverse=True)[0]
            return storage.sign_url(latest.key, expire_seconds)
        except Exception as e:
            logger.error(f"get_recording_url failed for {stream_name}: {e}")
            return None

    # ── 截图 ─────────────────────────────────────────────────

    def get_snapshot_url(self, stream_name: str, expire_seconds: int = 7 * 24 * 3600) -> Optional[str]:
        """获取最新截图签名URL

        Args:
            stream_name: 流名称
            expire_seconds: URL有效期（秒），默认7天

        Returns:
            签名URL 或 None
        """
        try:
            import oss2

            from app.infrastructure.config import settings
            from app.media_storage import get_media_storage, join_storage_key

            # 直播录制必须落 OSS，属业务约束而非环境配置。
            storage = get_media_storage("oss")
            bucket = storage.bucket
            prefix = f"{join_storage_key(settings.oss_video_prefix, 'snapshots', stream_name)}/"
            objects = list(oss2.ObjectIterator(bucket, prefix=prefix, max_keys=10))
            if not objects:
                return None
            latest = sorted(objects, key=lambda o: o.key, reverse=True)[0]
            return storage.sign_url(latest.key, expire_seconds)
        except Exception as e:
            logger.error(f"get_snapshot_url failed for {stream_name}: {e}")
            return None

    # ── 回调签名校验 ─────────────────────────────────────────

    def verify_callback(self, params: dict) -> bool:
        """校验阿里云回调签名（防盗回调）。

        回调 ``auth_key`` 格式为 ``timestamp-rand-uid-hash``，摘要规则与推流
        地址一致：``md5('/{AppName}/{StreamName}-{Timestamp}-{Rand}-{Uid}-{PrivateKey}')``。
        未配置回调密钥时拒绝回调，避免把未认证的公网请求当作直播状态事实来源。
        """
        auth_key = str(params.get("auth_key") or "")
        stream_name = str(params.get("stream_name") or "")
        private_key = str(ALICLOUD_AUTH_KEY or "")
        if not auth_key or not stream_name or not private_key:
            return False
        parts = auth_key.split("-")
        if len(parts) != 4:
            return False
        timestamp, rand, uid, expected_hash = parts
        if len(expected_hash) != 32 or any(c not in "0123456789abcdefABCDEF" for c in expected_hash):
            return False
        try:
            ts = int(timestamp)
        except (TypeError, ValueError):
            return False
        # 检查时间戳是否过期（允许1小时误差）。
        if abs(time.time() - ts) > 3600:
            return False
        auth_str = f"/live/{stream_name}-{timestamp}-{rand}-{uid}-{private_key}"
        actual_hash = hashlib.md5(auth_str.encode("utf-8")).hexdigest()
        return hmac.compare_digest(actual_hash.lower(), expected_hash.lower())


# ── 全局单例 ─────────────────────────────────────────────────

_live_service: Optional[AlicloudLiveService] = None


def get_live_service() -> AlicloudLiveService:
    """获取阿里云直播服务单例"""
    global _live_service
    if _live_service is None:
        _live_service = AlicloudLiveService()
    return _live_service
