"""应用包入口（目录整理）。

按 ``docs/directory-reorganization-plan.md`` 的领域归类，历史顶层的
``*_helpers.py`` 等模块逐步迁入领域子包（``app/helpers`` 等），旧导入
路径 ``from app.X import y`` / ``from app import X`` / ``import app.X``
通过 sys.modules 别名保持兼容。

别名注册在各领域子包的 ``__init__``（如 ``app/helpers/__init__.py``）；
这里的钩子只负责在解释器解析 ``app.<旧模块名>`` 之前把子包加载进来，
因此 ``from app.service_helpers import X`` 这类不经 ``app/__init__``
变量导出的写法也能命中注册好的别名。
"""

import importlib
import os

# 环境配置必须先于任何业务模块加载：_load_legacy_packages() 会在包初始化
# 阶段导入 app.db 等模块，它们在模块级就读取 DB_* 环境变量并执行 init_db()。
# 测试模式（TESTING=1）跳过：conftest 在导入 app 前自行注入 DB_* 等变量，
# 加载 .env.local 会把 REDIS_URL 等一并带入，改变测试假定的 no-op 行为。
if os.getenv("TESTING") != "1":
    from app.environment import load_environment

    load_environment()

# 日志集中配置（dictConfig）需要在业务模块导入前就绪，LOG_LEVEL 依赖上面的环境加载。
from app.log_config import configure_logging

configure_logging()

# 领域子包清单：每迁入一个域，在此追加，保证旧模块名可被解析。
# 顺序约束：app.helpers 必须最先加载——app/db/__init__.py 顶层
# 就执行 from app import analytics_time_helpers，其余领域包普遍依赖 app.db。
# 顺序约束：app.helpers 必须最先加载——app/db/__init__.py 顶层
# 就执行 from app import analytics_time_helpers，其余领域包普遍依赖 app.db。
# 顺序约束（硬性）：
# 1. app.helpers 最先——app/db/__init__.py 顶层执行 from app import analytics_time_helpers；
# 2. app.media 在 app.pipeline 之前——pipeline_cleanup 顶层 import app.media_storage；
# 3. app.assessment 前置于 app.reports——candidate_reports 依赖 assessment_flow 旧名；
# 4. app.wiki 前置于 app.reports——外部包 knowledge/wiki_base 顶层 import app.kb_tokenizer；
# 5. app.conversation 前置于 app.agents——poster_jobs 顶层 import app.conversation_store，
#    而 conversation_service 对 poster_progress 的依赖改为直达新包路径（agents.poster_progress）解环；
# 6. app.agents 前置于 app.reports——外部包 hr_harness.agents.jd_agent 顶层 import app.xiao_wen_context。
_LEGACY_PACKAGES = (
    "app.helpers",
    "app.schema",
    "app.media",
    "app.pipeline",
    "app.talent",
    "app.assessment",
    "app.wiki",
    "app.email",
    "app.interview",
    "app.conversation",
    "app.agents",
    "app.reports",
    "app.feishu",
    "app.analytics",
    "app.services",
)


def _load_legacy_packages() -> None:
    for package_name in _LEGACY_PACKAGES:
        importlib.import_module(package_name)


_load_legacy_packages()
