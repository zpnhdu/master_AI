"""静态资源和 API 路由注册。"""

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app import config
from app.audit.routes import monitor_router
from app.routers import (
    admin_router,
    agents_router,
    analytics_router,
    assessment_flow_router,
    auth_router,
    candidates_router,
    canvas_library_router,
    company_config_router,
    conversations_router,
    element_library_router,
    email_sync_router,
    feishu_router,
    interview_router,
    jd_router,
    knowledge_router,
    mass_interview_router,
    mass_interview_streams_router,
    ontology_router,
    pages_router,
    pipelines_router,
    question_review_router,
    resumes_router,
    rpa_router,
    studio_router,
    talent_pool_router,
    videos_router,
    websocket_router,
    wiki_router,
    written_test_page_router,
    written_test_router,
    xiao_hai_router,
)

APPLICATION_ROUTERS = (
    monitor_router,
    auth_router,
    admin_router,
    pages_router,
    pipelines_router,
    conversations_router,
    studio_router,
    company_config_router,
    jd_router,
    interview_router,
    candidates_router,
    resumes_router,
    videos_router,
    ontology_router,
    talent_pool_router,
    email_sync_router,
    agents_router,
    analytics_router,
    assessment_flow_router,
    rpa_router,
    feishu_router,
    mass_interview_router,
    mass_interview_streams_router,
    websocket_router,
    knowledge_router,
    wiki_router,
    written_test_router,
    written_test_page_router,
    xiao_hai_router,
    canvas_library_router,
    element_library_router,
    question_review_router,
)


def _mount_static_files(application: FastAPI) -> None:
    application.mount(
        "/brand",
        StaticFiles(directory=os.path.join(config.REACT_FRONTEND_DIR, "brand"), check_dir=False),
        name="react-brand-assets",
    )
    application.mount(
        "/assets",
        StaticFiles(directory=os.path.join(config.REACT_FRONTEND_DIR, "assets"), check_dir=False),
        name="react-assets",
    )


def configure_routes(application: FastAPI) -> None:
    """注册静态资源挂载点及全部业务路由。"""
    _mount_static_files(application)
    for router in APPLICATION_ROUTERS:
        application.include_router(router)
