"""HTTP 中间件和全局异常处理。"""

import os
import time
import uuid
from urllib.parse import quote

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, RedirectResponse

from app import config
from app.access_control import current_user, has_permission, required_api_permission, required_page_permission
from app.audit.logger import get_logger
from app.infrastructure.timeout_policy import BusinessTimeoutError
from app.log_config import request_id_var

logger = get_logger("main")

AUTH_WHITELIST = {
    "/login",
    "/forbidden",
    "/privacy",
    "/terms",
    "/api/auth/login",
    "/api/auth/logout",
    "/api/auth/me",
    "/api/auth/wecom/status",
    "/api/auth/wecom/login",
    "/api/auth/wecom/callback",
    "/api/auth/wecom/bind",
    "/api/auth/wecom/register",
    "/api/health",
    "/api/health/live",
    "/api/health/ready",
    "/docs",
    "/openapi.json",
    "/redoc",
    "/_health",
    "/favicon.ico",
}

AUTH_PREFIX_WHITELIST = (
    "/brand/",
    "/assets/",
    "/mass-interview/",
    "/written-test/",
    "/ws",
)

# 已迁移页面在 React 开启时统一跳转到对应的新路由。
LEGACY_REACT_PAGE_REDIRECTS = {
    "/frontend/studio.html": "/studio",
    "/frontend/pipeline-detail.html": "/pipeline-detail",
    "/frontend/mass-dashboard.html": "/mass-dashboard",
    "/frontend/xiao_wen.html": "/xiao-wen",
    "/frontend/xiao_xun.html": "/xiao-xun",
    "/frontend/xiao_hai.html": "/xiao-hai",
    "/frontend/xiao_shai.html": "/xiao-shai",
    "/frontend/xiao_mian.html": "/xiao-mian",
    "/frontend/xiao_ping.html": "/xiao-ping",
    "/frontend/talent-pool.html": "/talent-pool",
    "/frontend/profile.html": "/profile",
    "/frontend/dashboard.html": "/dashboard",
    "/frontend/monitor.html": "/monitor",
    "/frontend/knowledge.html": "/knowledge",
    "/frontend/agent.html": "/studio",
    "/frontend/role.html": "/studio",
    "/frontend/mass-interview.html": "/mass-dashboard",
}

PUBLIC_STATIC_EXTENSIONS = {
    ".css",
    ".gif",
    ".ico",
    ".jpeg",
    ".jpg",
    ".js",
    ".json",
    ".m3u8",
    ".mjs",
    ".mp4",
    ".png",
    ".svg",
    ".ttf",
    ".webm",
    ".webp",
    ".woff",
    ".woff2",
}


def _is_public_static_asset(path: str) -> bool:
    if not (path.startswith("/frontend/") or path.startswith("/static/")):
        return False
    return os.path.splitext(path)[1].lower() in PUBLIC_STATIC_EXTENSIONS


def _matches_path_prefix(path: str, prefix: str) -> bool:
    normalized_prefix = prefix.rstrip("/")
    return path == normalized_prefix or path.startswith(f"{normalized_prefix}/")


def _is_whitelisted(path: str, method: str = "GET") -> bool:
    if path in AUTH_WHITELIST or _is_public_static_asset(path):
        return True
    if path.startswith("/mass-interview/") or path.startswith("/written-test/"):
        return True
    if path.startswith("/ws"):
        return True
    # 企业微信可信域名校验文件：匿名可访问，内容路由见 pages.py
    if path.startswith("/WW_verify_") and path.endswith(".txt"):
        return True

    parts = path.strip("/").split("/")
    if path.startswith("/api/written-test/session/") and len(parts) >= 4:
        token_path = parts[:3] == ["api", "written-test", "session"] and bool(parts[3])
        return token_path and (len(parts) == 4 or parts[4] in {"submit", "upload-video", "transcribe", "video-upload"})

    if path.startswith("/api/mass-interview/") and len(parts) >= 4:
        token_path = parts[:3] == ["api", "mass-interview", "session"] and bool(parts[3])
        if token_path and (len(parts) == 4 or parts[4] in {"device-check", "full-video", "video-upload"}):
            return True
        if parts[2] in {"video", "thumbnail"}:
            return True
        if parts[2] == "callback" and len(parts) == 4:
            return True

    return any(_matches_path_prefix(path, prefix) for prefix in AUTH_PREFIX_WHITELIST)


class AuthMiddleware(BaseHTTPMiddleware):
    """校验登录状态和页面、接口权限。"""

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if _is_whitelisted(path, request.method):
            return await call_next(request)

        user = current_user(request)
        if user:
            request.state.user = user
            required_permission = (
                required_api_permission(path, request.method)
                if path.startswith("/api/")
                else required_page_permission(path, request.url.query)
            )
            if path.startswith("/api/") and required_permission is None and not path.startswith("/api/auth/"):
                return JSONResponse(status_code=403, content={"detail": "未配置接口权限", "code": "FORBIDDEN"})
            if has_permission(user, required_permission):
                react_redirect = LEGACY_REACT_PAGE_REDIRECTS.get(path)
                if react_redirect and config.react_frontend_available():
                    redirect_path = react_redirect
                    if request.url.query:
                        redirect_path = f"{redirect_path}?{request.url.query}"
                    return RedirectResponse(url=redirect_path, status_code=307)
                return await call_next(request)
            if path.startswith("/api/"):
                return JSONResponse(status_code=403, content={"detail": "无权访问此功能", "code": "FORBIDDEN"})
            return RedirectResponse(url=f"/forbidden?next={quote(path, safe='/')}", status_code=302)

        if path.startswith("/api/"):
            return JSONResponse(status_code=401, content={"error": "未登录"})
        return RedirectResponse(url="/login", status_code=302)


class RequestContextMiddleware(BaseHTTPMiddleware):
    """为每个响应和日志条目附加请求 ID 与耗时。

    request_id 通过 contextvars 注入本次请求处理期间的所有日志
    （app.log_config.RequestIdFilter），实现请求链路追踪。
    """

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or f"req_{uuid.uuid4().hex}"
        request.state.request_id = request_id
        context_token = request_id_var.set(request_id)
        started = time.perf_counter()
        try:
            response = await call_next(request)
            latency_ms = round((time.perf_counter() - started) * 1000, 2)
            response.headers["X-Request-ID"] = request_id
            # 访问日志需在 reset 之前记录，保证本条日志也带上 request_id。
            logger.info(
                f"{request.method} {request.url.path} {response.status_code} {latency_ms}ms",
                extra={
                    "source": "HTTP",
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "status_code": response.status_code,
                    "latency_ms": latency_ms,
                },
            )
        finally:
            request_id_var.reset(context_token)
        return response


class NoCacheStaticMiddleware(BaseHTTPMiddleware):
    """为前端静态资源设置与文件类型匹配的缓存策略。"""

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        path = request.url.path
        if path.startswith("/assets/"):
            response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        elif path.startswith("/brand/"):
            response.headers["Cache-Control"] = "public, max-age=3600"
        elif path.startswith("/static/"):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        return response


async def http_exception_handler(_request: Request, exc: HTTPException) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "code": "HTTP_ERROR"},
        headers=exc.headers,
    )


async def timeout_exception_handler(request: Request, exc: BusinessTimeoutError) -> JSONResponse:
    """Return one stable error contract for exhausted backend business budgets."""
    request_id = getattr(request.state, "request_id", None)
    content = {
        "code": "backend_timeout",
        "message": "任务执行超时，请稍后重试",
        "operation": exc.operation or "business_operation",
        "timeout_seconds": exc.timeout_seconds,
        "request_id": request_id,
    }
    logger.warning(
        "Business operation timed out",
        extra={
            "source": "TimeoutPolicy",
            "request_id": request_id,
            "operation": content["operation"],
            "timeout_seconds": exc.timeout_seconds,
        },
    )
    headers = {"X-Request-ID": request_id} if request_id else None
    return JSONResponse(status_code=504, content=content, headers=headers)


async def global_exception_handler(_request: Request, exc: Exception) -> JSONResponse:
    logger.error(f"Unhandled exception: {exc}", exc_info=True, extra={"source": "ExceptionHandler"})
    return JSONResponse(
        status_code=500,
        content={"detail": f"服务器内部错误: {exc}", "code": "INTERNAL_ERROR"},
    )


def configure_http(application: FastAPI) -> None:
    """按既有顺序注册跨域、中间件和全局异常处理。"""
    application.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=5)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    application.add_middleware(AuthMiddleware)
    application.add_middleware(RequestContextMiddleware)
    application.add_middleware(NoCacheStaticMiddleware)
    application.add_exception_handler(HTTPException, http_exception_handler)
    application.add_exception_handler(BusinessTimeoutError, timeout_exception_handler)
    application.add_exception_handler(Exception, global_exception_handler)
