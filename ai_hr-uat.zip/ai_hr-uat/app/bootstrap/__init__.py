"""应用启动与装配模块。"""

from app.bootstrap.factory import create_app

__all__ = ["create_app"]
