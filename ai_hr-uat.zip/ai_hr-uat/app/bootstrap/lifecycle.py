"""应用生命周期和后台任务。"""

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app import state
from app.audit.logger import get_logger

logger = get_logger("main")


def _restore_pending_data() -> dict:
    """从数据库恢复待处理数据，并兼容启动阶段数据库尚未就绪的情况。"""
    try:
        from app.db import get_all_pending

        restored = get_all_pending()
        for pipeline_id, types in restored.items():
            if "resumes" in types:
                state.pending_resumes[pipeline_id] = types["resumes"]
            if "videos" in types:
                state.pending_videos[pipeline_id] = types["videos"]
        if restored:
            total = sum(sum(len(values) for values in types.values()) for types in restored.values())
            logger.info(
                f"Restored {total} pending items from DB across {len(restored)} pipelines",
                extra={"source": "Startup"},
            )
        return restored
    except Exception as exc:
        logger.error(f"Pending data restore failed: {exc}", extra={"source": "Startup"})
        return {}


_restored = _restore_pending_data()


@asynccontextmanager
async def lifespan(_application: FastAPI):
    from app.db import ensure_access_control_tables
    from app.poster_jobs import cleanup_stale_jobs

    ensure_access_control_tables()
    cleanup_stale_jobs()
    await auto_resume_pending()
    yield


async def auto_resume_pending() -> None:
    """恢复待处理数据到内存，并启动应用后台任务。"""
    await asyncio.sleep(3)

    # Candidate answers are committed before AI scoring.  Any job interrupted
    # by a deployment is therefore safe to resume without asking candidates to
    # submit again.
    try:
        from app.routers.written_test import resume_pending_written_test_scoring

        resumed_written_scores = resume_pending_written_test_scoring()
        if resumed_written_scores:
            logger.info(
                "Resumed %s pending written-test scoring jobs",
                resumed_written_scores,
                extra={"source": "Startup"},
            )
    except Exception:
        logger.exception("Written-test scoring recovery failed", extra={"source": "Startup"})

    for pipeline_id, types in _restored.items():
        if "resumes" in types and types["resumes"]:
            logger.info(
                f"已恢复 {pipeline_id} 的 {len(types['resumes'])} 份待处理简历（等待手动触发）",
                extra={"source": "Startup"},
            )
        if "videos" in types and types["videos"]:
            logger.info(
                f"已恢复 {pipeline_id} 的待处理视频（等待手动触发）",
                extra={"source": "Startup"},
            )

    from app import wiki_ingest

    wiki_ingest.resume_pending_ingests()
    asyncio.create_task(_email_sync_loop())
    asyncio.create_task(_poster_job_recovery_loop())
    asyncio.create_task(_wecom_contacts_sync_loop())

    from app.aggregate_report_jobs import list_recoverable_job_ids as list_report_job_ids
    from app.aggregate_report_jobs import schedule_job as schedule_report_job

    for job_id in list_report_job_ids():
        schedule_report_job(job_id)
    asyncio.create_task(_aggregate_report_recovery_loop())


async def _aggregate_report_recovery_loop() -> None:
    """Recover queued or interrupted aggregate-report jobs."""
    from app.aggregate_report_jobs import list_recoverable_job_ids, schedule_job

    while True:
        await asyncio.sleep(30)
        try:
            for job_id in list_recoverable_job_ids():
                schedule_job(job_id)
        except Exception:
            logger.exception("Aggregate report job recovery failed", extra={"source": "Startup"})


async def _email_sync_loop() -> None:
    """Scan database-backed account schedules and dispatch due runs."""
    import os

    from app.email_accounts import EmailDomainError, create_sync_run, due_account_ids, expire_stale_sync_runs
    from app.email_logging import get_email_logger
    from app.email_sync import dispatch_sync_run

    email_logger = get_email_logger()
    poll_seconds = max(5, int(os.getenv("EMAIL_SCHEDULER_POLL_SECONDS", "30")))
    logger.info(f"邮箱账户调度器已启动，扫描间隔 {poll_seconds} 秒", extra={"source": "EmailSync"})
    email_logger.info("邮箱账户调度器已启动 poll_seconds=%s", poll_seconds)
    await asyncio.sleep(2)
    while True:
        try:
            expired_runs = expire_stale_sync_runs()
            if expired_runs:
                email_logger.warning(
                    "调度器已清理过期同步任务 count=%s runs=%s",
                    len(expired_runs),
                    ",".join(expired_runs),
                )
            due_accounts = due_account_ids()
            if due_accounts:
                email_logger.info("发现到期邮箱任务 count=%s accounts=%s", len(due_accounts), ",".join(due_accounts))
            for account_id in due_accounts:
                try:
                    run = create_sync_run(account_id, None, "schedule")
                    email_logger.info("定时同步已调度 account=%s run=%s", account_id, run["id"])
                    dispatch_sync_run(run["id"])
                except EmailDomainError as exc:
                    if exc.code != "EMAIL_SYNC_ALREADY_RUNNING":
                        logger.error(
                            f"邮箱调度失败 account={account_id}: {exc.code}",
                            extra={"source": "EmailSync"},
                        )
                        email_logger.error(
                            "邮箱调度失败 account=%s code=%s error=%s",
                            account_id,
                            exc.code,
                            exc.message,
                        )
                    else:
                        email_logger.debug("邮箱调度跳过 account=%s reason=already_running", account_id)
            await asyncio.sleep(poll_seconds)
        except Exception as exc:
            logger.error(f"邮箱同步异常: {exc}", extra={"source": "EmailSync"})
            email_logger.exception("邮箱调度循环异常 error=%s", exc)
            await asyncio.sleep(poll_seconds)


async def _poster_job_recovery_loop():
    from app.poster_jobs import list_recoverable_job_ids, schedule_job

    while True:
        try:
            for job_id in await asyncio.to_thread(list_recoverable_job_ids):
                schedule_job(job_id)
        except Exception:
            logger.exception("Poster task recovery failed")
        await asyncio.sleep(10)


async def _wecom_contacts_sync_loop() -> None:
    """每日全量同步企微通讯录到 wecom_contacts（扫码登录自动开通数据源）。"""
    import os

    interval_seconds = max(60, int(os.getenv("WECOM_CONTACTS_SYNC_INTERVAL_SECONDS", "86400")))
    logger.info(
        f"企微通讯录同步循环已启动，间隔 {interval_seconds} 秒",
        extra={"source": "WeComContacts"},
    )
    await asyncio.sleep(30)
    while True:
        try:
            from app.wecom.contacts import sync_contacts

            result = await asyncio.to_thread(sync_contacts)
            if result.get("status") != "disabled":
                logger.info(
                    "通讯录定时同步完成 result=%s",
                    result,
                    extra={"source": "WeComContacts"},
                )
        except Exception as exc:
            logger.error(f"通讯录定时同步异常: {exc}", extra={"source": "WeComContacts"})
        await asyncio.sleep(interval_seconds)
