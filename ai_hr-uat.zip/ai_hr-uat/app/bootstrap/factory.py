"""FastAPI 应用工厂。"""

from fastapi import FastAPI

from app.bootstrap.http import configure_http
from app.bootstrap.lifecycle import lifespan
from app.bootstrap.routes import configure_routes


def create_app() -> FastAPI:
    """创建并装配后端应用。"""
    application = FastAPI(title="锅圈食汇", version="2.0.0", lifespan=lifespan)
    configure_http(application)
    configure_routes(application)
    return application
