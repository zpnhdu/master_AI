#
#  Copyright 2025 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""
LLM adapter for resume parsing.

Maps ragflow's ``_call_llm(prompt, tenant_id, lang)`` (which used LLMBundle) to
ai_hr's ``hermes_wrapper.get_client().chat_json``.  Retains ragflow's semantics:
retry up to ``_LLM_MAX_RETRIES`` with escalating temperature (0.1 → 1.0).
Hermes ``_call_sync`` has no ``max_tokens``/``seed`` support, so those are
deliberately not forwarded — only temperature and timeout are honored.
"""

import logging
import os

logger = logging.getLogger("app.resume_parser")

_PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

_LLM_MAX_RETRIES = 2

_loaded_prompts: dict[str, str] = {}


def load_prompt(name: str) -> str:
    """Load a prompt template ``<name>.md`` from the prompts directory (cached)."""
    if name in _loaded_prompts:
        return _loaded_prompts[name]

    path = os.path.join(_PROMPT_DIR, f"{name}.md")
    if not os.path.exists(path):
        raise FileNotFoundError(f"prompt template not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    _loaded_prompts[name] = content
    return content


async def _call_llm(prompt: str, lang: str, system: str = "") -> dict:
    """Call the LLM and return a parsed dict, with retry + temperature escalation.

    Returns ``{}`` (falsy) when all attempts fail, mirroring ragflow's behavior
    so callers can fall back to regex parsing.
    """
    from hermes_wrapper.client import get_client
    from hermes_wrapper.models import LLMRequest

    client = get_client()
    last_error = ""

    for attempt in range(_LLM_MAX_RETRIES + 1):
        temperature = 0.1 if attempt == 0 else 1.0
        try:
            req = LLMRequest(
                prompt=prompt,
                system=system,
                complexity="flash",
                temperature=temperature,
                timeout=90,
            )
            result = await client.chat_json(req, operation="resume_parse")
            if isinstance(result, dict) and not result.get("parse_error") and not result.get("error"):
                return result
            last_error = str(result.get("error") or "parse_error") if isinstance(result, dict) else "non-dict result"
        except Exception as e:  # noqa: BLE001 — mirror ragflow retry semantics
            last_error = str(e)

        logger.warning(f"resume LLM attempt {attempt + 1} failed: {last_error}")

    return {}