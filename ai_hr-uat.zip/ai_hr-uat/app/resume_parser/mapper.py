#
#  Copyright 2025 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""
Map ragflow resume fields (``*_kwd``/``*_tks``/``*_flt``/``*_int``) to ai_hr's
legacy candidate dict, while passing the full ragflow result through as
``ragflow_raw`` so no information is lost downstream.
"""

import json


def _first(value) -> object:
    """Return the first element of a list, an empty string, or the value itself."""
    if isinstance(value, list):
        return value[0] if value else ""
    return value if value is not None else ""


def _int(value, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def ragflow_to_legacy(ragflow: dict) -> dict:
    """Map a ragflow field dict to the legacy ai_hr resume dict.

    The returned dict is intentionally compatible with ai_hr's existing
    downstream consumers (talent_pool.save_resume, resume_contact, etc.).
    """
    if not isinstance(ragflow, dict):
        ragflow = {}

    legacy = {
        "name": _first(ragflow.get("name_kwd", "")),
        "phone": str(_first(ragflow.get("phone_kwd", "")) or "").strip(),
        "email": str(_first(ragflow.get("email_tks", "")) or "").strip().lower(),
        "gender": str(_first(ragflow.get("gender_kwd", "")) or "").strip(),
        "years_experience": _int(ragflow.get("work_exp_flt", 0)),
        "current_company": str(_first(ragflow.get("corporation_name_tks", "")) or ""),
        "title": str(_first(ragflow.get("position_name_tks", "")) or ""),
        "education": str(_first(ragflow.get("highest_degree_kwd", ragflow.get("degree_kwd", ""))) or ""),
        "location": str(ragflow.get("current_location", "") or "").strip(),
        "skills": ragflow.get("skill_tks", []) if isinstance(ragflow.get("skill_tks"), list) else [],
    }

    # resume_text: prefer work descriptions + self evaluation, fall back to skills
    text_parts = []
    work_descs = ragflow.get("work_desc_tks", [])
    if isinstance(work_descs, list):
        text_parts.extend(str(d) for d in work_descs if d)
    self_eval = ragflow.get("self_evaluation_tks", "")
    if self_eval:
        text_parts.append(str(self_eval))
    legacy["resume_text"] = "\n".join(text_parts)

    # Preserve the full ragflow result verbatim.
    legacy["ragflow_raw"] = ragflow

    return legacy


def ragflow_raw_to_json(ragflow: dict) -> str:
    """Serialize the ragflow result for TEXT storage (survives JSON round-trips)."""
    if ragflow is None:
        return ""
    try:
        return json.dumps(ragflow, ensure_ascii=False)
    except (TypeError, ValueError):
        return ""


def legacy_with_ragflow(legacy: dict, ragflow: dict) -> dict:
    """Attach ``ragflow_raw`` (and its JSON string) to an existing legacy dict."""
    if not isinstance(legacy, dict):
        legacy = {}
    legacy["ragflow_raw"] = ragflow if isinstance(ragflow, dict) else {}
    legacy["ragflow_json"] = ragflow_raw_to_json(ragflow)
    return legacy
