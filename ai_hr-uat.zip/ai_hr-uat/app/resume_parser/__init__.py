#
#  Copyright 2025 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""
Resume parsing package — ragflow field-first resume parsing ported to ai_hr.

Public API:
  - ``parse_resume``          : async orchestrator (filename + bytes → fields)
  - ``parse_resume_plain_text``: sync regex fallback for paste/email flows
  - ``ragflow_to_legacy``     : ragflow fields → legacy ai_hr resume dict
  - ``ragflow_raw_to_json``   : ragflow fields → JSON string (for storage)
"""

from app.resume_parser.core import (
    extract_text,
    parse_resume,
    parse_resume_plain_text,
    parse_resume_text,
    parse_with_llm,
    parse_with_regex,
)
from app.resume_parser.legacy import (
    extract_resume_rules,
    parse_pdf_file,
    read_text_file,
    try_ocr_pdf,
)
from app.resume_parser.mapper import (
    legacy_with_ragflow,
    ragflow_raw_to_json,
    ragflow_to_legacy,
)

__all__ = [
    "extract_text",
    "parse_pdf_file",
    "try_ocr_pdf",
    "read_text_file",
    "extract_resume_rules",
    "parse_resume",
    "parse_resume_plain_text",
    "parse_resume_text",
    "parse_with_llm",
    "parse_with_regex",
    "ragflow_to_legacy",
    "ragflow_raw_to_json",
    "legacy_with_ragflow",
]
