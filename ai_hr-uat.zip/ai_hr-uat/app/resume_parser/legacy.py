"""Legacy resume file and rule parsing helpers.

These helpers intentionally have no database, state, storage, or background-task
side effects.  The pipeline router keeps upload and import orchestration there.
"""

import hashlib
import os
import re

from app.resume_contact import classify_contact, extract_contact


def parse_pdf_file(fpath: str, ocr_func=None) -> tuple:
    """Parse a PDF with pdfplumber, PyMuPDF, then OCR fallback."""
    text = ""
    text_source = "unknown"
    pdf_errors = []
    ocr_func = ocr_func or try_ocr_pdf

    try:
        import pdfplumber

        with pdfplumber.open(fpath) as pdf:
            text = "\n".join(page.extract_text() or "" for page in pdf.pages)
        text_source = "pdfplumber"
    except ImportError:
        pdf_errors.append("pdfplumber 未安装")
    except Exception as exc:
        pdf_errors.append(f"pdfplumber: {str(exc)[:80]}")

    if not text or len(text.strip()) < 10:
        try:
            import fitz

            doc = fitz.open(fpath)
            text = "\n".join(page.get_text() for page in doc)
            text_source = "pymupdf"
        except ImportError:
            pdf_errors.append("pymupdf 未安装")
        except Exception as exc:
            pdf_errors.append(f"pymupdf: {str(exc)[:80]}")

    if not text or len(text.strip()) < 20:
        ocr_text = ocr_func(fpath)
        if ocr_text and len(ocr_text.strip()) >= 20:
            text = ocr_text
            text_source = "ocr"

    if text and len(text.strip()) >= 20:
        return text, text_source, None

    if pdf_errors:
        return "", "", {"msg": f"PDF解析失败: {'; '.join(pdf_errors)}", "type": "pdf_parse_error"}
    return "", "", {"msg": "无法提取文本：可能为扫描件/图片型PDF，且OCR未就绪", "type": "scanned_pdf"}


def try_ocr_pdf(fpath: str) -> str:
    """Try OCR using pytesseract and pdf2image/PyMuPDF fallback."""
    try:
        import pytesseract
    except ImportError:
        return ""

    try:
        from pdf2image import convert_from_path

        images = convert_from_path(fpath, first_page=2, dpi=200)
    except ImportError:
        try:
            import fitz

            doc = fitz.open(fpath)
            import io

            from PIL import Image

            texts = []
            for page in doc:
                pix = page.get_pixmap(dpi=200)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                page_text = pytesseract.image_to_string(img, lang="chi_sim+eng")
                texts.append(page_text)
            return "\n".join(texts)
        except ImportError:
            return ""
        except Exception:
            return ""
    except Exception:
        return ""

    texts = []
    for img in images:
        try:
            page_text = pytesseract.image_to_string(img, lang="chi_sim+eng")
            texts.append(page_text)
        except Exception:
            pass
    return "\n".join(texts)


def read_text_file(fpath: str) -> str:
    """Read text files using UTF-8 and common Chinese encodings."""
    encodings = ["utf-8", "gb18030", "gbk", "gb2312", "latin-1"]
    for encoding in encodings:
        try:
            with open(fpath, encoding=encoding) as file_obj:
                text = file_obj.read()
            if encoding == "utf-8":
                return text
            if any("一" <= char <= "鿿" for char in text[:200]):
                return text
        except (UnicodeDecodeError, UnicodeError):
            continue
    with open(fpath, encoding="utf-8", errors="ignore") as file_obj:
        return file_obj.read()


def extract_resume_rules(text: str, filename: str) -> dict:
    """Extract stable resume fields with rules only; no LLM calls."""
    lines = text.split("\n")
    lines = [line.strip() for line in lines if line.strip()]

    name = ""
    name_patterns = [r"姓名[：:]\s*(.+)", r"^([^\d\s]{2,4})$"]
    for pattern in name_patterns:
        match = re.search(pattern, text, re.MULTILINE)
        if match:
            name = match.group(1).strip()
            break
    if not name and lines:
        first_line = lines[0]
        if len(first_line) <= 10 and not re.search(r"\d", first_line):
            name = first_line
    if not name:
        name = os.path.splitext(filename)[0][:10]

    years = 0
    years_match = re.search(r"(\d+)\s*年(?:以上)?(?:工作)?经验|工作经验[：:]\s*(\d+)", text)
    if years_match:
        years = int(years_match.group(1) or years_match.group(2))

    company = ""
    company_match = re.search(r"(?:公司|企业|就职|任职)[：:]\s*(.+)|(?:在|于)(.+?)(?:工作|任职)", text)
    if company_match:
        company = (company_match.group(1) or company_match.group(2) or "").strip()

    skill_keywords = [
        "React",
        "Vue",
        "Angular",
        "TypeScript",
        "JavaScript",
        "Python",
        "Java",
        "Go",
        "Rust",
        "C++",
        "Node.js",
        "Django",
        "Flask",
        "FastAPI",
        "Spring",
        "Docker",
        "K8s",
        "Kubernetes",
        "AWS",
        "MySQL",
        "PostgreSQL",
        "Redis",
        "MongoDB",
        "Webpack",
        "Vite",
        "GraphQL",
        "REST",
        "gRPC",
        "微服务",
        "分布式",
        "高并发",
        "React Native",
        "Flutter",
        "Swift",
        "Kotlin",
        "TensorFlow",
        "PyTorch",
        "Spark",
        "Hadoop",
        "Flink",
        "Elasticsearch",
        "Kafka",
        "RabbitMQ",
        "Nginx",
        "Linux",
        "Git",
        "CI/CD",
        "Agile",
        "Scrum",
        "Next.js",
        "Nuxt.js",
        "Svelte",
        "Tailwind",
        "Sass",
        "Less",
        "Electron",
        "Unity",
        "Unreal",
    ]
    skills = [skill for skill in skill_keywords if skill.lower() in text.lower()]

    education = ""
    education_match = re.search(r"(博士|硕士|本科|大专|学士|MBA|EMBA)", text)
    if education_match:
        education = education_match.group(1)

    location = ""
    location_match = re.search(
        r"(北京|上海|深圳|杭州|广州|成都|南京|武汉|西安|长沙|苏州|重庆|天津|青岛|大连|厦门)", text
    )
    if location_match:
        location = location_match.group(1)

    salary = ""
    salary_match = re.search(r"(\d+[kK]-?\d*[kK]?|\d+-\d+[kK]|\d+万)", text)
    if salary_match:
        salary = salary_match.group(1)

    title = ""
    title_match = re.search(r"(?:职位|岗位|Title)[：:]\s*(.+)|(.+工程师|.+设计师|.+经理|.+主管|.+总监|.+架构师)", text)
    if title_match:
        title = (title_match.group(1) or title_match.group(2) or "").strip()

    confidence = "high" if len(skills) >= 3 and years > 0 else ("mid" if len(skills) >= 1 else "low")
    phone, email = extract_contact(text)
    contact_status = classify_contact(phone, email)
    resume_id = "imp_" + hashlib.md5((filename + name).encode()).hexdigest()[:8]

    return {
        "id": resume_id,
        "name": name,
        "years_experience": years,
        "current_company": company,
        "current_salary": salary,
        "skills": skills,
        "resume_text": text[:500],
        "education": education,
        "location": location,
        "title": title,
        "source": "local_import",
        "confidence": confidence,
        "status": "new",
        "phone": phone,
        "email": email,
        "contact_status": contact_status,
    }
