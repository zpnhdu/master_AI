#
#  Copyright 2025 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""
Resume parsing — port of ragflow's rag/app/resume.py to ai_hr.

Differences from the original (light port per project constraints):
  - LLM calls go through hermes_wrapper.get_client().chat() (replaces LLMBundle).
  - OCR (deepdoc.vision.OCR) and YOLOv10 layout detection are dropped; scanned
    PDFs fall back to the project's existing pytesseract path outside this module.
  - HuQie tokenizer hooks (rag_tokenizer.add_positions / _build_chunk_document)
    are removed; this module only produces structured fields, not chunks.
"""

import asyncio
import datetime
import logging
import re
import unicodedata
from io import BytesIO
from typing import Optional

from app.resume_parser import llm_adapter

logger = logging.getLogger("app.resume_parser")

# tiktoken for long-random-string filtering (ref: SmartResume should_remove strategy)
try:
    import tiktoken

    _tiktoken_encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")
except ImportError:
    _tiktoken_encoding = None

# Long random string pattern: 40+ char alphanumeric mixed strings (hash, token, tracking ID, etc.)
_LONG_RANDOM_PATTERN = re.compile(r"[a-zA-Z0-9\-~_]{40,}")


# Field name to description mapping (bilingual versions for chunk construction)
FIELD_MAP_ZH = {
    "name_kwd": "姓名/名字",
    "name_pinyin_kwd": "姓名拼音/名字拼音",
    "gender_kwd": "性别（男，女）",
    "age_int": "年龄/岁/年纪",
    "phone_kwd": "电话/手机/微信",
    "email_tks": "email/e-mail/邮箱",
    "position_name_tks": "职位/职能/岗位/职责",
    "expect_city_names_tks": "期望城市",
    "work_exp_flt": "工作年限/工作年份/N年经验/毕业了多少年",
    "corporation_name_tks": "最近就职(上班)的公司/上一家公司",
    "first_school_name_tks": "第一学历毕业学校",
    "first_degree_kwd": "第一学历",
    "highest_degree_kwd": "最高学历",
    "first_major_tks": "第一学历专业",
    "edu_first_fea_kwd": "第一学历标签",
    "degree_kwd": "过往学历",
    "major_tks": "学过的专业/过往专业",
    "school_name_tks": "学校/毕业院校",
    "sch_rank_kwd": "学校标签",
    "edu_fea_kwd": "教育标签",
    "corp_nm_tks": "就职过的公司/之前的公司/上过班的公司",
    "edu_end_int": "毕业年份",
    "industry_name_tks": "所在行业",
    "birth_dt": "生日/出生年份",
    "expect_position_name_tks": "期望职位/期望职能/期望岗位",
    "skill_tks": "技能/技术栈/编程语言/框架/工具",
    "language_tks": "语言能力/外语水平",
    "certificate_tks": "证书/资质/认证",
    "project_tks": "项目经验/项目名称",
    "work_desc_tks": "工作职责/工作描述",
    "project_desc_tks": "项目描述/项目职责",
    "self_evaluation_tks": "自我评价/个人优势/个人总结",
}

FIELD_MAP_EN = {
    "name_kwd": "Name",
    "name_pinyin_kwd": "Name Pinyin",
    "gender_kwd": "Gender (Male, Female)",
    "age_int": "Age",
    "phone_kwd": "Phone/Mobile/WeChat",
    "email_tks": "Email",
    "position_name_tks": "Position/Title/Role",
    "expect_city_names_tks": "Preferred City",
    "work_exp_flt": "Years of Experience",
    "corporation_name_tks": "Most Recent Company",
    "first_school_name_tks": "First Degree School",
    "first_degree_kwd": "First Degree",
    "highest_degree_kwd": "Highest Degree",
    "first_major_tks": "First Degree Major",
    "edu_first_fea_kwd": "First Degree Tag",
    "degree_kwd": "Past Degrees",
    "major_tks": "Past Majors",
    "school_name_tks": "School/University",
    "sch_rank_kwd": "School Tag",
    "edu_fea_kwd": "Education Tag",
    "corp_nm_tks": "Past Companies",
    "edu_end_int": "Graduation Year",
    "industry_name_tks": "Industry",
    "birth_dt": "Date of Birth",
    "expect_position_name_tks": "Preferred Position/Role",
    "skill_tks": "Skills/Tech Stack/Languages/Frameworks/Tools",
    "language_tks": "Language Proficiency",
    "certificate_tks": "Certificates/Qualifications",
    "project_tks": "Project Experience/Project Name",
    "work_desc_tks": "Job Responsibilities/Description",
    "project_desc_tks": "Project Description/Responsibilities",
    "self_evaluation_tks": "Self-Evaluation/Personal Strengths/Summary",
}


def _is_english(lang: Optional[str]) -> bool:
    """Determine if the language parameter indicates English."""
    if not isinstance(lang, str):
        return False
    return lang.strip().lower() in ("english", "en")


# Backward compatible: default to Chinese version
FIELD_MAP = FIELD_MAP_ZH

# LLM call max retry count (ref: SmartResume retry strategy)
_LLM_MAX_RETRIES = 2


def _load_resume_prompt(name: str, lang: str) -> str:
    """Load the language-specific resume prompt template."""
    suffix = "_en" if _is_english(lang) else ""
    return llm_adapter.load_prompt(f"{name}{suffix}")


def get_system_prompt(lang: str) -> str:
    return _load_resume_prompt("resume_system", lang)


def get_basic_info_prompt(lang: str) -> str:
    return _load_resume_prompt("resume_basic_info", lang)


def get_work_exp_prompt(lang: str) -> str:
    return _load_resume_prompt("resume_work_exp", lang)


def get_education_prompt(lang: str) -> str:
    return _load_resume_prompt("resume_education", lang)


def get_project_exp_prompt(lang: str) -> str:
    return _load_resume_prompt("resume_project_exp", lang)


def _normalize_whitespace(text: str) -> str:
    """Unicode whitespace normalization (ref: SmartResume _clean_text_content)."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"[\u0020\u00A0\u1680\u2000-\u200A\u2028\u2029\u202F\u205F\u3000\u00A7]", " ", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def _should_remove_random_str(match: re.Match) -> bool:
    """Detect a meaningless random string via tiktoken token-count heuristic."""
    if _tiktoken_encoding is None:
        s = match.group(0)
        changes = sum(
            1
            for i in range(1, len(s))
            if s[i].isdigit() != s[i - 1].isdigit()
            or (s[i].isalpha() and s[i - 1].isalpha() and s[i].isupper() != s[i - 1].isupper())
        )
        return changes / len(s) > 0.3
    encoded = _tiktoken_encoding.encode(match.group(0))
    return len(encoded) > len(match.group(0)) * 0.5


def _clean_line_content(text: str) -> str:
    """Clean single line: unicode normalization + long random string filtering."""
    if not text:
        return ""
    text = _normalize_whitespace(text)
    text = _LONG_RANDOM_PATTERN.sub(lambda m: "" if _should_remove_random_str(m) else m.group(0), text)
    text = re.sub(r" {2,}", " ", text).strip()
    return text


# ==================== Phase 1: PDF Text Fusion ====================


def _is_noise_char(obj: dict) -> bool:
    """Detect a decorative-layer noise character using embedded-font + structure-tag whitelist."""
    fontname = obj.get("fontname", "")
    if "+" in fontname:
        return False
    tag = obj.get("tag")
    if tag in (
        "Span",
        "NonStruct",
        "P",
        "H1",
        "H2",
        "H3",
        "H4",
        "H5",
        "H6",
        "TD",
        "TH",
        "LI",
        "L",
        "Table",
        "TR",
        "Figure",
        "Caption",
    ):
        return False
    return True


def _extract_metadata_text(binary: bytes) -> list[dict]:
    """Extract text blocks from PDF metadata (with coordinate info)."""
    try:
        import pdfplumber

        blocks = []
        with pdfplumber.open(BytesIO(binary)) as pdf:
            for page_idx, page in enumerate(pdf.pages):
                page_width = page.width or 600

                try:
                    original_char_count = len(page.chars)
                    filtered_page = page.filter(lambda obj: not _is_noise_char(obj))
                    filtered_char_count = len(filtered_page.chars)
                    if original_char_count > 0 and filtered_char_count < original_char_count * 0.3:
                        filtered_page = page
                except Exception:
                    filtered_page = page

                words = []
                try:
                    words = filtered_page.extract_words(keep_blank_chars=False, use_text_flow=True)
                except Exception:
                    pass

                if words:
                    line_threshold = 5
                    current_line_words = [words[0]]

                    def _flush_line(line_words):
                        line_words.sort(key=lambda w: float(w.get("x0", 0)))
                        texts = [w.get("text", "") for w in line_words]
                        merged_text = " ".join(texts)
                        if not merged_text.strip():
                            return None
                        return {
                            "text": merged_text.strip(),
                            "x0": float(min(w.get("x0", 0) for w in line_words)),
                            "top": float(min(w.get("top", 0) for w in line_words)),
                            "x1": float(max(w.get("x1", 0) for w in line_words)),
                            "bottom": float(max(w.get("bottom", 0) for w in line_words)),
                            "page": page_idx,
                        }

                    for w in words[1:]:
                        w_top = float(w.get("top", 0))
                        cur_top = float(current_line_words[0].get("top", 0))
                        if abs(w_top - cur_top) <= line_threshold:
                            current_line_words.append(w)
                        else:
                            block = _flush_line(current_line_words)
                            if block:
                                blocks.append(block)
                            current_line_words = [w]

                    if current_line_words:
                        block = _flush_line(current_line_words)
                        if block:
                            blocks.append(block)
                else:
                    page_text = None
                    try:
                        page_text = page.extract_text()
                    except Exception:
                        pass
                    if page_text and page_text.strip():
                        raw_lines = page_text.split("\n")
                        line_height = 16
                        for i, line in enumerate(raw_lines):
                            cleaned = line.strip()
                            if not cleaned:
                                continue
                            blocks.append(
                                {
                                    "text": cleaned,
                                    "x0": 0,
                                    "top": i * line_height,
                                    "x1": page_width,
                                    "bottom": i * line_height + line_height - 2,
                                    "page": page_idx,
                                }
                            )

                try:
                    tables = page.extract_tables()
                    if tables:
                        page_blocks = [b for b in blocks if b["page"] == page_idx]
                        max_top = max((b["top"] for b in page_blocks), default=0) + 20
                        row_height = 16

                        for table in tables:
                            for row in table:
                                if not row:
                                    continue
                                cells = [str(c).strip() for c in row if c and str(c).strip()]
                                if not cells:
                                    continue
                                row_text = " | ".join(cells)
                                is_dup = False
                                for pb in page_blocks:
                                    if all(c in pb["text"] for c in cells[:2]):
                                        is_dup = True
                                        break
                                if is_dup:
                                    continue
                                blocks.append(
                                    {
                                        "text": row_text,
                                        "x0": 0,
                                        "top": max_top,
                                        "x1": page_width,
                                        "bottom": max_top + row_height - 2,
                                        "page": page_idx,
                                    }
                                )
                                max_top += row_height
                except Exception as e:
                    logger.debug(f"PDF table extraction skipped (page {page_idx}): {e}")
        return blocks
    except Exception as e:
        logger.warning(f"PDF metadata extraction failed: {e}")
        return []


def _layout_aware_reorder(blocks: list[dict]) -> list[dict]:
    """Layout-aware hierarchical sorting (two-column detection + top-to-bottom)."""
    if not blocks:
        return blocks

    pages = {}
    for b in blocks:
        pg = b.get("page", 0)
        pages.setdefault(pg, []).append(b)

    sorted_blocks = []
    for pg in sorted(pages.keys()):
        page_blocks = pages[pg]

        if len(page_blocks) > 5:
            x_centers = [(b["x0"] + b["x1"]) / 2 for b in page_blocks]
            x_min, x_max = min(x_centers), max(x_centers)
            page_width = x_max - x_min if x_max > x_min else 1

            mid_x = (x_min + x_max) / 2
            left_count = sum(1 for x in x_centers if x < mid_x - page_width * 0.1)
            right_count = sum(1 for x in x_centers if x > mid_x + page_width * 0.1)

            if left_count > 3 and right_count > 3:
                left_blocks = [b for b in page_blocks if (b["x0"] + b["x1"]) / 2 < mid_x]
                right_blocks = [b for b in page_blocks if (b["x0"] + b["x1"]) / 2 >= mid_x]
                left_blocks.sort(key=lambda b: (b["top"], b["x0"]))
                right_blocks.sort(key=lambda b: (b["top"], b["x0"]))
                sorted_blocks.extend(left_blocks)
                sorted_blocks.extend(right_blocks)
                continue

        page_blocks.sort(key=lambda b: (b["top"], b["x0"]))
        sorted_blocks.extend(page_blocks)

    return sorted_blocks


def _build_indexed_text(blocks: list[dict]) -> tuple[str, list[str], list[dict]]:
    """Merge sorted blocks into line-indexed text (with garbled-line filtering)."""
    if not blocks:
        return "", [], []

    raw_lines = []
    raw_positions = []
    current_line_parts = []
    current_line_blocks = []
    current_top = blocks[0].get("top", 0)
    threshold = 10

    def _merge_line_position(line_blocks: list[dict]) -> dict:
        return {
            "page": line_blocks[0].get("page", 0),
            "x0": min(b.get("x0", 0) for b in line_blocks),
            "x1": max(b.get("x1", 0) for b in line_blocks),
            "top": min(b.get("top", 0) for b in line_blocks),
            "bottom": max(b.get("bottom", 0) for b in line_blocks),
        }

    for b in blocks:
        y_changed = abs(b.get("top", 0) - current_top) > threshold
        if y_changed and current_line_parts:
            raw_lines.append(" ".join(current_line_parts))
            raw_positions.append(_merge_line_position(current_line_blocks))
            current_line_parts = []
            current_line_blocks = []
            current_top = b.get("top", 0)
        current_line_parts.append(b["text"])
        current_line_blocks.append(b)

    if current_line_parts:
        raw_lines.append(" ".join(current_line_parts))
        raw_positions.append(_merge_line_position(current_line_blocks))

    lines = []
    line_positions = []
    for line, pos in zip(raw_lines, raw_positions):
        line = _clean_line_content(line)
        if not line:
            continue
        if not _is_valid_line(line):
            continue
        lines.append(line)
        line_positions.append(pos)

    lines = _fix_split_labels(lines)

    indexed_parts = [f"[{i}]: {line}" for i, line in enumerate(lines)]
    indexed_text = "\n".join(indexed_parts)

    return indexed_text, lines, line_positions


def _is_valid_line(line: str) -> bool:
    """Check if a text line is valid content (not garbled)."""
    if len(line) <= 3:
        return True

    cid_count = len(re.findall(r"\(cid:\d+\)", line))
    if cid_count >= 3:
        return False

    valid_chars = re.findall(
        "[\\u4e00-\\u9fff\\u3400-\\u4dbf\\uf900-\\ufaffa-zA-Z0-9\\s@.,:;!%s()（）【】\\-_/\\\\|·•、，。：；！？\\u201c\\u201d\\u2018\\u2019《》\\uff01-\\uff5e\\u3000-\\u303f#%&+=~`\\u00b7\\u2022\\u2013\\u2014]",
        line,
    )
    ratio = len(valid_chars) / len(line) if len(line) > 0 else 0
    if ratio < 0.5:
        return False

    spaced_singles = re.findall(r"(?:^|\s)([a-zA-Z0-9])(?:\s|$)", line)
    non_space_len = len(line.replace(" ", ""))
    if non_space_len > 5 and len(spaced_singles) > 0:
        single_ratio = len(spaced_singles) / non_space_len
        if single_ratio > 0.3:
            return False

    garbled_seqs = re.findall(r"[a-zA-Z0-9]{4,}", line.replace(" ", ""))
    if garbled_seqs:
        garbled_count = 0
        for seq in garbled_seqs:
            case_changes = sum(
                1
                for i in range(1, len(seq))
                if (seq[i].isupper() != seq[i - 1].isupper() and seq[i].isalpha() and seq[i - 1].isalpha())
                or (seq[i].isdigit() != seq[i - 1].isdigit())
            )
            if len(seq) >= 4 and case_changes / len(seq) > 0.5:
                garbled_count += 1
        if len(garbled_seqs) > 0 and garbled_count / len(garbled_seqs) > 0.4:
            return False

    return True


def _fix_split_labels(lines: list[str]) -> list[str]:
    """Fix field label split issues (e.g. '名：陈晓俐 姓' -> '姓名：陈晓俐')."""
    split_patterns = {
        ("姓", "名"): "姓名",
        ("性", "别"): "性别",
        ("年", "龄"): "年龄",
        ("电", "话"): "电话",
        ("邮", "箱"): "邮箱",
        ("学", "历"): "学历",
        ("专", "业"): "专业",
        ("地", "址"): "地址",
        ("籍", "贯"): "籍贯",
        ("民", "族"): "民族",
    }

    fixed = []
    for line in lines:
        for (suffix_char, prefix_char), full_label in split_patterns.items():
            pattern = rf"^({re.escape(prefix_char)})\s*[:：]\s*(.+?)\s+{re.escape(suffix_char)}\s*$"
            m = re.match(pattern, line)
            if m:
                content = m.group(2).strip()
                line = f"{full_label}：{content}"
                break
            pattern2 = rf"^{re.escape(suffix_char)}\s*[:：]?\s*(.+?)\s+{re.escape(prefix_char)}\s*$"
            m2 = re.match(pattern2, line)
            if m2:
                content = m2.group(1).strip()
                line = f"{full_label}：{content}"
                break
        fixed.append(line)
    return fixed


def extract_text(filename: str, binary: bytes) -> tuple[str, list[str], list[dict]]:
    """Extract line-indexed text based on file type (PDF via metadata, DOCX via paragraphs+tables)."""
    fname_lower = filename.lower()

    try:
        if fname_lower.endswith(".pdf"):
            meta_blocks = _extract_metadata_text(binary)
            sorted_blocks = _layout_aware_reorder(meta_blocks)
            return _build_indexed_text(sorted_blocks)

        elif fname_lower.endswith(".docx"):
            from docx import Document

            doc = Document(BytesIO(binary))
            lines = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

            for table in doc.tables:
                for row in table.rows:
                    cells = []
                    for cell in row.cells:
                        cell_text = cell.text.strip()
                        if cell_text:
                            cells.append(cell_text)
                    if not cells:
                        continue
                    row_text = " | ".join(cells)
                    if row_text not in lines:
                        lines.append(row_text)

            indexed = "\n".join(f"[{i}]: {line}" for i, line in enumerate(lines))
            return indexed, lines, []

        else:
            from app.utils import decode_bytes

            text = decode_bytes(binary)
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            indexed = "\n".join(f"[{i}]: {line}" for i, line in enumerate(lines))
            return indexed, lines, []

    except Exception:
        logger.exception(f"Text extraction failed: {filename}")
        return "", [], []


# ==================== Phase 2: Parallel LLM Structured Extraction ====================


def _normalize_for_comparison(text: str) -> str:
    """Normalize text for comparison: NFKC + strip whitespace + lowercase."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", "", text)
    return text.lower()


def _parse_date_str(date_str: str) -> Optional[datetime.datetime]:
    """Parse a date string supporting 2024.1 / 2024-1 / 2024/1 / 2024年1月 / 2024."""
    date_str = date_str.strip()
    patterns = [
        (r"((?:19|20)\d{2})[.\-/年](\d{1,2})", "%Y-%m"),
        (r"^((?:19|20)\d{2})$", "%Y"),
    ]
    for pattern, _ in patterns:
        m = re.search(pattern, date_str)
        if m:
            try:
                year = int(m.group(1))
                month = int(m.group(2)) if len(m.groups()) > 1 else 1
                if month < 1 or month > 12:
                    month = 1
                return datetime.datetime(year, month, 1)
            except (ValueError, IndexError):
                continue
    return None


def _calc_single_exp_years(start_str: str, end_str: str) -> float:
    """Calculate years for a single experience entry."""
    start_str = str(start_str).strip()
    end_str = str(end_str).strip()
    if not start_str:
        return 0

    start_date = _parse_date_str(start_str)
    if not start_date:
        return 0

    if end_str in ("至今", "现在", "present", "Present", "now", "Now", ""):
        end_date = datetime.datetime.now()
    else:
        end_date = _parse_date_str(end_str)
        if not end_date:
            end_date = datetime.datetime.now()

    months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
    if months <= 0:
        return 0
    return round(months / 12.0, 1)


def _calculate_work_years(experiences: list[dict]) -> float:
    """Calculate total work years from each experience's start/end dates."""
    total = 0.0
    for exp in experiences:
        total += _calc_single_exp_years(exp.get("start_date", ""), exp.get("end_date", ""))
    return round(total, 1)


def _extract_description_from_range(index_range: list, lines: list[str], company: str = "", position: str = "") -> str:
    """Extract description from original text by index range (filter header lines)."""
    if not index_range or len(index_range) != 2:
        return ""

    start_idx, end_idx = int(index_range[0]), int(index_range[1])

    if start_idx < 0 or end_idx >= len(lines) or start_idx > end_idx:
        return ""

    extracted_lines = lines[start_idx : end_idx + 1]

    if company or position:
        norm_company = _normalize_for_comparison(company)
        norm_position = _normalize_for_comparison(position)
        filtered = []
        for line in extracted_lines:
            norm_line = _normalize_for_comparison(line)
            if norm_company and norm_position and norm_company in norm_line and norm_position in norm_line:
                continue
            if norm_line == norm_company or norm_line == norm_position:
                continue
            filtered.append(line)
        extracted_lines = filtered

    if not extracted_lines:
        return ""

    return "\n".join(line.strip() for line in extracted_lines if line.strip())


def _extract_basic_info(indexed_text: str, lang: str):
    """Extract basic info (subtask 1). Basic info is usually at the start."""
    prompt = get_basic_info_prompt(lang).format(indexed_text=indexed_text[:8000])
    return llm_adapter._call_llm(prompt, lang, system=get_system_prompt(lang))


def _extract_work_experience(indexed_text: str, lang: str):
    """Extract work experience (subtask 2, using index pointers)."""
    prompt = get_work_exp_prompt(lang).format(indexed_text=indexed_text)
    return llm_adapter._call_llm(prompt, lang, system=get_system_prompt(lang))


def _extract_education(indexed_text: str, lang: str):
    """Extract education background (subtask 3)."""
    prompt = get_education_prompt(lang).format(indexed_text=indexed_text)
    return llm_adapter._call_llm(prompt, lang, system=get_system_prompt(lang))


def _extract_project_experience(indexed_text: str, lang: str):
    """Extract project experience (subtask 4, using index pointers)."""
    prompt = get_project_exp_prompt(lang).format(indexed_text=indexed_text)
    return llm_adapter._call_llm(prompt, lang, system=get_system_prompt(lang))


async def parse_with_llm(indexed_text: str, lines: list[str], lang: str) -> Optional[dict]:
    """Extract resume info via 4 parallel LLM subtasks, then merge (ref: SmartResume)."""
    try:
        (basic_info, work_exp, education, project_exp) = await asyncio.gather(
            _extract_basic_info(indexed_text, lang),
            _extract_work_experience(indexed_text, lang),
            _extract_education(indexed_text, lang),
            _extract_project_experience(indexed_text, lang),
        )

        resume = {}

        if basic_info:
            resume.update(basic_info)
            logger.info(f"Basic info extraction succeeded: {len(basic_info)} fields")

        if work_exp and "workExperience" in work_exp:
            experiences = work_exp["workExperience"]
            companies = []
            positions = []
            work_descs = []
            work_exp_details = []
            for exp in experiences:
                company = exp.get("company", "")
                position = exp.get("position", "")
                start_date = exp.get("start_date", "")
                end_date = exp.get("end_date", "")
                years = _calc_single_exp_years(start_date, end_date)
                if company:
                    companies.append(company)
                if position:
                    positions.append(position)
                work_exp_details.append(
                    {
                        "company": company,
                        "position": position,
                        "start_date": start_date,
                        "end_date": end_date,
                        "years": years,
                    }
                )
                desc_lines = exp.get("desc_lines", [])
                if isinstance(desc_lines, list) and len(desc_lines) == 2:
                    desc = _extract_description_from_range(desc_lines, lines, company=company, position=position)
                    if desc.strip():
                        work_descs.append(desc.strip())

            if companies:
                resume["corp_nm_tks"] = companies
                resume["corporation_name_tks"] = companies[0]
            if positions:
                resume["position_name_tks"] = positions
            if work_descs:
                resume["work_desc_tks"] = work_descs
            if work_exp_details:
                resume["_work_exp_details"] = work_exp_details
            calculated_years = _calculate_work_years(experiences)
            if calculated_years > 0:
                resume["work_exp_flt"] = calculated_years
            logger.info(
                f"Work experience extraction succeeded: {len(experiences)} entries, total years: {calculated_years}"
            )

        if education and "education" in education:
            edu_list = education["education"]
            schools = []
            majors = []
            degrees = []
            for edu in edu_list:
                if edu.get("school"):
                    schools.append(edu["school"])
                if edu.get("major"):
                    majors.append(edu["major"])
                if edu.get("degree"):
                    degrees.append(edu["degree"])
                end_date = edu.get("end_date", "")
                if end_date and not resume.get("edu_end_int"):
                    year_match = re.search(r"(19|20)\d{2}", str(end_date))
                    if year_match:
                        resume["edu_end_int"] = int(year_match.group(0))

            if schools:
                resume["school_name_tks"] = schools
                resume["first_school_name_tks"] = schools[-1]
            if majors:
                resume["major_tks"] = majors
                resume["first_major_tks"] = majors[-1]
            if degrees:
                resume["degree_kwd"] = degrees
                degree_rank = {
                    "博士": 5,
                    "PhD": 5,
                    "Doctor": 5,
                    "硕士": 4,
                    "Master": 4,
                    "MBA": 4,
                    "EMBA": 4,
                    "MPA": 4,
                    "本科": 3,
                    "Bachelor": 3,
                    "大专": 2,
                    "专科": 2,
                    "Associate": 2,
                    "Diploma": 2,
                    "高中": 1,
                    "High School": 1,
                }
                highest = max(degrees, key=lambda d: degree_rank.get(d, 0), default="")
                if highest:
                    resume["highest_degree_kwd"] = highest
                resume["first_degree_kwd"] = degrees[-1] if degrees else ""
            logger.info(f"Education extraction succeeded: {len(edu_list)} entries")

        if project_exp and "projectExperience" in project_exp:
            projects = project_exp["projectExperience"]
            project_names = []
            project_descs = []
            for proj in projects:
                name = proj.get("project_name", "")
                if name:
                    project_names.append(name)
                desc_lines = proj.get("desc_lines", [])
                if isinstance(desc_lines, list) and len(desc_lines) == 2:
                    desc = _extract_description_from_range(
                        desc_lines, lines, company=name, position=proj.get("role", "")
                    )
                    if desc.strip():
                        project_descs.append(desc.strip())

            if project_names:
                resume["project_tks"] = project_names
            if project_descs:
                resume["project_desc_tks"] = project_descs
            logger.info(f"Project experience extraction succeeded: {len(projects)} entries")

        if not resume.get("name_kwd"):
            resume["name_kwd"] = "Unknown" if _is_english(lang) else "未知"

        return resume if len(resume) > 2 else None

    except Exception as e:
        logger.warning(f"LLM parallel extraction failed: {e}")
        return None


# ==================== Phase 3: Regex Fallback Parsing ====================


def parse_with_regex(text: str, lang: str = "Chinese") -> dict:
    """Parse resume text using regex (fallback when LLM fails)."""
    resume: dict = {}
    lines = [line.strip() for line in text.split("\n") if line.strip()]

    # --- Name ---
    if _is_english(lang):
        for line in lines[:30]:
            name_match = re.search(
                r"(?:Name|Full\s*Name)\s*[:：]\s*([A-Za-z][A-Za-z\s\-\.]{1,40})", line, re.IGNORECASE
            )
            if name_match:
                resume["name_kwd"] = name_match.group(1).strip()
                break
        if "name_kwd" not in resume and lines:
            first = lines[0].strip()
            if len(first) <= 40 and not re.search(r"\d", first) and re.match(r"^[A-Za-z][A-Za-z\s\-\.]+$", first):
                resume["name_kwd"] = first
    else:
        for line in lines[:30]:
            name_match = re.search(r"姓\s*名\s*[:：]\s*([\u4e00-\u9fa5]{2,4})", line)
            if name_match:
                resume["name_kwd"] = name_match.group(1)
                break

        if "name_kwd" not in resume:
            title_words = {
                "个人",
                "简历",
                "求职",
                "应聘",
                "基本",
                "信息",
                "概述",
                "简介",
                "教育",
                "工作",
                "经历",
                "经验",
                "技能",
                "项目",
                "自我",
                "评价",
                "专业",
                "技术",
                "证书",
                "语言",
                "能力",
                "培训",
                "荣誉",
                "奖项",
            }
            for line in lines[:20]:
                if any(w in line for w in title_words):
                    continue
                if re.search(r"[:：]", line) and len(line) > 6:
                    continue
                cleaned = re.sub(r"^[A-Za-z_\-\d\s]+\s+", "", line)
                cleaned = re.sub(r"\s+[A-Za-z_\-\d\s]+$", "", cleaned).strip()
                if 2 <= len(cleaned) <= 4 and re.match(r"^[\u4e00-\u9fa5]{2,4}$", cleaned):
                    resume["name_kwd"] = cleaned
                    break

        if "name_kwd" not in resume and lines:
            first = lines[0].strip()
            if len(first) <= 10 and not re.search(r"\d", first):
                cn_part = re.findall(r"[\u4e00-\u9fa5]+", first)
                if cn_part and 2 <= len(cn_part[0]) <= 4:
                    resume["name_kwd"] = cn_part[0]

    # --- Phone ---
    phones = re.findall(r"1[3-9]\d{9}", text)
    if phones:
        resume["phone_kwd"] = phones[0]

    # --- Email ---
    emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
    if emails:
        resume["email_tks"] = emails[0]

    # --- Gender ---
    if _is_english(lang):
        gender_label = re.search(r"(?:Gender|Sex)\s*[:：]\s*(Male|Female|M|F)", text, re.IGNORECASE)
        if gender_label:
            raw = gender_label.group(1).strip().upper()
            resume["gender_kwd"] = "Male" if raw in ("M", "MALE") else "Female"
        else:
            gender_match = re.search(r"\b(Male|Female)\b", text[:500], re.IGNORECASE)
            if gender_match:
                resume["gender_kwd"] = gender_match.group(1).capitalize()
    else:
        gender_label = re.search(r"性\s*别\s*[:：]\s*(男|女)", text)
        if gender_label:
            resume["gender_kwd"] = gender_label.group(1)
        else:
            gender_match = re.search(r"(男|女)", text[:500])
            if gender_match:
                resume["gender_kwd"] = gender_match.group(1)

    # --- Age ---
    if _is_english(lang):
        age_match = re.search(r"(?:Age)\s*[:：]\s*(\d{1,2})", text, re.IGNORECASE)
        if not age_match:
            age_match = re.search(r"(\d{1,2})\s*years?\s*old", text, re.IGNORECASE)
        if age_match:
            resume["age_int"] = int(age_match.group(1))
    else:
        age_match = re.search(r"(\d{1,2})\s*岁", text)
        if age_match:
            resume["age_int"] = int(age_match.group(1))

    # --- Date of Birth ---
    if _is_english(lang):
        birth_match = re.search(r"(?:Birth|DOB|Date\s*of\s*Birth)\s*[:：]\s*(.{6,20})", text, re.IGNORECASE)
        if birth_match:
            resume["birth_dt"] = birth_match.group(1).strip()
        else:
            birth_match = re.search(r"(19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}", text)
            if birth_match:
                resume["birth_dt"] = birth_match.group(0)
    else:
        birth_match = re.search(r"(19|20)\d{2}[年/-]\d{1,2}[月/-]\d{1,2}", text)
        if birth_match:
            resume["birth_dt"] = birth_match.group(0)

    # --- Education Level ---
    degree_keywords_zh = ["博士", "硕士", "本科", "大专", "专科", "高中", "MBA", "EMBA", "MPA"]
    degree_keywords_en = [
        "PhD",
        "Master",
        "Bachelor",
        "Associate",
        "Diploma",
        "High School",
        "MBA",
        "EMBA",
        "MPA",
        "Doctor",
    ]
    degree_keywords = degree_keywords_en if _is_english(lang) else degree_keywords_zh
    found_degrees = [d for d in degree_keywords if d in text]
    if found_degrees:
        resume["degree_kwd"] = found_degrees

    # --- School ---
    if _is_english(lang):
        schools = re.findall(r"([A-Z][A-Za-z\s\-&]{2,40}(?:University|College|Institute|School|Academy))", text)
        schools = [re.sub(r"\s+", " ", s).strip() for s in schools]
    else:
        schools = re.findall(r"[\u4e00-\u9fa5]{2,15}(?:大学|学院|职业技术学院)", text)
    if schools:
        resume["school_name_tks"] = list(set(schools))
        resume["first_school_name_tks"] = schools[0]

    # --- Major ---
    if _is_english(lang):
        majors = re.findall(
            r"(?:Major|Field\s*of\s*Study|Specialization|Concentration)\s*[:：]\s*([A-Za-z\s\-&,]{2,40})",
            text,
            re.IGNORECASE,
        )
        majors = [m.strip() for m in majors if m.strip()]
    else:
        majors = re.findall(r"专业[:：]\s*([\u4e00-\u9fa5]{2,20})", text)
    if majors:
        resume["major_tks"] = majors
        resume["first_major_tks"] = majors[0]

    # --- Company Names ---
    if _is_english(lang):
        en_company_patterns = [
            "([A-Z][A-Za-z\\s\\-&,\\.]{2,40}(%s:Inc\\.|Corp\\.|Ltd\\.|LLC|Co\\.|Company|Group|Technologies|Technology|Solutions|Consulting|Services|Bank))",
        ]
        companies = []
        for pattern in en_company_patterns:
            companies.extend(re.findall(pattern, text))
        companies = [re.sub(r"\s+", " ", c).strip() for c in companies]
    else:
        company_patterns = [
            r"[\u4e00-\u9fa5]{2,20}[（(][\u4e00-\u9fa5]{2,10}[)）](?:科技|信息技术|网络科技)?(?:股份)?有限公司",
            r"[\u4e00-\u9fa5]{4,20}(?:科技|信息技术|网络科技|银行)?(?:股份)?有限公司",
        ]
        companies = []
        for pattern in company_patterns:
            companies.extend(re.findall(pattern, text))

    unique_companies = []
    seen = set()
    filter_verbs = (
        ["completed", "conducted", "implemented", "responsible", "participated", "developed"]
        if _is_english(lang)
        else ["完成", "进行", "实施", "负责", "参与", "开发"]
    )
    min_len = 3 if _is_english(lang) else 6
    for c in companies:
        if len(c) < min_len or any(v in c.lower() for v in filter_verbs) or c in seen:
            continue
        is_sub = False
        for existing in list(unique_companies):
            if c in existing:
                is_sub = True
                break
            if existing in c:
                unique_companies.remove(existing)
                seen.discard(existing)
        if not is_sub:
            unique_companies.append(c)
            seen.add(c)

    if unique_companies:
        resume["corp_nm_tks"] = unique_companies
        resume["corporation_name_tks"] = unique_companies[0]

    # --- Position ---
    if _is_english(lang):
        position_label_matches = re.findall(
            r"(?:Title|Position|Role|Job\s*Title)\s*[:：]\s*([A-Za-z\s\-/&]{2,30})", text, re.IGNORECASE
        )
        positions = [p.strip() for p in position_label_matches if p.strip()]

        en_position_suffixes = [
            "Engineer",
            "Manager",
            "Director",
            "Supervisor",
            "Specialist",
            "Designer",
            "Consultant",
            "Assistant",
            "Architect",
            "Analyst",
            "Developer",
            "Lead",
            "Officer",
            "Coordinator",
            "Administrator",
            "Intern",
            "VP",
            "President",
        ]
        for line in lines:
            if len(line) > 60:
                continue
            for suffix in en_position_suffixes:
                match = re.search(rf"([A-Za-z\s\-]{{1,25}}{suffix})\b", line, re.IGNORECASE)
                if match:
                    pos = match.group(1).strip()
                    filter_pos_verbs = ["responsible", "participated", "completed", "developed", "designed"]
                    if not any(v in pos.lower() for v in filter_pos_verbs) and len(pos) > 3:
                        positions.append(pos)
    else:
        position_label_matches = re.findall(
            r"(?:职位|岗位|职务|职称|担任)\s*[:：]\s*([\u4e00-\u9fa5a-zA-Z]{2,15})", text
        )
        positions = list(position_label_matches)

        for line in lines:
            pos_match = re.search(
                r"(?:有限公司|集团|银行)\s+([\u4e00-\u9fa5]{2,8}(?:工程师|经理|总监|主管|专员|设计师|顾问|助理|架构师|分析师|运营|产品))",
                line,
            )
            if pos_match:
                positions.append(pos_match.group(1))

        position_suffixes = [
            "工程师",
            "经理",
            "总监",
            "主管",
            "专员",
            "设计师",
            "顾问",
            "助理",
            "架构师",
            "分析师",
            "开发者",
            "负责人",
        ]
        for line in lines:
            if len(line) > 20:
                continue
            for suffix in position_suffixes:
                match = re.search(rf"([\u4e00-\u9fa5]{{1,6}}{suffix})", line)
                if match:
                    pos = match.group(1)
                    if not any(v in pos for v in ["负责", "参与", "完成", "开发了", "设计了"]):
                        positions.append(pos)

    if positions:
        seen_pos = set()
        unique_positions = []
        for p in positions:
            if p not in seen_pos:
                seen_pos.add(p)
                unique_positions.append(p)
        resume["position_name_tks"] = unique_positions

    # --- Years of Experience ---
    if _is_english(lang):
        work_exp_match = re.search(r"(\d+)\+?\s*years?\s*(?:of\s*)?(?:experience|work)", text, re.IGNORECASE)
        if work_exp_match:
            resume["work_exp_flt"] = float(work_exp_match.group(1))
    else:
        work_exp_match = re.search(r"(\d+)\s*年.*?经验", text)
        if work_exp_match:
            resume["work_exp_flt"] = float(work_exp_match.group(1))

    # --- Graduation Year ---
    if _is_english(lang):
        grad_match = re.search(r"(?:Graduat(?:ed|ion)|Class\s*of)\s*[:：]?\s*((?:19|20)\d{2})", text, re.IGNORECASE)
        if grad_match:
            resume["edu_end_int"] = int(grad_match.group(1))
    else:
        grad_match = re.search(r"((?:19|20)\d{2})\s*年.*?毕业", text)
        if grad_match:
            resume["edu_end_int"] = int(grad_match.group(1))

    if "name_kwd" not in resume:
        resume["name_kwd"] = "Unknown" if _is_english(lang) else "未知"

    return resume


# ==================== Phase 4: Post-processing Pipeline ====================


def _shingling_jaccard(text1: str, text2: str, n: int = 5) -> float:
    """Jaccard similarity via tiktoken n-gram shingling."""
    if not text1 or not text2 or _tiktoken_encoding is None:
        return 0.0
    tokens1 = _tiktoken_encoding.encode(text1)
    tokens2 = _tiktoken_encoding.encode(text2)
    if len(tokens1) < n:
        s1 = {tuple(tokens1)} if tokens1 else set()
    else:
        s1 = {tuple(tokens1[i : i + n]) for i in range(len(tokens1) - n + 1)}
    if len(tokens2) < n:
        s2 = {tuple(tokens2)} if tokens2 else set()
    else:
        s2 = {tuple(tokens2[i : i + n]) for i in range(len(tokens2) - n + 1)}
    union = s1 | s2
    if not union:
        return 1.0
    return len(s1 & s2) / len(union)


def _postprocess_resume(resume: dict, lines: list[str], lang: str = "Chinese") -> dict:
    """Four-phase post-processing: source validation → domain normalization → dedup → completion."""
    _en = _is_english(lang)
    full_text = "\n".join(lines) if lines else ""
    norm_full_text = _normalize_for_comparison(full_text)

    # --- Phase 1: Source text validation ---
    _unknown_names = ("未知", "Unknown")
    if resume.get("name_kwd") and resume["name_kwd"] not in _unknown_names:
        norm_name = _normalize_for_comparison(resume["name_kwd"])
        if norm_full_text and norm_name and norm_name not in norm_full_text:
            logger.warning(f"Name '{resume['name_kwd']}' not found in source text, cleared")
            resume["name_kwd"] = ""

    if resume.get("corp_nm_tks") and norm_full_text:
        verified_companies = []
        for company in resume["corp_nm_tks"]:
            norm_company = _normalize_for_comparison(company)
            if norm_company and norm_company in norm_full_text:
                verified_companies.append(company)
        resume["corp_nm_tks"] = verified_companies
        if verified_companies:
            resume["corporation_name_tks"] = verified_companies[0]
        else:
            resume["corporation_name_tks"] = ""

    if resume.get("school_name_tks") and norm_full_text:
        verified_schools = []
        for school in resume["school_name_tks"]:
            norm_school = _normalize_for_comparison(school)
            if norm_school and norm_school in norm_full_text:
                verified_schools.append(school)
        resume["school_name_tks"] = verified_schools
        if verified_schools:
            if resume.get("first_school_name_tks") and resume["first_school_name_tks"] not in verified_schools:
                resume["first_school_name_tks"] = verified_schools[-1]
        else:
            resume["first_school_name_tks"] = ""

    if resume.get("position_name_tks") and norm_full_text:
        verified_positions = []
        for pos in resume["position_name_tks"]:
            norm_pos = _normalize_for_comparison(pos)
            if norm_pos and norm_pos in norm_full_text:
                verified_positions.append(pos)
        if verified_positions:
            resume["position_name_tks"] = verified_positions

    # --- Phase 2: Domain normalization ---
    if resume.get("birth_dt"):
        resume["birth_dt"] = re.sub(r"[年月]", "-", str(resume["birth_dt"])).rstrip("-")

    if resume.get("phone_kwd"):
        phone = re.sub(r"[^\d+]", "", str(resume["phone_kwd"]))
        if phone:
            resume["phone_kwd"] = phone

    if resume.get("gender_kwd"):
        gender = str(resume["gender_kwd"]).strip()
        if gender in ("male", "Male", "M", "m", "男"):
            resume["gender_kwd"] = "Male" if _en else "男"
        elif gender in ("female", "Female", "F", "f", "女"):
            resume["gender_kwd"] = "Female" if _en else "女"

    # --- Phase 3: Contextual deduplication ---
    for list_field in ["corp_nm_tks", "school_name_tks", "major_tks", "position_name_tks", "skill_tks"]:
        if isinstance(resume.get(list_field), list):
            seen = set()
            deduped = []
            for item in resume[list_field]:
                item_str = str(item).strip()
                if item_str and item_str not in seen:
                    seen.add(item_str)
                    deduped.append(item_str)
            resume[list_field] = deduped

    # --- Phase 3.4: work_desc dedup by company + time overlap ---
    work_descs = resume.get("work_desc_tks", [])
    if len(work_descs) > 1:
        corp_names = resume.get("corp_nm_tks", [])
        work_details = resume.get("_work_exp_details", [])
        positions = resume.get("position_name_tks", [])
        kept_indices = []
        for i in range(len(work_descs)):
            is_dup = False
            corp_i = _normalize_for_comparison(corp_names[i]) if i < len(corp_names) else ""
            detail_i = work_details[i] if i < len(work_details) else {}
            start_i = detail_i.get("start_date", "")
            end_i = detail_i.get("end_date", "")
            dt_start_i = _parse_date_str(start_i) if start_i else None
            dt_end_i = _parse_date_str(end_i) if end_i else None
            for j in kept_indices:
                corp_j = _normalize_for_comparison(corp_names[j]) if j < len(corp_names) else ""
                if corp_i and corp_j:
                    shorter_c, longer_c = (corp_i, corp_j) if len(corp_i) <= len(corp_j) else (corp_j, corp_i)
                    if shorter_c in longer_c:
                        detail_j = work_details[j] if j < len(work_details) else {}
                        start_j = detail_j.get("start_date", "")
                        end_j = detail_j.get("end_date", "")
                        dt_start_j = _parse_date_str(start_j) if start_j else None
                        dt_end_j = _parse_date_str(end_j) if end_j else None
                        if dt_start_i and dt_start_j:
                            eff_end_i = dt_end_i or datetime.datetime(2099, 12, 1)
                            eff_end_j = dt_end_j or datetime.datetime(2099, 12, 1)
                            if dt_start_i <= eff_end_j and dt_start_j <= eff_end_i:
                                is_dup = True
                                break
                        elif (start_i and start_j and start_i == start_j) or (end_i and end_j and end_i == end_j):
                            is_dup = True
                            break
                norm_i = _normalize_for_comparison(work_descs[i])
                norm_j = _normalize_for_comparison(work_descs[j])
                shorter, longer = (norm_i, norm_j) if len(norm_i) <= len(norm_j) else (norm_j, norm_i)
                if shorter and longer and shorter in longer:
                    is_dup = True
                    break
                if _shingling_jaccard(work_descs[i], work_descs[j], n=5) > 0.5:
                    is_dup = True
                    break
            if is_dup:
                dup_corp = corp_names[i] if i < len(corp_names) else f"#{i + 1}"
                logger.debug(f"Work desc internal duplicate removed: {dup_corp}")
            else:
                kept_indices.append(i)
        if len(kept_indices) < len(work_descs):
            resume["work_desc_tks"] = [work_descs[i] for i in kept_indices]
            if corp_names:
                resume["corp_nm_tks"] = [corp_names[i] for i in kept_indices if i < len(corp_names)]
            if work_details:
                resume["_work_exp_details"] = [work_details[i] for i in kept_indices if i < len(work_details)]
            if positions:
                resume["position_name_tks"] = [positions[i] for i in kept_indices if i < len(positions)]
            new_details = resume.get("_work_exp_details", [])
            if new_details:
                recalc_years = round(sum(d.get("years", 0) for d in new_details), 1)
                if recalc_years > 0:
                    resume["work_exp_flt"] = recalc_years
            new_corps = resume.get("corp_nm_tks", [])
            if new_corps:
                resume["corporation_name_tks"] = new_corps[0]

    # --- Phase 3.5: Merge project_desc_tks into work_desc_tks ---
    work_descs = resume.get("work_desc_tks", [])
    project_descs = resume.get("project_desc_tks", [])
    resume["_raw_project_descs"] = list(project_descs) if project_descs else []
    if project_descs:
        project_names = resume.get("project_tks", [])
        merged_count = 0
        skipped_count = 0
        for i, proj_desc in enumerate(project_descs):
            norm_proj = _normalize_for_comparison(proj_desc)
            if not norm_proj:
                continue
            already_exists = False
            for wd in work_descs:
                norm_wd = _normalize_for_comparison(wd)
                if not norm_wd:
                    continue
                shorter, longer = (norm_proj, norm_wd) if len(norm_proj) <= len(norm_wd) else (norm_wd, norm_proj)
                if shorter in longer:
                    already_exists = True
                    break
                if _shingling_jaccard(proj_desc, wd, n=5) > 0.5:
                    already_exists = True
                    break
            if already_exists:
                skipped_count += 1
            else:
                proj_name = project_names[i] if i < len(project_names) else ""
                if proj_name:
                    work_descs.append(f"[{proj_name}] {proj_desc}")
                else:
                    work_descs.append(proj_desc)
                merged_count += 1
        resume["work_desc_tks"] = work_descs
        resume["project_desc_tks"] = []
        logger.info(f"Merged project descs into work_desc_tks: {merged_count} merged, {skipped_count} skipped")

    # --- Phase 4: Field completion ---
    required_fields = [
        "name_kwd",
        "gender_kwd",
        "phone_kwd",
        "email_tks",
        "position_name_tks",
        "school_name_tks",
        "major_tks",
    ]
    for field in required_fields:
        if field not in resume:
            if field.endswith("_tks"):
                resume[field] = []
            elif field.endswith("_int") or field.endswith("_flt"):
                resume[field] = 0
            else:
                resume[field] = ""

    resume.pop("_name_confidence", None)

    return resume


# ==================== Pipeline Orchestration ====================


async def parse_resume(filename: str, binary: bytes, lang: str = "Chinese") -> tuple[dict, list[str], list[dict]]:
    """Resume parsing pipeline: extract → parallel LLM extract → regex fallback → post-process."""
    indexed_text, lines, line_positions = extract_text(filename, binary)
    if not indexed_text or not lines:
        logger.warning(f"Text extraction returned empty: {filename}")
        default_name = "Unknown" if _is_english(lang) else "未知"
        return {"name_kwd": default_name}, [], []

    resume = await parse_with_llm(indexed_text, lines, lang)

    if not resume:
        logger.info(f"LLM parsing failed, falling back to regex parsing: {filename}")
        plain_text = "\n".join(lines)
        resume = parse_with_regex(plain_text, lang)

    resume = _postprocess_resume(resume, lines, lang)

    return resume, lines, line_positions


def parse_resume_plain_text(text: str, lang: str = "Chinese") -> dict:
    """Parse a plain-text resume (no filename/binary) through regex + post-process.

    Used by paste/email flows where only text is available; LLM extraction is
    left to the async entry point in services.py.
    """
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    resume = parse_with_regex(text, lang)
    return _postprocess_resume(resume, lines, lang)


async def parse_resume_text(text: str, lang: str = "Chinese") -> dict:
    """Parse plain resume text through the LLM pipeline with regex fallback.

    Builds line-indexed text from the raw lines, runs the 4 parallel LLM
    subtasks, falls back to regex, then post-processes.
    """
    raw_lines = [line.strip() for line in text.split("\n") if line.strip()]
    if not raw_lines:
        return {"name_kwd": "Unknown" if _is_english(lang) else "未知"}

    indexed_text = "\n".join(f"[{i}]: {line}" for i, line in enumerate(raw_lines))

    resume = await parse_with_llm(indexed_text, raw_lines, lang)
    if not resume:
        logger.info("LLM parsing failed on plain text, falling back to regex")
        resume = parse_with_regex(text, lang)

    return _postprocess_resume(resume, raw_lines, lang)
