"""集中日志配置 — dictConfig + 请求链路上下文。

初始化入口：``app/__init__.py`` 在加载业务包之前调用 ``configure_logging()``。
输出目标：控制台（开发调试）+ ``logs/app.log``（线上排查，按天轮转、单文件
大小上限双重保险）。目录可用 ``APP_LOG_DIR`` 覆盖（部署环境可指向
/var/log/xxx），默认项目根相对路径 logs/，保证跨平台兼容。

全局级别由 ``LOG_LEVEL`` 环境变量控制（默认 INFO），调整后重启进程生效。
"""

import logging
import logging.config
import os
from contextvars import ContextVar
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - [%(request_id)s] - %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_BACKUP_COUNT = 30  # 按天切割保留 30 天
DEFAULT_MAX_BYTES = 100 * 1024 * 1024  # 单文件上限 100MB

# 请求链路上下文：RequestContextMiddleware 写入，RequestIdFilter 注入每条日志。
request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)

_CONFIGURED = False


class RequestIdFilter(logging.Filter):
    """把 contextvars 中的 request_id 注入日志记录，缺失时显示 "-"。"""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get() or "-"
        return True


class SizeCapTimedRotatingFileHandler(TimedRotatingFileHandler):
    """按天轮转 + 单文件大小上限，双重保险防止磁盘占满。

    Python 3.10 的 TimedRotatingFileHandler 不支持 maxBytes（3.11 才内置），
    为兼容项目声明的 3.10+ 基线，这里显式覆写 shouldRollover 补齐大小检查。
    同一天内既触发零点轮转又触发大小轮转时，较早的当日备份会被覆盖。
    """

    def __init__(
        self,
        filename,
        when="midnight",
        backupCount=DEFAULT_BACKUP_COUNT,
        maxBytes=DEFAULT_MAX_BYTES,
        encoding="utf-8",
        **kwargs,
    ):
        super().__init__(filename, when=when, backupCount=backupCount, encoding=encoding, **kwargs)
        self.maxBytes = maxBytes

    def shouldRollover(self, record: logging.LogRecord) -> bool:
        if super().shouldRollover(record):
            return True
        if self.maxBytes <= 0:
            return False
        if self.stream is None:
            self.stream = self._open()
        self.stream.seek(0, os.SEEK_END)
        message = f"{self.format(record)}\n"
        return self.stream.tell() + len(message.encode("utf-8")) >= self.maxBytes


def _log_dir() -> str:
    override = os.getenv("APP_LOG_DIR")
    if override:
        return override
    return str(Path(__file__).resolve().parent.parent / "logs")


def _resolve_level() -> int:
    level_name = os.getenv("LOG_LEVEL", DEFAULT_LOG_LEVEL).upper()
    level = getattr(logging, level_name, None)
    if not isinstance(level, int):
        level = logging.INFO
    return level


def configure_logging() -> None:
    """应用 dictConfig 集中日志配置；幂等，重复调用无副作用。"""
    global _CONFIGURED
    if _CONFIGURED:
        return

    handlers: dict = {
        "console": {
            "class": "logging.StreamHandler",
            "level": "NOTSET",
            "formatter": "standard",
            "filters": ["request_context"],
            "stream": "ext://sys.stderr",
        },
    }
    handler_names = ["console"]

    # 测试环境（TESTING=1）不落文件，避免污染工作区。
    if os.getenv("TESTING") != "1":
        log_dir = _log_dir()
        os.makedirs(log_dir, exist_ok=True)
        handlers["file"] = {
            "class": "app.log_config.SizeCapTimedRotatingFileHandler",
            "level": "NOTSET",
            "formatter": "standard",
            "filters": ["request_context"],
            "filename": os.path.join(log_dir, "app.log"),
            "when": "midnight",
            "backupCount": DEFAULT_BACKUP_COUNT,
            "maxBytes": DEFAULT_MAX_BYTES,
            "encoding": "utf-8",
        }
        handler_names.append("file")

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,  # 保留 uvicorn 等已存在的 logger 配置
            "filters": {
                "request_context": {"()": "app.log_config.RequestIdFilter"},
            },
            "formatters": {
                "standard": {"format": LOG_FORMAT, "datefmt": LOG_DATEFMT},
            },
            "handlers": handlers,
            "root": {"level": _resolve_level(), "handlers": handler_names},
        }
    )
    _CONFIGURED = True
