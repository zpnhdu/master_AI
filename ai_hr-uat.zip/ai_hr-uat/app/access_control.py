"""Session authentication and permission checks shared by routes and middleware."""

import hashlib
import os
from urllib.parse import parse_qs
from typing import Optional

from fastapi import HTTPException
from starlette.requests import Request

from app.db import get_auth_user_by_session, get_auth_user_by_username

COOKIE_NAME = "aihr_session"
LEGACY_TEST_COOKIE = "authenticated"
TRUE_VALUES = {"1", "true", "yes", "on", "strict"}


def strict_rbac_enabled() -> bool:
    value = os.getenv("AIHR_STRICT_RBAC")
    if value is not None:
        return value.strip().lower() in TRUE_VALUES
    # 权限控制是生产安全边界，默认必须收紧；仅在明确配置为 false 时才允许
    # 使用迁移期的兼容行为（所有已启用账号拥有全量权限）。
    return True


def apply_effective_permissions(user: Optional[dict]) -> Optional[dict]:
    if not user:
        return None
    effective_user = dict(user)
    effective_user["rbac_strict"] = strict_rbac_enabled()
    if not effective_user["rbac_strict"] and effective_user.get("is_active"):
        effective_user["permissions"] = ["*"]
    return effective_user


def session_token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def user_from_session_token(token: str) -> Optional[dict]:
    if not token:
        return None

    user = get_auth_user_by_session(session_token_hash(token))
    if user:
        return apply_effective_permissions(user)

    # 旧测试曾使用固定 Cookie。仅在 TESTING=1 时兼容，生产环境不会接受该固定值。
    if os.getenv("TESTING") == "1" and token == LEGACY_TEST_COOKIE:
        return apply_effective_permissions(get_auth_user_by_username("shanghai"))
    return None


def has_permission(user: Optional[dict], permission: Optional[str] | set[str] | tuple[str, ...]) -> bool:
    # "*" 是管理员的全量权限标记；其余角色必须显式拥有目标权限。
    # 业务权限是单粒度的：能看到导航页即拥有该页面的操作权限。
    if permission is None:
        return True
    if not user or not user.get("is_active"):
        return False
    if not strict_rbac_enabled():
        return True
    permissions = set(user.get("permissions") or [])
    required = {permission} if isinstance(permission, str) else set(permission)
    if "*" in permissions:
        return True
    return bool(required & permissions)


def current_user(request: Request) -> Optional[dict]:
    return user_from_session_token(request.cookies.get(COOKIE_NAME, ""))


def require_current_user(request: Request) -> dict:
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="未登录")
    return user


def require_permission(request: Request, permission: str) -> dict:
    user = require_current_user(request)
    if not has_permission(user, permission):
        raise HTTPException(status_code=403, detail="无权访问此功能")
    return user


def tenant_id_for_user(user: dict) -> str:
    """Return the server-controlled tenant boundary for a signed-in user."""
    return str(user.get("tenant_id") or "tenant_default")


def is_tenant_admin(user: dict) -> bool:
    # Row-level tenant administration must follow the persisted role. In
    # relaxed RBAC mode ordinary users receive an effective "*" permission,
    # but that compatibility flag must never widen their data visibility.
    return user.get("role_id") == "admin"


def require_pipeline_access(
    request: Request,
    pipeline_id: str,
    permission: Optional[str | set[str] | tuple[str, ...]] = None,
) -> dict:
    """Authorize the module and row-level access for a pipeline.

    Business navigation permissions are operation-independent, so the request
    path determines the required navigation permission unless an explicit one
    is supplied. A 404 is returned for another user's pipeline so its existence is
    not disclosed through an ID-guessing request.
    """
    user = require_current_user(request)
    required_permission = (
        permission if permission is not None else required_api_permission(request.url.path, request.method)
    )
    if required_permission and not has_permission(user, required_permission):
        raise HTTPException(status_code=403, detail="无权访问此功能")

    from app.db import get_pipeline_for_user

    pipeline = get_pipeline_for_user(
        pipeline_id,
        user_id=str(user["id"]),
        tenant_id=tenant_id_for_user(user),
        include_all=is_tenant_admin(user),
    )
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return pipeline


def require_pipeline_path_access(request: Request) -> None:
    """FastAPI dependency for routes whose path contains ``pipeline_id``."""
    # Candidate video playback is intentionally public and protected by its
    # generated interview URL rather than the HR login session.
    if request.url.path.startswith(("/api/mass-interview/video/", "/api/mass-interview/thumbnail/")):
        return
    pipeline_id = request.path_params.get("pipeline_id")
    if pipeline_id:
        # Two bootstrap endpoints intentionally return a minimal response for a
        # missing pipeline. Existing pipelines still pass through ownership.
        if request.method == "GET" and (
            request.url.path.endswith("/bootstrap") or "/interview-questions/generation/" in request.url.path
        ):
            from app.db import get_pipeline

            if not get_pipeline(str(pipeline_id)):
                return
        # Navigation access is operation-independent; this dependency only
        # enforces the pipeline's tenant/owner boundary.
        require_pipeline_access(request, str(pipeline_id))


def require_pipeline_query_access(request: Request) -> None:
    """FastAPI dependency for routes that receive ``pipeline_id`` in the query string."""
    pipeline_id = request.query_params.get("pipeline_id")
    if pipeline_id:
        require_pipeline_access(request, pipeline_id)


def require_candidate_access(
    request: Request,
    candidate_id: str,
    expected_pipeline_id: Optional[str] = None,
) -> dict:
    """Authorize a candidate through its owning pipeline."""
    from app.db import get_db

    row = get_db().execute("SELECT pipeline_id FROM candidates WHERE id=%s", (candidate_id,)).fetchone()
    if not row or (expected_pipeline_id and str(row["pipeline_id"]) != str(expected_pipeline_id)):
        raise HTTPException(status_code=404, detail="Candidate not found")
    return require_pipeline_access(request, str(row["pipeline_id"]))


def required_page_permission(path: str, query: str = "") -> Optional[str]:
    # 页面权限按产品模块划分；实际 HTML 访问由 main.py 的中间件统一拦截。
    if path in {"/", "/forbidden", "/login", "/privacy", "/terms"}:
        return None
    if path in {"/frontend/admin.html", "/frontend/user-admin.html", "/admin"}:
        return "user:manage"
    if path.startswith("/roles/") or path in {"/frontend/role.html", "/frontend/agent.html"}:
        return "system:manage"
    if path in {"/dashboard", "/monitor"} or path in {"/frontend/dashboard.html", "/frontend/monitor.html"}:
        return "analytics:read"
    if path in {"/talent-pool", "/profile"} or path in {
        "/frontend/talent-pool.html",
        "/frontend/profile.html",
    }:
        return "talent:read"
    if path in {"/mass-dashboard", "/frontend/mass-dashboard.html"} or path.startswith("/mass-dashboard/"):
        return "interview:read"
    if path == "/knowledge" or path == "/frontend/knowledge.html":
        query_params = parse_qs(query, keep_blank_values=True)
        return "materials:read" if query_params.get("tab") == ["materials"] else "knowledge:read"
    if (
        path == "/studio"
        or path.startswith("/frontend/")
        or path.startswith("/pipelines/")
        or path
        in {
            "/pipeline-detail",
            "/xiao-hai",
            "/xiao-wen",
            "/xiao-xun",
            "/xiao-shai",
            "/xiao-mian",
            "/xiao-ping",
        }
    ):
        return "pipeline:read"
    return None


def required_api_permission(path: str, method: str) -> Optional[str | set[str]]:
    """Map every business API method to its navigation permission."""
    if path.startswith("/api/admin/"):
        return "user:manage"
    if path.startswith("/api/auth/"):
        return None
    if (
        path == "/api/agents"
        or path.startswith("/api/agents/")
        or path == "/api/roles"
        or path.startswith("/api/roles/")
    ):
        return "system:manage"
    if (
        path == "/api/ontology"
        or path.startswith("/api/ontology/")
        or path == "/api/memory"
        or path.startswith("/api/memory/")
    ):
        return "system:manage"
    if path.startswith("/api/company-config"):
        return "system:manage"
    if path.startswith("/api/analytics") or path.startswith("/api/monitor") or path.startswith("/api/proactive"):
        return "analytics:read"
    if path.startswith("/api/communication-templates") or path == "/api/knowledge-cards":
        return "pipeline:read"
    if (
        path.startswith("/api/candidate-assistant")
        or path.startswith("/api/outreach")
        or path.startswith("/api/scheduling")
    ):
        return "pipeline:read"
    if path.startswith("/api/liepin/plugin"):
        return "talent:read"
    if path.startswith("/api/interview-copilot") or path == "/api/generate-quiz-questions":
        return "interview:read"
    if path == "/api/studio/stats" or path == "/api/action":
        return "pipeline:read"
    if path.startswith("/api/xiao-hai/elements"):
        # The shared picker is used by the pipeline workbench; mutation of the
        # global library itself remains exclusive to the materials navigation.
        return "materials:read" if method in {"POST", "DELETE"} else {"materials:read", "pipeline:read"}
    if path.startswith("/api/xiao-hai/canvases"):
        return {"materials:read", "pipeline:read"}
    if path.startswith("/api/xiao-hai"):
        return "pipeline:read"
    if path.startswith("/api/talent-pool"):
        return {"talent:read", "pipeline:read"} if "pipeline_id" in path else "talent:read"
    if path.startswith("/api/resumes") or path.startswith("/api/candidates"):
        return {"talent:read", "pipeline:read"}
    if path.startswith("/api/email-accounts"):
        return "talent:read"
    if (
        path.startswith("/api/interview")
        or path.startswith("/api/interviews")
        or path.startswith("/api/videos")
        or path.startswith("/api/assessment")
        or path.startswith("/api/written-test")
    ):
        return {"interview:read", "pipeline:read"}
    if path.startswith("/api/knowledge/recommend"):
        return "pipeline:read"
    if path.startswith("/api/knowledge"):
        return "knowledge:read"
    if path.startswith("/api/mass-interview"):
        return "interview:read"
    if path == "/api/files" or path.startswith("/api/files/"):
        return "pipeline:read"
    if (
        path.startswith("/api/pipelines")
        or path.startswith("/api/conversations")
        or path.startswith("/api/jd")
        or path.startswith("/api/screening")
        or path.startswith("/api/messages")
        or path.startswith("/api/profile")
        or path.startswith("/api/poster")
        or path.startswith("/api/rpa")
        or path.startswith("/api/feishu")
        or path.startswith("/api/email")
    ):
        return "pipeline:read"
    return None


def default_page_for(user: dict) -> str:
    for path, permission in (
        ("/studio", "pipeline:read"),
        ("/mass-dashboard", "interview:read"),
        ("/dashboard", "analytics:read"),
        ("/talent-pool", "talent:read"),
        ("/knowledge?tab=materials", "materials:read"),
        ("/knowledge", "knowledge:read"),
        ("/admin", "user:manage"),
    ):
        if has_permission(user, permission):
            return path
    return "/forbidden"
