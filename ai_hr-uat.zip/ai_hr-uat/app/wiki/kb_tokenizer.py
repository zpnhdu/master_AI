#
#  Copyright 2025 The InfiniFlow Authors. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

"""Tokenization utilities for document RAG — lightweight Python port of ragflow.

ragflow's production tokenizer is the HuQie C++ engine bundled in the
``infinity`` package; this module replaces it with pure-Python equivalents
(jieba for Chinese word segmentation, naive splitting for English) while
preserving the same output contract:

- ``tokenize``          -> space-joined tokens (mixed Chinese/English)
- ``fine_grained_tokenize`` -> CJK characters one-per-token, ASCII runs kept whole
- ``num_tokens_from_string`` -> token count for the tiktoken cl100k_base encoder
"""

from __future__ import annotations

import re

__all__ = [
    "fine_grained_tokenize",
    "num_tokens_from_string",
    "tokenize",
]

_CJK_CHAR = re.compile(r"[\u4e00-\u9fff]")
# Split runs of CJK vs non-CJK: used by fine_grained_tokenize.
_CJK_RUN = re.compile(r"[\u4e00-\u9fff]|[^\u4e00-\u9fff]+")
# Tokens that carry no information and should never enter the index.
_TOKEN_DROP = re.compile(r"^[\W_]+$", re.UNICODE)

# Full-width -> half-width mapping for ASCII (ragflow strQ2B approximation).
# 0xFF01..0xFF5E -> 0x21..0x7E (94 chars each).
_FW_TO_HW = str.maketrans(
    "".join(chr(c) for c in range(0xFF01, 0xFF5F)),
    "".join(chr(c) for c in range(0x21, 0x7F)),
)
_FW_SPACE = str.maketrans({"\u3000": " "})


def _normalize(text: str) -> str:
    """Normalize full-width punctuation/space before tokenization."""
    return (text or "").translate(_FW_TO_HW).translate(_FW_SPACE)


def _jieba():
    try:
        import jieba

        return jieba
    except ImportError as e:  # pragma: no cover - dependency guard
        raise RuntimeError("jieba 未安装，请先 `pip install jieba`") from e


def tokenize(line: str) -> str:
    """Tokenize text into a space-joined token string (mirrors HuQie output).

    Chinese text is segmented with jieba; consecutive ASCII letters/digits are
    kept as one token; punctuation-only tokens are dropped; ASCII tokens are
    lowercased for case-insensitive matching.
    """
    if not line:
        return ""

    jieba = _jieba()
    tokens = []
    for raw in jieba.cut(_normalize(line)):
        tok = raw.strip()
        if not tok:
            continue
        if _TOKEN_DROP.match(tok):
            continue
        # jieba emits punctuation inline for mixed scripts; split ASCII word runs.
        if _CJK_CHAR.search(tok):
            # Mixed/NN token: split off any non-CJK punctuation, keep the CJK piece.
            if len(tok) == 1 and not _CJK_CHAR.match(tok):
                continue
            tokens.append(tok)
        else:
            tok = tok.lower()
            if not _TOKEN_DROP.match(tok):
                tokens.append(tok)
    return " ".join(tokens)


def fine_grained_tokenize(tks: str) -> str:
    """Split tokens into finer granularity.

    Each CJK character becomes its own token; contiguous non-CJK runs (English
    words, numbers) are preserved as a single token. Used to compute fuzzy
    character-level matches for rare/long CJK terms.
    """
    if not tks:
        return ""
    out = []
    for token in (tks or "").split():
        if not token or _TOKEN_DROP.match(token):
            continue
        parts = _CJK_RUN.findall(token)
        if len(parts) == 1:
            out.append(parts[0])
        else:
            out.extend(p for p in parts if p)
    return " ".join(out)


# ── token counting ──────────────────────────────────────────

_ENCODER = None


def _get_encoder():
    global _ENCODER
    if _ENCODER is None:
        try:
            import tiktoken

            _ENCODER = tiktoken.get_encoding("cl100k_base")
        except Exception:  # pragma: no cover - degraded fallback
            _ENCODER = False
    return _ENCODER or None


def num_tokens_from_string(text: str) -> int:
    """Return the cl100k_base token count for ``text``.

    Falls back to a character count if tiktoken is unavailable so that chunk
    budgeting never raises.
    """
    if not text:
        return 0
    encoder = _get_encoder()
    if encoder is None:
        return len(text)
    try:
        return len(encoder.encode(text))
    except Exception:  # pragma: no cover
        return len(text)
