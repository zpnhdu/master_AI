"""LLM-wiki 存储层 — markdown 为单一真源，MySQL 只存元数据与向量。

忠实移植 llm_wiki 的「Raw Sources → Wiki → Schema」三层结构与
「Ingest / Query / Lint」三个操作。生产布局：

    OSS ai-hr/{env}/knowledge/pages/
      schema.md             # 页类型路由（type -> wiki/ 下目录）
      purpose.md            # 项目目标
      wiki/                 # 内容页、聚合页与流水
    OSS ai-hr/{env}/knowledge/source/
      <source_id>.<ext>     # 不可变原始资料
    OSS ai-hr/{env}/knowledge/cache/ingest-cache.json
    data/llm_wiki/          # 本地开发目录与迁移前兼容回退
      schema.md             # 页类型路由（type -> wiki/ 下目录）
      purpose.md            # 项目目标
      raw/                  # 不可变原始资料 <slug>.<ext>
      wiki/
        index.md            # 目录【应用维护】
        overview.md         # 概览【应用维护，确定性生成】
        log.md              # 流水【应用追加】
        entities/ concepts/ sources/ methods/ rules/ scenarios/ …  # LLM 生成页
      .llm-wiki/ingest-cache.json   # sha256 + filesWritten

MySQL 表：wiki_ingest（状态）与 wiki_pages（页索引/向量）。

设计约束：
- 所有落盘的页路径必须通过 is_safe_page_path 沙箱（强制 wiki/ 前缀、禁 .. / 绝对路径 / 设备名）。
- 建表幂等（CREATE TABLE IF NOT EXISTS），不依赖 app.db.init_db()。
- 时间戳用进程内单调 _now()，规避 Windows 时钟量化导致排序不稳。
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import yaml

from app.config import UPLOAD_DIR
from app.db import get_db
from app.infrastructure.config import settings
from app.media_storage import MediaStorage, get_media_storage, join_storage_key

logger = logging.getLogger("app.wiki_store")

_schema_lock = threading.Lock()
_prepared_db = None
# ensure_dirs 只做「本地建目录 + 一次性种子文件」两件事。种子文件落一次后
# 无需每次请求都 exists 校验；用 (WIKI_DIR, backend) 作为签名跳过后续调用，
# 同时兼容测试每次换临时目录（签名变化即重新 seed）。这消除了每次打开页树/
# 图谱都打 5 次 OSS exists 的冗余 I/O——页面多或冷启动后首屏慢的主要来源之一。
_dir_seed_signature: tuple | None = None
_dirs_init_lock = threading.Lock()

# ── 常量 ────────────────────────────────────────────────────

WIKI_DIR = os.path.normpath(os.path.join(os.path.dirname(UPLOAD_DIR), "data", "llm_wiki"))
RAW_DIR = os.path.join(WIKI_DIR, "raw")
WIKI_PAGES_DIR = os.path.join(WIKI_DIR, "wiki")
CACHE_DIR = os.path.join(WIKI_DIR, ".llm-wiki")
CACHE_PATH = os.path.join(CACHE_DIR, "ingest-cache.json")
WIKI_CONTENT_BACKEND = str(settings.wiki_content_storage_backend or "local").strip().lower()
WIKI_CONTENT_PREFIX = join_storage_key(settings.oss_knowledge_prefix, "pages")
WIKI_CACHE_STORAGE_KEY = join_storage_key(settings.oss_knowledge_prefix, "cache", "ingest-cache.json")

_content_storage_lock = threading.Lock()
_content_storage_instance: MediaStorage | None = None
_content_storage_backend: str | None = None

# OSS 内容页是不可变 Markdown 真源；应用内写入/删除时会主动失效，TTL 只兜底
# 其它进程或人工在 OSS 上修改内容的情况，避免每次打开图谱都重复请求远端对象。
WIKI_CONTENT_CACHE_TTL_SECONDS = 30.0
_content_cache_lock = threading.Lock()
_content_cache: dict[tuple[int, str], tuple[float, str]] = {}

# 页列表（list_page_paths）缓存：页树/图谱每次打开都会先列出全部页路径，
# 若每次都走 OSS list_keys 再 os.walk 本地目录，页面一多就会成为主要延迟。
# 写入/删除页时主动失效，TTL 兜底其它进程在 OSS 上的变更。
WIKI_LIST_CACHE_TTL_SECONDS = 30.0
_list_cache_lock = threading.Lock()
_page_list_cache: dict[int, tuple[float, list[str]]] = {}

# 页类型 -> 目录路由（schema.md 的种子值，ingest 时据此校验 FILE 路径）
DEFAULT_TYPE_DIRS: dict[str, str] = {
    "entity": "wiki/entities",
    "concept": "wiki/concepts",
    "source": "wiki/sources",
    "method": "wiki/methods",
    "rule": "wiki/rules",
    "scenario": "wiki/scenarios",
}

# 内容同时符合多种类型时，按此顺序取更具体的本体类型。source 由系统创建，
# 不允许模型自由生成；无法有把握归类时应回退到 concept。
KNOWLEDGE_TYPE_PRIORITY = ("source", "entity", "rule", "method", "scenario", "concept")

KNOWLEDGE_TYPE_GUIDANCE: dict[str, dict[str, str]] = {
    "entity": {
        "definition": "唯一、具体且可指认的人、组织、岗位、产品、系统、工具或制度对象。",
        "positive": "上海分公司、招聘管理系统",
        "negative": "人才盘点（概念）、面试评分流程（方法）、试用期不得超过六个月（规则）",
    },
    "concept": {
        "definition": "稳定的知识名词、术语或定义，重点是解释是什么及其核心属性。",
        "positive": "人才盘点、胜任力模型、人才密度",
        "negative": "上海分公司（实体）、面试三步流程（方法）、必须在 48 小时内反馈（规则）",
    },
    "method": {
        "definition": "可复用、可执行的做法、步骤、流程或操作方式，重点是如何做。",
        "positive": "面试分为准备、提问、评分三步、结构化面试实施流程",
        "negative": "人才盘点（概念）、试用期时限（规则）、跨部门调岗审批（场景）",
    },
    "rule": {
        "definition": "必须强制遵守的约束、禁止事项、阈值、时限或条件，重点是边界和强制性。",
        "positive": "候选人必须在 48 小时内反馈、试用期最长不得超过六个月",
        "negative": "面试实施流程（方法）、校园招聘中的批量面试（场景）、招聘管理系统（实体）",
    },
    "scenario": {
        "definition": "参与者在特定触发条件和上下文中，为达成目标而使用知识的业务情境或案例。",
        "positive": "跨部门调岗审批场景、校园招聘中的批量面试",
        "negative": "调岗审批步骤（方法）、调岗审批时限（规则）、胜任力模型（概念）",
    },
    "source": {
        "definition": "原始资料及其文件元数据的溯源入口；每份上传资料由系统确定性生成一个来源页。",
        "positive": "上传的原始 PDF（如员工手册 2026.pdf）、招聘 SOP.docx",
        "negative": "任何从原文抽取的实体、概念、方法、规则或场景；模型不得生成来源页",
    },
}


def knowledge_type_guidance() -> str:
    """返回供 schema 与 LLM 提示词复用的六类知识边界说明。"""
    lines = [
        "六类知识定义（AUTHORITATIVE）",
        "冲突判定优先级：source → entity → rule → method → scenario → concept",
        "source 页由系统确定性生成，模型不得生成或重复生成 source 页；低置信度时回退到 concept。",
        "",
    ]
    for ptype in ("entity", "concept", "method", "rule", "scenario", "source"):
        item = KNOWLEDGE_TYPE_GUIDANCE[ptype]
        lines.extend(
            [
                f"- {ptype}: {item['definition']}",
                f"  正例：{item['positive']}",
                f"  反例：{item['negative']}",
            ]
        )
    return "\n".join(lines)


# 应用维护的聚合文件，不走「内容页」树/检索/生成流程。
AGGREGATE_PATHS = {"wiki/index.md", "wiki/overview.md", "wiki/log.md"}


def _content_storage() -> MediaStorage | None:
    """返回知识库内容存储；生产环境为 OSS，测试/本地可继续使用磁盘。"""
    global _content_storage_instance, _content_storage_backend
    backend = WIKI_CONTENT_BACKEND
    if backend not in {"oss", "aliyun"}:
        return None
    with _content_storage_lock:
        if _content_storage_instance is None or _content_storage_backend != backend:
            _content_storage_instance = get_media_storage("oss")
            _content_storage_backend = backend
        return _content_storage_instance


def _is_safe_content_path(path: str) -> bool:
    """校验知识库根级配置文件和 wiki 内容页的相对路径。"""
    normalized = path.replace("\\", "/").strip("/") if isinstance(path, str) else ""
    return normalized in {"schema.md", "purpose.md"} or is_safe_page_path(normalized)


def _content_storage_key(relative_path: str) -> str:
    if not _is_safe_content_path(relative_path):
        raise ValueError(f"invalid wiki content path: {relative_path}")
    normalized = relative_path.replace("\\", "/").strip("/")
    return join_storage_key(WIKI_CONTENT_PREFIX, normalized)


def _read_content_object(relative_path: str) -> Optional[str]:
    storage = _content_storage()
    if storage is None:
        return None
    key = _content_storage_key(relative_path)
    if not storage.exists(key):
        return None
    return storage.read(key).decode("utf-8")


def _write_content_object(relative_path: str, content: str) -> None:
    storage = _content_storage()
    if storage is None:
        raise RuntimeError("wiki content storage is not configured")
    storage.write(_content_storage_key(relative_path), content.encode("utf-8"), "text/markdown; charset=utf-8")


def _content_object_exists(relative_path: str) -> bool:
    storage = _content_storage()
    return bool(storage and storage.exists(_content_storage_key(relative_path)))


def _content_cache_key(storage: MediaStorage, relative_path: str) -> tuple[int, str]:
    normalized = relative_path.replace("\\", "/").strip("/")
    return id(storage), normalized


def _get_cached_content(storage: MediaStorage, relative_path: str) -> Optional[str]:
    key = _content_cache_key(storage, relative_path)
    now = time.monotonic()
    with _content_cache_lock:
        cached = _content_cache.get(key)
        if cached is None:
            return None
        created_at, content = cached
        if now - created_at > WIKI_CONTENT_CACHE_TTL_SECONDS:
            _content_cache.pop(key, None)
            return None
        return content


def _cache_content(storage: MediaStorage, relative_path: str, content: str) -> None:
    with _content_cache_lock:
        _content_cache[_content_cache_key(storage, relative_path)] = (time.monotonic(), content)


def _invalidate_content_cache(relative_path: str) -> None:
    normalized = relative_path.replace("\\", "/").strip("/")
    with _content_cache_lock:
        stale_keys = [key for key in _content_cache if key[1] == normalized]
        for key in stale_keys:
            _content_cache.pop(key, None)


def _invalidate_page_list_cache(storage: MediaStorage | None = None) -> None:
    """页列表发生变化（写入/删除页）后，清掉对应后端的列表缓存。"""
    if storage is None:
        storage = _content_storage()
    cache_id = id(storage) if storage is not None else -1
    with _list_cache_lock:
        _page_list_cache.pop(cache_id, None)


SCHEMA_SEED = (
    """# Wiki Schema

本文件定义 wiki 页的 `type` 与落盘目录之间的路由。ingest 时 LLM 生成的
页必须把 `type` 与目录保持一致（例如 type=concept 必须写进 `wiki/concepts/`）。

## Page Types

| type | directory |
| --- | --- |
| entity | wiki/entities |
| concept | wiki/concepts |
| source | wiki/sources |
| method | wiki/methods |
| rule | wiki/rules |
| scenario | wiki/scenarios |

## 六类知识定义与解析边界

"""
    + knowledge_type_guidance()
    + "\n"
)

PURPOSE_SEED = """# Wiki Purpose

这是一个 HR 招聘流程知识库。原始资料（JD、简历、招聘 SOP、规则、场景）经
LLM 增量编译成可维护的 markdown 页，供招聘团队查询流程、标准与最佳实践。

- 知识编译一次、持续维护，不每次查询重算。
- 页面之间用 `[[wikilink]]` 交叉引用。
"""

# ── 安全沙箱 ────────────────────────────────────────────────

# Windows 保留设备名（CON/PRN/AUX/NUL/COM1-9/LPT1-9）
_DEVICE_RE = re.compile(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$", re.IGNORECASE)
_INVALID_SEGMENT_CHARS_RE = re.compile(r'[<>:"|?*]')


def is_windows_safe_segment(segment: str) -> bool:
    """单个路径段是否可作为 Windows 文件名。"""
    if segment in ("", ".", ".."):
        return False
    if _INVALID_SEGMENT_CHARS_RE.search(segment):
        return False
    if re.search(r"[ .]$", segment):
        return False
    stem = segment.split(".")[0]
    return not _DEVICE_RE.match(stem)


def is_safe_page_path(path: str) -> bool:
    """校验 LLM 生成的页路径，只允许 wiki/ 之下的安全相对路径。

    拒绝：空路径、控制字符、绝对路径(POSIX/Windows 盘符/UNC)、任何 ``..`` 段、
    Windows 非法文件名字符、保留设备名、段尾空格/点、非 wiki/ 前缀。
    """
    if not isinstance(path, str) or not path.strip():
        return False
    if re.search(r"[\x00-\x1f]", path):
        return False
    if path.startswith(("/", "\\")):
        return False
    if re.match(r"^[a-zA-Z]:", path):
        return False
    normalized = path.replace("\\", "/")
    segments = normalized.split("/")
    if any(seg == ".." for seg in segments):
        return False
    if any(not is_windows_safe_segment(seg) for seg in segments):
        return False
    if not normalized.startswith("wiki/"):
        return False
    return normalized.endswith(".md")


def abs_page_path(relative_path: str) -> str:
    """把 wiki/ 相对路径映射到磁盘绝对路径（调用前必须过 is_safe_page_path）。"""
    return os.path.normpath(os.path.join(WIKI_DIR, relative_path.replace("/", os.sep)))


def page_target(relative_path: str) -> str:
    """页路径 -> wikilink 裸 slug（去掉 wiki/ 前缀与 .md 后缀）。"""
    normalized = relative_path.replace("\\", "/")
    if normalized.startswith("wiki/"):
        normalized = normalized[len("wiki/") :]
    return re.sub(r"\.md$", "", normalized, flags=re.IGNORECASE)


# ── slug 解析（裸/目录限定 -> 唯一页路径）────────────────────
# LLM 生成的正文 [[wikilink]] 与 frontmatter related 都是裸 slug（如 c_approval），
# 而页实际落在 wiki/{type}/{slug}.md。这里建立「目录限定 + 裸文件名」双索引，
# 把任意 slug 解析成唯一页路径；裸 slug 命中多个目录时视为歧义，返回 None。


def slug_index() -> dict[str, str]:
    """返回 slug -> 唯一页相对路径。key 同时含目录限定（concepts/foo）与裸文件名（foo）。"""
    qualified: dict[str, str] = {}
    bare: dict[str, set[str]] = {}
    for rel in list_page_paths():
        slug = page_target(rel)  # 形如 concepts/foo
        qualified[slug] = rel
        bare_slug = slug.rsplit("/", 1)[-1]
        if bare_slug:
            bare.setdefault(bare_slug, set()).add(rel)

    result = dict(qualified)
    for b, paths in bare.items():
        if len(paths) == 1:
            result[b] = next(iter(paths))
        # 歧义：不收录，交由调用方跳过
    return result


def resolve_page_path(slug: str) -> Optional[str]:
    """把任意 slug（裸 / 目录限定 / 含 wiki/ 前缀 / 含 .md 后缀）解析为唯一页相对路径。

    歧义或不存在返回 None。
    """
    if not isinstance(slug, str) or not slug.strip():
        return None
    s = slug.replace("\\", "/").strip().strip("/")
    s = re.sub(r"^wiki/", "", s, flags=re.IGNORECASE)
    s = re.sub(r"\.md$", "", s, flags=re.IGNORECASE)
    if not s:
        return None
    return slug_index().get(s)


# ── 时间戳（进程内严格单调）─────────────────────────────────

_ts_lock = threading.Lock()
_last_ts: Optional[str] = None


def _now() -> str:
    global _last_ts
    with _ts_lock:
        now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")
        if _last_ts is not None and now <= _last_ts:
            now = (datetime.strptime(_last_ts, "%Y-%m-%dT%H:%M:%S.%f") + timedelta(microseconds=1)).strftime(
                "%Y-%m-%dT%H:%M:%S.%f"
            )
        _last_ts = now
        return now


def today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


# ── 目录初始化 ──────────────────────────────────────────────


def ensure_dirs() -> None:
    global _dir_seed_signature
    signature = (WIKI_DIR, WIKI_CONTENT_BACKEND)
    with _dirs_init_lock:
        if _dir_seed_signature == signature:
            return
        # 即使生产页面落在 OSS，也保留本地目录用于迁移旧内容和兼容开发环境。
        os.makedirs(RAW_DIR, exist_ok=True)
        os.makedirs(WIKI_PAGES_DIR, exist_ok=True)
        os.makedirs(CACHE_DIR, exist_ok=True)
        for d in DEFAULT_TYPE_DIRS.values():
            os.makedirs(os.path.join(WIKI_DIR, d.replace("/", os.sep)), exist_ok=True)
        # 种子 schema/purpose：不存在则写入，存在则保留用户编辑。
        _seed_if_missing("schema.md", SCHEMA_SEED)
        _seed_if_missing("purpose.md", PURPOSE_SEED)
        _seed_if_missing(os.path.join("wiki", "index.md"), "# Wiki Index\n")
        _seed_if_missing(os.path.join("wiki", "overview.md"), "# Wiki Overview\n")
        _seed_if_missing(os.path.join("wiki", "log.md"), "# Wiki Log\n")
        _dir_seed_signature = signature


def _seed_if_missing(rel_path: str, content: str) -> None:
    p = os.path.join(WIKI_DIR, rel_path.replace("/", os.sep))
    if _content_storage() is not None:
        if _content_object_exists(rel_path):
            return
        if os.path.isfile(p):
            try:
                _write_content_object(rel_path, Path(p).read_text(encoding="utf-8"))
                return
            except (OSError, UnicodeError) as exc:
                logger.warning("迁移知识库种子文件到 OSS 失败 %s: %s", rel_path, exc)
        _write_content_object(rel_path, content)
        return
    if not os.path.exists(p):
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)


# ── frontmatter ─────────────────────────────────────────────

_FM_STRICT_RE = re.compile(r"^---\s*\r?\n([\s\S]*?)\r?\n---\s*(?:\r?\n|$)")
_FM_ANYWHERE_RE = re.compile(r"\n---\s*\r?\n([\s\S]*?)\r?\n---\s*(?:\r?\n|$)")
MAX_PREFIX_LINES = 6


def _repair_wikilink_list(payload: str) -> str:
    """修复 LLM 偶发的 related: [[a]], [[b]] 非法 YAML —— 转成 related: [a, b]。"""
    lines = []
    for line in payload.split("\n"):
        m = re.match(r"^(\s*[A-Za-z_][\w-]*\s*:\s*)(\[\[[^\]]+\]\](?:\s*,\s*\[\[[^\]]+\]\])+)\s*$", line)
        if not m:
            lines.append(line)
            continue
        items = ['"' + s.strip().lstrip("[").rstrip("]") + '"' for s in m.group(2).split(",") if s.strip()]
        lines.append(f"{m.group(1)}[{', '.join(items)}]")
    return "\n".join(lines)


def parse_frontmatter(content: str) -> tuple[Optional[dict], str]:
    """解析 YAML frontmatter，返回 (frontmatter_dict, body)。

    严格首选（首行必须是 ---）；失败时在文件头部 6 行内做一次非锚定容错，
    兼容 LLM 偶发的多余前缀行（如 ```yaml 包裹）。无效则返回 (None, 原文)。
    """
    if not isinstance(content, str):
        return None, ""
    m = _FM_STRICT_RE.match(content)
    if m:
        payload, body = m.group(1), content[m.end() :]
        fm = _parse_yaml_payload(payload)
        return (fm, body) if fm is not None else (None, content)

    fallback = _FM_ANYWHERE_RE.search(content)
    if fallback is None:
        return None, content
    open_idx = fallback.start() + 1
    if content[:open_idx].count("\n") > MAX_PREFIX_LINES:
        return None, content
    payload = fallback.group(1)
    raw_end = open_idx + fallback.group(0).__len__() - 1
    body = content[raw_end:]
    # 剥掉可能包裹 frontmatter 的 ```yaml 代码栅栏残余
    body = re.sub(r"^\s*```(?:yaml|yml)?\s*(?:\r?\n|$)", "", body)
    fm = _parse_yaml_payload(payload)
    return (fm, body) if fm is not None else (None, content)


def _parse_yaml_payload(payload: str) -> Optional[dict]:
    def _load(text: str) -> Optional[dict]:
        try:
            parsed = yaml.safe_load(text)
        except yaml.YAMLError:
            return None
        if parsed is None:
            return {}
        if not isinstance(parsed, dict):
            return None
        return parsed

    parsed = _load(payload)
    if parsed is not None:
        return parsed
    return _load(_repair_wikilink_list(payload))


def _fm_str(fm: Optional[dict], key: str, default: str = "") -> str:
    if not fm:
        return default
    v = fm.get(key, default)
    return str(v) if v is not None else default


def _fm_list(fm: Optional[dict], key: str) -> list[str]:
    if not fm:
        return []
    v = fm.get(key)
    if v is None:
        return []
    if isinstance(v, str):
        return [v]
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v]
    return [str(v)]


def _fm_list_or_str(fm: Optional[dict], key: str, default: str = "") -> str:
    """sources 简写为 YAML 空/字符串时兜底。"""
    if not fm:
        return default
    v = fm.get(key)
    if v is None:
        return default
    if isinstance(v, list):
        return ",".join(str(x) for x in v)
    return str(v)


def page_title(content: str, fallback_path: str = "") -> str:
    fm, _ = parse_frontmatter(content)
    t = _fm_str(fm, "title", "").strip()
    if t:
        return t
    # 兜底：第一个 H1
    m = re.search(r"^#\s+(.+)$", content, flags=re.MULTILINE)
    if m:
        return m.group(1).strip()
    return fallback_path or "未命名"


# ── wikilink ────────────────────────────────────────────────

_WIKILINK_RE = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]")


def extract_wikilinks(content: str) -> list[str]:
    """抽取正文中的 [[wikilink]] 目标裸 slug（去重、保序）。"""
    body = parse_frontmatter(content)[1]
    targets: list[str] = []
    seen: set[str] = set()
    for m in _WIKILINK_RE.finditer(body):
        t = m.group(1).strip().replace("\\", "/")
        if t and t not in seen:
            seen.add(t)
            targets.append(t)
    return targets


def page_links(content: str) -> tuple[list[str], list[str]]:
    """返回 (正文 wikilink 目标, frontmatter related 裸 slug)。"""
    fm, _ = parse_frontmatter(content)
    related = [s.strip().replace("\\", "/") for s in _fm_list(fm, "related") if s.strip()]
    return extract_wikilinks(content), related


# ── 页读写 ──────────────────────────────────────────────────


def read_content(relative_path: str) -> Optional[str]:
    if not _is_safe_content_path(relative_path):
        return None
    storage = _content_storage()
    if storage is not None:
        cached = _get_cached_content(storage, relative_path)
        if cached is not None:
            return cached
        content = _read_content_object(relative_path)
        if content is not None:
            _cache_content(storage, relative_path, content)
            return content
        # 兼容尚未迁移的旧本地页面；新写入只进入 OSS。
    p = abs_page_path(relative_path)
    if not os.path.isfile(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        logger.warning("读取页失败 %s: %s", relative_path, e)
        return None


def read_page(relative_path: str) -> Optional[str]:
    if not is_safe_page_path(relative_path):
        return None
    return read_content(relative_path)


def _has_valid_type_route(relative_path: str, content: str) -> bool:
    """校验内容页的 frontmatter 类型与目录路由是否一致。"""
    normalized = relative_path.replace("\\", "/")
    if normalized in AGGREGATE_PATHS:
        return True
    fm, _ = parse_frontmatter(content)
    if fm is None:
        logger.warning("拒绝写入无有效 frontmatter 的内容页: %s", relative_path)
        return False
    ptype = _fm_str(fm, "type", "").strip()
    expected_dir = DEFAULT_TYPE_DIRS.get(ptype)
    if expected_dir is None:
        logger.warning("拒绝写入未知知识类型 %r: %s", ptype, relative_path)
        return False
    if not normalized.startswith(expected_dir + "/"):
        logger.warning("拒绝写入类型与目录不一致的页面 type=%s path=%s", ptype, relative_path)
        return False
    return True


def write_page(relative_path: str, content: str) -> bool:
    if not is_safe_page_path(relative_path):
        logger.warning("拒绝越界写页: %s", relative_path)
        return False
    if not _has_valid_type_route(relative_path, content):
        return False
    if _content_storage() is not None:
        try:
            _write_content_object(relative_path, content)
            _invalidate_content_cache(relative_path)
            _invalidate_page_list_cache()
            return True
        except Exception as e:
            logger.warning("写 OSS 页面失败 %s: %s", relative_path, e)
            return False
    p = abs_page_path(relative_path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    try:
        with open(p, "w", encoding="utf-8") as f:
            f.write(content)
        _invalidate_page_list_cache()
        return True
    except OSError as e:
        logger.warning("写页失败 %s: %s", relative_path, e)
        return False


def delete_page(relative_path: str) -> bool:
    normalized = relative_path.replace("\\", "/").strip("/") if isinstance(relative_path, str) else ""
    if not is_safe_page_path(normalized) or normalized in AGGREGATE_PATHS:
        return False
    storage = _content_storage()
    if storage is not None:
        try:
            deleted = storage.delete(_content_storage_key(normalized))
            if not deleted and storage.exists(_content_storage_key(normalized)):
                logger.warning("删 OSS 页面失败 %s：删除后对象仍存在", normalized)
                return False
        except Exception as e:
            logger.warning("删 OSS 页面失败 %s: %s", normalized, e)
            return False
        # 删除迁移前遗留的本地副本，避免兼容回退重新显示已删页面。
    p = abs_page_path(normalized)
    try:
        if os.path.isfile(p):
            os.remove(p)
    except OSError as e:
        logger.warning("删页失败 %s: %s", normalized, e)
        return False
    _invalidate_content_cache(normalized)
    _invalidate_page_list_cache(storage)
    return True


def list_page_paths() -> list[str]:
    """返回 wiki/ 下全部内容页相对路径（排除聚合文件），按路径排序。

    页树/图谱每次打开都会先调用本函数；结果按 TTL 缓存，避免反复 OSS
    list_keys + 本地 os.walk。写入/删除页时由 write_page/delete_page 主动失效。
    """
    ensure_dirs()
    storage = _content_storage()
    cache_id = id(storage) if storage is not None else -1
    now = time.monotonic()
    with _list_cache_lock:
        hit = _page_list_cache.get(cache_id)
        if hit is not None and now - hit[0] <= WIKI_LIST_CACHE_TTL_SECONDS:
            return list(hit[1])
    paths = _build_page_paths(storage)
    with _list_cache_lock:
        _page_list_cache[cache_id] = (time.monotonic(), paths)
    return list(paths)


def _build_page_paths(storage: MediaStorage | None) -> list[str]:
    out: set[str] = set()
    if storage is not None:
        prefix = f"{WIKI_CONTENT_PREFIX}/wiki/"
        for key in storage.list_keys(prefix):
            if not key.startswith(prefix):
                continue
            rel = key[len(WIKI_CONTENT_PREFIX) + 1 :]
            if rel not in AGGREGATE_PATHS and is_safe_page_path(rel):
                out.add(rel)
    for root, _dirs, files in os.walk(WIKI_PAGES_DIR):
        for name in files:
            if not name.endswith(".md"):
                continue
            abs_p = os.path.join(root, name)
            rel = os.path.relpath(abs_p, WIKI_DIR).replace(os.sep, "/")
            if rel not in AGGREGATE_PATHS:
                out.add(rel)
    return sorted(out)


# ── 聚合文件维护 ────────────────────────────────────────────


def append_log(entry: str) -> None:
    """向 wiki/log.md 追加一条流水记录（应用维护，非 LLM 生成）。"""
    ensure_dirs()
    relative_path = "wiki/log.md"
    current = read_page(relative_path) or "# Wiki Log\n"
    if not write_page(relative_path, f"{current.rstrip()}\n\n{entry}\n"):
        logger.warning("追加 log 失败: %s", relative_path)


def rebuild_index() -> None:
    """按类型分组重建 wiki/index.md 目录条目（确定性生成）。"""
    ensure_dirs()
    sections: dict[str, list[tuple[str, str]]] = {}
    for rel in list_page_paths():
        content = read_page(rel)
        if content is None:
            continue
        fm, _ = parse_frontmatter(content)
        ptype = _fm_str(fm, "type", "concept").strip() or "concept"
        title = page_title(content, page_target(rel))
        sections.setdefault(ptype, []).append((rel, title))

    lines = ["# Wiki Index", ""]
    for ptype in sorted(sections):
        lines.append(f"## {ptype}")
        lines.append("")
        for rel, title in sorted(sections[ptype]):
            lines.append(f"- [[{page_target(rel)}]] — {title}")
        lines.append("")
    write_page("wiki/index.md", "\n".join(lines))


def rebuild_overview() -> None:
    """确定性生成 overview：每类型页数 + 最近更新的页。"""
    ensure_dirs()
    from collections import Counter

    counts: Counter = Counter()
    for rel in list_page_paths():
        content = read_page(rel)
        if content is None:
            continue
        fm, _ = parse_frontmatter(content)
        counts[_fm_str(fm, "type", "concept") or "concept"] += 1

    lines = ["# Wiki Overview", "", f"_自动生成于 {today()}_", ""]
    if counts:
        lines.append("## 页类型统计")
        lines.append("")
        for ptype, n in sorted(counts.items()):
            lines.append(f"- {ptype}: {n}")
        lines.append("")
    lines.append(f"共 {sum(counts.values())} 个内容页。")
    write_page("wiki/overview.md", "\n".join(lines))


# ── SHA256 ingest 缓存 ──────────────────────────────────────

_cache_lock = threading.Lock()


def _load_cache() -> dict:
    storage = _content_storage()
    if storage is not None:
        try:
            if storage.exists(WIKI_CACHE_STORAGE_KEY):
                data = json.loads(storage.read(WIKI_CACHE_STORAGE_KEY).decode("utf-8"))
                return data if isinstance(data, dict) else {}
        except (OSError, UnicodeError, json.JSONDecodeError) as e:
            logger.warning("读取 OSS ingest 缓存失败: %s", e)
        # 兼容迁移前本地缓存；成功写入后会转存 OSS。
    if not os.path.isfile(CACHE_PATH):
        return {}
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("读取 ingest 缓存失败: %s", e)
        return {}


def _save_cache(cache: dict) -> None:
    ensure_dirs()
    storage = _content_storage()
    if storage is not None:
        storage.write(
            WIKI_CACHE_STORAGE_KEY,
            json.dumps(cache, ensure_ascii=False, indent=2).encode("utf-8"),
            "application/json; charset=utf-8",
        )
        return
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def check_ingest_cache(identity: str, content: str) -> Optional[list[str]]:
    """命中且文件都还在磁盘上时返回 filesWritten，否则返回 None。"""
    key = sha256_text(f"{identity}\n{content}")
    with _cache_lock:
        cache = _load_cache()
        entry = cache.get(key)
        if not entry:
            return None
        files: list[str] = entry.get("filesWritten", [])
        if files and all(_content_exists_for_cache(p) for p in files):
            # 更新最后命中时间，便于追溯
            entry["lastHit"] = _now()
            cache[key] = entry
            _save_cache(cache)
            return list(files)
        return None


def _content_exists_for_cache(relative_path: str) -> bool:
    if not is_safe_page_path(relative_path):
        return False
    if _content_storage() is not None and _content_object_exists(relative_path):
        return True
    return os.path.isfile(abs_page_path(relative_path))


def save_ingest_cache(identity: str, content: str, files: list[str]) -> None:
    key = sha256_text(f"{identity}\n{content}")
    with _cache_lock:
        cache = _load_cache()
        cache[key] = {"identity": identity, "filesWritten": list(files), "savedAt": _now()}
        _save_cache(cache)


def remove_ingest_cache_for_identity(identity: str) -> None:
    """只清理指定资料的摄取缓存，不影响共享生成页的其他资料缓存。"""
    if not identity:
        return
    with _cache_lock:
        cache = _load_cache()
        updated = {
            key: value
            for key, value in cache.items()
            if not isinstance(value, dict) or value.get("identity") != identity
        }
        if len(updated) != len(cache):
            _save_cache(updated)


# ── 数据库表（幂等，独立于 app.db.init_db）─────────────────


def ensure_tables() -> None:
    global _prepared_db
    conn = get_db()
    if _prepared_db is conn:
        return
    with _schema_lock:
        if _prepared_db is conn:
            return
        conn.executescript(
            """CREATE TABLE IF NOT EXISTS wiki_pages (
                path VARCHAR(191) PRIMARY KEY,
                type VARCHAR(191) NOT NULL DEFAULT 'concept',
                title VARCHAR(191) NOT NULL DEFAULT '',
                sources LONGTEXT NOT NULL,
                tags LONGTEXT NOT NULL,
                embedding LONGTEXT NOT NULL,
                updated_at VARCHAR(191) NOT NULL
            );
CREATE TABLE IF NOT EXISTS wiki_ingest (
                source_id VARCHAR(191) PRIMARY KEY,
                filename VARCHAR(191) NOT NULL,
                ext VARCHAR(191) NOT NULL,
                sha256 VARCHAR(191) NOT NULL DEFAULT '',
                status VARCHAR(191) NOT NULL DEFAULT 'processing',
                progress VARCHAR(191) NOT NULL DEFAULT '',
                error_msg LONGTEXT NOT NULL,
                pages_written LONGTEXT NOT NULL,
                created_at VARCHAR(191) NOT NULL,
                updated_at VARCHAR(191) NOT NULL
            );
CREATE INDEX idx_wiki_pages_type ON wiki_pages(type)"""
        )
        _ensure_mysql_text_columns(conn)
        conn.commit()
        _prepared_db = conn


def _ensure_mysql_text_columns(conn) -> None:
    """把旧部署中被自动建成 VARCHAR(191) 的 Wiki 长字段升级为 LONGTEXT。"""
    required = {
        "wiki_pages": ("sources", "embedding"),
        "wiki_ingest": ("error_msg", "pages_written"),
    }
    for table, columns in required.items():
        rows = conn.execute(f"SHOW COLUMNS FROM {table}").fetchall()
        current = {str(row["Field"]): str(row["Type"]).lower() for row in rows}
        for column in columns:
            if current.get(column) == "longtext":
                continue
            conn.execute(f"ALTER TABLE {table} MODIFY COLUMN {column} LONGTEXT NOT NULL")


def upsert_page(relative_path: str, content: str, embedding: Optional[list[float]] = None) -> None:
    """把页元数据（title/type/sources/tags/embedding）写入 wiki_pages 表。"""
    ensure_dirs()
    rel = relative_path.replace("\\", "/")
    if relative_path in AGGREGATE_PATHS:
        return
    fm, _ = parse_frontmatter(content)
    ptype = _fm_str(fm, "type", "concept") or "concept"
    title = page_title(content, page_target(rel))
    sources = _fm_list_or_str(fm, "sources", "")
    tags = json.dumps(_fm_list(fm, "tags"), ensure_ascii=False)
    emb = json.dumps(embedding) if embedding is not None else ""
    conn = get_db()
    sql = """
        INSERT INTO wiki_pages (path, type, title, sources, tags, embedding, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            type=VALUES(type), title=VALUES(title), sources=VALUES(sources),
            tags=VALUES(tags),
            embedding=IF(VALUES(embedding) = '', embedding, VALUES(embedding)),
            updated_at=VALUES(updated_at)
    """
    conn.execute(sql, (rel, ptype, title, sources, tags, emb, _now()))
    conn.commit()


def list_page_records() -> list[dict]:
    ensure_tables()
    conn = get_db()
    rows = conn.execute("SELECT * FROM wiki_pages ORDER BY updated_at DESC").fetchall()
    return [dict(r) for r in rows]


def reconcile_page_records() -> dict[str, int]:
    """让数据库页索引与磁盘 Markdown 单一真源保持一致。"""
    ensure_tables()
    disk_paths = set(list_page_paths())
    existing_paths = {str(row.get("path") or "") for row in list_page_records()}

    for path in sorted(disk_paths):
        content = read_page(path)
        if content is not None:
            upsert_page(path, content)

    stale_paths = existing_paths - disk_paths
    if stale_paths:
        conn = get_db()
        for path in stale_paths:
            conn.execute("DELETE FROM wiki_pages WHERE path = %s", (path,))
        conn.commit()

    return {
        "indexed": len(disk_paths),
        "added": len(disk_paths - existing_paths),
        "removed": len(stale_paths),
    }


# ── ingest 状态 CRUD ────────────────────────────────────────

_STATUSES = {"processing", "done", "failed"}


def create_ingest(source_id: str, filename: str, ext: str, sha256: str = "") -> dict:
    ensure_tables()
    now = _now()
    conn = get_db()
    conn.execute(
        """
        INSERT INTO wiki_ingest (source_id, filename, ext, sha256, status, progress, error_msg, pages_written, created_at, updated_at)
        VALUES (%s, %s, %s, %s, 'processing', '', '', '[]', %s, %s)
        """,
        (source_id, filename, ext, sha256, now, now),
    )
    conn.commit()
    return get_ingest(source_id)


def get_ingest(source_id: str) -> Optional[dict]:
    ensure_tables()
    conn = get_db()
    row = conn.execute("SELECT * FROM wiki_ingest WHERE source_id = %s", (source_id,)).fetchone()
    return dict(row) if row else None


def list_ingest() -> list[dict]:
    ensure_tables()
    conn = get_db()
    rows = conn.execute("SELECT * FROM wiki_ingest ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def update_ingest(
    source_id: str,
    *,
    status: Optional[str] = None,
    progress: Optional[str] = None,
    error_msg: Optional[str] = None,
    pages_written: Optional[list[str]] = None,
    sha256: Optional[str] = None,
) -> None:
    if status is not None and status not in _STATUSES:
        raise ValueError(f"非法状态: {status}")
    sets: list[str] = []
    params: list = []
    if status is not None:
        sets.append("status = %s")
        params.append(status)
    if progress is not None:
        sets.append("progress = %s")
        params.append(progress)
    if error_msg is not None:
        sets.append("error_msg = %s")
        params.append(error_msg)
    if pages_written is not None:
        sets.append("pages_written = %s")
        params.append(json.dumps(pages_written, ensure_ascii=False))
    if sha256 is not None:
        sets.append("sha256 = %s")
        params.append(sha256)
    if not sets:
        return
    sets.append("updated_at = %s")
    params.append(_now())
    params.append(source_id)
    conn = get_db()
    conn.execute(f"UPDATE wiki_ingest SET {', '.join(sets)} WHERE source_id = %s", params)
    conn.commit()
