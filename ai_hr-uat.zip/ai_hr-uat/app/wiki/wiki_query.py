"""LLM-wiki 查询层 — 轻量召回 + aiohttp SSE 流式回答。

忠实移植 llm_wiki 的 Query 操作：不做每查重算的完整图遍历，而是
在启用向量时先把问题向量化 + 与页元数据做 token 重叠，取 top-k 页拼成上下文；
关闭向量时只执行 token 重叠，
再流式回答并标注来源页。

召回口径（O(页数)，页数千级内足够）：
    score = 0.7 * 向量余弦 + 0.3 * token 重叠
若无 embedding（未配置 key 或向量缺失）则退化为纯 token 重叠。

SSE 复用 app/routers/knowledge.py 的 aiohttp + ThreadedResolver 模式
（系统 DNS 解析），但走 hermes 网关的真实 OpenAI 兼容 /chat/completions
流式协议（stream=True），不再用 hermes_client 的 50 字模拟分片。
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Optional

from app import kb_tokenizer
from app import wiki_store as ws
from app.infrastructure.config import settings
from hermes_wrapper.client import MODELS, get_client

logger = logging.getLogger("app.wiki_query")

_EMBEDDING = None

DEFAULT_TOP_K = 6
MAX_TOP_K = 20
MAX_CONTEXT_CHARS = 24_000
VECTOR_WEIGHT = 0.7
TOKEN_WEIGHT = 0.3


def _embedding():
    global _EMBEDDING
    if _EMBEDDING is None:
        from knowledge import embedding

        _EMBEDDING = embedding
    return _EMBEDDING


async def _embed_single(text: str, text_type: str = "query") -> Optional[list[float]]:
    """在线程池里调同步 embedding，避免阻塞事件循环；失败降级为 None。"""
    if not settings.wiki_vector_enabled:
        return None
    try:
        emb = _embedding()
        return await asyncio.to_thread(emb.embed_single, text, text_type)
    except Exception as e:  # 无 key / 服务不可用：降级 token 召回
        logger.warning("embedding 失败，降级 token 重叠: %s", e)
        return None


# ── token 重叠 ──────────────────────────────────────────────

_WORD_RE = re.compile(r"[\w\u4e00-\u9fff]+", re.UNICODE)


def _token_set(text: str) -> set[str]:
    """把文本切成可用于重叠评分的 token 集合。"""
    if not text:
        return set()
    tokens: set[str] = set()
    for w in kb_tokenizer.tokenize(text).split():
        if w:
            tokens.add(w)
    # 补充单字 CJK（提高短查询/专业术语召回）
    for w in _WORD_RE.findall(text):
        if len(w) <= 3:
            tokens.add(w.lower())
    return tokens


def _overlap_score(q_tokens: set[str], p_tokens: set[str]) -> float:
    """Jaccard 重叠；查询为空时返回 0。"""
    if not q_tokens or not p_tokens:
        return 0.0
    inter = len(q_tokens & p_tokens)
    union = len(q_tokens | p_tokens)
    return inter / union if union else 0.0


# ── 页检索文本 ──────────────────────────────────────────────


def _page_search_text(rec: dict) -> str:
    parts = [
        rec.get("title", ""),
        rec.get("type", ""),
        rec.get("sources", ""),
        rec.get("tags", "[]"),
    ]
    return " ".join(str(p) for p in parts if p)


def _page_embedding(rec: dict) -> Optional[list[float]]:
    raw = rec.get("embedding") or ""
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


async def _ensure_embedding(rec: dict, content: str) -> Optional[list[float]]:
    """优先用表内向量；缺失时按页正文（截断）临时补。"""
    if not settings.wiki_vector_enabled:
        return None
    emb = _page_embedding(rec)
    if emb is not None:
        return emb
    snippet = content[:2000]
    return await _embed_single(snippet, text_type="document")


def _cosine(a: Optional[list[float]], b: Optional[list[float]]) -> float:
    if not a or not b:
        return 0.0
    return _embedding().cosine_similarity(a, b)


# ── 召回 ────────────────────────────────────────────────────


async def retrieve(question: str, k: int = DEFAULT_TOP_K) -> list[dict]:
    """按「向量余弦 ⊕ token 重叠」召回 top-k 页，返回含正文的页字典。"""
    k = max(1, min(int(k), MAX_TOP_K))
    # Markdown 是单一真源；召回前对账，避免页面可读但问答索引缺失。
    ws.reconcile_page_records()
    records = ws.list_page_records()
    if not records:
        return []

    q_tokens = _token_set(question)
    vector_enabled = settings.wiki_vector_enabled
    q_emb = await _embed_single(question, text_type="query") if vector_enabled else None

    scored = []
    for rec in records:
        path = rec.get("path", "")
        content = ws.read_page(path) or ""
        if not content.strip():
            continue
        # 正文去 frontmatter 作为展示/上下文文本
        _fm, body = ws.parse_frontmatter(content)
        search_text = _page_search_text(rec) + " " + body[:2000]

        p_emb = await _ensure_embedding(rec, content) if vector_enabled else None
        vec = _cosine(q_emb, p_emb) if q_emb is not None else 0.0
        tok = _overlap_score(q_tokens, _token_set(search_text))
        score = VECTOR_WEIGHT * vec + TOKEN_WEIGHT * tok if q_emb is not None else tok
        if score <= 0:
            continue
        scored.append((score, path, rec, body))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:k]

    out: list[dict] = []
    for score, path, rec, body in top:
        out.append(
            {
                "path": path,
                "slug": ws.page_target(path),
                "title": rec.get("title") or ws.page_title(f"{content}", path),
                "type": rec.get("type", "concept"),
                "sources": rec.get("sources", ""),
                "score": round(float(score), 4),
                "snippet": body.strip()[:400],
                "body": body.strip(),
            }
        )
    return out


def build_context(pages: list[dict]) -> str:
    """把召回页拼成注入 LLM 的上下文。"""
    if not pages:
        return ""
    blocks = []
    for i, p in enumerate(pages, 1):
        src = p.get("sources") or "anonymous"
        blocks.append(
            f"[{i}] {p.get('title') or p.get('slug')} "
            f"(slug: {p.get('slug')}, type: {p.get('type')}, source: {src})\n{p.get('body', '')}"
        )
    return "\n\n".join(blocks)[:MAX_CONTEXT_CHARS]


# ── SSE 流式回答 ────────────────────────────────────────────


@asynccontextmanager
async def _ai_session():
    """aiohttp 会话（强制系统 DNS 解析，同 knowledge.py）。"""
    from aiohttp import ClientSession, TCPConnector
    from aiohttp.resolver import ThreadedResolver

    connector = TCPConnector(resolver=ThreadedResolver())
    session = ClientSession(connector=connector)
    try:
        yield session
    finally:
        await session.close()
        await connector.close()


def _stream_endpoint() -> tuple[str, str, str]:
    """返回 (api_base, api_key, model)。走 hermes 网关同源配置。"""
    client = get_client()
    base = client.api_base.rstrip("/")
    key = client.api_key
    model = MODELS.get("plus", "qwen-plus") or os.getenv("OPENAI_CHAT_MODEL", "qwen-plus")
    return base, key, model


_TOKENS_PER_SNIPPET = 600


async def stream_answer(question: str, k: int = DEFAULT_TOP_K) -> AsyncGenerator[str, None]:
    """轻量召回 + 流式回答，SSE 事件流。

    事件：
    - {"phase": "retrieving"}          开始召回
    - {"phase": "sources", "sources": [...]}  召回页元数据（供前端标注来源）
    - {"content": "..."}               增量正文
    - {"done": true, "total_length": N, "sources": [...]}
    - [DONE]
    """
    import aiohttp

    yield f"data: {json.dumps({'phase': 'retrieving'}, ensure_ascii=False)}\n\n"

    try:
        pages = await retrieve(question, k)
    except Exception as e:
        logger.error("召回失败: %s", e)
        yield f"data: {json.dumps({'error': f'召回失败: {str(e)[:100]}'}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"
        return

    source_meta = [
        {
            "slug": p.get("slug"),
            "title": p.get("title"),
            "type": p.get("type"),
            "sources": p.get("sources"),
            "score": p.get("score"),
        }
        for p in pages
    ]
    yield f"data: {json.dumps({'phase': 'sources', 'sources': source_meta}, ensure_ascii=False)}\n\n"

    context = build_context(pages)
    system = (
        "你是 HR 招聘知识库问答助手。只根据下面提供的 wiki 页内容回答；"
        "引用时用 [编号] 标注来源页。若上下文不足以回答，直接说明知识库中暂无相关内容，"
        "不要编造。用中文作答，专有名词保留原样。"
    )
    if context:
        user = f"参考资料：\n\n{context}\n\n问题：{question}"
    else:
        user = f"问题：{question}"

    base, key, model = _stream_endpoint()
    api_url = f"{base}/chat/completions"
    if not key:
        yield f"data: {json.dumps({'error': 'OPENAI_API_KEY 未配置'}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"
        return

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "stream": True,
        "temperature": 0.3,
        "max_tokens": 1024,
    }
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }

    full_content = ""
    try:
        async with _ai_session() as session:
            async with session.post(
                api_url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=120)
            ) as resp:
                if resp.status != 200:
                    error_text = (await resp.text())[:300]
                    logger.error("wiki 流式回答 %s: %s", resp.status, error_text)
                    yield f"data: {json.dumps({'error': f'AI 服务返回错误 ({resp.status})'}, ensure_ascii=False)}\n\n"
                    yield "data: [DONE]\n\n"
                    return

                async for line in resp.content:
                    line_text = line.decode("utf-8", errors="ignore").strip()
                    if not line_text or line_text.startswith(":"):
                        continue
                    if line_text == "data: [DONE]":
                        break
                    if line_text.startswith("data: "):
                        try:
                            chunk = json.loads(line_text[6:])
                            choices = chunk.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    full_content += content
                                    yield f"data: {json.dumps({'content': content}, ensure_ascii=False)}\n\n"
                        except json.JSONDecodeError:
                            continue

    except aiohttp.ClientError as e:
        logger.error("wiki 流式连接失败: %s", e)
        yield f"data: {json.dumps({'error': f'AI 服务连接失败: {str(e)[:100]}'}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"
        return
    except Exception as e:
        logger.error("wiki 流式未知错误: %s", e)
        yield f"data: {json.dumps({'error': f'未知错误: {str(e)[:100]}'}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"
        return

    yield f"data: {json.dumps({'done': True, 'total_length': len(full_content), 'sources': source_meta}, ensure_ascii=False)}\n\n"
    yield "data: [DONE]\n\n"
