"""LLM-wiki 摄取层 — 两步 Chain-of-Thought ingest。

from __future__ import annotations

忠实移植 llm_wiki 的 autoIngest 主流程：
  1. Step 1 分析（LLM -> 实体/概念/论证/关联/矛盾/建议）
  2. Step 2 生成（LLM -> ``---FILE: …--- …---END FILE---`` 块，可选 REVIEW 块）
  3. 解析 FILE 块（fence 感知 + 路径沙箱）-> 落盘 -> 聚合文件维护 -> SHA256 缓存

长文档走标头感知切块（~8k token/块），逐块分析后合并，再统一生成。
后台入口函数 start_ingest_source 在当前事件循环中调度；运行中任务会被强引用，
服务重启后由 resume_pending_ingests 从 raw/ 自动恢复数据库里的 processing 记录。
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import uuid
from contextlib import contextmanager
from threading import Lock
from typing import Optional

import app.wiki_store as ws
from app.infrastructure.config import settings
from app.media_storage import MediaStorage, get_media_storage, join_storage_key
from hermes_wrapper.client import get_client
from hermes_wrapper.models import LLMRequest

logger = logging.getLogger("app.wiki_ingest")

# asyncio 事件循环只弱引用 Task。这里按 source_id 持有任务，既避免任务在等待 LLM 时
# 被垃圾回收，也防止同一进程内重复恢复/重复点击产生两条摄取链路。
_active_ingest_tasks: dict[str, asyncio.Task[None]] = {}
_content_mutation_lock = Lock()


@contextmanager
def content_mutation():
    """串行化页面写入与资料删除的短临界区，避免删除后后台任务复活页面。"""
    with _content_mutation_lock:
        yield


# 落盘目录：原始资料统一放 data/llm_wiki/raw/<source_id>.<ext>
RAW_DIR = os.path.normpath(os.path.join(ws.WIKI_DIR, "raw"))
OSS_RAW_PREFIX = join_storage_key(settings.oss_knowledge_prefix, "source")

# ── 常量 ────────────────────────────────────────────────────

LONG_SOURCE_CHUNK_TOKENS = 8_000
GENERATION_MAX_TOKENS = 16_384
ANALYSIS_MAX_TOKENS = 4_096

LANGUAGE_RULE = (
    "## Output Language\n"
    "全部 prose（标题、正文、解释、段落文字）用中文书写；但专有名词、缩写、模型名、数据集名、"
    "工具/库名、代码标识符、URL、文件名、引文、论文标题、以及 SQL DDL / 建表语句 / API 签名 / "
    "配置 / 表格等结构化数据必须逐字原样保留，放入 fenced code block 或 Markdown 表格，不得改写。"
)

# ── FILE 块解析（fence 感知，移植 llm_wiki parseFileBlocks）──

_OPENER_LINE = re.compile(r"^---\s*FILE:\s*(.+?)\s*---\s*$", re.IGNORECASE)
_CLOSER_LINE = re.compile(r"^---\s*END\s+FILE\s*---\s*$", re.IGNORECASE)
_FENCE_LINE = re.compile(r"^\s{0,3}(```+|~~~+)")

_REVIEW_OPENER_LINE = re.compile(r"^---\s*REVIEW:\s*(.+?)\s*---\s*$", re.IGNORECASE)
_REVIEW_CLOSER_LINE = re.compile(r"^---\s*END\s+REVIEW\s*---\s*$", re.IGNORECASE)


def parse_file_blocks(text: str) -> tuple[list[tuple[str, str]], list[str]]:
    """把 LLM 阶段2输出解析为 [(path, content)] 与 warnings。

    处理：CRLF 归一化、fence 内 ``---END FILE---`` 不当结束标记、
    大小写/空白容忍的开闭标记、路径沙箱拒绝、未闭合块告警。
    """
    normalized = text.replace("\r\n", "\n")
    lines = normalized.split("\n")
    blocks: list[tuple[str, str]] = []
    warnings: list[str] = []

    i = 0
    while i < len(lines):
        opener = _OPENER_LINE.match(lines[i].strip())
        if not opener:
            i += 1
            continue
        path = opener.group(1).strip()
        i += 1

        content_lines: list[str] = []
        fence_marker: Optional[str] = None
        fence_len = 0
        closed = False

        while i < len(lines):
            line = lines[i]
            fence = _FENCE_LINE.match(line)
            if fence:
                run = fence.group(1)
                ch = run[0]
                length = len(run)
                if fence_marker is None:
                    fence_marker = ch
                    fence_len = length
                elif ch == fence_marker and length >= fence_len:
                    fence_marker = None
                    fence_len = 0
                content_lines.append(line)
                i += 1
                continue

            # 结束标记只在非 fence 内生效
            if fence_marker is None and _CLOSER_LINE.match(line.strip()):
                closed = True
                i += 1
                break

            content_lines.append(line)
            i += 1

        if not closed:
            msg = f'FILE 块 "{path or "(未命名)"}" 未闭合即到流尾——可能因 max_tokens 截断，已丢弃。'
            logger.warning("[wiki_ingest] %s", msg)
            warnings.append(msg)
            continue
        if not path:
            warnings.append("FILE 块路径为空（LLM 省略了 ---FILE: 后的路径），已跳过。")
            continue
        if not ws.is_safe_page_path(path):
            warnings.append(f'FILE 块路径 "{path}" 越界被拒（须为 wiki/ 下、无 ..、无绝对路径、Windows 安全名）。')
            continue

        blocks.append((path, "\n".join(content_lines)))

    return blocks, warnings


def parse_review_blocks(text: str) -> list[dict]:
    """解析可选 REVIEW 块为结构化项（当前只留档，不做人工审批流）。"""
    normalized = text.replace("\r\n", "\n")
    lines = normalized.split("\n")
    items: list[dict] = []
    i = 0
    while i < len(lines):
        opener = _REVIEW_OPENER_LINE.match(lines[i].strip())
        if not opener:
            i += 1
            continue
        header = opener.group(1).strip()
        i += 1
        body: list[str] = []
        closed = False
        while i < len(lines):
            line = lines[i]
            if _REVIEW_CLOSER_LINE.match(line.strip()):
                closed = True
                i += 1
                break
            body.append(line)
            i += 1
        if closed:
            items.append({"header": header, "body": "\n".join(body).strip()})
    return items


# ── 文本提取 ────────────────────────────────────────────────

SUPPORTED_EXTS = {"pdf", "docx", "txt", "md"}


def extract_text(filename: str, content: bytes) -> str:
    """按扩展名抽取文本：pdf/docx 复用 extract_text_from_bytes_rich；txt/md 用 decode_bytes。"""
    from app.utils import decode_bytes, extract_text_from_bytes_rich

    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in {"pdf", "docx"}:
        try:
            return extract_text_from_bytes_rich(content, filename)
        except Exception as e:
            logger.warning("富文本抽取失败 %s: %s，降级为字节解码", filename, e)
            return decode_bytes(content)
    return decode_bytes(content)


# ── 长文档切块（标头感知）───────────────────────────────────


def chunk_text(text: str, max_tokens: int = LONG_SOURCE_CHUNK_TOKENS) -> list[str]:
    from app.kb_tokenizer import num_tokens_from_string

    if not text:
        return [""]
    if num_tokens_from_string(text) <= max_tokens:
        return [text]

    # 以空白行为粗边界（保留 markdown 段落/标题结构）
    paragraphs = re.split(r"\n\s*\n", text)
    if not paragraphs:
        paragraphs = [text]

    chunks: list[str] = []
    cur: list[str] = []
    cur_tokens = 0
    for para in paragraphs:
        pt = num_tokens_from_string(para)
        if cur and cur_tokens + pt > max_tokens:
            chunks.append("\n\n".join(cur))
            cur = []
            cur_tokens = 0
        cur.append(para)
        cur_tokens += pt
    if cur:
        chunks.append("\n\n".join(cur))

    # 硬上限：单段超长则按字符切
    out: list[str] = []
    for c in chunks:
        while num_tokens_from_string(c) > max_tokens:
            cut = max(1, int(len(c) * max_tokens / num_tokens_from_string(c)))
            out.append(c[:cut])
            c = c[cut:]
        if c.strip():
            out.append(c)
    return out


# ── LLM 调用 ────────────────────────────────────────────────


async def _call_llm(system: str, prompt: str, *, max_tokens: int, temperature: float = 0.1) -> str:
    client = get_client()
    resp = await client.chat(
        LLMRequest(
            prompt=prompt,
            system=system,
            complexity="plus",
            temperature=temperature,
            timeout=300,
            max_tokens=max_tokens,
        ),
        agent="knowledge_wiki",
        operation="wiki_ingest",
    )
    if resp.error:
        raise RuntimeError(f"LLM 调用失败: {resp.error}")
    return resp.content


# ── prompt 构建 ─────────────────────────────────────────────


def _read_agg(rel: str) -> str:
    return ws.read_content(rel) or ""


def build_analysis_prompt(purpose: str, index: str, schema: str) -> str:
    parts = [
        "You are an expert research analyst. Read the source document and produce a structured analysis.",
        "Do not output chain-of-thought, hidden reasoning, or a thinking transcript. Reason internally and write only the concise final analysis.",
        "",
        LANGUAGE_RULE,
        "",
        "## Knowledge Type Definitions and Conflict Priority (AUTHORITATIVE)",
        ws.knowledge_type_guidance(),
        "",
        "Your analysis should cover:",
        "",
        "## Key Entities",
        "List people, organizations, products, datasets, tools mentioned. For each:",
        "- Name and type",
        "- Role in the source (central vs. peripheral)",
        "- Whether it likely already exists in the wiki (check the index)",
        "",
        "## Key Concepts",
        "List theories, methods, techniques, phenomena. For each:",
        "- Name and brief definition",
        "- Why it matters in this source",
        "- Whether it likely already exists in the wiki",
        "",
        "## Main Arguments & Findings",
        "- What are the core claims or results?",
        "- What evidence supports them?",
        "- How strong is the evidence?",
        "- Preserve structured source data verbatim when present: SQL DDL / CREATE TABLE, API signatures, config, tables in fenced code blocks.",
        "",
        "## Connections to Existing Wiki",
        "- What existing pages does this source relate to?",
        "- Does it strengthen, challenge, or extend existing knowledge?",
        "",
        "## Contradictions & Tensions",
        "- Does anything in this source conflict with existing wiki content?",
        "- Are there internal tensions or caveats?",
        "",
        "## Recommendations",
        "- What wiki pages should be created or updated?",
        "- What should be emphasized vs. de-emphasized?",
        "",
        "Be thorough but concise. Focus on what's genuinely important.",
        "",
    ]
    if schema:
        parts += ["## Project Schema (page types available)", schema]
    if purpose:
        parts += ["## Wiki Purpose (for context)", purpose]
    if index:
        parts += ["## Current Wiki Index (for checking existing content)", index]
    return "\n".join(parts)


def build_generation_prompt(
    schema: str, purpose: str, index: str, source_filename: str, source_summary_path: str
) -> str:
    today = ws.today()
    parts = [
        "You are a wiki maintainer. Based on the analysis provided, generate wiki files.",
        "Do not output chain-of-thought, hidden reasoning, or explanatory preamble. Reason internally and output only the requested FILE/REVIEW blocks.",
        "",
        LANGUAGE_RULE,
        "",
        "## Knowledge Type Definitions and Conflict Priority (AUTHORITATIVE)",
        ws.knowledge_type_guidance(),
        "",
        "## IMPORTANT: Source File",
        f"The original source file is: **{source_filename}**",
        "All wiki pages generated from this source MUST include this filename in their frontmatter `sources` field.",
        f"Today's date is **{today}**. Use this exact date for all new `created`, `updated`.",
        "",
    ]
    if schema:
        parts += [
            "## Project Schema and Routing (AUTHORITATIVE)",
            schema,
            "",
            "Use this schema as the primary routing rule for page types and directories.",
            "Every generated page's frontmatter type must match the schema directory used in its FILE path.",
            "",
        ]
    parts += [
        "## What to generate",
        "",
        "1. Generate entity, concept, method, rule, and scenario pages for key knowledge identified in the analysis.",
        f"2. The application will deterministically create the source summary page at **{source_summary_path}** after your response; 不要生成来源页或 wiki/sources/ 下的任何 FILE。",
        "3. Classify overlapping candidates using the stated priority; when confidence is low, use concept.",
        "Do not generate wiki/index.md or wiki/overview.md. The application maintains aggregate navigation separately.",
        "",
        "## Frontmatter Rules (CRITICAL — parser is strict)",
        "",
        "Every page begins with a YAML frontmatter block:",
        "1. The VERY FIRST line MUST be exactly `---` (three hyphens, nothing else). Do NOT wrap in ```yaml fence.",
        "2. Each field is `key: value` on its own line; frontmatter ends with another `---` line.",
        "3. Arrays use inline form `[a, b, c]` (bare strings). Wikilinks go in the BODY only;",
        "   write `related: [a, b]` with bare slugs, never `[[a]], [[b]]`.",
        "",
        "Required fields and types:",
        "  • type    — one of the schema's page types (entity | concept | source | method | rule | scenario)",
        "  • title   — string (quote it if it contains a colon)",
        f"  • created — {today} for new pages (YYYY-MM-DD, no quotes)",
        f"  • updated — {today} for new pages",
        "  • tags    — array of bare strings: tags: [a, b]",
        "  • related — array of bare wiki page slugs: related: [foo, bar-baz]",
        f'  • sources — array of source filenames; MUST include "{source_filename}"',
        "",
        "Concrete example:",
        "    ---",
        "    type: entity",
        "    title: Example Entity",
        f"    created: {today}",
        f"    updated: {today}",
        "    tags: [example, demo]",
        "    related: [related-slug]",
        f'    sources: ["{source_filename}"]',
        "    ---",
        "",
        "    # Example Entity",
        "",
        "    Body content. Use [[wikilink]] in the body for cross-references.",
        "",
        "Other rules:",
        "- Use [[wikilink]] syntax in the BODY for cross-references",
        "- Use kebab-case for Latin filenames; keep CJK characters for Chinese titles.",
        "- Preserve structured source data verbatim in fenced code blocks.",
        "- source is reserved for the application-generated source summary; do not emit source pages.",
        "- If a candidate could fit multiple types, follow source → entity → rule → method → scenario → concept.",
        "- If classification confidence is low, fall back to concept instead of guessing entity, rule, method, or scenario.",
        "",
        "## Output Format (MUST FOLLOW EXACTLY)",
        "",
        "Your ENTIRE response consists of FILE blocks. Optional REVIEW blocks after.",
        "FILE block template:",
        "```",
        "---FILE: wiki/path/to/page.md---",
        "(complete file content with YAML frontmatter)",
        "---END FILE---",
        "```",
        "",
        "## Output Requirements (STRICT)",
        "1. The FIRST character MUST be `-` (opening of `---FILE:`).",
        "2. No preamble, no trailing commentary outside FILE/REVIEW blocks.",
        "3. Do NOT echo the analysis.",
        "4. Between blocks, only blank lines.",
    ]
    if purpose:
        parts += ["", "## Wiki Purpose", purpose]
    if index:
        parts += ["", "## Current Wiki Index (preserve existing entries)", index]
    parts += ["", LANGUAGE_RULE]
    return "\n".join(parts)


# ── 主流程 ──────────────────────────────────────────────────


async def run_ingest(source_id: str, filename: str, content: bytes, ext: str, force: bool = False) -> list[str]:
    """执行两步 ingest。返回落盘页路径列表。异常时抛出并让调用方置 failed。

    force=True 时绕过 sha256 缓存，强制重新分析/生成（reprocess 场景）。
    """
    ws.update_ingest(source_id, progress="抽取文本…")
    text = extract_text(filename, content)
    if not text.strip():
        raise ValueError("未抽取出有效文本")

    identity = f"{source_id}.{ext}"
    if not force:
        cached = ws.check_ingest_cache(identity, text)
        if cached is not None:
            ws.update_ingest(source_id, status="done", progress="跳过（内容未变更）", pages_written=cached)
            return cached

    schema = _read_agg("schema.md")
    purpose = _read_agg("purpose.md")
    index = _read_agg("wiki/index.md")

    # 长文档分块分析
    ws.update_ingest(source_id, progress="Step 1/2: 分析…")
    analysis = await _analyze(text, schema, purpose, index, filename)

    ws.update_ingest(source_id, progress="Step 2/2: 生成 wiki 页…")
    source_summary_path = f"wiki/sources/{source_id}.md"
    gen_prompt = (
        f"Source document to process: **{filename}**\n\n"
        "The Stage 1 analysis below is CONTEXT to inform your output. Do NOT echo it.\n\n"
        "## Stage 1 Analysis (context only)\n\n"
        f"{analysis}\n\n"
        "---\n\n"
        f"Now emit the FILE blocks for the wiki files derived from **{filename}**.\n"
        "Your response MUST begin with `---FILE:` as the very first characters."
    )
    gen_system = build_generation_prompt(schema, purpose, index, filename, source_summary_path)
    generation = await _call_llm(gen_system, gen_prompt, max_tokens=GENERATION_MAX_TOKENS)

    blocks, warnings = parse_file_blocks(generation)
    review_items = parse_review_blocks(generation)

    if not blocks:
        raise ValueError(f"无可用 FILE 块。{' '.join(warnings[:3])}")

    with content_mutation():
        current = ws.get_ingest(source_id)
        if not current or current.get("status") != "processing":
            raise RuntimeError(f"资料已被删除或停止处理: {source_id}")

        written: list[str] = []
        for path, page_content in blocks:
            # 来源页是系统的确定性溯源记录。即使模型违反提示词输出 source 页，
            # 也不写入，避免模型伪造/重复来源入口。
            normalized_path = path.replace("\\", "/")
            if normalized_path.lower().startswith("wiki/sources/"):
                warnings.append(f"忽略模型生成的来源页：{path}")
                continue
            if ws.write_page(path, page_content):
                written.append(path)

        # 来源摘要始终由系统确定性写入，覆盖任何历史/模型同路径内容。
        source_page = _build_fallback_summary(filename, identity, analysis, text)
        if ws.write_page(source_summary_path, source_page):
            if source_summary_path not in written:
                written.append(source_summary_path)

        if not written:
            raise ValueError("生成页均落盘失败")

        # 聚合文件维护
        ws.append_log(f"## [{ws.today()}] ingest | {filename}")
        ws.rebuild_index()
        ws.rebuild_overview()

        # 写入 wiki_pages 表 + 缓存
        for path in written:
            ws.upsert_page(path, ws.read_page(path) or "")
        ws.save_ingest_cache(identity, text, written)

        ws.update_ingest(
            source_id,
            progress=f"{len(written)} 页已写入，正在同步检索索引…",
            pages_written=written,
        )

    index_progress = f"{len(written)} 页已写入" + (f"，{len(review_items)} 条 review" if review_items else "")
    try:
        await asyncio.to_thread(_sync_knowledge_pages_to_es)
    except Exception as exc:
        # Markdown/MySQL remain the source of truth.  A temporary ES or
        # embedding outage must not discard a successfully ingested file.
        logger.warning("Wiki 页面已写入，但 Elasticsearch 同步失败: %s", exc)
        index_progress += "，检索索引同步失败（后续查询将重试）"

    ws.update_ingest(source_id, status="done", progress=index_progress, pages_written=written)

    return written


def _sync_knowledge_pages_to_es() -> None:
    """Build the ES mirror after a successful Wiki page write."""
    from knowledge import get_knowledge_base

    get_knowledge_base().sync_to_elasticsearch()


async def _analyze(text: str, schema: str, purpose: str, index: str, filename: str) -> str:
    chunks = chunk_text(text)
    if len(chunks) == 1:
        system = build_analysis_prompt(purpose, index, schema)
        user = f"Analyze this source document:\n\n**File:** {filename}\n\n---\n\n{text}"
        return await _call_llm(system, user, max_tokens=ANALYSIS_MAX_TOKENS)

    # 限制并发数保护 LLM 网关；gather 保证结果按块序排列。
    concurrency = max(1, int(getattr(settings, "wiki_analysis_concurrency", 5) or 5))
    semaphore = asyncio.Semaphore(concurrency)

    async def analyze_chunk(i: int, chunk: str) -> str:
        async with semaphore:
            system = build_analysis_prompt(purpose, index, schema)
            user = f"Analyze this source document (chunk {i}/{len(chunks)}):\n\n**File:** {filename}\n\n---\n\n{chunk}"
            return await _call_llm(system, user, max_tokens=ANALYSIS_MAX_TOKENS)

    analyses = await asyncio.gather(
        *(analyze_chunk(i, chunk) for i, chunk in enumerate(chunks, 1))
    )

    # 合并各块分析为最终分析
    system = (
        "You are consolidating per-chunk analyses of one long source document into a single analysis. "
        "Follow the same six-section structure. Do not output chain-of-thought.\n\n" + LANGUAGE_RULE
    )
    user = (
        "## Per-chunk analyses\n\n"
        + "\n\n---\n\n".join(f"[Chunk {i}]\n{a}" for i, a in enumerate(analyses, 1))
        + "\n\nProduce one merged analysis."
    )
    return await _call_llm(system, user, max_tokens=ANALYSIS_MAX_TOKENS)


def build_source_page(filename: str, source_id: str, analysis: str, text: str) -> str:
    """确定性生成来源页；模型输出不会参与来源页路径或类型决策。"""
    today = ws.today()
    excerpt = text[:2000].strip()
    return (
        "---\n"
        "type: source\n"
        f'title: "{filename}"\n'
        f"created: {today}\n"
        f"updated: {today}\n"
        "tags: []\n"
        "related: []\n"
        f'sources: ["{filename}"]\n'
        "---\n\n"
        f"# {filename}\n\n"
        "## 资料摘要\n\n"
        f"{analysis[:3000].strip()}\n\n"
        "## 原文片段\n\n"
        f"```text\n{excerpt}\n```\n"
    )


def _build_fallback_summary(filename: str, identity: str, analysis: str, text: str) -> str:
    """兼容旧调用方的内部别名；来源页统一走确定性生成器。"""
    return build_source_page(filename, identity, analysis, text)


# ── 后台调度入口（router 通过 asyncio.to_thread 调用）──────


def raw_storage_key(source_id: str, ext: str) -> str:
    return join_storage_key(OSS_RAW_PREFIX, f"{source_id}.{ext}")


def list_source_files(*, storage: MediaStorage | None = None) -> list[dict[str, str]]:
    """列出原始资料文件，兼容 OSS 与迁移前的本地 raw/ 目录。"""
    storage = storage or get_media_storage()
    names: list[str]
    if storage.backend == "oss":
        prefix = f"{OSS_RAW_PREFIX}/"
        names = [key[len(prefix) :] for key in storage.list_keys(OSS_RAW_PREFIX) if key.startswith(prefix)]
    else:
        try:
            names = [entry.name for entry in os.scandir(RAW_DIR) if entry.is_file()]
        except OSError:
            names = []

    files: list[dict[str, str]] = []
    for name in names:
        if "/" in name or "\\" in name or "." not in name:
            continue
        source_id, ext = os.path.splitext(name)
        ext = ext.lstrip(".").lower()
        if source_id and ext in SUPPORTED_EXTS:
            files.append({"source_id": source_id, "ext": ext})
    return sorted(files, key=lambda item: item["source_id"])


def save_source_file(source_id: str, filename: str, content: bytes, ext: str) -> str:
    """把原始资料写入 OSS 或 raw/，返回稳定存储 key/路径。"""
    storage = get_media_storage()
    if storage.backend == "oss":
        key = raw_storage_key(source_id, ext)
        storage.write(key, content, "application/octet-stream")
        return key

    os.makedirs(RAW_DIR, exist_ok=True)
    path = os.path.join(RAW_DIR, f"{source_id}.{ext}")
    with open(path, "wb") as f:
        f.write(content)
    return path


def read_source_file(source_id: str, ext: str, *, storage: MediaStorage | None = None) -> bytes | None:
    storage = storage or get_media_storage()
    if storage.backend == "oss":
        key = raw_storage_key(source_id, ext)
        return storage.read(key) if storage.exists(key) else None
    path = os.path.join(RAW_DIR, f"{source_id}.{ext}")
    try:
        with open(path, "rb") as raw_file:
            return raw_file.read()
    except OSError:
        return None


def delete_source_file(source_id: str, ext: str, *, storage: MediaStorage | None = None) -> bool:
    storage = storage or get_media_storage()
    try:
        if storage.backend == "oss":
            key = raw_storage_key(source_id, ext)
            if storage.delete(key):
                return True
            return not storage.exists(key)

        path = os.path.join(RAW_DIR, f"{source_id}.{ext}")
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
        return True
    except OSError as error:
        logger.warning("删原始资料失败 %s.%s: %s", source_id, ext, error)
        return False
    except Exception as error:
        logger.warning("删原始资料失败 %s.%s: %s", source_id, ext, error)
        return False


def start_ingest_source(filename: str, content: bytes, ext: str) -> str:
    """同步入口：保存资料、建状态、启动后台 async ingest（非阻塞）。"""
    source_id = uuid.uuid4().hex
    sha256 = ws.sha256_text(content.decode("utf-8", errors="replace"))
    ws.create_ingest(source_id, filename, ext, sha256)
    save_source_file(source_id, filename, content, ext)
    _spawn_ingest(source_id, filename, content, ext, force=False)
    return source_id


def start_ingest_source_sync(filename: str, content: bytes, ext: str) -> str:
    """FastAPI 上传入口的别名：同步创建状态后，用 background_task 调度。

    语义与 start_ingest_source 一致，命名区分「是否在本函数内已完成磁盘/状态写入」。
    """
    return start_ingest_source(filename, content, ext)


def run_reprocess(source_id: str, filename: str, content: bytes, ext: str) -> None:
    """重跑 ingest（强制，绕过缓存）。同步阻塞式，供 background task 调用。"""
    asyncio.run(_run_ingest_async(source_id, filename, content, ext, force=True))


async def _run_ingest_async(source_id: str, filename: str, content: bytes, ext: str, force: bool) -> None:
    try:
        await run_ingest(source_id, filename, content, ext, force=force)
    except Exception as e:
        logger.exception("ingest 失败 %s: %s", filename, e)
        ws.update_ingest(source_id, status="failed", error_msg=str(e)[:500], progress="")


def _spawn_ingest(source_id: str, filename: str, content: bytes, ext: str, force: bool) -> bool:
    """在后台运行 async ingest，并保证同一 source_id 在本进程只运行一次。"""
    existing = _active_ingest_tasks.get(source_id)
    if existing is not None and not existing.done():
        logger.info("ingest 已在运行，跳过重复调度: %s", source_id)
        return False

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        asyncio.run(_run_ingest_async(source_id, filename, content, ext, force))
        return True

    task = loop.create_task(_run_ingest_async(source_id, filename, content, ext, force))
    _active_ingest_tasks[source_id] = task

    def _release(finished: asyncio.Task[None]) -> None:
        if _active_ingest_tasks.get(source_id) is finished:
            _active_ingest_tasks.pop(source_id, None)

    task.add_done_callback(_release)
    return True


def resume_pending_ingests() -> dict[str, int]:
    """恢复上个进程遗留的 processing 任务。

    原始文件仍在时重新进入幂等摄取流程；原始文件缺失或无法读取时明确标记 failed，
    避免前端永久轮询“解析中”。该函数应在应用启动事件循环内调用。
    """
    resumed = 0
    failed = 0
    skipped = 0

    for ingest in ws.list_ingest():
        if ingest.get("status") != "processing":
            continue

        source_id = str(ingest.get("source_id") or "")
        filename = str(ingest.get("filename") or "")
        ext = str(ingest.get("ext") or "").lower()
        if not source_id or not ext:
            failed += 1
            if source_id:
                ws.update_ingest(
                    source_id,
                    status="failed",
                    progress="",
                    error_msg="服务重启后无法恢复：任务元数据不完整",
                )
            continue

        try:
            content = read_source_file(source_id, ext)
        except OSError as exc:
            failed += 1
            ws.update_ingest(
                source_id,
                status="failed",
                progress="",
                error_msg=f"服务重启后无法恢复：原始文件不可读（{type(exc).__name__}）",
            )
            continue

        if content is None:
            failed += 1
            ws.update_ingest(
                source_id,
                status="failed",
                progress="",
                error_msg="服务重启后无法恢复：原始文件不可读（FileNotFoundError）",
            )
            continue

        if not content:
            failed += 1
            ws.update_ingest(
                source_id,
                status="failed",
                progress="",
                error_msg="服务重启后无法恢复：原始文件为空",
            )
            continue

        ws.update_ingest(
            source_id,
            status="processing",
            progress="服务重启，正在恢复解析…",
            error_msg="",
        )
        if _spawn_ingest(source_id, filename, content, ext, force=False):
            resumed += 1
        else:
            skipped += 1

    if resumed or failed or skipped:
        logger.info("wiki ingest 启动恢复: resumed=%d failed=%d skipped=%d", resumed, failed, skipped)
    return {"resumed": resumed, "failed": failed, "skipped": skipped}
