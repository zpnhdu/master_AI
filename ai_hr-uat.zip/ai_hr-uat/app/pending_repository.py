"""Persistence helpers for restart-safe pending pipeline data.

The public ``app.db`` module remains the compatibility facade.  Database
connections are resolved lazily so importing this repository never opens a
connection or triggers schema initialization.
"""

import json


def _db_facade():
    """Resolve app.db only when a pending-data operation is invoked."""
    from app import db

    return db


def get_db():
    return _db_facade().get_db()


def save_pending(pipeline_id: str, data_type: str, data: dict):
    """Persist one pending resume or video and commit it immediately."""
    conn = get_db()
    conn.execute(
        "INSERT INTO pending_data (pipeline_id, data_type, data_json) VALUES (%s,%s,%s)",
        (pipeline_id, data_type, json.dumps(data, ensure_ascii=False)),
    )
    conn.commit()


def get_pending(pipeline_id: str, data_type: str) -> list[dict]:
    """Load pending data for one pipeline and type in insertion order."""
    conn = get_db()
    rows = conn.execute(
        "SELECT data_json FROM pending_data WHERE pipeline_id=%s AND data_type=%s ORDER BY id",
        (pipeline_id, data_type),
    ).fetchall()
    results = []
    for row in rows:
        try:
            results.append(json.loads(row["data_json"]))
        except (json.JSONDecodeError, TypeError):
            continue
    return results


def clear_pending(pipeline_id: str, data_type: str | None = None):
    """Clear pending data for a pipeline and commit the deletion."""
    conn = get_db()
    if data_type:
        conn.execute("DELETE FROM pending_data WHERE pipeline_id=%s AND data_type=%s", (pipeline_id, data_type))
    else:
        conn.execute("DELETE FROM pending_data WHERE pipeline_id=%s", (pipeline_id,))
    conn.commit()


def delete_pending_for_pipeline(conn, pipeline_id: str) -> None:
    """Delete pending data using a caller-owned connection and transaction."""
    conn.execute("DELETE FROM pending_data WHERE pipeline_id=%s", (pipeline_id,))


def get_all_pending() -> dict[str, dict[str, list[dict]]]:
    """Load all pending data grouped by pipeline and data type."""
    conn = get_db()
    rows = conn.execute("SELECT pipeline_id, data_type, data_json FROM pending_data ORDER BY id").fetchall()
    result: dict[str, dict[str, list]] = {}
    for row in rows:
        pid = row["pipeline_id"]
        dtype = row["data_type"]
        if pid not in result:
            result[pid] = {}
        if dtype not in result[pid]:
            result[pid][dtype] = []
        try:
            result[pid][dtype].append(json.loads(row["data_json"]))
        except (json.JSONDecodeError, TypeError):
            continue
    return result
