# 前端 React/Vite 渐进迁移计划

## 1. 项目目标

### 1.1 业务目标

把当前多页面 HTML/原生 JavaScript 前端逐步迁移到统一的 React 单页应用，优先改善：

- 工作室首页的导航和页面切换体验；
- 候选人、职位、面试、人才库等高频页面的组件复用；
- 表格、表单、筛选、分页、加载态和错误态的一致性；
- 前端 API 类型安全、缓存和请求失效管理；
- 发布、回滚和新旧页面并行运行的可控性。

### 1.2 非目标

本计划不包含：

- 更换 FastAPI 后端；
- 重做数据库、权限模型或 API 业务语义；
- 引入 Next.js、SSR 或独立 BFF；
- 一次性删除旧版 `frontend/` 页面；
- 在本计划阶段修改代码。

## 2. 当前实现基线

以下结论来自当前 `dev` 分支代码：

1. `app/routers/pages.py` 的 `/` 路由先读取当前用户，再根据 `default_page_for(user)` 返回默认页面；未登录请求由认证中间件转到 `/login`。
2. `app/access_control.py` 当前把 `pipeline:read` 对应的默认页面配置为 `/frontend/studio.html`，因此有该权限的用户已经默认进入 studio。
3. `frontend/index.html` 通过 meta refresh 和 `location.replace` 跳转到 `studio.html`。
4. `frontend/studio.html` 是一个包含布局、导航、样式和业务脚本的大型页面，当前直接调用 `/api/pipelines`、`/api/company-config`、`/api/ontology` 等接口。
5. FastAPI 当前将项目的 `frontend/` 目录挂载到 `/frontend` 和 `/static`。
6. 当前仓库没有独立的 React/Vite 前端工程配置，迁移需要新建前端工程目录，不能把 React 源码直接混入现有静态目录。

## 3. 目标技术方案

### 3.1 最终技术栈

| 层次 | 方案 | 责任边界 |
| --- | --- | --- |
| 应用框架 | React + Vite + TypeScript | 页面、组件和构建 |
| UI 组件 | Ant Design 6 | 表格、表单、弹窗、菜单、反馈、主题 |
| 样式 | Ant Design Design Token + CSS Modules | 主题和业务页面样式 |
| 路由 | React Router 8.x | 页面路由、参数和认证后跳转 |
| 服务端状态 | TanStack Query 5.x | API 数据、缓存、请求状态、失效和刷新 |
| 本地状态 | Zustand 5.x | 侧边栏、弹窗、布局、临时 UI 状态 |
| 表单 | React Hook Form + Zod | 表单状态、校验和类型推导 |
| API 类型 | `openapi-typescript` + `openapi-fetch` | 从 FastAPI OpenAPI 生成和调用类型安全客户端 |
| 图表 | ECharts | 招聘漏斗、趋势和雷达图 |
| 单元测试 | Vitest + Testing Library | 组件和业务逻辑 |
| 浏览器测试 | Playwright | 登录、路由、核心业务链路 |
| 包管理 | pnpm | 依赖和锁文件 |

### 3.2 UI 方案结论：选 Ant Design

本项目优先选 Ant Design，不把 Tailwind 作为主 UI 方案，理由是：

- HR/BI 系统的主要工作量在表格、表单、筛选、分页、日期、抽屉、弹窗和权限反馈；
- Ant Design 直接提供这些企业后台组件，能减少自建交互和无障碍细节的成本；
- Ant Design 的主题 Token 能覆盖品牌色、密度、圆角和状态色，不需要为每个页面单独维护视觉变量；
- Tailwind 是原子化 CSS，不等同于组件库。若作为主方案，仍需要自行建设 DataTable、Form、Dialog、Select 等基础组件；
- Ant Design 和 Tailwind 同时作为主样式系统会产生间距、颜色、层级和状态表达的双重来源。

Tailwind 只适合未来存在高度定制的营销页、落地页或独立设计系统时单独引入。本次 HR/BI 主应用不引入 Tailwind。

### 3.3 版本策略

以下是按 2026-08-17 查询到的稳定标签形成的候选基线，真正创建工程时要先执行一次安装、构建和核心页面冒烟测试，再写入锁文件：

| 依赖 | 候选版本 |
| --- | --- |
| `react` / `react-dom` | `19.2.8` |
| `vite` | `8.2.0` |
| `typescript` | `7.0.2` |
| `antd` | `6.5.3` |
| `@ant-design/icons` | `6.x` |
| `react-router` | `8.3.0` |
| `@tanstack/react-query` | `5.101.4` |
| `zustand` | `5.0.14` |
| `react-hook-form` | `7.84.0` |
| `zod` | `4.4.3` |
| `vitest` | `4.1.1` |
| `@playwright/test` | `1.61.1` |

版本规则：

- CI 不使用 `latest`、beta、alpha 或 nightly 标签；
- React、Vite、Ant Design、TypeScript 先固定版本，再由 Renovate/Dependabot 提交升级；
- 每次升级必须通过类型检查、生产构建和核心 Playwright 链路；
- Vite 8 要求 Node.js 20.19+ 或 22.12+，项目统一使用 Node.js 22.12+ LTS；
- Ant Design 6 要求 React 18+，并配套 `@ant-design/icons` 6.x；
- 若 TypeScript 7 在项目依赖或编辑器插件上出现兼容问题，允许只把 TypeScript 回退到 6.x，不回退 React、Vite 和 Ant Design 主架构。

参考：

- [Vite 8 正式发布](https://vite.dev/blog/announcing-vite8)
- [Vite 环境要求](https://vite.dev/guide/)
- [Ant Design v5 到 v6 迁移说明](https://ant.design/docs/react/migration-v6/)
- [React npm 稳定标签](https://registry.npmjs.org/react/latest)
- [Ant Design npm](https://www.npmjs.com/package/antd)
- [Tailwind CSS npm](https://www.npmjs.com/package/tailwindcss)

## 4. 目标目录和部署边界

### 4.1 新前端工程目录

建议新建独立目录：

```text
frontend-react/
├── public/
├── src/
│   ├── app/
│   ├── assets/
│   ├── components/
│   ├── features/
│   ├── layouts/
│   ├── pages/
│   ├── services/
│   ├── stores/
│   ├── styles/
│   ├── types/
│   └── main.tsx
├── tests/
├── package.json
├── tsconfig.json
├── vite.config.ts
└── playwright.config.ts
```

旧版静态页面继续保留在 `frontend/`。迁移完成前，两个目录不能混用构建产物和源码。

### 4.2 构建和服务方式

第一阶段采用同域部署，避免改动 Cookie、CORS 和认证边界：

```text
浏览器
  ├── /、/studio、/app/*        → React/Vite 构建产物
  ├── /frontend/*               → 旧版静态页面，迁移期间保留
  ├── /static/*                 → 旧版静态资源，迁移期间保留
  └── /api/*、/ws               → 现有 FastAPI
```

开发环境由 Vite 代理 `/api` 和 `/ws` 到 FastAPI；生产环境优先由 Nginx 或 FastAPI 提供同域静态文件。不要在迁移初期拆成不同域名。

## 5. 根路径和 Studio 首页策略

### 5.1 当前行为

当前 `/` 不是简单静态文件映射，而是认证和权限入口：

```text
/ 未登录  → /login
/ 已登录  → 按权限选择默认页面
pipeline:read → /frontend/studio.html
```

因此当前代码已经满足“有权限用户默认进入 studio”的主要业务目标。不能为了让地址看起来像首页而跳过登录中间件。

### 5.2 迁移期间的推荐行为

第一阶段保留现有行为，只新增 React 页面入口，不修改旧页面：

```text
/ 未登录                         → /login
/ 已登录且 FRONTEND_APP_ENABLED=0 → /frontend/studio.html
/ 已登录且 FRONTEND_APP_ENABLED=1 → /studio
/frontend/studio.html（开关=0）  → 旧版 Studio 回退页
/frontend/studio.html（开关=1）  → /studio，并保留查询参数
```

`FRONTEND_APP_ENABLED` 通过环境变量控制，构建缺失或开关关闭时仍回退旧版页面。

### 5.3 最终行为

```text
/ 未登录                 → /login
/ 已登录且有权限         → /studio
/ 已登录但无权限         → /forbidden
/frontend/studio.html    → 迁移完成后保留一段观察期，再决定是否下线
```

React 应用内部使用 `/studio` 作为稳定路由，不把 `studio.html` 作为 React 页面名。这样可以在未来更换构建工具时保持业务 URL 不变。

## 6. 页面和模块迁移顺序

### 6.1 P0：应用外壳和 Studio

目标：先让用户能稳定进入新应用，并复刻 Studio 的主路径。

范围：

- 登录态读取和过期处理；
- App Shell：品牌、侧边栏、顶部栏、内容区；
- `/`、`/studio`、`/login`、`/forbidden`；
- Pipeline 列表、创建、删除、批量操作；
- 公司配置和知识图谱配置的入口；
- 全局加载态、错误态、空状态、通知和确认弹窗。

完成标准：

- 具备 `pipeline:read` 的账号从 `/` 进入 `/studio`；
- 未登录不能看到 Studio 数据；
- Studio 的核心操作与旧页面结果一致；
- 旧版 `/frontend/studio.html` 仍能独立访问并可回滚。

### 6.2 P1：高频招聘页面

按业务频率迁移：

1. 流水线详情：`pipeline-detail.html`；
2. 数据仪表盘：`dashboard.html`；
3. 人才库：`talent-pool.html`；
4. 人才画像：`profile.html`；
5. 知识库：`knowledge.html`。

每个页面按“路由、页面骨架、API 查询、表格/表单、错误路径、权限、E2E”完整交付，不把多个页面堆在同一批次里只完成视觉层。

### 6.3 P2：复杂交互页面

最后迁移对实时性、媒体或 Agent 交互要求较高的页面：

- `agent.html`、`written-test.html`；
- `mass-interview.html`、`mass-dashboard.html`；
- `xiao_hai.html`、相关画布和海报工作流；
- 邮箱同步、飞书、RPA 等配置页面。

原因：这些页面涉及 WebSocket、音视频、长任务、轮询、文件上传或外部服务，不应与第一批路由基础设施同时排错。

### 6.4 P3：收口和旧版下线

- 统计旧版页面访问量和错误量；
- 确认所有入口、书签、邮件链接和运营链接已迁移；
- 保留旧版回退开关一个发布周期；
- 再删除重复的旧版页面和旧版专用脚本；
- 最后再考虑把 FastAPI 的静态挂载从双轨收敛为 React 构建产物。

## 7. 代码组织约束

### 7.1 推荐目录职责

```text
src/
├── app/              路由、QueryClient、错误边界、权限入口
├── layouts/          AppShell、登录布局、公开页面布局
├── pages/            路由级页面，不直接承载所有请求细节
├── features/         按业务域组织：pipeline、talent、interview、knowledge
├── components/       跨业务通用组件
├── services/         OpenAPI client、请求适配、上传和 WebSocket
├── stores/           只保存本地 UI 状态
├── types/            后端生成类型和少量前端领域类型
└── styles/           Token、全局样式和 CSS Modules 公共约束
```

### 7.2 状态边界

| 数据类型 | 放置位置 |
| --- | --- |
| 候选人列表、流水线详情、统计数据 | TanStack Query |
| 请求缓存、分页、刷新、失效 | TanStack Query |
| 侧边栏展开、弹窗、主题、当前布局 | Zustand |
| 筛选、排序、分页、当前 tab | URL Search Params 优先 |
| 未提交表单值 | React Hook Form |
| 表单校验规则 | Zod |
| 登录凭据 | 继续使用后端 Cookie/Session，不在 Zustand 中保存密码或长期 Token |

禁止把服务端列表复制到 Zustand，再自行维护 loading、error 和刷新逻辑。

### 7.3 API 约束

- 以 FastAPI OpenAPI 作为接口类型来源；
- 每个 feature 维护自己的 query key 和 mutation；
- 统一处理 401、403、422、500 和网络断开；
- 401 统一跳转登录，403 统一进入无权限页或显示无权限状态；
- mutation 成功后只失效受影响的 query，不做全局粗暴刷新；
- WebSocket 和长任务封装为独立 service，不直接散落在页面组件中；
- 文件上传、下载和媒体播放保留现有 API 协议，先迁移调用方，不在前端迁移阶段改后端协议。

## 8. 分阶段执行计划

### Phase 0：基线和工程准备

预估：2～3 个工作日。

任务：

- [ ] 固定 Node、pnpm、React、Vite、Ant Design 版本；
- [ ] 创建 `frontend-react/`，配置 React、TypeScript、Vite；
- [ ] 配置 Vite `/api`、`/ws` 代理；
- [ ] 配置 ESLint/Prettier 或项目统一格式化策略；
- [ ] 配置 Vitest、Testing Library、Playwright；
- [ ] 记录旧版 Studio 的截图、URL、接口请求和关键操作结果；
- [ ] 记录登录、权限不足、会话过期、网络错误的现状行为；
- [ ] 生成首版 OpenAPI 类型，确认后端 schema 是否存在阻塞问题。

退出条件：

- 新工程可启动、可构建、可运行测试；
- React 页面可以同域访问 FastAPI 健康检查和一个只读 API；
- 旧版行为基线已保存；
- 没有修改旧版业务页面。

### Phase 1：App Shell、认证和根路径

预估：3～5 个工作日。

任务：

- [x] 实现 `AuthProvider` 或等价的会话读取层；
- [x] 实现 `ProtectedRoute` 和 `PermissionGate`；
- [x] 实现 `/login`、`/forbidden`、`/studio` 路由；
- [x] 实现 Ant Design 主题 Token、品牌色、密度和响应式断点；
- [x] 实现 App Shell 和统一导航；
- [x] 将 `/` 的新旧入口切换做成可回滚开关；
- [x] 保留 `/frontend/studio.html` 旧入口。

退出条件：

- 未登录访问 `/` 仍到登录页；
- 已登录且具备权限访问 `/studio`；
- 失去权限时返回 403 页面，不显示半成品内容；
- 关闭开关即可恢复旧版 Studio；
- Playwright 覆盖登录、登出、过期和无权限路径。

### Phase 2：Studio 业务迁移

预估：5～8 个工作日。

任务：

- [x] 把 Studio 页面拆成导航、Pipeline 列表、Pipeline 操作和配置面板；
- [x] 为 `/api/pipelines`、`/api/company-config`、`/api/ontology` 建立 query/mutation（本阶段本体规则为只读查询）；
- [x] 迁移创建、删除、批量操作和自动运行；
- [x] 统一空列表、加载、失败、重试和确认弹窗；
- [ ] 对比旧版数据展示、权限和操作结果；
- [ ] 开启小范围用户灰度。

退出条件：

- Studio 的核心操作全部有自动化验收；
- 没有重复的服务端数据状态；
- 线上出现问题时可在一个配置变更内回退旧版。

### Phase 3：高频页面迁移

预估：每个页面 3～7 个工作日，按页面复杂度调整。

每个页面固定执行：

1. 盘点旧页面入口和被引用 URL；
2. 列出页面 API、权限和数据依赖；
3. 先写路由和页面骨架；
4. 再接 TanStack Query；
5. 再迁移表格/表单和状态；
6. 最后补错误路径、权限、响应式和 E2E；
7. 通过新旧结果对比后再切换入口。

页面顺序：

- [x] `pipeline-detail.html` → `/pipelines/:pipelineId`（2026-08-18 完成，详见 acceptance-checklist.md 第二批记录）；
- [ ] `dashboard.html` → `/dashboard`；
- [ ] `talent-pool.html` → `/talent-pool`；
- [ ] `profile.html` → `/profiles/:profileId`；
- [ ] `knowledge.html` → `/knowledge`。

### Phase 4：复杂页面和实时能力

预估：每个业务域 1～2 周。

任务：

- [ ] 抽象 WebSocket 生命周期、重连、断线提示和页面卸载；
- [ ] 抽象上传、媒体播放、进度和取消；
- [ ] 抽象长任务轮询和任务状态缓存；
- [ ] 迁移 Agent 对话与工作台；
- [ ] 迁移面试、录制和多人面试；
- [ ] 迁移小海画布、海报生成和文件资源库。

退出条件：

- 刷新页面或断网重连不会丢失不可恢复的任务状态；
- 长任务失败有可见错误和重试入口；
- WebSocket 关闭后不会残留定时器、事件监听器或重复请求。

### Phase 5：全量切换和旧版下线

预估：3～5 个工作日观察期，加一个发布周期。

任务：

- [ ] 全量开启 `/` → `/studio`；
- [ ] 监控登录成功率、页面 JS 错误、API 4xx/5xx 和核心操作成功率；
- [ ] 检查旧版页面访问和外部链接；
- [ ] 保留旧版回退开关一个发布周期；
- [ ] 形成下线清单；
- [ ] 删除旧版页面前完成一次全量回归和备份。

## 9. 测试和验收策略

### 9.1 必测用户路径

- 未登录访问 `/`；
- 登录成功后进入 `/studio`；
- 登录成功但没有 `pipeline:read`；
- Cookie 过期后访问受保护页面；
- 刷新 `/studio` 和带参数的详情页；
- 创建、删除、批量操作和自动运行 Pipeline；
- API 返回 401、403、422、500 和超时；
- 列表为空、加载慢、重复点击、重复提交；
- 浏览器窄屏和常见桌面分辨率；
- WebSocket 断开、重连和页面离开；
- 旧版 `/frontend/studio.html` 回退入口。

### 9.2 质量门槛

- TypeScript 类型检查无错误；
- 生产构建成功且无未处理的构建警告；
- 核心页面单元测试覆盖查询状态、权限和表单校验；
- 核心 E2E 全部通过；
- 新旧入口切换至少完成一次回滚演练；
- 前端错误日志能关联路由、用户、请求和发布版本，但不记录密码、Cookie 或 API Key。

## 10. 发布、灰度和回滚

### 10.1 发布顺序

1. 部署 React 构建产物，但默认不切换根路径；
2. 由内部测试账号访问 `/studio`；
3. 开启少量账号灰度；
4. 验证核心 API、权限和页面错误率；
5. 扩大灰度；
6. 全量切换 `/` 到 React Studio；
7. 观察一个完整业务周期。

### 10.2 回滚条件

出现以下任一情况，应立即回到旧版 Studio：

- 登录成功率或权限判断异常；
- Pipeline 创建、删除、批量操作出现数据风险；
- 关键 API 失败率持续升高；
- 页面白屏、路由刷新丢失或静态资源无法加载；
- 长任务、WebSocket 或文件上传不可恢复。

回滚动作只切换前端入口开关，不回滚数据库、不删除新构建产物、不修改后端数据。

## 11. 主要风险和应对

| 风险 | 影响 | 应对 |
| --- | --- | --- |
| 直接把 `/` 改成静态 studio | 绕过登录或出现权限错乱 | 保留认证中间件，根路径只做认证后的路由选择 |
| 新旧页面同时修改同一 API | 行为不一致 | 先不改 API 协议，建立 OpenAPI 类型和契约测试 |
| 服务端数据复制到多个 Store | 数据过期、刷新不一致 | TanStack Query 作为唯一服务端数据源 |
| Tailwind 与 Ant Design 混用 | 样式来源冲突 | 主应用只保留 Ant Design + CSS Modules |
| 一次性迁移全部页面 | 发布风险和回滚困难 | 按页面域渐进迁移，旧版入口始终可回退 |
| 新路由刷新 404 | 用户直接打开详情链接失败 | 同域静态回退和 FastAPI/Nginx history fallback 先验收 |
| WebSocket/上传迁移还有遗漏 | 面试和长任务中断 | 把实时能力单独放在 P2，不与 Studio 一起迁移 |
| 外部链接仍指向旧页面 | 用户进入旧版或丢失上下文 | 建立旧 URL 清单，保留兼容路由和跳转 |

## 12. 完成定义

迁移不能只以“页面能打开”为完成。整个迁移达到以下条件才算结束：

- `/` 对未登录、已登录、有权限、无权限四类用户行为正确；
- Studio 和所有已迁移页面都有 React 路由、权限、加载态、错误态和空状态；
- API 数据只由 TanStack Query 管理，UI 状态不承载服务端列表；
- 核心业务链路有自动化测试；
- 新旧入口可切换，且完成过回滚演练；
- 旧版页面的访问量和依赖已确认可下线；
- 删除旧版前端文件不会影响书签、邮件、外部候选人链接和运维入口；
- 文档、构建、部署和故障回滚步骤已同步给维护人员。

## 13. 首批执行清单

建议从以下任务开始，不立即改 `/`：

1. 建立 `frontend-react/` 工程并通过空壳构建；
2. 加入同域 Vite 代理和 FastAPI 健康检查；
3. 完成登录态、权限守卫和 `/studio` 空壳路由；
4. 用一个只读 Pipeline 查询验证 TanStack Query；
5. 迁移 Studio 的列表展示；
6. 迁移 Studio 的创建/删除操作；
7. 写根路径切换和旧版回退 E2E；
8. 通过灰度后，再决定是否将 `/` 默认入口切到 React Studio。

本计划阶段不改变现有代码，以上清单是后续实现顺序。
