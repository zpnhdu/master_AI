# 前端 React/Vite 迁移计划

本目录只保存前端改造方案、迁移边界和验收标准，不包含本次迁移代码。

## 文档入口

- [完整迁移计划](./migration-plan.md)
- [验收清单](./acceptance-checklist.md)

## 目标

将现有 FastAPI 静态 HTML/JavaScript 前端，渐进迁移到 React + Vite + TypeScript + Ant Design 架构。

根路径目标：

```text
/ → 登录校验 → /studio
```

迁移期间保留 `/frontend/studio.html` 等旧页面作为回退链路，不采用一次性重写。

## 当前状态

- 当前 `dev` 分支的 `frontend/` 仍以 HTML/原生 JavaScript 为主。
- FastAPI 负责页面路由、静态文件挂载、认证中间件和 API。
- 现有根路径已经根据登录状态和权限选择默认页面，具备 `pipeline:read` 权限的用户默认进入 studio。
- 本次只建立计划目录，未修改现有前端或后端代码。
