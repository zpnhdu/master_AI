# 前端迁移验收清单

## 当前阶段执行记录（2026-08-18）

- [x] 已建立独立 `frontend-react/` React/Vite 工程，旧版 `frontend/` 页面保持不变；FastAPI 根入口增加默认关闭、可回退的 React 开关。
- [x] 已实现 `/`、`/studio`、`/login`、`/forbidden` 的认证感知路由。
- [x] 已实现 Ant Design Studio 壳层、空状态、加载状态、错误重试和只读 Pipeline 列表。
- [x] 已接入 TanStack Query 管理 `/api/pipelines`、Agent、公司配置和本体规则服务端状态，筛选、排序和分页保存在 URL 参数。
- [x] 已实现 Studio 创建表单、流程预设、创建后自动启动、删除确认、批量删除、Agent/公司配置、本体规则只读入口、失败反馈和 mutation 后列表刷新。
- [x] 已统一 Pipeline API 错误反馈：401、403、422、500、超时和断网均有可见提示与重试入口。
- [x] Vitest：4 个测试文件、46 个测试通过；TypeScript 类型检查通过；Vite 生产构建通过。
- [x] HTTP 检查：Vite 根页面返回 200，`/api/auth/me` 同源代理返回预期 401。
- [x] Playwright 浏览器冒烟：已安装 Playwright Chromium，核心冒烟测试 1/1 通过。
- [x] FastAPI 入口浏览器验收：未登录 `/` 进入 `/login`，测试 Cookie 登录后 `/` 进入 `/studio`，旧版 `/frontend/studio.html` 仍可访问。
- [x] 旧版导航兼容：React 开关开启时 `/frontend/studio.html` 跳转 `/studio`，关闭时保留旧版页面。
- [x] 旧版 Studio 跳转保留查询参数，上下文可继续用于新版筛选。
- [x] 后端回归测试：25 项根入口开关、构建缺失回退、Studio 权限、旧链接、WebSocket 和静态资源边界测试通过。
- [x] 旧版工作区链接回归：`talent-pool` 在 React 开关开启时仍可访问（`pipeline-detail`、`mass-dashboard` 已迁移，见下方批次记录）。
- [x] 配置安全扫描：React 迁移代码没有密码、Cookie、令牌或 API Key 的日志和持久化逻辑。
- [x] API/WebSocket 入口回归：`/api/health` 与 `/ws` 同域入口可用，静态资源响应保持 `no-cache`。

### pipeline-detail 迁移（2026-08-18 第二批）

- [x] React 版流水线详情页上线新路由 `/pipelines/:pipelineId`；旧 `/pipeline-detail?id=` 由 React 内重定向保留 id，旧 `/frontend/pipeline-detail.html` 在开关开启时 307 跳转并保留 query。
- [x] 页面能力对齐旧版：Hero（状态徽标 / 六阶段 stepper / 自动运行）、KPI 概览、KG 推荐 chips、六 Agent 卡片（产出摘要 / 进度 / 跳转旧版工作台）、极简模式候选人导入（名单粘贴 / OCR 拍照 / CSV 模板下载）。
- [x] 后端开关接线：`/pipeline-detail` 走 `_serve_app_entry`，新增 `/pipelines/{pipeline_id}` 路由（开关关闭或构建缺失时回退旧页）；`main.py` 以 `LEGACY_REACT_PAGE_REDIRECTS` 映射表管理旧 HTML 跳转；`access_control.py` 为 `/pipelines/` 前缀补 `pipeline:read` 映射。
- [x] 测试：前端新增 selectors/api 43 个用例，全量 Vitest 90 通过、typecheck 通过；后端 `test_frontend_switch.py` 29 项通过（新增旧链 307、双入口开关回退、未登录跳转、权限映射用例）。
- [x] **「重置」按钮决策：砍掉不迁移**。旧版按钮调用 `POST /api/pipelines/{id}/reset`，后端不存在该路由（旧按钮实际为死链）。React 版不实现；如业务确需重置能力，须先补后端端点再恢复 UI，已登记为后端待办。
- [x] KG 推荐 chips 的节点详情弹窗降级为悬浮提示（title 属性展示节点定义；旧版弹窗依赖尚未迁移的 knowledge 页），待 knowledge 页迁移后恢复。
- [x] React Studio 列表项已接详情跳转：点击卡片 `navigate('/pipelines/:id')`，复选框与删除按钮阻止冒泡不跳转，支持 Enter 键与 focus 可见样式。
- [x] 视觉对齐修复（2026-08-18）：详情页去除 AppShell 侧边栏，改为旧版独立整页布局——sticky 白色 hero（返回/角色/徽标/meta 胶囊/stepper）、灰底滚动主区、白卡 KPI、三列 Agent 卡片网格、极简模式黄色渐变卡、右上角 toast 反馈；样式值逐项拷贝自 pipeline-detail.html。

### mass-dashboard 迁移（2026-08-18 第三批）

- [x] React 版多人面试中心上线 `/mass-dashboard` 与 `/mass-dashboard/:pipelineId`，旧入口 `/frontend/mass-dashboard.html?pid=` 在开关开启时 307 跳转并保留岗位上下文。
- [x] 页面能力对齐旧版：岗位选择、Token 使用量、五项统计、实时监控、排名看板、推荐筛选、红旗筛选、候选人详情、简历查看、面试评估、视频播放、复制/导出邀请链接、邮件邀请、续期、批量续期、HR 决策和直播流停止。
- [x] 接入 TanStack Query 与 WebSocket：多人面试状态、流状态、排名和候选人资料分别缓存，操作成功后只刷新当前岗位相关查询；实时消息触发状态、流和排名刷新。
- [x] 后端入口开关与权限接线：`/mass-dashboard` 使用 React Shell，构建缺失或开关关闭时回退旧页；页面权限为 `interview:read`。
- [x] 测试与验证：`MassDashboardPage` 3 个前端用例通过，`tests/test_frontend_switch.py` 32 个后端用例通过，TypeScript 检查通过，Vite 生产构建通过。
- [ ] HLS 专用播放器和视频深度分析状态仍沿用后端返回的兼容 URL；如需完整迁移旧版 HLS 控制条和逐题视频分析交互，另立媒体专项。

### xiao_xun 迁移（2026-08-18 第四批）

- [x] React 小寻工作台上线 `/xiao-xun`，旧版 `/frontend/xiao_xun.html?pipeline=` 在 React 开关开启时保留查询参数并跳转；开关关闭或构建缺失时回退旧页面。
- [x] 完整迁移本地简历流程：拖拽/选择、待上传文件列表、移除/清空、50 份和 10MB 限制、上传结果、自动解析、重复/失败原因、联系方式异常提醒和已上传文件查看。
- [x] 完整迁移人才库流程：JD 条件、手动必选/排除条件、精准/平衡/宽松召回、相关度/地区/来源/更新时间筛选、详情查看、当前结果选择、批量导入、防重复提交和导入后下游入口。
- [x] 三栏处理概况对齐旧版：候选人来源、解析进度、待处理事项、文件格式和人才库数量；辅助统计失败提供可见重试。
- [x] `/xiao-xun` 使用 `pipeline:read` 权限，Agent 导航已切换到 React 路由，传递下游使用后端 `next` Agent 解析结果。
- [x] 小寻前端全量 Vitest：13 个测试文件、142 个测试通过；TypeScript 检查通过；Vite 生产构建通过。
- [x] 后端 `tests/test_frontend_switch.py`：42 个测试通过，包含旧入口跳转、开关回退和小寻权限映射。
- [ ] gstack Chromium 浏览器冒烟待补：本机控制器缺少 Bun，安装/构建需用户确认；代码级页面测试已通过。

### xiao_hai / xiao_shai / xiao_mian / xiao_ping 迁移（2026-08-18 第五批）

- [x] 四个 React 路由上线：`/xiao-hai`、`/xiao-shai`、`/xiao-mian`、`/xiao-ping`；旧入口在 React 开启时保留 query 并 307 跳转，关闭或构建缺失时回退旧 HTML。
- [x] 小海核心流程：读取 JD/公司配置、海报版本预览和历史切换、文案调整生成新版本、参考图上传、版本确认、PNG 下载和下游传递；HTML 模板预览使用隔离 iframe。
- [x] 小筛核心流程：JD 默认规则、硬门槛与权重校验、预览/执行筛选、状态筛选、搜索排序、单人/批量人工复核、CSV 导出和确认传递给小面。
- [x] 小面核心流程：候选人恢复、单人/批量出题、生成任务轮询、题目编辑保存、单人审核、应用到全部、题集导出、视频面试/在线笔试发起、链接复制、邮件邀请、人工面试记录和人工评估。
- [x] 在线笔试候选人流程迁移到 React：免登录 token 校验、欢迎页、倒计时、逐题文字作答、语音转写、可选摄像头录像、提交确认、自动提交及过期/已提交状态；小面中的视频邀请与笔试邀请独立展示。
- [x] 小评核心流程：评估队列、强推/推荐/不推荐分组、排名、人工复核、服务端报告生成、无报告时本地排序兜底、打印导出、对话和下游传递。
- [x] Agent 导航元数据已切换到四个 React 路由；页面权限和旧入口回归测试已补充。
- [x] 新增小筛、小面、小评 selector 测试；TypeScript 检查通过；Vite 生产构建通过；前端原有测试保持通过。
- [ ] 小海对话式修改（预览→确认→取消→轮询）仍复用旧页面会话实现，待后续统一会话组件专项迁移。
- [ ] gstack Chromium 浏览器冒烟待补：本机控制器缺少 Bun，安装/构建需用户确认；当前已完成代码级测试和服务端入口回归。

## A. 根路径和认证

- [x] 未登录访问 `/` 会进入 `/login`。
- [x] 已登录且有 `pipeline:read` 权限访问 `/` 会进入 `/studio`。
- [x] 已登录但无目标权限访问 `/studio` 会进入 `/forbidden`，不会看到业务数据。
- [x] Cookie 过期后访问 `/studio` 会回到登录页。
- [x] 直接刷新 `/studio` 不出现 404 或白屏。
- [x] 旧版 `/frontend/studio.html` 在迁移期间仍可访问。
- [x] 关闭前端切换开关后，`/` 可恢复旧版 Studio。

## B. Studio 业务

- [x] Pipeline 列表加载、空状态、错误状态和重试正常。
- [x] 创建 Pipeline 成功后自动启动，列表自动失效并刷新；自动启动失败可重试。
- [x] 删除 Pipeline 有确认步骤，成功后列表刷新。
- [x] 批量操作不能重复提交，失败时显示明确反馈。
- [x] 配置面板已覆盖 Agent 启用、公司核心字段读写和本体规则只读查看；旧版 Logo/二维码/海报文件上传仍属于后续专项。
- [x] 刷新和返回不会丢失 URL 中的筛选、排序和分页。

## C. API 和状态

- [x] API 请求使用生成的类型，不在页面中重复声明响应结构。
- [x] 服务端数据由 TanStack Query 管理。
- [x] 当前未引入 Zustand；候选人、Pipeline 等服务端列表只由 TanStack Query 管理。
- [x] 401、403、422、500、超时和断网都有可见反馈。
- [x] mutation 只失效受影响的 query（Pipeline 操作失效 `pipelines`，配置操作失效对应配置 query）。
- [x] 不记录密码、Cookie、令牌和 API Key。

## D. 兼容性

- [x] 旧版导航到已迁移页面时能进入新路由或兼容跳转。
- [x] 旧版页面返回新 Studio 时保留查询参数上下文。
- [x] 外部邮件、书签和候选人链接不受影响。
- [x] `/api/*` 和 `/ws` 的同域访问行为不变。
- [x] Nginx/FastAPI 静态资源缓存策略已验证。

## E. 质量门槛

- [x] TypeScript 类型检查通过。
- [x] 生产构建通过。
- [x] 单元测试通过。
- [x] Playwright 核心路径通过。
- [ ] Chrome、Safari、Edge 目标版本通过。
- [x] Chromium 已验证桌面 1440px 与窄屏 390px，页面无横向溢出；Safari/Edge 仍待目标环境验收。
- [x] 发生故障时可在一次配置切换内回退旧版。

## F. 下线旧版前

- [ ] 旧版页面访问量已观察一个完整业务周期。
- [ ] 所有旧入口、书签、邮件和运维链接已盘点。
- [ ] 新版所有页面具备对应路由和权限测试。
- [ ] 已完成一次旧版回滚演练。
- [ ] 已确认删除旧版不会影响录制、多人面试、画布、静态资源和外部链接。
