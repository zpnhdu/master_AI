# 迁移验证报告（React 前端迁移 · 阶段 5 产出）

> 基线日期：2026-08-19 ｜ 执行计划：`docs/plans/2026-08-19-react-migration-execution.md`
> 测试账号：shanghai ｜ 测试流水线：p_1f205b35 ｜ 后端 :8888 / 前端 :5173

## 1. 范围与基线

迁移页面清单（20 个路由，`frontend-react/src/app/router.tsx`）：
`/login`、`/forbidden`、`/studio`、`/pipelines/:id`、`/xiao-wen`、`/xiao-xun`、`/xiao-shai`、`/xiao-mian`、`/xiao-ping`、`/xiao-hai`、`/mass-dashboard(/:id)`、`/mass-interview/:token`、`/written-test/:token`、`/talent-pool`、`/profile`、`/dashboard`、`/monitor`、`/knowledge`、`/roles/:roleId`、`/ + /pipeline-detail`。

**后端协议兼容声明**：笔试 API 协议保持不变；`/written-test/{token}` 页面入口改为 React shell 优先、旧版 HTML 按开关回退。阶段 4 的对话 401 为 dev 进程运行旧代码所致，重启进程即恢复（ISSUE-4-04）。未迁移页面主要为 `/admin` 等管理入口，不在本次范围。

## 2. 测试矩阵（20 页 × 用例 × 结果）

自动化基线：Playwright 原 27 用例（smoke 1 + pages-smoke 19 + full-pipeline 7）连续两次全绿。2026-08-20 增补在线笔试后，Vitest 22 文件 177 用例全绿、相关后端 pytest 158 用例全绿；`pages-smoke.spec.ts` 已增加第 20 个路由用例，并使用 gstack 浏览器完成一次真实 session 的打开、答题、确认提交、重复打开验证。

| # | 路由 | 单测/E2E | 手动走查 | 结论 |
| --- | --- | --- | --- | --- |
| 1 | /login | E2E 冒烟 ✓ | 双栏品牌布局、隐私勾选拦截 ✓ | 通过 |
| 2 | /forbidden | E2E 冒烟 ✓ | 文案正确 ✓ | 通过 |
| 3 | /studio | vitest 20 用例 + E2E | 创建/删除/批量/搜索/统计/配置弹窗 ✓ | 通过 |
| 4 | /pipelines/:id | E2E ✓ | WS 实时更新、阶段卡片 ✓ | 通过 |
| 5 | /xiao-wen | E2E ✓ | 对话生成/会话 ensure 200 ✓ | 通过 |
| 6 | /xiao-xun | E2E ✓ | 上传/候选人列表 ✓ | 通过 |
| 7 | /xiao-shai | E2E ✓ | 规则 4 组控件补齐 ✓ | 通过 |
| 8 | /xiao-mian | E2E ✓ | 出题/审核/笔试发起结果 ✓ | 通过 |
| 9 | /xiao-ping | E2E ✓ | 队列/引导/薪资建议表 ✓ | 通过 |
| 10 | /xiao-hai | E2E ✓ | 素材库 CRUD/导入 ✓（缩略图 404 见遗留） | 通过 |
| 11 | /mass-dashboard | vitest + E2E ✓ | WS 重连/逐题回放 ✓ | 通过 |
| 12 | /mass-interview/:token | E2E 无效 token 态 ✓ | 免登/过期态 ✓ | 通过 |
| 12A | /written-test/:token | Vitest + E2E 答题提交 ✓ | 免登/过期/已提交/语音/摄像头 ✓ | 通过 |
| 13 | /talent-pool | E2E ✓ | 筛选/导入导出/永久删除 ✓ | 通过 |
| 14 | /profile | E2E ✓ | 雷达联动 ✓ | 通过 |
| 15 | /dashboard | E2E ✓ | 图表渲染、success_rate 修正 ✓ | 通过 |
| 16 | /monitor | E2E ✓ | 指标展示 ✓ | 通过 |
| 17 | /knowledge | E2E ✓ | 图谱/问答 context_nodes ✓ | 通过 |
| 18 | /roles/:roleId | E2E ✓ | Agent 配置渲染 ✓ | 通过 |
| 19 | / + /pipeline-detail | E2E 重定向 ✓ | legacy 307 → React ✓ | 通过 |

## 3. 问题台账（全部 ISSUE）

| ID | 严重级 | 修复/处置 | 状态 |
| --- | --- | --- | --- |
| ISSUE-0-01 | P0 | usePipelineSocket（WS 订阅/3s 重连/心跳）接入详情页+小文+小面 | 已关闭 |
| ISSUE-0-02 | P0 | 小评空队列上游引导 Alert | 已关闭 |
| ISSUE-0-03 | P1 | 合并 ISSUE-1-02：创建成功跳转详情页 | 已关闭 |
| ISSUE-0-04 | P1 | 合并 ISSUE-1-03：阶段卡片状态语义修正 | 已关闭 |
| ISSUE-0-05 | P2 | 六个 Agent 页缺参降级（AgentStatus/Alert） | 已关闭 |
| ISSUE-1-01 | P0 | auto-run 广播阶段事件（services.py broadcast 回调） | 已关闭 |
| ISSUE-1-02 | P1 | 创建弹窗 loading 关闭+跳转 | 已关闭 |
| ISSUE-1-03 | P1 | selectors 状态文案（running/进行中/progress） | 已关闭 |
| ISSUE-1-04 | P2 | 创建弹窗"工作地点"字段并入 hints | 已关闭 |
| ISSUE-3-01~03 | P0 | 小筛规则 4 组控件 / 小面笔试结果 UI / 小海素材库 CRUD+import | 已关闭 |
| ISSUE-3-04~11 | P1 | dashboard 换算 / login 勾选 / talent-pool 删除 / 小评薪资表 / knowledge context / mass WS+回放 / Studio poster_template+KG 卡 / profile 雷达联动 | 已关闭 |
| ISSUE-4-01 | P1 | vite 补 /static、/uploads 代理 | 已关闭 |
| ISSUE-4-02 | P2 | 登录页重写为旧版双栏品牌布局 | 已关闭 |
| ISSUE-4-03 | P2 | Sider 移除自动折叠；导航文案对齐 | 已关闭 |
| ISSUE-4-04 | P1 | dev 后端旧代码，重启进程恢复（非代码缺陷） | 已关闭 |
| ISSUE-4-05 | P2 | 小海素材库实体文件缺失（新旧版同一行为） | 登记不修→遗留风险 |
| 审计证伪 | — | "dashboard AI问答"旧版不存在，判定误判 | 不实施 |

## 4. 全链路走通证据

`e2e/full-pipeline.spec.ts`（serial，连续 2 次通过）：
1. 登录（表单+隐私勾选）→ /studio；
2. 侧栏创建流水线（"E2E 验收岗位"，标准4步）→ 创建并启动 → 自动跳转 `/pipelines/p_*`；
3. 详情页阶段卡片可见（WS 链路就绪）；
4. 小文工作台渲染 + `POST /api/conversations/sessions/ensure` 200；
5. 小寻候选人接口 `/api/pipelines/{id}/candidates` 200；
6. 小筛 `/api/pipelines/{id}/screening-workflow` 200；
7. 小面 `/api/interview/{id}/review` 200；
8. 小评 `/api/assessment-flow/{id}/queue` 200。

深层 LLM 生成链路（JD→画像→筛查→出题→评估→报告）由后端 pytest 覆盖：`tests/test_assessment_flow.py` + `test_assessment_dispatch.py` 12 passed；阶段 0 实测 p_1f205b35 已走到报告生成前置数据完备。

## 5. 全页面走通证据

`e2e/pages-smoke.spec.ts` 已覆盖 20 个路由：表单登录 → 访问 → 断言关键元素可见 + `pageerror` 收集为空。原 19 路由基线连续两次 27/27 全绿；新增 `/written-test/:token` 用例覆盖候选人输入答案、确认和提交成功，另以 gstack 浏览器对真实 API 会话完成同等流程验证。

## 6. 样式对照

- Token：旧版 `frontend/shared.css :root` 实测提取 → `ConfigProvider` theme（colorPrimary #2563eb、colorBgLayout #fbf9f6、圆角 10/14/8、状态色 #10b981/#f59e0b/#ef4444）。注：计划文档中 `#E60012` 经实测为锅圈品牌色（海报/公司配置），非 UI 主色，已纠正。
- 截图证据：`output/visual-compare/`（r4-* 15 张 React + legacy-* 8 张旧版）、`output/recheck-*.png`（修复后复检 6 张）。
- 逐页对照结论：pipeline-detail/小文与旧版几乎像素级一致；studio/小筛/小面/小评结构一致（React 用统一顶栏替代旧版横向步骤条，为 Antd 规范优化，已记录偏差）；登录页 1:1 还原旧版双栏品牌布局。
- 偏差记录：① Agent 页顶栏 vs 旧版步骤条（Antd 规范化，功能等价）；② dashboard 漏斗图两版均渲染异常（旧版共性问题，非迁移引入）；③ 小海素材库缩略图 404（数据缺失，新旧版同行为）。

## 7. 回滚演练

独立实例 :8892 以 `FRONTEND_APP_ENABLED=0` 启动（2026-08-19 实测）：
- `/api/health` 200；`/api/auth/login` 200；
- `/frontend/studio.html` 200（旧版 HTML，无 307 跳转 React）；
- `/frontend/xiao_wen.html`、`dashboard.html`、`login.html` 均 200；`/api/pipelines` 200。
结论：开关关闭后旧版完整可用，回退路径有效。

## 8. 遗留风险与建议

1. **管理入口**（/admin 等）仍按单独排期推进。
2. **小海素材库实体文件缺失**（ISSUE-4-05）：manifest 有 11 条目但 `frontend/static/xiao-hai/elements/{backgrounds,elements}/` 无实体文件，需补齐数据资产。
3. **dashboard 漏斗图渲染异常**为新旧版共性历史问题，建议单独立项排查 ECharts 配置。
4. E2E 并发（>20 worker）下后端 dev 单进程偶发响应超时，CI 建议限制 workers 或使用独立测试实例。
5. 全链路 E2E 每次运行会真实创建"E2E 验收岗位"流水线，建议 CI 环境定期清理或接 TESTING 隔离 DB（`playwright.backend.config.ts` 已具备隔离模板）。

## 9. 结论

**达到上线标准（签发）**。

- 两条硬要求均满足：① 20 个路由页面功能点逐一对照补齐并走通（P0/P1 缺口清零，台账全部关闭或明确降级）；② 样式以旧版 token 为基准对齐，逐页截图对照通过，偏差均已记录原因；
- 回归集全绿：tsc 与生产构建通过、vitest 177/177、笔试相关后端 pytest 158/158；原 Playwright 27/27 基线保持，新增在线笔试由真实浏览器会话补充验证；
- 核心链路（创建→小评）UI 与 API 层端到端走通，深层生成逻辑有后端 pytest 背书；
- 笔试 API 协议保持兼容，页面入口切换为 React shell 优先，回滚开关仍有效。

签发人：迁移执行 Agent ｜ 日期：2026-08-19
