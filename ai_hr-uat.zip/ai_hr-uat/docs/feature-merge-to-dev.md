# Feature 安全合并到 dev 操作规范

## 一、核心原则

将 `feature/xxx` 合并到远端 `origin/dev` 时，必须保证：

- 合并前使用最新的 `dev`
- 不覆盖远端已有提交
- 冲突可追溯、可回滚
- 合并后经过测试再推送
- 不误提交其他成员的文件或环境密钥

禁止使用：

```bash
git add -A
git add .
git push --force
git reset --hard
```

## 二、合并前先同步 dev

先同步远端最新代码：

```bash
git fetch origin --prune
```

确认远端分支：

```bash
git rev-parse origin/dev
git rev-parse origin/feature/xxx
```

`git fetch origin` 只更新远端引用，不修改当前分支，最安全。

不要在 feature 分支直接执行 `git pull origin dev`，否则会把 `dev` 合进 feature。

如果只是更新本地 `dev` 分支，可以执行：

```bash
git switch dev
git pull --ff-only origin dev
```

## 三、创建 dev 保护分支

合并前保留一个回滚点：

```bash
git branch backup/dev-before-merge-20260819 origin/dev
```

如果合并结果有问题，可以回到这个保护分支。

## 四、创建隔离合并工作区

不要直接在成员当前工作区合并，建议创建临时 worktree：

```bash
git worktree add ../project-merge-dev \
  -b merge/feature-xxx origin/dev

cd ../project-merge-dev
```

这样可以保证：

- 原 feature 工作区不被改变
- `dev` 以最新远端版本为基线
- 合并过程独立、可检查

## 五、执行合并

先合并但暂不提交：

```bash
git merge --no-ff --no-commit origin/feature/xxx
```

参数说明：

- `--no-ff`：保留清晰的合并节点
- `--no-commit`：先检查代码，确认后再提交

检查状态：

```bash
git status
git diff --name-only --diff-filter=U
```

## 六、处理冲突

不要直接全部选择 `ours` 或 `theirs`，应逐文件按业务逻辑处理：

- `dev`：主干现有逻辑
- `feature`：本次功能逻辑
- 两边都需要时，手工合并保留有效逻辑

处理后精确暂存：

```bash
git add <已解决的具体文件>
git diff --cached --check
```

确认没有未解决冲突：

```bash
git diff --name-only --diff-filter=U
```

然后提交：

```bash
git commit -m "merge: 合并 feature 到 dev"
```

## 七、合并后验证

根据改动范围运行测试，例如：

```bash
python -m pytest <相关后端测试> -q
pnpm run typecheck
pnpm run build
```

前后端都有改动时，两边都要验证。

## 八、推送前再次同步 dev

合并和测试期间，其他成员可能再次更新 `dev`，因此推送前必须再同步一次：

```bash
git fetch origin dev
git merge --no-ff origin/dev
```

如果出现新冲突，重新解决并测试。

## 九、安全推送到 dev

使用普通 push：

```bash
git push origin HEAD:dev
```

不要使用 force push。

普通 push 可以防止覆盖远端：

- 远端 `dev` 没变化：推送成功
- 远端 `dev` 已被更新：push 被拒绝
- 被拒绝后重新 fetch、合并、解决冲突即可

## 十、验证远端结果

```bash
git ls-remote --heads origin dev
git log --oneline --decorate -3
```

确认远端 `dev` 已指向新的合并提交。

## 十一、清理临时工作区

确认合并和推送完成后：

```bash
git worktree remove ../project-merge-dev
```

保护分支建议暂时保留，确认线上稳定后再删除。

## 本次实际示例

- feature：`feature/zhoulin-chonggou-0819`
- 保护分支：`backup/dev-before-feature-20260819`
- 合并提交：`ede3749`
- 合并过程：无冲突
- 后端测试：27 项通过
- 前端类型检查：通过
- 推送方式：普通 push，未覆盖远端历史
