# xiao_ping 阶段产出、数据看板与中间会话完整代码修改方案

## 1. 文档信息

- 页面：`frontend/xiao_ping.html`
- 关联前端公共模块：`frontend/shared.js`
- 关联后端模块：`app/action_handler.py`、`app/assessment_flow.py`、`hr_harness/agents/report_agent.py`
- 目标：优化阶段产出、数据看板和中间会话，使页面围绕“录用决策”工作，而不是只展示统计数字
- 本文性质：开发实施方案，不包含本次代码修改

## 2. 目标与非目标

### 2.1 目标

1. 阶段产出能够回答“当前进行到哪一步、产出了什么、下一步做什么”。
2. 数据看板只展示真实数据，明确区分“真实值、计算值、暂无数据”，禁止用默认比例伪造业务结果。
3. 中间会话定位为“录用决策助手”，承担解释、比较、复核和行动引导。
4. 报告生成过程有明确的准备中、生成中、成功、失败和可重试状态。
5. 阶段产出、看板和会话共用同一份候选人评估数据，避免三个区域数字不一致。
6. 保持现有接口兼容，优先在现有页面和接口上做最小改动。

### 2.2 非目标

- 本期不重做整套视觉设计系统。
- 本期不引入新的图表库。
- 本期不改变候选人评分规则和录用阈值。
- 本期不增加新的模型供应商。
- 本期不把同步报告生成强行改造成完整异步任务系统；只保留后续异步化的接口边界。

## 3. 当前问题

### 3.1 阶段产出问题

- 阶段状态、产出内容和下一步动作没有形成闭环。
- 评估报告生成卡片同时承担计划概览、异常提示和操作入口，信息密度过高。
- `needs_review`、`incomplete` 和已经可以决策的候选人没有被清晰分层。
- 生成失败时存在前端 fallback 展示，可能把失败伪装成成功结果；当前 `generateReport` 中还存在重复调用 `showReportCard(fallback)` 的问题。

### 3.2 数据看板问题

- 漏斗数据存在 `0.6`、`0.8`、`0.3` 等默认比例回退，会产生看似完整但并不真实的招聘结果。
- KPI 与排序、漏斗的数据源不完全一致。
- 推荐、考虑、不推荐的划分逻辑散落在渲染层，后续容易与后端规则不一致。
- 缺少数据更新时间、数据覆盖范围和数据质量提示。
- 没有把“待人工复核”和“资料不完整”作为一等指标展示。

### 3.3 中间会话问题

- 中间区域仍然偏“普通聊天框”，没有体现它是决策工作台的操作入口。
- 用户需要自己组织问题，才能获得候选人解释、横向比较或下一步建议。
- 报告生成、导出和流转操作与会话内容的关系不够清晰。
- 失败后没有明确告诉用户是“数据未准备好、模型失败、网络失败”还是“可以重试”。
- 会话回复没有统一的结构化卡片，难以与右侧看板联动。

## 4. 目标页面结构

```text
┌──────────────────────────────────────────────────────────────┐
│ 页面标题 + JD/批次信息 + 数据更新时间 + 当前阶段状态        │
├───────────────┬───────────────────────────────┬──────────────┤
│ 阶段产出       │ 录用决策助手                  │ 数据看板     │
│               │                               │              │
│ 1. 已完成产出  │ 上下文条                       │ KPI          │
│ 2. 进行中      │ 阶段摘要卡                     │ 候选人分布   │
│ 3. 待处理事项  │ 快捷问题                       │ 待办/告警    │
│ 4. 下一步动作  │ 会话消息 + 结构化决策卡         │ 排名         │
│               │ 输入框 + 操作按钮               │ 漏斗         │
└───────────────┴───────────────────────────────┴──────────────┘
```

### 4.1 左侧：阶段产出

按“状态 → 产出 → 行动”展示，而不是只展示阶段名称。

每个阶段卡片包含：

- 阶段名称：简历筛选、人才匹配、面试评估、录用决策等
- 状态：未开始、进行中、已完成、存在异常
- 产出摘要：例如“已评估 12 人，其中 8 人可进入决策”
- 时间：最近更新时间
- 数据质量：完整、部分缺失、需要人工复核
- 主操作：查看、继续处理、重新生成、重试
- 依赖提示：如“需先完成 3 位候选人的面试记录”

阶段产出建议分成四组：

1. 已完成：可直接查看，不抢占主视觉。
2. 进行中：显示进度和当前动作。
3. 待处理：优先展示人工复核和资料补齐。
4. 下一步：明确页面当前最推荐的动作。

### 4.2 中间：录用决策助手

中间会话不负责重复展示整张看板，重点负责解释和决策动作。

首屏固定显示：

- 当前 JD/招聘批次
- 当前候选人范围
- 评估数据更新时间
- 可决策人数、待复核人数、资料不完整人数
- 当前推荐动作，例如“先处理 2 位待复核候选人，再生成报告”

首屏快捷操作：

- `哪些人可以直接进入录用决策？`
- `为什么推荐这几个人？`
- `帮我比较前 3 名候选人`
- `哪些候选人需要人工复核？`
- `生成录用评估报告`

### 4.3 右侧：数据看板

右侧只保留支持决策的指标：

- 评估总人数
- 可决策人数
- 待人工复核人数
- 资料不完整人数
- 推荐/考虑/不推荐分布
- 候选人排名
- 关键告警和下一步动作

漏斗只允许使用后端真实计数。没有真实数据时显示“暂无数据”，不能用固定比例补齐。

## 5. 前端修改方案：`frontend/xiao_ping.html`

### 5.1 新增统一页面状态

在现有页面状态基础上增加以下字段，避免阶段产出、会话和看板各自维护一套状态：

```js
const decisionState = {
  pipelineId: null,
  pipelineData: null,
  assessmentQueue: null,
  report: null,
  reportStatus: 'idle',
  activeCandidateId: null,
  conversationMode: 'decision',
  lastUpdatedAt: null,
  error: null,
};
```

字段约束：

- `assessmentQueue` 只能来自 `/api/assessment-flow/{pipeline_id}/queue`。
- `report` 只能来自报告接口或 `/api/action` 的成功响应。
- `reportStatus` 只能使用 `idle`、`ready`、`generating`、`completed`、`failed`。
- 页面渲染函数不直接推断业务数量，只消费统一后的数据模型。

### 5.2 增加数据归一化函数

新增 `normalizeDecisionQueue(queue)`，统一处理后端字段，至少输出：

```js
{
  total: 0,
  ready: [],
  needsReview: [],
  incomplete: [],
  counts: {
    total: 0,
    ready: 0,
    needsReview: 0,
    incomplete: 0,
  },
  updatedAt: null,
  dataQuality: 'unknown',
}
```

规则：

- 优先使用后端 `counts`。
- 后端缺少 `counts` 时才根据数组长度计算。
- 不把缺失字段默认为 1。
- 不把空数组推断成存在候选人。
- 对非数组字段安全降级为空数组，并记录 `dataQuality = 'partial'`。

新增 `normalizeReportData(payload)`，兼容当前 ReportAgent 的 `ranking` 结构和历史的 `recommend/consider/reject` 结构，但页面内部统一为：

```js
{
  summary: '',
  ranking: [],
  decisionSummary: {},
  nextSteps: [],
  riskAssessment: [],
  dataQuality: {},
  generatedAt: null,
}
```

### 5.3 重做阶段产出渲染

将当前 `showGenerateCard()` 拆为以下职责明确的函数：

- `renderStageOutputs()`：渲染四组阶段产出。
- `renderReportPreparationCard()`：渲染报告准备情况。
- `renderReviewQueueCard()`：渲染待复核候选人。
- `renderIncompleteCard()`：渲染资料不完整候选人。
- `renderNextActionCard()`：渲染当前推荐动作。

报告准备卡片的状态：

| 状态 | 文案 | 操作 |
|---|---|---|
| `ready` | 已有 N 人可以生成报告 | 生成报告 |
| `needs_review` | 有 N 人需要人工复核 | 查看待复核 |
| `incomplete` | 有 N 人资料不完整 | 查看缺失项 |
| `empty` | 暂无可用于决策的候选人 | 返回上一阶段 |
| `generating` | 报告生成中 | 禁用重复生成 |
| `completed` | 报告已生成 | 查看报告/导出 |
| `failed` | 报告生成失败 | 重试/查看错误 |

禁止在失败状态自动展示 fallback 报告。若确实需要示例数据，必须明确标记为“示例”，不能放进真实报告区域。

### 5.4 重做中间会话

新增以下组件函数：

- `renderConversationContext()`：显示当前范围、统计和更新时间。
- `renderConversationWelcome()`：显示阶段摘要和快捷问题。
- `renderConversationCard(card)`：统一渲染决策摘要、候选人解释、比较表、复核队列、报告状态、错误提示和下一步动作。
- `renderQuickActions()`：根据当前状态生成快捷操作。
- `setConversationMode(mode)`：预留 `decision`、`candidate`、`report` 三种模式。

结构化卡片类型：

```js
{
  type: 'decision_summary',
  title: '当前决策概览',
  data: {},
  actions: [],
}
```

首期支持：

- `decision_summary`：推荐、待复核、资料不完整的数量与结论。
- `candidate_explanation`：单个候选人的评分依据、优势、风险和证据。
- `candidate_compare`：最多 5 名候选人的横向比较。
- `review_queue`：待人工复核列表及进入复核操作。
- `report_progress`：报告生成阶段、耗时和当前状态。
- `report_result`：报告摘要、排名和后续动作。
- `error_retry`：错误原因、影响范围和重试按钮。
- `next_actions`：明确的下一步动作列表。

消息气泡只展示自然语言摘要；可操作内容必须进入结构化卡片，避免用户在长文本中寻找按钮。

### 5.5 调整 `sendChat()` 意图路由

保留现有接口调用方式，但先在前端将意图归一化：

```js
const intent = {
  type: 'compare_candidates',
  candidateIds: [],
  query: userMessage,
};
```

首期意图：

- `decision_summary`
- `explain_candidate`
- `compare_candidates`
- `review_queue`
- `generate_report`
- `export_report`
- `pass_downstream`

路由要求：

- 有明确候选人时带上 `candidate_id` 或 `candidate_ids`。
- 询问看板统计时直接使用 `decisionState.assessmentQueue`，不重复请求或自行估算。
- 报告生成时先检查 `ready` 数量，数量为 0 时不调用模型。
- 生成中禁止重复提交，按钮和快捷操作同步禁用。
- 请求失败必须渲染 `error_retry` 卡片，不生成虚假报告。

### 5.6 修复报告生成前端流程

现有 `generateReport()` 修改为以下流程：

```text
检查状态
  ├─ 无可决策候选人 → 展示原因和下一步
  ├─ 正在生成 → 忽略重复请求
  └─ 可以生成 → 设置 generating
                   ↓
                调用接口
                   ↓
        成功 → 保存 report → completed
        失败 → 保存 error → failed + 重试
```

必须删除：

- 失败时自动调用 `generateFallbackReport()` 作为真实结果展示。
- 重复调用 `showReportCard(fallback)`。

成功后：

1. 更新 `decisionState.report`。
2. 更新阶段产出卡片为 `completed`。
3. 在中间会话插入 `report_result` 卡片。
4. 刷新右侧排名和分布。
5. 保留“导出报告”和“进入下一阶段”操作。

失败后：

1. 保留原有看板和候选人数据。
2. 展示错误类别和可执行的重试按钮。
3. 不清空已有历史报告。
4. 记录 `request_id` 或错误标识，便于日志排查。

## 6. 公共看板修改方案：`frontend/shared.js`

### 6.1 扩展看板配置类型

在现有 `kpis`、`rank`、`hbars`、`funnel` 之外增加：

- `distribution`：推荐/考虑/不推荐分布。
- `alerts`：待复核、资料缺失、数据异常。
- `actions`：看板上的快捷动作。
- `metric`：单指标及数据质量状态。
- `empty`：无数据时的统一空状态。

### 6.2 看板数据规则

统一规定：

- 真实数量为 `0` 时展示 `0`，不展示 `—`。
- 没有数据来源时展示“暂无数据”。
- 估算数据必须显式标记“估算”，首期禁止在招聘漏斗中使用估算。
- 每个图表显示数据来源范围和更新时间。
- 组件不得自行计算录用阈值；阈值来自后端返回的决策分类。

### 6.3 漏斗修改

删除以下回退逻辑：

- `Math.round(resumeCount * 0.6)`
- `Math.round(passCount * 0.8)`
- `Math.round(passCount * 0.3)`
- `|| 1`

漏斗只接收后端明确字段，例如：

```js
{
  stages: [
    { key: 'resume', label: '简历', count: 120, source: 'crawl' },
    { key: 'match', label: '匹配通过', count: 36, source: 'match' },
    { key: 'interview', label: '完成面试', count: 18, source: 'interview' },
    { key: 'decision', label: '进入决策', count: 8, source: 'assessment' },
  ],
  dataQuality: 'complete',
  updatedAt: '2026-08-11T10:00:00Z',
}
```

缺少中间阶段时：

- 不补比例。
- 标记缺失阶段。
- 在图表底部展示“当前漏斗数据不完整”。

## 7. 后端数据契约修改方案

### 7.1 `app/assessment_flow.py`

保持现有队列接口路径，补充稳定的 `counts`、`updated_at` 和 `data_quality`：

```json
{
  "plan": {},
  "ready_for_decision": [],
  "needs_review": [],
  "incomplete": [],
  "closed_incomplete": [],
  "counts": {
    "total": 0,
    "ready": 0,
    "needs_review": 0,
    "incomplete": 0
  },
  "updated_at": "2026-08-11T10:00:00Z",
  "data_quality": {
    "status": "complete",
    "missing_fields": [],
    "warnings": []
  }
}
```

要求：

- `total` 由实际队列总量计算。
- `ready`、`needs_review`、`incomplete` 互斥计数，必要时明确去重规则。
- 不用评分比例推算数量。
- 数据为空时返回稳定空结构，不返回 `null` 让前端猜测。

### 7.2 `app/action_handler.py`

报告生成处理需要统一返回成功和失败结构：

成功：

```json
{
  "success": true,
  "action": "generate_report",
  "status": "completed",
  "report": {},
  "request_id": "...",
  "generated_at": "..."
}
```

失败：

```json
{
  "success": false,
  "action": "generate_report",
  "status": "failed",
  "error": {
    "code": "REPORT_GENERATION_FAILED",
    "message": "报告生成失败，请稍后重试",
    "retryable": true
  },
  "request_id": "..."
}
```

错误信息对用户使用可读文案，详细异常只写服务端日志，不能把堆栈直接返回前端。

报告生成前继续使用 `build_report_inputs()`，并明确校验：

- 是否存在可决策候选人。
- 是否存在必要的评估包。
- 是否存在当前 JD 快照。
- 是否已有同一版本的生成任务。

### 7.3 `hr_harness/agents/report_agent.py`

报告输出增加元数据和数据质量信息，同时保持现有字段兼容：

```json
{
  "report_version": 1,
  "generated_at": "...",
  "source_snapshot": {
    "pipeline_id": "...",
    "candidate_count": 8,
    "assessment_count": 8,
    "interview_count": 7
  },
  "decision_summary": {
    "recommend": 2,
    "consider": 4,
    "reject": 2,
    "confidence": "medium"
  },
  "ranking": [],
  "next_steps": [],
  "risk_assessment": [],
  "data_quality": {
    "status": "partial",
    "warnings": ["候选人 C001 缺少完整面试记录"]
  }
}
```

排名项增加：

- `confidence`
- `evidence`
- `data_quality`
- `next_action`

模型提示词要求：

- 结论必须基于输入证据。
- 缺少证据时输出“信息不足”，不能自行补全。
- 推荐理由和风险必须能回溯到候选人资料、评估包或面试记录。
- 只对本次输入范围内的候选人排名。

当前 `candidates[:10]` 的范围限制需要与后续补全逻辑统一，避免摘要只看前 10 人但排名包含更多人的不一致。首期选择一种明确策略：

- 页面只支持最多 10 人：后端在输入阶段明确截断并返回范围提示；或
- 页面支持完整批次：移除无意的前 10 人限制，并增加分页/异步生成。

建议首期采用第一种，减少接口和性能风险。

## 8. 评分与推荐分类

推荐分类必须由后端统一输出，前端只负责展示。

建议统一字段：

```json
{
  "recommendation": "recommend",
  "recommendation_label": "推荐",
  "final_score": 86,
  "score_band": "high",
  "confidence": "high"
}
```

兼容历史值：

- `strong_recommend` → `recommend`
- `recommended` → `recommend`
- `consider` → `consider`
- `reject` → `reject`

兼容映射集中放在一个归一化函数中，不要继续散落在 `showReportCard()` 的多个分支里。

## 9. 交互状态与错误处理

### 9.1 报告状态机

```text
idle
 ├─ 有可决策数据 → ready
 └─ 无可决策数据 → idle + empty

ready → generating → completed
                  └→ failed → retry → generating
```

### 9.2 错误分类

| 错误类别 | 用户提示 | 是否允许重试 |
|---|---|---|
| 数据未准备好 | 请先完成面试评估或补齐资料 | 否，先处理数据 |
| 请求超时 | 报告生成时间较长，可稍后重试 | 是 |
| 模型调用失败 | 评估服务暂时不可用 | 是 |
| 服务端 500 | 报告生成失败，已保留当前数据 | 是 |
| 权限/版本冲突 | 当前页面数据已过期，请刷新 | 刷新后重试 |

### 9.3 防重复提交

- 生成按钮在 `generating` 状态禁用。
- 快捷问题“生成报告”同步禁用。
- 请求完成后恢复按钮状态。
- 页面刷新后根据服务端报告状态恢复，而不是仅依赖内存状态。

## 10. 测试修改方案

### 10.1 前端单元/静态检查

覆盖：

1. 队列为空时所有计数为 0，不出现默认 1。
2. 队列字段缺失时安全降级并标记 `partial`。
3. `ready/needs_review/incomplete` 数量与后端计数一致。
4. 历史报告结构能归一化为统一 `ranking`。
5. 报告生成失败时不展示 fallback 真实报告。
6. 报告生成按钮不会重复提交。
7. 错误卡片包含重试动作。
8. 漏斗缺失阶段时展示暂无数据或数据不完整提示。

### 10.2 后端测试

覆盖：

1. 空评估队列返回稳定空结构。
2. 队列计数与候选人分类互斥且一致。
3. 报告生成前无 ready 候选人时不调用模型。
4. 报告成功响应包含 `status`、`request_id`、`generated_at`。
5. 模型异常返回可重试错误，不泄露堆栈。
6. ReportAgent 输出只包含输入范围内候选人。
7. 缺少面试资料时输出数据质量警告。
8. 历史报告字段仍可被前端读取。

### 10.3 手工验收场景

| 场景 | 预期 |
|---|---|
| 0 位候选人 | 阶段产出提示返回上一阶段，看板显示暂无数据 |
| 只有资料不完整候选人 | 不允许生成报告，给出补齐资料动作 |
| 有待复核候选人 | 优先展示人工复核，不阻塞查看已有完整候选人 |
| 8 位可决策候选人 | 可生成报告，三栏数量一致 |
| 报告接口 500 | 展示失败卡片，可重试，不出现虚假报告 |
| 连续点击生成 | 只发出一个请求 |
| 刷新页面 | 阶段、看板、报告状态从服务端恢复 |
| 历史报告 | 仍能查看排名、薪资策略和下一步 |

## 11. 实施顺序

### 第 1 步：统一数据模型

修改 `assessment_flow` 返回稳定队列结构，前端新增归一化函数。

验证条件：页面三栏能使用同一组计数，空数据不出现伪造数字。

### 第 2 步：修复报告生成状态

修改 `xiao_ping.html` 和 `action_handler.py` 的成功/失败响应处理，删除失败 fallback 展示和重复渲染。

验证条件：接口失败时只出现错误卡片，成功时才出现报告卡片。

### 第 3 步：重做阶段产出

拆分阶段卡片和报告准备卡片，加入待复核、资料不完整和下一步动作。

验证条件：用户无需进入会话即可知道当前阻塞点和下一步。

### 第 4 步：重做中间会话

加入上下文条、欢迎摘要、快捷问题和结构化决策卡。

验证条件：候选人解释、横向比较、待复核和报告进度都能以卡片形式展示。

### 第 5 步：重做看板

扩展 `shared.js`，移除默认比例和 `|| 1` 回退。

验证条件：看板所有数字都有真实来源、更新时间和数据质量提示。

### 第 6 步：补 ReportAgent 元数据

增加报告版本、来源快照、结论置信度、证据和数据质量字段。

验证条件：报告结论可追溯，缺失信息不被模型静默补齐。

### 第 7 步：回归验证

执行前端格式化/语法检查、后端受影响测试和手工验收场景。

验证条件：受影响测试通过；无关历史失败单独记录，不混入本次改动结论。

## 12. 风险与控制措施

### 风险 1：前后端字段不一致

控制：先定义归一化函数和稳定响应结构，保留历史字段兼容映射。

### 风险 2：报告生成仍然是同步请求，页面感觉卡顿

控制：首期提供明确 `generating` 状态和超时提示；后续可将 `request_id` 扩展为任务查询接口。

### 风险 3：删除 fallback 后用户看到空白

控制：用明确的失败卡片和重试动作替代虚假报告；保留已有历史报告。

### 风险 4：报告范围超过前端可承载人数

控制：首期限制单次报告最多 10 人，并在页面显示范围；后续再做分页或异步报告。

### 风险 5：推荐阈值前后端再次漂移

控制：分类由后端输出，前端只做展示和历史值兼容，不在渲染层重新计算。

### 风险 6：三个区域出现数量不一致

控制：页面只保留一份 `decisionState.assessmentQueue`，阶段、会话、看板均由该状态渲染。

## 13. 完成标准

- [ ] `xiao_ping.html` 的阶段产出按“已完成/进行中/待处理/下一步”组织。
- [ ] 中间会话具备上下文、快捷问题和结构化决策卡。
- [ ] 右侧看板不再使用固定比例或 `|| 1` 伪造数据。
- [ ] 三栏使用同一份队列和报告数据。
- [ ] 报告失败不再展示虚假 fallback 结果。
- [ ] 报告生成具备防重复提交、失败提示和重试能力。
- [ ] 报告包含来源快照、数据质量和结论置信度。
- [ ] 历史报告结构仍可正常展示。
- [ ] 受影响测试和页面手工场景验证通过。

## 14. 建议的首期范围

首期优先交付以下四项，能最快改善用户体验并降低数据误导风险：

1. 删除看板中的默认比例回退。
2. 修复报告生成失败时的 fallback 和重复展示。
3. 阶段产出增加待复核、资料不完整和下一步动作。
4. 中间会话增加决策摘要、快捷问题和错误重试卡片。

ReportAgent 的详细证据链和异步任务化可以作为第二阶段，在首期稳定数据契约后继续推进。
