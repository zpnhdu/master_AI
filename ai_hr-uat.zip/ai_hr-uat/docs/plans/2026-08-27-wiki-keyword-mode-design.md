# 知识库关键词模式设计

## 目标

在当前知识库规模下，保持向量后端关闭，让上传、页面浏览、知识库问答和小文 Agent 都稳定使用 Wiki Markdown 的关键词召回；未来需要语义召回时，可以通过配置开关启用，而不改变业务调用方。

## 架构概览

- OSS 保存原始资料与 Wiki Markdown 页面，MySQL 保存页面索引、来源和状态。
- `WikiKnowledgeBase` 作为小文 Agent 的同步检索入口，当前使用标题、标签和正文 token 重叠召回。
- `app.wiki_query.retrieve` 作为知识库问答入口；向量关闭时只执行 token 召回，向量开启时保留现有向量 + token 评分逻辑。
- 通过 `WIKI_VECTOR_ENABLED` 显式控制 Wiki 查询是否调用 embedding。默认关闭，即使未来配置了 embedding API 也不会隐式产生网络调用。

## 数据流

1. 上传 PDF/DOCX 到 OSS 原始资料区。
2. 摄取流程生成带类型和来源的 Markdown 页面，并写入 OSS；MySQL 更新页面索引。
3. JD、画像、小文对话和知识库问答读取同一批 Wiki 页面。
4. 关键词模式下只根据标题、标签和正文 token 计算召回分；无命中时返回空上下文并保持原流程可用。

## 边界与错误处理

- `VECTOR_BACKEND=none` 继续表示没有 Elasticsearch/OpenSearch 向量存储。
- `WIKI_VECTOR_ENABLED=false` 额外保证不会调用 embedding API。
- embedding 服务不可用时，向量模式仍降级到 token 召回。
- 不把候选人、岗位流水线和个人记忆写入知识库；这些继续由业务数据库和 `MemorySystem` 管理。

## 验证策略

- 测试关闭开关时不会调用 embedding，且仍能召回 Wiki 页面。
- 测试开启开关时保留现有向量召回路径。
- 回归 Wiki、KB、摄取恢复、MySQL 兼容和知识库引导测试。
