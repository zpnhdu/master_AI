# 小海海报工作台 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 将小海页面改为三栏工作台，让当前海报始终可见；左侧管理版本、画幅和素材，右侧直接提交修改给模型。

**Architecture:** 保留现有 React Query 数据流和小海 API，仅重组 `XiaoHaiPage` 的页面结构。复用 `ConversationPanel` 的完整会话能力，将版本、画幅和素材固定在左侧，右侧输入直接触发小海的生图任务，不展示修改预览卡片或快捷指令，并通过页面局部 CSS 实现三栏布局。

**Tech Stack:** React 19、TypeScript、Ant Design、TanStack Query、Vitest、Testing Library。

---

### Task 1: 锁定海报优先交互

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoHaiPage.test.tsx`

**Step 1: Write the failing tests**

新增测试，验证：

- 海报工作台和左侧配置可见，不再存在“当前海报 / 版本”标签页。
- 文案不再单独维护编辑抽屉，输入自然语言即可直接修改并生成。
- 点击版本缩略图后调用选择接口并在中间预览区域显示新版本。

**Step 2: Run test — confirm it fails**

Command: `pnpm test:run src/app/pages/XiaoHaiPage.test.tsx`

Expected: FAIL，因为当前页面仍为三栏 chat-first 布局和互斥 Tabs。

### Task 2: 重组页面组件

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoHaiPage.tsx`

**Step 1: Write minimal implementation**

- 删除 `rightTab` 状态和 `Tabs`。
- 将左侧版本记录、画幅选择、素材库，中间当前海报和右侧 `ConversationPanel` 组合进主工作台。
- 生成入口统一为视觉生成，不再区分“修改文案并生成”和“适配当前画幅”；右侧输入直接入队。
- 将“传递给下游”移动到当前海报工具栏，避免全局顶栏重复操作。

**Step 2: Run target tests — confirm they pass**

Command: `pnpm test:run src/app/pages/XiaoHaiPage.test.tsx`

Expected: PASS。

### Task 3: 完成工作台视觉布局

**Files:**
- Modify: `frontend-react/src/styles.css`

**Step 1: Write minimal styles**

- 三列布局：左侧配置、中间海报预览、右侧对话。
- 吸顶且可换行的海报操作栏。
- 左侧完整版本缩略图、画幅和素材摘要。
- 右侧完整对话区，不展示临时参考图、命令预览卡片和快捷指令。
- 桌面、平板和手机断点。

**Step 2: Verify tests and static checks**

Commands:

- `pnpm test:run src/app/pages/XiaoHaiPage.test.tsx`
- `pnpm typecheck`
- `pnpm build`

Expected: 全部通过。

### Task 4: Review

检查最终 diff 仅包含设计文档、小海页面、对应测试和局部样式；确认无旧版迁移代码、无新的 API 或依赖。
