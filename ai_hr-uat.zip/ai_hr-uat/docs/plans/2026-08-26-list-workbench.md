# 列表工作台实施计划

> **For implementer:** 先写失败测试，再写最小实现；不要修改 MassInterview 相关文件。

**Goal:** 在现有 DataTable 之上统一前端列表的搜索、筛选、新增入口、批量操作和行内操作体验。

**Architecture:** 新增 `frontend-react/src/shared/list-workbench/` 公共薄封装。`ListToolbar` 负责布局，`ListSearch`/`ListFilterSelect` 负责控件行为，`SelectionActionBar` 负责选择反馈；业务页面继续持有查询状态、API、权限和表单。

**Tech Stack:** React 19、TypeScript 7、Ant Design 6、Vitest 4、现有 CSS token。

---

## Task 1: 公共列表工作台控件

**Files:**

- Create: `frontend-react/src/shared/list-workbench/ListSearch.tsx`
- Create: `frontend-react/src/shared/list-workbench/ListFilterSelect.tsx`
- Create: `frontend-react/src/shared/list-workbench/ListToolbar.tsx`
- Create: `frontend-react/src/shared/list-workbench/SelectionActionBar.tsx`
- Create: `frontend-react/src/shared/list-workbench/index.ts`
- Create: `frontend-react/src/shared/list-workbench/list-workbench.test.tsx`
- Modify: `frontend-react/src/styles.css`

**Behavior:**

- 搜索控件保持输入即时显示，查询回调默认 300ms 防抖。
- 回车和清空立即触发回调。
- 工具栏提供 `search`、`filters`、`actions` 插槽，不持有业务数据。
- 选择栏显示已选数量并支持清空。
- 公共组件不调用 API，不创建业务 Modal。

**Verify:**

- 定向 Vitest 覆盖搜索防抖、回车、清空、筛选和选择数量。
- TypeScript 检查通过。

## Task 2: 迁移主列表工具栏

**Files:**

- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify: `frontend-react/src/app/pages/AdminPage.tsx`
- Modify: `frontend-react/src/app/pages/DashboardPage.tsx`
- Modify: `frontend-react/src/app/pages/MonitorPage.tsx`
- Modify: `frontend-react/src/app/pages/StudioPage.tsx`

**Behavior:**

- 将搜索、筛选和主操作放到 `ListToolbar`。
- Admin 增加用户列表搜索，并保留角色列表业务筛选空间。
- Dashboard、Monitor、TalentPool 使用相同搜索触发规则。
- Studio 保留 URL 查询状态，但替换自定义搜索控件为共享搜索控件。

**Verify:**

- 页面级测试覆盖搜索清空、页码重置和主操作可见性。
- 保留当前业务查询和权限行为。

## Task 3: 统一新增与行操作反馈

**Files:**

- Modify: `frontend-react/src/app/pages/AdminPage.tsx`
- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify: `frontend-react/src/features/xiao-xun/components/TalentPoolImportCard.tsx`

**Behavior:**

- mutation 成功后再关闭新增/编辑表单，失败时保留输入。
- 邮箱账户超过两个的操作收进更多菜单。
- 行操作保持权限禁用状态，并提供原因提示。
- 批量操作统一使用 `SelectionActionBar`。

**Verify:**

- mutation 失败时表单仍打开。
- 行内菜单、危险操作确认和批量数量文案测试通过。

## Task 4: 状态、样式和回归验证

**Files:**

- Modify: `frontend-react/src/styles.css`
- Modify or create affected tests only.

**Behavior:**

- 工具栏桌面端对齐、移动端换行、筛选标签和空状态 CTA 统一。
- 不引入新的第三方依赖，不修改 MassInterview 文件。

**Verify:**

- `pnpm typecheck`
- 公共组件和受影响页面定向测试
- `git diff --name-only` 确认不包含 `MassInterview`。
