# Agent 交接顶栏 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 让六个角色页使用极简公共顶栏，主按钮统一完成数据交接并进入下游页面。

**Architecture:** 复用现有 `AgentTopbar`，不新增常驻“更多”菜单。每个页面保留自己的 mutation 和前置条件，在传递成功回调中使用后端返回的 `to_agent` 导航；小评成功后回到流水线详情。小文保留业务适配，但顶栏只承担交接。

**Tech Stack:** React 19、TypeScript、React Router、Ant Design、TanStack Query、Vitest Testing Library。

---

### Task 1: 锁定公共顶栏契约

**Files:**
- Modify: `frontend-react/src/app/components/AgentTopbar.tsx`
- Create: `frontend-react/src/app/components/AgentTopbar.test.tsx`

**Step 1: Write the failing test**

覆盖仅渲染主按钮、loading 文案和禁用状态；确认未传 `secondaryActions` 时没有多余操作。

**Step 2: Run test — confirm it fails**

Command: `pnpm --dir frontend-react vitest run src/app/components/AgentTopbar.test.tsx`

Expected: FAIL because the test file and shared component behavior are not yet covered.

**Step 3: Write minimal implementation**

保持现有 `primaryAction`/`secondaryActions` API，仅补齐可测试的语义属性和必要的 `aria`/title 行为；不添加未使用的菜单协议。

**Step 4: Run test — confirm it passes**

Command: `pnpm --dir frontend-react vitest run src/app/components/AgentTopbar.test.tsx`

Expected: PASS.

### Task 2: 统一小文顶栏并迁移复制入口

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoWenPage.tsx`
- Modify: `frontend-react/src/features/xiao-wen/components/DocumentPane.tsx`
- Modify: `frontend-react/src/features/xiao-wen/xiao-wen.css`
- Modify: `frontend-react/src/features/xiao-wen/components/XiaoWenTopbar.tsx`
- Modify: `frontend-react/src/features/xiao-wen/components/XiaoWenTopbar.test.tsx`

**Step 1: Write the failing test**

调整小文页面测试，要求顶栏主按钮为“传递给下游”，复制 JD 出现在文档工具栏；传递成功后按接口返回的 `to_agent` 进入下游。

**Step 2: Run test — confirm it fails**

Command: `pnpm --dir frontend-react vitest run src/features/xiao-wen/components/XiaoWenTopbar.test.tsx src/app/pages/XiaoWenPage.test.tsx`

Expected: FAIL because the old specialized topbar still owns the copy and approval actions.

**Step 3: Write minimal implementation**

让小文使用 `AgentTopbar`，将确认/画像动作保留在页面内容区域，将复制按钮放入 `DocumentPane` 工具栏；顶栏交接成功后导航到下游。

**Step 4: Run test — confirm it passes**

Command: `pnpm --dir frontend-react vitest run src/features/xiao-wen/components/XiaoWenTopbar.test.tsx src/app/pages/XiaoWenPage.test.tsx`

Expected: PASS.

### Task 3: 统一小海、小寻、小筛、小面的交接导航

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoHaiPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoXunPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoShaiPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoMianPage.tsx`

**Step 1: Write the failing test**

为各页补充/调整集成断言：主按钮文案为“传递给下游”，成功后进入 API 返回的下游路由，失败不导航；移除顶栏中的页面导航按钮。

**Step 2: Run test — confirm it fails**

Command: `pnpm --dir frontend-react vitest run src/app/pages/XiaoHaiPage.test.tsx src/app/pages/XiaoXunPage.test.tsx src/app/pages/XiaoShaiPage.test.tsx src/app/pages/XiaoMianPage.test.tsx`

Expected: FAIL on old labels, redundant actions, or missing success navigation.

**Step 3: Write minimal implementation**

保留各页现有 payload 和前置条件；把传递按钮放到 `primaryAction`，在成功回调中读取 `to_agent` 并导航；不要把业务规则搬到公共顶栏。

**Step 4: Run test — confirm it passes**

Command: `pnpm --dir frontend-react vitest run src/app/pages/XiaoHaiPage.test.tsx src/app/pages/XiaoXunPage.test.tsx src/app/pages/XiaoShaiPage.test.tsx src/app/pages/XiaoMianPage.test.tsx`

Expected: PASS.

### Task 4: 统一小评末端完成行为

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoPingPage.tsx`

**Step 1: Write the failing test**

要求小评按钮为“完成流水线”，报告生成后可点击，成功后回到 `/pipelines/:id`，失败留在当前页。

**Step 2: Run test — confirm it fails**

Command: `pnpm --dir frontend-react vitest run src/app/pages/XiaoPingPage.test.tsx`

Expected: FAIL because当前实现只提交报告，不处理成功后的导航。

**Step 3: Write minimal implementation**

使用 `mutateAsync` 或成功回调，在传递成功后导航到 `routePaths.pipelineDetail(pipelineId)`；移除顶栏上下游/工作室按钮。

**Step 4: Run test — confirm it passes**

Command: `pnpm --dir frontend-react vitest run src/app/pages/XiaoPingPage.test.tsx`

Expected: PASS.

### Task 5: 样式和全量验证

**Files:**
- Modify: `frontend-react/src/styles.css`
- Modify: `frontend-react/src/features/xiao-wen/xiao-wen.css`

**Step 1: Write the failing test**

补充或调整移动端渲染断言，确保顶栏在窄屏仍保留返回和主按钮，不出现横向溢出。

**Step 2: Run test — confirm it fails**

Command: `pnpm --dir frontend-react vitest run`

Expected: FAIL only on changed selectors/labels before样式收口。

**Step 3: Write minimal implementation**

删除小文顶栏专属壳层样式，保留内容区仍使用的 `xw-button` 等样式；统一公共顶栏移动端断点，避免操作按钮溢出。

**Step 4: Run test — confirm it passes**

Commands:
- `pnpm --dir frontend-react typecheck`
- `pnpm --dir frontend-react vitest run`

Expected: PASS with no TypeScript errors and all Vitest tests green.
