# 小海 GPT Image 2 完整海报视觉闭环实施计划

> **For implementer:** Use TDD throughout. Write failing tests first. Watch them fail. Then implement.

**Goal:** 让 GPT Image 2 负责完整海报视觉，仅由程序覆盖公司配置中的真实 Logo 和二维码，消除素材重复与保护区底板冲突。

**Architecture:** 保留完整海报模型生成和参考图编辑链路，但取消模型输出后的装饰元素/背景重合成。Prompt 允许模型设计 Logo 与二维码容器，同时禁止伪造 Logo、二维码图案和重复装饰；后处理只覆盖真实品牌资产。

**Tech Stack:** Python、FastAPI、Pillow、pytest、GPT Image 2 兼容接口。

---

### Task 1: 固化单一视觉层所有者

**Files:**
- Modify: `tests/test_xiao_hai_image_service.py`
- Modify: `tests/test_xiao_hai_branding.py`
- Modify: `tests/test_element_library.py`
- Modify: `tests/test_xiao_hai_routes.py`

**Step 1:** 增加完整海报 Prompt 的 Logo/二维码容器约束测试，并增加元素选择后不再执行程序重合成的路由测试。

**Step 2:** 运行受影响测试，确认新测试失败。

### Task 2: 调整 GPT Image 2 Prompt 与后处理

**Files:**
- Modify: `app/xiao_hai_image.py`
- Modify: `app/xiao_hai_branding.py`
- Modify: `app/routers/xiao_hai.py`
- Modify: `app/poster_jobs.py`

**Step 1:** 让 Prompt 明确模型拥有完整视觉构图，允许设计品牌容器，要求每个参考元素只出现一次。

**Step 2:** 删除模型输出后的背景/装饰重合成，品牌后处理只贴真实 Logo、股票代码和二维码。

**Step 3:** 运行目标测试，确认通过。

### Task 3: 回归验证

**Commands:**
- `PYTHONPATH=. uv run pytest tests/test_xiao_hai_image_service.py tests/test_xiao_hai_branding.py tests/test_element_library.py tests/test_xiao_hai_routes.py -q`
- `PYTHONPATH=. uv run ruff check app/xiao_hai_image.py app/xiao_hai_branding.py app/routers/xiao_hai.py app/poster_jobs.py`
