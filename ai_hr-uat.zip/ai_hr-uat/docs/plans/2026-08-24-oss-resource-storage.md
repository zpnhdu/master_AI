# OSS 资源存储迁移实施计划

> **For implementer:** Use TDD throughout. Write failing tests first, then implement the smallest change.

**Goal:** 将运行时上传和素材读取统一接入现有 `MediaStorage`，生产环境使用 OSS 签名直连，本地环境保留兼容。

**Architecture:** 扩展媒体存储适配器提供删除、前缀枚举和签名 URL；品牌图、小海元素/参考图、流水线原始简历、笔试/面试视频和 Wiki 原文件通过统一对象 key 读写。数据库只保存稳定的 storage key，接口按请求生成短期签名 URL；解析、转码等临时工作文件仍使用本地临时目录。

**Tech Stack:** FastAPI、Python、`oss2`、SQLite、pytest。

---

## 实施范围

1. 扩展 `app/media_storage.py`，补齐 OSS/local 的删除、对象枚举和签名能力。
2. 将品牌上传、小海元素库和参考素材读取改为存储适配器优先，保留本地回退。
3. 将流水线原始简历、笔试音视频、候选人录制视频和 Wiki 原文件写入 OSS，并让后续读取从 OSS 获取。
4. 增加资源迁移脚本，用于把现有 `frontend/brand` 和 `frontend/static/xiao-hai` 素材上传到 OSS；不在无 OSS 配置的本地环境执行真实上传。
5. 运行相关单元测试、静态检查，并用 `rg` 检查目标链路是否仍有直接本地持久化。

## 约束

- `MEDIA_STORAGE_BACKEND=local` 时现有测试和本地开发目录行为保持不变。
- 不删除历史 `frontend` 素材，也不自动覆盖部署卷；历史素材需要通过迁移脚本显式上传。
- OSS bucket 默认保持私有，浏览器访问使用短期签名 URL。
- 临时转码、OCR、ASR 文件不迁移为长期 OSS 资产。
