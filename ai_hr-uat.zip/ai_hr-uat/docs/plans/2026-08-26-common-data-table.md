# 通用数据表格组件实施计划

> **For implementer:** 严格使用 TDD。先写一个能复现目标行为的失败测试，确认失败后再写最小实现；本仓库禁止未经用户确认的 Git 提交。

**Goal:** 在不替换 Ant Design `Table` 的前提下，将前端 16 个表格迁移到统一的 `DataTable` 薄封装，补齐远程排序、分页、搜索、列显隐、固定列、异常状态和响应式验证。

**Architecture:** 新增 `frontend-react/src/shared/data-table/`，由 `DataTable` 负责 Ant Design 表格外壳和视觉，`useDataTableController` 负责本地/远程状态转换，业务页面继续负责请求、筛选、权限和单元格渲染。远程人才库与 Token 明细接口增加排序白名单；列显隐仅保存在组件生命周期内。

**Tech Stack:** React 19、TypeScript 7、Ant Design 6、TanStack Query 5、Vitest 4、FastAPI、pytest。

---

## 执行约束

- 只修改本计划涉及的文件；保留工作区已有的并行改动，尤其不回退 AgentTopbar、XiaoWen、XiaoMian 和相关样式变更。
- 每个任务都必须遵循 RED → GREEN → REFACTOR，并运行最小受影响测试。
- 共享工作区不创建分支、不提交、不执行 reset、checkout、merge、rebase 或 push。
- 只有公共表格组件内部直接渲染 Ant Design `Table`；业务页面改为渲染 `DataTable`。
- 列显隐不得写入 URL、`localStorage` 或 `sessionStorage`。
- 远程排序只接受后端白名单字段，不能直接拼接前端输入到 SQL。

## Task 1: 建立公共表格类型与控制器测试

**Files:**

- Create: `frontend-react/src/shared/data-table/types.ts`
- Create: `frontend-react/src/shared/data-table/useDataTableController.test.ts`

**Step 1: Write the failing tests**

覆盖以下行为，每个行为保持一个测试：

- 默认页码和页大小为 1 / 20；
- 设置搜索词后页码回到 1；
- 设置排序后页码回到 1，并生成远程查询参数；
- 受控列显隐只影响当前 hook 实例；
- 操作列和身份列不能进入隐藏集合；
- 非法页码、页大小和排序方向回退安全默认值。

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/useDataTableController.test.ts`

Expected: FAIL because the controller and types do not exist.

**Step 3: Implement the minimal types and controller**

- Define `DataTableColumn<T>` as Ant Design `ColumnType<T>` plus `hideable`、`defaultVisible` and `role` metadata.
- Define local and remote controller state types.
- Export a controller hook that owns only generic state transitions and returns visible column keys, pagination state, sort state and reset helpers.
- Do not implement table rendering or business filtering in this task.

**Step 4: Run tests and confirm GREEN**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/useDataTableController.test.ts`

Expected: PASS.

**Step 5: Verify worktree**

Command: `git status --short`

Expected: only the new data-table files appear in addition to pre-existing changes.

## Task 2: Build the DataTable shell and interaction tests

**Files:**

- Create: `frontend-react/src/shared/data-table/DataTable.tsx`
- Create: `frontend-react/src/shared/data-table/DataTable.test.tsx`
- Create: `frontend-react/src/shared/data-table/index.ts`

**Step 1: Write the failing tests**

Render a small table and assert:

- the underlying Ant Design table renders;
- `role: 'actions'` columns receive `fixed="right"` and cannot be hidden;
- column settings hide/show only hideable columns and restore defaults;
- standard mode shows search and pagination while compact mode can hide them;
- empty, filtered-empty, loading and error states are distinct;
- search changes call the controller and reset the page;
- table width props enable horizontal scrolling without replacing the table implementation.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/DataTable.test.tsx`

Expected: FAIL because `DataTable` does not exist.

**Step 3: Implement the minimal shell**

- Render Ant Design `Table` with filtered visible columns.
- Normalize identity and action column metadata without mutating caller-owned column arrays.
- Provide toolbar slots for search, business filters, result count and actions.
- Provide temporary column settings state with reset-to-default.
- Pass through `rowSelection`, `expandable`, `loading` and table callbacks.
- Provide explicit empty/error renderers and compact mode.

**Step 4: Run tests and confirm GREEN**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/DataTable.test.tsx src/shared/data-table/useDataTableController.test.ts`

Expected: PASS.

**Step 5: Typecheck the new module**

Command: `cd frontend-react && pnpm typecheck`

Expected: PASS with no new TypeScript errors.

## Task 3: Add shared table styling and accessibility behavior

**Files:**

- Modify: `frontend-react/src/styles.css`
- Modify: `frontend-react/src/shared/data-table/DataTable.tsx`
- Modify: `frontend-react/src/shared/data-table/DataTable.test.tsx`

**Step 1: Write the failing tests**

Assert accessible names for the table region, search input, column settings trigger and reset action; assert that a table with no hideable columns does not render a column settings trigger.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/DataTable.test.tsx`

Expected: FAIL for missing labels and settings visibility.

**Step 3: Implement styles and accessibility**

- Add scoped `data-table` styles using existing project tokens and colors.
- Add fixed-column shadow, table overflow, toolbar wrapping and mobile breakpoints.
- Add labels/roles for the table region, settings popover and clear-filter action.
- Keep existing global styles intact and avoid broad table selector changes.

**Step 4: Run tests and verify styles compile**

Command: `cd frontend-react && pnpm vitest run src/shared/data-table/DataTable.test.tsx && pnpm typecheck`

Expected: PASS.

## Task 4: Add remote sort contracts for talent pool and usage detail

**Files:**

- Modify: `frontend-react/src/features/talent-pool/api.ts`
- Modify: `frontend-react/src/features/analytics/api.ts`
- Modify: `app/routers/talent_pool.py`
- Modify: `app/audit/routes.py`
- Modify: `tests/test_email_accounts.py`
- Modify: `tests/test_token_tracking.py`

**Step 1: Write failing backend/API tests**

- Talent pool accepts an allowed sort field and direction and returns stable order.
- Talent pool rejects or safely defaults an unknown sort field.
- Usage detail accepts an allowed sort field and direction for JSON and CSV.
- Usage detail keeps pagination boundaries and existing search behavior.

**Step 2: Run tests and confirm RED**

Commands:

- `pytest tests/test_email_accounts.py -k sort -q`
- `pytest tests/test_token_tracking.py -k sort -q`

Expected: FAIL because sort parameters are not yet accepted or applied.

**Step 3: Implement minimal safe sorting**

- Add typed `sort_by` and `sort_order` query params to frontend API functions.
- Add explicit backend field-to-SQL expression maps.
- Normalize direction to `asc`/`desc` and append a stable secondary key.
- Keep tenant scoping and current filter conditions unchanged.
- Make CSV use the same validated ordering.

**Step 4: Run tests and confirm GREEN**

Commands:

- `pytest tests/test_email_accounts.py -k sort -q`
- `pytest tests/test_token_tracking.py -k sort -q`

Expected: PASS.

## Task 5: Migrate the talent pool remote table

**Files:**

- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify: `frontend-react/src/features/talent-pool/api.ts`
- Modify: `frontend-react/src/features/talent-pool/hooks.ts`
- Create or modify: `frontend-react/src/app/pages/TalentPoolPage.test.tsx`

**Step 1: Write failing page tests**

Cover search, min-years filter, remote page changes, remote sort parameters, empty state, retry state and fixed delete action column.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/app/pages/TalentPoolPage.test.tsx`

Expected: FAIL for the new DataTable contract or missing sort state.

**Step 3: Migrate the page**

- Replace the resumes `Table` with `DataTable` in remote mode.
- Preserve existing query debounce, mutations, row keys and empty copy.
- Add whitelisted sortable fields and pass controller state to `useTalentResumesQuery`.
- Mark name as identity and delete as actions; keep actions fixed right.
- Leave email account and sync history tables for Task 8.

**Step 4: Run tests and typecheck**

Command: `cd frontend-react && pnpm vitest run src/app/pages/TalentPoolPage.test.tsx && pnpm typecheck`

Expected: PASS.

## Task 6: Migrate the Token usage remote table

**Files:**

- Modify: `frontend-react/src/app/pages/DashboardPage.tsx`
- Modify: `frontend-react/src/features/analytics/hooks.ts`
- Modify: `frontend-react/src/features/analytics/api.ts`
- Create or modify: `frontend-react/src/app/pages/DashboardPage.test.tsx`

**Step 1: Write failing tests**

Assert search reset, page changes, sort request parameters, CSV filter preservation and remote error/retry behavior.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/app/pages/DashboardPage.test.tsx`

Expected: FAIL for the new DataTable and sort state.

**Step 3: Migrate the table**

- Replace the detail table with remote `DataTable`.
- Keep charts and KPI cards unchanged.
- Add allowed sort fields for time, model, tokens, cost and status.
- Keep export action in the table toolbar and pass current filters/sort to CSV.

**Step 4: Run tests**

Command: `cd frontend-react && pnpm vitest run src/app/pages/DashboardPage.test.tsx && pnpm typecheck`

Expected: PASS.

## Task 7: Migrate admin, screening and assessment primary tables

**Files:**

- Modify: `frontend-react/src/app/pages/AdminPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoShaiPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoPingPage.tsx`
- Modify or create the affected page tests.

**Step 1: Write failing tests**

Add focused tests for search/filter/sort, action column fixed-right behavior, row selection feedback, compact/standard table modes and empty states.

**Step 2: Run tests and confirm RED**

Run only the affected page tests and record the expected missing DataTable behavior.

**Step 3: Migrate**

- Keep business renderers, permissions and mutations intact.
- Add local search predicates for accounts, candidates and roles.
- Preserve existing XiaoShai selection and XiaoPing batch actions.
- Mark identity and action columns with the new metadata.
- Use “更多” action menus where existing action sets exceed the fixed-column budget.

**Step 4: Run tests and typecheck**

Command: `cd frontend-react && pnpm vitest run src/app/pages/AdminPage.test.tsx src/app/pages/XiaoShaiPage.test.tsx src/app/pages/XiaoPingPage.test.tsx && pnpm typecheck`

Expected: PASS. If a page test file does not exist, add the smallest page-level test covering the migrated table before implementation.

## Task 8: Migrate talent pool email tables and nested detail tables

**Files:**

- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify or create: `frontend-react/src/app/pages/TalentPoolPage.test.tsx`

**Step 1: Write failing tests**

Cover accounts, sync history, expanded messages and attachment modal rendering, including compact mode and no-toolbar behavior.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/app/pages/TalentPoolPage.test.tsx`

Expected: FAIL for direct-table selectors or missing compact DataTable behavior.

**Step 3: Migrate**

- Use standard DataTable for accounts and sync history.
- Use compact DataTable for expanded messages and attachment modal.
- Preserve expansion-driven query loading and message/detail actions.
- Add local search/sort only where fields have clear semantics.

**Step 4: Run tests**

Command: `cd frontend-react && pnpm vitest run src/app/pages/TalentPoolPage.test.tsx && pnpm typecheck`

Expected: PASS.

## Task 9: Migrate talent recommendation, picker and selected-candidate tables

**Files:**

- Modify: `frontend-react/src/features/xiao-xun/components/TalentPoolImportCard.tsx`
- Modify or create: `frontend-react/src/features/xiao-xun/components/TalentPoolImportCard.test.tsx`
- Modify: `frontend-react/src/features/talent-pool/api.ts`

**Step 1: Write failing tests**

Cover selection checkboxes, disabled unavailable rows, recommendation search/sort, picker server pagination, compact selected-candidate table and preview action fixed-right behavior.

**Step 2: Run tests and confirm RED**

Command: `cd frontend-react && pnpm vitest run src/features/xiao-xun/components/TalentPoolImportCard.test.tsx`

Expected: FAIL for the new DataTable and picker pagination contract.

**Step 3: Migrate**

- Use standard DataTable for recommendation results and picker.
- Use compact DataTable for selected candidates.
- Preserve selection callbacks and disabled-row logic.
- Replace the picker’s `limit: 100` query with page/page-size state.

**Step 4: Run tests**

Command: `cd frontend-react && pnpm vitest run src/features/xiao-xun/components/TalentPoolImportCard.test.tsx && pnpm typecheck`

Expected: PASS.

## Task 10: Migrate remaining compact tables and remove direct business usage

**Files:**

- Modify: `frontend-react/src/app/pages/MonitorPage.tsx`
- Modify: `frontend-react/src/app/pages/XiaoPingPage.tsx`
- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify: `frontend-react/src/app/pages/DashboardPage.tsx`
- Modify: any remaining table-owning page/component identified by `rg -n '<Table' frontend-react/src`

**Step 1: Write failing structural check**

Add or run a repository check that the only `<Table` usage is inside `src/shared/data-table/DataTable.tsx` after migration.

**Step 2: Run check and confirm RED**

Command: `rg -n '<Table' frontend-react/src`

Expected: direct usages remain in business pages.

**Step 3: Migrate remaining tables**

- Use compact DataTable for salary recommendations and model summaries.
- Keep all existing data transformations and labels.
- Preserve nested/expanded behavior and modal layout.
- Add explicit table IDs for URL-synced primary tables and no persistence for column visibility.

**Step 4: Run structural and type checks**

Commands:

- `rg -n '<Table' frontend-react/src`
- `cd frontend-react && pnpm typecheck`

Expected: only the public DataTable implementation contains the underlying Ant Design table; typecheck passes.

## Task 11: Full regression, responsive and accessibility verification

**Files:**

- Modify only files required by failed tests or visual regressions.

**Step 1: Run frontend tests**

Command: `cd frontend-react && pnpm test:run`

Expected: PASS.

**Step 2: Run typecheck and build**

Commands:

- `cd frontend-react && pnpm typecheck`
- `cd frontend-react && pnpm build`

Expected: PASS.

**Step 3: Run backend targeted tests**

Commands:

- `pytest tests/test_email_accounts.py tests/test_token_tracking.py -q`
- Run any newly added endpoint tests.

Expected: PASS.

**Step 4: Visual and interaction QA**

Use `/design-review` and `/qa` after the application is running. Verify 1440px, 1024px, 768px and 390px viewports, fixed columns, toolbar wrapping, empty/error states, keyboard access and cross-page selection behavior.

**Step 5: Final structural check**

Command: `rg -n '<Table|localStorage|sessionStorage' frontend-react/src`

Expected: direct `Table` usage is confined to the shared component, and no table column preference persistence was introduced.
