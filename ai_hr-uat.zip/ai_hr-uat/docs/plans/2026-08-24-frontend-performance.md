# 前端首屏性能优化实施计划

> **For implementer:** Use TDD throughout. Write failing test first, then implement the smallest change.

**Goal:** 减少 React 登录首屏的 antd 下载量，并让 FastAPI 直出静态资源具备压缩和缓存能力。

**Architecture:** 登录与 Loading 保持轻量原生渲染；认证后的业务路由通过懒加载的 antd runtime 提供主题和消息上下文；静态资源由 FastAPI GZipMiddleware 和按路径缓存策略处理。

**Tech Stack:** React 19、TypeScript、Vite、Ant Design、FastAPI、Starlette。

---

### Task 1: 验证首屏不预加载 antd

**Files:**
- Modify: `frontend-react/src/app/App.tsx`
- Modify: `frontend-react/src/app/router.tsx`
- Modify: `frontend-react/src/app/pages/LoginPage.tsx`
- Modify: `frontend-react/src/app/pages/LoadingPage.tsx`
- Create: `frontend-react/src/app/AuthenticatedRuntime.tsx`
- Test: `frontend-react/src/app/pages/LoginPage.test.tsx`

**Steps:**
1. 先添加登录页原生表单和运行时边界的测试，确认测试在实现前失败。
2. 将 antd provider 移入懒加载 runtime，登录页改为原生控件，Loading 页移除 `Spin`。
3. 运行前端测试、typecheck 和 build，确认构建入口不再预加载 antd。

### Task 2: 压缩并缓存 FastAPI 静态资源

**Files:**
- Modify: `app/bootstrap/http.py`
- Test: `tests/test_frontend_switch.py`

**Steps:**
1. 添加静态资源响应头测试，先验证当前响应不满足 gzip/缓存预期。
2. 注册 GZipMiddleware，并按 `/assets/`、`/brand/`、`/static/` 设置缓存策略。
3. 运行相关后端测试和响应头检查。

### Task 3: 回归验证

**Files:**
- No production changes.

**Steps:**
1. 运行前端 typecheck、build 和相关 Vitest 测试。
2. 运行 Python 静态资源与前端切换测试。
3. 对比构建入口和静态资源响应大小/响应头，记录剩余的大 chunk 警告。
