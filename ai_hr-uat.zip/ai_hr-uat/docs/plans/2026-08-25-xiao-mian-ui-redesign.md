# 小面三栏对话工作台实施计划

> **For implementer:** 遵循测试先行。先写一个能失败的行为测试，再写最小实现。

**Goal:** 在后端不变的前提下，将小面改成候选人、对话、题目三栏工作台，并补齐冲突保护与移动端交互。

**Architecture:** 保留现有 `ConversationPanel` 和 `XiaoMianCommandCard` 的会话数据流，重组 `XiaoMianPage` JSX，将候选人列表移到左栏，题目编辑移到右栏，对话使用中央非 dock 模式。通过页面状态控制当前候选人、未保存草稿和待处理命令，不新增后端接口。

**Tech Stack:** React 19、TypeScript、Ant Design、TanStack Query、Vitest、Testing Library、现有 `styles.css`。

---

### Task 1: 建立三栏页面行为测试

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoMianPage.test.tsx`
- Modify: `frontend-react/src/features/xiao-mian/selectors.test.ts`

**Step 1: Write failing tests**

- 页面显示候选人列表、中央“与小面对话”和右侧“当前候选人题目”。
- 选中候选人后，右侧显示对应题目。
- 有未保存题目时发送对话，页面提示先保存。

**Step 2: Run tests**

Command: `pnpm --dir frontend-react test:run -- src/app/pages/XiaoMianPage.test.tsx src/features/xiao-mian/selectors.test.ts`

Expected: FAIL because the current page still renders the bottom conversation card and does not expose the new layout states.

**Step 3: Implement the minimum page structure and pure helpers**

Add only the state and DOM needed for the tests; keep existing API calls unchanged.

**Step 4: Run tests again**

Expected: PASS for the new layout and guard tests.

### Task 2: Recompose the workspace

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoMianPage.tsx`
- Modify: `frontend-react/src/features/xiao-mian/XiaoMianCommandCard.tsx`

Move `CandidateList` to the left pane, render `ConversationPanel` as the central full-height pane, and render `QuestionEditor` as the right pane. Keep launch/invite operations in a separate right-side “下一步” section. Add target candidate synchronization after successful conversation commands without changing the backend response contract.

Verification: the targeted page tests pass and no `app/` file changes.

### Task 3: Add card hierarchy and responsive styling

**Files:**
- Modify: `frontend-react/src/styles.css`
- Modify: `frontend-react/src/app/pages/XiaoMianPage.tsx`

Use a fixed desktop grid of approximately `240px / minmax(480px, 1fr) / minmax(380px, 420px)`, independent pane scrolling, compact question cards, sticky right action bar, one primary button per section, and mobile Tab/stack behavior. Avoid importing the whole xiao-wen stylesheet.

Verification: typecheck and the page tests pass; desktop and mobile DOM states remain accessible by role and label.

### Task 4: Verify the complete frontend slice

**Files:**
- No new production files unless the previous tasks identify a necessary small component extraction.

Run:

- `pnpm --dir frontend-react test:run -- src/app/pages/XiaoMianPage.test.tsx src/features/xiao-mian`
- `pnpm --dir frontend-react typecheck`
- `pnpm --dir frontend-react build`

Expected: all targeted tests pass, TypeScript passes, and Vite build completes without warnings caused by this change.
