# 统一对话式面试工作台 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 在“小面”工作台中用统一的文字/语音对话入口完成单人改题和单人排期，并通过预览、确认、取消、撤销和重复执行保护保证写操作安全。

**Architecture:** 新增独立的受控对话执行层。文字和 ASR 转写文本先解析成白名单命令，持久化为待确认记录；确认时再调用现有 `question_review` 或排期 CRUD。前端只负责录音、转写、发送消息和渲染对话卡片，不直接判断或执行改题、排期意图。

**Tech Stack:** FastAPI、Pydantic、SQLite/MySQL 兼容 DB 层、现有 Hermes LLM 调用、单文件 HTML/JavaScript、pytest。

**Approved design:** `/Users/zhoulin/.gstack/projects/shanghai-ai-hr-demo/zhoulin-hotfix-20260806-design-20260810-101832.md`

**Scope:** 实现设计文档 Phase 1 和 Phase 2。Phase 3 的批量操作、外部日历和邀请通知不在本次范围。

---

## Task 1: 命令账本与排期取消能力

**Files:**

- Modify: `app/db.py`
- Create: `tests/test_interview_conversation.py`

**RED:** 先测试以下行为，再实现：

- 命令的 `payload/preview/result` 可以 JSON 往返。
- allowlist 更新状态和执行结果，未知字段不能写入。
- 缺失命令查询、更新返回 `None`。
- 取消排期只把状态改为 `cancelled`，不删除记录。

**Implementation:**

- 新增 `interview_commands` 表。
- 新增 `save_interview_command`、`get_interview_command`、`update_interview_command`。
- 新增 `cancel_interview_schedule`。

**Verify:**

```bash
python -m pytest tests/test_interview_conversation.py -q
```

---

## Task 2: 指令解析、追问与安全预览

**Files:**

- Create: `app/interview_conversation.py`
- Modify: `tests/test_interview_conversation.py`

**RED:** 覆盖：

- 单题修改生成差异预览但不写题目。
- 整套修改保持题数。
- 缺失面试官等字段返回单项追问。
- 带 `command_id` 的补充消息合并旧 payload。
- 候选人必须精确且唯一匹配。
- 排期预览显示绝对日期、时间、`Asia/Shanghai` 和内部冲突。
- 过去日期或无效时间不能进入确认状态。

**Implementation:**

```python
async def submit_message(
    pipeline_id: str,
    message: str,
    source: str = "text",
    command_id: str = "",
) -> dict: ...
```

内部拆分解析、候选人解析、改题预览、排期预览和题目版本 hash。LLM 只允许返回 `modify_questions` 或 `schedule_interview`，预览阶段不得调用写接口。

**Verify:**

```bash
python -m pytest tests/test_interview_conversation.py -q
```

---

## Task 3: 确认、取消、撤销与重复执行保护

**Files:**

- Modify: `app/interview_conversation.py`
- Modify: `tests/test_interview_conversation.py`

**RED:** 覆盖：

- 改题确认只写一次并重置审核状态。
- 预览后题目变化时返回 `stale`，不覆盖他人修改。
- 排期确认前重新检查冲突。
- 相同命令重复确认返回首次结果，不重复排期。
- 待确认命令可取消且无副作用。
- 撤销改题恢复旧题；撤销排期保留 cancelled 记录。

**Implementation:**

```python
async def confirm_command(pipeline_id: str, command_id: str) -> dict: ...
def cancel_command(pipeline_id: str, command_id: str) -> dict: ...
async def undo_command(pipeline_id: str, command_id: str) -> dict: ...
```

改题调用 `question_review.set_questions`。排期 ID 从 command ID 稳定派生。执行、取消、撤销均记录审计事件。

**Verify:**

```bash
python -m pytest tests/test_interview_conversation.py tests/test_question_review.py -q
```

---

## Task 4: FastAPI 路由

**Files:**

- Create: `app/routers/interview_conversation.py`
- Modify: `app/routers/__init__.py`
- Modify: `app/main.py`
- Modify: `tests/test_interview_conversation.py`

**Routes:**

```text
POST /api/pipelines/{pipeline_id}/interview-commands
POST /api/pipelines/{pipeline_id}/interview-commands/{command_id}/confirm
POST /api/pipelines/{pipeline_id}/interview-commands/{command_id}/cancel
POST /api/pipelines/{pipeline_id}/interview-commands/{command_id}/undo
```

先写 404/422/成功路径测试，再注册路由。业务校验失败映射 400，pipeline 或 command 不存在映射 404。

**Verify:**

```bash
python -m pytest tests/test_interview_conversation.py -q
```

---

## Task 5: 小面统一文字与语音入口

**Files:**

- Modify: `frontend/xiao_mian.html`
- Create: `tests/test_xiao_mian_conversation_ui.py`

**RED:** 静态测试覆盖：

- 改题、排期统一调用 `interview-commands` API。
- 排期意图不再打开 `showScheduleCard()`。
- 题目展示不再渲染结构化编辑字段。
- 语音控件复用 `/api/interview/asr`，转写后只回填文字。
- 对话卡支持确认、取消、撤销。

**Implementation:**

- 输入框升级为 textarea，增加录音/停止按钮和状态文案。
- 使用 `MediaRecorder` 采集 WebM 音频。
- `activeInterviewCommandId` 关联追问回复。
- 渲染 clarification、question diff、schedule summary、executed、stale 和 failed。
- 保留生成题目、发起面试等未迁移能力的原路径。

**Verify:**

```bash
python -m pytest tests/test_xiao_mian_conversation_ui.py -q
npx prettier --check frontend/xiao_mian.html
```

---

## Task 6: 回归与最终审查

```bash
python -m pytest tests/test_interview_conversation.py tests/test_question_review.py tests/test_xiao_mian_conversation_ui.py -q
npx prettier --check frontend/xiao_mian.html
ruff check app/interview_conversation.py app/routers/interview_conversation.py tests/test_interview_conversation.py tests/test_xiao_mian_conversation_ui.py
ruff format --check app/interview_conversation.py app/routers/interview_conversation.py tests/test_interview_conversation.py tests/test_xiao_mian_conversation_ui.py
```

最终检查不得包含用户已有的 `data/`、合同文档或其他无关改动。全部验证通过后，再按仓库规则征求 commit 确认。
