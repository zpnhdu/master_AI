# 前后端超时职责统一设计

## 背景

当前前端同时维护公共请求超时、JD 生成超时、画像生成超时、海报生成超时和视频上传超时；后端又存在 Agent 配置、LLM 单次请求超时、DAG 阶段超时以及 Supervisor 硬编码 120 秒限制。多个超时可能覆盖同一段执行，也可能互相矛盾。

## 目标

1. 后端成为业务执行超时的唯一来源。
2. 后端以总业务 deadline 约束 LLM 调用、重试、持久化和阶段状态更新。
3. 前端只保留统一的网络安全取消机制，不维护 JD、画像、海报等业务秒数。
4. 长任务逐步复用现有阶段状态和 WebSocket，避免长期占用同步 HTTP 连接。
5. 超时结果可观测、可重试，且不会把阶段永久留在 `running`。

## 非目标

- 本次不重写现有 Redis 队列或 WebSocket 协议。
- 不修改业务 Agent 的提示词、模型选择和重试策略之外的逻辑。
- 不为文件上传和 SSE 引入与业务任务相同的超时语义；它们继续保留传输级取消能力。

## 设计

### 1. 超时模型

后端的 `timeout` 统一表示一次业务操作的总预算，而不是单次 HTTP/LLM 请求预算。执行开始时创建 deadline；每次下游调用使用剩余秒数，重试不得超过 deadline。

第一阶段复用 `agent_configs.timeout` 作为配置入口，并统一阶段 ID（例如将 `jd_writer` 兼容到 `jd_write`）。当不同操作确实需要不同预算时，再增加按 operation 的后端配置，不在前端复制这些值。

### 2. 后端执行入口

统一包装以下路径：

- JD 生成
- JD 修改预览
- 候选人画像
- 海报生成
- DAG/Supervisor 阶段

包装器负责读取有效配置、创建 deadline、计算剩余时间、统一处理 `TimeoutError`，并将阶段置为 `failed` 或 `timed_out`。

### 3. HTTP 错误契约

后端超时返回 HTTP 504：

```json
{
  "code": "backend_timeout",
  "message": "任务执行超时，请稍后重试",
  "operation": "profile_build",
  "timeout_seconds": 240,
  "request_id": "req_..."
}
```

前端只根据 HTTP 状态和错误码展示统一提示，不根据本地业务秒数判断失败。

### 4. 前端请求层

`requestWithTimeout` 保留，但改成单一网络安全超时，并区分：

- 网络安全超时
- 用户主动取消
- 页面卸载取消
- 后端 504

`requestJson` 的业务 `timeoutMs` 参数进入迁移兼容期后删除。JD 和海报模块移除各自的长超时常量。普通直接 `fetch` 接入公共请求层；SSE 和 XHR 上传保留自己的传输取消机制。

### 5. 长任务迁移

优先复用现有 Pipeline stage 状态和 WebSocket 事件。长任务入口最终返回任务/阶段标识，前端通过 WebSocket 事件刷新工作台，并保留查询接口作为降级方案。海报生成优先复用已有 `poster_generation_jobs` 数据结构。

## 错误和边界

- 后端 deadline 到期时必须清理 `running` 状态。
- LLM 调用在 `asyncio.to_thread` 中运行时，传入剩余请求超时，避免仅取消协程而遗留长时间线程。
- 已经完成的任务重复请求应继续走现有幂等/缓存逻辑。
- Nginx 超时不得短于仍然同步执行的后端业务上限；异步化后恢复短 API 超时。

## 测试策略

- 后端：deadline 剩余时间、重试预算、504 错误体、阶段状态清理。
- 前端：统一网络超时、主动取消分类、504 映射、业务模块不再传入 timeout。
- 集成：延迟 LLM、Nginx 上限、WebSocket 阶段完成事件和重复请求。
- 静态检查：前端不再出现业务级 `*_TIMEOUT_MS` 常量。
