# 知识库硬删除可靠性改造实施计划

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 在不引入回收站或软删除的前提下，让知识库按资料硬删除时具备幂等、失败可重试和共享页面保护能力。

**Architecture:** 删除以 `source_id` 为边界，先删除 OSS/本地内容，再清理派生缓存，最后在一个数据库事务中删除 `wiki_pages` 和 `wiki_ingest`。已被其他资料引用的 Wiki 页面保留。兼容图谱统一使用页面内容哈希检测 OSS 页面变化，前端同步失效页面查询缓存。

**Tech Stack:** Python、FastAPI、MySQL、OSS/本地 MediaStorage、React Query、pytest、Vitest。

---

### Task 1: 硬删除行为测试

**Files:**
- Modify: `tests/test_wiki.py`
- Modify: `tests/test_kb_upload_api.py`

**Step 1:** 添加测试，覆盖已不存在文件的幂等成功、存储删除失败时不清数据库、其他资料引用的页面不删除。

**Step 2:** 分别运行新增测试，确认当前实现失败。

**Step 3:** 实现最小后端改动使测试通过。

**Step 4:** 运行知识库后端测试，确认无回归。

---

### Task 2: 存储删除与数据库清理

**Files:**
- Modify: `app/wiki_store.py`
- Modify: `app/wiki_ingest.py`
- Modify: `app/routers/wiki.py`

**Step 1:** 让本地/OSS删除对“目标已不存在”幂等，对真实删除异常返回失败。

**Step 2:** 删除路由预校验页面路径，跳过仍被其他资料引用的页面；存储删除失败时保留数据库记录并返回错误。

**Step 3:** 存储清理成功后使用数据库事务删除索引和资料状态记录，再重建聚合页。

**Step 4:** 运行 `pytest tests/test_wiki.py tests/test_kb_upload_api.py tests/test_wiki_oss_storage.py -q`。

---

### Task 3: OSS 兼容读取与前端缓存

**Files:**
- Modify: `kg/core.py`
- Modify: `frontend-react/src/app/pages/KnowledgePage.tsx`
- Modify: `tests/test_wiki_oss_storage.py` 或 `tests/test_wiki.py`

**Step 1:** 添加 OSS-only 页面可被兼容图谱加载、页面删除后查询缓存失效的测试。

**Step 2:** 用 `ws.read_page()` 内容指纹替换本地 `os.stat` 指纹；删除成功后失效 `wiki/page` 查询。

**Step 3:** 运行相关 Python 与前端测试。

---

### Task 4: 最终验证

**Files:** 无新增生产文件。

**Verification:**
- `pytest tests/test_wiki.py tests/test_kb_upload_api.py tests/test_wiki_oss_storage.py -q`
- `pnpm --dir frontend-react test -- --run src/app/pages/KnowledgePage.test.tsx`
- `ruff check app/wiki_store.py app/wiki_ingest.py app/routers/wiki.py kg/core.py`
- 检查 `git diff` 和 `git status`，确保不包含既有的 `useXiaoWenController.ts` 修改。
