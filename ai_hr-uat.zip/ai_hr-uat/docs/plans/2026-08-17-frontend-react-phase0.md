# React/Vite Frontend Phase 0/1 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first for runtime behavior. Configuration-only scaffolding may be verified by build commands.

**Goal:** Build an isolated React/Vite frontend shell with Ant Design, typed API access, authentication-aware routes, and a `/studio` placeholder without changing the legacy frontend or backend routes.

**Architecture:** Create `frontend-react/` as a separate Vite application. The app talks to the existing FastAPI server through Vite dev proxies for `/api` and `/ws`; production cutover remains disabled until the shell and Studio slice pass acceptance tests. The root route inside the new app is authentication-aware, while the existing FastAPI `/` route remains unchanged in this phase.

**Tech Stack:** React 19, Vite 8, TypeScript 7, Ant Design 6, React Router 7, TanStack Query 5, Zustand 5, React Hook Form 7, Zod 4, Vitest, Testing Library, Playwright, pnpm.

---

## Task 1: Scaffold isolated frontend project

**Files:**
- Create: `frontend-react/package.json`
- Create: `frontend-react/index.html`
- Create: `frontend-react/tsconfig.json`
- Create: `frontend-react/tsconfig.node.json`
- Create: `frontend-react/vite.config.ts`
- Create: `frontend-react/src/vite-env.d.ts`
- Create: `frontend-react/src/main.tsx`

**Step 1: Write the minimal build contract**

The contract is that `pnpm --dir frontend-react build` emits a production bundle and `pnpm --dir frontend-react typecheck` completes without errors. No runtime implementation is required in this configuration-only task.

**Step 2: Run the build command before scaffolding**

Command: `pnpm --dir frontend-react build`

Expected: FAIL because `frontend-react/package.json` and the Vite entry do not exist.

**Step 3: Add the minimal Vite/React configuration**

- Use the React Vite plugin.
- Add `dev`, `build`, `typecheck`, `test`, and `test:run` scripts.
- Configure `/api` and `/ws` proxy targets from `VITE_BACKEND_ORIGIN`, defaulting to `http://127.0.0.1:8888`.
- Keep the output inside `frontend-react/dist`; do not write into `frontend/`.

**Step 4: Run verification**

Commands:

```bash
pnpm --dir frontend-react install
pnpm --dir frontend-react typecheck
pnpm --dir frontend-react build
```

Expected: all commands pass and `frontend-react/dist/index.html` exists.

## Task 2: Add application entry and route contract

**Files:**
- Create: `frontend-react/src/app/App.tsx`
- Create: `frontend-react/src/app/App.test.tsx`
- Create: `frontend-react/src/app/router.tsx`
- Modify: `frontend-react/src/main.tsx`
- Create: `frontend-react/src/test/setup.ts`
- Create: `frontend-react/vitest.config.ts`

**Step 1: Write the failing route tests**

Cover one behavior per test:

- unauthenticated app renders the login route;
- authenticated user with `pipeline:read` renders the Studio route;
- authenticated user without `pipeline:read` renders the forbidden route;
- direct `/studio` navigation does not fall through to a blank page.

Use a small in-memory auth fixture. Do not call the live API from unit tests.

**Step 2: Run the tests**

Command: `pnpm --dir frontend-react test:run -- src/app/App.test.tsx`

Expected: FAIL because the app, router, and auth fixture do not exist.

**Step 3: Implement the smallest route tree**

- Add `BrowserRouter` with `/`, `/login`, `/studio`, and `/forbidden`.
- Add a temporary typed auth context/provider owned by `src/app/`.
- Make `/` redirect to `/studio` only after the auth fixture reports a user with `pipeline:read`.
- Keep the auth contract isolated so it can later call `/api/auth/me` without changing route components.

**Step 4: Run the tests and typecheck**

Commands:

```bash
pnpm --dir frontend-react test:run -- src/app/App.test.tsx
pnpm --dir frontend-react typecheck
```

Expected: all route tests pass and typecheck is clean.

## Task 3: Implement Ant Design App Shell and Studio placeholder

**Files:**
- Create: `frontend-react/src/layouts/AppShell.tsx`
- Create: `frontend-react/src/layouts/AppShell.test.tsx`
- Create: `frontend-react/src/pages/LoginPage.tsx`
- Create: `frontend-react/src/pages/ForbiddenPage.tsx`
- Create: `frontend-react/src/pages/StudioPage.tsx`
- Create: `frontend-react/src/styles/theme.ts`
- Create: `frontend-react/src/styles/global.css`
- Modify: `frontend-react/src/app/App.tsx`

**Step 1: Write failing shell tests**

Cover:

- authenticated Studio renders the product title, navigation shell, and main content landmark;
- the Studio placeholder exposes a stable heading and a clear migration status;
- unauthenticated users see the login page without the protected shell.

**Step 2: Run the tests**

Command: `pnpm --dir frontend-react test:run -- src/layouts/AppShell.test.tsx`

Expected: FAIL because the shell and page components do not exist.

**Step 3: Implement the shell**

- Use Ant Design `Layout`, `Menu`, `Typography`, `Result`, and `Spin` only where needed.
- Put brand/theme tokens in one place.
- Keep navigation entries declarative and mark non-migrated pages as placeholders; do not link to fake React routes that are not implemented.
- Do not copy the legacy `studio.html` markup into React. This task creates the boundary and visual shell only.

**Step 4: Run focused and full frontend checks**

Commands:

```bash
pnpm --dir frontend-react test:run
pnpm --dir frontend-react typecheck
pnpm --dir frontend-react build
```

Expected: tests, typecheck, and build pass.

## Task 4: Add typed API client and TanStack Query foundation

**Files:**
- Create: `frontend-react/src/services/http.ts`
- Create: `frontend-react/src/services/auth.ts`
- Create: `frontend-react/src/services/api-types.ts`
- Create: `frontend-react/src/app/query-client.ts`
- Create: `frontend-react/src/services/auth.test.ts`
- Modify: `frontend-react/src/main.tsx`

**Step 1: Write failing service tests**

Cover:

- a 401 response produces an unauthenticated result;
- a 403 response is distinguishable from a 401;
- a successful `/api/auth/me` response maps to the typed auth shape;
- network failure returns a retryable error without exposing credentials.

Use a local fetch stub only at the service boundary. Do not mock TanStack Query internals.

**Step 2: Run the tests**

Command: `pnpm --dir frontend-react test:run -- src/services/auth.test.ts`

Expected: FAIL because the typed client and auth service do not exist.

**Step 3: Implement the foundation**

- Use `fetch` or `openapi-fetch` behind one client boundary.
- Create one `QueryClient` at app startup.
- Keep the existing FastAPI cookie/session model; never store password or session secrets in Zustand.
- Treat 401, 403, 422, 500, and network errors as separate error categories.

**Step 4: Run verification**

Commands:

```bash
pnpm --dir frontend-react test:run
pnpm --dir frontend-react typecheck
pnpm --dir frontend-react build
```

Expected: all checks pass.

## Task 5: Verify same-origin development integration

**Files:**
- Create: `frontend-react/e2e/smoke.spec.ts`
- Create: `frontend-react/playwright.config.ts`
- Modify: `frontend-react/vite.config.ts` only if proxy verification requires it

**Step 1: Write the failing smoke test**

The test must verify:

- Vite serves the React shell;
- `/api/health` is reachable through the Vite proxy;
- the app does not request an absolute backend origin from browser code.

**Step 2: Run the test before starting Vite**

Command: `pnpm --dir frontend-react exec playwright test e2e/smoke.spec.ts`

Expected: FAIL because the Vite dev server is not running.

**Step 3: Run the smallest integration environment**

Start Vite on a separate port, keep the existing FastAPI service on 8888, and run the Playwright smoke test against the Vite port.

**Step 4: Run verification**

Commands:

```bash
pnpm --dir frontend-react exec playwright test e2e/smoke.spec.ts
pnpm --dir frontend-react build
```

Expected: smoke test and production build pass. Stop only the Vite process started by this task after verification.

## Completion handoff

After Tasks 1–5 are green, review the diff for scope creep, then continue with the Studio feature slice in a separate plan. Do not switch FastAPI `/` to `/studio` until the React Studio has a real authenticated read-only Pipeline view and a passing rollback test.

No git commit is included in this plan because the repository rules require explicit user confirmation before committing.
