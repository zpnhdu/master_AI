# 去重自动可靠化 Implementation Plan

> **REQUIRED SUB-SKILL:** Use the executing-plans skill to implement this plan task-by-task.

**Goal:** 去重由系统在入库/导入/匹配全链路自动保障，删除前端"去重检查"按钮与后端 `/dedup` 端点，用户无需任何手动操作。

**Architecture:** 以 `app/talent_pool.save_resume` 为唯一去重闸门（统一启用"姓名+目标岗位"去重 + 指纹去重 + 疑似关联三层防线），所有简历入口（手动添加/文件上传/插件导入/粘贴/邮箱同步）入库时自动拦截重复；管道入口在重复时跳过不入 `pending_resumes`；匹配前对库中已有候选人做跨批次同名查重；最后移除手动去重按钮与端点；写只读统计脚本评估存量重复。

**Tech Stack:** Python 3.9+ / FastAPI / SQLite / 原生前端 HTML/JS / pytest / DedupAgent（文本 Jaccard）

**决策记录（已与用户确认）：**
- 所有入口统一自动按"姓名+目标岗位"去重（接受同名同岗不同人合并的取舍）
- 管道内重复：保留最完整 + 跳过其余（沿用 DedupAgent 行为）
- 存量数据：先写只读统计脚本，看数据再决定是否清理

---

### Task 1: save_resume 默认启用姓名+岗位去重 + 电话归一化

**Files:**
- Modify: `app/talent_pool.py`（`compute_fingerprint` ~L60-80、`_dedup_by_name_and_role` ~L185-206、`save_resume` ~L209-232）
- Modify: `app/email_sync.py:539`
- Test: `tests/test_resume_dedup.py`、`tests/test_full_pipeline.py:317-346`

**Step 1: 写失败测试（默认参数即去重）**

更新 `tests/test_resume_dedup.py`：
- `test_same_name_same_role_deduped_when_enabled` → 去掉 `dedup_by_name=True`，改为默认调用即去重：
```python
def test_same_name_same_role_deduped_default(self):
    """默认开启：同名+同岗位 → 去重"""
    _reset()
    r1 = save_resume({"name": "张思远", "title": "私域运营总监", "skills": ["私域"], "current_company": "某品牌"})
    assert r1.get("duplicate") is False, r1
    r2 = save_resume({"name": "张思远", "title": "私域运营总监", "skills": ["私域运营"], "current_company": "某品牌总部"})
    assert r2.get("duplicate") is True, f"应去重: {r2}"
```
- `test_same_name_diff_role_kept`：去掉 `dedup_by_name=True`
- **删除** `test_default_off_keeps_same_name_same_role`（行为已反转）
- `test_dedup_helper`：保持不变
- 新增电话归一化测试：
```python
def test_phone_normalization_fingerprint(self):
    """+86/空格/横线差异不影响指纹去重"""
    _reset()
    r1 = save_resume({"name": "陈晓", "phone": "+86 138-0000-0000", "skills": ["运营"]})
    assert r1.get("duplicate") is False, r1
    r2 = save_resume({"name": "陈晓", "phone": "13800000000", "skills": ["运营"]})
    assert r2.get("duplicate") is True, f"电话格式差异应去重: {r2}"
```
- 新增占位名保护测试：
```python
def test_placeholder_name_not_deduped(self):
    """'未知'等占位名不做姓名去重，避免误杀"""
    _reset()
    save_resume({"name": "未知", "title": "销售", "skills": ["销售"]})
    r2 = save_resume({"name": "未知", "title": "销售", "skills": ["销售"]})
    assert r2.get("duplicate") is False, f"占位名不应去重: {r2}"
```

更新 `tests/test_full_pipeline.py` `test_email_dedup_flow`：r2、r3 调用去掉 `dedup_by_name=True`（L331、L339）。

**Step 2: 运行测试确认失败**

```bash
python -m pytest tests/test_resume_dedup.py tests/test_full_pipeline.py -v
```
Expected: FAIL — 默认调用时 `_dedup_by_name_and_role` 未被触发（`dedup_by_name` 仍为 False），`test_same_name_same_role_deduped_default` 断言失败；`test_phone_normalization_fingerprint` 指纹不一致失败；`test_placeholder_name_not_deduped` 已通过（当前就不去重）。

**Step 3: 实现**

`app/talent_pool.py`：
1. 新增电话归一化（放在 `compute_fingerprint` 上方）：
```python
def _normalize_phone(phone: str) -> str:
    """电话归一化：去空格/横线/括号，统一 +86/86 前缀，全角转半角。"""
    if not phone:
        return ""
    p = str(phone)
    # 全角转半角
    p = p.translate({0xFF10 + i: 0x30 + i for i in range(10)})
    p = re.sub(r"[^\d+]", "", p)
    if p.startswith("+86"):
        p = p[3:]
    elif p.startswith("86") and len(p) == 13:
        p = p[2:]
    return p
```
2. `compute_fingerprint` 中电话段改为归一化：
```python
    if phone or email:
        parts.append(_normalize_phone(phone))
        parts.append(email.strip().lower())
```
3. `_dedup_by_name_and_role` 增加占位名防护：
```python
    name = _normalize_for_fingerprint(resume_data.get("name", ""))
    if not name or len(name) < 2 or name in {"未知", "无名", "无", "unknown", "n/a"}:
        return None
```
4. `save_resume` 签名去掉 `dedup_by_name` 参数，去重段无条件执行：
```python
def save_resume(resume_data: dict, tenant_id: str = "") -> dict:
    """Save a parsed resume to the global talent pool.

    Returns:
        - New insert: {"id": resume_id, "duplicate": False}
        - Exact fingerprint match: {"duplicate": True, "existing_id": <id>}
        - Name+role duplicate: {"duplicate": True, "existing_id": <id>}
        - Suspect match: {"id": resume_id, "duplicate": False, "suspect_match": <id>}
        - Validation fail: {"duplicate": False, "skipped": True, "reason": str}
    """
    if not _validate_resume(resume_data):
        return {"duplicate": False, "skipped": True, "reason": "validation_failed"}

    # ── 基础去重（全入口默认开启）：同名 + 同目标岗位 → 视为同一份简历 ──
    dedup_result = _dedup_by_name_and_role(resume_data, tenant_id)
    if dedup_result:
        return {"duplicate": True, "existing_id": dedup_result}
```

`app/email_sync.py:539`：`save_resume(parsed, dedup_by_name=True)` → `save_resume(parsed)`

**Step 4: 运行测试确认通过**

```bash
python -m pytest tests/test_resume_dedup.py tests/test_full_pipeline.py -v
```
Expected: ALL PASS。另跑人才库回归：
```bash
python -m pytest tests/test_talent_pool.py -v
```
Expected: PASS（如该文件有依赖旧签名的用例，同步调整）。

**Step 5: 全局搜索残留调用**

```bash
grep -rn "dedup_by_name" app/ tests/ scripts/ frontend/
```
Expected: 无残留（若 tests/ 其他文件引用，一并更新）。

**Step 6: Commit**

```bash
git add app/talent_pool.py app/email_sync.py tests/test_resume_dedup.py tests/test_full_pipeline.py
git commit -m "feat(dedup): save_resume 全入口默认按姓名+岗位去重，电话归一化强化指纹"
```

---

### Task 2: 管道入口识别重复并跳过（resumes.py import/upload/paste）

**Files:**
- Modify: `app/routers/resumes.py`（`api_import_resumes` ~L104-146、`api_upload_resumes` ~L153-246）
- Test: 新增 `tests/test_resume_import_dedup.py`

**Step 1: 写失败测试**

新建 `tests/test_resume_import_dedup.py`（直接调 `save_resume` 验证语义 + 验证 import 路由不再把重复简历放入 `pending_resumes`）：
```python
# -*- coding: utf-8 -*-
"""管道入口去重测试：与人才库重复的简历不入 pending_resumes"""
import pytest
from app.db import init_db
from app.state import pending_resumes


def _reset():
    pending_resumes.clear()
    init_db()


@pytest.mark.asyncio
async def test_import_duplicate_skipped():
    """重复导入同一人 → 第二次不入 pending_resumes"""
    _reset()
    from app.talent_pool import save_resume
    from app.routers.resumes import api_import_resumes

    from app.db import create_pipeline
    pid = create_pipeline({"role": "私域运营总监", "title": "私域运营总监"})["id"]

    # 先入库一份
    save_resume({"name": "张思远", "title": "私域运营总监", "skills": ["私域"], "current_company": "A"})

    req = type("R", (), {"pipeline_id": pid, "source": "extension", "candidates": [
        {"name": "张思远", "title": "私域运营总监", "tags": ["私域运营"], "currentCompany": "A公司"},
    ]})()
    resp = await api_import_resumes(req)
    assert resp["status"] == "imported"
    assert len(pending_resumes[pid]) == 0, f"重复简历不应入 pending: {pending_resumes[pid]}"
```
> 注：`api_import_resumes` 返回需新增 `duplicates` 计数（见 Step 3）。若 `create_pipeline` 签名不同，以 `app/db.py` 实际签名为准。

**Step 2: 运行测试确认失败**

```bash
python -m pytest tests/test_resume_import_dedup.py -v
```
Expected: FAIL — 当前 import 不检查 `save_resume` 返回值，`pending_resumes[pid]` 长度为 1。

**Step 3: 实现**

`app/routers/resumes.py`：
1. `api_import_resumes` 中：
```python
        # Auto-save to global talent pool
        pool_result = save_resume_to_pool(normalized)
        if pool_result.get("duplicate"):
            duplicates += 1
            continue  # 与人才库重复 → 不入 pending，不参与匹配
        state.pending_resumes[req.pipeline_id].append(normalized)
```
（函数开头初始化 `duplicates = 0`，返回 `{..., "duplicates": duplicates}`，并统计 message 文案：`从{req.source}导入{len(imported)}份，跳过{duplicates}份重复`。注意 import 循环中 `count` 更新逻辑保持正确。）
2. `api_upload_resumes`：files 与 paste 两处同理：
```python
            pool_result = save_resume_to_pool(parsed)
            if pool_result.get("duplicate"):
                duplicates.append({"filename": filename, "reason": "与人才库已有简历重复"})
                continue
            state.pending_resumes[pipeline_id].append(parsed)
```
（返回体增加 `"duplicates": duplicates`；`save_pending` 仅在非重复时调用。）

**Step 4: 运行测试确认通过**

```bash
python -m pytest tests/test_resume_import_dedup.py tests/test_pending.py -v
```
Expected: ALL PASS。

**Step 5: Commit**

```bash
git add app/routers/resumes.py tests/test_resume_import_dedup.py
git commit -m "feat(dedup): 管道入口与人才库重复时跳过，不入 pending_resumes"
```

---

### Task 3: 匹配前与库中已有候选人跨批次同名查重

**Files:**
- Modify: `app/services.py`（`_do_process_imported_resumes` 查重段 ~L396-432）
- Test: `tests/test_full_pipeline.py`（新增跨批次场景，若可行）

**Step 1: 写失败测试**

在 `tests/test_full_pipeline.py` 新增：
```python
def test_pipeline_cross_batch_name_dedup():
    """同一流水线：已匹配过的候选人再次导入同名简历 → 跳过不重复匹配"""
    _clean()
    from app.db import create_pipeline, save_candidate, get_candidates
    from app.services import _do_process_imported_resumes

    pid = create_pipeline({"role": "私域运营总监", "title": "私域运营总监"})["id"]
    # 已有候选人（上一批次已匹配）
    save_candidate(pid, {"id": "c_a", "name": "张思远", "title": "私域运营总监", "skills": ["私域"]})
    # 本次待处理批次里再次出现同名
    from app.state import pending_resumes
    pending_resumes[pid] = [{"id": "c_b", "name": "张思远", "title": "私域运营总监", "skills": ["私域运营"]}]
    # 补 JD stage 以免匹配前失败（若 _do_process_imported_resumes 需要 JD，则构造最小 stage）
    ...
    await _do_process_imported_resumes(pid)
    # 断言：c_b 被标记 duplicate 且未参与匹配（检查其 status）
```
> 注：`_do_process_imported_resumes` 依赖 JD stage、MatchAgent 等完整链路，若单测不可行，则降级为 Task 6 手工验证（启动服务 → 导入重复 → 观察跳过）。实现时以真实行为为准，测试骨架先行。

**Step 2: 运行测试确认失败**

```bash
python -m pytest tests/test_full_pipeline.py::test_pipeline_cross_batch_name_dedup -v
```
Expected: FAIL（当前无跨批次查重，c_b 进入匹配）。

**Step 3: 实现**

`app/services.py` 查重段（在 DedupAgent 批内查重之后追加）：
```python
    # === 跨批次查重：与库中已有候选人（同一流水线已匹配过）同名 → 跳过 ===
    from app.talent_pool import _normalize_for_fingerprint

    existing_candidates = get_candidates(pipeline_id)
    existing_names = set()
    for c in existing_candidates:
        n = _normalize_for_fingerprint(c.get("name", ""))
        if n and len(n) >= 2 and n not in {"未知", "无名", "无", "unknown", "n/a"}:
            existing_names.add(n)

    batch_names = set()
    kept, removed_by_existing = [], []
    for r in dedup_resumes:
        n = _normalize_for_fingerprint(r.get("name", ""))
        if n and len(n) >= 2 and (n in existing_names or n in batch_names):
            removed_by_existing.append(r)
            update_candidate(r.get("id", ""), {"status": "duplicate"})
            continue
        if n:
            batch_names.add(n)
        kept.append(r)

    if removed_by_existing:
        dedup_resumes = kept
        dedup_result["removed"] = dedup_result.get("removed", []) + [
            {"id": r.get("id", ""), "name": r.get("name", "")} for r in removed_by_existing
        ]
        save_message(
            pipeline_id,
            "assistant",
            f"⚠️ 跳过 {len(removed_by_existing)} 份与已有候选人重复的简历",
            card_type="dedup_card",
            card_data=dedup_result,
        )
```
注意：`dedup_resumes` 必须用局部 `kept` 覆盖并同步 `context["resumes"]` / `new_resumes` / `resumes`（与现有 DedupAgent 分支相同的赋值方式）。`update_candidate`、`get_candidates` 已在 services.py 引入。

**Step 4: 运行测试确认通过**

```bash
python -m pytest tests/test_full_pipeline.py -v
```
Expected: ALL PASS。

**Step 5: Commit**

```bash
git add app/services.py tests/test_full_pipeline.py
git commit -m "feat(dedup): 匹配前与已有候选人跨批次同名查重，重复跳过并标记"
```

---

### Task 4: 删除手动去重（前端按钮 + 后端端点 + 脚本断言）

**Files:**
- Modify: `frontend/xiao_xun.html`（按钮 ~L409、`runDedup` 函数 ~L444-458）
- Modify: `app/routers/pipelines.py`（`api_dedup_candidates` ~L1093-1131）
- Modify: `scripts/test_all_buttons.py:198`

**Step 1: 删除前端按钮与函数**

`frontend/xiao_xun.html`：
- 删除卡片 actions 中的 `<button class="btn" onclick="runDedup()">去重检查</button>`
- 删除整个 `async function runDedup() {...}` 块
- 保留上传状态渲染里的 `f.status === "duplicate"`（那是文件上传 MD5 去重的状态展示，非手动检查）

**Step 2: 删除后端端点**

`app/routers/pipelines.py`：删除 `# ============ Candidate Dedup ============` 注释与 `api_dedup_candidates` 整个函数。

**Step 3: 删除脚本断言**

`scripts/test_all_buttons.py:198`：删除 `btn("runDedup (去重)", True, "route exists")` 一行。

**Step 4: 验证**

```bash
grep -rn "runDedup\|/dedup\|去重检查" frontend/ scripts/ app/ --include=*.py --include=*.html
```
Expected: 无残留（`app/db.py` 中 `fingerprint (for dedup check)` 注释、docs 营销文案除外）。

```bash
python scripts/test_all_buttons.py 2>&1 | tail -20
```
Expected: 不再出现 runDedup 行，其余按钮 OK/FAIL 与改动前一致。

**Step 5: Commit**

```bash
git add frontend/xiao_xun.html app/routers/pipelines.py scripts/test_all_buttons.py
git commit -m "refactor(dedup): 移除手动去重检查按钮与 /dedup 端点"
```

---

### Task 5: 存量重复只读统计脚本

**Files:**
- Create: `scripts/analyze_duplicates.py`

**Step 1: 编写脚本（只读，不写库）**

```python
# -*- coding: utf-8 -*-
"""存量人才库重复统计（只读）——按新去重策略扫描 resumes 表。
用法: python scripts/analyze_duplicates.py [--limit 20]
"""
import argparse, sys
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").abspath(__file__))))

from app.db import init_db, get_db
from app.talent_pool import _normalize_for_fingerprint, _normalize_phone


def main(limit: int):
    init_db()
    conn = get_db()
    rows = conn.execute("SELECT id, name, title, phone, email, current_company, source, fingerprint FROM resumes").fetchall()

    by_name_role = {}
    for r in rows:
        key = (_normalize_for_fingerprint(r["name"]), _normalize_for_fingerprint(r["title"]))
        if not key[0] or len(key[0]) < 2:
            continue
        by_name_role.setdefault(key, []).append(r)

    print(f"总简历数: {len(rows)}")
    groups = [(k, v) for k, v in by_name_role.items() if len(v) > 1]
    groups.sort(key=lambda kv: -len(kv[1]))
    print(f"按『姓名+岗位』重复组: {len(groups)} 组, 涉及 {sum(len(v) for _, v in groups)} 条记录")
    for (name, title), rs in groups[:limit]:
        print(f"  [{name} | {title}] x{len(rs)}")
        for r in rs:
            print(f"    - {r['id']} phone={r['phone'] or '-'} email={r['email'] or '-'} source={r['source'] or '-'}")
    print("说明: 本脚本只读，未修改任何数据。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=20)
    args = parser.parse_args()
    main(args.limit)
```

**Step 2: 运行**

```bash
python scripts/analyze_duplicates.py
```
Expected: 输出总简历数、重复组数、分组明细。

**Step 3: 汇报结果给用户，决定是否进入存量清理（另立任务）**

**Step 4: Commit**

```bash
git add scripts/analyze_duplicates.py
git commit -m "chore(dedup): 新增存量重复只读统计脚本"
```

---

### Task 6: 全量回归 + 文档清理

**Step 1: 全量测试**

```bash
python -m pytest tests/ -x -q
```
Expected: ALL PASS。若有与本改动无关的存量失败，单独列出说明（不阻塞）。

**Step 2: 手工冒烟（可选，需起服务）**

```bash
# 启动服务后：
curl -X POST http://localhost:8000/api/pipelines/<pid>/dedup   # 期望 404（端点已删）
# 人才库页面上传同一文件两次 → 第二次提示重复
```

**Step 3: 文档清理**

```bash
grep -rn "去重检查\|runDedup" docs/ TEST_GUIDE.md FRONTEND_ENHANCEMENTS.md README.md
```
如有过期描述（如 TEST_GUIDE 提到手动去重按钮），更新为"系统自动去重"。

**Step 4: Commit**

```bash
git add docs/ TEST_GUIDE.md FRONTEND_ENHANCEMENTS.md README.md
git commit -m "docs(dedup): 更新文档描述为系统自动去重"
```

---

## 执行中补充（代码质量审查结论，Task 1 commit 6c39fdf 后追加）

- **Task 3 附加改动**：`_dedup_by_name_and_role` 在 `save_resume` 热路径上每次全表 LIKE 扫描（`search_resumes_db(query=name, limit=20)`，OR 多字段 + LIMIT 20 可能把精确同名同岗记录挤出窗口，导致漏去重）。在模糊扫描前加精确快速路径：`SELECT id FROM resumes WHERE is_archived=0 AND name = ? AND title = ? AND tenant_id = ? LIMIT 1`，仅当未命中时回退到 LIKE 扫描。
- **Task 1 遗留 minor**（可并入 Task 3 顺手修）：`_normalize_phone` 补 `0086` 前缀处理（`elif p.startswith("0086") and len(p) == 15: p = p[3:]`）；占位名集合考虑补 "暂无"、"未提供"、"不详"。
- Task 2 已覆盖代码审查指出的 `routers/resumes.py` 忽略 save_resume 返回值的问题。
- 电话归一化不追溯旧数据：由姓名+岗位去重跨版本兜底，是否回填由 Task 5 统计结果决定。

## 执行中补充（Task 7：最终审查发现的缺口修复，commit 71fd045 + f37572f）

**最终整体审查发现**：主 UI 文件上传入口（`xiao_xun.html` → `upload-resumes` → `parse-resumes`）此前完全绕过去重系统——`api_parse_resumes` 规则解析后直接 `save_candidate`，不进人才库、不进 pending_resumes，且不触达匹配期 DedupAgent/跨批次查重；`api_batch_import_resumes` 同理。而 Task 4 恰好删除了该页面的"去重检查"按钮，用户最常用的上传路径面临"无手动按钮 + 无自动去重"的空窗。

**修复**（对齐 Task 2 模式）：
- `api_parse_resumes` / `api_batch_import_resumes` 在 `save_candidate` 前接入 `save_resume` 去重闸门；`duplicate` 时跳过不入流水线并计数（响应加 `duplicates`）；`skipped`（校验失败）不跳过照常入库；调用包 try/except 异常降级（对齐 resumes.py 约定）
- 本地导入经 `save_resume` 同时写入全局人才库（行为变化：人才池扩充、跨流水线可推荐）
- 前端 `xiao_xun.html` 展示"N 份重复跳过"与 ♻️ 明细
- 测试：`tests/test_parse_resumes_dedup.py` 4 用例（重复跳过/新人保留/批量导入重复跳过/skipped≠duplicate）

**计划假设修正**：原计划假设"全部入口都调用 save_resume"，实际 `parse-resumes`/`import-resumes` 是第三条直接 `save_candidate` 的路径——此类入口审核时应纳入"去重闸门接入"检查清单。

## 风险与取舍

| 取舍/风险 | 说明 | 缓解 |
|---|---|---|
| 同名同岗不同人会被合并 | 当前人才库字段有限（姓名+岗位），接受此取舍 | `_dedup_by_name_and_role` 仅命中完全一致的归一化姓名+岗位；指纹/疑似关联层仍保留 |
| 占位名误杀 | 插件导入可能产生"未知"姓名 | 姓名长度<2 或占位词集合直接跳过姓名去重 |
| 跨批次同名合并 | 同流水线同名不同人会被跳过 | 同一流水线通常同一岗位，同名不同人概率低；用户已确认"保留最完整+跳过其余" |
| 电话格式变体 | 影响指纹 | 新增 `_normalize_phone`（+86/86/空格/横线/全角） |
| 存量数据 | 未清理前仍含重复 | Task 5 统计后决定是否另立清理任务 |
