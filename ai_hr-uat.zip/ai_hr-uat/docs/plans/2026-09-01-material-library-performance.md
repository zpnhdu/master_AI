# 素材库图片加载性能优化实施计划

> **For implementer:** 全程使用 TDD：先写失败测试，再实现最小改动。

**目标：** 让小海素材库网格使用独立的小尺寸 WebP 缩略图，并消除 OSS 清单加载时逐张 HEAD 检查造成的串行等待。

**架构：** 上传素材时保留原图，同时在同一素材目录写入不超过 480px 的 WebP 缩略图，清单分别记录原图和缩略图对象键。已有 OSS 素材通过一次性脚本回填缩略图。清单读取通过一次 `list_keys` 建立对象键集合，校验原图和缩略图，不再对每条记录单独调用 `exists`。

**技术栈：** FastAPI、Pillow、OSS2、pytest。

---

### 任务 1：上传链路生成缩略图

**文件：**

- 修改：`app/routers/element_library.py`
- 测试：`tests/test_element_library.py`、`tests/test_element_library_oss.py`

**验证：** 上传后的 `thumb_url` 指向独立 WebP 文件，最长边不超过 480px；删除素材时原图和缩略图都被删除。

### 任务 2：OSS 清单消除逐张 HEAD

**文件：**

- 修改：`app/routers/element_library.py`
- 测试：`tests/test_element_library_oss.py`

**验证：** OSS 列表接口只调用一次 `list_keys`，不会对每一条素材调用 `exists`。

### 任务 3：回填已有 OSS 素材

**文件：**

- 新增：`scripts/generate_element_thumbnails.py`

**验证：** 在当前 OSS 清单中为缺少独立缩略图的素材写入 WebP 缩略图并更新清单；脚本不输出连接凭据。

### 任务 4：回归验证

**命令：**

```bash
.venv/bin/pytest tests/test_element_library.py tests/test_element_library_oss.py -q
.venv/bin/ruff check app/routers/element_library.py scripts/generate_element_thumbnails.py tests/test_element_library.py tests/test_element_library_oss.py
```

**验收：** 专项测试和 lint 通过；真实 `/api/xiao-hai/elements` 返回独立缩略图 URL，OSS 缩略图响应体积显著小于原图。

### 任务 5：复用缩略图能力到品牌、画布和参考图

**文件：**

- 新增：`app/image_thumbnails.py`
- 修改：`app/routers/element_library.py`、`app/brand_assets.py`、`app/db.py`、`app/routers/canvas_library.py`、`app/routers/xiao_hai.py`
- 修改：`frontend-react/src/features/config/api.ts`、`frontend-react/src/app/components/companyBrand.ts`
- 测试：`tests/test_image_thumbnails.py`、`tests/test_brand_assets.py`、`tests/test_canvas_library_oss.py`、`tests/test_xiao_hai_assets_oss.py`、前端品牌测试

**验证：** 列表接口只在 OSS 对象确实存在时返回缩略图 URL；品牌导航优先使用缩略图；原图 URL 和读取逻辑保持不变。

### 任务 6：回填现有品牌图片并验证缓存

**文件：**

- 修改：`scripts/generate_element_thumbnails.py`

**验证：** 当前 OSS 中存在的品牌栅格图生成缩略图；脚本重复运行无新增写入；清单缓存命中时不重复访问 OSS。
