# 面试中心表格化改版设计

## 目标

将 `MassDashboardPage`（React 路由 `/mass-dashboard`）从「监控看板 / 排名看板 / 面试日历」三个 tab 改为单页布局：KPI 统计条 + 一张候选人表格。删除 tab 与日历、排名卡片视图，监控与排名的信息合并进表格，候选人详情、简历预览、复试安排等交互全部保留。

## 布局

```
页头：[HR 筛选] [岗位选择] [日期范围] [去小评查看综合报告]（现有不动）
KPI：（已邀请=总数）（已打开）（答题中）（已完成）（已过期）  ← 可点击筛选
表格：姓名 │ 状态 │ 小评评分 │ 开始时间 │ 有效期 │ 操作
弹窗：候选人详情 / 简历预览 / 复试安排（全部保留）
```

## KPI 点击筛选

- 复用现有 `StatsBar`，卡片改为可点击 toggle：点击状态卡按状态筛选表格，再点一次取消；选中卡片高亮。
- 「已邀请」卡保持显示当前筛选范围内候选人总数（面试中心里的人都是被邀请过的，总数即已邀请人数）；点击效果为清除状态筛选、显示全部。
- 状态判定口径统一为 `splitMonitorRanking` 的分桶逻辑（`assessment_completed` 或 `completed/evaluated` 计入已完成；`started` 按 `current_question` 区分已打开/答题中），KPI 计数与行筛选共用同一函数，保证卡片数字 = 筛选后行数。

## 表格

复用 `shared/data-table/DataTable`，客户端模式，交互模式对齐人才库页：

- 列定义：
  - `姓名`（identity，fixed left）：头像 + 姓名，点击打开候选人详情弹窗。
  - `状态`：Tag，复用 `statusLabel` / `statusColor`。
  - `小评评分`：`interview_score ?? total_score ?? match_score`，无分显示 `—`，列带 `sorter` 客户端排序。
  - `开始时间`：`started_at`，复用 `formatDateTime`。
  - `有效期`：`expires_at`，复用 `formatExpiry`。
  - `操作`（actions，fixed right）。
- 行内操作按状态显示，全部沿用现有 handler：
  - 所有行：`详情`、`简历`。
  - 所有行（与旧排名看板一致，不区分状态）：`通过` / `复试` / `淘汰`；复试弹现有复试安排表单，淘汰保留确认弹窗。
  - `已邀请` / `已过期`：`复制链接` / `发邮件`（沿用 `copyInvite` / `sendEmail`）。
  - `答题中` / `已打开`：`停止直播`（沿用 `kickStream`，仅在有直播流时显示）。
- 搜索：`searchableText` 按候选人姓名搜索；结果计数显示当前行数，承担「总数」信息。

## 删除内容

- `MassDashboardPage.tsx`：`PageTabs` 与 `DashboardTab` / `tab` state；`MonitorView`、`RankingView`、`CalendarView`、`CandidateCard`、`RankingCard`；`filter` / `trendFilter` / `redFlagOnly` state；`useMassSchedulesQuery` 与 `MassSchedule` 引用；`hasError` / `loading` 中的 calendar 分支；仅被上述代码使用的辅助函数与 import。
- `MassDashboardPage.components.tsx`：`SectionHeading`、`VideoThumbnail`、`WrittenTestThumbnail`（只被卡片墙使用）；`StatsBar` 保留并改造为可点击。
- `MassDashboardPage.selectors.ts`：`splitMonitorRanking` 保留（KPI/筛选共用），删除仅服务旧视图的 `matchesRankingFilter`、`sortRankingByScore`、`completedVideoThumbnailSource`、`isWrittenTestCandidate`（视测试引用情况，被测试引用的同步调整）。
- `styles/70-mass-dashboard.css`：删除 `mass-monitor`、`mass-ranking`、`mass-calendar`、`rank-card` 相关段落；新增 KPI 选中态与表格状态列样式。

## 数据流

- Query 保持不变：pipelines / status / streams / ranking / assessmentQueue / candidateReports；WebSocket `/ws/mass-monitor/{pipelineId}` 实时失效逻辑不动。
- 页面计算链：`ranking → enrichMassRanking → filterRankingByDate(顶部日期范围) → summarizeRankingStats(KPI) → 状态筛选(点击的 KPI 卡) → DataTable`。
- 行内 mutation（mark / kick / invite）与成功后的失效、提示逻辑不动。

## 错误与边界

- 无岗位：保留现有「暂无面试数据」空状态。
- 加载/错误态沿用现有分支，去掉 calendar 相关条件。
- 表格空数据区分「无数据」与「筛选后为空」（DataTable 自带能力，清除筛选按钮会同时重置 KPI 选中态）。

## 测试策略

- `MassDashboardPage.test.tsx`：
  - 删除「loads schedules only after opening the calendar tab」。
  - monitor / ranking 两条用例改写为表格断言：列渲染、KPI 点击筛选行数、行内操作（通过/复试/淘汰、复制链接/发邮件、停止直播）。
  - 停止直播、简历预览等现有用例的定位器从卡片改为表格行。
- selectors 测试：调整被删除导出的用例，为 KPI 与筛选共用的状态分桶补断言。
- 验收：Vitest 全量、`tsc`、Vite build、浏览器冒烟（KPI 筛选、行内操作、弹窗）。

## 非目标

- 不改后端接口与 WebSocket 协议。
- 不迁移旧版 `mass-dashboard.html` 的日历/排名视图（直接下线，不保留入口）。
- 不新增推荐等级、红旗、趋势筛选（随排名看板一并删除）。
