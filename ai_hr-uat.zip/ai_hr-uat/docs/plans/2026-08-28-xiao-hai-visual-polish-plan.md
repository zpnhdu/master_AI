# 小海海报工作台视觉优化实施计划

> **For implementer:** 先写行为测试，再实现最小改动；每完成一组改动都运行受影响的验证命令。

**目标：** 完成小海海报工作台的布局、状态、按钮、色彩、对话和响应式视觉优化。

**架构：** 保持 XiaoHaiPage 的数据流和 ConversationPanel API 不变，通过增加版本导航区域、有限的语义 class 和小海作用域 CSS 完成改造；仅在 PosterResult 中调整按钮语义和状态文案。

**技术栈：** React 19、TypeScript、Ant Design 6、Vitest、Vite。

---

### Task 1：三栏版本导航布局

**文件：**
- 修改：`frontend-react/src/app/pages/XiaoHaiPage.tsx`
- 修改：`frontend-react/src/styles.css`
- 测试：`frontend-react/src/app/pages/XiaoHaiPage.test.tsx`

**行为：** 桌面端版本记录位于工作台左侧；移动端仍位于海报下方并可横向滚动。

**验证：** `pnpm --dir frontend-react test:run -- src/app/pages/XiaoHaiPage.test.tsx`

### Task 2：海报卡片和响应式可视性

**文件：**
- 修改：`frontend-react/src/app/pages/XiaoHaiPage.tsx`
- 修改：`frontend-react/src/styles.css`

**行为：** 确认海报成为唯一主操作；预览舞台在移动端保持最小高度；顶部状态与卡片状态一致。

**验证：** `pnpm --dir frontend-react typecheck`

### Task 3：对话、快捷指令和状态色

**文件：**
- 修改：`frontend-react/src/app/pages/XiaoHaiPage.tsx`
- 修改：`frontend-react/src/styles.css`
- 修改：`frontend-react/src/features/conversations/ConversationPanel.tsx`
- 修改：`frontend-react/src/features/xiao-hai/XiaoHaiCommandCard.tsx`

**行为：** 对话消息层级更清晰，快捷指令可见，失败命令保留直接重试；发送和高频操作达到可触达尺寸。

**验证：** `pnpm --dir frontend-react test:run -- src/app/pages/XiaoHaiPage.test.tsx src/features/xiao-hai/MaterialPicker.test.tsx`

### Task 4：整体验证

**文件：** 无新增文件。

**命令：**
- `pnpm --dir frontend-react typecheck`
- `pnpm --dir frontend-react test:run`
- `pnpm --dir frontend-react build`

**验收：** 使用浏览器检查桌面、平板和 375px 移动视口，确认无控制台错误且海报预览可读。
