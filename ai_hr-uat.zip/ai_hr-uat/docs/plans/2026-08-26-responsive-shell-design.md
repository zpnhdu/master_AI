# 响应式公共壳层设计

## 目标

统一后台页面在小屏幕下的公共布局行为，减少页面各自维护断点和固定尺寸的重复逻辑，同时保留小文、小面等多面板工作台的业务专属切换。

## 架构

- `AppShell` 负责导航栏的响应式收缩，使用 Ant Design Sider 的 `breakpoint` / `collapsedWidth`，不通过 CSS 覆盖组件的 flex 尺寸。
- `PageShell` 负责统一页面内边距、标题与操作区的换行契约；页面自己的业务内容继续由页面 CSS 控制。
- 全局 CSS 提供视口高度、安全区、页面 gutter 和表格横向滚动的公共规则；页面专属工作台继续使用自己的断点。

## 边界

- 不新增运行时 viewport hook；纯布局使用 CSS，只有需要改变业务视图时才使用现有 React 状态。
- 不重构现有小文、小面移动端面板切换。
- 不删除并行工作区已有的 AgentTwoColumnLayout 改动。

## 测试策略

- 组件单元测试验证 Sider 响应式参数和 PageShell 操作区 class 契约。
- Playwright 在 `390x844`、`768x1024`、`1366x768` 下验证 Studio 页面无整体横向溢出，并验证窄屏导航收缩。
- 运行项目已有 `typecheck`、`test:run` 和必要的 Playwright 冒烟测试。
