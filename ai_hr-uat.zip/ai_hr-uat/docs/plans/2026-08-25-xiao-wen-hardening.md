# 小文流程统一与性能治理实施计划

> **For implementer:** 每个任务先写失败测试，再实现最小改动；不做无关重构。

**目标：** 统一小文生成 JD、修改 JD、生成画像的上下文和状态边界，降低模型调用次数，并保证无关输入不会误改 JD。

**架构：** 以 pipeline 的 `role/type/context` 和当前 JD revision 为唯一事实来源。所有小文入口复用同一运行上下文；JD 自然语言修改只输出受白名单约束的 Patch，由服务端合并、校验并等待确认。画像只基于已确认 JD 生成，并按 revision/hash 复用。

**技术栈：** Python/FastAPI/Pydantic/pytest，React/TypeScript/Vitest。

---

### 任务 1：统一小文运行上下文和 Agent 配置

**文件：**

- 创建：`app/xiao_wen_context.py`
- 修改：`app/services.py`、`hr_harness/orchestrator.py`、`hr_harness/dag_engine.py`
- 修改：`hr_harness/agents/base.py`、`hr_harness/agents/jd_agent.py`、`hr_harness/agents/profile_agent.py`
- 测试：`tests/test_xiao_wen_context.py`、相关 Agent 测试

**验收：** `kg_context`、`company_config`、`pipeline_type`、`quiz_answers` 能进入 JDAgent/ProfileAgent；数据库中的模型、温度和超时配置实际生效；结构化调用启用 JSON mode。

### 任务 2：统一 JD/画像入口

**文件：**

- 修改：`app/routers/pipelines.py`、`app/action_handler.py`
- 测试：`tests/test_jd_workspace.py`、新增入口一致性测试

**验收：** 自动生成、手动生成、重新生成、画像生成使用同一上下文和岗位类型；固定岗位预设时不再额外调用流水线规划模型。

### 任务 3：JD Patch 修改和无关输入拦截

**文件：**

- 修改：`app/jd_workspace.py`、`app/action_handler.py`、`app/routers/pipelines.py`
- 修改：`frontend-react/src/features/xiao-wen/api.ts`、`useXiaoWenController.ts`
- 测试：`tests/test_jd_workspace.py`、`frontend-react/src/features/xiao-wen/*.test.ts*`

**验收：** 模型只返回字段 Patch；未知字段被拒绝；天气/闲聊返回 no-op 且不保存；所有旧入口均经过预览和确认；服务端校验不能被前端绕过。

### 任务 4：revision、下游失效、并发和权限

**文件：**

- 修改：`app/jd_workspace.py`、`app/routers/pipelines.py`、`app/routers/candidates.py`
- 测试：`tests/test_jd_workspace.py`、新增并发/权限测试

**验收：** 同一 pipeline 只能有一个后台自动任务；JD 修改按字段失效下游；旧结果不能以旧 revision 传递；`/api/action` 校验 pipeline 所有权。

### 任务 5：回归验证和观测

**文件：**

- 修改：`hermes_wrapper/client.py`、相关日志调用点
- 测试：Python 及前端小文测试

**验收：** 日志能按 Agent/operation 区分模型调用、耗时、token 和重试；覆盖无关输入、错误模型输出、超时和 revision 冲突。
