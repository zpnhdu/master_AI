# 小寻 React 迁移设计

## 目标

将 `frontend/xiao_xun.html` 的完整业务能力迁移到 React 路由 `/xiao-xun`，保留旧入口兼容跳转、权限校验和开关回退，同时不修改旧版页面。

## 架构

- 页面层：新增 `XiaoXunPage`，保持 Agent 三栏工作台结构；顶部、返回流水线和 Agent 跳转沿用现有小文工作台的交互约定，但小寻使用独立文案和视觉标识。
- 数据层：新增 `features/xiao-xun/api.ts`、`hooks.ts`、`selectors.ts`。服务端数据由 TanStack Query 管理；文件选择、筛选条件、选择集合等短生命周期交互状态保留在页面或 feature hook 中。
- 入口层：在 React Router 增加 `/xiao-xun`；FastAPI 将 `/frontend/xiao_xun.html` 映射到新路由并保留 `pipeline` 查询参数，构建缺失或 `FRONTEND_APP_ENABLED=0` 时回退旧页面。

## 组件职责

- `XiaoXunTopbar`：返回流水线、当前岗位、Agent 状态和流程导航。
- `XiaoXunArtifactsPanel`：展示候选人来源、已上传文件和候选人产物摘要。
- `ResumeUploadCard`：文件拖拽/选择、50 份与 10MB 限制、文件列表、上传与清空。
- `ResumeProcessCard`：上传结果、解析结果、失败/重复原因、联系方式异常提醒和继续上传。
- `TalentPoolImportCard`：JD 条件、手动必选条件、匹配宽严度、结果分组、地区/来源/更新时间筛选、候选人详情和批量导入。
- `XiaoXunDashboard`：文件总数、解析成功、待处理、来源和格式概况。
- 页面仅编排组件和 mutation/query，API 归一化及筛选规则不放在 JSX 中。

## 数据流

1. 页面从 `pipeline` 查询岗位详情，读取 `crawl` 阶段和候选人，计算初始处理概况。
2. 上传使用 `POST /api/pipelines/{id}/upload-resumes`，成功后自动调用 `POST /api/pipelines/{id}/parse-resumes`。
3. 上传/解析完成后失效流水线详情 query，刷新候选人、阶段和右侧概况。
4. 人才库入口先读取人才库统计、邮箱同步状态和当前岗位匹配条件；匹配调用 `GET /api/talent-pool/recommend/{id}`。
5. 批量导入调用 `POST /api/talent-pool/recommend/{id}/accept`，成功后刷新流水线并保留可继续选择/前往小筛的下一步。
6. 传递下游调用现有 `/api/pipelines/{id}/pass-artifact`，目标 Agent 使用流水线配置计算，不硬编码跳转逻辑。

## 错误与边界

- 缺少 `pipeline` 参数时显示可返回 Studio 的空状态。
- 401、403、404、422、500、超时和网络错误均显示可见提示与重试；不吞掉上传和解析错误。
- 文件在前端拦截扩展名、数量和大小限制；后端逐文件返回的成功、重复、失败结果原样归一化展示。
- 人才库为空、JD 未完成、没有匹配结果、全部候选人已导入都提供明确空状态。
- 上传和批量导入期间禁用重复提交，组件卸载后不更新已取消的请求状态。

## 测试策略

- API 测试覆盖响应归一化、错误码、FormData 上传、匹配查询参数和批量导入请求体。
- selector 测试覆盖解析统计、候选人来源、条件构造、结果筛选和文件限制。
- 页面测试覆盖初始状态、上传后自动解析、人才库匹配筛选、批量导入和下游跳转。
- FastAPI 测试覆盖旧入口跳转、查询参数保留、开关回退和 `pipeline:read` 权限。
- 最终运行前端全量 Vitest、TypeScript、Vite build，以及浏览器冒烟。

## 非目标

- 不迁移小筛页面本身；“传递给小筛”仍跳转现有 Agent 入口。
- 不重写人才库后端匹配算法、邮箱同步或简历解析服务。
- 不删除或重构旧版 `frontend/xiao_xun.html` 与共享旧版脚本。
