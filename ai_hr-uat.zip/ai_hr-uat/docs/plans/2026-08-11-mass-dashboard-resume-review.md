# 面试排名看板简历人工审核 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 为排名看板每位候选人增加简历预览，并形成“查看材料后再决策”的人工审核流程。

**Architecture:** `mass-dashboard.html` 使用现有候选人 API 按需加载简历数据，并复用当前详情弹窗承载简历与面试评估两个页签。选择复试时由现有 mark 接口在一个数据库事务中保存排期和复试状态，避免两个请求产生部分成功。新增静态交互契约测试和事务回滚测试。

**Tech Stack:** HTML、CSS、原生 JavaScript、pytest 静态契约测试。

---

### Task 1: 锁定简历审核交互契约

**Files:**
- Create: `tests/test_mass_dashboard_resume_review.py`
- Test: `tests/test_mass_dashboard_resume_review.py`

**Step 1: Write the failing test**

测试应断言：

- 排名卡片始终渲染“预览简历”。
- 页面提供 `showCandidateResume` 和候选人简历加载逻辑。
- 详情弹窗提供“简历 / 面试评估”页签。
- 存在“暂无完整简历”、加载失败和重试状态。
- 决策文案为“进入录用评估 / 选择复试 / 淘汰”，并提供“更改决定”。

**Step 2: Run test — confirm it fails**

Command: `pytest -q tests/test_mass_dashboard_resume_review.py`

Expected: FAIL，因为页面尚无简历预览入口和审核页签。

**Step 3: Commit**

本仓库要求提交前获得用户确认，本次不提交。

### Task 2: 实现卡片证据操作和简历预览

**Files:**
- Modify: `frontend/mass-dashboard.html`
- Modify: `app/routers/mass_interview.py`
- Test: `tests/test_mass_dashboard_resume_review.py`
- Test: `tests/test_mass_interview_mark_schedule.py`

**Step 1: Write minimal implementation**

- 为卡片操作区增加证据/决策分组和分隔线。
- 所有候选人显示“预览简历”，有录像时显示“面试回放”。
- 增加候选人按需加载与缓存。
- 将详情弹窗扩展为简历和面试评估页签。
- 提供简历加载、空数据、失败和重试状态。

**Step 2: Run test — confirm it passes**

Command: `pytest -q tests/test_mass_dashboard_resume_review.py`

Expected: PASS。

### Task 3: 收敛人工决策流程

**Files:**
- Modify: `frontend/mass-dashboard.html`
- Test: `tests/test_mass_dashboard_resume_review.py`

**Step 1: Write minimal implementation**

- 将决策文案改成“进入录用评估 / 选择复试 / 淘汰”。
- 在审核弹窗底部增加固定决策区。
- 已有决定显示状态和“更改决定”，更改前恢复决策可用状态。
- 选择复试时先完成安排选择，再通过同一请求事务化保存排期和复试决定；“稍后安排”只保存复试状态。

**Step 2: Run test — confirm it passes**

Command: `PYTHONPATH=. pytest -q tests/test_mass_dashboard_resume_review.py tests/test_mass_interview_mark_schedule.py`

Expected: PASS。

### Task 4: 格式和回归验证

**Files:**
- Verify: `frontend/mass-dashboard.html`
- Verify: `tests/test_mass_dashboard_resume_review.py`

**Step 1: Run target tests**

Command: `PYTHONPATH=. pytest -q tests/test_mass_dashboard_resume_review.py tests/test_mass_interview_mark_schedule.py tests/test_mass_interview_scoring_safety.py`

Expected: PASS。

**Step 2: Run target formatting check**

Command: `npx prettier --check frontend/mass-dashboard.html`

Expected: PASS。

**Step 3: Review diff**

Command: `git diff -- frontend/mass-dashboard.html app/routers/mass_interview.py tests/test_mass_dashboard_resume_review.py tests/test_mass_interview_mark_schedule.py docs/plans/2026-08-11-mass-dashboard-resume-review-design.md docs/plans/2026-08-11-mass-dashboard-resume-review.md`

Expected: 仅包含本功能相关改动。
