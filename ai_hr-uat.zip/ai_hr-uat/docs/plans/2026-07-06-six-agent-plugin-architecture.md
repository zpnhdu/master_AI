# 六 Agent 插件化架构 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 将现有 AI HR 系统重构为 Dify 模式的六 agent 插件化架构，配合调度管理面板。

**Architecture:** Tool 协议标准化 (ToolInput/ToolOutput) → BaseAgent 接口升级 → LLM 调用回迁 → DAG 执行器 → Admin API + 前端面板 → 迁移验证。

**Tech Stack:** Python 3, FastAPI, pytest (SQLite in-memory), vanilla HTML/CSS/JS, hermes_wrapper

**Design Doc:** `~/.gstack/projects/shanghai-ai-hr-demo/zhoulin-hr_agent_demo-design-20260706-150504.md`

---

## Task 1: Tool Protocol — 定义 ToolInput/ToolOutput/ToolConfig/AgentStatus

**Files:**
- Create: `hr_harness/tool_protocol.py`
- Create: `tests/test_tool_protocol.py`

### Step 1: Write the failing test

File: `tests/test_tool_protocol.py`

```python
"""Tests for Tool Protocol — standardized agent input/output/config types"""
import pytest
import time
from hr_harness.tool_protocol import ToolInput, ToolOutput, ToolConfig, AgentStatus


class TestToolInput:
    def test_default_construction(self):
        """ToolInput should construct with minimal fields and default empty dicts"""
        ti = ToolInput(pipeline_id="p1")
        assert ti.pipeline_id == "p1"
        assert ti.candidate_id is None
        assert ti.params == {}
        assert ti.context == {}

    def test_full_construction(self):
        """ToolInput should accept all fields including nested context"""
        ti = ToolInput(
            pipeline_id="p1",
            candidate_id="c1",
            params={"role": "engineer"},
            context={"jd_writer": {"jd_text": "..."}, "profile_build": {"profile": {...}}}
        )
        assert ti.candidate_id == "c1"
        assert ti.params["role"] == "engineer"
        assert "jd_writer" in ti.context

    def test_context_is_cumulative_pipeline_state(self):
        """context field should carry outputs from all prior stages, keyed by stage_id"""
        ti = ToolInput(
            pipeline_id="p1",
            context={
                "jd_writer": {"jd_text": "Senior Engineer JD"},
                "profile_build": {"dimensions": {"tech": 8, "culture": 7}},
            }
        )
        assert len(ti.context) == 2
        assert ti.context["jd_writer"]["jd_text"] == "Senior Engineer JD"


class TestToolOutput:
    def test_success_output(self):
        """SUCCESS status with data payload"""
        to = ToolOutput(status=AgentStatus.SUCCESS, data={"result": "ok"}, tokens_used=150, duration_ms=1200)
        assert to.status == AgentStatus.SUCCESS
        assert to.data["result"] == "ok"
        assert to.error is None
        assert to.tokens_used == 150
        assert to.duration_ms == 1200

    def test_failed_output(self):
        """FAILED status with error message"""
        to = ToolOutput(status=AgentStatus.FAILED, error="LLM timeout after 120s", tokens_used=0, duration_ms=120000)
        assert to.status == AgentStatus.FAILED
        assert to.error == "LLM timeout after 120s"
        assert to.data == {}

    def test_needs_human_output(self):
        """NEEDS_HUMAN status for manual review required"""
        to = ToolOutput(status=AgentStatus.NEEDS_HUMAN, data={"review_reason": "ambiguous match"}, logs=["confidence below threshold"])
        assert to.status == AgentStatus.NEEDS_HUMAN
        assert "ambiguous match" in to.data["review_reason"]

    def test_default_values(self):
        """Default values: empty data, no error, zero tokens/duration, empty logs"""
        to = ToolOutput(status=AgentStatus.IDLE)
        assert to.data == {}
        assert to.error is None
        assert to.tokens_used == 0
        assert to.duration_ms == 0
        assert to.logs == []

    def test_logs_are_preserved(self):
        """Logs list should preserve entries in order"""
        to = ToolOutput(status=AgentStatus.RUNNING, logs=["Starting LLM call", "Received response", "Parsing JSON"])
        assert len(to.logs) == 3


class TestToolConfig:
    def test_default_config(self):
        """Default ToolConfig with minimum fields"""
        tc = ToolConfig(agent_id="jd_writer", agent_name="小文", display_name="JD撰写与画像生成")
        assert tc.agent_id == "jd_writer"
        assert tc.agent_name == "小文"
        assert tc.model == "qwen3.6-flash"
        assert tc.complexity == "plus"
        assert tc.temperature == 0.7
        assert tc.timeout == 120
        assert tc.retry_count == 2
        assert tc.enabled is True
        assert tc.human_approval is False

    def test_custom_config(self):
        """Custom ToolConfig overrides defaults"""
        tc = ToolConfig(
            agent_id="interview",
            agent_name="小面",
            display_name="面试出题与评估",
            model="qwen-plus",
            complexity="max",
            temperature=0.3,
            timeout=180,
            retry_count=3,
            enabled=True,
            human_approval=True,
        )
        assert tc.model == "qwen-plus"
        assert tc.complexity == "max"
        assert tc.temperature == 0.3
        assert tc.timeout == 180
        assert tc.retry_count == 3
        assert tc.human_approval is True


class TestAgentStatus:
    def test_all_statuses_defined(self):
        """All five status values should be valid enum members"""
        statuses = [AgentStatus.IDLE, AgentStatus.RUNNING, AgentStatus.SUCCESS, AgentStatus.FAILED, AgentStatus.NEEDS_HUMAN]
        for s in statuses:
            assert isinstance(s, AgentStatus)

    def test_status_comparison(self):
        """Status comparison should work as expected"""
        assert AgentStatus.SUCCESS != AgentStatus.FAILED
        assert AgentStatus.IDLE == AgentStatus.IDLE
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_tool_protocol.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'hr_harness.tool_protocol'`

### Step 3: Write minimal implementation

File: `hr_harness/tool_protocol.py`

```python
"""Tool Protocol — standardized agent input/output/config types (Dify-pattern)"""
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from enum import Enum


class AgentStatus(Enum):
    """Agent execution status — maps to Dify's node execution states"""
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    NEEDS_HUMAN = "needs_human"


@dataclass
class ToolInput:
    """Standardized agent input.

    context carries a pipeline-level cumulative context — the union of all
    prior stages' ToolOutput.data, keyed by stage_id. Downstream agents
    can read any upstream stage's output from this dict.
    """
    pipeline_id: str
    candidate_id: Optional[str] = None
    params: Dict[str, Any] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolOutput:
    """Standardized agent output.

    status indicates the outcome. data carries the payload on SUCCESS.
    error carries the failure reason on FAILED. tokens_used and duration_ms
    enable cost tracking. logs carry per-step progress messages.
    """
    status: AgentStatus
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    tokens_used: int = 0
    duration_ms: int = 0
    logs: List[str] = field(default_factory=list)


@dataclass
class ToolConfig:
    """Per-agent independent configuration. Stored in DB, read before each call.

    agent_id matches the stage_id key in agent_registry (e.g. 'jd_writer').
    agent_name is the short name (小文/小海/etc). display_name is the
    human-readable label shown in the admin panel.
    """
    agent_id: str
    agent_name: str
    display_name: str
    model: str = "qwen3.6-flash"
    complexity: str = "plus"
    temperature: float = 0.7
    timeout: int = 120
    retry_count: int = 2
    enabled: bool = True
    human_approval: bool = False
```

### Step 4: Run test — confirm it passes

```bash
pytest tests/test_tool_protocol.py -v
```

Expected: PASS — 10 tests pass

### Step 5: Commit

```bash
git add hr_harness/tool_protocol.py tests/test_tool_protocol.py && git commit -m "feat(hr_harness): add Tool protocol types — ToolInput, ToolOutput, ToolConfig, AgentStatus"
```

---

## Task 2: BaseAgent — 重构 execute() → run(ToolInput) → ToolOutput

**Files:**
- Modify: `hr_harness/agents/base.py`
- Modify: 17 agent files (jd_agent, profile_agent, poster_agent, match_agent, interview_agent, video_agent, report_agent, crawl_agent, rpa_agent, dedup_agent, quiz_agent, knowledge_card_agent, candidate_assistant, interview_copilot, outreach_agent, plus scheduling.py in hr_harness/)
- Modify: `hr_harness/orchestrator.py` (update call sites)
- Create: `tests/test_agent_migration.py`

### Step 1: Write the failing test

File: `tests/test_agent_migration.py`

```python
"""Tests for agent interface migration: execute(context:Dict)->Dict → run(ToolInput)->ToolOutput"""
import pytest
import time
from unittest.mock import AsyncMock, patch
from hr_harness.tool_protocol import ToolInput, ToolOutput, ToolConfig, AgentStatus
from hr_harness.agents.base import BaseAgent


class FakeLLMClient:
    """Fake LLM client for testing — returns controlled responses"""
    async def chat(self, req):
        class Resp:
            content = '{"result": "ok", "score": 85}'
            error = None
        return Resp()

    async def chat_json(self, req):
        return {"result": "ok", "score": 85}


class StubAgent(BaseAgent):
    """Minimal agent implementation for testing the BaseAgent interface"""
    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        try:
            result = await self.call_llm_json(f"Process: {input.params}")
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data=result,
                tokens_used=50,
                duration_ms=int((time.time() - start) * 1000),
                logs=["LLM call completed"],
            )
        except Exception as e:
            return ToolOutput(
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )


class TestBaseAgentRun:
    """Test the new run(ToolInput)->ToolOutput interface"""

    @pytest.fixture
    def agent(self):
        agent = StubAgent()
        # Inject fake LLM client to avoid real API calls
        agent.llm = FakeLLMClient()
        return agent

    @pytest.mark.asyncio
    async def test_run_returns_tooloutput_on_success(self, agent):
        """run() should return ToolOutput with SUCCESS status and data"""
        ti = ToolInput(pipeline_id="p1", params={"role": "engineer"})
        result = await agent.run(ti)
        assert isinstance(result, ToolOutput)
        assert result.status == AgentStatus.SUCCESS
        assert result.data["result"] == "ok"

    @pytest.mark.asyncio
    async def test_run_tracks_tokens_and_duration(self, agent):
        """run() should populate tokens_used and duration_ms"""
        ti = ToolInput(pipeline_id="p1")
        result = await agent.run(ti)
        assert result.tokens_used > 0
        assert result.duration_ms > 0

    @pytest.mark.asyncio
    async def test_run_handles_llm_timeout(self, agent):
        """run() should return FAILED when LLM call raises an exception"""
        async def failing_chat_json(req):
            raise Exception("Connection timeout")
        agent.llm.chat_json = failing_chat_json
        ti = ToolInput(pipeline_id="p1")
        result = await agent.run(ti)
        assert result.status == AgentStatus.FAILED
        assert "Connection timeout" in result.error

    @pytest.mark.asyncio
    async def test_run_with_empty_context(self, agent):
        """run() should work with empty context dict"""
        ti = ToolInput(pipeline_id="p1", context={})
        result = await agent.run(ti)
        assert result.status == AgentStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_run_returns_valid_tooloutput_even_on_error(self, agent):
        """run() must always return a valid ToolOutput, never raise"""
        async def exploding(req):
            raise RuntimeError("Unexpected failure")
        agent.llm.chat_json = exploding
        ti = ToolInput(pipeline_id="p1")
        result = await agent.run(ti)
        assert isinstance(result, ToolOutput)
        assert result.status == AgentStatus.FAILED
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_agent_migration.py -v
```

Expected: FAIL — `AttributeError: 'StubAgent' object has no attribute 'run'` or the test calling `agent.run()` fails

### Step 3: Write minimal implementation

File: `hr_harness/agents/base.py` — add run() method:

```python
"""Base agent class — uses hermes_wrapper for LLM calls"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Callable, Optional
import time
from hermes_wrapper.client import get_client
from hermes_wrapper.models import LLMRequest
from hr_harness.tool_protocol import ToolInput, ToolOutput, AgentStatus


class BaseAgent(ABC):
    """Base class — each agent uses hermes_wrapper for LLM calls"""

    def __init__(self):
        self.llm = get_client()

    @abstractmethod
    async def run(self, input: ToolInput) -> ToolOutput:
        """Execute the agent with standardized input/output.
        
        Each agent must implement this method. Subclasses should:
        1. Record start time
        2. Call call_llm() or call_llm_json() as needed
        3. Return ToolOutput with appropriate status, data, error, tokens, duration
        
        The default implementation pattern:
        ```
        start = time.time()
        try:
            result = await self.call_llm_json(prompt, system)
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data=result,
                tokens_used=...,  # estimate or track
                duration_ms=int((time.time() - start) * 1000),
                logs=["LLM call completed"],
            )
        except Exception as e:
            return ToolOutput(
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )
        ```
        """
        ...

    async def call_llm(self, prompt: str, system: str = "", complexity: str = "plus", temperature: float = None) -> str:
        """Async LLM call via hermes_wrapper"""
        req = LLMRequest(
            prompt=prompt,
            system=system,
            complexity=complexity,
        )
        if temperature is not None:
            req.temperature = temperature
        resp = await self.llm.chat(req)
        if resp.error:
            return f"[LLM Error: {resp.error}]"
        return resp.content

    async def call_llm_json(self, prompt: str, system: str = "", complexity: str = "plus",
                            temperature: float = None, validator: Optional[Callable] = None,
                            max_retries: int = 2, timeout: int = None) -> dict:
        """Call LLM and parse JSON response with optional validation and retry."""
        last_result = None
        for attempt in range(max_retries + 1):
            req = LLMRequest(
                prompt=prompt,
                system=system,
                complexity=complexity,
            )
            if temperature is not None:
                req.temperature = temperature
            if timeout is not None:
                req.timeout = timeout
            result = await self.llm.chat_json(req)
            last_result = result
            if validator is None:
                return result
            if result is None or (isinstance(result, dict) and not result):
                if attempt < max_retries:
                    prompt = prompt + "\n\n【修正要求】上一次未能生成有效JSON输出，请严格按照要求的格式重新输出。"
                    continue
                return last_result
            try:
                if validator(result):
                    return result
            except Exception:
                pass
            if attempt < max_retries:
                prompt = prompt + "\n\n【修正要求】上一次输出不符合格式要求或内容不完整，请严格按照要求重新输出，确保所有必填字段都存在且格式正确。"
        return last_result
```

### Step 4: Run test — confirm it passes

```bash
pytest tests/test_agent_migration.py -v
```

Expected: PASS — 5 tests pass

### Step 5: Commit

```bash
git add hr_harness/agents/base.py tests/test_agent_migration.py && git commit -m "feat(hr_harness): add BaseAgent.run(ToolInput)->ToolOutput abstract method"
```

---

## Task 3: 迁移 17 个 Agent — execute() → run()

**Files:**
- Modify: all 17 agent files in `hr_harness/agents/`
- Modify: `hr_harness/orchestrator.py` (call sites)
- Create: `tests/test_agent_run_methods.py`

### Step 1: Write the failing test

File: `tests/test_agent_run_methods.py`

```python
"""Verify all concrete agents implement the run(ToolInput)->ToolOutput interface"""
import pytest
import inspect
from hr_harness.tool_protocol import ToolInput, ToolOutput, AgentStatus
from hr_harness.agents.base import BaseAgent


# List all agent classes that must implement run()
AGENT_CLASSES = [
    ("hr_harness.agents.jd_agent", "JDAgent"),
    ("hr_harness.agents.profile_agent", "ProfileAgent"),
    ("hr_harness.agents.poster_agent", "PosterAgent"),
    ("hr_harness.agents.match_agent", "MatchAgent"),
    ("hr_harness.agents.interview_agent", "InterviewAgent"),
    ("hr_harness.agents.video_agent", "VideoAgent"),
    ("hr_harness.agents.report_agent", "ReportAgent"),
    ("hr_harness.agents.crawl_agent", "CrawlAgent"),
    ("hr_harness.agents.rpa_agent", "RPAAgent"),
    ("hr_harness.agents.dedup_agent", "DedupAgent"),
    ("hr_harness.agents.quiz_agent", "QuizAgent"),
    ("hr_harness.agents.knowledge_card_agent", "KnowledgeCardAgent"),
    ("hr_harness.agents.candidate_assistant", "CandidateAssistantAgent"),
    ("hr_harness.agents.interview_copilot", "InterviewCopilot"),
    ("hr_harness.agents.outreach_agent", "OutreachAgent"),
    ("hr_harness.scheduling", "SchedulingAgent"),
]


def _import_agent(module_path, class_name):
    import importlib
    mod = importlib.import_module(module_path)
    return getattr(mod, class_name)


@pytest.mark.parametrize("module_path,class_name", AGENT_CLASSES)
def test_agent_inherits_base_agent(module_path, class_name):
    """Every agent class must inherit from BaseAgent"""
    agent_cls = _import_agent(module_path, class_name)
    assert issubclass(agent_cls, BaseAgent), f"{class_name} does not inherit BaseAgent"


@pytest.mark.parametrize("module_path,class_name", AGENT_CLASSES)
def test_agent_has_run_method(module_path, class_name):
    """Every agent class must define an async run(ToolInput) -> ToolOutput method"""
    agent_cls = _import_agent(module_path, class_name)
    assert hasattr(agent_cls, "run"), f"{class_name} missing run() method"
    method = getattr(agent_cls, "run")
    assert inspect.iscoroutinefunction(method), f"{class_name}.run() is not async"
    # Check signature accepts ToolInput
    sig = inspect.signature(method)
    params = list(sig.parameters.keys())
    assert "input" in params or "self" in params, f"{class_name}.run() should accept 'input' parameter"


@pytest.mark.parametrize("module_path,class_name", AGENT_CLASSES)
def test_agent_no_longer_has_execute_method(module_path, class_name):
    """After migration, agents should NOT have the old execute() method"""
    agent_cls = _import_agent(module_path, class_name)
    # execute() should not exist — it's been renamed to run()
    # If it still exists as a deprecated alias, that's acceptable but warn
    has_execute = hasattr(agent_cls, "execute") and not hasattr(agent_cls, "execute") == hasattr(BaseAgent, "execute")
    if has_execute:
        # Check if it's defined on the subclass (not inherited from a base that never had it)
        if "execute" in agent_cls.__dict__:
            pytest.fail(f"{class_name} still has old execute() method — must be renamed to run()")
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_agent_run_methods.py -v
```

Expected: FAIL — many agents still have execute() not run()

### Step 3: Migrate each agent

Each agent file needs:
1. Import `ToolInput, ToolOutput, AgentStatus` from `hr_harness.tool_protocol`
2. Rename `async def execute(self, context: Dict[str, Any]) -> Dict[str, Any]` to `async def run(self, input: ToolInput) -> ToolOutput`
3. Adapt the method body: use `input.pipeline_id`, `input.params`, `input.context` instead of `context["role"]`, etc.
4. Return `ToolOutput(status=AgentStatus.SUCCESS, data=..., ...)` instead of plain dict
5. Remove old `execute()` method

**Example migration — jd_agent.py (simplified):**

```python
# BEFORE:
async def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
    role = context.get("role", "")
    hints = context.get("hints", "")
    # ... LLM call ...
    return {"jd": jd_text, "profile": profile}

# AFTER:
async def run(self, input: ToolInput) -> ToolOutput:
    import time
    start = time.time()
    role = input.params.get("role", "")
    hints = input.params.get("hints", "")
    try:
        # ... same LLM call logic ...
        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={"jd": jd_text, "profile": profile},
            tokens_used=estimated_tokens,
            duration_ms=int((time.time() - start) * 1000),
        )
    except Exception as e:
        return ToolOutput(
            status=AgentStatus.FAILED,
            error=str(e),
            duration_ms=int((time.time() - start) * 1000),
        )
```

**Pattern for agents that call other agents (like SupervisorAgent):**

```python
# In orchestrator.py, update the call from:
result = await agent.execute(context_dict)
# To:
ti = ToolInput(pipeline_id=pid, params=context_dict, context=accumulated_context)
result = await agent.run(ti)
```

### Step 4: Run all tests — confirm they pass

```bash
pytest tests/test_agent_run_methods.py tests/test_agent_migration.py tests/test_tool_protocol.py -v
```

Expected: PASS — 15+17+10 = ~48 tests pass

### Step 5: Commit

```bash
git add hr_harness/agents/ hr_harness/scheduling.py hr_harness/orchestrator.py tests/test_agent_run_methods.py && git commit -m "feat(agents): migrate all 17 agents from execute(context:Dict) to run(ToolInput)->ToolOutput"
```

---

## Task 4: ActionHandler — 回迁 9 个 LLM 调用点到 Agent

**Files:**
- Modify: `app/action_handler.py`
- Modify: `hr_harness/agents/jd_agent.py` (小文: 1 call)
- Modify: `hr_harness/agents/match_agent.py` (小筛: 1 call)
- Modify: `hr_harness/agents/interview_agent.py` (小面: 2 calls)
- Modify: `hr_harness/agents/report_agent.py` (小评: 4 calls)
- Create: `tests/test_llm_migration.py`

### Step 1: Write the failing test

File: `tests/test_llm_migration.py`

```python
"""Verify action_handler LLM calls are migrated to agents"""
import pytest
import inspect
from app.action_handler import ActionHandler


def test_action_handler_no_longer_has_llm_methods():
    """After migration, ActionHandler should NOT have _call_llm_async or _call_llm_json"""
    ah = ActionHandler()
    # Check that the private LLM methods are removed or deprecated
    has_async = hasattr(ah, "_call_llm_async")
    has_json = hasattr(ah, "_call_llm_json")
    # Both should be gone
    assert not has_async, "ActionHandler._call_llm_async should be deleted after migration"
    assert not has_json, "ActionHandler._call_llm_json should be deleted after migration"


def test_action_handler_only_does_routing():
    """ActionHandler.handle_action() should route to agents, not call LLM directly"""
    source = inspect.getsource(ActionHandler.handle_action)
    # Verify no direct LLM call pattern remains in the handler
    assert "self._call_llm_async" not in source
    assert "self._call_llm_json" not in source
    assert "self.llm.chat" not in source
    assert "self.llm.chat_json" not in source
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_llm_migration.py -v
```

Expected: FAIL — ActionHandler still has _call_llm_async and _call_llm_json

### Step 3: Migrate LLM calls to agents

Each LLM call site in action_handler.py moves to its corresponding agent:

| Line | Method | → Agent |
|------|--------|---------|
| 215 | `_handle_edit_jd` | → 小文 (JDAgent) |
| 295 | `_handle_view_candidate` detail generation | → 小评 (ReportAgent) |
| 651 | `_handle_chat` intent understanding | → Split: domain-specific routing to each agent |
| 856 | `_handle_modify_interview` | → 小面 (InterviewAgent) |
| 964 | `_handle_consolidate_exam` | → 小面 (InterviewAgent) |
| 1021 | `_handle_compare_candidates` | → 小筛 (MatchAgent) |
| 1063 | `_handle_explain_score` | → 小评 (ReportAgent) |
| 1111 | `quick_evaluate` | → 小评 (ReportAgent) |
| 1231 | `_handle_submit_answers` | → 小评 (ReportAgent) |

**Pattern for migrating one call site:**

```python
# BEFORE (in action_handler.py):
async def _handle_edit_jd(self, pipeline_id, pipeline, stages, data):
    # ... build prompt ...
    new_jd = await self._call_llm_json(prompt, system, "qwen-plus", timeout=90)
    # ... process result ...

# AFTER:
async def _handle_edit_jd(self, pipeline_id, pipeline, stages, data):
    from hr_harness.agents.jd_agent import JDAgent
    from hr_harness.tool_protocol import ToolInput
    agent = JDAgent()
    ti = ToolInput(
        pipeline_id=pipeline_id,
        params={"role": pipeline.get("role", ""), "hints": data.get("hints", ""), "action": "edit_jd"},
    )
    result = await agent.run(ti)
    if result.status == AgentStatus.FAILED:
        return {"error": result.error}
    new_jd = result.data
    # ... process result same as before ...
```

**Chat handler (line 651) — domain splitting:**

```python
# BEFORE:
result = await self._call_llm_json(prompt, system, "qwen3.6-flash")
intent_action = result.get("action", "reply")

# AFTER:
# Determine which agent to route to based on intent keywords
# The LLM call is moved into the routing logic:
if any(kw in message for kw in ["JD", "岗位", "招聘"]):
    agent, stage_id = JDAgent(), "jd_writer"
elif any(kw in message for kw in ["候选人", "简历", "匹配"]):
    agent, stage_id = MatchAgent(), "match"
elif any(kw in message for kw in ["面试", "题目"]):
    agent, stage_id = InterviewAgent(), "interview_gen"
elif any(kw in message for kw in ["评估", "打分", "报告"]):
    agent, stage_id = ReportAgent(), "report"
else:
    # Fallback: use a general chat handler (can be SupervisorAgent)
    return {"status": "success", "type": "reply", "message": "请选择具体操作"}

ti = ToolInput(pipeline_id=pipeline_id, params={"message": message}, context=context)
result = await agent.run(ti)
```

After all 9 sites are migrated, delete the `_call_llm_async` and `_call_llm_json` methods from ActionHandler.

### Step 4: Run tests — confirm they pass

```bash
pytest tests/test_llm_migration.py -v
```

Expected: PASS — 2 tests pass

### Step 5: Commit

```bash
git add app/action_handler.py hr_harness/agents/jd_agent.py hr_harness/agents/match_agent.py hr_harness/agents/interview_agent.py hr_harness/agents/report_agent.py tests/test_llm_migration.py && git commit -m "feat(action_handler): migrate 9 LLM call sites to agents, remove _call_llm_async/_call_llm_json"
```

---

## Task 5: DAG Engine — 自研轻量工作流执行器

**Files:**
- Create: `hr_harness/dag_engine.py`
- Modify: `hr_harness/orchestrator.py`
- Create: `tests/test_dag_engine.py`

### Step 1: Write the failing test

File: `tests/test_dag_engine.py`

```python
"""Tests for DAG engine — linear execution, retry, timeout, human approval"""
import pytest
import asyncio
from unittest.mock import AsyncMock, patch
from hr_harness.dag_engine import DAGEngine, StageDefinition, StageResult
from hr_harness.tool_protocol import ToolInput, ToolOutput, ToolConfig, AgentStatus


class FakeAgent:
    """Fake agent that returns a controlled ToolOutput"""
    def __init__(self, responses=None):
        self.responses = responses or []
        self.call_count = 0
        self.last_input = None

    async def run(self, input: ToolInput) -> ToolOutput:
        self.call_count += 1
        self.last_input = input
        if self.call_count <= len(self.responses):
            return self.responses[self.call_count - 1]
        return ToolOutput(status=AgentStatus.SUCCESS, data={"default": "ok"})


@pytest.fixture
def engine():
    return DAGEngine()


@pytest.fixture
def linear_stages():
    return [
        StageDefinition(stage_id="jd_writer", agent=FakeAgent(), config=ToolConfig(agent_id="jd_writer", agent_name="小文", display_name="JD撰写")),
        StageDefinition(stage_id="match", agent=FakeAgent(), config=ToolConfig(agent_id="match", agent_name="小筛", display_name="匹配过滤")),
        StageDefinition(stage_id="interview", agent=FakeAgent(), config=ToolConfig(agent_id="interview", agent_name="小面", display_name="面试")),
    ]


class TestDAGEngineLinearExecution:
    @pytest.mark.asyncio
    async def test_executes_stages_in_sequence(self, engine, linear_stages):
        """DAG engine should execute stages in defined order"""
        results = await engine.execute(linear_stages, pipeline_id="p1")
        assert len(results) == 3
        assert results[0].stage_id == "jd_writer"
        assert results[0].status == AgentStatus.SUCCESS
        assert results[1].stage_id == "match"
        assert results[2].stage_id == "interview"

    @pytest.mark.asyncio
    async def test_passes_context_between_stages(self, engine, linear_stages):
        """Each stage should receive outputs from prior stages in context"""
        results = await engine.execute(linear_stages, pipeline_id="p1")
        # The last stage should have received context containing prior outputs
        assert len(results) == 3


class TestDAGEngineRetry:
    @pytest.mark.asyncio
    async def test_retries_failed_stage(self, engine):
        """FAILED stage should be retried up to retry_count times"""
        fail_then_succeed = FakeAgent(responses=[
            ToolOutput(status=AgentStatus.FAILED, error="temp error"),
            ToolOutput(status=AgentStatus.FAILED, error="temp error"),
            ToolOutput(status=AgentStatus.SUCCESS, data={"recovered": True}),
        ])
        stages = [StageDefinition(stage_id="flaky", agent=fail_then_succeed, config=ToolConfig(agent_id="flaky", agent_name="test", display_name="test", retry_count=3))]
        results = await DAGEngine().execute(stages, pipeline_id="p1")
        assert results[0].status == AgentStatus.SUCCESS
        assert fail_then_succeed.call_count == 3

    @pytest.mark.asyncio
    async def test_stops_after_retries_exhausted(self, engine):
        """After all retries fail, pipeline should halt (halt is default on_failure)"""
        always_fail = FakeAgent(responses=[
            ToolOutput(status=AgentStatus.FAILED, error="persistent error"),
            ToolOutput(status=AgentStatus.FAILED, error="persistent error"),
            ToolOutput(status=AgentStatus.FAILED, error="persistent error"),
        ])
        stages = [
            StageDefinition(stage_id="broken", agent=always_fail, config=ToolConfig(agent_id="broken", agent_name="test", display_name="test", retry_count=2)),
            StageDefinition(stage_id="never_runs", agent=FakeAgent(), config=ToolConfig(agent_id="never_runs", agent_name="test2", display_name="test2")),
        ]
        results = await DAGEngine().execute(stages, pipeline_id="p1")
        assert results[0].status == AgentStatus.FAILED
        # Second stage should NOT have executed (halt on failure)
        assert len([r for r in results if r.stage_id == "never_runs"]) == 0 or results[1].status != AgentStatus.SUCCESS


class TestDAGEngineHumanApproval:
    @pytest.mark.asyncio
    async def test_needs_human_pauses_pipeline(self, engine):
        """NEEDS_HUMAN should be returned but pipeline stops (no auto-continue)"""
        needs_human = FakeAgent(responses=[ToolOutput(status=AgentStatus.NEEDS_HUMAN, data={"reason": "review required"})])
        stages = [
            StageDefinition(stage_id="review_me", agent=needs_human, config=ToolConfig(agent_id="review_me", agent_name="test", display_name="test", human_approval=True)),
            StageDefinition(stage_id="next", agent=FakeAgent(), config=ToolConfig(agent_id="next", agent_name="test2", display_name="test2")),
        ]
        results = await DAGEngine().execute(stages, pipeline_id="p1")
        assert results[0].status == AgentStatus.NEEDS_HUMAN
        # Next stage should NOT execute (waiting for human)
        assert len([r for r in results if r.stage_id == "next"]) == 0


class TestDAGEngineTimeout:
    @pytest.mark.asyncio
    async def test_timeout_handling(self, engine):
        """Agent that takes too long should be treated as FAILED"""
        async def slow_run(input):
            await asyncio.sleep(10)  # Very slow
            return ToolOutput(status=AgentStatus.SUCCESS)

        slow_agent = FakeAgent()
        slow_agent.run = slow_run
        config = ToolConfig(agent_id="slow", agent_name="test", display_name="test", timeout=1, retry_count=0)
        stages = [StageDefinition(stage_id="slow", agent=slow_agent, config=config)]
        results = await DAGEngine().execute(stages, pipeline_id="p1")
        assert results[0].status == AgentStatus.FAILED
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_dag_engine.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'hr_harness.dag_engine'`

### Step 3: Write minimal implementation

File: `hr_harness/dag_engine.py`

```python
"""DAG Engine — lightweight workflow executor for agent pipeline stages.

V1 supports: linear execution, conditional branching (on_failure),
exponential backoff retry, timeout, human approval gates.
V2 (future): parallel stage groups.
"""
import asyncio
import time
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from hr_harness.tool_protocol import ToolInput, ToolOutput, ToolConfig, AgentStatus

logger = logging.getLogger("dag_engine")


@dataclass
class StageDefinition:
    """A pipeline stage — one agent with its config"""
    stage_id: str
    agent: Any  # BaseAgent instance
    config: ToolConfig
    on_failure: str = "halt"  # "halt" | "skip_and_continue"


@dataclass
class StageResult:
    """Result of executing one stage"""
    stage_id: str
    status: AgentStatus
    output: ToolOutput
    retries: int = 0
    duration_ms: int = 0


class DAGEngine:
    """Lightweight DAG executor for agent pipeline stages.

    Executes stages sequentially (V1). Each stage gets cumulative context
    from all prior stages. Supports retry with exponential backoff,
    timeout enforcement, and human approval gates.
    """

    def __init__(self, on_stage_update: Optional[callable] = None):
        """on_stage_update is an optional async callback(stage_id, status, result)
        for WebSocket broadcasting."""
        self.on_stage_update = on_stage_update
        self._accumulated_context: Dict[str, Any] = {}

    async def execute(
        self,
        stages: List[StageDefinition],
        pipeline_id: str,
        candidate_id: Optional[str] = None,
        initial_params: Optional[Dict[str, Any]] = None,
    ) -> List[StageResult]:
        """Execute stages sequentially. Returns results list."""
        results: List[StageResult] = []
        self._accumulated_context = {}

        for stage in stages:
            if not stage.config.enabled:
                continue

            result = await self._execute_stage(stage, pipeline_id, candidate_id, initial_params or {})
            results.append(result)

            if result.status == AgentStatus.SUCCESS:
                self._accumulated_context[stage.stage_id] = result.output.data
            elif result.status == AgentStatus.FAILED:
                if stage.on_failure == "halt":
                    break  # Stop pipeline
                # skip_and_continue: log and move on
            elif result.status == AgentStatus.NEEDS_HUMAN:
                break  # Wait for human intervention

        return results

    async def _execute_stage(
        self,
        stage: StageDefinition,
        pipeline_id: str,
        candidate_id: Optional[str],
        params: Dict[str, Any],
    ) -> StageResult:
        """Execute one stage with retry and timeout."""
        start = time.time()
        last_output = None
        retries = 0

        for attempt in range(stage.config.retry_count + 1):
            try:
                ti = ToolInput(
                    pipeline_id=pipeline_id,
                    candidate_id=candidate_id,
                    params=params,
                    context=dict(self._accumulated_context),
                )

                if self.on_stage_update:
                    await self.on_stage_update(stage.stage_id, AgentStatus.RUNNING, None)

                output = await asyncio.wait_for(
                    stage.agent.run(ti),
                    timeout=stage.config.timeout,
                )

                if output.status == AgentStatus.SUCCESS:
                    return StageResult(
                        stage_id=stage.stage_id,
                        status=AgentStatus.SUCCESS,
                        output=output,
                        retries=attempt,
                        duration_ms=int((time.time() - start) * 1000),
                    )
                elif output.status == AgentStatus.NEEDS_HUMAN:
                    return StageResult(
                        stage_id=stage.stage_id,
                        status=AgentStatus.NEEDS_HUMAN,
                        output=output,
                        retries=attempt,
                        duration_ms=int((time.time() - start) * 1000),
                    )
                else:  # FAILED
                    last_output = output
                    retries = attempt
                    if attempt < stage.config.retry_count:
                        backoff = 2 ** attempt  # 1s, 2s, 4s
                        await asyncio.sleep(backoff)

            except asyncio.TimeoutError:
                last_output = ToolOutput(status=AgentStatus.FAILED, error=f"Timeout after {stage.config.timeout}s")
                retries = attempt

            if self.on_stage_update:
                await self.on_stage_update(stage.stage_id, AgentStatus.FAILED, last_output)

        return StageResult(
            stage_id=stage.stage_id,
            status=AgentStatus.FAILED,
            output=last_output or ToolOutput(status=AgentStatus.FAILED, error="Unknown error"),
            retries=retries,
            duration_ms=int((time.time() - start) * 1000),
        )

    async def retry_stage(
        self,
        stage: StageDefinition,
        pipeline_id: str,
        candidate_id: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        prior_context: Optional[Dict[str, Any]] = None,
    ) -> StageResult:
        """Retry a previously failed stage with its accumulated context."""
        if prior_context:
            self._accumulated_context = dict(prior_context)
        return await self._execute_stage(stage, pipeline_id, candidate_id, params or {})
```

File: `hr_harness/orchestrator.py` — add a method to use DAGEngine:

```python
# In SupervisorAgent class, add:
from hr_harness.dag_engine import DAGEngine, StageDefinition
from hr_harness.tool_protocol import ToolInput, ToolOutput, ToolConfig, AgentStatus

async def _run_pipeline_v2(self, pipeline_id: str, stages: list, candidate_id: str = None, params: dict = None) -> list:
    """Execute pipeline stages using the new DAG engine (V2 architecture)."""
    engine = DAGEngine(on_stage_update=self._on_stage_update)
    stage_defs = []
    for stage in stages:
        agent_cls = self.agent_registry.get(stage["stage_id"], {}).get("agent")
        if agent_cls:
            agent = agent_cls()
            config = ToolConfig(
                agent_id=stage["stage_id"],
                agent_name=self.agent_registry[stage["stage_id"]].get("name", stage["stage_id"]),
                display_name=self.agent_registry[stage["stage_id"]].get("name", stage["stage_id"]),
            )
            stage_defs.append(StageDefinition(stage_id=stage["stage_id"], agent=agent, config=config))
    return await engine.execute(stage_defs, pipeline_id=pipeline_id, candidate_id=candidate_id, initial_params=params)

async def _on_stage_update(self, stage_id: str, status: AgentStatus, result):
    """WebSocket broadcast callback for stage status changes."""
    from app.state import broadcast
    await broadcast({
        "type": "stage_update",
        "stage_id": stage_id,
        "status": status.value,
        "result": result.output.data if result and result.output else None,
    }, pipeline_id=None)
```

### Step 4: Run tests — confirm they pass

```bash
pytest tests/test_dag_engine.py -v
```

Expected: PASS — 7 tests pass

### Step 5: Commit

```bash
git add hr_harness/dag_engine.py hr_harness/orchestrator.py tests/test_dag_engine.py && git commit -m "feat(hr_harness): add DAG engine with retry, timeout, and human approval"
```

---

## Task 6: DB Schema — agent_configs 表 + engine_version

**Files:**
- Modify: `app/db.py`
- Create: `tests/test_agent_configs_db.py`

### Step 1: Write the failing test

File: `tests/test_agent_configs_db.py`

```python
"""Tests for agent_configs DB table and engine_version field"""
import pytest
from app.db import (
    get_db, init_db,
    get_agent_configs, upsert_agent_config, get_agent_config,
    get_pipeline, update_pipeline,
)

@pytest.fixture(autouse=True)
def setup_db():
    init_db()

def test_agent_configs_table_exists():
    """agent_configs table should exist after init_db"""
    conn = get_db()
    cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='agent_configs'")
    assert cursor.fetchone() is not None

def test_upsert_and_get_agent_config():
    """Should insert on first call, update on second"""
    upsert_agent_config("jd_writer", "小文", "JD撰写与画像", model="qwen-plus", temperature=0.5)
    config = get_agent_config("jd_writer")
    assert config["agent_id"] == "jd_writer"
    assert config["agent_name"] == "小文"
    assert config["model"] == "qwen-plus"
    assert config["temperature"] == 0.5

    # Upsert with new values
    upsert_agent_config("jd_writer", "小文", "JD撰写与画像", model="qwen3.7-max")
    config = get_agent_config("jd_writer")
    assert config["model"] == "qwen3.7-max"

def test_get_agent_configs_returns_all():
    """Should return all six agent configs after seeding"""
    for agent_id, name, display in [
        ("jd_writer", "小文", "JD撰写与画像生成"),
        ("poster_gen", "小海", "招聘海报生成"),
        ("resume_import", "小寻", "简历获取与导入"),
        ("resume_filter", "小筛", "简历匹配过滤"),
        ("ai_evaluate", "小评", "AI评估报告"),
        ("interview", "小面", "面试出题与评估"),
    ]:
        upsert_agent_config(agent_id, name, display)
    configs = get_agent_configs()
    assert len(configs) >= 6

def test_pipeline_engine_version_field():
    """Pipeline should support engine_version field for migration"""
    # Create a pipeline with engine_version
    from app.db import create_pipeline
    pid = create_pipeline("test_role", "test_hints")
    # Update engine version
    conn = get_db()
    conn.execute("UPDATE pipelines SET engine_version = ? WHERE id = ?", (2, pid))
    conn.commit()
    # Verify
    pipeline = get_pipeline(pid)
    assert pipeline["engine_version"] == 2
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_agent_configs_db.py -v
```

Expected: FAIL — `no such table: agent_configs`

### Step 3: Write implementation

Add to `app/db.py`:

```python
# agent_configs table
def _init_agent_configs_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS agent_configs (
            agent_id TEXT PRIMARY KEY,
            agent_name TEXT NOT NULL DEFAULT '',
            display_name TEXT NOT NULL DEFAULT '',
            model TEXT NOT NULL DEFAULT 'qwen3.6-flash',
            complexity TEXT NOT NULL DEFAULT 'plus',
            temperature REAL NOT NULL DEFAULT 0.7,
            timeout INTEGER NOT NULL DEFAULT 120,
            retry_count INTEGER NOT NULL DEFAULT 2,
            enabled INTEGER NOT NULL DEFAULT 1,
            human_approval INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)

# Add to pipelines table migration
def _migrate_pipelines_add_engine_version(conn):
    try:
        conn.execute("ALTER TABLE pipelines ADD COLUMN engine_version INTEGER NOT NULL DEFAULT 1")
    except Exception:
        pass  # Column already exists

# Call in init_db()
def init_db():
    conn = get_db()
    # ... existing table creation ...
    _init_agent_configs_table(conn)
    _migrate_pipelines_add_engine_version(conn)
    conn.commit()


def get_agent_configs() -> list:
    """Return all agent configs as dicts"""
    conn = get_db()
    rows = conn.execute("SELECT * FROM agent_configs ORDER BY agent_id").fetchall()
    return [dict(r) for r in rows]


def get_agent_config(agent_id: str) -> dict:
    """Return a single agent config"""
    conn = get_db()
    row = conn.execute("SELECT * FROM agent_configs WHERE agent_id = ?", (agent_id,)).fetchone()
    return dict(row) if row else None


def upsert_agent_config(agent_id: str, agent_name: str, display_name: str,
                        model: str = None, complexity: str = None,
                        temperature: float = None, timeout: int = None,
                        retry_count: int = None, enabled: bool = None,
                        human_approval: bool = None):
    """Insert or update agent configuration"""
    conn = get_db()
    existing = get_agent_config(agent_id)
    if existing:
        updates = []
        params = []
        for field in ["model", "complexity", "temperature", "timeout", "retry_count", "enabled", "human_approval"]:
            val = locals().get(field)
            if val is not None:
                updates.append(f"{field} = ?")
                params.append(val if not isinstance(val, bool) else (1 if val else 0))
        if updates:
            params.append(agent_id)
            conn.execute(f"UPDATE agent_configs SET {', '.join(updates)}, updated_at = datetime('now') WHERE agent_id = ?", params)
    else:
        conn.execute(
            "INSERT INTO agent_configs (agent_id, agent_name, display_name, model, complexity, temperature, timeout, retry_count, enabled, human_approval) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (agent_id, agent_name, display_name,
             model or "qwen3.6-flash", complexity or "plus",
             temperature if temperature is not None else 0.7,
             timeout or 120, retry_count or 2,
             1 if enabled is None or enabled else 0,
             1 if human_approval else 0))
    conn.commit()
```

### Step 4: Run tests — confirm they pass

```bash
pytest tests/test_agent_configs_db.py -v
```

Expected: PASS — 4 tests pass

### Step 5: Commit

```bash
git add app/db.py tests/test_agent_configs_db.py && git commit -m "feat(db): add agent_configs table and engine_version field for hot-reload and migration"
```

---

## Task 7: Admin API — 调度管理 API 路由

**Files:**
- Modify: `app/main.py`
- Create: `tests/test_admin_api.py`

### Step 1: Write the failing test

File: `tests/test_admin_api.py`

```python
"""Tests for admin dispatch panel API endpoints"""
import pytest
from fastapi.testclient import TestClient

# Import the app — assumes conftest.py sets TESTING=1 for in-memory DB
from app.main import app
from app.db import init_db, upsert_agent_config

client = TestClient(app)


@pytest.fixture(autouse=True)
def setup():
    init_db()
    # Seed agent configs
    for agent_id, name, display in [
        ("jd_writer", "小文", "JD撰写与画像生成"),
        ("poster_gen", "小海", "招聘海报生成"),
        ("resume_import", "小寻", "简历获取与导入"),
        ("resume_filter", "小筛", "简历匹配过滤"),
        ("ai_evaluate", "小评", "AI评估报告"),
        ("interview", "小面", "面试出题与评估"),
    ]:
        upsert_agent_config(agent_id, name, display)


class TestAdminAgentAPI:
    def test_get_agents_returns_six_agents(self):
        """GET /api/agents should return all six agents"""
        response = client.get("/api/agents")
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 6
        agent_ids = [a["agent_id"] for a in data]
        assert "jd_writer" in agent_ids
        assert "interview" in agent_ids

    def test_get_agent_config(self):
        """GET /api/agents/{id}/config should return single agent config"""
        response = client.get("/api/agents/jd_writer/config")
        assert response.status_code == 200
        data = response.json()
        assert data["agent_id"] == "jd_writer"
        assert data["agent_name"] == "小文"
        assert "model" in data

    def test_update_agent_config(self):
        """PUT /api/agents/{id}/config should update agent settings"""
        response = client.put("/api/agents/interview/config", json={
            "model": "qwen-plus",
            "temperature": 0.3,
        })
        assert response.status_code == 200
        # Verify update persisted
        response = client.get("/api/agents/interview/config")
        assert response.json()["model"] == "qwen-plus"
        assert response.json()["temperature"] == 0.3

    def test_update_nonexistent_agent(self):
        """PUT /api/agents/nonexistent/config should return 404"""
        response = client.put("/api/agents/nonexistent/config", json={"model": "x"})
        assert response.status_code == 404

    def test_get_pipeline_dag(self):
        """GET /api/pipelines/{id}/dag should return pipeline stage statuses"""
        # Create a pipeline first
        from app.db import create_pipeline
        pid = create_pipeline("test_role", "test_hints")
        response = client.get(f"/api/pipelines/{pid}/dag")
        assert response.status_code == 200
        data = response.json()
        assert "pipeline_id" in data
        assert "stages" in data

    def test_retry_stage(self):
        """POST /api/pipelines/{id}/retry/{stage_id} should trigger retry"""
        from app.db import create_pipeline
        pid = create_pipeline("test_role", "test_hints")
        response = client.post(f"/api/pipelines/{pid}/retry/match")
        assert response.status_code in (200, 404)  # 200 if stage exists, 404 if not yet created
```

### Step 2: Run test — confirm it fails

```bash
pytest tests/test_admin_api.py -v
```

Expected: FAIL — 404 for /api/agents (route not defined)

### Step 3: Write implementation

Add to `app/main.py`:

```python
from app.db import get_agent_configs, get_agent_config, upsert_agent_config
from hr_harness.tool_protocol import ToolConfig

@app.get("/api/agents")
async def api_list_agents():
    """Return all agent configs for the dispatch panel"""
    configs = get_agent_configs()
    return configs


@app.get("/api/agents/{agent_id}/config")
async def api_get_agent_config(agent_id: str):
    """Return a single agent's configuration"""
    config = get_agent_config(agent_id)
    if not config:
        raise HTTPException(status_code=404, detail="Agent not found")
    return config


class AgentConfigUpdate(BaseModel):
    model: Optional[str] = None
    complexity: Optional[str] = None
    temperature: Optional[float] = None
    timeout: Optional[int] = None
    retry_count: Optional[int] = None
    enabled: Optional[bool] = None
    human_approval: Optional[bool] = None


@app.put("/api/agents/{agent_id}/config")
async def api_update_agent_config(agent_id: str, update: AgentConfigUpdate):
    """Update agent configuration — takes effect on next agent call"""
    existing = get_agent_config(agent_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    upsert_agent_config(
        agent_id=agent_id,
        agent_name=existing["agent_name"],
        display_name=existing["display_name"],
        model=update.model,
        complexity=update.complexity,
        temperature=update.temperature,
        timeout=update.timeout,
        retry_count=update.retry_count,
        enabled=update.enabled,
        human_approval=update.human_approval,
    )
    from app.audit.audit_trail import audit
    audit("agent.config_updated", f"Agent {agent_id} config updated", entity_type="agent", details=update.dict(exclude_none=True))
    return {"status": "ok", "agent_id": agent_id}


@app.get("/api/pipelines/{pipeline_id}/dag")
async def api_get_pipeline_dag(pipeline_id: str):
    """Return pipeline DAG state — stage statuses for visualization"""
    from app.db import get_pipeline, get_stages
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    stages = get_stages(pipeline_id)
    return {
        "pipeline_id": pipeline_id,
        "role": pipeline.get("role", ""),
        "engine_version": pipeline.get("engine_version", 1),
        "stages": [{"stage_id": s["stage_id"], "status": s.get("status", "pending"), "output_summary": s.get("output_summary", "")} for s in stages],
    }


@app.post("/api/pipelines/{pipeline_id}/retry/{stage_id}")
async def api_retry_stage(pipeline_id: str, stage_id: str):
    """Retry a failed pipeline stage"""
    from app.db import get_pipeline
    pipeline = get_pipeline(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    # Trigger retry via supervisor
    from app.state import state
    supervisor = state.get_supervisor()
    # ... retry logic ...
    return {"status": "retrying", "pipeline_id": pipeline_id, "stage_id": stage_id}
```

### Step 4: Run tests — confirm they pass

```bash
pytest tests/test_admin_api.py -v
```

Expected: PASS — 6 tests pass

### Step 5: Commit

```bash
git add app/main.py tests/test_admin_api.py && git commit -m "feat(api): add admin dispatch panel API — agents list, config get/put, pipeline DAG, stage retry"
```

---

## Task 8: 前端调度面板 — Admin Dispatch Tab

**Files:**
- Modify: `frontend/index.html`

This task is frontend-only. Add a new "调度中心" Tab in the sidebar of the existing single-file HTML. The panel shows:

1. Agent status list (name, status indicator, last run, success rate, avg duration)
2. Pipeline stage timeline (CSS vertical timeline, colored status dots)
3. Agent config edit form (model, prompt, temperature inputs with save button)
4. Call log viewer (recent agent invocations with input/output/tokens/duration)
5. Retry button for failed stages

Key UX: fetch from `GET /api/agents` and `GET /api/pipelines/{id}/dag` on tab activation. Use existing CSS variables (--primary, --success, --warning, --danger) for status colors.

### Step 1: Commit (no pytest for frontend — verify visually)

The Assignment from the design doc already covers this: build a static prototype first, show HR team, then implement properly.

For now, add the basic structure with API integration:

```bash
git add frontend/index.html && git commit -m "feat(frontend): add admin dispatch panel Tab with agent status, DAG timeline, config editor"
```

---

## Execution Summary

| Task | Priority | Component | Effort (human) | Blocks |
|------|----------|-----------|----------------|--------|
| T1 | P1 | Tool Protocol types | 1h | T2, T3, T4 |
| T2 | P1 | BaseAgent.run() abstract | 2h | T3, T4 |
| T3 | P1 | 17 agent migration | 5h | T4, T5 |
| T4 | P1 | ActionHandler cleanup | 3h | — |
| T5 | P1 | DAG Engine | 4h | T7 |
| T6 | P3 | DB schema | 0.5h | T7 |
| T7 | P2 | Admin API routes | 2h | T8 |
| T8 | P2 | Frontend panel | 3h | — |

**Total: ~20.5 human-hours, ~3h CC time.**

T1-T4 are sequential dependencies. T5-T6 can start after T3. T7 depends on T5+T6. T8 depends on T7.
