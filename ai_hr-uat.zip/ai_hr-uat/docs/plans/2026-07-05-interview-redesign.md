# AI 面试官重设计 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 将 `frontend/interview.html` 从 HR 操作工具改造为候选人自助面试页面，支持文字/语音双通道答题、实时评分反馈、追问、完整评估报告，面试结果自动同步到 pipeline。

**Architecture:** 轮次制交互——每道题一个完整轮次（AI 播报 → 候选人回答 → AI 评估 → 追问 → 下一题）。前端为 11 状态的状态机，后端新增 `quick-evaluate` API 做单题快速评估，复用现有 `submit-answers` API 做全量评估和 pipeline 同步。

**Tech Stack:** FastAPI (Python) + 单文件 HTML/JS 前端 + hermes_wrapper LLM client + Web Speech API (TTS/ASR) + localStorage

---

## Pipeline 前置约束：简历获取与匹配触发机制

> 本节描述简历获取和 match 阶段的触发规则，作为面试流程的上游前提。

**核心规则：所有简历获取和匹配节点始终手动触发，禁止自动执行。**

### 触发条件

| 操作 | 触发方式 | 按钮展示 |
|------|---------|---------|
| 上传本地简历 | HR 手动上传 | resume source card 第 2 步展示"📤 上传本地简历"按钮 |
| 从人才库导入简历 | HR 手动触发 | resume source card 第 1 步展示"🏢 从人才库导入"按钮 |
| Chrome 插件抓取 | HR 手动导入 | 插件采集后，HR 点击"获取插件简历"导入 |
| 开始 AI 匹配 | HR 手动点击"开始匹配" | 简历导入后展示"🎯 开始匹配"按钮 |
| 生成面试题 | HR 手动点击"生成面试题" | 匹配完成后展示"📝 生成面试题"按钮 |

### 前端流程（`frontend/index.html`）

```
showResumeSourceCard()  →  Step 1: "从人才库导入" | "跳过"
                            ↓
showResumeStep2()       →  Step 2: "上传本地简历" | "🎯 开始匹配"
                            ↓
triggerMatch()          →  POST /api/resumes/{pipeline_id}/process
                            ↓
process_imported_resumes()  →  匹配完成 → 展示结果 + "📝 生成面试题"按钮
```

### 关键约束

1. **无自动匹配代码** — `auto_match_resumes()`、`_schedule_auto_match()`、`_do_auto_match()` 已从 `app/services.py` 中删除，不存在任何自动触发路径
2. **简历入队不触发匹配** — 简历上传/导入仅写入 `pending_resumes`，由 HR 手动点击"开始匹配"调用 `process_imported_resumes()`
3. **orchestrator 延迟 match 阶段** — `match`、`interview_gen`、`video_assess`、`report` 在初始 pipeline run 中跳过，等待手动触发
4. **匹配完成后不自动推进** — pipeline 保持 `waiting_for_resumes` 状态，等 HR 手动点击"生成面试题"

### 涉及文件

- `app/services.py` — `process_imported_resumes()` 手动匹配逻辑
- `app/main.py` — 简历上传/导入 API（不含自动匹配调用）
- `hr_harness/orchestrator.py` — deferred stages 逻辑
- `frontend/index.html` — `showResumeSourceCard()`、`showResumeStep2()`、`triggerMatch()`、`showMatchButton()`

---

## Phase 0: Backend API (P0, Day 1)

### Task 1: quick-evaluate API — 测试

**Files:**
- Create: `tests/test_quick_evaluate.py`
- Modify: `app/main.py` (add API endpoint)
- Modify: `app/action_handler.py` (add evaluation logic)

**Step 1: Write the failing test**

```python
# tests/test_quick_evaluate.py
"""Tests for single-question quick evaluation API"""
import pytest
from unittest.mock import AsyncMock, patch
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    from app.main import app
    return TestClient(app)


@pytest.fixture
def mock_pipeline_data():
    """Set up pipeline with interview questions in DB"""
    from app.db import init_db
    import app.db as db_module
    import json

    db_module.init_db()

    # Create a pipeline
    db_module._conn.execute(
        "INSERT INTO pipelines (id, role, status, context) VALUES (?, ?, ?, ?)",
        ("pipe-1", "后端工程师", "running", json.dumps({"role": "后端工程师"}))
    )
    db_module._conn.commit()

    # Create a candidate
    db_module._conn.execute(
        "INSERT INTO candidates (id, pipeline_id, name, skills, overall_score) VALUES (?, ?, ?, ?, ?)",
        ("cand-1", "pipe-1", "张三", '["Python","Go"]', 80)
    )
    db_module._conn.commit()

    # Create interview_gen stage with questions
    stage_output = json.dumps({
        "interviews": [{
            "candidate_id": "cand-1",
            "candidate_name": "张三",
            "questions": [
                {
                    "question": "请描述滑动窗口限流算法的实现",
                    "type": "技术深度",
                    "difficulty": "中等",
                    "expected_points": ["滑动窗口原理", "时间复杂度", "并发安全"]
                }
            ]
        }]
    })
    db_module._conn.execute(
        "INSERT INTO pipeline_stages (pipeline_id, stage_id, status, output) VALUES (?, ?, ?, ?)",
        ("pipe-1", "interview_gen", "done", stage_output)
    )
    db_module._conn.commit()


def test_quick_evaluate_returns_score(client, mock_pipeline_data):
    """Quick evaluate should return score, hit_points, missed_points, comment"""
    with patch("app.action_handler.ActionHandler._call_llm_json", new_callable=AsyncMock) as mock_llm:
        mock_llm.return_value = {
            "score": 75,
            "hit_points": ["滑动窗口原理"],
            "missed_points": ["并发安全"],
            "comment": "覆盖了核心概念，缺少并发考虑",
            "should_follow_up": True
        }

        resp = client.post("/api/interviews/quick-evaluate", json={
            "pipeline_id": "pipe-1",
            "candidate_id": "cand-1",
            "question_index": 0,
            "question": "请描述滑动窗口限流算法的实现",
            "expected_points": ["滑动窗口原理", "时间复杂度", "并发安全"],
            "answer": "滑动窗口通过维护一个时间窗口来统计请求数...",
            "jd_role": "后端工程师"
        })

        assert resp.status_code == 200
        data = resp.json()
        assert data["score"] == 75
        assert "滑动窗口原理" in data["hit_points"]
        assert "并发安全" in data["missed_points"]
        assert data["should_follow_up"] is True
        assert len(data["comment"]) > 0


def test_quick_evaluate_invalid_pipeline(client, mock_pipeline_data):
    """Should return error for non-existent pipeline"""
    resp = client.post("/api/interviews/quick-evaluate", json={
        "pipeline_id": "nonexistent",
        "candidate_id": "cand-1",
        "question_index": 0,
        "question": "test",
        "expected_points": [],
        "answer": "test answer",
        "jd_role": "test"
    })
    assert resp.status_code == 404


def test_quick_evaluate_missing_answer(client, mock_pipeline_data):
    """Should return error when answer is empty"""
    resp = client.post("/api/interviews/quick-evaluate", json={
        "pipeline_id": "pipe-1",
        "candidate_id": "cand-1",
        "question_index": 0,
        "question": "test",
        "expected_points": [],
        "answer": "",
        "jd_role": "test"
    })
    assert resp.status_code == 422
```

**Step 2: Run test — confirm it fails**
```bash
cd /Users/zhoulin/ai-hr-os && python -m pytest tests/test_quick_evaluate.py -v
```
Expected: FAIL — endpoint `/api/interviews/quick-evaluate` not found (404 or similar)

**Step 3: Commit test**
```bash
git add tests/test_quick_evaluate.py && git commit -m "test: add quick-evaluate API tests"
```

---

### Task 2: quick-evaluate API — 实现

**Files:**
- Modify: `app/main.py` (add Pydantic model + route)

**Step 1: Add Pydantic request model and API endpoint**

在 `app/main.py` 的 `# ============ Interview Answers & Re-evaluation APIs ============` 区块（约 line 647）之前添加：

```python
# ============ Quick Evaluate API ============
class QuickEvaluateRequest(BaseModel):
    pipeline_id: str
    candidate_id: str
    question_index: int
    question: str
    expected_points: list = []
    answer: str
    jd_role: str = ""

@app.post("/api/interviews/quick-evaluate")
async def api_quick_evaluate(req: QuickEvaluateRequest):
    """Single-question quick evaluation — returns score, hit/missed points, comment"""
    pipeline = get_pipeline(req.pipeline_id)
    if not pipeline:
        raise HTTPException(404, "Pipeline not found")

    if not req.answer or not req.answer.strip():
        raise HTTPException(422, "Answer cannot be empty")

    handler = state.get_action_handler()
    result = await handler.quick_evaluate(
        pipeline_id=req.pipeline_id,
        candidate_id=req.candidate_id,
        question=req.question,
        expected_points=req.expected_points,
        answer=req.answer,
        jd_role=req.jd_role,
    )
    return result
```

**Step 2: Add `quick_evaluate` method to ActionHandler**

在 `app/action_handler.py` 的 `_handle_submit_answers` 方法之前添加：

```python
async def quick_evaluate(self, pipeline_id: str, candidate_id: str,
                         question: str, expected_points: list,
                         answer: str, jd_role: str) -> dict:
    """Evaluate a single interview question answer — fast feedback"""
    system = """你是一个资深技术面试官，快速评估候选人对单道面试题的回答。
输出JSON格式，包含：score(0-100), hit_points(命中的要点列表), missed_points(未命中的要点列表), comment(一句话评价), should_follow_up(是否需要追问，bool)。"""

    points_str = "、".join(expected_points) if expected_points else "无"

    prompt = f"""岗位：{jd_role}
题目：{question}
期望要点：{points_str}

候选人回答：
{answer}

请快速评估，输出JSON：
{{
    "score": 数字(0-100),
    "hit_points": ["命中的要点"],
    "missed_points": ["未命中的要点"],
    "comment": "20字以内的评价",
    "should_follow_up": true或false(如果score<60或缺失要点>1则为true)
}}"""

    result = await self._call_llm_json(prompt, system, "qwen3.7-max", timeout=30)

    if isinstance(result, dict) and "score" in result:
        return {
            "score": result.get("score", 0),
            "hit_points": result.get("hit_points", []),
            "missed_points": result.get("missed_points", []),
            "comment": result.get("comment", ""),
            "should_follow_up": result.get("should_follow_up", False),
        }

    return {
        "score": 0,
        "hit_points": [],
        "missed_points": expected_points,
        "comment": "评估失败，请重试",
        "should_follow_up": False,
    }
```

**Step 3: Run test — confirm it passes**
```bash
cd /Users/zhoulin/ai-hr-os && python -m pytest tests/test_quick_evaluate.py -v
```
Expected: 3 tests PASS

**Step 4: Commit**
```bash
git add app/main.py app/action_handler.py && git commit -m "feat: add quick-evaluate API for single-question assessment"
```

---

## Phase 1: Frontend Rewrite — State Machine + Text Input (P0, Day 1-2)

### Task 3: interview.html — 状态机 + 文字输入基础框架

**Files:**
- Modify: `frontend/interview.html` (完整重写)

**Step 1: 重写 interview.html 的 CSS 和 HTML 结构**

保留现有 CSS 变量和基本样式，重写布局为三区域：
- 顶部栏：进度条 + 计时器 + 候选人信息
- 左侧：面试官区域（头像 + 题目 + 输入区域）
- 右侧：对话记录 + 评分卡片流

关键变化：
1. 输入区域从 action-bar 移到左侧面板底部，增加文字输入框
2. 右侧从纯对话记录变为"对话 + 评分卡片"混排
3. 添加状态机 CSS 类（`.state-speaking`, `.state-recording` 等）

**Step 2: 实现 JavaScript 状态机**

```javascript
// frontend/interview.html <script> section

const STATES = {
  LOADING: 'loading',
  SPEAKING: 'speaking',
  IDLE_INPUT: 'idle_input',
  RECORDING: 'recording',
  TRANSCRIBING: 'transcribing',
  EDITING: 'editing',
  THINKING: 'thinking',
  ANALYSIS: 'analysis',
  FOLLOW_UP: 'follow_up',
  COMPLETE: 'complete',
  ERROR: 'error',
};

class InterviewStateMachine {
  constructor() {
    this.state = STATES.LOADING;
    this.questions = [];
    this.currentIdx = 0;
    this.answers = [];          // [{question_index, answer_text, score, ...}]
    this.followUpCount = 0;     // 当前题目的追问次数
    this.maxFollowUps = 2;
    this.timerSec = 0;
    this.timerHandle = null;
  }

  setState(newState) {
    this.state = newState;
    this.render();
  }

  render() {
    // Update UI based on current state
    this.updateProgressBar();
    this.updateActionButtons();
    this.updateInputArea();
    this.updateStatusIndicator();
  }

  // ... methods for each state transition
}
```

**Step 3: 实现文字输入流程**

```javascript
// 文字输入提交
async function submitTextAnswer() {
  const inputEl = document.getElementById('answer-input');
  const text = inputEl.value.trim();
  if (!text) return;

  sm.setState(STATES.THINKING);
  inputEl.value = '';

  const result = await callQuickEvaluate(sm.currentIdx, text);
  recordAnswer(sm.currentIdx, text, result);
  renderScoreCard(result);
  addTranscriptMessage('候选人', text);

  if (result.should_follow_up && sm.followUpCount < sm.maxFollowUps) {
    sm.followUpCount++;
    sm.setState(STATES.FOLLOW_UP);
    // AI asks follow-up question
  } else {
    sm.followUpCount = 0;
    sm.setState(STATES.ANALYSIS);
  }
}

async function callQuickEvaluate(questionIndex, answerText) {
  const q = sm.questions[questionIndex];
  try {
    const resp = await fetch('/api/interviews/quick-evaluate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pipeline_id: pipelineId,
        candidate_id: candidateId,
        question_index: questionIndex,
        question: q.question,
        expected_points: q.expected_points || [],
        answer: answerText,
        jd_role: jdRole,
      }),
    });
    return await resp.json();
  } catch (e) {
    return { score: 0, hit_points: [], missed_points: [], comment: '评估失败', should_follow_up: false };
  }
}
```

**Step 4: 实现评分卡片渲染**

```javascript
function renderScoreCard(result) {
  const container = document.getElementById('score-cards');
  const card = document.createElement('div');
  card.className = 'score-card';
  card.innerHTML = `
    <div class="score-header">📊 本题评分: ${result.score}/100</div>
    <div class="hit-points">
      <div class="label">✅ 命中要点:</div>
      ${result.hit_points.map(p => `<span class="point hit">${p}</span>`).join('')}
    </div>
    <div class="missed-points">
      <div class="label">⚠️ 缺失要点:</div>
      ${result.missed_points.map(p => `<span class="point missed">${p}</span>`).join('')}
    </div>
    <div class="comment">💬 ${result.comment}</div>
  `;
  container.appendChild(card);

  // Also add to right panel transcript
  addTranscriptScoreCard(result);
}
```

**Step 5: 实现 localStorage 断点恢复**

```javascript
const PROGRESS_KEY = `interview_progress_${pipelineId}_${candidateId}`;

function saveProgress() {
  const progress = {
    current_question_index: sm.currentIdx,
    submitted_answers: sm.answers,
    started_at: sm.startedAt,
    expires_at: new Date(Date.now() + 72 * 3600 * 1000).toISOString(),
  };
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
}

function loadProgress() {
  const raw = localStorage.getItem(PROGRESS_KEY);
  if (!raw) return null;
  const progress = JSON.parse(raw);
  if (new Date(progress.expires_at) < new Date()) {
    localStorage.removeItem(PROGRESS_KEY);
    return null; // expired
  }
  return progress;
}

function restoreProgress(progress) {
  sm.currentIdx = progress.current_question_index;
  sm.answers = progress.submitted_answers;
  // Re-render completed questions' score cards
  for (const ans of sm.answers) {
    if (ans.score !== undefined) {
      renderScoreCard(ans);
    }
  }
}
```

**Step 6: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: rewrite interview.html with state machine + text input + score cards"
```

---

## Phase 2: Voice Input + Follow-up + Final Report (P1, Day 3-4)

### Task 4: 语音输入集成

**Files:**
- Modify: `frontend/interview.html`

**Step 1: 复用现有 TTS 播报**

保留现有 `speakQuestion()` 函数，在状态机的 `speaking` 状态下调用。

**Step 2: 复用现有 ASR 录音**

保留现有 `startRecording()` / `stopRecording()` / `sendAudioForASR()` 函数。
修改 `sendAudioForASR()` 使 ASR 结果填入文字输入框（而非直接添加到对话记录）：

```javascript
async function sendAudioForASR(blob) {
  sm.setState(STATES.TRANSCRIBING);
  try {
    const formData = new FormData();
    formData.append('audio', blob, 'recording.webm');
    const resp = await fetch('/api/interview/asr', { method: 'POST', body: formData });
    const data = await resp.json();

    if (data.text && data.text.trim()) {
      document.getElementById('answer-input').value = data.text.trim();
      sm.setState(STATES.EDITING); // 候选人可编辑转写结果
    } else {
      sm.setState(STATES.ERROR);
      showError('语音识别失败，请改用文字输入');
    }
  } catch (e) {
    sm.setState(STATES.ERROR);
    showError('网络错误，请重试');
  }
}
```

**Step 3: TTS 降级检测**

```javascript
function checkTTSAvailability() {
  if (!('speechSynthesis' in window)) return false;
  const voices = speechSynthesis.getVoices();
  return voices.some(v => v.lang.startsWith('zh'));
}

// 在 startInterview() 中检测
if (!checkTTSAvailability()) {
  document.getElementById('tts-fallback-hint').classList.remove('hidden');
  // 显示 "语音播报不可用，请阅读题目文字" 提示
}
```

**Step 4: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: integrate voice input (TTS + ASR) with text editing fallback"
```

---

### Task 5: 追问流程

**Files:**
- Modify: `frontend/interview.html`
- Modify: `app/main.py` (quick-evaluate 返回 follow-up 提示)

**Step 1: 实现追问 UI 和逻辑**

```javascript
async function handleFollowUp() {
  const followUpText = generateFollowUpPrompt(sm.questions[sm.currentIdx]);
  addTranscriptMessage('面试官', followUpText);
  speakQuestion(followUpText);
  sm.setState(STATES.IDLE_INPUT); // 等待候选人回答追问
}

function generateFollowUpPrompt(question) {
  const lastResult = sm.answers[sm.answers.length - 1];
  const missed = lastResult?.missed_points?.join('、') || '部分要点';
  return `关于这道题，能否补充一下${missed}方面的内容？`;
}

// 在 submitTextAnswer() 中，追问回答后的处理：
// 如果 isFollowUp=true，重新评估但不更新 score（取最高分）
```

**Step 2: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: add follow-up flow (max 2 rounds per question)"
```

---

### Task 6: 最终报告 + Pipeline 同步

**Files:**
- Modify: `frontend/interview.html`
- Modify: `app/main.py` (submit-answers 已有 pipeline 同步)

**Step 1: 实现面试完成流程**

```javascript
async function finishInterview() {
  sm.setState(STATES.THINKING); // "生成报告中..."

  // 调用 submit-answers 做全量评估 + pipeline 同步
  const answers = sm.answers.map(a => ({
    question_index: a.question_index,
    answer_text: a.answer_text,
  }));

  try {
    const resp = await fetch('/api/interviews/submit-answers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pipeline_id: pipelineId,
        candidate_id: candidateId,
        candidate_name: candidateName,
        answers: answers,
      }),
    });
    const result = await resp.json();

    if (result.assessment) {
      renderFinalReport(result.assessment);
    }
  } catch (e) {
    showError('报告生成失败，请稍后重试');
  }

  sm.setState(STATES.COMPLETE);
  localStorage.removeItem(PROGRESS_KEY); // 清理断点数据
}

function renderFinalReport(assessment) {
  const overlay = document.getElementById('end-overlay');
  overlay.classList.remove('hidden');

  const dims = assessment.dimensions || {};
  const dimLabels = {
    technical_expression: '技术表达',
    logical_thinking: '逻辑思维',
    communication: '沟通能力',
    learning_willingness: '学习意愿',
    culture_fit: '文化匹配',
  };

  let dimsHtml = Object.entries(dimLabels).map(([key, label]) => {
    const val = dims[key] || 0;
    const pct = Math.round(val);
    return `<div class="dim-row">
      <span class="dim-label">${label}</span>
      <div class="dim-bar"><div class="dim-fill" style="width:${pct}%"></div></div>
      <span class="dim-val">${pct}</span>
    </div>`;
  }).join('');

  document.getElementById('report-content').innerHTML = `
    <h2>✅ 面试完成</h2>
    <div class="overall-score">综合评分: ${assessment.overall_score || 0}/100</div>
    <div class="dimensions">${dimsHtml}</div>
    <div class="highlights">
      <div class="label">亮点:</div>
      ${(assessment.highlights || []).map(h => `<span>· ${h}</span>`).join('<br>')}
    </div>
    <div class="concerns">
      <div class="label">建议提升:</div>
      ${(assessment.concerns || []).map(c => `<span>· ${c}</span>`).join('<br>')}
    </div>
    <p class="sync-note">感谢您的面试，结果已提交。</p>
    <div class="actions">
      <button class="btn btn-primary" onclick="downloadReport()">下载报告</button>
      <button class="btn btn-outline" onclick="closeEndOverlay()">关闭</button>
    </div>
  `;
}
```

**Step 2: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: final report + pipeline sync via submit-answers API"
```

---

## Phase 3: Error Recovery + Mobile (P2, Day 5)

### Task 7: 错误恢复策略

**Files:**
- Modify: `frontend/interview.html`

**Step 1: 实现错误 UI 和重试逻辑**

```javascript
function showError(message, retryAction) {
  const errorEl = document.getElementById('error-toast');
  errorEl.textContent = message;
  errorEl.classList.remove('hidden');

  if (retryAction) {
    errorEl.innerHTML += ` <button onclick="${retryAction}">重试</button>`;
  }

  // Auto-hide after 5 seconds for non-critical errors
  setTimeout(() => errorEl.classList.add('hidden'), 5000);
}

// 网络断连检测
window.addEventListener('online', () => {
  document.getElementById('offline-banner')?.classList.add('hidden');
});
window.addEventListener('offline', () => {
  showError('网络连接已断开，答案已缓存');
  saveProgress(); // 缓存到 localStorage
});

// ASR 降级：语音失败自动切换到文字
function fallbackToTextInput() {
  sm.setState(STATES.IDLE_INPUT);
  document.getElementById('voice-tab')?.classList.add('disabled');
  showError('语音识别失败，请改用文字输入');
  switchToTextInput();
}
```

**Step 2: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: error recovery with retry, offline detection, ASR fallback"
```

---

### Task 8: 移动端适配

**Files:**
- Modify: `frontend/interview.html`

**Step 1: 响应式 CSS**

```css
@media(max-width:768px) {
  .main { flex-direction: column; }
  .left-panel { width: 100%; min-width: 0; max-height: 55vh; }
  .right-panel { height: 45vh; }

  .input-area {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #fff;
    border-top: 1px solid var(--border);
    padding: 12px;
    z-index: 20;
  }

  .score-card { margin: 8px; }
}
```

**Step 2: API 可用性检测**

```javascript
function detectCapabilities() {
  const caps = {
    tts: checkTTSAvailability(),
    asr: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
    mediaRecorder: !!window.MediaRecorder,
  };

  if (!caps.tts) {
    document.getElementById('tts-fallback-hint').classList.remove('hidden');
  }
  if (!caps.asr || !caps.mediaRecorder) {
    document.getElementById('voice-tab')?.classList.add('disabled');
    document.getElementById('voice-unavailable-hint')?.classList.remove('hidden');
  }

  return caps;
}
```

**Step 3: Commit**
```bash
git add frontend/interview.html && git commit -m "feat: mobile responsive layout + API capability detection"
```

---

## Execution Summary

| Phase | Tasks | Duration | Commits |
|-------|-------|----------|---------|
| P0 | Task 1-3 (API + state machine + text input) | Day 1-2 | 4 |
| P1 | Task 4-6 (voice + follow-up + report) | Day 3-4 | 3 |
| P2 | Task 7-8 (error recovery + mobile) | Day 5 | 2 |

**Total: 8 tasks, ~9 commits, 3-5 days**
