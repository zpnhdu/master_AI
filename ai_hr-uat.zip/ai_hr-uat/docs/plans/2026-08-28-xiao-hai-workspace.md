# 小海海报工作台布局实施计划

> **For implementer:** Use TDD throughout. Write the failing test first and verify it fails for the intended reason.

**Goal:** 将小海工作台收敛为海报主区加 AI 修改侧栏，默认配置一键生成，画幅和素材变为可选设置。

**Architecture:** 只调整 React 页面结构、素材选择器展示变体、工作台 CSS 和 UI 文案；保留现有生成 API、版本逻辑和对话命令状态机。

## Task 1: 更新工作台结构测试

- 修改 `frontend-react/src/app/pages/XiaoHaiPage.test.tsx`，断言配置不再占用常驻左栏，版本胶片位于海报工作区，素材入口可见。
- 运行页面测试确认新断言在旧三栏结构上失败。

## Task 2: 实现两栏工作台与可选素材入口

- 修改 `frontend-react/src/app/pages/XiaoHaiPage.tsx`，移除常驻配置栏，把版本列表放入主海报区，并保留快捷卡一键生成。
- 修改 `frontend-react/src/features/xiao-hai/MaterialPicker.tsx`，增加紧凑入口变体，默认素材不展开。
- 修改 `frontend-react/src/styles.css`，增加两栏布局、紧凑素材入口和移动端顺序样式。

## Task 3: 简化生成状态文案

- 修改 `frontend-react/src/features/xiao-hai/XiaoHaiCommandCard.tsx`，将模型实现步骤改为“整理文案 / 生成画面 / 合成品牌信息”。
- 保留确认、取消、采用和继续修改动作。

## Task 4: 验证

- 运行 `pnpm vitest run src/app/pages/XiaoHaiPage.test.tsx`。
- 运行 `pnpm run typecheck`。
