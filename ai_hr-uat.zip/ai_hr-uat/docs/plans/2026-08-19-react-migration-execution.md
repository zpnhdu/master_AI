# React 迁移收尾执行计划（全页面功能走通 + 样式一致 + 流水线全链路）

> 基线：2026-08-19（周三）
> 背景：HTML → React 迁移已基本完成页面覆盖，当前存在三类问题：
> 1. 样式与旧版 HTML 风格不一致（要求：与原来尽量保持一致）；
> 2. 迁移后功能完整性未经系统验证（要求：**React 下所有页面功能都要走通**）；
> 3. 完整流水线（创建 → 小文 → 小寻 → 小筛 → 小面 → 小评）目前走不通。
> 依据：`docs/frontend-migration/migration-plan.md`、`acceptance-checklist.md`、
> `frontend-react/src/app/router.tsx`、`app/routers/pages.py`、`hr_harness/orchestrator.py`

## 核心目标（两条硬要求）

1. **功能全覆盖走通**：React 下所有页面（共 19 个路由页面，见下方清单）的每个功能点必须逐一验证走通，不允许"页面能打开就算完成"；
2. **样式尽量一致**：CSS 样式尽量按照旧版 HTML 的风格走；无法 1:1 还原时以旧版风格为基准按 React 方式（Antd 组件、BEM 命名）优化，不引入第三套视觉语言。

### React 全页面验证清单（19 个路由页面）

| # | 路由 | 页面 | 核心功能验证点 |
| --- | --- | --- | --- |
| 1 | `/login` | 登录页 | 登录成功跳转、错误提示、过期处理 |
| 2 | `/forbidden` | 无权限页 | 无权限访问时正确展示 |
| 3 | `/studio` | 流水线管理 | 创建/删除/批量删除、搜索排序分页、统计卡片、Agent/公司配置弹窗、本体规则 |
| 4 | `/pipelines/:id` | 流水线详情 | 阶段卡片、消息流、简历导入（简单/OCR）、KG 推荐、自动运行、跳转各 Agent 页 |
| 5 | `/xiao-wen` | 小文 JD 工作台 | 对话生成/修改 JD、草稿保存、审批、画像生成、传递下游 |
| 6 | `/xiao-xun` | 小寻简历获取 | 简历上传解析、人才库推荐导入、候选人列表 |
| 7 | `/xiao-shai` | 小筛简历筛查 | 阈值规则、筛查执行、通过/淘汰结果 |
| 8 | `/xiao-mian` | 小面面试出题 | 批量出题、题目审核/改题、导出 md/docx、笔试发起 |
| 9 | `/xiao-ping` | 小评录用评估 | 评估队列、人工复核、生成报告、报告对话 |
| 10 | `/xiao-hai` | 小海海报 | 海报生成指令、产物展示 |
| 11 | `/mass-dashboard`(/:id) | 面试中心 | 岗位列表、候选人监控、WS 实时状态 |
| 12 | `/mass-interview/:token` | 候选人面试 | 免登进入、答题、媒体录制、token 失效/过期态 |
| 13 | `/talent-pool` | 人才库 | 列表、筛选、导入导出 |
| 14 | `/profile` | 人才画像 | 21 维雷达图、详情展示 |
| 15 | `/dashboard` | 数据看板 | ECharts 图表、招聘漏斗数据加载 |
| 16 | `/monitor` | 系统监控 | 监控指标展示 |
| 17 | `/knowledge` | 知识图谱 | D3/Canvas 图谱渲染、节点交互 |
| 18 | `/roles/:roleId` | 角色管理 | Agent 配置/日志/测试 |
| 19 | `/` `/pipeline-detail` | 入口跳转 | 默认落地页、legacy 重定向正确 |

> 未迁移页面（`/admin`）不在本计划范围内，按单独排期推进。视频面试与视频笔试候选人页面已由 React 路由 `/mass-interview/{token}`、`/written-test/{token}` 承接。

## 调研结论：流水线走不通的三大嫌疑断点

| # | 断点 | 证据 | 影响 |
| --- | --- | --- | --- |
| D1 | React 端几乎没接 WebSocket | 全 `frontend-react/src` 仅 `MassDashboardPage.tsx` 有 WS；`pipeline-detail/hooks.ts` 只有 `staleTime: 10s` 的静态查询，无轮询无 WS | JD 生成/匹配/出题等长任务前端收不到进度和结果，流水线"看起来走不动"，最大嫌疑 |
| D2 | report agent 默认 disabled | `hr_harness/orchestrator.py` 中 `"report": {"enabled": False}`，`_enabled_registry()` 会过滤它 | 走到小评时报告生成链路断裂 |
| D3 | 小评前置环节在 React 端缺失 | report 依赖 video_assess（需视频上传）+ interview_gen 完成；React 无视频上传入口，xiao-mian 只做了出题审核 | 即使 D2 修好，小评也拿不到评估数据 |

已排除：`/api/assessment-flow` 路由已注册（`app/main.py`），小评 API 层（queue/review/generateReport）实现完整。

## 全局机制：问题回归闭环（所有阶段通用）

```text
发现问题 → 登记 ISSUE-{阶段}-{序号} → 最小化修复 → 局部自测 → 全量回归 → 通过关闭
                                                        ↓ 未通过
                                                     回到修复
```

- **问题登记格式**：`ID | 严重级(P0阻断/P1功能缺失/P2样式偏差) | 复现步骤 | 涉及文件 | 状态`
- **关闭标准**：修复后同一用例连续通过 2 次（手动链路）或自动化用例进回归集，才允许关闭
- **回归集**：`pnpm vitest run`（单元）+ Playwright 已有用例 + 本阶段新增用例，任一失败则阻塞进入下一阶段
- **铁律**：不改后端 API 协议；后端只允许配置级修改（如 agent 启用开关）

## 阶段 0：实测基线与断点定位（0.5 天）

| 项 | 内容 |
| --- | --- |
| 目标 | 把"流水线走不通"从猜测变成精确断点清单 |
| 执行 | ① 启动后端 + React（确认 `FRONTEND_APP_ENABLED=1`）；② 测试账号登录，手动完整走一遍：创建 → 小文 JD → 小寻导简历 → 小筛筛查 → 小面出题 → 小评报告；③ 每步记录：HTTP 请求/响应、WS 消息、控制台错误、页面表现 |
| 自测标准 | 输出断点清单，验证或排除 D1/D2/D3 |
| 产出 | `ISSUE-0-xx` 断点表 + 旧版各页截图基线（后续样式对照用） |
| 通过条件 | 每个断点有明确根因归类（WS / 配置 / 功能缺失 / 样式） |

### 阶段 0 实测结果（2026-08-19，测试流水线 p_1f205b35）

**断点验证结论**：D1 确认（无 WS 无轮询，后端已 done 前端静止，需手动刷新）；D2 排除（`/api/agents` 中 report `enabled=1`，静态分析的默认值与实际 DB 配置不符）；D3 确认（小评空队列无可操作上游引导）。

| ISSUE | 严重级 | 描述 | 状态 |
| --- | --- | --- | --- |
| ISSUE-0-01 | P0 | 流水线详情页无实时更新：后端 jd_write/profile_build/poster_gen 已 done，前端无 WS/轮询，必须手动刷新 | 待修（阶段1） |
| ISSUE-0-02 | P0 | 小评页评估队列为空时无上游操作指引（导入简历→筛查→评估），用户遇死胡同 | 待修（阶段2） |
| ISSUE-0-03 | P1 | 创建流水线成功后不自动跳转详情页，仅 toast | 已关闭（阶段3，合并 ISSUE-1-02：创建成功后 navigate 详情页） |
| ISSUE-0-04 | P1 | 详情页顶部状态徽标与进度不同步（进度 33% 徽标仍“待启动”） | 已关闭（阶段3，合并 ISSUE-1-03：selectors 阶段状态语义修正） |
| ISSUE-0-05 | P2 | Agent 页直接访问无 `?pipeline=` 参数时报错无友好降级（应引导选择流水线） | 已关闭（阶段3：六个 Agent 页均已有 AgentStatus/Alert 缺参降级，实测确认） |

**阶段 1 完成记录（2026-08-19）**：

| ISSUE | 严重级 | 描述 | 状态 |
| --- | --- | --- | --- |
| ISSUE-0-01 | P0 | 详情页无实时更新 | 已关闭：新建 `shared/usePipelineSocket.ts`（`/ws/{id}` 连接/load_pipeline 订阅/3s 重连/30s 心跳），接入详情页+小文+小面，vitest 7/7、全量 153/153 通过，实测事件到达 1-2s 内自动刷新 |
| ISSUE-1-01 | P0 | auto-run 主链不广播阶段事件（`run_pipeline_bg` 未传回调） | 已关闭：`app/services.py` 增加 broadcast 回调（stage_start/done/progress/error/pipeline_done），实测不刷新自动更新 |
| ISSUE-1-02 | P1 | 创建弹窗“创建并启动”后 loading 不关闭也不跳转详情页 | 已关闭（阶段3：成功后关闭弹窗并 navigate 详情页，失败保留弹窗+重试） |
| ISSUE-1-03 | P1 | 阶段卡片状态文案误导：jd_write 已 done 仍显示“待启动” | 已关闭（阶段3：selectors 新语义 running/进行中/progress，断言同步更新） |
| ISSUE-1-04 | P2 | JD 生成工作地点未按创建输入城市（创建弹窗无城市字段） | 已关闭（阶段3：创建弹窗新增可选“工作地点”字段，并入 hints，不改后端协议） |

回归基线：`tests/test_assessment_flow.py`+`test_assessment_dispatch.py` 12 passed；`test_api_comprehensive::test_02` 为存量失败（裸请求需鉴权 API，与本次改动无关）。

**阶段 2 完成记录（2026-08-19）**：

| ISSUE | 严重级 | 描述 | 状态 |
| --- | --- | --- | --- |
| ISSUE-0-02 | P0 | 小评空队列无上游引导 | 已关闭：`XiaoPingPage.tsx` 新增引导 Alert（小寻→小筛→小面三链接），实测文案/跳转均正确 |
| — | P2 | antd 弃用告警（Alert message/Statistic valueStyle） | 已顺手修复（title/styles.content） |

D2 已在阶段 0 排除（report `enabled=1`）。报告生成实测需完整候选人评估数据，归入阶段 5 全链路 E2E 一并执行；API 层证据：`test_assessment_flow.py` 12 passed、queue API 实测 200。

**阶段 3 完成记录（2026-08-19）**：

19 页对照清单已逐项完成，P0/P1 缺口清零。新登记与修复项：

| ISSUE | 严重级 | 描述 | 状态 |
| --- | --- | --- | --- |
| ISSUE-3-01 | P0 | 小筛规则 Card 缺 skills 命中模式/最少命中数、location 开关、salary_max、bonuses 增删 | 已关闭：`XiaoShaiPage.tsx` 补齐 4 组规则控件 |
| ISSUE-3-02 | P0 | 小面笔试发起后无结果展示（sessions 链接不可见） | 已关闭：`XiaoMianPage.tsx` 发起成功后展示笔试链接列表（复制/邮件） |
| ISSUE-3-03 | P0 | 小海素材库 elements CRUD 与 versions/import 缺失 | 已关闭：`xiao-hai/api.ts` 新增 4 个 API + `XiaoHaiPage.tsx` 素材库 Card（上传/删除）+“导入为图生图基础版本” |
| ISSUE-3-04 | P1 | dashboard success_rate 双倍换算（后端已是百分比又 ×100） | 已关闭：`DashboardPage.tsx` 去掉 ×100 |
| ISSUE-3-05 | P1 | login 无隐私协议勾选即可登录 | 已关闭：`LoginPage.tsx` 增加协议 Checkbox 校验 |
| ISSUE-3-06 | P1 | talent-pool 缺永久删除 | 已关闭：`TalentPoolPage.tsx` 三按钮确认弹窗 + `?permanent=true` |
| ISSUE-3-07 | P1 | 小评报告缺薪资建议表（salary_recommendations） | 已关闭：`XiaoPingPage.tsx` ReportCard 新增薪资建议 Table |
| ISSUE-3-08 | P1 | knowledge 图谱问答未带 context_nodes | 已关闭：`KnowledgePage.tsx` 选中节点传入 streamKnowledgeChat |
| ISSUE-3-09 | P1 | mass-dashboard WS 断线不重连、缺逐题回放与回放入口 | 已关闭：`MassDashboardPage.tsx` 3s 重连 + EvaluationPanel 逐题回放（旧版 URL 公式）+ 排名卡回放按钮 |
| ISSUE-3-10 | P1 | Studio 公司配置缺 poster_template；创建弹窗缺 KG 识别卡 | 已关闭：`StudioConfigModals.tsx` 海报模板 Select + `StudioPage.tsx` KgIdentifyCard（debounce 300ms） |
| ISSUE-3-11 | P1 | profile 雷达图轴标签点击无联动 | 已关闭：`ProfilePage.tsx` radarEvents 点击高亮维度卡 |
| 审计证伪 | — | “dashboard AI问答”缺口：grep 旧版 dashboard.html 无任何 chat/问答功能 | 判定审计误判，不实施 |

回归基线：`pnpm tsc --noEmit` 通过；`pnpm vitest run` 153/153（17 文件）全绿，连续 2 次通过。测试修复：StudioPage/MassDashboardPage 测试 wrapper 补 `<AuthProvider>`（AppShell 引入 useAuth 后）；selectors.test 断言同步 ISSUE-1-03 新语义。

**阶段 4 完成记录（2026-08-19）**：

Token 对齐：旧版 UI 主色实测为 `#2563eb`（shared.css --primary）；计划文档提及的 `#E60012` 为锅圈品牌色（仅海报/公司配置用），非 UI 主色，已实测纠正。ConfigProvider 补齐 colorSuccess/Warning/Error/colorBorder/colorBgLayout(#fbf9f6)/borderRadius(10/14/8)，styles.css :root 注册 --legacy-* 变量，`.agent-page` 背景 #f5f7fb → #fbf9f6 对齐旧版。

| ISSUE | 严重级 | 描述 | 状态 |
| --- | --- | --- | --- |
| ISSUE-4-01 | P1 | dev 下 /static 未代理，SPA fallback 返回 HTML 导致 studio logo/吉祥物破图 | 已关闭：vite.config.ts 补 /static、/uploads 代理，实测 image/png |
| ISSUE-4-02 | P2 | 登录页极简单卡片与旧版双栏品牌布局差异大 | 已关闭：LoginPage 重写为旧版双栏（深绿 hero+吉祥物+绿色按钮+footer），样式 1:1 移植自旧版 login.html，浏览器复检 ✓ |
| ISSUE-4-03 | P2 | dashboard 侧栏 Sider breakpoint 自动折叠截断菜单文字 | 已关闭：移除 breakpoint/collapsedWidth；导航文案对齐旧版（流水线管理/数据看板） |
| ISSUE-4-04 | P1 | 小面/小海对话 401：8888 dev 后端运行旧代码（会话接口旧鉴权要求固定 cookie），--reload 未生效 | 已关闭：重启 dev 后端后 ensure 200，浏览器复检无 401（非代码缺陷） |
| ISSUE-4-05 | P2 | 小海素材库 11 张缩略图 404：manifest 有条目但 backgrounds/elements 目录无实体文件 | 登记不修：新旧版同一后端同一行为（旧版同 404），数据资产缺失非迁移缺陷，进遗留风险 |

截图证据：`output/visual-compare/`（r4-* 与 legacy-* 共 23 张）、`output/recheck-*.png`（修复后复检）。Browser 复检结论：登录页/隐私勾选/logo/侧栏/小面对话/小海 API 全部 ✓。回归：tsc 通过，vitest 153/153 全绿。

**旧版截图基线**：`output/01-studio-pipelines.png`、`04-xiao-wen.png`、`05-xiao-xun.png`、`07-xiao-ping.png`（React 现状，后续阶段 4 样式对照前需补拍旧版 HTML 页面截图）。

## 阶段 1：WebSocket 实时链路（1-2 天）— 最高优先级

| 项 | 内容 |
| --- | --- |
| 任务 | ① 新建 `frontend-react/src/shared/usePipelineSocket.ts`：连 `/ws`、按 pipeline_id 订阅、断线重连、页面卸载清理；② WS 事件（`stage_start/progress/card/done/error/pipeline_done`）→ `queryClient.invalidateQueries` 联动；③ 接入 pipeline-detail（现无实时更新）；④ 替换小文的 30×2s 轮询（保留轮询作降级）；⑤ 小面出题进度接 WS |
| 自测 | vitest：hook 重连/清理逻辑；手动：创建流水线后 JD 生成进度实时可见、卡片自动出现 |
| 回归 | 全量 vitest + 现有 Playwright smoke |
| 通过条件 | 阶段事件到达后 1 秒内页面自动刷新，无需手动 F5；断网重连后不丢事件 |

## 阶段 2：小评链路打通（1-2 天）

| 项 | 内容 |
| --- | --- |
| 任务 | ① 后端：验证通过（report agent 实际 `enabled=1`，D2 已排除）；② 小评页前置引导：评估队列为空时明确提示"先完成小寻导入简历→小筛筛查→小面评估"，而非空表；③ 验证 pass-artifact 小面→小评产物传递；④ 打通 assessment-flow queue → review → 生成报告 → 报告持久化 |
| 自测 | 从阶段 0 的测试流水线手动走到生成报告；检查 `report` stage output 落库 |
| 回归 | 后端相关 pytest（`tests/test_assessment_flow.py` 等）+ vitest |
| 通过条件 | 报告成功生成、可复现（刷新后仍在）、`ISSUE-0-*` 中小评断点关闭 |

## 阶段 3：全页面功能对照与补齐（3-5 天）— 覆盖全部 19 个页面

| 项 | 内容 |
| --- | --- |
| 任务 | ① 对上方清单**全部 19 个页面**逐一建功能对照清单：从旧 HTML 提取「fetch 调用 + WS 事件 + 按钮/跳转」三类，逐项与 React 对照打勾；② 按清单补差距，优先级：P0 流水线主链（pipeline-detail → 五个 Agent 页）> P1 高频页（studio/面试中心/人才库/看板）> P2 其余页（monitor/knowledge/roles/profile/mass-interview 等）；③ 每补一项同步写 Playwright 用例；④ 无旧版对照的新页面（如 roles）按需求文档验证功能点 |
| 自测 | 对照清单逐项 ✓；每项改动跑对应新用例；19 页逐一手动冒烟（能打开、数据加载、核心操作可用） |
| 回归 | 全量 vitest + Playwright 全量（含新增） |
| 通过条件 | **19 个页面全部走通**、对照清单无 P0/P1 缺口；发现的新问题走闭环机制直至关闭 |

## 阶段 4：全页面样式对齐（2-3 天）— 覆盖全部 19 个页面

| 项 | 内容 |
| --- | --- |
| 任务 | ① 从旧版提取设计 token（主色 `#E60012`、卡片/边框/字号/圆角）→ CSS variables → Antd `ConfigProvider` theme；② **19 个页面逐一**与阶段 0 旧版截图对照：studio → pipeline-detail → 五个 Agent 页 → 面试中心/候选人面试 → 人才库/画像/看板/监控/知识图谱/角色页 → login/forbidden；③ 样式尽量与原来保持一致：能还原的照还原；结构冲突的按 Antd 规范优化（间距/层级/状态色统一）并记录偏差原因 |
| 自测 | 逐页 before/after 截图对比；分辨率 1280/1440/1920 三档；移动优先页（mass-interview）加测 375/414 |
| 回归 | vitest + Playwright（样式不应破坏已有交互用例） |
| 通过条件 | **19 个页面**视觉走查全部通过，P2 样式问题清零或明确降级记录 |

## 阶段 5：全链路 E2E 固化 + 验证报告（1 天）

| 项 | 内容 |
| --- | --- |
| 任务 | ① Playwright 全链路用例：`登录 → 创建流水线 → JD生成 → 上传简历 → 筛查 → 出题 → 小评报告`，进 CI；② 全页面冒烟用例：19 个路由逐一访问，断言无 JS 报错、关键元素可见；③ 回滚演练：关闭 `FRONTEND_APP_ENABLED` 确认旧版回退正常；④ 输出《迁移验证报告》 |
| 通过条件 | CI 全绿（全链路 + 19 页冒烟）；报告签发 |

**阶段 5 完成记录（2026-08-19）**：

1. **E2E 固化**：新增 `e2e/helpers.ts`、`e2e/pages-smoke.spec.ts`（19 路由逐一冒烟：关键元素可见 + pageerror 为空）、`e2e/full-pipeline.spec.ts`（serial 7 步：登录→创建流水线→详情页 WS→小文 ensure→小寻 candidates→小筛 screening-workflow→小面 review→小评 queue，UI+API 双层断言）。Playwright 共 27 用例，**连续两次 27/27 全绿**。
2. **回归集**：`tsc --noEmit` 通过；vitest 17 文件 153/153；后端 `test_assessment_flow.py`+`test_assessment_dispatch.py` 12 passed 背书深层 LLM 链路。
3. **回滚演练**：独立实例 :8892 以 `FRONTEND_APP_ENABLED=0` 启动，`/api/health`、登录、`studio.html`、`xiao_wen.html`、`dashboard.html`、`login.html`、`/api/pipelines` 均 200 且无 307 跳转，旧版回退路径有效。
4. **报告签发**：`docs/frontend-migration/migration-verification-report.md`（9 节齐全：范围与基线 / 测试矩阵 / 问题台账 / 全链路证据 / 全页面证据 / 样式对照 / 回滚演练 / 遗留风险 / 结论），结论：**达到上线标准（签发）**。
5. **遗留风险**（不阻塞签发）：未迁移页面单独排期；小海素材库实体文件缺失（ISSUE-4-05）；dashboard 漏斗图新旧版共性问题；E2E 高并发下 dev 后端偶发超时；全链路 E2E 会真实创建流水线建议 CI 隔离 DB。

## 《迁移验证报告》模板（阶段 5 产出）

```text
1. 范围与基线：迁移页面清单（19 个路由）、后端协议未变更声明
2. 测试矩阵：19 页面 × 用例 × 结果（单测/E2E/手动），每页一行结论
3. 问题台账：ISSUE-* 全列表、严重级、修复提交、关闭状态
4. 全链路走通证据：创建→小评 每步的请求/截图/WS 记录
5. 全页面走通证据：19 页逐页功能验证结果（✓/✗ + 备注）
6. 样式对照：19 页逐页 before/after 截图，偏差项附原因说明
7. 回滚演练：开关关闭后旧版可用性确认
8. 遗留风险与建议：未迁移页面、性能项、监控项
9. 结论：是否达到上线标准（签发/有条件签发/不签发）
```

## 总览

| 阶段 | 工期 | 阻塞下一阶段的条件 |
| --- | --- | --- |
| 0 实测定位 | 0.5 天 | 断点清单未出 |
| 1 WebSocket | 1-2 天 | 事件到达未自动刷新 |
| 2 小评链路 | 1-2 天 | 报告未生成 |
| 3 全页面功能补齐 | 3-5 天 | 19 页对照清单有 P0/P1 缺口 |
| 4 全页面样式对齐 | 2-3 天 | 走查未通过 |
| 5 E2E+报告 | 1 天 | CI 未全绿（含 19 页冒烟） |

合计约 **9-13 个工作日**。

## 样式问题处理原则（贯穿全程）

1. CSS 样式**尽量与旧版 HTML 保持一致**（token、布局、层级、状态色），一致性是第一优先级；
2. 无法 1:1 还原时，以旧版风格为基准、按 Antd 组件规范以 React 方式优化，不引入第三套视觉语言，且必须在验证报告中记录偏差原因；
3. 旧版截图（阶段 0 产出）是所有样式争议的裁决基线；
4. 样式验收覆盖全部 19 个页面，任何一页走查不通过都阻塞阶段 5 签发。

## 功能走通原则（贯穿全程）

1. React 下**所有页面**（19 个路由）的功能都要走通，验收粒度到功能点而非页面级；
2. 核心业务链路（创建 → 小评）必须端到端完整跑通，作为签发的硬性前提；
3. 每个页面的验证结果（✓/✗）必须进入《迁移验证报告》测试矩阵，不允许跳过。
