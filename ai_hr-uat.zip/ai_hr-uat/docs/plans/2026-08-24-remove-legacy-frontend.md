# 删除旧 frontend 并统一 OSS 素材读取实施计划

> **For implementer:** Use TDD throughout. Write failing tests first, then implement the smallest change.

**Goal:** 删除旧版 `frontend/` 目录，让 React 负责页面静态资源、后端素材接口和海报生成统一从 OSS 读取。

**Architecture:** `frontend-react/public` 只保留 React 登录页需要的静态资源；品牌图、海报模板、元素库和参考图的服务端读取统一通过 `MediaStorage` 的 OSS 实现。后端不再读取 `frontend/`，也不再把旧 HTML 作为 React 不可用时的页面回退；旧 URL 仅保留到 React 路由的兼容重定向。

**Tech Stack:** FastAPI、Python、`oss2`、pytest、React/Vite、pnpm。

---

### Task 1: 锁定 OSS-only 素材读取行为

**Files:**
- Modify: `tests/test_brand_assets.py`
- Modify: `tests/test_template_compositor.py`
- Modify: `tests/test_xiao_hai_routes.py`
- Modify: `tests/test_element_library.py`
- Modify: `tests/test_frontend_switch.py`

**Step 1: Write failing tests**

- 品牌素材在 OSS 对象不存在时不得扫描或读取旧 `frontend/brand`。
- 海报合成器和小海默认吉祥物不得构造 `frontend/*` 路径。
- React 入口可用时，旧页面 URL 只重定向到 React；React 构建不可用时返回明确 404，不读取旧 HTML。
- 小海画布、元素和参考图接口只调用 `MediaStorage`。

**Step 2: Run tests — confirm they fail**

```bash
python -m pytest -q tests/test_brand_assets.py tests/test_template_compositor.py tests/test_xiao_hai_routes.py tests/test_element_library.py tests/test_frontend_switch.py
```

Expected: FAIL because current code still has local `frontend` fallbacks and legacy page fallbacks.

### Task 2: 移除后端旧目录依赖

**Files:**
- Modify: `app/brand_assets.py`
- Modify: `app/template_compositor.py`
- Modify: `app/xiao_hai_image.py`
- Modify: `app/routers/canvas_library.py`
- Modify: `app/routers/element_library.py`
- Modify: `app/routers/xiao_hai.py`
- Modify: `app/routers/pages.py`
- Modify: `app/bootstrap/routes.py`
- Modify: `app/bootstrap/http.py`
- Modify: `app/config.py`
- Modify: `app/db.py`

**Step 1: Implement the smallest green change**

- Brand read/write/URL helpers use only the injected storage instance; missing OSS objects produce a controlled missing-resource result.
- Poster and 小海 image composition loads image bytes through `read_brand_asset` and never opens `frontend/*`.
- Canvas, element and reference APIs use OSS keys and signed URLs/bytes; local filesystem branches are removed.
- React page routes serve the React shell or return 404; old `/frontend/*.html` paths retain only React redirects.
- Static mounting removes `/frontend` and old `/static` directory mounting; favicon is read from storage.
- Database defaults use React/OSS-compatible asset URLs instead of `/static/brand/*`.

**Step 2: Run focused tests — confirm they pass**

```bash
python -m pytest -q tests/test_brand_assets.py tests/test_template_compositor.py tests/test_xiao_hai_routes.py tests/test_element_library.py tests/test_frontend_switch.py
```

### Task 3: 迁移 React 默认资源和 OSS 素材

**Files:**
- Modify: `frontend-react/src/app/components/companyBrand.ts`
- Modify: `frontend-react/src/app/components/companyBrand.test.ts`
- Modify: `scripts/migrate_assets_to_oss.py`
- Add: `frontend-react/public/brand/company-logo.png`

**Step 1: Implement**

- React 默认 Logo 改为 `/brand/company-logo.png`。
- 迁移脚本改为显式来源和 OSS-only 校验，避免删除 `frontend` 后仍引用不存在路径。
- 使用本地公开 OSS endpoint 上传现有品牌、画布、元素和参考素材，不能覆盖非目标对象之外的用户数据。

**Step 2: Verify**

```bash
APP_ENV=local python scripts/migrate_assets_to_oss.py --dry-run
APP_ENV=local python scripts/migrate_assets_to_oss.py
APP_ENV=local python -c 'from app.environment import load_environment; load_environment(); from app.media_storage import get_media_storage; s=get_media_storage(); assert s.backend == "oss"; print(len(s.list_keys("ai-hr/brand/")))'
```

Expected: dry-run lists all source assets; upload completes; OSS brand prefix contains the migrated objects.

### Task 4: 删除旧目录和部署挂载

**Files:**
- Delete: `frontend/`
- Modify: `deploy/compose/development.yml`
- Modify: `deploy/compose/production.yml`
- Modify: `deploy/README.md`
- Modify: `tests` references that assert legacy files exist

**Step 1: Delete only after Task 3 verification**

- Remove old HTML/CSS/JS, old brand copies, manifests and docs under `frontend/`.
- Remove Docker volumes that mount old frontend asset paths.
- Keep `frontend-react/` as the only frontend source/build project.

**Step 2: Verify no active references remain**

```bash
rg -n 'frontend/|FRONTEND_DIR|/static/brand' app scripts deploy frontend-react/src tests
```

Expected: no runtime path references to deleted `frontend/`; remaining `/static/brand` references must be test fixtures or migrated OSS key compatibility handled by the backend.

### Task 5: Full verification

```bash
python -m pytest -q tests/test_brand_assets.py tests/test_template_compositor.py tests/test_xiao_hai_routes.py tests/test_element_library.py tests/test_canvas_library_oss.py tests/test_frontend_switch.py
pnpm --dir frontend-react typecheck
pnpm --dir frontend-react build
git diff --check
```

Expected: focused backend tests and React typecheck/build pass; no whitespace errors or active legacy directory dependencies remain.
