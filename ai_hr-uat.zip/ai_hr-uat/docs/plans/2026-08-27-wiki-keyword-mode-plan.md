# 知识库关键词模式实施计划

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 在向量后端关闭时，彻底禁止 Wiki 查询隐式调用 embedding，并保持小文与知识库问答的关键词检索能力。

**Architecture:** 增加显式 `WIKI_VECTOR_ENABLED` 配置。Wiki 问答入口根据该开关选择 token-only 或现有 hybrid 路径；小文继续复用 Wiki Markdown 的 `WikiKnowledgeBase`。不改变 OSS 页面和 MySQL 索引结构。

**Tech Stack:** Python、FastAPI、pytest、现有 `app.wiki_store` 与 `knowledge` 检索模块。

---

### Task 1: 增加向量调用开关

**Files:**
- Modify: `app/infrastructure/config.py`
- Modify: `config/environments/.env.example`
- Modify: `config/environments/.env.local`
- Modify: `config/environments/.env.dev`
- Modify: `config/environments/.env.uat`
- Modify: `config/environments/.env.prod`
- Test: `tests/test_wiki.py`

**Step 1: Write the failing test**

增加配置断言，验证默认值为关闭，并让 `wiki_query` 可读取该配置。

**Step 2: Run test — confirm it fails**

Command: `PYTHONPATH=. pytest tests/test_wiki.py -q`

Expected: FAIL because `InfrastructureSettings` has no Wiki vector switch.

**Step 3: Write minimal implementation**

在 `InfrastructureSettings` 增加 `wiki_vector_enabled: bool = _bool("WIKI_VECTOR_ENABLED", False)`，并在各环境文件显式写入 `WIKI_VECTOR_ENABLED=false`，示例文件说明开启条件。

**Step 4: Run test — confirm it passes**

Command: `PYTHONPATH=. pytest tests/test_wiki.py -q`

Expected: PASS。

**Step 5: Commit**

提交需先获得用户确认；当前共享工作区不执行 Git 写操作。

### Task 2: 关闭向量时跳过 embedding

**Files:**
- Modify: `app/wiki_query.py`
- Test: `tests/test_wiki.py`

**Step 1: Write the failing test**

构造一张 Wiki 页面，关闭开关并替换 `_embed_single` 为抛错函数；调用 `retrieve` 后断言仍有关键词命中且 embedding 函数未被调用。

**Step 2: Run test — confirm it fails**

Command: `PYTHONPATH=. pytest tests/test_wiki.py::test_wiki_query_skips_embedding_when_disabled -q`

Expected: FAIL because `retrieve` 当前无条件生成查询向量。

**Step 3: Write minimal implementation**

在 `_embed_single`、`_ensure_embedding` 和 `retrieve` 中使用 `settings.wiki_vector_enabled`。关闭时不创建查询向量、不生成页面临时向量，只用 token score。

**Step 4: Run test — confirm it passes**

Command: `PYTHONPATH=. pytest tests/test_wiki.py::test_wiki_query_skips_embedding_when_disabled -q`

Expected: PASS。

**Step 5: Commit**

提交需先获得用户确认；当前共享工作区不执行 Git 写操作。

### Task 3: 回归验证

**Files:**
- Test: `tests/test_wiki.py`

**Step 1: Run focused tests**

Command: `PYTHONPATH=. pytest tests/test_wiki.py tests/test_kb.py tests/test_wiki_ingest_recovery.py tests/test_wiki_mysql_compat.py tests/test_knowledge_bootstrap.py -q`

Expected: 全部通过。

**Step 2: Run diff checks**

Command: `git diff --check`

Expected: 无空白错误。
