# 前后端超时统一实施计划

> **For implementer:** 每个任务先写失败测试，确认失败后再写最小实现；本仓库已有并行改动，不要重置或格式化无关文件。

**Goal:** 让后端负责业务执行超时，前端只保留统一网络安全取消机制，并以 504 错误契约和阶段状态保证可恢复性。

**Architecture:** 复用现有 `agent_configs.timeout`、Pipeline stage 状态、Redis task facade 和 WebSocket。第一阶段统一同步接口的 deadline 和前端请求层；第二阶段将长任务接入现有异步/阶段状态链路，最后删除前端业务超时常量。

**Tech Stack:** FastAPI、Python asyncio、requests、React、TypeScript、Vitest、pytest。

---

### Task 1: 建立后端 deadline 工具

**Files:**
- Create: `app/infrastructure/timeout_policy.py`
- Test: `tests/test_timeout_policy.py`

**Step 1: Write the failing test**

覆盖以下行为：创建总 deadline；读取剩余秒数；剩余时间耗尽后抛出统一异常；重试预算不能超过总 deadline。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: FAIL because the timeout policy module and exception do not exist.

**Step 3: Write minimal implementation**

实现 `BusinessTimeoutError`、`TimeoutDeadline` 和 `get_agent_timeout(agent_id)`。配置优先读取后端 Agent 配置，兼容 `jd_writer` 到 `jd_write` 的别名；不要引入前端依赖。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: PASS。

### Task 2: 统一后端 LLM 调用的剩余时间

**Files:**
- Modify: `hr_harness/agents/base.py`
- Modify: `hermes_wrapper/client.py`
- Test: `tests/test_timeout_policy.py`

**Step 1: Write the failing test**

验证 BaseAgent 将 deadline 剩余秒数传给 `LLMRequest`，当剩余时间不足时不会发起下一次重试。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: FAIL because Agent 尚未支持 deadline。

**Step 3: Write minimal implementation**

让 `ToolInput.params` 可携带 deadline，`call_llm_json` 每次调用前读取剩余秒数；保留现有调用兼容性。不要只依赖 `asyncio.wait_for` 取消协程，必须把剩余时间传给 requests 层。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: PASS。

### Task 3: 移除后端硬编码阶段超时

**Files:**
- Modify: `hr_harness/dag_engine.py`
- Modify: `hr_harness/orchestrator.py`
- Modify: `app/db.py`
- Test: `tests/test_timeout_policy.py`

**Step 1: Write the failing test**

验证阶段执行使用 Agent 配置的业务 deadline，而不是固定 120 秒；验证 `jd_writer`/`jd_write` 只产生一个有效配置。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: FAIL because Supervisor 仍固定使用 120 秒。

**Step 3: Write minimal implementation**

删除或改造固定 120 秒逻辑，使用统一 timeout policy；数据库 seed 和读取逻辑统一 canonical stage ID，并保留旧数据兼容读取。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: PASS。

### Task 4: 统一同步接口的 504 契约

**Files:**
- Modify: `app/bootstrap/http.py`
- Modify: `app/routers/pipelines.py`
- Modify: `app/routers/xiao_hai.py`
- Modify: `app/action_handler.py`
- Test: `tests/test_timeout_policy.py`

**Step 1: Write the failing test**

验证 JD 生成、JD 修改预览、画像生成和海报生成超时后返回 504，响应包含 `code=backend_timeout`，阶段不保持 `running`。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: FAIL because路由当前直接返回普通 500/502 或吞掉超时异常。

**Step 3: Write minimal implementation**

增加统一超时异常处理；在长调用前后使用 deadline；超时更新阶段状态并返回结构化 504。使用现有 `request.state.request_id` 写入错误体和日志。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_timeout_policy.py -q`

Expected: PASS。

### Task 5: 前端请求层只保留网络安全超时

**Files:**
- Modify: `frontend-react/src/features/pipelines/api.ts`
- Modify: `frontend-react/src/features/agent-workbench/api.ts`
- Modify: `frontend-react/src/features/xiao-wen/api.ts`
- Modify: `frontend-react/src/features/xiao-hai/api.ts`
- Test: `frontend-react/src/features/pipelines/api.test.ts`
- Test: `frontend-react/src/features/xiao-wen/api.test.ts`
- Test: `frontend-react/src/features/xiao-hai/api.test.ts`

**Step 1: Write the failing test**

验证公共请求层能区分网络安全超时、主动 Abort 和后端 504；验证 JD/海报请求不再传入业务 timeout 参数。

**Step 2: Run test — confirm it fails**

Command: `cd frontend-react && pnpm test:run -- src/features/pipelines/api.test.ts src/features/xiao-wen/api.test.ts src/features/xiao-hai/api.test.ts`

Expected: FAIL because当前所有 AbortError 都被识别为 timeout，且业务模块显式传入 timeout。

**Step 3: Write minimal implementation**

保留一个公共网络安全超时常量；增加 504/backend_timeout 映射；移除 `JD_*_TIMEOUT_MS`、`PROFILE_BUILD_TIMEOUT_MS`、`POSTER_GENERATION_TIMEOUT_MS` 和 `requestJson` 的业务 timeout 调用。迁移期可保留参数签名但不新增使用。

**Step 4: Run test — confirm it passes**

Command: `cd frontend-react && pnpm test:run -- src/features/pipelines/api.test.ts src/features/xiao-wen/api.test.ts src/features/xiao-hai/api.test.ts`

Expected: PASS。

### Task 6: 接入剩余直接 fetch 的统一错误处理

**Files:**
- Modify: `frontend-react/src/features/knowledge/api.ts`
- Modify: `frontend-react/src/features/talent-pool/api.ts`
- Modify: `frontend-react/src/features/written-test/api.ts`
- Modify: `frontend-react/src/features/mass-interview/api.ts`
- Test: 对应已有前端测试文件

**Step 1: Write the failing test**

验证普通上传/提交请求使用统一网络取消和 504 错误提示；SSE 支持外部 AbortSignal；XHR 视频上传继续保留进度和传输超时。

**Step 2: Run test — confirm it fails**

Command: `cd frontend-react && pnpm test:run -- src/features/knowledge src/features/talent-pool src/features/written-test src/features/mass-interview`

Expected: FAIL because这些请求绕过公共请求层。

**Step 3: Write minimal implementation**

普通 JSON/上传请求接入 `requestJson`；SSE 只复用公共错误解析并保留调用方 signal；XHR 不改为 fetch。

**Step 4: Run test — confirm it passes**

Command: `cd frontend-react && pnpm test:run -- src/features/knowledge src/features/talent-pool src/features/written-test src/features/mass-interview`

Expected: PASS。

### Task 7: 长任务异步化和阶段状态联动

**Files:**
- Modify: `app/routers/pipelines.py`
- Modify: `app/routers/xiao_hai.py`
- Modify: `app/infrastructure/tasks/queue.py`
- Modify: `frontend-react/src/shared/usePipelineSocket.ts`
- Modify: 对应小文、小海页面和 API 文件
- Test: `tests/test_timeout_policy.py` and related frontend tests

**Step 1: Write the failing test**

验证长任务入口返回 queued/task 或阶段标识；任务完成、失败、超时均会通过现有 WebSocket/查询状态通知前端。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_timeout_policy.py -q` and targeted Vitest tests。

Expected: FAIL because当前长任务接口同步等待结果。

**Step 3: Write minimal implementation**

优先复用现有 Pipeline stage 和 `poster_generation_jobs`，不要新增第二套任务协议。前端收到 `stage_done`、`stage_error` 或 `timed_out` 后刷新对应查询，并保留查询降级。

**Step 4: Run test — confirm it passes**

Command: backend targeted pytest and frontend targeted Vitest。

Expected: PASS。

### Task 8: 完成静态检查和链路配置对齐

**Files:**
- Modify: `deploy/nginx/frontend.conf`
- Modify: `deploy/nginx/host.conf`
- Modify: `frontend-react/src/app/pages/RolePage.tsx`
- Test: `tests/` and `frontend-react/`

**Step 1: Write the failing test**

增加静态检查，确保前端不再定义业务级 `*_TIMEOUT_MS`，角色页面不再用 `120` 作为后端超时默认值。

**Step 2: Run test — confirm it fails**

Command: `rg -n 'JD_.*TIMEOUT_MS|PROFILE_BUILD_TIMEOUT_MS|POSTER_GENERATION_TIMEOUT_MS|timeout: config\.timeout \?\? 120' frontend-react/src`

Expected: FAIL and命中旧实现。

**Step 3: Write minimal implementation**

前端只展示后端返回配置，不在页面创建业务默认值。同步接口期间让 Nginx 上限覆盖后端最大同步 deadline；异步化完成后恢复短 API 超时。

**Step 4: Run test — confirm it passes**

Command: `pytest -q`, `cd frontend-react && pnpm typecheck && pnpm test:run`。

Expected: PASS。
