# 列表工作台交互设计

## 背景

现有列表页已经开始使用 `DataTable`，但搜索、筛选、新增、批量操作和行内操作仍由页面各自实现，造成触发方式、间距、按钮位置和异常反馈不一致。本次在 `DataTable` 之上增加轻量的列表工作台层，不触碰 `MassInterview` 分屏组件。

## 目标

- 统一搜索框和筛选下拉的视觉与交互：300ms 防抖、回车立即执行、清空立即执行、变更后回到第一页。
- 统一列表工具栏布局：左侧搜索/筛选，右侧结果信息和主操作，小屏自动换行。
- 统一批量操作反馈：显示选择数量、清空选择、明确当前页和全部结果的范围。
- 统一空数据、筛选无结果、加载失败和重试的呈现。
- 新增和编辑表单保留业务差异，失败时不丢失输入，成功后才关闭。
- 高于两项的行内操作收进更多菜单，危险操作始终有确认。

## 架构

`ListToolbar` 只负责布局，`ListSearch` 和 `ListFilterSelect` 只负责控件外观与输入行为，`SelectionActionBar` 只负责批量选择反馈。查询状态仍由页面或 `useListQueryState` 管理，业务表单和业务 API 不进入公共组件。

```text
Page
├─ ListToolbar
│  ├─ ListSearch
│  ├─ ListFilterSelect / business filters
│  └─ primary actions
├─ SelectionActionBar (selected rows only)
├─ DataTable
└─ feature-owned modal/drawer
```

## 交互约束

- 搜索输入值和实际查询值分离，避免防抖期间输入框回退。
- 筛选、排序和分页变化后回到第一页。
- 业务页面可以把查询状态同步到 URL，但公共组件不直接写 URL。
- `ListToolbar` 不创建 Modal，也不调用 API。
- 小屏宽度低于 768px 时搜索独占一行，筛选项和操作按钮换行。
- 不修改 `MassInterviewPage.tsx` 及其 feature 文件。

## 测试策略

- 公共组件测试搜索防抖、回车、清空、筛选选择、响应式 class 和批量数量文案。
- 页面测试验证搜索状态重置页码、mutation 失败保留表单、行操作菜单和危险操作确认。
- 运行前端类型检查、公共组件定向测试和受影响页面测试。
