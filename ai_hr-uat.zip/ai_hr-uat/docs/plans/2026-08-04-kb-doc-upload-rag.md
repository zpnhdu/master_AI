# 知识库文档上传 + 文档级 RAG 检索 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 让知识库页面（`frontend/knowledge.html`）的「上传文档」功能真实可用：上传文件 → 解析 → 切块 → 向量化入库 → AI 问答可引用文档内容回答。同时删除页面中 3 条写死的假「已上传文档」预设和假统计。

**Architecture:** 新 SQLite 持久化（文档元数据 + 切块 + 向量）→ 新上传/管理 API → 解析入库流水线（复用 `app/utils.py` 解析、`knowledge/embedding.py` 向量化）→ `/api/knowledge/chat` 集成文档检索 → 前端接入真实接口并移除假数据。

**Tech Stack:** Python 3.9+, FastAPI, SQLite (`app/db.py`), pytest, vanilla HTML/CSS/JS, python-multipart（已装）。

**决策摘要（已与用户确认）**
- 深度：**文档级 RAG** —— 上传→解析→切块→向量化入库，AI 问答可引用文档内容；知识图谱本体（静态 JSON）不变。
- 管理操作：删除 + 失败重试（必备）；查看提取结果做轻量版（状态/切块数/错误信息，不做全文预览）；下载原文件可选、后置。
- 假数据：删除 3 条硬编码 doc-item 与「3 份文档 · 已提取 87 个知识节点」统计，改为真实列表。

**现状（改动前基线）**
- `frontend/knowledge.html`：上传弹窗 UI 齐全（拖拽区 + 文档列表），但拖拽区仅有视觉反馈、`drop-select-btn` 无点击 handler、文档列表为硬编码假数据（约 L920-950 三个 `.doc-item`）。无任何真实上传逻辑。
- 当时的 `app/routers/knowledge.py` 尚无上传/文档管理接口；该静态图谱方案现已由 LLM Wiki 取代。
- `app/utils.py::extract_text_from_file(content, ext)`：已支持 pdf/docx/doc/txt 解析（级联 fallback）。
- `knowledge/embedding.py`：`embed_sync`（批量，batch=10）、`embed_single`、`_doc_embeddings`（**纯内存，无持久化**）、`vector_search`。
- `knowledge/base.py::KnowledgeBase`：BM25+向量混合检索，种子知识内存加载，被 hr_harness agents 使用（面试题生成等）——**本计划不改造它**，文档检索独立建库，避免影响现有 Agent 行为。

---

## Task 1: 持久化层 — 文档/切块/向量表 + 存储访问模块

**Files:**
- Create: `app/kb_docs.py`（存储与检索访问层，SQLite）
- Create: `tests/test_kb_docs.py`

### 设计

新增两张 SQLite 表（复用 `app/db.py::get_db()`，SQLite 路径 `data/aron.db`）：

```sql
CREATE TABLE IF NOT EXISTS kb_documents (
    id            TEXT PRIMARY KEY,          -- uuid4 hex
    filename      TEXT NOT NULL,
    ext           TEXT NOT NULL,             -- pdf/docx/txt/md
    size_bytes    INTEGER NOT NULL,
    file_path     TEXT NOT NULL,             -- uploads/knowledge_docs/<id>.<ext>
    status        TEXT NOT NULL DEFAULT 'processing',  -- processing/done/failed
    chunk_count   INTEGER NOT NULL DEFAULT 0,
    error_msg     TEXT DEFAULT '',
    created_at    TEXT NOT NULL,             -- ISO
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS kb_doc_chunks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id     TEXT NOT NULL REFERENCES kb_documents(id) ON DELETE CASCADE,
    chunk_idx  INTEGER NOT NULL,
    content    TEXT NOT NULL,
    embedding  TEXT NOT NULL                 -- JSON 数组，持久化向量
);
```

**要点：**
- 向量持久化为 chunks 表的 JSON 列（系统内嵌向量数小，numpy/列表比较即可，不引入向量库依赖）。
- `app/kb_docs.py` 暴露：`create_document(...)` / `list_documents()` / `get_document(doc_id)` / `update_document_status(...)` / `delete_document(doc_id)`（连表删、删文件）/ `save_chunks(doc_id, chunks_with_embeddings)` / `search_doc_chunks(query_embedding, top_k)`（内存加载后余弦相似度，复用 `embedding.cosine_similarity`）/ `rebuild_inmemory_index()`（启动时加载，供 chat 检索）。
- 删除文档时同步删除原文件（`file_path`），路径穿越防护：只允许 `UPLOAD_DIR/knowledge_docs/` 下的文件。

### 测试用例（先写，`tests/test_kb_docs.py`）

1. `test_create_and_list_document` — 创建记录后列表返回该文档，字段完整。
2. `test_update_status` — status/chunk_count/error_msg 可更新。
3. `test_save_and_search_chunks` — 保存切块（含向量）后，`search_doc_chunks` 按相似度返回 top-k（用已知向量，如 [1,0] vs [0,1]，验证排序）。
4. `test_delete_document_cascades` — 删除文档后 chunks 清除、原文件删除。
5. `test_delete_rejects_path_escape` — file_path 不在 `UPLOAD_DIR/knowledge_docs/` 下时拒绝删除。
6. `test_empty_list_returns_empty` — 无文档时返回空列表（前端空状态依赖）。

---

## Task 2: 解析入库流水线 — 文本提取 → 切块 → 向量化

**Files:**
- Create: `app/kb_ingest.py`（解析 + 切块 + 入库编排）
- Create: `tests/test_kb_ingest.py`

### 设计

```python
SUPPORTED_EXTS = {".pdf", ".docx", ".doc", ".txt", ".md"}
MAX_FILE_SIZE = 20 * 1024 * 1024        # 20MB
CHUNK_SIZE = 500                         # 字符
CHUNK_OVERLAP = 50                       # 字符

def extract_text(file_path: str, ext: str) -> str:
    # 复用 app.utils.extract_text_from_file(content, ext)；txt/md 直接按 UTF-8 读
    # 注意：extract_text_from_file 接收 bytes，读文件后传入；解析失败抛 KBParseError

def split_chunks(text: str) -> list[str]:
    # 按空行分段优先；单段超长再按 CHUNK_SIZE 滑窗（overlap CHUNK_OVERLAP）；
    # 清洗：去多余空白、控制字符；空/过短（<20 字符）段丢弃

def ingest_document(doc_id: str) -> None:
    # 编排：extract_text → split_chunks → embed_sync(chunks, "document") 批量（内部已 batch=10）
    # 成功 → save_chunks + status=done + chunk_count；异常 → status=failed + error_msg
    # 异常类型区分：解析失败（BadFile/Unsupported）/ embedding API 失败（返回友好信息）
    # embedding API Key 缺失时直接 failed：'API Key 未配置'
```

**要点：**
- 嵌入向量持久化在 `kb_doc_chunks.embedding`，入库后调用 `kb_docs.rebuild_inmemory_index()` 使检索立即可用（当前进程内）。
- `ingest_document` 可独立调用 → 天然支持「失败重试 / 重新解析」（Task 3 接口复用）。

### 测试用例（`tests/test_kb_ingest.py`）

1. `test_extract_text_txt` — 写临时 txt，提取内容等于原文。
2. `test_extract_text_unsupported_ext` — 抛 `KBParseError`。
3. `test_split_chunks_short_text` — 短文返回 1 块。
4. `test_split_chunks_long_text` — 长文按 500/overlap 50 切多块，首尾衔接（无内容丢失：拼接后去重覆盖原文子串）。
5. `test_split_chunks_drops_empty` — 空段被丢弃。
6. `test_ingest_document_success` — mock `embed_sync` 返回定长向量，ingest 后文档 status=done、chunk_count>0、chunks 表有数据。
7. `test_ingest_document_parse_failure` — 损坏文件 → status=failed 且 error_msg 非空。
8. `test_ingest_document_no_api_key` — mock `embed_sync` 抛 KeyError/连接错误 → status=failed，error_msg 含友好提示。

---

## Task 3: 后端 API — 上传 / 列表 / 删除 / 重试

**Files:**
- Edit: `app/routers/knowledge.py`（追加新端点；router 已注册在 `/api/knowledge`）
- Create: `tests/test_kb_upload_api.py`（或并入 `test_kb_docs.py`）

### 新增端点（全部挂 `/api/knowledge` 前缀下）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/documents/upload` | multipart `files: list[UploadFile]`；逐个校验扩展名/大小 → 存文件 → 建记录(status=processing) → `BackgroundTasks` 异步 `ingest_document` → 返回创建的记录列表 |
| GET | `/documents` | 文档列表，按 created_at 倒序，含 status/chunk_count/error_msg/文件大小 |
| DELETE | `/documents/{doc_id}` | 删除记录 + chunks + 原文件 |
| POST | `/documents/{doc_id}/reprocess` | 重试：status 置 processing → `BackgroundTasks` 重新 `ingest_document` |

**要点：**
- 上传即回（异步处理），前端轮询状态——UI 已有 `processing` 样式，按此设计。
- 文件保存目录：`uploads/knowledge_docs/`（由 `app/config.py::UPLOAD_DIR` 派生，`os.makedirs(exist_ok=True)`）。
- 文件名清洗：仅保留安全字符，实际落盘名用 `<doc_id>.<ext>`，杜绝路径穿越/重名。
- 校验失败（扩展名不支持 / 超 20MB）返回 400 及中文错误；空文件列表返回 400「未选择文件」。
- 错误处理：`ingest_document` 内部捕获一切异常写 status=failed，接口不抛 500。

### 测试用例

1. `test_upload_txt_success` — 上传 txt → 200，返回记录 status=processing；等 BackgroundTasks 完成后 status=done（用 TestClient 的 background 执行语义或直接调 ingest 断言）。
2. `test_upload_unsupported_ext` — 上传 `.exe` → 400。
3. `test_upload_too_large` — mock 超 20MB 文件 → 400。
4. `test_upload_empty` — 无文件 → 400。
5. `test_list_documents` — 上传后 GET /documents 返回该记录。
6. `test_delete_document` — 删除后列表为空、chunks 清空、文件不存在。
7. `test_reprocess_failed_doc` — 构造 failed 记录 → reprocess → status 回到 processing，最终 done。
8. `test_reprocess_missing_doc` — 不存在的 id → 404。

---

## Task 4: AI 问答集成 — `/api/knowledge/chat` 追加文档检索上下文

**Files:**
- Edit: `app/routers/knowledge.py`（`api_knowledge_chat` 内新增文档检索分支）
- Edit: `tests/test_kb_upload_api.py`（或新建 `tests/test_kb_chat_docs.py`）

### 设计

在 `api_knowledge_chat` 现有 KG 检索之后、构建 system prompt 之前插入：

```python
# 4b. 文档级检索（已上传文档）
doc_context = kb_docs.search_doc_chunks_for_question(question, top_k=3)
# → 复用 embed_single(question, "query") 得查询向量 → vector 余弦检索
# → 返回 [{doc_id, doc_name, content, score}]
```

- 命中时在现有 `context_text` 尾部追加 `## 已上传文档参考` 小节，每块标注来源文档名，如 `- 《锅圈食汇门店招聘SOP手册》：「...」`。
- `_build_system_prompt` 增加一条要求：引用文档内容时注明来源文档。
- 候选者模式（`mode="candidate"`）不注入文档上下文（`visibility` 语义一致：文档属内部资料）。
- 文档库为空或检索无命中时行为与现状完全一致（零回归）。
- `nodes_used` 字段顺带返回命中的文档名，前端可展示引用来源。

### 测试用例

1. `test_chat_uses_doc_context` — mock `search_doc_chunks_for_question` 返回 1 块 → 断言 system prompt 构建路径包含文档内容（通过 mock LLM 流或直接断言 `_build_context` 拼接结果）。
2. `test_chat_no_docs_no_change` — 文档库为空 → 请求成功且行为与基线一致（不报错）。
3. `test_chat_candidate_mode_excludes_docs` — mode=candidate 时文档上下文为空。
4. `test_doc_retrieval_returns_sorted` — 预置 2 块向量，查询向量与块 A 更近 → 块 A 排前（可用 `tests/test_kb_docs.py` 的检索单测覆盖，此条做集成断言）。

---

## Task 5: 前端 — 删除假数据、接入真实上传与列表

**Files:**
- Edit: `frontend/knowledge.html`

### 改动明细

1. **删除假预设**：移除 `upload-modal-body` 中 `.doc-list-section` 内 3 条硬编码 `.doc-item`（锅圈食汇门店招聘SOP手册.pdf / 2026校招面试评估标准.docx / 劳动法合规招聘指南.pdf）及「3 份文档 · 已提取 87 个知识节点」假统计（`doc-list-count` 由真实数据填充）。
2. **真实上传**：
   - `drop-select-btn` 绑定隐藏 `<input type="file" accept=".pdf,.docx,.doc,.txt,.md" multiple>`。
   - drop 事件接入文件：`dz` 的 `drop` handler 里取 `e.dataTransfer.files` → `uploadFiles(files)`。
   - `uploadFiles(files)`：FormData 追加 → `POST /api/knowledge/documents/upload` → 成功后刷新列表并开始轮询。
3. **动态文档列表**：`renderDocList()` 从 `GET /api/knowledge/documents` 渲染；状态 badge 用现有 `done/processing/pending` 样式，`failed` 显示红色错误文案 + 「重试」按钮（`POST /documents/{id}/reprocess`）；每项「删除」按钮（确认后 `DELETE`）。
4. **轮询**：有 `processing` 文档时每 2s 拉取列表，全部非 processing 或 60s 超时停止；页面关闭弹窗不停止轮询（后台静默刷新）。
5. **空状态**：无文档时显示「暂无上传文档，拖拽文件到上方区域开始上传」。
6. **失败提示**：上传响应 400 时 toast/alert 展示中文错误；列表项 `failed` 时展示 `error_msg`。
7. 打开弹窗（`openUploadModal`）时首次拉取列表。

### 验收（手动）

- [ ] 上传一个 PDF/DOCX/TXT → 列表出现 processing → 自动变 done，chunk_count 正确。
- [ ] 上传失败（如损坏文件）→ failed + 错误信息 → 点重试成功后 done。
- [ ] 删除文档 → 列表消失，刷新页面不再出现。
- [ ] 页面无任何假「已上传文档」数据。
- [ ] AI 问答问及已上传文档内容 → 回答引用文档内容且标注来源。

---

## Task 6: 全量回归验证

**Files:**
- 运行 `pytest tests/test_kb_docs.py tests/test_kb_ingest.py tests/test_kb_upload_api.py tests/test_kb.py -x -q`
- 运行 `pytest tests/ -x -q --timeout=120`（全量回归，重点看 test_kb.py / test_api_comprehensive.py 确认 chat 接口零回归）
- 启动服务（`uvicorn app.main:app --port 8888`）手动走查 Task 5 验收清单
- `ruff check app/kb_docs.py app/kb_ingest.py app/routers/knowledge.py` + `ruff format --check`（遵循仓库规范）

---

## 风险与决策记录

| 风险 | 决策 |
|---|---|
| embedding 为纯内存实现，重启丢失 | chunks 表持久化向量 + 启动时 `rebuild_inmemory_index()` |
| 大文档同步解析会卡事件循环 | 上传接口用 `BackgroundTasks` 异步入库，前端轮询 |
| embedding API Key 未配置 | 状态置 failed + 友好错误信息，可重试 |
| 文档库污染现有 Agent 知识（KnowledgeBase） | 文档检索独立建库，不改造 `knowledge/base.py`，零影响现有 Agent |
| 候选者模式泄露内部文档 | mode=candidate 不注入文档上下文 |
| 文件类型/大小安全 | 白名单 `.pdf/.docx/.doc/.txt/.md` + 20MB 上限 + 落盘名 `doc_id.ext` |

## 实施顺序

Task 1 → Task 2 → Task 3 → Task 4 → Task 5 → Task 6（每任务先写失败测试，再实现；TDD 贯穿）。
