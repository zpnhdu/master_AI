# 知识库重置实施计划

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** 删除旧版知识库种子及迁移入口，安全清空现有 Wiki 数据，并验证空库不会被重新填充。

**Architecture:** 生命周期不再执行旧迁移；旧种子文件、迁移脚本及其测试移除。一次性运行带备份的清理步骤，重建 `data/llm_wiki` 结构并清空知识库专用元数据。

**Tech Stack:** Python、FastAPI lifespan、SQLite/项目数据库、pytest。

---

### Task 1: 防止启动时恢复旧种子

**Files:**
- Modify: `app/bootstrap/lifecycle.py`
- Test: `tests/test_knowledge_bootstrap.py`

**Step 1: Write the failing test**

测试生命周期源码不再引用旧迁移模块；在当前实现下应因仍存在引用而失败。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_knowledge_bootstrap.py -q`

Expected: FAIL，检测到旧迁移引用。

**Step 3: Write minimal implementation**

删除 lifespan 中导入并调用 `migrate_default_seed_if_empty` 的代码及对应日志分支。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_knowledge_bootstrap.py -q`

Expected: PASS。

### Task 2: 移除旧迁移资产

**Files:**
- Delete: `scripts/migrate_legacy_knowledge_graph.py`
- Delete: `knowledge/seeds/legacy_knowledge_graph_v2.json`
- Delete: `tests/test_legacy_knowledge_migration.py`

**Step 1: Write the failing test**

Task 1 的测试同时断言旧迁移模块路径不存在；当前仓库应失败。

**Step 2: Run test — confirm it fails**

Command: `pytest tests/test_knowledge_bootstrap.py -q`

Expected: FAIL，旧迁移模块仍存在。

**Step 3: Write minimal implementation**

删除上述旧脚本、种子和仅覆盖该脚本的测试，并用 `rg` 确认无生产代码引用。

**Step 4: Run test — confirm it passes**

Command: `pytest tests/test_knowledge_bootstrap.py -q`

Expected: PASS。

### Task 3: 备份并重置运行数据

**Files:**
- Runtime data: `data/llm_wiki/`
- Runtime database: configured DB file, knowledge tables only

**Step 1: Create recoverable backup**

将当前 Wiki 目录移动到明确的时间戳备份目录，并导出 `wiki_pages`、`wiki_ingest` 记录；不删除备份。

**Step 2: Reset**

重建 Wiki 结构文件，清空 `wiki_pages` 与 `wiki_ingest`，然后运行索引对账。

**Step 3: Verify**

检查 `/api/knowledge/wiki/tree` 返回 `pages=0`，并确认页面目录没有内容页。

### Task 4: 回归验证

**Step 1: Run targeted tests**

Command: `pytest tests/test_knowledge_bootstrap.py -q`

Expected: PASS。

**Step 2: Run relevant Wiki tests**

Command: `pytest tests/test_kb.py -q`

Expected: PASS。

**Step 3: Restart verification**

重启应用后再次检查页面数仍为 0；不执行 Git 提交，等待用户确认。
