# 响应式公共壳层实施计划

> **For implementer:** 遵循测试先行；每个行为先写失败测试，再做最小实现。

**Goal:** 让后台公共壳层、全局视口高度和数据表格在手机与平板尺寸下具有一致的响应式行为。

**Architecture:** 使用 Ant Design Sider 的响应式 API 管理导航宽度；使用 PageShell 的公共 class 和 CSS token 管理页面间距；用 `100dvh` 回退策略与表格滚动容器处理移动浏览器约束。Agent 工作台保持现有专属布局。

**Tech Stack:** React 19、TypeScript、Ant Design 6、CSS、Vitest、Playwright。

---

### Task 1: 公共壳层响应式契约

**Files:**
- Modify: `frontend-react/src/app/components/AppShell.tsx`
- Modify: `frontend-react/src/app/components/PageShell.tsx`
- Test: `frontend-react/src/app/components/AppShell.test.tsx`
- Test: `frontend-react/src/app/components/PageShell.test.tsx`

**Steps:**
1. 写测试，证明 Sider 使用 `breakpoint="md"`、`collapsedWidth={64}`，PageShell 的 header 操作区使用公共 class。
2. 运行目标 Vitest，确认测试先失败。
3. 做最小组件实现。
4. 运行目标 Vitest，确认通过。

### Task 2: 公共 CSS 与表格滚动

**Files:**
- Modify: `frontend-react/src/styles.css`
- Modify: `frontend-react/src/app/pages/TalentPoolPage.tsx`
- Modify: `frontend-react/src/app/pages/AdminPage.tsx`
- Modify: `frontend-react/src/app/pages/MonitorPage.tsx`

**Steps:**
1. 为公共页面壳层补充小屏 gutter、header actions、`100dvh` fallback 和安全区 token。
2. 为后台数据表增加统一横向滚动策略，并保持桌面布局不变。
3. 运行 typecheck 和相关单元测试。

### Task 3: 响应式 E2E 冒烟

**Files:**
- Create: `frontend-react/e2e/responsive.spec.ts`

**Steps:**
1. 写三组 viewport 冒烟测试。
2. 运行 Playwright 目标测试，确认环境限制或失败原因。
3. 修正测试中的脆弱选择器，保留可重复断言。

### Task 4: 最终验证

**Commands:**
- `pnpm typecheck`
- `pnpm test:run`
- `pnpm exec playwright test responsive.spec.ts`
- `pnpm build`

不执行 git commit，等待用户明确授权。
