# Studio Pipeline Mutations Implementation Plan

> **For implementer:** Use TDD throughout. Write failing tests first, run them, then implement the smallest change.

**Goal:** Add authenticated Pipeline creation and deletion to the isolated React Studio without changing the legacy frontend or FastAPI page routes.

**Architecture:** Keep Pipeline server data in TanStack Query. Add typed `POST /api/pipelines` and `DELETE /api/pipelines/{id}` functions beside the existing list API, then invalidate the `['pipelines']` query after successful mutations. Keep confirmation and form state local to the Studio page.

**Tech Stack:** React 19, TypeScript 7, Ant Design 6, TanStack Query 5, Vitest, Testing Library, pnpm.

## Task 1: Add typed Pipeline mutation API

**Files:**

- Modify: `frontend-react/src/features/pipelines/api.ts`
- Test: `frontend-react/src/features/pipelines/api.test.ts`
- Modify: `frontend-react/src/features/pipelines/hooks.ts`

1. Add failing tests for the request method/body of create and delete, plus error propagation.
2. Run the focused API test and confirm it fails because mutation functions do not exist.
3. Implement `createPipeline` and `deletePipeline`, and TanStack Query mutation hooks that invalidate `['pipelines']` on success.
4. Run the focused test and the existing frontend suite.

## Task 2: Add Studio creation and deletion interactions

**Files:**

- Modify: `frontend-react/src/app/components/AppShell.tsx`
- Modify: `frontend-react/src/app/pages/StudioPage.tsx`
- Modify: `frontend-react/src/app/pages/StudioPage.test.tsx`
- Modify: `frontend-react/src/styles.css`

1. Add failing tests for the create form, successful create refresh, delete confirmation, and successful delete refresh.
2. Run the focused Studio test and confirm it fails because the controls do not exist.
3. Implement a minimal Ant Design create modal with required role validation, a delete button on each pipeline row, confirmation before deletion, visible success/error feedback, and query invalidation after successful mutations.
4. Run all frontend tests, typecheck, production build, and `git diff --check`.

## Scope boundaries

- Do not switch FastAPI `/` to React in this phase.
- Do not migrate pipeline detail, batch delete, auto-run, WebSocket updates, or other legacy pages.
- Do not modify `data/kg_usage.json`; it is a pre-existing user change.
- Do not commit until the user explicitly confirms.

## Execution record

- [x] Task 1: typed list/create/delete API, runtime response guards, status normalization, and query invalidation.
- [x] Task 2: Studio create modal with required role validation, four flow presets, delete confirmation, visible error feedback, and mutation refresh assertions.
- [x] Validation: Node `v22.23.1`, 26 Vitest tests, TypeScript typecheck, Vite production build, and source whitespace check passed.
- [x] Playwright browser smoke: Chromium and Headless Shell installed; the existing smoke test passed 1/1.
- [ ] Root route cutover, pipeline detail, batch operations, auto-run, WebSocket updates, and legacy page retirement remain outside this phase.
