# 前端首屏性能优化设计

## 背景

本地 Vite 开发服务器会直接提供约 11MB 的预构建 antd 文件；生产构建虽然已压缩，但根入口仍然因为 `App.tsx` 静态引入 antd 而预加载 antd。FastAPI 直出静态资源时还会返回未压缩且不可缓存的响应。

## 方案

1. 登录页和 Loading 页使用原生表单/轻量 CSS，不再依赖 antd。
2. 将 `ConfigProvider`、`AntdApp` 和业务路由放入按需加载的认证运行时，登录首屏不再预加载 antd。
3. FastAPI 增加 GZipMiddleware；`/assets/` 使用一年 immutable 缓存，`/brand/` 使用短期公共缓存，旧 `/static/` 保持不缓存兼容。
4. 保持生产 Nginx 已有的 gzip 和 hashed 资源 immutable 策略。

## 边界

- 不替换 antd，不重写业务页面，不调整 ECharts/D3 功能。
- 不修改其他未提交的 timeout 改动。
- 生产构建继续由 Nginx 托管；Vite `5173` 仍只作为开发服务器。

## 验收

- 构建后的 `index.html` 不再 modulepreload antd。
- 登录页可在没有 antd 运行时的情况下渲染和提交。
- FastAPI 静态 JS 在支持 gzip 的请求下返回 `Content-Encoding: gzip` 和长期缓存头。
- Python 测试、React typecheck、React build 通过。
