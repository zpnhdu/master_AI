# 面试中心表格化改版 实现计划

> **面向 AI 代理的工作者：** 必需子技能：使用 superpowers:subagent-driven-development（推荐）或 superpowers:executing-plans 逐任务实现此计划。步骤使用复选框（`- [ ]`）语法来跟踪进度。

**目标：** 将 `/mass-dashboard` 从「监控看板 / 排名看板 / 面试日历」三个 tab 改为「KPI 可点击统计条 + 单张候选人 DataTable」，删除三个旧视图及配套代码。

**架构：** 页面数据链不变（pipelines / status / streams / ranking / assessmentQueue / candidateReports + WebSocket 实时失效），渲染层用 `shared/data-table/DataTable`（客户端模式）替换 `MonitorView` / `RankingView` / `CalendarView`；`StatsBar` 改造为可点击的状态筛选器，与表格共用 `splitMonitorRanking` 分桶口径。

**技术栈：** React 18 + antd 5（Table/Tag/Avatar/Space）+ TanStack Query + Vitest + Testing Library。

**规格：** `docs/plans/2026-09-04-mass-dashboard-table-redesign-design.md`（含设计决策依据，实现时不必重读，本计划自包含）。

**验证命令基线（每个任务通用）：**

- 单测：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.test.tsx src/app/pages/MassDashboardPage.selectors.test.ts`
- 类型：`cd frontend-react && npm run typecheck`
- 全量收尾：`cd frontend-react && npm run test:run && npm run typecheck && npm run build`

**提交规范（仓库 pre-commit/commitlint 强制）：** subject ≤72 字符、小写开头、scope 取 `pipeline/interview/agent/kg/frontend/api/feishu/rpa/infra` 之一、body 行 ≤100 字符；只 `git add <具体文件>`，禁止 `git add -A`；提交前 `git status --porcelain` 连读两次确认无并行改动。

---

## 文件结构与职责

| 文件 | 动作 | 职责 |
|---|---|---|
| `src/app/pages/MassDashboardPage.tsx` | 修改 | 删 tab/三视图/三卡片组件/筛选 state；新增 `statusFilter` state、`CandidateTable` 组件与列定义；删除行尾死代码 `formatCount` / `formatToken` / `csvCell` |
| `src/app/pages/MassDashboardPage.components.tsx` | 修改 | 删 `SectionHeading` / `VideoThumbnail` / `WrittenTestThumbnail`；`StatsBar` 增加 `selectedKey` / `onSelect` props 变为可点击 toggle |
| `src/app/pages/MassDashboardPage.selectors.ts` | 修改 | 删 `matchesRankingFilter` / `sortRankingByScore` / `isWrittenTestCandidate` / `completedVideoFilename` / `completedVideoThumbnailSource` / `recommendationLabel`；其余保留 |
| `src/app/pages/MassDashboardPage.selectors.test.ts` | 修改 | 删对应被删导出的用例 |
| `src/app/pages/MassDashboardPage.test.tsx` | 修改 | 删 calendar 用例；monitor/ranking 用例改写为表格断言 |
| `src/styles/70-mass-dashboard.css` | 修改 | 删 `mass-monitor/mass-ranking/rank-*/mass-candidate-card/mass-calendar` 段落；删行尾死代码 `formatCount`/`formatToken`/`csvCell` 对应的 `.mass-dashboard__usage` 段（页面已无引用）；新增 KPI 选中态样式 |

**不动：** `features/mass-dashboard/`（hooks/api 含 `useMassSchedulesQuery`——页面不再调用即可，hooks 自测保留）；`shared/components/PageTabs`（Admin/Dashboard/Knowledge 共用，其样式 `.mass-dashboard__tabs` 保留）；`shared/data-table/`；`styles.agent-pages.test.ts`（只校验 import 顺序与选择器存在性，删除的类不在断言里）。

**注意 `massDashboardDetail` 路由：** `routePaths.massDashboard(pipelineId)` 与 detail 路由、外页跳转（XiaoMian/XiaoPing）全部不动。

---

### 任务 1：selectors 清理（删死代码 + 测试同步）

**文件：**
- 修改：`frontend-react/src/app/pages/MassDashboardPage.selectors.ts`
- 修改：`frontend-react/src/app/pages/MassDashboardPage.selectors.test.ts`

- [ ] **步骤 1：修改 selectors 测试，删除被删导出的用例**

在 `MassDashboardPage.selectors.test.ts` 的 import 块中删除：`completedVideoThumbnailSource`、`isWrittenTestCandidate`、`matchesRankingFilter`、`sortRankingByScore` 四行（保留 `enrichMassRanking`、`filterRankingByDate`、`fiveDimensionScores`、`formatDateTime`、`splitMonitorRanking`、`statusColor`、`statusLabel`、`summarizeRankingStats`）。

删除两个用例（整段 `it(...)`）：

```ts
// 删除整段：
it("filters and sorts ranking candidates by recommendation, flags, trend, and scores", () => { ... });

// 删除整段：
it("prioritizes video evidence over written-test modality and encodes thumbnail paths", () => { ... });
```

- [ ] **步骤 2：运行测试验证失败**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.selectors.test.ts`
预期：**PASS**（测试只是删用例，此步先确认基线绿；selectors.ts 尚未删，import 未破坏）

- [ ] **步骤 3：删除 selectors.ts 中的死导出**

删除以下函数（源文件行号参考，删除以函数边界为准）：

- `matchesRankingFilter`（`selectors.ts:126-145`）
- `isWrittenTestCandidate`（`selectors.ts:182-194`）
- `completedVideoFilename`（`selectors.ts:196-203`）
- `completedVideoThumbnailSource`（`selectors.ts:205-209`）
- `sortRankingByScore`（`selectors.ts:117-124`）
- `recommendationLabel`（`selectors.ts:233-242`，仅 selectors.test 与已删除的排名视图使用；注意 `MassDashboardPage.tsx` 不引用它，`recommendationBadge` 是页面内私有函数，一起在任务 4 删除）

`splitMonitorRanking`、`filterRankingByDate`、`summarizeRankingStats`、`statusLabel`、`statusColor`、`hrActionLabel`、`formatExpiry`、`formatDateTime`、`enrichMassRanking`、`fiveDimensionScores` 保留（页面与测试在用）。

- [ ] **步骤 4：运行测试验证通过**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.selectors.test.ts`
预期：PASS。此时 `MassDashboardPage.tsx` 仍 import 被删符号，**页面测试会编译失败，这是预期中间态**，`npm run typecheck` 也会报错——不在本任务修，任务 4 完成。

- [ ] **步骤 5：Commit**

```bash
git add frontend-react/src/app/pages/MassDashboardPage.selectors.ts frontend-react/src/app/pages/MassDashboardPage.selectors.test.ts
git commit -m "frontend: 面试中心 selectors 清理排名与日历死代码"
```

---

### 任务 2：StatsBar 可点击筛选（TDD）

**文件：**
- 修改：`frontend-react/src/app/pages/MassDashboardPage.components.tsx`
- 修改：`frontend-react/src/styles/70-mass-dashboard.css`（KPI 选中态样式，新增段落放在 `.mass-stat-card--expired .ant-progress-bg` 之后约 187 行处）

- [ ] **步骤 1：编写失败的测试**

在 `MassDashboardPage.test.tsx` 的 `describe` 内新增用例（放「renders monitoring data」用例后）。mock 结构照抄现有 monitor 用例（pipelines/status/streams/ranking 四段 fetch mock），ranking 数据扩为 2 人：`candidate-1 王芳 completed score 88`、`candidate-2 李强 invited`：

```tsx
it('filters the table by clicking a KPI stat card', async () => {
  vi.stubGlobal(
    'fetch',
    vi.fn().mockImplementation(async (input: RequestInfo | URL) => {
      const path = String(input);
      if (path === '/api/mass-interview/pipelines') {
        return response({ pipelines: [{ id: 'pipeline-1', role: '店长' }] });
      }
      if (path === '/api/mass-interview/pipeline-1/status') {
        return response({ stats: { total: 2 }, sessions: [] });
      }
      if (path === '/api/mass-interview/pipeline-1/streams') {
        return response({ online_count: 0, recorded: 0, streams: [] });
      }
      if (path === '/api/mass-interview/pipeline-1/ranking') {
        return response({
          total: 2,
          ranking: [
            { candidate_id: 'candidate-1', candidate_name: '王芳', status: 'completed', total_score: 88 },
            { candidate_id: 'candidate-2', candidate_name: '李强', status: 'invited' },
          ],
        });
      }
      return response({ last_24h: {} });
    }),
  );

  renderMassDashboard();

  // 两行都在
  expect(await screen.findByText('王芳')).toBeInTheDocument();
  expect(screen.getByText('李强')).toBeInTheDocument();

  // 点击 KPI 卡「已完成」→ 只剩王芳
  fireEvent.click(screen.getByRole('button', { name: /已完成/ }));
  expect(screen.getByText('王芳')).toBeInTheDocument();
  expect(screen.queryByText('李强')).not.toBeInTheDocument();

  // 再点一次取消 → 两行恢复
  fireEvent.click(screen.getByRole('button', { name: /已完成/ }));
  expect(screen.getByText('李强')).toBeInTheDocument();
});
```

- [ ] **步骤 2：运行测试验证失败**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.test.tsx -t "filters the table by clicking"`
预期：FAIL——找不到 `role=button, name=/已完成/`（StatsBar 卡片还不是按钮）。

- [ ] **步骤 3：改造 StatsBar 支持点击与选中态**

`MassDashboardPage.components.tsx`——`StatsBar` 增加两个 props；卡片渲染包一层 `role="button"` 的 div（保留原卡片内容与类名，追加 `is-selected`）：

```tsx
export function StatsBar({
  stats,
  selectedKey,
  onSelect,
}: {
  stats: MassInterviewStats;
  selectedKey?: string;
  onSelect?: (key: string) => void;
}) {
  // cards 数组不变（5 张卡，key: invited/started/in_progress/completed/expired）
  // …
  return (
    <div className="mass-dashboard__stats" aria-label="面试统计">
      {cards.map((card) => {
        // …percentage/gradient 计算不变
        return (
          <div
            key={card.key}
            className={`mass-stat-card mass-stat-card--${card.color}${selectedKey === card.key ? ' is-selected' : ''}`}
            role={onSelect ? 'button' : undefined}
            tabIndex={onSelect ? 0 : undefined}
            aria-pressed={onSelect ? selectedKey === card.key : undefined}
            aria-label={`${card.label}筛选`}
            onClick={onSelect ? () => onSelect(card.key) : undefined}
            onKeyDown={(event) => {
              if (onSelect && (event.key === 'Enter' || event.key === ' ')) {
                event.preventDefault();
                onSelect(card.key);
              }
            }}
          >
            {/* 原 icon/value/label/Progress/percentage 结构不动 */}
          </div>
        );
      })}
    </div>
  );
}
```

本任务先不改 `MassDashboardPage.tsx` 的调用处（仍传 `stats`，不传新 props），用例里点击的是 KPI 卡本身但表格还没接——**因此步骤 2 的失败点必须在步骤 3 之前先由本改造转绿**：改造后卡片成为 `role=button` 且有 aria-label `已完成筛选`，用例的 `getByRole('button', { name: /已完成/ })` 能找到并点击，但李强行不会消失——**用例仍 FAIL（断言李强消失失败）**，这是预期的第二步失败；真正的筛选接线在任务 3。

**修正步骤 2/3 的验证口径（以此为准）：** 步骤 2 失败原因 = 找不到按钮；步骤 3 后运行同一命令，失败原因 = 「李强仍在文档中」（即卡片可点但未过滤）。两者都是绿灯路上的中间态，任务 3 完成后整条转绿。

- [ ] **步骤 4：新增 KPI 选中态 CSS**

`70-mass-dashboard.css` 中 `.mass-stat-card--expired .ant-progress-bg` 段之后追加：

```css
.mass-stat-card[role='button'] {
  cursor: pointer;
  transition: background-color 0.2s;
}

.mass-stat-card[role='button']:hover {
  background: #f3f0ea;
}

.mass-stat-card.is-selected {
  background: #f3f0ea;
  box-shadow: inset 0 -3px 0 #2563eb;
}
```

- [ ] **步骤 5：运行 selectors 测试确认无回归**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.selectors.test.ts`
预期：PASS（components 改动不触碰 selectors）。

- [ ] **步骤 6：Commit**

```bash
git add frontend-react/src/app/pages/MassDashboardPage.components.tsx frontend-react/src/app/pages/MassDashboardPage.test.tsx frontend-react/src/styles/70-mass-dashboard.css
git commit -m "frontend: 面试中心 KPI 卡片支持点击与选中态"
```

---

### 任务 3：CandidateTable 替换三视图（核心任务）

**文件：**
- 修改：`frontend-react/src/app/pages/MassDashboardPage.tsx`

- [ ] **步骤 1：新增 statusFilter state 与筛选数据链**

在 `MassDashboardPage` 组件中（`redFlagOnly` 等 state 删除后）：

```tsx
// KPI 点击筛选：'' 表示全部（“已邀请”卡=总数，点击即清除筛选）
const [statusFilter, setStatusFilter] = useState("");
const tableRanking = useMemo(() => {
  if (!statusFilter) return visibleRanking;
  const buckets = splitMonitorRanking(visibleRanking);
  if (statusFilter === 'started') return [...buckets.answering, ...buckets.opened];
  if (statusFilter === 'in_progress') return [...buckets.answering, ...buckets.opened];
  if (statusFilter === 'completed') return buckets.completed;
  if (statusFilter === 'expired') return buckets.expired;
  return visibleRanking;
}, [statusFilter, visibleRanking]);
```

⚠️ **口径对齐（卡片数字必须等于行数）**：`StatsBar` 五张卡的 key 是 `invited/started/in_progress/completed/expired`，值来自 `summarizeRankingStats`；而 `splitMonitorRanking` 的桶是 `completed/answering/opened/invited/expired`。两个口径不一致（`summarizeRankingStats` 按 `status` 原值计，`splitMonitorRanking` 用 `assessment_completed` 与 `current_question` 调整）。**必须统一**：把 KPI 计数也改为从 `splitMonitorRanking` 桶推导：

```tsx
const stats = useMemo(() => {
  const buckets = splitMonitorRanking(visibleRanking);
  return summarizeRankingStats(visibleRanking, buckets);
}, [visibleRanking]);
```

并给 `summarizeRankingStats` 增加可选第二参（`selectors.ts`，向后兼容测试）：

```ts
export function summarizeRankingStats(
  ranking: MassRanking[],
  buckets?: MonitorRankingBuckets,
): MassInterviewStats {
  const next: MassInterviewStats = { ...EMPTY_MASS_STATS, total: ranking.length };
  if (buckets) {
    next.invited = buckets.invited.length;
    next.started = buckets.opened.length;
    next.in_progress = buckets.answering.length;
    next.completed = buckets.completed.length;
    next.expired = buckets.expired.length;
    for (const candidate of ranking) if (candidate.video_paths?.length) next.recorded += 1;
    return next;
  }
  // 原有 status 逐条累加逻辑保留（兜底/兼容现有测试）
  for (const candidate of ranking) { /* 原循环体不动 */ }
  return next;
}
```

`StatsBar` 卡片 key 与 `statusFilter` 的映射（在页面里做成常量，KPI onSelect 直接用卡片 key）：

```tsx
const STATUS_FILTER_BY_STAT_KEY: Record<string, string> = {
  invited: '',
  started: 'started',
  in_progress: 'in_progress',
  completed: 'completed',
  expired: 'expired',
};
// 状态列/行筛选统一用桶口径：
// started → answering+opened；in_progress → answering+opened（「已打开/答题中」两卡都含两桶，避免口径打架）
```

⚠️ 说明：`started` 与 `in_progress` 两张卡的桶映射相同（都是 answering+opened），因为 DataTable 行内「停止直播」按钮也按 `answering+opened` 显示，口径一致才能保证「卡片数字 = 筛后行数」。若要两卡严格互斥，`splitMonitorRanking` 的 `opened` 判定（`current_question <= 0`）已天然分流，但 `summarizeRankingStats(buckets)` 用 `buckets.opened` / `buckets.answering` 分开计数即可——**最终实现以「KPI 卡数值 = 对应筛选下表格行数」为验收标准**，实现时在页面里断言一次（见步骤 4 测试）。

- [ ] **步骤 2：编写 CandidateTable 组件**

在 `MassDashboardPage.tsx` 内新增组件（放在 `MonitorView` 原位置），并删除 `MonitorView`、`RankingView`、`CalendarView`、`CandidateCard`、`RankingCard` 五个组件整段：

```tsx
type CandidateTableProps = {
  ranking: MassRanking[];               // 已按 statusFilter 过滤
  streams: MassStream[];
  pipelineId: string;
  onOpen: (candidate: MassRanking) => void;
  onResume: (candidate: MassRanking) => void;
  onMark: (candidate: MassRanking, action: 'pass' | 'review' | 'reject') => void;
  onCopy: (candidate: MassRanking) => void;
  onEmail: (candidate: MassRanking) => void;
  onKick: (stream: MassStream) => void;
};

function CandidateTable(props: CandidateTableProps) {
  const { ranking, streams, pipelineId } = props;
  // currentQuestion 从 streams 取，与 KPI 桶口径一致
  const currentQuestionByCandidate = useMemo(
    () => new Map(streams.map((stream) => [stream.candidate_id, stream.current_question ?? 0])),
    [streams],
  );
  const { completed, answering, opened, invited, expired: expiredCandidates } = splitMonitorRanking(ranking);
  const interactiveIds = new Set([
    ...completed.map((item) => item.candidate_id),
    ...answering.map((item) => item.candidate_id),
    ...opened.map((item) => item.candidate_id),
  ]);
  const streamByCandidateId = useMemo(() => new Map(streams.map((stream) => [stream.candidate_id, stream])), [streams]);

  const columns: DataTableColumn<MassRanking>[] = [
    {
      key: 'name',
      role: 'identity',
      title: '姓名',
      dataIndex: 'candidate_name',
      render: (name: string, candidate) => (
        <Space>
          <Avatar size="small">{name.slice(0, 1)}</Avatar>
          <Typography.Text strong>{name}</Typography.Text>
        </Space>
      ),
      onCell: () => ({ style: { cursor: 'pointer' } }),
    },
    {
      key: 'status',
      title: '状态',
      dataIndex: 'status',
      width: 100,
      render: (status: string, candidate) => (
        <Tag color={candidate.assessment_completed ? 'success' : statusColor(status)}>
          {candidate.assessment_completed ? '已完成' : statusLabel(status)}
        </Tag>
      ),
    },
    {
      key: 'score',
      title: '小评评分',
      width: 110,
      sorter: (left: MassRanking, right: MassRanking) =>
        (left.interview_score ?? left.total_score ?? left.match_score ?? 0) -
        (right.interview_score ?? right.total_score ?? right.match_score ?? 0),
      render: (value: unknown, candidate) => {
        const score = candidate.interview_score ?? candidate.total_score ?? candidate.match_score;
        return typeof score === 'number' ? <b>{score}</b> : <Typography.Text type="secondary">—</Typography.Text>;
      },
    },
    {
      key: 'started_at',
      title: '开始时间',
      dataIndex: 'started_at',
      width: 120,
      render: (value: string) => (value ? formatDateTime(value) : '—'),
    },
    {
      key: 'expires_at',
      title: '有效期',
      dataIndex: 'expires_at',
      width: 200,
      render: (value: string) => (value ? formatExpiry(value) : '—'),
    },
    {
      key: 'actions',
      role: 'actions',
      title: '操作',
      width: 260,
      fixed: 'right' as const,
      render: (_value, candidate) => {
        const isLive = interactiveIds.has(candidate.candidate_id);
        const stream = streamByCandidateId.get(candidate.candidate_id);
        const isPending = [...invited, ...expiredCandidates].some(
          (item) => item.candidate_id === candidate.candidate_id,
        );
        return (
          <Space size={4} wrap>
            <DataTableAction onClick={() => props.onOpen(candidate)}>详情</DataTableAction>
            <DataTableAction onClick={() => props.onResume(candidate)}>简历</DataTableAction>
            <DataTableAction onClick={() => props.onMark(candidate, 'pass')}>通过</DataTableAction>
            <DataTableAction onClick={() => props.onMark(candidate, 'review')}>复试</DataTableAction>
            <DataTableAction tone="danger" onClick={() => props.onMark(candidate, 'reject')}>淘汰</DataTableAction>
            {isPending ? (
              <>
                <DataTableAction onClick={() => props.onCopy(candidate)}>复制链接</DataTableAction>
                <DataTableAction onClick={() => props.onEmail(candidate)}>发邮件</DataTableAction>
              </>
            ) : null}
            {isLive && stream ? (
              <DataTableAction tone="danger" onClick={() => props.onKick(stream)}>停止直播</DataTableAction>
            ) : null}
          </Space>
        );
      },
    },
  ];

  return (
    <DataTable
      tableId="mass-candidates"
      rowKey="candidate_id"
      columns={columns}
      dataSource={ranking}
      searchableText={(record) => record.candidate_name}
      searchPlaceholder="搜索候选人姓名"
      scroll={{ x: 'max-content' }}
      onRow={(record) => ({
        onClick: () => props.onOpen(record),
        style: { cursor: 'pointer' },
      })}
      onClearFilters={() => setStatusFilter('')}
      emptyText="暂无面试数据，请先在小面页面发起面试邀请"
      locale={{ emptyText: <Empty description="暂无面试数据" /> }}
    />
  );
}
```

⚠️ **`onClearFilters` 闭包警告**：上面 `onClearFilters={() => setStatusFilter('')}` 在 `CandidateTable`（无 state 的函数组件）里引用了页面的 setter——**这是设计错误，修正如下**：把 `onClearFilters` 与 `emptyText` 作为 props 从页面传入（`onClearFilters: () => void` 加进 `CandidateTableProps`），页面调用处写 `<CandidateTable onClearFilters={() => setStatusFilter('')} … />`，避免子组件反向依赖页面 state。

⚠️ **同一行内的操作触发行点击**：`onRow.onClick` 会连同操作链接一起冒泡触发详情弹窗。`DataTableAction` 已 `preventDefault` 但未 `stopPropagation`。处理：操作列 `onCell: () => ({ onClick: (e) => e.stopPropagation() })`（加到 actions 列定义里）。

页面调用处（`tab === "monitor" ? … : …` 三元整段替换为）：

```tsx
<CandidateTable
  ranking={tableRanking}
  streams={streamsQuery.data?.streams ?? []}
  pipelineId={selectedPipelineId}
  onOpen={openCandidate}
  onResume={openResume}
  onMark={markCandidate}
  onCopy={copyInvite}
  onEmail={(candidate) => sendEmail(candidate)}
  onKick={kickStream}
  onClearFilters={() => setStatusFilter('')}
/>
```

- [ ] **步骤 3：删除页面内旧代码**

同文件删除（以标识符定位，不依赖行号）：

- state：`tab`、`filter`、`trendFilter`、`redFlagOnly`、`startDate`/`endDate` 保留但 **`setTab` 调用**全删
- 类型：`DashboardTab`；import：`PageTabs`、`Radio`、`DatePicker`（若日期范围仍在用则保留，仅删 ranking filters 里的 `mass-ranking__date-range` 实例——**注意 header 的 `DatePicker.RangePicker` 仍在用，import 保留**）
- 组件函数：`MonitorView`（594-782 整段）、`CalendarView`（784-909 整段）、`RankingView`（911-1017 整段）、`CandidateCard`（1019-1133 整段）、`RankingCard`（1152-1304 整段）、`avatarScoreTier`、`recommendationBadge`（1135-1150，仅 RankingCard 用）
- 常量 `DIMENSION_COLORS`（仅卡片/详情维度条用——**检查：`EvaluationPanel` 也用它渲染维度 Progress（1460 行），保留**）
- `schedulesQuery` 及 `useMassSchedulesQuery` import、`MassSchedule` 类型 import、`hasError`/`loading` 中 `tab === "calendar"` 分支、`handleRankingDateRangeChange` + `rankingDateRange`（URL start_from/start_to 筛选属排名视图——**决策：保留 URL 参数读取与 `startFrom`/`startTo`（query 仍需要），删 `handleRankingDateRangeChange` UI 入口；`rankingDateRange` memo 删除**）
- import 清单收敛：删 `Checkbox`、`Radio`、`Progress`（卡片在用、表格不用；**`EvaluationPanel` 的维度 Progress 仍在用，保留**）、`Tag`（状态列在用，保留）…… 以 `npx tsc --noEmit` 报错为准逐个收敛，**禁止盲删**
- 行尾死代码：`formatCount`、`formatToken`、`csvCell` 三个函数（无引用）
- import 中被删 selector：`matchesRankingFilter`、`sortRankingByScore`、`completedVideoThumbnailSource`、`isWrittenTestCandidate`（任务 1 已从 selectors 删除，此时 import 报错，删除 import 行）
- import components：`SectionHeading`、`VideoThumbnail`、`WrittenTestThumbnail`（任务 4 删除导出，本步骤先删页面 import；**注意顺序：任务 4 删 components 导出前页面必须先不引用**——本步骤完成后页面已无引用，任务 4 安全）

`StatsBar` 调用处改为：

```tsx
<StatsBar
  stats={stats}
  selectedKey={STATUS_FILTER_BY_STAT_KEY[statusFilter] ? statusFilter === '' ? 'invited' : undefined : undefined}
  onSelect={(key) => {
    const next = STATUS_FILTER_BY_STAT_KEY[key] ?? '';
    setStatusFilter(next === statusFilter ? '' : next); // toggle：再点同一张卡取消
  }}
/>
```

⚠️ **selectedKey 推导修正（以最终实现为准，上面表达式有误）**：卡片 key 与 statusFilter 值不同（`in_progress` 卡对应 statusFilter `'in_progress'`，同名；`started` 卡同名）——实际映射：`statusFilter === ''` 时选中卡是 `invited`（总数卡）；否则选中卡 key = statusFilter（五张卡 key 恰为 `invited/started/in_progress/completed/expired`，与 statusFilter 值一一对应同名）。**正确写法：**

```tsx
const selectedStatKey = statusFilter === '' ? 'invited' : statusFilter;
<StatsBar stats={stats} selectedKey={selectedStatKey} onSelect={handleStatSelect} />;

function handleStatSelect(key: string) {
  // invited 卡 = 清除筛选；其余卡 = 按卡筛选；再点当前选中卡 = 取消
  const target = key === 'invited' ? '' : key;
  setStatusFilter((current) => (current === target ? '' : target));
}
```

（此函数写进 `MassDashboardPage` 组件内；`STATUS_FILTER_BY_STAT_KEY` 常量随之作废，不需要。）

- [ ] **步骤 4：运行 KPI 筛选用例验证通过**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.test.tsx -t "filters the table by clicking"`
预期：PASS（点「已完成」卡 → 李强消失；再点 → 恢复）。

- [ ] **步骤 5：改写其余页面测试用例**

`MassDashboardPage.test.tsx`：

- **删除**：`loads schedules only after opening the calendar tab` 整段
- **改写** `renders monitoring data and switches to the ranking board` → `renders candidate rows in the table`：保留四段 fetch mock（ranking 数据沿用王芳 completed 88 分）；断言改为：

```tsx
expect(await screen.findByText('李明')).toBeInTheDocument();
// 评分列显示 90（interview_score 优先）
expect(screen.getByText('90')).toBeInTheDocument();
// 状态列
expect(screen.getAllByText('已完成').length).toBeGreaterThan(0);
// 行内操作
expect(screen.getByRole('button', { name: '详情' })).toBeInTheDocument();
expect(screen.getByRole('button', { name: '简历' })).toBeInTheDocument();
```

⚠️ 上面用 `getByRole('button', { name: '详情' })` 定位——**`DataTableAction` 渲染为 `Typography.Link`（`<a href="#">`），role 是 `link` 不是 `button`**。断言统一改用：

```tsx
expect(screen.getByRole('link', { name: '详情' })).toBeInTheDocument();
expect(screen.getByRole('link', { name: '简历' })).toBeInTheDocument();
expect(screen.getByRole('link', { name: '通过' })).toBeInTheDocument();
```

- **改写** `stops a live stream without opening the candidate detail modal`：mock 不变；定位器 `getByRole('button', { name: '停止直播' })` → `getByRole('link', { name: '停止直播' })`
- **改写** `loads the candidate resume when a ranking card opens the preview`：删 `fireEvent.click(screen.getByText('排名看板'))` 一行，`getByRole('button', { name: '预览简历' })` → `getByRole('link', { name: '简历' })`
- `shows a written-test completion as completed…` 用例断言不变（`getAllByText('已完成')` 在表格状态列里同样成立）；确认 `待面试` 不再出现的断言保留（旧卡片专属文案已删，天然通过）

- [ ] **步骤 6：运行全部页面测试验证通过**

运行：`cd frontend-react && npx vitest run src/app/pages/MassDashboardPage.test.tsx src/app/pages/MassDashboardPage.selectors.test.ts`
预期：PASS（含任务 1、2 的用例）。

- [ ] **步骤 7：类型检查**

运行：`cd frontend-react && npm run typecheck`
预期：0 errors。若报未使用 import，逐个删除后重跑。

- [ ] **步骤 8：Commit**

```bash
git add frontend-react/src/app/pages/MassDashboardPage.tsx frontend-react/src/app/pages/MassDashboardPage.test.tsx frontend-react/src/app/pages/MassDashboardPage.selectors.ts
git commit -m "frontend: 面试中心三视图合并为候选人表格"
```

（注：`summarizeRankingStats` 的 buckets 参数改动落在 selectors.ts，与本任务同 commit；selectors.test 若需补 buckets 断言也在本步。）

---

### 任务 4：components 与 CSS 清理

**文件：**
- 修改：`frontend-react/src/app/pages/MassDashboardPage.components.tsx`
- 修改：`frontend-react/src/styles/70-mass-dashboard.css`

- [ ] **步骤 1：删除 components.tsx 中的卡片导出**

删除 `SectionHeading`（177-184）、`VideoThumbnail`（140-152）、`WrittenTestThumbnail`（154-175）三个导出整段；同时删顶部 import 中仅被它们使用的 `useEffect`、`useState`、`MassInterviewStats` 之外的类型引用——**注意 `StatsBar` 仍需要 `MassInterviewStats` 与 `Progress`**，只删真正未使用的（`useEffect`/`useState` 只有 VideoThumbnail 用，删）。保留文件头 `STAT_GRADIENTS` 与 `StatsBar`。

- [ ] **步骤 2：删除 70-mass-dashboard.css 旧视图段落**

按选择器前缀删除（保留 `.mass-dashboard__tabs`——`PageTabs` 共享组件在用）：

- 删 `mass-calendar` 全部（237-373 段，含 `.mass-calendar-modal` 变体与 374-382 的空态例外——**374 `.mass-dashboard__content > .ant-empty` 与 378 `.mass-dashboard__empty` 保留**，页面空态在用）
- 删 `mass-monitor` 全部（383-446：section/summary/wall）
- 删 `mass-candidate-card` 全部（447-659 附近，含 thumbnail/written/score/pending/footer/actions）
- 删 `mass-ranking__filters` / `mass-ranking__list` / `mass-ranking__date-range`（660-697 段内）
- 删 `rank-` 与 `.rank` 开头全部（约 729-1035：rank-card/rank-avatar/rank-badge-v2/rank-dims-v2/rank-formula/rank-actions 及 `.btn` 系列——**`.btn` 前缀通用，检查是否被其他页面引用：`grep -rn "className=\"btn\|'btn " frontend-react/src --include="*.tsx"` 确认仅旧卡片用后删**；若被引用则保留）
- 删媒体查询中的死选择器：1214-1311 两个 `@media` 块内的 `.mass-ranking-card*`、`.mass-monitor*`、`.mass-ranking__date-range` 规则（`.mass-detail*`、`.mass-stat-card*` 保留）
- 删 `.mass-dashboard__usage`（27-57 段：usage/usage .ant-typography 等，页面无引用——**确认：`grep -rn "mass-dashboard__usage" frontend-react/src --include="*.tsx"` 为空后删**）
- 删 `.mass-dashboard__notice`（13-21）：**先 grep 确认**——页面当前不引用（notice 用 antd message，不走 DOM 类名），为空则删

**每个删除段落前执行 grep 确认 0 引用**，模板：

```bash
grep -rn "<选择器类名去掉点>" frontend-react/src --include="*.tsx" --include="*.ts" | grep -v "70-mass-dashboard.css"
```

- [ ] **步骤 3：验证样式契约测试**

运行：`cd frontend-react && npx vitest run src/styles.agent-pages.test.ts`
预期：PASS（该测试只断言 import 顺序与特定 marker 选择器，被删类不在断言内；`.mass-dashboard__tabs` 被删会 FAIL——**所以绝对不删 `.mass-dashboard__tabs` 段 58-84**）。

- [ ] **步骤 4：运行全量前端测试**

运行：`cd frontend-react && npm run test:run`
预期：PASS（全仓库测试，含 App.test / StudioPage.test 等跳转断言不受影响）。

- [ ] **步骤 5：Commit**

```bash
git add frontend-react/src/app/pages/MassDashboardPage.components.tsx frontend-react/src/styles/70-mass-dashboard.css
git commit -m "frontend: 面试中心删除卡片墙与日历样式"
```

---

### 任务 5：收尾验证

**文件：** 无新改动（若发现问题，回对应任务修复后重新 commit）

- [ ] **步骤 1：全量测试 + 类型 + 构建**

运行：

```bash
cd frontend-react && npm run test:run
cd frontend-react && npm run typecheck
cd frontend-react && npm run build
```

预期：三项全部通过。

- [ ] **步骤 2：CSS 死代码复核**

运行（应全部为空或仅剩测试/类型引用）：

```bash
grep -rn "mass-monitor\|mass-ranking\|mass-calendar\|rank-card\|mass-candidate-card" frontend-react/src --include="*.tsx" --include="*.ts"
```

- [ ] **步骤 3：浏览器冒烟（可选，若环境可用）**

`npm run dev` 后访问 `/mass-dashboard`：KPI 五卡渲染、点击筛选/取消、表格列与排序、行内操作与弹窗、日期/HR/岗位筛选不回归。

---

## 自检记录

1. **规格覆盖度**：规格「布局」→任务 3 调用处；「KPI 点击筛选」→任务 2+3（含口径统一）；「表格列定义/行内操作」→任务 3 步骤 2；「删除内容」→任务 1/3/4；「数据流」→任务 3 步骤 1（数据链不变）；「错误与边界」→空态文案在任务 3；「测试策略」→任务 1/2/3/5；「非目标」→不动的文件已列。无遗漏。
2. **占位符扫描**：无「待定/TODO/类似任务 N」；所有代码步骤含完整代码；两个「⚠️ 修正」块是对草稿的内联勘误，保留在计划里指导实现者走正确写法。
3. **类型一致性**：`StatsBar({stats, selectedKey, onSelect})` 在任务 2 定义、任务 3 调用一致；`statusFilter` 的值域 `''/started/in_progress/completed/expired` 与 `selectedStatKey` 推导一致；`DataTableAction` 的 role 修正（link 非 button）已在测试断言中统一；`CandidateTableProps` 的 `onClearFilters` 为页面传入 prop。
