# 小海文案丰富化与 OCR 移除 Implementation Plan

> **For implementer:** Use TDD throughout. Write failing test first. Watch it fail. Then implement.

**Goal:** Remove OCR completely from Xiao Hai raster poster generation while keeping `qwen3.6-flash` and producing richer structured copy.

**Architecture:** Both the synchronous workbench route and asynchronous conversation worker keep the shared GPT Image 2 edit call, branding overlays, and immutable poster versions. OCR-specific modules, retries, metadata, UI badges, and error handling are removed. The existing Flash copy summarizer gains richer fields and less restrictive item limits without changing user-field precedence.

**Tech Stack:** FastAPI/Python, pytest, React/TypeScript, Vitest.

---

### Task 1: Lock the new generation and copy behavior with tests

**Files:**
- Modify: `tests/test_xiao_hai_routes.py`
- Modify: `tests/test_xiao_hai_conversation.py`
- Modify: `tests/test_element_library.py`
- Modify: `tests/test_xiao_hai_image_service.py` (only if an OCR-specific image-service assertion is present)
- Add: `tests/test_poster_copy.py`

**Step 1: Write the failing tests**

- Change direct generation tests so a mocked image provider is asserted to be called exactly once even when the provider output would previously fail OCR.
- Change conversation job tests so the job succeeds with one image call and its `render_data` has no `ocr_validation` key.
- Add a copy summarizer test that captures the Flash request and asserts the prompt asks for `highlights`, `benefits`, and `career_growth`, and allows at least three responsibilities/requirements for long posters.

**Step 2: Run tests — confirm they fail**

Commands:

```bash
python -m pytest -q tests/test_xiao_hai_routes.py tests/test_xiao_hai_conversation.py tests/test_element_library.py tests/test_poster_token_e2e.py tests/test_poster_copy.py
```

Expected: FAIL because current generation invokes OCR/retry and current copy schema omits the richer modules.

**Step 3: Write minimal implementation**

Implement the production changes in Tasks 2–4.

**Step 4: Run tests — confirm they pass**

Run the same command; expected PASS.

### Task 2: Remove OCR from direct and queued generation

**Files:**
- Modify: `app/routers/xiao_hai.py`
- Modify: `app/poster_jobs.py`
- Delete: `app/xiao_hai_ocr.py`
- Delete: `tests/test_xiao_hai_ocr.py`

**Step 1: Write the failing test**

Use the tests from Task 1 to assert no second image call, no OCR metadata, and no OCR-specific exception path.

**Step 2: Run test — confirm it fails**

```bash
python -m pytest -q tests/test_xiao_hai_routes.py::TestXiaoHaiRoutes::test_generate_returns_429_without_prompt_fallback_retry tests/test_xiao_hai_conversation.py::test_queued_job_generates_an_immutable_child_version
```

Expected: FAIL because current code imports OCR and retries/records OCR output.

**Step 3: Write minimal implementation**

- Make `_call_unified_image_edit` return the single image result directly from the shared generator.
- Remove `_generate_with_ocr_retry`, OCR imports, OCR exception handling, and `ocr_validation` parameters/fields from the route.
- Make `_generate_job_poster` call the provider once and return bytes only; remove the OCR exception branch and metadata from queued versions.
- Delete the now-unreferenced OCR module and its dedicated test file.

**Step 4: Run test — confirm it passes**

```bash
python -m pytest -q tests/test_xiao_hai_routes.py tests/test_xiao_hai_conversation.py tests/test_element_library.py tests/test_poster_token_e2e.py
```

Expected: PASS for the Xiao Hai route, conversation, element-library, and copy tests. The separate token/trace E2E
test still requires its configured brand QR asset and existing trace-test environment.

### Task 3: Enrich Flash poster copy without changing the model

**Files:**
- Modify: `app/poster_jobs.py`
- Add/modify: `tests/test_poster_copy.py`

**Step 1: Write the failing test**

Capture the `LLMRequest` passed by `_call_poster_jd_summary` and assert the schema contains `highlights`, `benefits`, and `career_growth`; assert the long-canvas limits are at least three items and the prompt asks for persuasive but factual copy.

**Step 2: Run test — confirm it fails**

```bash
python -m pytest -q tests/test_poster_copy.py
```

Expected: FAIL because the current schema explicitly excludes benefits/highlights and limits output to two/three items.

**Step 3: Write minimal implementation**

- Keep `POSTER_TEXT_MODEL = "qwen3.6-flash"`.
- Expand the structured output schema and factual-only prompt with `highlights`, `benefits`, and `career_growth`.
- Raise item limits to four for long posters and three for compact posters.
- Merge the new list/string fields while preserving protected and user-priority fields.
- Pass the enriched fields through the existing full-poster prompt where applicable.

**Step 4: Run test — confirm it passes**

```bash
python -m pytest -q tests/test_poster_copy.py tests/test_xiao_hai_routes.py tests/test_xiao_hai_conversation.py
```

Expected: PASS.

### Task 4: Remove OCR UI and stale conversation copy

**Files:**
- Modify: `frontend-react/src/app/pages/XiaoHaiPage.tsx`
- Modify: `frontend-react/src/features/xiao-hai/XiaoHaiCommandCard.tsx`

**Step 1: Write the failing test**

Remove/replace assertions that expect OCR badges or OCR steps; assert the generation UI contains no OCR text.

**Step 2: Run test — confirm it fails**

```bash
pnpm --dir frontend-react vitest run src/app/pages/XiaoHaiPage.test.tsx
```

Expected: FAIL until the stale OCR UI strings and render-data handling are removed.

**Step 3: Write minimal implementation**

- Remove OCR status extraction and tags from `PosterResult`.
- Update command-card copy/steps to describe one image generation and branding completion without OCR.
- Keep current trigger buttons and retry behavior unchanged.

**Step 4: Run test — confirm it passes**

```bash
pnpm --dir frontend-react vitest run src/app/pages/XiaoHaiPage.test.tsx
```

Expected: PASS.

### Task 5: Verify no residual OCR path

**Files:**
- No planned source changes.

**Step 1: Run focused backend tests**

```bash
python -m pytest -q tests/test_xiao_hai_routes.py tests/test_xiao_hai_conversation.py tests/test_element_library.py tests/test_poster_token_e2e.py
```

Expected: PASS for the focused Xiao Hai tests. The token/trace E2E test additionally requires its configured brand QR
asset and existing trace-test environment.

**Step 2: Run focused frontend tests**

```bash
pnpm --dir frontend-react vitest run src/app/pages/XiaoHaiPage.test.tsx
```

Expected: PASS.

**Step 3: Search residual references**

```bash
rg -n "xiao_hai_ocr|PosterOCR|ocr_validation|append_ocr|validate_poster_copy|OCR CORRECTION|文字已校验|文字待复核" app frontend-react/src tests
```

Expected: no Xiao Hai production/UI references remain; unrelated resume/PDF OCR references may remain outside this feature.
