# React Root Cutover Acceptance Plan

> **For implementer:** Use TDD throughout. Write failing tests first, watch them fail, then implement the smallest change.

**Goal:** Add a reversible FastAPI entry switch that serves the built React shell for `/`, `/login`, `/forbidden`, and `/studio` while preserving the legacy Studio fallback by default.

**Architecture:** Keep FastAPI authentication and permission middleware as the single page-entry guard. Add `FRONTEND_APP_ENABLED` and `REACT_FRONTEND_DIR` checks around the existing React `dist/index.html`; serve React assets from `/assets` only when a build exists, and keep `/frontend/*` unchanged for rollback.

**Tech Stack:** FastAPI, Starlette middleware, React/Vite build output, pytest/TestClient, Playwright.

## Task 1: Add a reversible React shell resolver

**Files:**

- Modify: `app/config.py`
- Modify: `app/access_control.py`
- Modify: `app/routers/pages.py`
- Test: `tests/test_frontend_switch.py`

1. Add failing tests for flag-off legacy routing, flag-on React shell routing, missing-build fallback, and `/studio` permission mapping.
2. Run the focused backend test and confirm it fails because the resolver and flag behavior do not exist.
3. Implement runtime checks for `FRONTEND_APP_ENABLED` and `REACT_FRONTEND_DIR` without changing the default-off behavior.
4. Run the focused backend test and the existing access-control tests.

## Task 2: Serve React assets without weakening authentication

**Files:**

- Modify: `app/main.py`
- Modify: `tests/test_frontend_switch.py`

1. Add a failing test for the built React asset path and no-cache headers.
2. Mount the built `dist/assets` directory at `/assets` only when it exists; whitelist only static assets, not page routes.
3. Verify unauthenticated `/studio` redirects to login and authenticated users without `pipeline:read` are redirected to forbidden.

## Task 3: Expand browser acceptance coverage

**Files:**

- Add: `frontend-react/e2e/backend-entry.spec.ts`
- Add: `frontend-react/playwright.backend.config.ts`
- Modify: `frontend-react/playwright.config.ts` only if required by the test setup

1. Add a FastAPI browser check for the login shell, protected root behavior, legacy Studio fallback, and same-origin page serving while preserving the existing Vite smoke path.
2. Run both Playwright configurations with the installed Chromium browser.

## Task 4: Update migration acceptance records

**Files:**

- Modify: `docs/frontend-migration/acceptance-checklist.md`

1. Mark only the root-switch behaviors proven by backend and browser tests.
2. Keep full production cutover, rollback rehearsal, and other page migrations explicitly pending.

## Scope boundaries

- Do not enable React by default in production in this phase.
- Do not delete or rewrite `frontend/studio.html`.
- Do not migrate pipeline detail, batch operations, WebSocket pages, or other legacy pages in this phase.
- Do not commit or push until explicitly approved.

## Execution record

- [x] Task 1 completed with 17 focused backend tests passing.
- [x] Task 2 completed with static asset authentication boundaries and no-cache behavior covered.
- [x] Task 3 completed: Vite smoke 1/1 and FastAPI entry browser test 1/1 passed.
- [x] Task 4 completed: migration checklist records the proven root-switch behavior.
