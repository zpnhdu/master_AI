# 候选人视频直传 OSS 部署说明

候选人完整面试视频使用后端签发的短期 OSS 表单策略上传。浏览器不会获得 AccessKey Secret，策略仅允许上传一个随机对象，并限制文件类型、大小和有效期。OSS 未配置时，前端会兼容回退到原有后端流式上传。

## 必需配置

```dotenv
SECRET_KEY=<生产环境随机强密钥>
ALICLOUD_ACCESS_KEY=<仅后端可见>
ALICLOUD_ACCESS_SECRET=<仅后端可见>
ALICLOUD_OSS_BUCKET=aihr-recordings
ALICLOUD_OSS_ENDPOINT=oss-cn-hangzhou-internal.aliyuncs.com
ALICLOUD_OSS_PUBLIC_ENDPOINT=oss-cn-hangzhou.aliyuncs.com
ALICLOUD_OSS_REGION=cn-hangzhou
MASS_INTERVIEW_VIDEO_MAX_MB=512
MASS_INTERVIEW_UPLOAD_EXPIRES_SECONDS=1800
```

如果后端不使用内网 endpoint，`ALICLOUD_OSS_ENDPOINT` 和 `ALICLOUD_OSS_PUBLIC_ENDPOINT` 可以相同。也可以通过 `OSS_ACCESS_KEY_ID`、`OSS_ACCESS_KEY_SECRET`、`OSS_BUCKET`、`OSS_ENDPOINT` 配置兼容名称。

## Bucket CORS

在 OSS Bucket 的跨域设置中添加候选人站点来源：

- 来源：正式前端域名；本地联调时另加 `http://localhost:5173`
- 允许方法：`POST`
- 允许 Headers：`*`
- 暴露 Headers：`ETag`、`x-oss-request-id`
- 缓存时间：`600` 秒

生产环境不要把来源配置为 `*`。Bucket 应保持私有读权限，回放地址由后端签发。

## 服务账号最小权限

服务账号只需要目标 Bucket 下 `interviews/*`、`asr-temp/*` 和 `tts/*` 前缀所需的上传、读取、查询元数据和删除权限，不应授予其他 Bucket 或账号管理权限。

## 上传链路

1. 前端向 `/video-upload/prepare` 提交视频大小和类型。
2. 后端使用 OSS V4（HMAC-SHA256）返回绑定对象路径、文件大小、类型和过期时间的表单策略。
3. 浏览器直接向 OSS 上传视频并展示真实上传进度。
4. 前端调用 `/video-upload/complete`。
5. 后端校验签名令牌和 OSS 对象大小，记录对象 key，并异步下载到评分节点复用现有 ffmpeg、ASR 和评分流程。
