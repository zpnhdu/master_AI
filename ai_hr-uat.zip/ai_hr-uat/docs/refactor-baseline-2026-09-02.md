# 重构前基线（2026-09-02）

本文档记录大文件拆分前的可回归契约和验证基线。第一阶段只建立观测点，不改变业务实现。

## 1. 基线范围与工作树

- 工作区：`D:\Java\company\ai_hr`
- 分支：`feature/lwx-backend`
- 基线提交：`4113b63`
- 工作树状态：已有未提交改动 `app/email_accounts.py`；该文件不是本次工作产生的内容，不纳入本次基线改动和后续提交。
- 本阶段原则：保持 HTTP、WebSocket、数据库 facade、前端路由、查询缓存和状态值不变。

## 2. 可回归契约

### 2.1 后端应用装配

- 启动入口：`app/main.py:5-19`
- 应用工厂：`app/bootstrap/factory.py:10-15`
- 路由注册：`app/bootstrap/routes.py:44-77`
- HTTP 横切逻辑：`app/bootstrap/http.py:22-253`
- 生命周期恢复：`app/bootstrap/lifecycle.py:14-178`
- `APPLICATION_ROUTERS` 当前注册 33 个 router；路由源码中的装饰器计数为 309（该值是静态源码计数，不等同于 FastAPI 最终 OpenAPI 路由数）。

### 2.2 主要后端路由域

路由路径和 HTTP 方法是拆分时必须保持的外部契约。当前源码按模块的装饰器计数如下：

| 模块 | 数量 | 主要职责 |
|---|---:|---|
| `app/routers/pipelines.py` | 30 | Pipeline、阶段、简历、JD 工作台 |
| `app/routers/pages.py` | 24 | 页面和兼容页面入口 |
| `app/routers/mass_interview.py` | 23 | 视频面试、session、媒体和评分 |
| `app/routers/analytics.py` | 22 | 看板、漏斗、Leader Chat 和分析 |
| `app/routers/interview.py` | 17 | 面试题、ASR、答案和评估 |
| `app/routers/ontology.py` | 15 | 本体和记忆规则 |
| `app/routers/question_review.py` | 15 | 题目审核、锁定和导出 |
| `app/routers/talent_pool.py` | 14 | 人才库和候选人助手 |
| `app/routers/agents.py` | 13 | Agent、角色和海报兼容接口 |
| `app/routers/assessment_flow.py` | 13 | 评估方案、队列和报告 |
| `app/routers/xiao_hai.py` | 13 | 海报任务和版本 |
| `app/routers/conversations.py` | 12 | 会话、命令和会话 WebSocket |
| `app/routers/knowledge.py` | 12 | 旧知识库接口 |
| `app/routers/mass_interview_streams.py` | 8 | 直播状态和云回调 |
| 其他 router | 78 | 认证、管理、简历、笔试、Wiki、RPA、媒体等 |

关键业务路由示例：

- Pipeline 创建：`POST /api/pipelines`，`app/routers/pipelines.py:307`
- Pipeline 启动：`POST /api/pipelines/{pipeline_id}/auto-run`，同文件 `:426`
- 简历上传：`POST /api/pipelines/{pipeline_id}/upload-resumes`，同文件 `:1449`
- 简历解析：`POST /api/pipelines/{pipeline_id}/parse-resumes`，同文件 `:1588`
- 小筛确认：`POST /api/pipelines/{pipeline_id}/screening-workflow/finalize`，`app/routers/candidates.py:181`
- 笔试启动：`POST /api/written-test/launch`，`app/routers/written_test.py:316`
- 视频面试启动：`POST /api/mass-interview/launch`，`app/routers/mass_interview.py:342`
- 评估队列：`GET /api/assessment/{pipeline_id}/queue`，`app/routers/assessment_flow.py:66`
- 综合报告任务：`POST /api/assessment/{pipeline_id}/aggregate-report/jobs`，同文件 `:80`
- Pipeline WebSocket：`/ws/{pipeline_id}`，`app/routers/websocket.py:256`
- 会话 WebSocket：`/ws/conversations/{session_id}`，`app/routers/conversations.py:245`

实际前缀以 `app/routers/__init__.py` 和 `app/bootstrap/routes.py` 中的 router 配置为准；拆分时应使用 OpenAPI 或 FastAPI 路由表重新核对完整路径。

### 2.3 后端状态契约

评估方案定义在 `app/assessment_flow.py:12-16`：

- 组合：`all`、`any`、`conditional`
- 评估方式：`written_test`、`video_interview`、`manual_interview`
- 比较符：`gt`、`gte`、`lt`、`lte`、`eq`
- 条件分支动作：`ready`、`review`、`close`
- 可进入就绪计算的执行状态：`submitted`、`completed`、`evaluated`

评估结果字段由 `record_step_result()` 写入（`app/assessment_flow.py:549-641`）：

- `execution_status`
- `scoring_status`
- `review_status`
- `result_status`
- `score`
- `evidence`
- `scoring_version`
- `red_flags`
- `metadata`

评估队列状态至少包括：

- `ready_for_decision`
- `incomplete`
- `closed_incomplete`

其他必须保持的状态和业务约束：

- 面试通过分阈值：`60`，`app/db.py:29-31`
- 面试 session 超时：`35` 分钟，`app/db.py:33`
- 笔试 scoring：`queued` -> `processing` -> `succeeded` 或 `failed`，相关流程见 `app/routers/written_test.py:611-867`
- 海报任务：`queued`、`running`、`cancel_requested`、`cancelled`、`succeeded`、`failed`，见 `app/poster_jobs.py:379-830`
- 综合报告任务：`queued`、`running`、`succeeded`、`failed`，见 `app/aggregate_report_jobs.py:89-215`
- 视频 session：`invited`、`started`、`in_progress`、`streaming`、`completed`、`evaluated`、`expired`，相关逻辑见 `app/routers/mass_interview.py:723-863` 和 `:1988-2395`

### 2.4 数据访问兼容面

`app/db.py` 是现有公共数据库 facade，当前约 168 个顶层定义，其中大量调用方直接从 `app.db` 导入函数。拆分时旧导入路径必须继续工作。

重点兼容域：

- 连接和事务：`app/db.py:36-235`
- RBAC、用户、角色和 session：`app/db.py:253-505`
- 公司及 Agent 配置：`app/db.py:508-750`
- Pipeline 和阶段：`app/db.py:898-1209`
- 候选人、消息和记忆：`app/db.py:1695-2038`
- 人才库和简历：`app/db.py:2039-2460`
- 分析和看板：`app/db.py:2461-3578`
- RPA：`app/db.py:3606-3707`
- 面试 session、排名和直播：`app/db.py:3708-4305`

拆分前后必须保持：事务边界、行锁、删除顺序、返回字段、SQL 兼容性、跨 Pipeline 去重和测试对 `app.db` 的 monkeypatch 行为。

### 2.5 前端路由与权限

路由定义集中在 `frontend-react/src/app/routes/route-definitions.ts:14-68`，实际渲染在 `frontend-react/src/app/router.tsx:58-227`。

公开路由：

- `/login`
- `/privacy`
- `/terms`
- `/mass-interview/:token`
- `/written-test/:token`

主要受保护路由和权限：

| 路由 | 权限 |
|---|---|
| `/`、`/studio`、`/pipelines/:pipelineId` | `pipeline:read` |
| `/xiao-wen`、`/xiao-xun`、`/xiao-hai`、`/xiao-shai`、`/xiao-mian`、`/xiao-ping` | `pipeline:read` |
| `/mass-dashboard`、`/mass-dashboard/:pipelineId` | `interview:read` |
| `/talent-pool`、`/profile` | `talent:read` |
| `/dashboard`、`/monitor` | `analytics:read` |
| `/knowledge` | `knowledge:read` |
| `/knowledge?tab=materials` | `materials:read` |
| `/admin` | `user:manage` |
| `/roles/:roleId` | `system:manage` |

`routePermission()` 对路径参数和 query 做精确匹配，见 `route-definitions.ts:113-145`。不要在页面拆分时改变 query 规则或默认重定向。

### 2.6 前端实时和缓存契约

React 端没有 Redux/Zustand，服务端状态主要由 TanStack Query 管理；页面交互状态由 React hooks 管理。

统一 WebSocket 行为位于 `frontend-react/src/shared/usePipelineSocket.ts:36-135`：

- 地址：`/ws/{pipelineId}`
- 建连后发送 `{type: "load_pipeline", pipeline_id}`
- 断线 3 秒重连
- 每 30 秒发送 `{type: "ping"}`
- 触发同步的事件：`pipeline_loaded`、`stage_start`、`stage_done`、`stage_card`、`stage_error`、`pipeline_done`、`artifact_passed`
- 事件到达时失效：`["pipeline-detail", pipelineId]`、`["pipeline-candidates", pipelineId]` 及调用方追加的 key

当前主要 Query key 命名约定：

- Pipeline：`["pipelines", ...]`
- Pipeline 详情：`["pipeline-detail", pipelineId]`
- Pipeline 候选人：`["pipeline-candidates", pipelineId]`
- 小文：`["jd-workspace", pipelineId]`（由 `jdWorkspaceQueryKey()` 生成）
- 小寻：`["xiao-xun", ...]`
- 小筛：`["xiao-shai", ...]`
- 小面：`["xiao-mian", ...]`
- 小评：`["xiao-ping", ...]`
- 海报任务：`["xiao-hai", "jobs", pipelineId]`
- 面试中心：由 `massDashboardKeys` 生成 `pipelines`、`status`、`streams`、`ranking`、`schedules`、`candidates` 等 key
- Wiki：`["wiki", ...]`
- 人才库：由 `talentPoolKeys` 生成 `all`、`resumes(params)` 等 key

拆分 API 或页面时必须保留公开导出、query key 和 mutation 成功后的 invalidate 关系；否则页面可能显示旧的阶段、候选人或任务状态。

## 3. 大文件尺寸基线

以下指标来自 2026-09-02 工作树。SHA-256 用于确认拆分前原文件内容，不是业务版本号。

| 文件 | 行数 | 字节数 | SHA-256 |
|---|---:|---:|---|
| `frontend-react/src/styles.css` | 17,109 | 341,163 | `1960a8ba8b99e9d56a764d4f32f0ce32e091b3e6a9d95e5cbe33f33ef89a3134` |
| `app/db.py` | 4,312 | 168,382 | `cab367bc90dbd3c063bce05d48d771a01c596657a58692d182b8c35e5e6b3f9c` |
| `app/routers/mass_interview.py` | 3,772 | 150,484 | `47c79c57bacbe1f8bafae31623e21a72c4cd48d611bec1d1403e0d799c1343ac` |
| `app/routers/pipelines.py` | 2,344 | 88,981 | `ea38a22486ebcb67414c5f9809f90d3942405a46502b6e48c6d853cbb9f8a75c` |
| `app/action_handler.py` | 2,055 | 86,560 | `6b77704f4067b33f965e8fda96f74f632beb8beda9f50dd8ad07f12fb87b91b2` |
| `frontend-react/src/app/pages/MassDashboardPage.tsx` | 1,895 | 70,514 | `e1a4b497c50f2618d26ebeb3302bf50656bed43a7bd79a3509a83fc9570d4b72` |
| `app/db_schema.py` | 1,714 | 79,039 | `9414dbbeec658265350cdb2b0fb9ff921dbd92911035d44122738526b07cf8c` |
| `app/services.py` | 1,535 | 63,033 | `9084c93fe0ca25c6030644685ce3a0aba69f031c82e544079f9b2b99a32e57e6` |

生成文件（例如 `pnpm-lock.yaml`）不纳入人工拆分范围。

## 4. 现有测试入口

静态文件计数：

- 后端 `tests/test_*.py`：137 个
- 前端 `src/**/*.test.ts(x)`：67 个
- 前端 Playwright `e2e/*.spec.ts`：5 个

命令：

```bash
# 后端：默认跳过需要真实服务和登录的黑盒测试
pytest

# 后端黑盒测试（需先启动服务并设置 API_BASE_URL）
pytest tests/test_api_comprehensive.py

# 前端类型检查
pnpm --dir frontend-react run typecheck

# 前端单元测试
pnpm --dir frontend-react run test:run

# 前端 Playwright
pnpm --dir frontend-react run test:e2e
pnpm --dir frontend-react run test:e2e:backend
```

`pyproject.toml:5-10` 默认忽略 `tests/test_api_comprehensive.py`。本次基线不自动启动数据库、Redis、OSS、LLM 或浏览器服务，因此黑盒和真实外部依赖测试需要单独执行。

### 4.1 本次实际结果

| 检查 | 结果 | 说明 |
|---|---|---|
| `pytest` | 失败：1167 通过，20 失败（共 1187） | 使用 `PYTHONPATH=.` 执行；失败为当前工作树已有的数据库、OSS、邮箱、评估、Wiki 和启动时序问题，未修改业务代码。 |
| `pnpm --dir frontend-react run typecheck` | 通过 | 两个 TypeScript 配置均通过。 |
| `pnpm --dir frontend-react run test:run` | 失败：364 通过，37 失败（共 401） | 67 个测试文件中 55 个通过、12 个失败；包含媒体上传回退、Ant Design/jsdom 超时、页面断言等已有失败。 |
| `pnpm --dir frontend-react exec vitest run src/styles.agent-pages.test.ts` | 通过：19/19 | 当前全局样式相关专项测试通过。 |
| `git diff --check`（基线文档） | 通过 | 文档无空白错误。 |

失败详情摘要：

- 后端：`tests/test_element_library_oss.py`、`test_email_logging.py`、`test_full_pipeline.py`、`test_hr_performance.py`、`test_mass_interview_direct_upload.py`、`test_mass_interview_scoring_safety.py`、`test_pipeline_completion.py`、`test_startup_performance.py`、`test_wiki.py`。
- 前端：`src/features/mass-interview/api.test.ts`、`src/shared/list-workbench/list-workbench.test.tsx`、`src/shared/data-table/DataTable.test.tsx` 以及多个页面测试；其中部分失败是超时，部分是断言或测试环境 API 不完整。
- 初次直接执行 `pytest` 未设置 `PYTHONPATH`，在收集阶段报 `ModuleNotFoundError: No module named 'app'`；随后用 `PYTHONPATH=.` 完整执行，以上 1187 项结果才是有效基线。

## 5. 后续拆分的验收门槛

每一批拆分至少要通过：

1. `git diff --check`，且只包含本批指定文件。
2. 受影响后端 pytest 子集和完整默认 pytest。
3. 前端 `typecheck` 与受影响 Vitest 子集。
4. 路由表核对：路径、方法、依赖和 response model 不变。
5. `app.db` 与 `ActionHandler` 兼容导入检查。
6. WebSocket 事件名、Query key 和 invalidate 关系核对。
7. 涉及 UI 时执行 390、768、1366 宽度的 Playwright smoke/截图检查。
8. 不把现有未提交的 `app/email_accounts.py` 改动纳入提交。

## 6. 本阶段结论

第一步基线已建立。当前不修改业务代码；下一步应优先处理全局 CSS，按明确导入顺序拆分，并用页面行为、响应式和截图基线验收。数据库 facade、多人面试路由和后台任务应在 CSS 基线稳定后再分批处理。
