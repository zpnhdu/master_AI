# 并行协作规范（Git 多人在线协同）

> 目的：多人（含多个 AI agent）在同一仓库/分支并行工作时，避免未提交改动被误提交、丢失或混入他人提交。
> 背景：2026-08 曾发生同一 worktree 上双会话并行，一方 `git add -A` 把另一方的 staged 改动卷进提交，随后 reset 重提交才侥幸找回——**能找回是运气，不是常态**。

---

## 一、四条铁律

1. **先识别环境，再动代码**
   开工前 30 秒确认是否与他人共享工作区（见下"开工前检查"）。共享 = 高风险模式，全程按本规范执行。

2. **小步提交，不攒大包**
   一个功能点做完立即 commit。改动窗口越大，被卷走/冲突的风险和损失越大。
   - 反例：一次攒 20+ 文件（收口/性能/看板/渲染 4 件事混在一个 commit 里）
   - 正例：按功能拆 3-4 个 commit，每个边界清晰

3. **精确暂存，永远不用 `git add -A` / `git add .`**
   `git add <具体文件>` 逐个指定。这是提交边界唯一可靠的防线。

4. **诊断真相看 reflog，别信 git show**
   `git show <sha> --stat` 里出现"你的文件" ≠ 你的改动已提交——该提交可能已被 reset/amend。
   确认改动是否在仓库：`git show HEAD:<file> | grep <你的改动标识>`。
   **`git reflog` 是还原 reset/amend 真相的唯一可靠来源。**

---

## 二、检查清单

### 开工前（30 秒）

```bash
git worktree list        # 是否存在其他 worktree（共享信号）
git reflog -5            # 最近是否有人 reset/amend/commit
git status -sb           # 记录基线状态，后续对比
```

### 提交前（每次）

```bash
git status --porcelain   # 连续读两次：出现/消失自己没动过的文件 = 有人并行
git diff HEAD --stat     # 核对边界：只含自己要提交的内容
git add <具体文件>        # 精确暂存
git commit               # add 后立即 commit，不隔夜
```

### 检测到并行操作时

```text
1. 立即停止所有 git 写操作（commit/reset/checkout/push）
2. git fetch + git reflog，确认对方在做什么、有没有卷走你的东西
3. 确认无混入后再提交；push 前再 fetch 一次，确认 fast-forward
4. 不确认就不动，宁可等对方提交完
```

---

## 三、提交规范自查（钩子会卡）

本仓库 pre-commit + commitlint 强制检查，提交前自查避免反复失败：

| 规则 | 要求 |
|---|---|
| subject 长度 | ≤ 72 字符 |
| subject 大小写 | 小写开头（`Token...` 会失败，用 `token...`） |
| scope | 从枚举取：`pipeline/interview/agent/kg/frontend/api/feishu/rpa/infra` |
| body 行宽 | 每行 ≤ 100 字符 |
| 依赖 | 代码 import 的库必须同步进 `requirements.txt`（pre-commit 的 import 检查） |

---

## 四、根治方案（推荐给正式项目）

同一目录裸奔式并行是事故温床，正式项目应做到：

1. **每人独立 worktree + 独立分支**

   ```bash
   git worktree add ../ai_hr-lyx -b feature/lyx_xxx
   # 工作、提交都在独立 worktree，互不可见对方的未提交改动
   ```

2. **合入走 PR / code review**，而不是直接 push 共享分支
3. **未提交改动不跨会话共享**：一个 agent/会话的工作在结束时 commit（即使未完成，用 `WIP` 提交标记），避免工作区残留
4. 工具产物（`.pi-subagents/` 等）加入 `.gitignore`，避免污染 status、混入误提交

---

## 五、事故处置速查

| 症状 | 处置 |
|---|---|
| status 出现自己没动过的文件 | 暂停，`git reflog` 查谁在动 |
| 自己的改动"消失"了 | `git reflog` 找 commit，`git show <sha>:<file>` 确认内容，`git cherry-pick` / 手动恢复 |
| 提交里混入了别人的文件 | 未 push：`git reset HEAD~1` 拆开重提；已 push：与对方协商，切勿私自 force push |
| push 被拒（non-fast-forward） | 对方已推送，先 `git pull --rebase` 再推 |
