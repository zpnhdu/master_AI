# 目录整理清单与迁移方案

> 制定日期：2026-09-03
>
> 目标：把后端 `app/` 顶层 73 个扁平 `.py` 模块按领域归入子包。
>
> 性质：**本文档只做现状清单与迁移方案，不移动、不改动任何代码。** 实际迁移需先按
> `docs/collaboration-parallel.md` 确认工作区与协作者状态，再逐批小步执行。
>
> 前置提醒：本仓库存在并行的 email worktree（`codex/talent-email-phase1`），且
> `app/email_accounts.py` 归协作者所有，任何阶段都不得触碰。

---

## 一、现状盘点

### 1. 后端 `app/`

- 顶层扁平模块：**73 个 `.py`**，其中 8 个大文件都在顶层，其余约 65 个中小模块散落。
- 已有规整子包（**保持不变，只做归类表中的引用**）：

| 子包 | 内容 | 说明 |
|---|---|---|
| `routers/` | 29 个路由模块 + 聚合 `__init__.py` | 已分层 |
| `infrastructure/` | config / health / timeout_policy + cache / tasks / vector 子包 | 已分层 |
| `bootstrap/` | factory / http / lifecycle / routes | 已分层 |
| `models/` | schemas.py（Pydantic model） | 已分层，仅 1 个模块 |
| `repositories/` | pipeline_queries.py | 已分层，仅 1 个模块 |
| `resume_parser/` | core / legacy / llm_adapter / mapper / prompts | 已分层 |
| `audit/` | audit_trail / llm_trace / logger / routes / token_tracker | 已分层 |
| `alicloud/` | alicloud_live.py | 已分层 |

### 2. 前端 `frontend-react/src/`

已经按 `app/` + `features/`（22 个领域目录）+ `shared/` + `styles/` 分层清晰，**本次不涉及**。

### 3. 仓库顶层

运行时产物目录已被 `.gitignore` 覆盖（`logs/`、`uploads/`、`output/`、`data/`、`dist/`、
缓存目录等），无需整理。`memory/` 有 6 个被跟踪文件，需保留。其余为独立子项目或工程目录。

---

## 二、73 个顶层模块的领域归类

> 大小取“字节数 / 行数”，便于判断拆分优先级。目标包名为建议，命名可按仓库约定微调。

### A. 保留在 `app/` 顶层（应用引导与基础，不迁移）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `main.py` | 522B / 19L | FastAPI 入口 |
| `config.py` | 4.2KB / 107L | 应用配置常量 |
| `environment.py` | 2.0KB / 55L | 环境变量加载 |
| `security.py` | 1.1KB / 32L | 本地账号密码工具 |
| `utils.py` | 2.3KB / 70L | 通用工具（从 main 抽出） |
| `state.py` | 2.6KB / 77L | 共享应用状态 / 广播 |
| `access_control.py` | 12.7KB / 338L | 会话鉴权与权限检查（可择机并入 `app/auth/`） |
| `template_compositor.py` | 8.4KB / 210L | 模板路径解析（其首行 docstring 有误，需顺带修正） |

> 可选：将上述 8 个进一步收进 `app/core/`，但优先级低，建议保持顶层以免引入早期循环导入。

### B. `app/db/` — 数据库 facade（对应计划文档**阶段 C**）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `db.py` | **158KB / 4142L** | 持久层 facade，待拆 |
| `db_runtime.py` | 5.2KB / 176L | MySQL 连接运行时 |
| `pending_repository.py` | 2.6KB / 79L | 重启安全 pending 数据 |

### C. `app/schema/` — 表结构（对应**阶段 G**）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `db_schema.py` | **77KB / 1714L** | schema 初始化与幂等迁移 |

### D. `app/action_handler/` — Agent 动作分发（对应**阶段 F**）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `action_handler.py` | **84KB / 2055L** | LLM 意图处理 / action 分发 |

### E. `app/services/` — 业务服务与外部适配（对应**阶段 H**）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `services.py` | **55KB / 1384L** | Pipeline 处理服务（从 main 抽出） |
| `wecom_schedule.py` | 5.1KB / 132L | 企业微信复试日程 |

### F. `app/email/` — 邮件（对应**阶段 H** 的 mail；`email_accounts.py` 属协作者，勿动）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `email_sync.py` | **61KB / 1365L** | 多账户 IMAP 运行器 |
| `email_sender.py` | 19.5KB / 517L | SMTP 发送 |
| `user_mailbox.py` | 7.4KB / 202L | 用户邮箱 1:1 联动 |
| `email_providers.py` | 2.7KB / 75L | 服务商预设 |
| `email_logging.py` | 1.2KB / 40L | 邮箱日志 |
| `email_accounts.py` | 12.4KB / 342L | ⚠️ 协作者文件，本阶段只登记不迁移 |

### G. `app/feishu/` — 飞书集成（对应**阶段 H** 的 feishu）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `feishu_webhook.py` | 12.1KB / 311L | webhook 接收 / 命令解析 |
| `feishu_notify.py` | 3.5KB / 110L | 卡片消息 |
| `feishu_sync.py` | 3.1KB / 97L | OpenAPI client |

### H. `app/media/` — 媒体资产（对应**阶段 H** 的 media / asr_tts）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `multimodal.py` | 32.7KB / 892L | ASR / TTS / 图像分析 |
| `media_storage.py` | 8.4KB / 226L | 媒体存储适配 |
| `brand_assets.py` | 3.0KB / 89L | 品牌素材 |
| `image_thumbnails.py` | 735B / 20L | 缩略图 |
| `upload_workers.py` | 583B / 20L | 上传线程池 |

### I. `app/agents/` — 各 Xiao Agent 及其专属服务

| 模块 | 大小 | 说明 |
|---|---:|---|
| `xiao_hai_image.py` | **60KB / 1533L** | 小海画布 / prompt / 生图 |
| `xiao_hai_branding.py` | 13.3KB / 319L | 小海品牌素材 |
| `xiao_hai_conversation.py` | 11.4KB / 307L | 小海海报修改解析 |
| `xiao_hai_generation_jobs.py` | 11.1KB / 332L | 小海生图任务 |
| `xiao_hai_prefill.py` | 3.3KB / 94L | 小海预填 |
| `poster_jobs.py` | 33.1KB / 857L | 图生图持久化任务 |
| `poster_delivery.py` | 18.4KB / 440L | 海报交付 |
| `poster_service.py` | 11.9KB / 283L | 海报资产版本 |
| `poster_progress.py` | 9.3KB / 230L | 海报阶段写回 |
| `poster_generation.py` | 937B / 29L | 海报 body 合成 |
| `xiao_mian_conversation.py` | 18.4KB / 385L | 小面会话 |
| `xiao_wen_context.py` | 2.4KB / 74L | 小文上下文 |
| `xiao_wen_startup.py` | 384B / 12L | 小文预热 |
| `screening_workflow.py` | 28.2KB / 712L | 小筛面试工作流 |
| `screening_model.py` | 9.0KB / 235L | 小筛模型打分 |

> 可选：按 agent 拆二级子包 `app/agents/xiao_hai/` 等；初期可先平铺在 `app/agents/`。

### J. `app/conversation/` — 统一多 Agent 会话

| 模块 | 大小 | 说明 |
|---|---:|---|
| `conversation_service.py` | 15.7KB / 377L | 六 Agent 会话统一入口 |
| `conversation_store.py` | 7.6KB / 218L | 会话 / 命令账本持久化 |
| `conversation_capabilities.py` | 1.5KB / 47L | 能力注册表 |
| `conversation_events.py` | 855B / 29L | WebSocket 通知 |

### K. `app/interview/` — 面试对话与脚本

| 模块 | 大小 | 说明 |
|---|---:|---|
| `interview_conversation.py` | 41.9KB / 956L | 面试对话解析 / 追问 / 预览 |

### L. `app/assessment/` — 评估 / 出题 / 人工审核 / 笔试打分

| 模块 | 大小 | 说明 |
|---|---:|---|
| `question_review.py` | 39.8KB / 1002L | 出题人工审核 |
| `assessment_flow.py` | 34.5KB / 874L | 统一评估状态机 |
| `written_scoring.py` | 13.0KB / 307L | 笔试行为打分 |
| `assessment_dispatch.py` | 2.9KB / 64L | 评估后续环节派发 |

### M. `app/talent/` — 人才库与简历

| 模块 | 大小 | 说明 |
|---|---:|---|
| `talent_pool.py` | 34.3KB / 936L | 人才库 / 简历集中存储 |
| `resume_contact.py` | 3.9KB / 133L | 联系方式抽取 |

### N. `app/pipeline/` — 招聘流程 / JD / 岗位

| 模块 | 大小 | 说明 |
|---|---:|---|
| `jd_workspace.py` | 18.6KB / 473L | JD 草稿 / 确认 / 质检 |
| `pipeline_cleanup.py` | 4.8KB / 111L | 删除流水线清理 |
| `job_types.py` | 1.2KB / 41L | 岗位类型定义 |

### O. `app/reports/` — 报表生成

| 模块 | 大小 | 说明 |
|---|---:|---|
| `candidate_reports.py` | 35.0KB / 875L | 候选人评估报告 |
| `reports.py` | 10.2KB / 299L | 日报 / 周报 |
| `aggregate_report_jobs.py` | 6.9KB / 214L | 报表后台任务 |

### P. `app/analytics/` — 分析对话与聚合

| 模块 | 大小 | 说明 |
|---|---:|---|
| `leader_chat_service.py` | 26.8KB / 615L | 领导分析对话 |
| `leader_chat_store.py` | 9.7KB / 274L | 分析会话持久化 |
| `leader_chat_tools.py` | 4.6KB / 120L | 分析工具白名单 |

### Q. `app/wiki/` — Wiki 知识库（含分词）

| 模块 | 大小 | 说明 |
|---|---:|---|
| `wiki_store.py` | 41.3KB / 1095L | Wiki 存储（markdown 真源） |
| `wiki_ingest.py` | 30.0KB / 769L | Wiki 摄取 |
| `wiki_query.py` | 12.0KB / 343L | Wiki 查询 / SSE |
| `kb_tokenizer.py` | 4.8KB / 151L | 文档 RAG 分词（可并入 `app/knowledge/`） |

### R. `app/helpers/` — 本次重构新增的纯函数 helper

| 模块 | 大小 | 说明 |
|---|---:|---|
| `service_helpers.py` | 13.3KB / 345L | Pipeline 处理纯函数 |
| `role_overview_helpers.py` | 5.9KB / 181L | 角色总览聚合 |
| `talent_pool_helpers.py` | 1.9KB / 59L | 人才库分组 |
| `analytics_time_helpers.py` | 764B / 24L | 时间解析 |

> 这 4 个文件恰是计划文档“先收敛 reducer”的产物。短期可先归 `app/helpers/`；
> 长期应在**阶段 C** 做 `db.py` facade 拆分时，随各领域函数一起吸收进 `app/db/` 或对应领域包。

---

## 三、迁移目标目录树

```text
app/
├─ main.py  config.py  environment.py  security.py  utils.py  state.py
├─ access_control.py  template_compositor.py        # 可选再收进 core/
├─ db/                     # 阶段 C：db.py + db_runtime + pending_repository
├─ schema/                 # 阶段 G：db_schema.py
├─ action_handler/         # 阶段 F：action_handler.py
├─ services/               # 阶段 H：services.py + wecom_schedule
├─ email/                  # 阶段 H：email_*（email_accounts.py 除外）
├─ feishu/                 # 阶段 H：feishu_*
├─ media/                  # 阶段 H：multimodal / media_storage / brand_assets / image_thumbnails / upload_workers
├─ agents/                 # xiao_* / poster_* / screening_*
├─ conversation/           # conversation_*
├─ interview/              # interview_conversation
├─ assessment/             # question_review / assessment_flow / assessment_dispatch / written_scoring
├─ talent/                 # talent_pool / resume_contact
├─ pipeline/               # jd_workspace / pipeline_cleanup / job_types
├─ reports/                # reports / candidate_reports / aggregate_report_jobs
├─ analytics/              # leader_chat_*
├─ wiki/                   # wiki_* + kb_tokenizer
├─ helpers/                # 4 个 *_helpers.py（阶段 C 时按领域吸收）
│
├─ routers/  bootstrap/  infrastructure/  models/  repositories/
├─ resume_parser/  audit/  alicloud/                    # 已有子包，保持不变
└─ __init__.py
```

---

## 四、建议迁移顺序

> 严格对应已有计划文档的 C→H，并补齐文档未覆盖的其余模块（新增阶段 J1–J6 建议）。

| 顺序 | 阶段 | 目标 | 说明 |
|---|---|---|---|
| 1 | 前置 | 继续收敛 reducer | 先补齐 `get_owner_overview_for_user`、`get_talent_pool_growth`、`get_stage_pass_rate_trend` 的纯 reducer，与已抽取的 4 个 helper 汇合 |
| 2 | 阶段 C | `db.py` → `app/db/` | facade + 领域模块，保留旧导入路径；先建包再逐领域迁移 |
| 3 | 阶段 G | `db_schema.py` → `app/schema/` | 表结构不随迁移改动 |
| 4 | 阶段 H | `services.py` + email/feishu/media → 各自包 | 外部适配薄 facade；`email_accounts.py` 除外 |
| 5 | J1 | agents 系（xiao_* / poster_* / screening_*） | 业务域独立，依赖少 |
| 6 | J2 | wiki 系（wiki_* / kb_tokenizer） | 独立 LLM-wiki |
| 7 | J3 | assessment 系 | 评估状态机 / 出题 / 打分 |
| 8 | J4 | conversation / interview / talent / reports / analytics / pipeline | 剩余中小域 |
| 9 | 阶段 F | `action_handler.py` → `app/action_handler/` | 放最后，因与多域耦合最深 |
| 10 | 收尾 | helpers 归位 + 清理循环导入 + 旧 import 兼容测试 | 全量回归后收口 |

> 也可先做「阶段 8」里最独立的小域（talent / reports）作为低风险试点，验证
> facade + re-export 模式在真实代码上的可行性，再推进大文件（db.py / action_handler.py）。

---

## 五、迁移硬约束（每次移动必守）

1. 保留旧公开导入路径：`from app.db import ...`、`from app import X_helpers`、路由模块导出、
   Pydantic model 路径、测试 monkeypatch 路径，均通过 `re-export` 或薄 wrapper 保持兼容。
2. 不同时改业务逻辑、SQL、schema、路由、事务边界、状态机或外部服务时序。
3. 每移动一组就跑定向测试 + `git diff --check`，再进下一组；不在同一提交混入协作者文件。
4. 开始前必读 `docs/collaboration-parallel.md`，连续两次 `git status --porcelain` 一致才动写操作。
5. 禁止 `git add -A` / `git add .` / `git reset --hard`。

---

## 六、暂不动清单

- **前端** `frontend-react/src/`：已分层，无需迁移。
- **顶层运行时目录**：`logs/ uploads/ output/ data/ dist/` + 缓存目录，已被忽略，不纳入清理。
- **`app/email_accounts.py`**：协作者文件，任何阶段不迁移、不修改。
- **`docs/architecture-and-dataflow.md`**：未跟踪，非本次重构内容，不暂存不提交。
- **已有子包**：`routers/ bootstrap/ infrastructure/ models/ repositories/ resume_parser/ audit/ alicloud/`，保持现状。

---

## 七、每阶段验收（与计划文档一致）

- 目标文件职责边界清楚，旧模块不再承载已迁移实现。
- 公开导入路径兼容、路由/依赖/响应模型不变。
- 数据库事务、锁、删除顺序、返回字段不变。
- 受影响单元测试通过；前端 typecheck/build 或后端 pytest 通过；全量失败数与基线对比无新增。
- `git diff --check` 通过；两次连续 `git status --porcelain` 一致；提交只含本阶段文件；未触碰协作者文件。