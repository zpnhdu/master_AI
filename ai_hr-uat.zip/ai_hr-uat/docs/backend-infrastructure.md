# 后端基础设施接入说明

> 本文档是历史改造说明。当前业务主库已切换为 MySQL（SQLite 支持已移除），本地文件和同步流程保持不变；Redis、Elasticsearch、OSS 等可选服务仍按配置接入。

## 当前接入点

| 能力 | 默认实现 | 可选实现 | 配置入口 |
|---|---|---|---|
| 业务数据库 | MySQL | — | `DB_HOST` / `DB_NAME` |
| 缓存/临时状态 | No-op | Redis | `REDIS_URL` |
| 向量检索 | Disabled | Elasticsearch 8.x | `VECTOR_BACKEND` |
| 媒体文件 | 本地目录 | 阿里云 OSS | `MEDIA_STORAGE_BACKEND` |
| 异步任务 | 仅返回任务描述 | Redis 队列入口 | `REDIS_URL` |
| 集中日志 | 控制台 + `logs/app.log` 按天轮转 | 自定义目录 | `LOG_LEVEL` / `APP_LOG_DIR` |

配置集中在 `app/infrastructure/config.py`，Provider SDK 仅出现在对应适配模块中。业务模块后续应依赖适配器公开方法，不直接实例化 Redis、Elasticsearch 或 OSS SDK。

## 本地启动

```bash
bash run.sh local
```

未设置 `APP_ENV` 时，本地直接启动加载 `config/environments/.env.local`，其中 MySQL、Redis 指向
本机，不使用 Docker。设置 `APP_ENV=dev|uat|prod` 时，应用分别加载 `.env.dev`、`.env.uat`、`.env.prod`；这
三份文件当前内容保持一致。FastAPI 在检测到 `frontend-react/dist` 构建产物时直接托管 React 页面（目录可用 `REACT_FRONTEND_DIR` 覆盖），已无旧版前端页面。

宿主机、容器或 CI 注入的同名系统变量可以覆盖环境文件中的单个值。文件包含真实密钥时不得
提交到远程仓库，服务器权限建议设置为 `600`，详见 `deploy/README.md`。

将对应可选服务配置为 `none` 或 `local` 时，可以不连接 Redis、Elasticsearch
或 OSS（业务数据库固定为 MySQL）；当前 `dev/uat/prod` 已启用远程服务，因此对应服务器必须能够访问相应私网地址。

## 启动基础服务

```bash
docker compose -f deploy/compose/infrastructure.yml up -d mysql redis
```

配置 `REDIS_URL` 后可立即启用 Redis 适配器。业务主库已切换为 MySQL，历史 SQLite schema（FTS5 与 SQLite 方言）已随迁移移除。

## 健康检查

- `GET /api/health/live`：只检查 API 进程。
- `GET /api/health`：汇总当前启用的基础设施，未配置的可选服务标记为 `disabled`。
- `GET /api/health/ready`：检查所有已配置的外部服务；已配置但不可用时返回 `ready: false`。

## 集中日志

日志由 `app/log_config.py` 在应用启动时通过 `dictConfig` 统一初始化（控制台 +
`logs/app.log`），业务模块统一用 `app.audit.logger.get_logger("模块名")` 获取
logger，输出同时进入数据库 `system_logs` 表。

- 级别：`LOG_LEVEL` 环境变量（默认 `INFO`），修改后重启生效。
- 文件：`logs/app.log` 按天轮转、保留 30 天、单文件上限 100MB；目录可用
  `APP_LOG_DIR` 覆盖（Linux 部署可指向 `/var/log/`）。测试环境（`TESTING=1`）
  只输出控制台，不落文件。
- 请求链路：`RequestContextMiddleware` 为每个 HTTP 请求生成 `request_id`
  并写入 contextvars，请求处理期间所有日志自动携带 `[request_id]`，同时通过
  响应头 `X-Request-ID` 返回（上游传入同名头时透传）。排查问题时可用
  `grep req_xxxx logs/app.log` 检索完整链路。

## 渐进迁移顺序

1. ~~保持 `DB_BACKEND=sqlite`，先接 Redis、OSS 和健康检查。~~（已完成）
2. ~~为现有 SQLite 表建立正式 MySQL/Alembic migration，完成双环境回归后切数据库。~~（已完成）
3. 将耗时的简历解析、Embedding、视频和报告生成逐项改为任务生产者/Worker 消费者。
4. 选择 Elasticsearch 作为唯一向量主库，将现有知识库查询迁移到 `vector` 适配器。
5. 增加任务事实表、文件元数据表、审计和指标采集，再进入生产部署。
