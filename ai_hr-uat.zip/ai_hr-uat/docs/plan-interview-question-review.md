# Plan：面试出题人工审核修改 + 题目导出

> 会议纪要方向：在面试出题环节增加人工审核修改权限，支持相关人员在批量生成或发起面试的流程中自主调整、添加题目。结合实际面试最多可能设置 20 道题。
> 已确认方向：① 新增题目导出 ② 逐人编辑 + 支持统一题集 ③ 生成数可配置 1-20 道 ④ 强制审核后发起。

---

## 一、现状（调研结论）

### 出题链路

```
jd_write ──► interview_gen 阶段（批量出题唯一源头）
              └─ InterviewAgent 为每位入围候选人生成个性化题（写死 3 道深题）
                 结果存 stages.interview_gen.output：
                 {"interviews":[{"candidate_id","candidate_name","questions":[{type,question,duration,follow_up,reason,expected_points,difficulty,...}]}]}
                 │
                 ├─► 在线笔试  /api/written-test/launch：读题目 → 快照存 written_test_sessions.questions
                 └─► 百人面试  /api/mass-interview/launch：优先用预生成题；无则 MassInterviewAgent 模板实时生成（2~5 道）→ 快照存 interview_sessions.questions
```

### 关键文件

| 文件 | 职责 | 现状 |
|---|---|---|
| `app/services.py::_run_interview_gen` | 批量出题后台任务 | 固定 3 道/人 |
| `hr_harness/agents/interview_agent.py` | 高管深题生成 | prompt 写死 3 道 |
| `hr_harness/agents/mass_interview_agent.py` | 视频面试模板出题 | 模板 question_count 2~5 |
| `app/routers/written_test.py::api_launch_written_test` | 笔试发起 | 无审核拦截 |
| `app/routers/mass_interview.py::api_launch_mass_interview` | 视频面试发起 | 无审核拦截 |
| `app/routers/pipelines.py::api_confirm_stage` | 阶段确认 | 仅标记 done，不改题目 |
| `frontend/xiao_mian.html` | 面试工作台 | `editQuestions` 是占位；`exportCsv`/`exportWrittenTestCSV` 导邀请链接 |
| `app/action_handler.py::_handle_export_interviews/_export_exam` | 聊天式导出 | Markdown 已存在，仅聊天触发、无下载端点 |

### 差距清单

| 会议要求 | 现状差距 |
|---|---|
| 人工审核修改权限 | 编辑=占位；无审核状态 |
| 批量生成/发起流程中调整题目 | 发起入口无编辑/拦截环节 |
| 最多 20 道题 | 无上限概念，生成数写死 |
| 题目导出 | Markdown 存在但未接前端；无 Word/下载 |

---

## 二、技术方案

### 2.1 审核状态模型（存于 interview_gen stage output）

```json
{
  "interviews": [
    {
      "candidate_id": "c1",
      "candidate_name": "张三",
      "questions": [ { "type","question","duration","follow_up","reason","expected_points","difficulty", ... } ],
      "review_status": "pending",          // pending | reviewed
      "reviewed_by": "", "reviewed_at": ""
    }
  ],
  "review_status": "pending",              // 全局（全部候选人）
  "reviewed_at": "",
  "max_questions": 20,
  "generated_count": 3                     // 本次批量生成时选定的题数（1-20）
}
```

- 题目 schema 兼容两套：interview_agent 的 `question/duration/...` 与 mass_interview_agent 的 `text/tts_prefix/time_limit_seconds/answer_mode`。编辑器统一读 `question || text`，编辑时保留原对象其余扩展字段不丢。

### 2.2 后端：新模块 + 新路由（低耦合）

**`app/question_review.py`（纯逻辑，不挂路由）**
- `get_review_state(pipeline_id)`：读取/兜底初始化审核数据
- `set_questions(pipeline_id, cid, questions)`：整体替换某人题目（校验 ≤20）
- `add_question / update_question / delete_question`：单题增改删（统一校验上限 20）
- `apply_to_all(pipeline_id, from_cid)`：把某人题集应用到全部候选人（复制 questions，保留各自 candidate_id）
- `mark_reviewed(pipeline_id, cid=None)`：标记审核通过（cid 为空=全部）
- `regenerate_questions(pipeline_id, cid=None, count=None)`：重新生成（复用现有 agent，支持 count 1-20）
- `set_generated_count(pipeline_id, count)`：设置本次生成数量（1-20）
- 所有写操作：`update_stage(pipeline_id,"interview_gen","done",new_output)` 写回源头 + WebSocket 广播

**`app/routers/question_review.py`（REST API）**

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/interview/{pid}/review` | 审核数据全量（题目+状态） |
| PUT | `/api/interview/{pid}/review/questions/{cid}` | 整体替换某人题目 |
| POST | `/api/interview/{pid}/review/questions/{cid}` | 添加一题 |
| PATCH | `/api/interview/{pid}/review/questions/{cid}/{index}` | 修改一题 |
| DELETE | `/api/interview/{pid}/review/questions/{cid}/{index}` | 删除一题 |
| POST | `/api/interview/{pid}/review/apply-to-all/{cid}` | 统一题集（应用到全部） |
| POST | `/api/interview/{pid}/review/confirm` | 标记全部审核通过 |
| POST | `/api/interview/{pid}/review/regenerate` | 重新生成（body: cid?/count? 1-20） |
| POST | `/api/interview/{pid}/review/question-count` | 设置生成数量 1-20 |
| GET | `/api/interview/{pid}/review/export.docx` | 导出 Word（python-docx 已在依赖） |
| GET | `/api/interview/{pid}/review/export.md` | 导出 Markdown（沿用现有格式） |

**发起拦截（强制审核）**
- `written_test.py::api_launch_written_test`：遍历 candidate_ids，任一 `review_status != "reviewed"` → 400「请先在小面完成题目审核」
- `mass_interview.py::api_launch_mass_interview`：同上（含 interview_gen 无数据时的实时生成分支 → 同样要求先出题+审核）

**生成数量可配置**
- `_run_interview_gen(pipeline_id, match_result, jd, role, question_count=3)`：透传数量
- `InterviewAgent`：支持 `question_count` 参数，prompt 输出 N 道（1-20，默认 3）
- `mass_interview_agent`：launch 时 question_count 由审核页设置的 generated_count 决定（仍校验 1-20）

**导出**
- Word：`python-docx`（已在 requirements.txt），按候选人分节（候选人 → Q1..N → 题型/难度/题目/追问/期望要点）
- Markdown：复用现有 `_handle_export_interviews` 格式
- 响应 `FileResponse` 直接下载，文件名 `面试题_{pipeline}_{日期}.docx`

### 2.3 前端（xiao_mian.html 为主）

1. **批量生成弹窗**：题数选择器（3/5/10/20 + 自定义 1-20），调 `question-count` + `batchGenerate`
2. **题目卡片升级为审核卡片**（替换现有 `showInterviewCards` 只读版）：
   - 状态徽章：🟡 待审核 / 🟢 已审核（每人 + 全局）
   - 每题：可编辑字段（题目/题型/时长/难度/追问/期望要点）+ 删除按钮 + 单题重新生成
   - 「➕ 添加题目」（上限 20 提示）
   - 「👥 应用到全部候选人」（统一题集）
   - 「✅ 标记审核通过」/「✅ 全部审核通过」
   - 「📥 导出 Word」「📄 导出 Markdown」
3. **发起拦截**：`launchWrittenTest` / `launchMassInterview` 前调 review 接口校验；未审核 → 提示并跳审核
4. `editQuestions` 占位函数删除，替换为真编辑 UI

### 2.4 兼容性

- 旧 pipeline（interview_gen 无 output / 无 review_status）：`get_review_state` 兜底为 pending，不阻塞查看；发起时要求先出题+审核（与现状「无题不可发起」行为一致，只是多一步审核）
- 已发起 session 的快照不受审核修改影响（预期行为，方案说明里写明）
- 保留 `confirm` 旧接口与 `_handle_export_*` 聊天导出（不破坏现有消息流）

---

## 三、改动范围

| 层 | 文件 | 动作 |
|---|---|---|
| 新模块 | `app/question_review.py` | 新增 |
| 新路由 | `app/routers/question_review.py` | 新增（main.py 挂载） |
| 后端 | `app/services.py` `_run_interview_gen` | 加 question_count 参数 |
| 后端 | `hr_harness/agents/interview_agent.py` | 支持 question_count |
| 后端 | `app/routers/written_test.py` | launch 加审核校验 |
| 后端 | `app/routers/mass_interview.py` | launch 加审核校验 + 用 generated_count |
| 前端 | `frontend/xiao_mian.html` | 审核编辑 UI + 导出按钮 + 数量选择 + 发起拦截 |
| 测试 | `tests/test_question_review.py`（新） | 增删改/上限20/统一题集/审核拦截/导出 |
| 测试 | `tests/test_written_test_scoring.py` 等 | 兼容回归 |

## 四、风险点

1. **题目 schema 不统一**（interview_agent vs mass_interview_agent）：编辑必须保留未知扩展字段，只改已知字段
2. **强制审核改变现有使用习惯**：旧流程「生成→直接发起」变为「生成→审核→发起」，需在产品文案上提示
3. **20 道上限对 LLM 生成质量的影响**：生成 20 道时 prompt 需明确分维度覆盖，防止重复题
4. **并发写**：多人同时编辑同一 pipeline 可能覆盖 stage output —— 读写串行化（asyncio.Lock per pipeline，简单实现）
5. **python-docx 中文字体**：导出 Word 需显式设置中文字体（宋体/微软雅黑），否则乱码

## 六、实施状态（2026-08-04 更新）

✅ **已完成（测试先行，28 个新测试全过，全量回归 367 过 / 1 存量失败 kb_docs / 1 skip）**：

1. ✅ `tests/test_question_review.py`（新，28 用例）：审核读取/兜底、题目增删改、20 道上限、统一题集、标记审核（单人/全部）、重新生成数量控制、发起拦截（笔试/视频面试）、Word/Markdown 导出
2. ✅ `app/question_review.py`（新）：核心逻辑（per-pipeline 锁、写回源头、归一化读取、导出）
3. ✅ `app/routers/question_review.py`（新，12 端点）+ main.py 挂载
4. ✅ 发起拦截：written_test / mass_interview launch（缺失状态视为已审核，显式 pending 才拦截，存量兼容）
5. ✅ 生成数可配置：InterviewAgent / services._run_interview_gen / action_handler / mass launch 均支持 1-20
6. ✅ 前端 xiao_mian.html：审核编辑面板（逐人编辑/增删/重生成/应用到全部/标记审核/题数设置/导出按钮）、批量生成题数选择、发起前审核校验、占位 editQuestions 替换
7. ✅ conftest.py 补跑 `_migrate()`（测试内存库与生产 schema 一致）

**已知遗留（非本次范围）**：
- `tests/test_xiao_hai_routes.py` 2 用例失败：工作区 `app/routers/xiao_hai.py`（之前会话改动）与测试引用的函数名不一致（`call_nn147_generate` 不存在）
- `tests/test_kb_docs.py` 排序用例：存量失败
- `test_api_comprehensive.py`：黑盒集成测试（需真实服务），pytest 默认忽略

**未做（如需后续）**：
- 已发起 session 的题目同步修改（当前快照不变，方案 A）
- Excel 导出（需加 openpyxl 依赖）
- 单题级重新生成（当前为整人重新生成）

## 五、实施顺序（测试先行）

1. `tests/test_question_review.py`：审核 CRUD、上限校验、统一题集、mark_reviewed、发起拦截、导出文件存在性
2. `app/question_review.py` + `app/routers/question_review.py` + main.py 挂载 → 跑测试
3. 发起拦截（written_test / mass_interview）→ 跑测试
4. question_count 支持（services / interview_agent / mass_interview launch）→ 跑测试
5. 前端 xiao_mian.html 审核 UI + 导出 + 数量选择 + 拦截 → 手工/Playwright 验证
6. 回归测试 + 提交
