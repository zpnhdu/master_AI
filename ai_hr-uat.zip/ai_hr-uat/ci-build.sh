#!/usr/bin/env bash
# ci-build.sh — 云效 Flow 流水线专用，构建并推送生产 API 和 React 镜像到 ACR
set -euo pipefail

# ── 云效流水线环境变量 ──
# ACR_REGISTRY       = <实例名>-registry.cn-shanghai.cr.aliyuncs.com
# ACR_NAMESPACE      = ACR 命名空间
# APP_NAME           = 应用名（如 ai-hr、ai-hr-gq），必填；仓库名自动派生为 ${APP_NAME}-api 和 ${APP_NAME}-frontend
# ACR_USERNAME       = ACR 用户名
# ACR_PASSWORD       = ACR 密码
# DEPLOY_ENV         = 环境标识（dev/uat/prod），必填；用于自动拼 tag
# IMAGE_TAG          = 可选；手动指定完整 tag 时覆盖自动生成（非 latest 且合法）
# API_PORT           = 后端端口，默认 8888
# FRONTEND_PORT      = 前端端口，默认 80

ACR_REGISTRY="${ACR_REGISTRY:?ACR_REGISTRY must be set}"
ACR_NAMESPACE="${ACR_NAMESPACE:?ACR_NAMESPACE must be set}"
ACR_USERNAME="${ACR_USERNAME:?ACR_USERNAME must be set}"
ACR_PASSWORD="${ACR_PASSWORD:?ACR_PASSWORD must be set}"
APP_NAME="${APP_NAME:?APP_NAME must be set}"

REGISTRY="${ACR_REGISTRY%/}/${ACR_NAMESPACE#/}"
API_REPO="${APP_NAME}-api"
FRONTEND_REPO="${APP_NAME}-frontend"

# TAG 生成：优先用 IMAGE_TAG 手动指定；否则 环境-commit短SHA（如 dev-8f3a2c1e）
if [[ -n "${IMAGE_TAG:-}" ]]; then
    TAG="$IMAGE_TAG"
else
    DEPLOY_ENV="${1:?用法: bash $0 <env>  (dev/uat/prod)}"
    case "$DEPLOY_ENV" in
        dev|uat|prod) ;;
        *) echo "❌ 不支持的环境: ${DEPLOY_ENV}（只支持 dev/uat/prod）" >&2; exit 1 ;;
    esac
    COMMIT_SHA="${GIT_COMMIT_SHA:-${CI_COMMIT_SHA:-$(git rev-parse HEAD)}}"
    SHORT_SHA="${COMMIT_SHA:0:8}"
    TAG="${DEPLOY_ENV}-${SHORT_SHA}"
fi

if [[ "$TAG" == "latest" || ! "$TAG" =~ ^[a-zA-Z0-9_.-]+$ ]]; then
    echo "IMAGE_TAG 必须是合法且非 latest 的镜像标签：${TAG}" >&2
    exit 1
fi

BACKEND_IMAGE="${REGISTRY}/${API_REPO}:${TAG}"
FRONTEND_IMAGE="${REGISTRY}/${FRONTEND_REPO}:${TAG}"

echo "=== 配置 Docker 镜像加速器（国内拉取 Docker Hub 基础镜像）==="
mkdir -p /etc/docker
cat > /etc/docker/daemon.json << 'MIRROR_EOF'
{
  "registry-mirrors": [
    "https://docker.m.daocloud.io",
    "https://dockerhub.icu",
    "https://docker.rainbond.cc",
    "https://hub.rat.dev"
  ]
}
MIRROR_EOF
if command -v systemctl &>/dev/null; then
    systemctl restart docker >/dev/null 2>&1 || true
elif command -v service &>/dev/null; then
    service docker restart >/dev/null 2>&1 || true
fi
sleep 3

echo "=== 登录 ACR：${ACR_REGISTRY} ==="
printf '%s' "$ACR_PASSWORD" | docker login \
    --username="$ACR_USERNAME" \
    --password-stdin \
    "$ACR_REGISTRY"

export DOCKER_BUILDKIT=1
export BUILDKIT_PROGRESS=plain

# ── 初始化基础镜像到 ACR（首次构建时自动从 daocloud 拉取并推送，后续直接复用）──
BASE_REPO="${REGISTRY}/base"
echo "=== 检查/初始化 ACR 基础镜像 ==="
for PAIR in "python:3.11-slim:python-3.11-slim" "node:22-alpine:node-22-alpine" "nginx:1.27-alpine:nginx-1.27-alpine"; do
    IFS=: read -r _NAME _TAG ACR_TAG <<< "$PAIR"
    SRC_IMAGE="docker.m.daocloud.io/library/${_NAME}:${_TAG}"
    ACR_IMAGE="${BASE_REPO}:${ACR_TAG}"
    if docker pull "$ACR_IMAGE" 2>/dev/null; then
        echo "  ✓ ${ACR_TAG} 已存在于 ACR"
    else
        echo "  → ${ACR_TAG} 不存在，从 daocloud 拉取并推送到 ACR..."
        docker pull "$SRC_IMAGE"
        docker tag "$SRC_IMAGE" "$ACR_IMAGE"
        docker push "$ACR_IMAGE"
        echo "  ✓ ${ACR_TAG} 已推送到 ACR"
    fi
done

# ── 构建 API 依赖镜像（预装 apt 系统包 + pip 依赖，避免每次 CI 重复安装）──
API_DEPS_IMAGE="${BASE_REPO}:api-deps"
echo "=== 检查/构建 API 依赖镜像: ${API_DEPS_IMAGE} ==="
# 用 requirements.txt 的 md5 做版本标记，依赖变了才重建
REQS_HASH=$(md5sum requirements.txt | cut -d' ' -f1)
API_DEPS_TAG="api-deps-${REQS_HASH:0:12}"
API_DEPS_VERSIONED="${BASE_REPO}:${API_DEPS_TAG}"
if docker pull "$API_DEPS_VERSIONED" 2>/dev/null; then
    echo "  ✓ ${API_DEPS_TAG} 已存在（requirements.txt 未变）"
    # retag 为固定名 api-deps 供 Dockerfile 引用
    docker tag "$API_DEPS_VERSIONED" "$API_DEPS_IMAGE"
else
    echo "  → 依赖有变更，构建 api-deps 镜像..."
    cat <<'DEPS_EOF' | docker build -f - -t "$API_DEPS_IMAGE" -t "$API_DEPS_VERSIONED" .
FROM shanghai-registry.cn-hangzhou.cr.aliyuncs.com/dev/base:python-3.11-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PIP_NO_CACHE_DIR=1
RUN sed -i 's|deb.debian.org|mirrors.aliyun.com|g; s|security.debian.org|mirrors.aliyun.com|g' /etc/apt/sources.list.d/debian.sources 2>/dev/null \
    || sed -i 's|deb.debian.org|mirrors.aliyun.com|g; s|security.debian.org|mirrors.aliyun.com|g' /etc/apt/sources.list 2>/dev/null \
    || true; \
    apt-get update \
    && apt-get install -y --no-install-recommends ffmpeg curl tesseract-ocr tesseract-ocr-chi-sim \
    && rm -rf /var/lib/apt/lists/*
COPY requirements.txt ./
RUN pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/ \
    && pip install -r requirements.txt
DEPS_EOF
    docker push "$API_DEPS_IMAGE"
    docker push "$API_DEPS_VERSIONED"
    echo "  ✓ ${API_DEPS_IMAGE} 已推送"
fi

echo "=== 构建 API 镜像：${BACKEND_IMAGE} ==="
docker pull "${REGISTRY}/${API_REPO}:build-cache" 2>/dev/null || true
docker build \
    --build-arg API_PORT=${API_PORT:-8888} \
    --cache-from="${REGISTRY}/${API_REPO}:build-cache" \
    -f deploy/docker/api.Dockerfile \
    -t "$BACKEND_IMAGE" \
    .
docker tag "$BACKEND_IMAGE" "${REGISTRY}/${API_REPO}:build-cache"
docker push "${REGISTRY}/${API_REPO}:build-cache"

echo "=== 构建 React 镜像：${FRONTEND_IMAGE} ==="
docker pull "${REGISTRY}/${FRONTEND_REPO}:build-cache" 2>/dev/null || true
docker build \
    --build-arg FRONTEND_PORT=${FRONTEND_PORT:-80} \
    --cache-from="${REGISTRY}/${FRONTEND_REPO}:build-cache" \
    -f deploy/docker/frontend.Dockerfile \
    -t "$FRONTEND_IMAGE" \
    .
docker tag "$FRONTEND_IMAGE" "${REGISTRY}/${FRONTEND_REPO}:build-cache"
docker push "${REGISTRY}/${FRONTEND_REPO}:build-cache"

echo "=== 推送正式镜像 ==="
docker push "$BACKEND_IMAGE"
docker push "$FRONTEND_IMAGE"

echo "=== 构建推送完成 ==="
echo "BACKEND_IMAGE=${BACKEND_IMAGE}"
echo "FRONTEND_IMAGE=${FRONTEND_IMAGE}"