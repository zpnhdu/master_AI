"""Hermes网关客户端 - 真实LLM调用实现"""

from __future__ import annotations

import asyncio
import inspect
import json
import os
import re
import time
from collections.abc import AsyncGenerator
from typing import Optional

import requests

from app.audit.logger import get_logger
from app.audit.token_tracker import record_usage
from app.environment import load_environment
from app.infrastructure.timeout_policy import TimeoutDeadline
from hermes_wrapper.base_client import BaseLLMClient
from hermes_wrapper.models import LLMRequest, LLMResponse, StreamChunk
from hermes_wrapper.session_pool import SessionPool

logger = get_logger("hermes")

DEFAULT_WORKSPACE_API_BASE = "https://ws-dax6bh2yg3o6dbkb.cn-beijing.maas.aliyuncs.com/compatible-mode/v1"
DEFAULT_DASHSCOPE_API_BASE = "https://dashscope.aliyuncs.com/compatible-mode/v1"

# 模型映射：复杂度 → 模型名
MODELS = {
    "flash": "qwen3.6-flash",  # 极速轻量：意图识别/简单分类/短文本生成
    "plus": "qwen-plus",  # 均衡质量：JD生成/画像/编辑/创意生成
    "max": "qwen-plus",  # 深度推理：匹配评分/面试策略/决策报告（复用plus，速度更快）
    "vision": "qwen-vl-max",  # 视觉多模态（图片/视频帧分析）
}

# BaseAgent 的通用调用没有额外传递观测字段；按既有角色注册关系补齐默认上下文。
_BASE_AGENT_OBSERVABILITY = {
    "JDAgent": ("xiao_wen", "jd_write"),
    "ProfileAgent": ("xiao_wen", "profile_build"),
    "PosterAgent": ("xiao_hai", "poster_gen"),
    "RPAAgent": ("xiao_xun", "publish"),
    "CrawlAgent": ("xiao_xun", "crawl"),
    "MatchAgent": ("xiao_shai", "match"),
    "InterviewAgent": ("xiao_mian", "interview_gen"),
    "VideoAgent": ("xiao_mian", "video_assess"),
    "ReportAgent": ("xiao_ping", "report"),
}


class HermesClient(BaseLLMClient):
    """
    Hermes网关统一客户端
    底层对接 http://token.shanghai.work/v1 (OpenAI兼容API)
    上层业务代码只认 BaseLLMClient 接口，不关心底层实现
    """

    def __init__(self):
        load_environment()
        self.api_base = os.getenv("OPENAI_API_BASE", DEFAULT_WORKSPACE_API_BASE)
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        self.dashscope_api_base = os.getenv("DASHSCOPE_BASE_URL") or os.getenv("DASHSCOPE_API_BASE", "")
        self.dashscope_api_key = os.getenv("DASHSCOPE_API_KEY", "")
        self.session_pool = SessionPool()

    @staticmethod
    def _normalize_api_base(base: str) -> str:
        return (base or "").strip().rstrip("/")

    @staticmethod
    def _is_workspace_access_denied(status_code: int, text: str) -> bool:
        if status_code != 403:
            return False
        lowered = (text or "").lower()
        return "workspace endpoint access denied" in lowered or "access_denied" in lowered

    def _gateway_candidates(self) -> list[tuple[str, str, str]]:
        primary_base = self._normalize_api_base(self.api_base or DEFAULT_WORKSPACE_API_BASE)
        primary_key = self.api_key.strip()
        dash_base = self._normalize_api_base(self.dashscope_api_base or DEFAULT_DASHSCOPE_API_BASE)
        dash_key = self.dashscope_api_key.strip() or primary_key

        candidates: list[tuple[str, str, str]] = []
        if primary_key:
            candidates.append(("OpenAI-compatible", primary_base, primary_key))
        if dash_key and dash_base != primary_base:
            candidates.append(("DashScope-compatible", dash_base, dash_key))
        if not candidates:
            candidates.append(("OpenAI-compatible", primary_base, primary_key))
        return candidates

    def _resolve_model(self, req: LLMRequest) -> str:
        """解析模型：显式模型优先，文本请求其次使用环境配置。"""
        if req.model:
            return req.model
        configured_model = os.getenv("OPENAI_MODEL", "").strip()
        if configured_model and req.complexity != "vision":
            return configured_model
        return MODELS.get(req.complexity, MODELS["plus"])

    def _build_messages(self, req: LLMRequest) -> list:
        """构建消息列表，支持 profile 隔离上下文和多模态内容"""
        messages = []
        if req.system:
            messages.append({"role": "system", "content": req.system})

        # 多模态消息：直接使用 content_parts（image_url + text）
        if req.content_parts:
            messages.append({"role": "user", "content": req.content_parts})
            return messages

        # 画像范围的历史记录：注入该画像最近的对话
        if req.profile_id:
            from hermes_wrapper.profile import get_profile_manager

            pm = get_profile_manager()
            profile = pm.get(req.profile_id)
            if profile:
                for msg in profile.get_history(last_n=6):
                    messages.append({"role": msg["role"], "content": msg["content"]})
        elif req.session_id:
            # 兼容旧逻辑：使用全局会话池
            session = self.session_pool.get_or_create(req.session_id)
            for msg in session.get_messages()[-6:]:
                messages.append({"role": msg["role"], "content": msg["content"]})

        messages.append({"role": "user", "content": req.prompt})
        return messages

    @staticmethod
    def _agent_observability(candidate) -> tuple[str, str] | None:
        if candidate is None:
            return None
        for cls in type(candidate).__mro__:
            metadata = _BASE_AGENT_OBSERVABILITY.get(cls.__name__)
            if metadata:
                return metadata
        return None

    def _resolve_observability(
        self,
        req: LLMRequest,
        agent: str | None,
        operation: str | None,
        pipeline_id: str | None,
    ) -> tuple[str | None, str | None, str]:
        """补齐 BaseAgent 未显式透传的角色、阶段和流水线信息。"""
        inferred_agent = None
        inferred_operation = None
        inferred_pipeline_id = None
        frame = inspect.currentframe()
        try:
            frame = frame.f_back if frame else None
            while frame:
                locals_ = frame.f_locals
                stage = locals_.get("stage")
                stage_id = getattr(stage, "stage_id", None)
                if stage_id and inferred_operation is None:
                    inferred_operation = stage_id

                input_value = locals_.get("input")
                input_pipeline_id = getattr(input_value, "pipeline_id", None)
                if input_pipeline_id and inferred_pipeline_id is None:
                    inferred_pipeline_id = input_pipeline_id

                local_pipeline_id = locals_.get("pipeline_id")
                if local_pipeline_id and inferred_pipeline_id is None:
                    inferred_pipeline_id = local_pipeline_id

                metadata = self._agent_observability(locals_.get("self"))
                if metadata:
                    if inferred_agent is None:
                        inferred_agent = metadata[0]
                    mapped_operation = metadata[1]
                    if inferred_operation is None:
                        inferred_operation = mapped_operation
                frame = frame.f_back
        finally:
            del frame

        return (
            agent or inferred_agent,
            operation or inferred_operation,
            pipeline_id or req.profile_id or inferred_pipeline_id or "",
        )

    @staticmethod
    def _retry_count_from_prompt(prompt: str) -> int:
        """识别 BaseAgent 校验重试追加的修正标记，不改变请求内容。"""
        return str(prompt or "").count("【修正要求】")

    @staticmethod
    def _observability_extra(
        model: str,
        usage: dict,
        latency_ms: int | None,
        agent: str | None,
        operation: str | None,
        pipeline_id: str,
        retry_count: int,
    ) -> dict:
        prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
        completion_tokens = int(usage.get("completion_tokens", 0) or 0)
        return {
            "source": "Hermes",
            "agent": agent or "",
            "operation": operation or "",
            "pipeline_id": pipeline_id,
            "model": model,
            "latency_ms": latency_ms or 0,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": int(usage.get("total_tokens", prompt_tokens + completion_tokens) or 0),
            "retry_count": retry_count,
        }

    @staticmethod
    def _apply_deadline_timeout(req: LLMRequest, deadline: TimeoutDeadline | None) -> None:
        if deadline is None:
            return
        req.timeout = min(float(req.timeout), deadline.require_remaining())

    def _call_sync(
        self,
        model: str,
        messages: list,
        temperature: float,
        timeout: int,
        max_tokens: int | None = None,
        response_format: Optional[dict] = None,
    ) -> dict:
        """同步HTTP调用（在to_thread中执行）"""
        return self._call_sync_with_fallback(model, messages, temperature, timeout, max_tokens, response_format)

    def _call_sync_with_fallback(
        self,
        model: str,
        messages: list,
        temperature: float,
        timeout: int,
        max_tokens: int | None = None,
        response_format: Optional[dict] = None,
        enable_thinking: Optional[bool] = None,
    ) -> dict:
        """Sync HTTP call with gateway fallback when the workspace endpoint is denied."""
        start_time = time.time()
        payload = {
            "model": model,
            "messages": messages,
        }
        if temperature != 1.0:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if enable_thinking is not None:
            payload["enable_thinking"] = enable_thinking
        if response_format:
            payload["response_format"] = response_format

        candidates = self._gateway_candidates()
        last_result: dict = {"content": "", "usage": {}, "error": "", "latency_ms": 0}
        for index, (label, api_base, api_key) in enumerate(candidates):
            try:
                resp = requests.post(
                    f"{api_base}/chat/completions",
                    headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                    json=payload,
                    timeout=timeout,
                )

                latency_ms = int((time.time() - start_time) * 1000)
                if resp.status_code == 200:
                    data = resp.json()
                    choice = data["choices"][0]
                    content = choice["message"]["content"]
                    finish_reason = choice.get("finish_reason", "")
                    usage_raw = data.get("usage", {})
                    usage = {k: v for k, v in usage_raw.items() if isinstance(v, (int, float))}
                    logger.info(
                        f"{model}: {content[:80]}... (finish_reason={finish_reason})",
                        extra={"source": "Hermes"},
                    )
                    return {
                        "content": content,
                        "usage": usage,
                        "error": "",
                        "latency_ms": latency_ms,
                        "finish_reason": finish_reason,
                    }

                error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                last_result = {"content": "", "usage": {}, "error": error, "latency_ms": latency_ms}
                if self._is_workspace_access_denied(resp.status_code, resp.text) and index < len(candidates) - 1:
                    logger.warning(
                        f"{model}: {label} rejected the request, retrying with fallback gateway",
                        extra={"source": "Hermes"},
                    )
                    continue
                logger.error(f"{model}: {error}", extra={"source": "Hermes"})
                return last_result
            except Exception as e:
                latency_ms = int((time.time() - start_time) * 1000)
                error = str(e)
                last_result = {"content": "", "usage": {}, "error": error, "latency_ms": latency_ms}
                logger.error(f"{model}: {error}", extra={"source": "Hermes"})
                return last_result

        return last_result

    async def chat(
        self,
        req: LLMRequest,
        *,
        agent: str = None,
        operation: str = None,
        pipeline_id: str = None,
        json_mode: bool = False,
        deadline: TimeoutDeadline | None = None,
        retry_count: int = 0,
    ) -> LLMResponse:
        """一次性完整返回"""
        self._apply_deadline_timeout(req, deadline)
        agent, operation, pipeline_id = self._resolve_observability(req, agent, operation, pipeline_id)
        retry_count = max(retry_count, self._retry_count_from_prompt(req.prompt))
        model = self._resolve_model(req)
        messages = self._build_messages(req)

        response_format = {"type": "json_object"} if json_mode else None
        result = await asyncio.to_thread(
            self._call_sync_with_fallback,
            model,
            messages,
            req.temperature,
            req.timeout,
            req.max_tokens,
            response_format,
            req.enable_thinking,
        )

        # 记录到会话池（profile 优先，否则 legacy session）
        if req.profile_id:
            from hermes_wrapper.profile import get_profile_manager

            pm = get_profile_manager()
            profile = pm.get(req.profile_id)
            if profile:
                profile.add_message("user", req.prompt)
                if result["content"]:
                    profile.add_message("assistant", result["content"])
        elif req.session_id:
            session = self.session_pool.get_or_create(req.session_id)
            session.add_message("user", req.prompt)
            if result["content"]:
                session.add_message("assistant", result["content"])

        # 网关未返回 usage 时也记一条（0 token），保证调用量统计完整。
        usage = result.get("usage") or {}
        await asyncio.to_thread(
            record_usage,
            model=model,
            token_usage=usage,
            agent=agent,
            operation=operation,
            pipeline_id=pipeline_id,
            latency_ms=result.get("latency_ms"),
            success=not bool(result.get("error")),
        )

        logger.info(
            "LLM call completed",
            extra=self._observability_extra(
                model,
                usage,
                result.get("latency_ms"),
                agent,
                operation,
                pipeline_id,
                retry_count,
            ),
        )

        # 全链路 trace 环节（无活跃 trace 上下文时静默跳过）
        try:
            from app.audit.llm_trace import record_trace_step

            await asyncio.to_thread(
                record_trace_step,
                operation or "llm_call",
                model=model,
                status=("error: " + str(result.get("error"))[:200] if result.get("error") else "ok"),
                latency_ms=result.get("latency_ms") or 0,
                detail=(
                    f"agent={agent or ''};pipeline_id={pipeline_id};retry_count={retry_count};"
                    f"total_tokens={usage.get('total_tokens', 0)}"
                ),
            )
        except Exception:
            pass

        return LLMResponse(
            content=result["content"],
            model=model,
            token_usage=result["usage"],
            session_id=req.session_id,
            error=result["error"],
        )

    async def stream_chat(self, req: LLMRequest) -> AsyncGenerator[StreamChunk, None]:
        """流式输出（预留接口，当前用同步模拟）"""
        # TODO: 实现真正的SSE流式
        # 当前先用同步调用模拟，后续接入stream=true
        resp = await self.chat(req)
        if resp.error:
            yield StreamChunk(text=f"[Error: {resp.error}]", finish=True)
            return

        # 模拟分片输出
        chunk_size = 50
        content = resp.content
        for i in range(0, len(content), chunk_size):
            chunk = content[i : i + chunk_size]
            is_last = i + chunk_size >= len(content)
            yield StreamChunk(text=chunk, finish=is_last)
            if not is_last:
                await asyncio.sleep(0.05)

    async def chat_json(
        self,
        req: LLMRequest,
        *,
        agent: str = None,
        operation: str = None,
        pipeline_id: str = None,
        json_mode: bool = False,
        deadline: TimeoutDeadline | None = None,
        retry_count: int = 0,
    ) -> dict:
        """调用LLM并解析JSON响应，失败时用严格格式提示重试一次。"""
        agent, operation, pipeline_id = self._resolve_observability(req, agent, operation, pipeline_id)
        retry_count = max(retry_count, self._retry_count_from_prompt(req.prompt))
        resp = await self.chat(
            req,
            agent=agent,
            operation=operation,
            pipeline_id=pipeline_id,
            json_mode=json_mode,
            deadline=deadline,
            retry_count=retry_count,
        )

        if resp.error:
            return {"error": resp.error, "parse_error": True}

        parsed = self._parse_json_content(resp.content)
        logger.info(
            f"JSON length={len(resp.content)}",
            extra={
                "source": "Hermes",
                "agent": agent or "",
                "operation": operation or "",
                "pipeline_id": pipeline_id,
                "retry_count": retry_count,
            },
        )
        if parsed is not None:
            return parsed

        # 模型偶发在 JSON 结尾处截断；用更明确的修复要求重试一次。
        format_requirement = "完整 JSON 对象，必须以 { 开始、以 } 结束" if json_mode else "完整合法 JSON（对象或数组）"
        retry_req = req.model_copy(
            update={
                "prompt": (
                    f"{req.prompt}\n\n"
                    f"【格式修复】上一次输出不是完整的合法 JSON。请重新输出{format_requirement}，"
                    "不要 Markdown、解释文字或省略任何字段。"
                )
            }
        )
        retry_resp = await self.chat(
            retry_req,
            agent=agent,
            operation=operation,
            pipeline_id=pipeline_id,
            json_mode=json_mode,
            deadline=deadline,
            retry_count=retry_count + 1,
        )
        if retry_resp.error:
            return {"error": retry_resp.error, "parse_error": True}

        parsed = self._parse_json_content(retry_resp.content)
        logger.info(
            f"JSON retry length={len(retry_resp.content)}",
            extra={
                "source": "Hermes",
                "agent": agent or "",
                "operation": operation or "",
                "pipeline_id": pipeline_id,
                "retry_count": retry_count + 1,
            },
        )
        if parsed is not None:
            return parsed
        return {"raw": retry_resp.content, "parse_error": True}

    @staticmethod
    def _parse_json_content(result: str):
        """解析模型返回的 JSON，兼容代码块和前后说明文字。"""
        if not isinstance(result, str):
            return None

        # 第一层：直接解析
        try:
            return json.loads(result)
        except (json.JSONDecodeError, TypeError):
            pass

        # 第二层：去除 Markdown 代码块
        cleaned = result
        if "```json" in cleaned:
            cleaned = cleaned.split("```json")[1].split("```")[0]
        elif "```" in cleaned:
            cleaned = cleaned.split("```")[1].split("```")[0]
        try:
            return json.loads(cleaned.strip())
        except (json.JSONDecodeError, TypeError):
            pass

        # 第三层：正则提取（数组优先，因为匹配评分要求输出数组）
        for pattern in [r"\[[\s\S]*\]", r"\{[\s\S]*\}"]:
            match = re.search(pattern, result)
            if match:
                try:
                    return json.loads(match.group())
                except (json.JSONDecodeError, TypeError):
                    continue

        return None


# 全局单例
_client: HermesClient = None


def get_client() -> HermesClient:
    """获取全局HermesClient单例"""
    global _client
    if _client is None:
        _client = HermesClient()
    return _client
