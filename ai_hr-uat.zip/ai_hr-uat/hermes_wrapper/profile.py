"""Profile Manager — isolated context per recruitment pipeline.

Each pipeline (job position) gets its own profile with:
- Isolated session history (no cross-pipeline context leakage)
- Dedicated knowledge base (can add pipeline-specific docs)
- Scoped memory (already handled by MemorySystem via pipeline_id)

Inspired by xiaohai_v2's per-conversation Hermes profile isolation.
"""

import json
import logging
from pathlib import Path

from knowledge.base import KnowledgeBase
from typing import Optional

logger = logging.getLogger("hermes.profile")

# 画像存储根目录
_PROFILES_DIR = Path(__file__).parent.parent / "data" / "profiles"


class Profile:
    """Isolated context for a single recruitment pipeline."""

    def __init__(self, profile_id: str, role: str = "", hints: str = ""):
        self.profile_id = profile_id
        self.role = role
        self.hints = hints
        self.dir = _PROFILES_DIR / profile_id
        self.dir.mkdir(parents=True, exist_ok=True)

        # 隔离的会话历史
        self.history: list[dict] = []

        # 隔离的知识库（从种子知识开始，可继续扩展）
        self.kb = KnowledgeBase()

        # 元数据
        self.meta_path = self.dir / "meta.json"
        self._load_meta()

    def _load_meta(self):
        """Load profile metadata from disk."""
        if self.meta_path.exists():
            try:
                data = json.loads(self.meta_path.read_text())
                self.role = data.get("role", self.role)
                self.hints = data.get("hints", self.hints)
            except Exception:
                pass

    def save_meta(self):
        """Persist profile metadata."""
        data = {
            "profile_id": self.profile_id,
            "role": self.role,
            "hints": self.hints,
        }
        self.meta_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))

    def add_message(self, role: str, content: str):
        """Add a message to this profile's session history."""
        self.history.append({"role": role, "content": content})

    def get_history(self, last_n: int = 8) -> list[dict]:
        """Get recent session history for LLM context."""
        return self.history[-last_n:] if self.history else []

    def add_knowledge(self, doc_id: str, category: str, title: str, content: str, tags: Optional[list[str]] = None):
        """Add pipeline-specific knowledge to this profile's KB."""
        self.kb.add(doc_id, category, title, content, tags or [])

    def search_knowledge(self, query: str, top_k: int = 3, category: Optional[str] = None) -> list[dict]:
        """Search this profile's knowledge base."""
        return self.kb.search(query, top_k=top_k, category=category)

    def get_context(self, query: str = "") -> str:
        """Build full context string for LLM calls."""
        parts = []

        # 职位信息
        if self.role:
            parts.append(f"招聘岗位: {self.role}")
        if self.hints:
            parts.append(f"补充要求: {self.hints}")

        # 知识上下文
        if query:
            kb_ctx = self.kb.get_context_for_intent("", query)
            if kb_ctx:
                parts.append(kb_ctx)

        # 最近历史摘要
        recent = self.get_history(last_n=4)
        if recent:
            parts.append(f"最近对话: {len(recent)}条")

        return "\n".join(parts)

    def clear_history(self):
        """Clear session history."""
        self.history.clear()

    def to_dict(self) -> dict:
        """Serialize profile state."""
        return {
            "profile_id": self.profile_id,
            "role": self.role,
            "hints": self.hints,
            "history_count": len(self.history),
            "kb_docs": len(self.kb.documents),
        }


class ProfileManager:
    """Manages isolated profiles for concurrent recruitment pipelines."""

    def __init__(self):
        self._profiles: dict[str, Profile] = {}
        _PROFILES_DIR.mkdir(parents=True, exist_ok=True)

    def get_or_create(self, profile_id: str, role: str = "", hints: str = "") -> Profile:
        """Get existing profile or create new one."""
        if profile_id in self._profiles:
            return self._profiles[profile_id]

        profile = Profile(profile_id, role, hints)
        profile.save_meta()
        self._profiles[profile_id] = profile
        logger.info(f"Profile created: {profile_id} (role={role})")
        return profile

    def get(self, profile_id: str) -> Optional[Profile]:
        """Get profile by ID, returns None if not found."""
        return self._profiles.get(profile_id)

    def remove(self, profile_id: str):
        """Remove a profile from memory (keeps disk data)."""
        self._profiles.pop(profile_id, None)

    def list_profiles(self) -> list[dict]:
        """List all active profiles."""
        return [p.to_dict() for p in self._profiles.values()]

    def clear_all(self):
        """Clear all profiles from memory."""
        self._profiles.clear()


# 全局单例
_manager: Optional[ProfileManager] = None


def get_profile_manager() -> ProfileManager:
    """Get global ProfileManager singleton."""
    global _manager
    if _manager is None:
        _manager = ProfileManager()
    return _manager
