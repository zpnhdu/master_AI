"""统一请求/响应数据模型"""

from typing import Any, Optional

from pydantic import BaseModel


class LLMRequest(BaseModel):
    """统一LLM请求体"""

    session_id: str = ""
    profile_id: str = ""  # 流水线范围的画像，用于隔离上下文
    prompt: str = ""
    system: str = ""
    model: str = ""
    complexity: str = "plus"  # 复杂度：flash / plus / max
    stream: bool = False
    temperature: float = 0.7
    timeout: int = 120
    max_tokens: Optional[int] = None
    content_parts: Optional[list[dict[str, Any]]] = None  # 多模态消息（image_url + text）
    # 推理模型（如 qwen3.6-flash）默认会先产出 reasoning_content，简单分类/路由等
    # 场景无需深度推理，显式关闭可把首字延迟从数秒降到亚秒级。None 表示不发送该字段，
    # 沿用网关默认行为，避免影响其它调用方。
    enable_thinking: Optional[bool] = None


class LLMResponse(BaseModel):
    """统一LLM响应体"""

    content: str
    model: str = ""
    token_usage: dict[str, Any] = {}
    session_id: str = ""
    error: str = ""


class StreamChunk(BaseModel):
    """流式输出分片"""

    text: str
    finish: bool = False
