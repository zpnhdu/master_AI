"""LLM抽象基类 - 定义统一接口"""

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator

from hermes_wrapper.models import LLMRequest, LLMResponse, StreamChunk


class BaseLLMClient(ABC):
    """所有LLM客户端的抽象基类"""

    @abstractmethod
    async def chat(self, req: LLMRequest) -> LLMResponse:
        """一次性完整返回"""
        ...

    @abstractmethod
    async def stream_chat(self, req: LLMRequest) -> AsyncGenerator[StreamChunk, None]:
        """流式输出"""
        ...

    @abstractmethod
    async def chat_json(self, req: LLMRequest) -> dict:
        """调用LLM并解析JSON响应"""
        ...
