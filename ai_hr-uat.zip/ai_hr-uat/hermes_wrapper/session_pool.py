"""会话池管理 - 复用会话上下文"""


class Session:
    """单个会话，维护消息历史"""

    def __init__(self, sid: str):
        self.id = sid
        self.history: list[dict] = []

    def add_message(self, role: str, content: str):
        self.history.append({"role": role, "content": content})

    def get_messages(self) -> list[dict]:
        return self.history.copy()

    def clear(self):
        self.history.clear()


class SessionPool:
    """会话池 - 管理多个会话实例"""

    def __init__(self):
        self._pool: dict[str, Session] = {}

    def get_or_create(self, sid: str) -> Session:
        if sid not in self._pool:
            self._pool[sid] = Session(sid)
        return self._pool[sid]

    def recycle(self, sid: str):
        if sid in self._pool:
            del self._pool[sid]

    def clear_all(self):
        self._pool.clear()
