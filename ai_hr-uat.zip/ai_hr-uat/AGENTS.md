## Skill routing

When the user's request matches an available skill, invoke it via the Skill tool. When in doubt, invoke the skill.

Key routing rules (the 8 skills under skills/):
- JD writing → invoke /jd-write
- Candidate matching/scoring → invoke /match-candidates
- Interview question generation → invoke /interview-gen
- Video interview analysis → invoke /video-assess
- Recruitment daily/weekly/overview reports → invoke /recruitment-reports
- Hiring decision report → invoke /hiring-report
- Resume crawling/import → invoke /crawl-resumes
- Multi-channel JD publishing → invoke /rpa-publish

## Git 协作铁律

本仓库为多人并行工作区，**每次 git 写操作前必读**：`docs/collaboration-parallel.md`。

核心四条：
1. 先识别环境：`git worktree list` / `git reflog -5`，共享 worktree = 高风险模式
2. 小步提交不攒包；`git add <具体文件>`，**禁止 `git add -A`**
3. status 连续两次读取不一致 = 有人在并行操作，立即停止 git 写操作
4. 诊断用 `git reflog`，确认改动在不在仓库用 `git show HEAD:<file>`

提交规范自查：subject ≤72 字符、小写开头、scope 取枚举、body 行 ≤100、新 import 同步 requirements.txt（pre-commit 会卡）。
