"""DAG Engine — lightweight workflow executor for agent pipeline stages.
V1 supports: linear execution, conditional branching (on_failure),
exponential backoff retry, timeout, human approval gates.
V2 (future): parallel stage groups.
"""

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, Optional

from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline
from app.xiao_wen_context import XIAO_WEN_MODEL, XIAO_WEN_STAGE_IDS
from hr_harness.tool_protocol import AgentStatus, ToolConfig, ToolInput, ToolOutput

logger = logging.getLogger("dag_engine")


@dataclass
class StageDefinition:
    """A pipeline stage — one agent with its config"""

    stage_id: str
    agent: Any
    config: ToolConfig
    on_failure: str = "halt"


@dataclass
class StageResult:
    """Result of executing one stage"""

    stage_id: str
    status: AgentStatus
    output: ToolOutput
    retries: int = 0
    duration_ms: int = 0


class DAGEngine:
    """Lightweight DAG executor for agent pipeline stages."""

    def __init__(self, on_stage_update: Optional[callable] = None):
        self.on_stage_update = on_stage_update
        self._accumulated_context: dict[str, Any] = {}

    async def execute(
        self,
        stages: list[StageDefinition],
        pipeline_id: str,
        candidate_id: Optional[str] = None,
        initial_params: Optional[dict[str, Any]] = None,
    ) -> list[StageResult]:
        """Execute stages sequentially. Returns results list."""
        results: list[StageResult] = []
        self._accumulated_context = {}

        for stage in stages:
            if not stage.config.enabled:
                continue

            result = await self._execute_stage(stage, pipeline_id, candidate_id, initial_params or {})
            results.append(result)

            if result.status == AgentStatus.SUCCESS:
                self._accumulated_context[stage.stage_id] = result.output.data
            elif result.status == AgentStatus.FAILED:
                if stage.on_failure == "halt":
                    break
            elif result.status == AgentStatus.NEEDS_HUMAN:
                break

        return results

    async def _execute_stage(
        self,
        stage: StageDefinition,
        pipeline_id: str,
        candidate_id: Optional[str],
        params: dict[str, Any],
    ) -> StageResult:
        """Execute one stage with retry and timeout."""
        start = time.time()
        last_output = None
        retries = 0
        deadline = TimeoutDeadline(stage.config.timeout, agent_id=stage.config.agent_id)
        effective_model = XIAO_WEN_MODEL if stage.stage_id in XIAO_WEN_STAGE_IDS else stage.config.model

        for attempt in range(stage.config.retry_count + 1):
            try:
                stage_params = dict(params)
                stage_params.setdefault("deadline", deadline)
                stage_params["agent_id"] = stage.config.agent_id
                stage_params["model"] = stage.config.model
                stage_params["complexity"] = stage.config.complexity
                stage_params["temperature"] = stage.config.temperature
                stage_params["llm_max_retries"] = (
                    1 if stage.stage_id in {"jd_write", "profile_build"} else min(stage.config.retry_count, 1)
                )
                ti = ToolInput(
                    pipeline_id=pipeline_id,
                    candidate_id=candidate_id,
                    params=stage_params,
                    context=dict(self._accumulated_context),
                )

                if self.on_stage_update and attempt == 0:
                    await self.on_stage_update(stage.stage_id, AgentStatus.RUNNING, None)

                remaining = deadline.require_remaining()
                if hasattr(stage.agent, "run_with_deadline"):
                    execution = stage.agent.run_with_deadline(ti, deadline)
                else:
                    execution = stage.agent.run(ti)
                output = await asyncio.wait_for(execution, timeout=remaining)

                if output.status == AgentStatus.SUCCESS:
                    sr = StageResult(
                        stage_id=stage.stage_id,
                        status=AgentStatus.SUCCESS,
                        output=output,
                        retries=attempt,
                        duration_ms=int((time.time() - start) * 1000),
                    )
                    from app.db import log_agent_call

                    log_agent_call(
                        pipeline_id,
                        stage.stage_id,
                        stage.config.agent_id,
                        "success",
                        sr.duration_ms,
                        output.tokens_used,
                    )
                    logger.info(
                        "Agent stage timing",
                        extra={
                            "source": "DAG",
                            "pipeline_id": pipeline_id,
                            "stage_id": stage.stage_id,
                            "model": effective_model,
                            "duration_ms": sr.duration_ms,
                            "retries": attempt,
                        },
                    )
                    if self.on_stage_update:
                        await self.on_stage_update(stage.stage_id, AgentStatus.SUCCESS, output)
                    return sr
                elif output.status == AgentStatus.NEEDS_HUMAN:
                    result = StageResult(
                        stage_id=stage.stage_id,
                        status=AgentStatus.NEEDS_HUMAN,
                        output=output,
                        retries=attempt,
                        duration_ms=int((time.time() - start) * 1000),
                    )
                    if self.on_stage_update:
                        await self.on_stage_update(stage.stage_id, AgentStatus.NEEDS_HUMAN, output)
                    return result
                else:
                    last_output = output
                    retries = attempt
                    if attempt < stage.config.retry_count:
                        backoff = 2**attempt
                        await asyncio.sleep(min(backoff, deadline.require_remaining()))

            except BusinessTimeoutError as error:
                last_output = ToolOutput(status=AgentStatus.FAILED, error=str(error))
                retries = attempt
                break
            except asyncio.TimeoutError:
                last_output = ToolOutput(status=AgentStatus.FAILED, error=f"Timeout after {stage.config.timeout}s")
                retries = attempt
                break
            except Exception as error:
                last_output = ToolOutput(status=AgentStatus.FAILED, error=str(error))
                retries = attempt

        result = StageResult(
            stage_id=stage.stage_id,
            status=AgentStatus.FAILED,
            output=last_output or ToolOutput(status=AgentStatus.FAILED, error="Unknown error"),
            retries=retries,
            duration_ms=int((time.time() - start) * 1000),
        )
        logger.info(
            "Agent stage timing",
            extra={
                "source": "DAG",
                "pipeline_id": pipeline_id,
                "stage_id": stage.stage_id,
                "model": effective_model,
                "duration_ms": result.duration_ms,
                "retries": retries,
                "success": False,
            },
        )
        if self.on_stage_update:
            await self.on_stage_update(stage.stage_id, AgentStatus.FAILED, result.output)
        return result

    async def retry_stage(
        self,
        stage: StageDefinition,
        pipeline_id: str,
        candidate_id: Optional[str] = None,
        params: Optional[dict[str, Any]] = None,
        prior_context: Optional[dict[str, Any]] = None,
    ) -> StageResult:
        """Retry a previously failed stage with its accumulated context."""
        if prior_context:
            self._accumulated_context = dict(prior_context)
        return await self._execute_stage(stage, pipeline_id, candidate_id, params or {})
