"""六角色包 — 每个角色对应一个独立模块，未来可独立部署"""

from hr_harness.roles.registry import (
    ROLE_REGISTRY,
    RoleDefinition,
    get_all_roles,
    get_role,
)

__all__ = [
    "ROLE_REGISTRY",
    "RoleDefinition",
    "get_role",
    "get_all_roles",
]