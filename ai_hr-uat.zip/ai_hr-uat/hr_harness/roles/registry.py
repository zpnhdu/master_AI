"""角色注册表 — 六 Agent 统一元数据管理

每个角色对应一个独立的模块包，未来可独立部署。
ROLE_REGISTRY 是所有角色元数据的单一事实来源。
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class RoleDefinition:
    """一个角色的完整定义"""

    role_id: str  # 唯一标识：xiao_wen / xiao_hai / ...
    agent_id: str  # 对应 agent_registry 的 stage_id（主阶段）
    name: str  # 短名：小文
    display_name: str  # 面板显示名：JD撰写与画像生成
    description: str  # 角色职责描述
    icon: str  # emoji 图标
    stage_ids: list[str]  # 该角色拥有的所有 stage_id
    agent_classes: list[str]  # agent 类的导入路径（供独立部署时动态加载）
    enabled: bool = True
    route: str = ""  # 角色页面路由（前端）


# ─── 六角色注册表 ───

ROLE_REGISTRY: dict[str, RoleDefinition] = {
    "xiao_wen": RoleDefinition(
        role_id="xiao_wen",
        agent_id="jd_write",
        name="小文",
        display_name="JD撰写与画像生成",
        description="根据岗位需求撰写专业 JD，并基于本体引擎生成 22 维候选人画像",
        icon="📝",
        stage_ids=["jd_write", "profile_build"],
        agent_classes=[
            "hr_harness.agents.jd_agent.JDAgent",
            "hr_harness.agents.profile_agent.ProfileAgent",
        ],
        route="/roles/xiao-wen",
    ),
    "xiao_hai": RoleDefinition(
        role_id="xiao_hai",
        agent_id="poster_gen",
        name="小海",
        display_name="招聘海报生成",
        description="根据 JD 和品牌素材生成朋友圈招聘海报",
        icon="🎨",
        stage_ids=["poster_gen"],
        agent_classes=[
            "hr_harness.agents.poster_agent.PosterAgent",
        ],
        route="/roles/xiao-hai",
    ),
    "xiao_xun": RoleDefinition(
        role_id="xiao_xun",
        agent_id="crawl",
        name="小寻",
        display_name="简历获取与导入",
        description="从招聘平台获取候选人简历，支持文件上传和 Chrome 插件导入",
        icon="🔍",
        stage_ids=["crawl", "publish"],
        # crawl/rpa 阶段无 agent 实现：简历来源为手动上传，发布走 app/routers/rpa.py
        agent_classes=[],
        enabled=False,
        route="/roles/xiao-xun",
    ),
    "xiao_shai": RoleDefinition(
        role_id="xiao_shai",
        agent_id="match",
        name="小筛",
        display_name="简历匹配与过滤",
        description="对候选人与 JD 进行多维度匹配评分，去重排序",
        icon="🎯",
        stage_ids=["match"],
        agent_classes=[
            "hr_harness.agents.match_agent.MatchAgent",
            "hr_harness.agents.dedup_agent.DedupAgent",
        ],
        route="/roles/xiao-shai",
    ),
    "xiao_ping": RoleDefinition(
        role_id="xiao_ping",
        agent_id="report",
        name="小评",
        display_name="AI 评估与录用报告",
        description="生成面试评估报告、五维度打分、录用决策建议和薪资策略",
        icon="📊",
        stage_ids=["report"],
        agent_classes=[
            "hr_harness.agents.report_agent.ReportAgent",
        ],
        route="/roles/xiao-ping",
    ),
    "xiao_mian": RoleDefinition(
        role_id="xiao_mian",
        agent_id="interview_gen",
        name="小面",
        display_name="面试出题与评估",
        description="为候选人生成个性化面试题，评估面试回答并给出多维度评分",
        icon="🎤",
        stage_ids=["interview_gen", "video_assess"],
        agent_classes=[
            "hr_harness.agents.interview_agent.InterviewAgent",
            "hr_harness.agents.video_agent.VideoAgent",
        ],
        route="/roles/xiao-mian",
    ),
}


# ─── 辅助函数 ───


def get_role(role_id: str) -> Optional[RoleDefinition]:
    """获取单个角色定义"""
    return ROLE_REGISTRY.get(role_id)


def get_all_roles() -> list[RoleDefinition]:
    """获取所有角色（按定义顺序）"""
    return list(ROLE_REGISTRY.values())
