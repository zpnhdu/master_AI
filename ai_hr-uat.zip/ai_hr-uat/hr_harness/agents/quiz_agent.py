"""Quiz Agent - Generate contextual Q&A questions for precise JD generation"""

import logging
import re
from typing import Any

from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """你是一位资深HR猎头顾问。根据用人方需求，生成5道精准选择题，帮用人方梳理岗位画像。

## 输出5道题，每维度1题：

Q1-核心定位：岗位存在的核心价值（为什么需要这个人？日常最影响绩效的事是什么？）
Q2-能力画像：最不可替代的一项能力是什么？（逼出真正优先级）
Q3-团队协作：这个人在团队中的角色和最大协作挑战？
Q4-矛盾探测：需求中最不切实际的期望或二选一难题（薪资vs要求、经验vs潜力），直击痛点
Q5-底线弹性：如果找不到完美人选，最不能让步的条件是什么？

## 输出格式
严格输出包含5个对象的JSON数组：
{
  "id": "q1"到"q5",
  "category": "核心定位" | "能力画像" | "团队协作" | "矛盾探测" | "底线弹性",
  "title": "结合具体行业和岗位的问法",
  "subtitle": "一句话解释为什么问这个",
  "options": [
    { "id": "qN_a", "emoji": "emoji", "text": "选项描述（15-25字，具体接地气）", "tags": ["标签1", "标签2"] },
    ...3个选项
  ]
}

## 铁律
1. 每题必须结合具体行业/岗位特点，不泛泛而谈
2. 矛盾探测题(Q4)要真正戳痛点
3. 选项tags精准，用于后续JD生成
4. 用户补充描述中的关键信息必须融入题目"""


class QuizAgent(BaseAgent):
    """Generate contextual Q&A questions to refine recruitment needs before JD generation."""

    async def run(self, input: ToolInput) -> ToolOutput:
        """Delegate to generate_questions with ToolInput params."""
        try:
            role = input.params.get("role", "")
            hints = input.params.get("hints", "")
            questions = await self.generate_questions(role, hints)
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"questions": questions},
                tokens_used=300,
                duration_ms=0,
            )
        except Exception as e:
            return ToolOutput(status=AgentStatus.FAILED, error=str(e))

    async def generate_questions(self, role: str, hints: str = "") -> list[dict[str, Any]]:
        """Generate 5 contextual multiple-choice questions for the given role.

        Args:
            role: Job title (e.g. "后端开发工程师")
            hints: Optional supplementary requirements from user

        Returns:
            List of 5 question dicts with id, category, title, subtitle, options
        """
        user_prompt = self._build_prompt(role, hints)

        def _validate_questions(result):
            if not isinstance(result, list):
                return False
            if len(result) < 3:
                return False
            for q in result:
                if not isinstance(q, dict):
                    return False
                opts = q.get("options", [])
                if not isinstance(opts, list) or len(opts) < 2:
                    return False
                for opt in opts:
                    if not isinstance(opt, dict) or not opt.get("text"):
                        return False
            # 检查题目内容是否有区分度（至少3道不同类别的题）
            titles = [q.get("title", "") for q in result]
            unique_titles = len(set(titles))
            if unique_titles < 3:
                return False
            categories = [q.get("category", "") for q in result]
            unique_categories = len(set(categories))
            if unique_categories < 3:
                return False
            return True

        try:
            result = await self.call_llm_json(
                user_prompt,
                SYSTEM_PROMPT,
                complexity="plus",
                temperature=0.9,
                validator=_validate_questions,
                max_retries=2,
            )

            if not isinstance(result, list) or len(result) < 3:
                logger.warning("QuizAgent: LLM returned insufficient questions, using fallback")
                return self._generate_fallback(role, hints)

            # 去重：移除标题重复的问题
            seen_titles = set()
            unique_questions = []
            for q in result:
                title = q.get("title", "").strip()
                if title and title not in seen_titles:
                    seen_titles.add(title)
                    unique_questions.append(q)
            if len(unique_questions) < 3:
                logger.warning("QuizAgent: too many duplicate questions, using fallback")
                return self._generate_fallback(role, hints)

            # 规范化：最多保留 5 道题并修正 ID
            questions = unique_questions[:5]
            for i, q in enumerate(questions):
                q["id"] = f"q{i + 1}"
                q["options"] = q.get("options", [])[:3]
                for j, opt in enumerate(q["options"]):
                    opt["id"] = f"q{i + 1}_{chr(97 + j)}"

            logger.info(f"QuizAgent: Generated {len(questions)} unique questions for '{role}'")
            return questions

        except Exception as e:
            logger.error(f"QuizAgent: LLM failed: {e}, using fallback")
            return self._generate_fallback(role, hints)

    def _build_prompt(self, role: str, hints: str) -> str:
        prompt = "请分析以下招聘需求，并生成5道针对性选择题：\n\n"
        prompt += f"【岗位名称】{role}\n"
        if hints:
            prompt += f"\n【需求描述】\n{hints}\n"
        prompt += "\n请直接输出5道选择题的JSON数组，不要输出其他内容。"
        return prompt

    def _generate_fallback(self, role: str, hints: str) -> list[dict[str, Any]]:
        """Rule-based fallback when LLM fails. Generates 5 targeted questions."""
        desc = (hints or "").lower()
        has_tech = bool(re.search(r"技术|开发|系统|架构|代码|算法|前端|后端|工程师", desc + role))
        is_manager = bool(re.search(r"经理|主管|总监|负责人|head|lead|管理", role + desc))

        domain = "技术" if has_tech else "业务"

        questions = [
            {
                "id": "q1",
                "category": "核心定位",
                "title": f"{role}岗位存在的核心价值是什么？日常最花时间的事？",
                "subtitle": "搞清楚为什么需要这个人",
                "options": [
                    {
                        "id": "q1_a",
                        "emoji": "🔧",
                        "text": "解决当前团队最头疼的技术难题",
                        "tags": ["技术深度", "问题解决"],
                    },
                    {
                        "id": "q1_b",
                        "emoji": "📈",
                        "text": "驱动业务增长，带来可衡量的业绩提升",
                        "tags": ["业绩导向", "结果驱动"],
                    },
                    {"id": "q1_c", "emoji": "🏗️", "text": "从0到1搭建体系、流程或架构", "tags": ["体系建设", "从0到1"]},
                ],
            },
            {
                "id": "q2",
                "category": "能力画像",
                "title": "这个人最不可替代的一项能力是什么？",
                "subtitle": "逼出真正的优先级——什么都要等于什么都不要",
                "options": [
                    {
                        "id": "q2_a",
                        "emoji": "🧠",
                        "text": f"在{domain}领域的深度专业积累",
                        "tags": ["专业深度", f"{domain}能力"],
                    },
                    {"id": "q2_b", "emoji": "⚡", "text": "超强的执行力和落地能力", "tags": ["执行力", "结果导向"]},
                    {"id": "q2_c", "emoji": "💡", "text": "能从全局视角做判断和取舍", "tags": ["战略思维", "判断力"]},
                ],
            },
            {
                "id": "q3",
                "category": "团队协作",
                "title": "这个人在团队中的角色和最大协作挑战？",
                "subtitle": "大部分岗位的死穴不在专业能力，在协作关系",
                "options": [
                    {
                        "id": "q3_a",
                        "emoji": "📱",
                        "text": "产品/业务方——需求对齐和优先级博弈",
                        "tags": ["产品协作", "需求管理"],
                    },
                    {
                        "id": "q3_b",
                        "emoji": "⬆️",
                        "text": "上级/老板——期望管理和资源争取",
                        "tags": ["向上管理", "资源争取"],
                    },
                    {
                        "id": "q3_c",
                        "emoji": "🤝",
                        "text": "平行部门——跨团队拉齐和利益平衡",
                        "tags": ["跨部门协调", "利益平衡"],
                    },
                ],
            },
            {
                "id": "q4",
                "category": "矛盾探测",
                "title": "说句实话，这个岗位最大的挑战或矛盾是什么？",
                "subtitle": "每个岗位都有坑，提前知道才能找到愿意踩坑的人",
                "options": [
                    {
                        "id": "q4_a",
                        "emoji": "💰",
                        "text": "预算有限但要找高水平的人",
                        "tags": ["薪资矛盾", "性价比导向"],
                    },
                    {
                        "id": "q4_b",
                        "emoji": "🌫️",
                        "text": "业务方向不确定，需要能接受模糊性的人",
                        "tags": ["业务不确定", "模糊容忍度"],
                    },
                    {
                        "id": "q4_c",
                        "emoji": "🔧",
                        "text": "技术债务多，需一边还债一边做新东西",
                        "tags": ["技术债务", "平衡能力"],
                    },
                ],
            },
            {
                "id": "q5",
                "category": "底线弹性",
                "title": "如果找不到理想人选，最不愿意妥协的是什么？",
                "subtitle": "知道底线在哪里，才知道弹性空间有多大",
                "options": [
                    {
                        "id": "q5_a",
                        "emoji": "💪",
                        "text": "专业能力不能妥协——这是吃饭的本事",
                        "tags": ["专业底线", "能力刚性"],
                    },
                    {
                        "id": "q5_b",
                        "emoji": "❤️",
                        "text": "价值观和文化契合不能妥协",
                        "tags": ["文化底线", "价值观契合"],
                    },
                    {
                        "id": "q5_c",
                        "emoji": "💰",
                        "text": "薪资不能超预算——再合适也不行",
                        "tags": ["成本底线", "预算刚性"],
                    },
                ],
            },
        ]

        # 管理岗位将第 3 题调整为管理能力方向
        if is_manager:
            questions[2]["options"] = [
                {
                    "id": "q3_a",
                    "emoji": "👥",
                    "text": "5人以下小团队，需要手把手带",
                    "tags": ["小团队管理", "player-coach"],
                },
                {"id": "q3_b", "emoji": "🏢", "text": "5-15人，需要建机制和培养骨干", "tags": ["中层管理", "体系建设"]},
                {"id": "q3_c", "emoji": "🏛️", "text": "15人以上多团队，需要战略统筹", "tags": ["高层管理", "战略规划"]},
            ]

        return questions


def format_quiz_answers_for_jd(answers: list[dict[str, Any]]) -> str:
    """Format quiz answers as context string for JDAgent.

    Args:
        answers: List of answer dicts, each with:
            question_id, question_title, question_category, selected_text, tags

    Returns:
        Formatted string to append to JD generation prompt
    """
    if not answers:
        return ""

    lines = ["【用户需求分析——基于5道选择题的回答】", ""]
    for a in answers:
        cat = a.get("question_category", "")
        title = a.get("question_title", "")
        text = a.get("selected_text", "")
        tags = a.get("tags", [])
        lines.append(f"【{cat}】{title}")
        lines.append(f"→ 选择：{text}")
        if tags:
            lines.append(f"→ 标签：{'、'.join(tags)}")
        lines.append("")

    lines.append("请重点参考「矛盾探测」和「底线弹性」的答案来推断用户的真实优先级。")
    lines.append("不要生成与用户选择明显矛盾的JD内容。")
    return "\n".join(lines)
