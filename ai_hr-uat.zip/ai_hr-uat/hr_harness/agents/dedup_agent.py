"""Dedup Agent - Simple text-similarity duplicate detection across resumes"""

from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import ToolInput, ToolOutput


class DedupAgent(BaseAgent):
    async def run(self, input: ToolInput) -> ToolOutput:
        resumes = input.params.get("resumes", [])

        if len(resumes) < 2:
            return {"duplicates": [], "status": "too_few"}

        duplicates = self._find_duplicates(resumes)

        return {
            "duplicates": duplicates,
            "status": "completed",
        }

    def _find_duplicates(self, resumes: list[dict], threshold: float = 0.7) -> list[dict]:
        """基于 Jaccard 相似度检测重复简历"""
        duplicates = []
        texts = []

        for r in resumes:
            text = r.get("resume_text", "")
            if not text:
                text = f"{r.get('name', '')} {r.get('education', '')} {' '.join(r.get('skills', []))} {r.get('current_company', '')}"
            texts.append(self._tokenize(text))

        for i in range(len(texts)):
            for j in range(i + 1, len(texts)):
                similarity = self._jaccard(texts[i], texts[j])
                if similarity >= threshold:
                    duplicates.append(
                        {
                            "candidate_a": {
                                "id": resumes[i].get("id", ""),
                                "name": resumes[i].get("name", ""),
                            },
                            "candidate_b": {
                                "id": resumes[j].get("id", ""),
                                "name": resumes[j].get("name", ""),
                            },
                            "similarity": round(similarity, 2),
                            "reason": f"简历文本相似度 {int(similarity * 100)}%",
                        }
                    )

        return duplicates

    def _tokenize(self, text: str) -> set:
        """简单分词：按空白和标点切分"""
        import re

        tokens = re.split(r"[\s,，。、；：！？\n\r]+", text.lower())
        return {t for t in tokens if len(t) >= 2}

    def _jaccard(self, set_a: set, set_b: set) -> float:
        """Jaccard 相似度"""
        if not set_a and not set_b:
            return 1.0
        intersection = len(set_a & set_b)
        union = len(set_a | set_b)
        if union == 0:
            return 0.0
        return intersection / union

    @staticmethod
    def filter_duplicates(resumes: list[dict], duplicates: list[dict]):
        """基于重复检测结果过滤简历，每组保留数据最完整的一份。

        Returns:
            (cleaned_resumes, removed_resumes)
        """
        if not duplicates:
            return resumes, []

        # Union-Find: 将传递性重复对合并为组 (A≈B, B≈C → {A,B,C})
        parent = {}

        def find(x):
            while parent.get(x, x) != x:
                parent[x] = parent.get(parent[x], parent[x])
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb

        for dup in duplicates:
            id_a = dup["candidate_a"]["id"]
            id_b = dup["candidate_b"]["id"]
            if id_a and id_b:
                union(id_a, id_b)

        # 按组聚合
        groups = {}
        for r in resumes:
            rid = r.get("id", "")
            if rid:
                root = find(rid)
                groups.setdefault(root, []).append(r)

        def _completeness(r):
            """数据完整度评分：resume_text 长度 + 关键字段存在 + 技能数量"""
            score = len(r.get("resume_text", ""))
            for field in ("name", "education", "current_company", "years_experience", "current_salary"):
                if r.get(field):
                    score += 50
            score += len(r.get("skills", [])) * 10
            return score

        cleaned, removed = [], []
        grouped_ids = set()
        for group in groups.values():
            group.sort(key=_completeness, reverse=True)
            cleaned.append(group[0])
            removed.extend(group[1:])
            for r in group:
                grouped_ids.add(r.get("id", ""))

        # 不在任何重复组中的简历直接保留
        for r in resumes:
            if r.get("id", "") not in grouped_ids:
                cleaned.append(r)

        return cleaned, removed
