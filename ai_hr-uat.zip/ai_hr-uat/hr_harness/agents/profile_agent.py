"""Profile Agent - Generate a structured candidate profile from JD + ontology"""

import time

from app.xiao_wen_context import XIAO_WEN_MODEL
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput
from knowledge import get_knowledge_base
from ontology import get_ontology_engine

# 画像维度（22 项）
# 不含 age_range、gender_preference 等敏感字段（与 guardrails 反歧视规则一致）
PROFILE_DIMENSIONS = {
    "basic": ["location", "salary_expectation", "availability", "work_mode"],
    "education": ["degree", "school_tier", "major", "certifications"],
    "experience": ["years", "industry", "company_tier", "role_progression", "project_scale"],
    "skills": ["tech_stack", "soft_skills", "language", "domain_expertise", "leadership_experience"],
    "culture": ["work_style", "team_size_preference", "growth_orientation", "values"],
}
PROFILE_DIMENSION_COUNT = sum(len(dimensions) for dimensions in PROFILE_DIMENSIONS.values())

# 每个维度的数据来源：ontology（本体推理）或 llm（通用能力）
DIMENSION_SOURCE_MAP = {
    "location": "llm",
    "salary_expectation": "ontology",
    "availability": "llm",
    "work_mode": "llm",
    "degree": "ontology",
    "school_tier": "ontology",
    "major": "ontology",
    "certifications": "llm",
    "years": "ontology",
    "industry": "ontology",
    "company_tier": "ontology",
    "role_progression": "llm",
    "project_scale": "llm",
    "tech_stack": "ontology",
    "soft_skills": "llm",
    "language": "llm",
    "domain_expertise": "ontology",
    "leadership_experience": "llm",
    "work_style": "llm",
    "team_size_preference": "llm",
    "growth_orientation": "llm",
    "values": "llm",
}

# 22 维画像 → 现有 6 维评分的聚合映射
PROFILE_TO_SIX_DIM_MAP = {
    "tech_score": ["tech_stack", "domain_expertise"],
    "experience_score": ["years", "industry", "company_tier", "role_progression", "project_scale"],
    "education_score": ["degree", "school_tier", "certifications"],
    "major_match_score": ["major"],
    "culture_score": ["work_style", "team_size_preference", "growth_orientation", "values"],
    "salary_risk": ["salary_expectation"],
}


class ProfileAgent(BaseAgent):
    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        # 合并 params 和上游 context（DAG 引擎按 stage_id 索引）
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        jd = data.get("jd", {})
        role = data.get("role", "")
        if not role:
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"profile": {}, "status": "no_role"},
                duration_ms=0,
            )
        pipeline_id = data.get("pipeline_id", input.pipeline_id)
        memory_context = data.get("memory_context", "")
        pipeline_type = data.get("pipeline_type", "general")
        company_config = data.get("company_config", {})
        kg_context = data.get("kg_context", {})
        model = XIAO_WEN_MODEL
        complexity = data.get("complexity", "plus")
        temperature = data.get("temperature")
        llm_max_retries = int(data.get("llm_max_retries", 1))

        # 本体上下文
        ontology = get_ontology_engine(pipeline_id)
        ontology_context = ontology.build_jd_prompt_context(role)
        weights = ontology.get_scoring_weights(role)

        # 知识库检索
        kb = get_knowledge_base()
        kb_results = kb.search(f"{role} 岗位要求 人才画像 技能要求", top_k=3)
        kb_context = ""
        if kb_results:
            kb_context = "\n【知识库参考】\n" + "\n".join(f"- [{k['title']}] {k['content'][:200]}" for k in kb_results)

        company_context = ""
        if company_config:
            benefits = company_config.get("default_benefits", [])
            company_context = (
                "\n【公司背景参考】\n"
                f"公司：{company_config.get('company_name', '')}\n"
                f"行业：{company_config.get('industry', '')}\n"
                f"规模：{company_config.get('company_size', '')}\n"
                f"福利：{'、'.join(benefits[:4]) if isinstance(benefits, list) else benefits}\n"
            )

        kg_context_text = ""
        if kg_context:
            kg_parts = []
            for key, label, limit in (("scenarios", "场景", 2), ("methods", "方法", 3), ("rules", "规则", 2)):
                items = kg_context.get(key, [])
                names = [item.get("name", "") for item in items[:limit] if isinstance(item, dict)]
                if names:
                    kg_parts.append(f"{label}：{'、'.join(names)}")
            if kg_parts:
                kg_context_text = "\n【知识图谱参考】\n" + "\n".join(kg_parts)

        jd_text = (
            str(jd)
            if not isinstance(jd, dict)
            else (
                f"岗位：{jd.get('title', role)}\n"
                f"职责：{', '.join(jd.get('responsibilities', []))}\n"
                f"要求：{', '.join(jd.get('requirements', []))}\n"
                f"技术栈：{', '.join(jd.get('tech_stack', []))}\n"
                f"薪资：{jd.get('salary_range', '未指定')}\n"
                f"福利：{', '.join(jd.get('benefits', []))}\n"
                f"团队：{jd.get('team_intro', '')}\n"
                f"工作时间：{jd.get('work_hours', '')}"
            )
        )

        weight_desc = ", ".join([f"{k}={int(v * 100)}%" for k, v in weights.items()])

        system = f"""你是一个资深人才画像专家，擅长根据 JD 和公司背景构建精准的候选人画像。

{ontology_context}
{kb_context}
{company_context}
{kg_context_text}

岗位类型：{pipeline_type}

画像构建原则：
1. 每个维度必须有明确的推荐值和权重（0-1）
2. 权重反映该维度对这个岗位的重要程度
3. 推荐值必须具体可操作（如 tech_stack 必须列出具体的技术名称，不能写"主流框架"）
4. 本体驱动的维度（tech_stack、school_tier、degree 等）要基于公司知识给出精准推荐
5. 不要包含任何歧视性维度（年龄、性别、民族、婚育等）

维度说明：
- location: 期望工作城市
- salary_expectation: 薪资范围（对标 JD）
- availability: 到岗时间要求
- work_mode: 远程/混合/坐班偏好
- degree: 最低学历（专科/本科/硕士/博士）
- school_tier: 学校层次（C9/985/211/QS前200/普通本科）
- major: 专业方向
- certifications: 相关证书
- years: 工作年限范围
- industry: 行业背景偏好
- company_tier: 公司背景偏好（大厂/中厂/创业公司）
- role_progression: 职级成长路径期望
- project_scale: 项目规模期望（DAU/团队规模/营收规模）
- tech_stack: 核心技术栈（必须具体）
- soft_skills: 软技能要求
- language: 语言要求
- domain_expertise: 领域专业知识
- leadership_experience: 管理经验要求
- work_style: 工作风格（自驱型/协作型/执行型）
- team_size_preference: 期望团队规模
- growth_orientation: 成长导向（技术深耕/管理路线/业务导向）
- values: 价值观匹配

当前本体评分权重参考：{weight_desc}

输出严格的 JSON 格式。"""

        memory_section = f"\n\n【历史经验参考】\n{memory_context}" if memory_context else ""

        prompt = f"""根据以下 JD 构建 22 维候选人画像：

{jd_text}{memory_section}

输出 JSON 格式：
{{
  "dimensions": {{
    "location": {{"weight": 0.0-1.0, "recommended": "推荐值或范围"}},
    "salary_expectation": {{"weight": 0.0-1.0, "recommended": "薪资范围"}},
    "availability": {{"weight": 0.0-1.0, "recommended": "到岗时间"}},
    "work_mode": {{"weight": 0.0-1.0, "recommended": "工作模式偏好"}},
    "degree": {{"weight": 0.0-1.0, "recommended": "最低学历"}},
    "school_tier": {{"weight": 0.0-1.0, "recommended": ["学校层次列表"]}},
    "major": {{"weight": 0.0-1.0, "recommended": "专业方向"}},
    "certifications": {{"weight": 0.0-1.0, "recommended": ["证书列表"]}},
    "years": {{"weight": 0.0-1.0, "recommended": {{"min": 数字, "max": 数字}}}},
    "industry": {{"weight": 0.0-1.0, "recommended": ["行业列表"]}},
    "company_tier": {{"weight": 0.0-1.0, "recommended": ["公司层次列表"]}},
    "role_progression": {{"weight": 0.0-1.0, "recommended": "职级路径描述"}},
    "project_scale": {{"weight": 0.0-1.0, "recommended": "项目规模描述"}},
    "tech_stack": {{"weight": 0.0-1.0, "recommended": ["技术1", "技术2", "..."]}},
    "soft_skills": {{"weight": 0.0-1.0, "recommended": ["软技能列表"]}},
    "language": {{"weight": 0.0-1.0, "recommended": "语言要求"}},
    "domain_expertise": {{"weight": 0.0-1.0, "recommended": "领域知识描述"}},
    "leadership_experience": {{"weight": 0.0-1.0, "recommended": "管理经验描述"}},
    "work_style": {{"weight": 0.0-1.0, "recommended": "工作风格描述"}},
    "team_size_preference": {{"weight": 0.0-1.0, "recommended": "团队规模偏好"}},
    "growth_orientation": {{"weight": 0.0-1.0, "recommended": "成长导向描述"}},
    "values": {{"weight": 0.0-1.0, "recommended": "价值观描述"}}
  }}
}}"""

        all_dim_keys = set()
        for dims in PROFILE_DIMENSIONS.values():
            all_dim_keys.update(dims)

        def _validate_profile(result):
            """画像输出校验：22 维齐全 + weight 合法 + tech_stack 非空"""
            if not isinstance(result, dict):
                return False
            dimensions = result.get("dimensions", {})
            if not isinstance(dimensions, dict):
                return False
            # 检查所有 22 维存在
            for key in all_dim_keys:
                if key not in dimensions:
                    return False
            # 检查 weight 范围
            for key, dim in dimensions.items():
                if not isinstance(dim, dict):
                    return False
                w = dim.get("weight")
                if not isinstance(w, (int, float)) or not (0 <= w <= 1):
                    return False
            # tech_stack 至少 1 项
            tech = dimensions.get("tech_stack", {}).get("recommended", [])
            if isinstance(tech, list) and len(tech) < 1:
                return False
            return True

        result = await self.call_llm_json(
            prompt,
            system,
            complexity=complexity,
            temperature=temperature,
            model=model,
            json_mode=True,
            validator=_validate_profile,
            max_retries=llm_max_retries,
        )

        # 附加 source 标注
        if isinstance(result, dict) and "dimensions" in result:
            for dim_key, dim_value in result["dimensions"].items():
                if isinstance(dim_value, dict):
                    dim_value["source"] = DIMENSION_SOURCE_MAP.get(dim_key, "llm")

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "profile": result if isinstance(result, dict) else {},
                "role": role,
                "status": "completed",
            },
            tokens_used=500,
            duration_ms=int((time.time() - start) * 1000),
        )
