"""应聘助手 - 24/7 候选人智能服务（参考北森 AI应聘助手）

功能：
1. 回答候选人关于岗位、公司、流程的常见问题
2. 提供候选人进度查询
3. 主动推送面试提醒和状态更新
4. 收集候选人基本信息和意向

北森核心差异化：
- 7×24小时智能答疑
- 提升应聘者体验
- 实时响应候选人咨询
"""

import json
from typing import Any

from app.db import get_candidates, get_pipeline, get_stages
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


class CandidateAssistant(BaseAgent):
    """应聘助手 — 面向候选人的7×24智能服务"""

    async def run(self, input: ToolInput) -> ToolOutput:
        """Dispatch to appropriate assistant method."""
        try:
            action = input.params.get("action", "query")
            query = input.params.get("query", "")
            pid = input.pipeline_id
            name = input.params.get("candidate_name", "")
            if action == "status":
                result = await self.get_status_update(pid, name)
            elif action == "reminder":
                result = await self.generate_reminder(name, input.params.get("role", ""), pid)
            elif action == "screening":
                result = await self.screening_flow(pid, name)
            else:
                result = await self.handle_query(query, pid, name)
            return ToolOutput(status=AgentStatus.SUCCESS, data=result)
        except Exception as e:
            return ToolOutput(status=AgentStatus.FAILED, error=str(e))

    async def handle_query(self, query: str, pipeline_id: str = "", candidate_name: str = "") -> dict[str, Any]:
        """处理候选人查询/问题（带 KG 安全防护）"""
        from kg.safety import check_emotion, check_privacy_probe

        # 隐私探测检测
        if check_privacy_probe(query):
            return {
                "status": "completed",
                "response": {
                    "answer": "这个问题涉及内部信息，建议直接联系 HR。",
                    "action_needed": "none",
                    "follow_up": "",
                    "mood": "neutral",
                },
            }

        # 情感检测
        if check_emotion(query):
            return {
                "status": "completed",
                "response": {
                    "answer": "别担心，面试是一个双向了解的过程。做好准备，展现真实的自己就好。加油！💪",
                    "action_needed": "none",
                    "follow_up": "如有任何问题，随时联系 HR。",
                    "mood": "positive",
                },
            }

        # 获取pipeline上下文
        pipeline_context = self._get_pipeline_context(pipeline_id)

        # KG 检索（只取 public 节点）
        kg_context_text = ""
        try:
            from kg.core import KnowledgeGraph

            kg = KnowledgeGraph()
            kg_results = kg.search(query, top_k=3, visibility="public", min_confidence=0.5)
            if kg_results:
                kg_context_text = "\n【知识库参考】\n" + "\n".join(
                    f"【{r['name']}】{r.get('definition', '')}" for r in kg_results
                )
        except Exception:
            pass

        # 读取公司配置
        company_info = ""
        try:
            from app.db import get_company_config

            cfg = get_company_config()
            if cfg and cfg.get("company_name"):
                benefits = "、".join(cfg.get("default_benefits", [])[:4])
                company_info = f"""
【公司信息】
公司：{cfg.get("company_name")}（{cfg.get("company_en", "")}）
行业：{cfg.get("industry", "")} | 规模：{cfg.get("company_size", "")}
介绍：{cfg.get("company_intro", "")}
福利：{benefits}
"""
        except Exception:
            pass

        system = f"""你是一个友善专业的招聘助手，代表{company_info.split(chr(10))[1] if company_info else "公司"}回答候选人的问题。{company_info}
{kg_context_text}
核心原则：
1. 友善、专业、简洁
2. 不泄露其他候选人的信息
3. 不给出虚假承诺（如"你一定会被录用"）
4. 对敏感问题（如具体薪资）引导与HR沟通
5. 积极正面地介绍岗位和公司

当前岗位信息：
- 岗位：{pipeline_context.get("role", "未知")}
- 薪资范围：{pipeline_context.get("salary_range", "面议")}
- 工作地点：{pipeline_context.get("location", "未指定")}
- 招聘流程：{pipeline_context.get("process_desc", "简历筛选→面试→录用")}

候选人当前状态：{pipeline_context.get("candidate_status", "未知")}

输出JSON格式。"""

        prompt = f"""候选人"{candidate_name or "未登录"}"的问题：{query}

请回答：
{{
    "answer": "回复内容（80字以内，友善专业）",
    "action_needed": "none/notify_hr/schedule_interview/provide_info",
    "follow_up": "后续行动建议（如：已帮您通知HR，预计24小时内回复）",
    "mood": "positive/neutral/concerned"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="flash")
        if isinstance(result, dict) and "answer" in result:
            return {"status": "completed", "response": result, "pipeline_context": pipeline_context}
        return {"status": "error", "response": {"answer": "抱歉，暂时无法回答您的问题，请联系HR。"}}

    async def get_status_update(self, pipeline_id: str, candidate_name: str = "") -> dict[str, Any]:
        """生成候选人状态更新"""
        pipeline = get_pipeline(pipeline_id) if pipeline_id else None
        if not pipeline:
            return {"status": "error", "message": "未找到相关招聘信息"}

        candidates = get_candidates(pipeline_id)
        stages = get_stages(pipeline_id)

        # 找到匹配的候选人
        matched = None
        for c in candidates:
            if c.get("name") == candidate_name:
                matched = c
                break

        if not matched and candidate_name:
            # 模糊匹配
            for c in candidates:
                if candidate_name in c.get("name", "") or c.get("name", "") in candidate_name:
                    matched = c
                    break

        if not matched:
            return {
                "status": "not_found",
                "message": f"未找到名为'{candidate_name}'的候选人记录。请确认姓名或联系HR。",
            }

        # 构建状态描述
        status_map = {
            "new": "简历已收到，正在评估中",
            "matched": "简历评估完成",
            "interviewed": "面试已完成",
            "shortlisted": "已通过初筛，等待面试安排",
            "offered": "已发送Offer",
            "rejected": "很遗憾，本次未通过筛选",
        }
        current_status = status_map.get(matched.get("status", "new"), "处理中")

        # 当前阶段
        current_stage = "处理中"
        for s in stages:
            if s.get("status") in ("running", "waiting"):
                current_stage = s.get("stage_name", s.get("stage_id", ""))
                break

        # 用 LLM 包装为友善消息
        friendly_message = await self._generate_friendly_message(
            matched.get("name", ""),
            pipeline.get("role", ""),
            current_status,
            current_stage,
            self._get_next_step(matched.get("status", "new")),
        )

        return {
            "status": "completed",
            "candidate_name": matched.get("name", ""),
            "role": pipeline.get("role", ""),
            "current_status": current_status,
            "current_stage": current_stage,
            "next_step": self._get_next_step(matched.get("status", "new")),
            "overall_score": matched.get("overall_score", 0),
            "friendly_message": friendly_message,
        }

    async def generate_reminder(self, candidate_name: str, role: str, event_type: str = "interview") -> dict[str, Any]:
        """生成面试提醒消息"""
        prompts = {
            "interview": f"提醒{candidate_name}参加{role}的面试，包含时间地点准备事项",
            "result": f"通知{candidate_name}关于{role}岗位的面试结果",
            "followup": f"跟进{candidate_name}关于{role}岗位的应聘进展",
        }

        system = """你是一个专业的招聘助手，负责给候选人发送友善的通知消息。
消息要简洁（50字以内）、包含关键信息、语气友善。
输出JSON格式。"""

        prompt = f"""请生成{event_type}类型的通知消息：
{prompts.get(event_type, f"通知{candidate_name}关于{role}岗位的信息")}

{{
    "message": "通知消息正文（50字以内）",
    "subject": "消息标题（10字以内）"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="flash")
        if isinstance(result, dict) and "message" in result:
            return {"status": "completed", "reminder": result}
        return {
            "status": "completed",
            "reminder": {
                "message": f"您好 {candidate_name}，温馨提醒：您的 {role} 岗位面试即将开始，请做好准备。",
                "subject": "面试提醒",
            },
        }

    async def screening_flow(self, pipeline_id: str, candidate_name: str) -> dict:
        """对话式预筛选：生成3-5个筛选问题，对标 Paradox Olivia"""
        pipeline = get_pipeline(pipeline_id)
        if not pipeline:
            return {"error": "Pipeline not found"}

        stages = get_stages(pipeline_id)
        jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
        jd_output = (
            json.loads(jd_stage["output"])
            if jd_stage and isinstance(jd_stage["output"], str)
            else (jd_stage["output"] if jd_stage else {})
        )
        jd = jd_output.get("jd", {})

        system = """你是一个专业的招聘预筛选助手。根据岗位要求，设计3-5个关键筛选问题来快速判断候选人是否满足基本条件。
问题要有区分度，能有效筛除不合格候选人。
输出JSON格式。"""

        prompt = f"""岗位：{pipeline["role"]}
JD要求：{json.dumps(jd, ensure_ascii=False)[:1000]}

候选人：{candidate_name}

请设计3-5个预筛选问题，输出JSON：
{{
    "screening_questions": [
        {{"question": "筛选问题", "type": "knockout/basic/preference", "pass_criteria": "通过标准"}}
    ],
    "estimated_duration": "约5分钟"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="flash")
        return result if isinstance(result, dict) else {"screening_questions": []}

    async def _generate_friendly_message(
        self,
        candidate_name: str,
        role: str,
        current_status: str,
        current_stage: str,
        next_step: str,
    ) -> str:
        """用 LLM 将状态信息包装为友善的候选人通知消息"""
        system = """你是一个友善专业的招聘助手。将候选人的状态信息转化为一段温暖、简洁的消息。
语气亲切自然，像朋友一样告知进展，50字以内。
输出JSON格式。"""

        prompt = f"""候选人：{candidate_name}
应聘岗位：{role}
当前状态：{current_status}
当前阶段：{current_stage}
下一步：{next_step}

请生成友善通知消息：
{{"message": "通知消息正文（50字以内）"}}"""
        try:
            result = await self.call_llm_json(prompt, system, complexity="flash")
            if isinstance(result, dict) and "message" in result:
                return result["message"]
        except Exception:
            pass

        return f"您好 {candidate_name}，您的 {role} 岗位申请{current_status}，{next_step}。"

    def _get_pipeline_context(self, pipeline_id: str) -> dict:
        """获取pipeline上下文信息（供候选人查询用）"""
        if not pipeline_id:
            return {}

        pipeline = get_pipeline(pipeline_id)
        if not pipeline:
            return {}

        stages = get_stages(pipeline_id)
        jd_stage = next((s for s in stages if s["stage_id"] == "jd_write"), None)
        jd = {}
        if jd_stage:
            try:
                output = json.loads(jd_stage["output"]) if isinstance(jd_stage["output"], str) else jd_stage["output"]
                jd = output.get("jd", {})
            except (json.JSONDecodeError, TypeError):
                pass

        # 构建流程描述
        completed_stages = [s["stage_name"] for s in stages if s.get("status") == "done"]
        process_desc = " → ".join(completed_stages) if completed_stages else "简历筛选→面试→录用"

        return {
            "role": pipeline.get("role", ""),
            "salary_range": jd.get("salary_range", "面议"),
            "location": jd.get("location", "未指定"),
            "process_desc": process_desc,
            "benefits": jd.get("benefits", []),
            "pipeline_status": pipeline.get("status", ""),
        }

    def _get_next_step(self, current_status: str) -> str:
        """根据当前状态推断下一步"""
        next_steps = {
            "new": "HR将在3个工作日内完成简历评估",
            "matched": "符合条件将安排面试，预计1周内通知",
            "interviewed": "面试结果将在5个工作日内通知",
            "shortlisted": "即将安排面试，请保持手机畅通",
            "offered": "请在3个工作日内确认Offer",
            "rejected": "已纳入人才库，有合适岗位将再次联系",
        }
        return next_steps.get(current_status, "请耐心等待HR通知")
