"""Outreach Agent - 多渠道自动触达序列（参考 Gem Nurturing 序列）

功能：
1. 为筛选通过的候选人生成个性化触达消息
2. 支持多步骤序列（首次触达 → 跟进 → 确认）
3. 通过飞书/企微等渠道自动发送
"""

from collections.abc import Callable

from app.db import save_outreach_event
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import ToolInput, ToolOutput
from typing import Optional

# 多步触达序列（参考 Gem Nurturing 模式）
OUTREACH_SEQUENCE = [
    {"step": "initial", "delay": "0天", "channel": "preferred"},
    {"step": "follow_up_1", "delay": "3天", "channel": "same", "condition": "no_reply"},
    {"step": "follow_up_2", "delay": "7天", "channel": "alternate", "condition": "no_reply"},
    {"step": "last_touch", "delay": "14天", "channel": "email", "condition": "no_reply", "tone": "casual"},
    {"step": "confirm", "delay": "reply", "channel": "same", "trigger": "positive_reply"},
]

# 渠道模板配置
CHANNEL_TEMPLATES = {
    "email": {"has_subject": True, "max_length": 500, "formal": True},
    "feishu": {"has_subject": False, "max_length": 200, "formal": False},
    "sms": {"has_subject": False, "max_length": 70, "formal": False},
    "boss": {"has_subject": False, "max_length": 150, "formal": False, "tone": "professional"},
}


class OutreachAgent(BaseAgent):
    """多渠道候选人触达Agent"""

    def __init__(self):
        super().__init__()
        self._progress_cb: Optional[Callable] = None

    async def _progress(self, msg: str):
        if self._progress_cb:
            await self._progress_cb(msg)

    async def run(self, input: ToolInput) -> ToolOutput:
        context = input.params
        candidates = context.get("candidates", [])
        jd = context.get("jd", {})
        role = context.get("role", "")
        pipeline_id = context.get("pipeline_id", "")
        step = context.get("outreach_step", "initial")
        company_config = context.get("company_config", {})
        company_name = company_config.get("company_name", "") if company_config else ""

        if not candidates:
            return {"messages": [], "status": "no_candidates"}

        # 知识库检索：触达话术参考
        from knowledge import get_knowledge_base

        kb = get_knowledge_base()
        kb_results = kb.search(f"{role} 招聘触达 话术 候选人沟通", top_k=2)
        kb_context = ""
        if kb_results:
            kb_context = "\n【知识库参考】\n" + "\n".join(f"- [{k['title']}] {k['content'][:150]}" for k in kb_results)

        # 只为入围候选人触达
        targets = [c for c in candidates if c.get("overall_score", 0) >= 60]
        if not targets:
            targets = candidates[:3]

        messages = []
        for i, cand in enumerate(targets):
            await self._progress(f"正在为 {cand['name']} 生成个性化触达消息...")

            msg = await self._generate_message(role, jd, cand, step, kb_context, company_name)

            # 记录触达事件
            save_outreach_event(
                pipeline_id=pipeline_id,
                candidate_id=cand.get("id", ""),
                candidate_name=cand.get("name", ""),
                event_type=f"outreach_{step}",
                content=msg.get("text", ""),
                channel="feishu",
            )

            messages.append(
                {
                    "candidate_id": cand.get("id", ""),
                    "candidate_name": cand.get("name", ""),
                    "step": step,
                    **msg,
                }
            )

        await self._progress(f"已生成 {len(messages)} 条触达消息")

        return {
            "messages": messages,
            "total": len(messages),
            "step": step,
            "status": "completed",
        }

    async def _generate_message(
        self, role: str, jd: dict, cand: dict, step: str, kb_context: str = "", company_name: str = ""
    ) -> dict:
        """为单个候选人生成个性化消息"""
        co_intro = f"你是{company_name}的HR招聘顾问。" if company_name else ""
        system = f"""你是一个专业的HR招聘顾问。{co_intro}擅长撰写个性化的候选人触达消息。

核心原则：
1. 个性化 — 引用候选人简历中的具体亮点（项目经验、技能、公司背景）
2. 简洁 — 消息控制在100字以内，HR可以直接发送
3. 有吸引力 — 突出岗位的核心卖点和团队优势
4. 行动导向 — 明确下一步（确认面试时间、回复意愿等）

不同步骤的策略：
- initial（首次触达）：突出岗位匹配度 + 团队亮点，邀请沟通
- follow_up（跟进）：换个角度强调机会，补充新信息
- confirm（确认）：确认面试时间和准备事项

{kb_context}

输出JSON格式。"""

        jd_highlights = ""
        if isinstance(jd, dict):
            benefits = jd.get("benefits", [])
            if benefits:
                jd_highlights = f"\n岗位亮点：{', '.join(benefits[:3])}"
            salary = jd.get("salary_range", "")
            if salary:
                jd_highlights += f"\n薪资范围：{salary}"

        prompt = f"""岗位：{role}
{jd_highlights}

候选人：{cand["name"]}
经验：{cand.get("years_experience", 0)}年 · {cand.get("current_company", "")}
技能：{", ".join(cand.get("skills", [])[:5])}
AI评分：综合{cand.get("overall_score", 0)}分
亮点：{cand.get("reason", "优秀候选人")}

触达步骤：{step}

请生成一条个性化触达消息：
{{
    "text": "消息正文（100字以内，HR可直接发送）",
    "subject": "消息主题/标题（15字以内）",
    "channel": "推荐渠道（email/feishu/sms/boss）",
    "highlights_referenced": ["引用了候选人的哪些亮点"],
    "next_step": "期望的下一步动作"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="plus")
        if isinstance(result, dict) and "text" in result:
            return result
        # 降级：生成简单模板
        return {
            "text": f"您好 {cand['name']}，我们在寻找{role}方面的人才，您的背景非常匹配。方便聊聊吗？",
            "subject": f"{role}机会",
            "channel": "feishu",
            "highlights_referenced": [],
            "next_step": "等待回复",
        }
