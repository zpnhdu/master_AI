"""Match Agent - AI-powered candidate scoring with ontology + knowledge base"""

import json
import time
from collections.abc import Callable

from hr_harness.agents.base import BaseAgent
from hr_harness.agents.profile_agent import PROFILE_TO_SIX_DIM_MAP
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput
from knowledge import get_knowledge_base
from ontology import get_ontology_engine
from typing import Optional

# 评分维度的中文标签映射
WEIGHT_LABELS = {
    "tech_score": "技术匹配度",
    "experience_score": "经验匹配度",
    "education_score": "学历背景",
    "major_match_score": "专业匹配度",
    "culture_score": "文化匹配度",
    "salary_risk": "薪资风险",
}

# 学历分层基准（参考 boss-hr-agent-toolkit）
EDUCATION_TIER_DESC = """学历背景(0-100)：
- 90+: C9/顶尖985/QS前50海外名校，硕士及以上
- 70-89: 985/211/QS前200，或普通本科+硕士
- 50-69: 普通本科，或专升本但有丰富经验
- 30-49: 学历偏弱且经验不足
- 0-29: 无相关学历信息

专业匹配度(0-100)：
- 90+: 专业完全对口（如招前端→计算机/软件工程）
- 70-89: 相关专业（如招后端→数学/自动化）
- 50-69: 跨专业但有可迁移技能或自学经历
- 30-49: 专业不相关，无明显迁移能力
- 0-29: 专业完全不相关且无补充信息"""


class MatchAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self._progress_cb: Optional[Callable] = None

    async def _progress(self, msg: str):
        """Send progress update to frontend"""
        if self._progress_cb:
            await self._progress_cb(msg)

    def _build_profile_weights(self, profile: dict) -> dict[str, float]:
        """将 22 维画像聚合为 6 维评分权重"""
        dimensions = profile.get("dimensions", {})
        if not dimensions:
            return {}
        aggregated = {}
        for six_dim, profile_dims in PROFILE_TO_SIX_DIM_MAP.items():
            weights = [dimensions.get(d, {}).get("weight", 0.5) for d in profile_dims if d in dimensions]
            aggregated[six_dim] = sum(weights) / len(weights) if weights else 0.5
        # 归一化到 sum=1
        total = sum(aggregated.values())
        if total > 0:
            aggregated = {k: v / total for k, v in aggregated.items()}
        return aggregated

    def _build_profile_rubric(self, profile: dict) -> str:
        """基于画像生成评分标准描述"""
        dimensions = profile.get("dimensions", {})
        if not dimensions:
            return ""
        parts = ["\n【画像驱动评分标准】"]
        for six_dim, profile_dims in PROFILE_TO_SIX_DIM_MAP.items():
            label = WEIGHT_LABELS.get(six_dim, six_dim)
            recs = []
            for d in profile_dims:
                dim_data = dimensions.get(d, {})
                rec = dim_data.get("recommended", "")
                if rec:
                    if isinstance(rec, list):
                        recs.append(f"{d}: {', '.join(str(x) for x in rec)}")
                    elif isinstance(rec, dict):
                        recs.append(f"{d}: {rec.get('min', '?')}-{rec.get('max', '?')}")
                    else:
                        recs.append(f"{d}: {rec}")
            if recs:
                parts.append(f"  {label}理想候选人: {'; '.join(recs)}")
        return "\n".join(parts)

    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        jd = data.get("jd", {})
        resumes = data.get("resumes", [])
        role = data.get("role", "")
        memory_context = data.get("memory_context", "")
        pipeline_id = data.get("pipeline_id", input.pipeline_id)

        if not resumes:
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"candidates": [], "status": "no_resumes"},
                duration_ms=int((time.time() - start) * 1000),
            )

        # 本体规则
        ontology = get_ontology_engine(pipeline_id)
        ontology_context = ontology.build_match_prompt_context(role)
        weights = ontology.get_scoring_weights(role)
        thresholds = ontology.get_screening_thresholds(role)

        # 画像驱动评估：如果上游 profile_build 产出了画像，用它覆盖默认权重
        profile = data.get("profile", {})
        profile_rubric = ""
        if profile and isinstance(profile, dict) and profile.get("dimensions"):
            profile_weights = self._build_profile_weights(profile)
            if profile_weights:
                weights = profile_weights
            profile_rubric = self._build_profile_rubric(profile)

        # KG 场景动态权重调整
        kg_context = input.params.get("kg_context", {})
        is_service = False
        if kg_context:
            scenarios = kg_context.get("scenarios", [])
            scenario_ids = [s["id"] for s in scenarios]

            # 紧急招聘：经验权重提升
            if "s_urgent" in scenario_ids:
                weights["experience_score"] = min(weights.get("experience_score", 0.2) * 1.2, 0.4)
                weights["culture_score"] = weights.get("culture_score", 0.2) * 0.8

            # 管理岗：文化匹配权重提升
            if "s_management" in scenario_ids:
                weights["culture_score"] = min(weights.get("culture_score", 0.2) * 1.2, 0.3)

            # 服务业场景：使用 service 权重预设 + 稳定性评分
            is_service = any(s in scenario_ids for s in ["s_tea_beverage", "s_store_frontline", "s_food_retail"])
            if is_service:
                from ontology.engine import ROLE_WEIGHT_PRESETS

                service_weights = ROLE_WEIGHT_PRESETS.get("service", {})
                if service_weights:
                    weights = service_weights

        # 知识库检索：找匹配标准和行业基准
        kb = get_knowledge_base()
        kb_results = kb.search(f"{role} 候选人评估 匹配标准 面试评分", top_k=3)
        if kb_results:
            kb_results = [k for k in kb_results if k.get("score", 0) > 0.3 or len(kb_results) <= 1]
        kb_context = ""
        if kb_results:
            kb_context = "\n【知识库参考】\n" + "\n".join(f"- [{k['title']}] {k['content'][:150]}" for k in kb_results)

        jd_text = json.dumps(jd, ensure_ascii=False, indent=2) if isinstance(jd, dict) else str(jd)
        resumes_text = "\n\n".join(
            [
                f"【{i + 1}号 - {r['name']}】{r.get('years_experience', 0)}年 · {r.get('current_company', '')} · {r.get('current_salary', '')}\n学历：{r.get('education', '未提及')} · {r.get('major', '未提及')}\n技能：{', '.join(r.get('skills', []))}\n简历：{r.get('resume_text', '')}"
                for i, r in enumerate(resumes)
            ]
        )

        memory_section = f"\n\n【历史匹配经验】\n{memory_context}" if memory_context else ""

        # 检测岗位类型（后续多处使用）
        role_type = ontology.detect_role_type(role)

        # 薪资未知时的兜底引导
        salary_range = jd.get("salary_range", "") if isinstance(jd, dict) else ""
        salary_unknown = not salary_range or any(
            kw in str(salary_range) for kw in ["市场", "面议", "待定", "competitive"]
        )

        salary_guidance = ""
        if salary_unknown:
            salary_guidance = """
【薪资评估说明】
本岗位薪资范围为「根据市场情况/面议」，请按以下标准评估薪资风险：
- 参考候选人当前薪资和行业水平，判断其期望是否合理
- 如果候选人当前薪资明显高于行业平均，标记为高风险
- 如果候选人当前薪资在合理范围内，标记为低风险
- 重点关注候选人的薪资期望是否与公司支付能力匹配
"""

        # 构建权重描述（使用标签映射，兼容新旧维度，技术岗保留原始标签名）
        labels = (
            WEIGHT_LABELS
            if role_type == "technical"
            else {
                "tech_score": "专业能力匹配度",
                "experience_score": "经验匹配度",
                "education_score": "学历背景",
                "major_match_score": "专业匹配度",
                "culture_score": "文化匹配度",
                "salary_risk": "薪资风险",
            }
        )
        weight_desc = ", ".join([f"{labels.get(k, k)}{int(v * 100)}%" for k, v in weights.items()])

        PERSONAS = {
            "technical": "你是一个在字节/阿里/腾讯工作过8年的资深技术招聘专家，阅人无数，评分精准。",
            "management": "你是一个在猎头行业工作10年的高管寻访专家，擅长评估战略思维、行业资源、经营能力和团队领导力。",
            "sales_marketing": "你是一个在消费品/零售/餐饮行业工作8年的资深运营招聘专家，精通流量运营、用户增长和平台规则。",
            "service": "你是一个在连锁餐饮/零售行业工作6年的一线招聘专家，了解门店运营和基层人才特点。",
            "admin": "你是一个在大型企业工作8年的行政人事招聘专家，擅长评估服务意识、沟通能力和细节执行力。",
            "general": "你是一个有8年跨行业经验的资深招聘专家。",
        }
        persona = PERSONAS.get(role_type, PERSONAS["general"])

        system = f"""{persona}

{salary_guidance}{ontology_context}
{kb_context}

评分维度（严格打分，必须有区分度）：

技术匹配度(0-100)：
- 90+: 技能栈完全匹配JD，有深度实践经验（如JD要求React，候选人有3年React+源码级理解）
- 70-89: 核心技能匹配，有相关项目经验
- 50-69: 部分技能匹配，需要学习成本
- 30-49: 技能栈偏差较大
- 0-29: 完全不匹配（如JD要前端，候选人是纯后端）

经验匹配度(0-100)：
- 90+: 年限、项目规模、团队规模完全匹配
- 70-89: 年限略低但项目质量高
- 50-69: 年限或规模有明显差距
- 0-49: 经验严重不足

{EDUCATION_TIER_DESC}

文化匹配度(0-100)：
- 90+: 公司背景高度匹配（同级别大厂/同赛道创业公司）
- 70-89: 有相关行业经验
- 50-69: 跨行业但有可迁移能力
- 0-49: 背景差异过大

薪资风险(0-100，100=低风险)：
- 90+: 当前薪资在JD范围内，涨幅合理
- 70-89: 需要小幅溢价但可接受
- 50-69: 期望薪资可能超出预算
- 0-49: 薪资差距过大，大概率谈不拢

综合评分 = 加权总分（{weight_desc}）

入围线：综合分≥{thresholds["shortlist_min"]}
淘汰线：综合分<{thresholds["reject_below"]}

关键原则：
1. 角色错配直接低分 — 招前端来了后端，不管后端多牛都是低分
2. 要有梯度 — 不要所有人都70-80分，好的给90+，差的给30以下
3. red_flags要具体 — 不要写"经验不足"，要写"3年经验但无React项目经历"
4. interview_focus要可操作 — 不要写"技术能力"，要写"深挖其在XX项目中的架构决策"

区分度强制规则（必须遵守）：
- 候选人之间最高分与最低分差距必须≥30分
- 不允许出现3个以上候选人overall_score相同
- 如果所有候选人都很优秀，最高分必须≥90，最低优秀者≥75
- 如果所有候选人都一般，最高分不应超过75
- 每位候选人的reason必须独特，不允许出现雷同评价
- 每位候选人至少有1个独特维度使其与其他人区分开
{profile_rubric}

推荐理由必须引用画像维度（如'tech_stack匹配度高，有React+TypeScript实战经验'）。

输出严格的JSON数组。"""

        prompt = f"""岗位：{role}
JD要求：
{jd_text}

候选人简历：
{resumes_text}{memory_section}

请对每位候选人严格评分，输出JSON数组：
[
  {{
    "id": "候选人序号（1号写1，2号写2，以此类推）",
    "name": "姓名",
    "tech_score": 数字,
    "experience_score": 数字,
    "education_score": 数字,
    "major_match_score": 数字,
    "culture_score": 数字,
    "salary_risk": 数字,
    "overall_score": 数字,
    "reason": "具体评价（50字，要有数据支撑，如'6年全栈经验但无React项目'）",
    "red_flags": ["具体风险点（如'简历未体现任何B端产品经验'）"],
    "interview_focus": "面试重点（可操作的方向，如'深挖其在小米IoT平台的架构决策'）"
  }}
]"""

        await self._progress(f"正在评估 {len(resumes)} 位候选人与岗位匹配度...")

        def _validate_match(result):
            """Match 输出校验：基本结构检查 + 数量校验 + 区分度宽松"""
            scores = result if isinstance(result, list) else (result.get("raw", []) if isinstance(result, dict) else [])
            if not isinstance(scores, list) or len(scores) == 0:
                return False
            # 数量校验：LLM 漏返回候选人时必须重试
            if len(scores) < len(resumes):
                return False
            for s in scores:
                if not isinstance(s, dict):
                    return False
                overall = s.get("overall_score", -1)
                if not isinstance(overall, (int, float)) or not (0 <= overall <= 100):
                    return False
            # 区分度：仅当候选人≥3时才检查，且阈值放宽到10
            all_scores = [s.get("overall_score", 0) for s in scores if isinstance(s, dict)]
            if len(all_scores) >= 3 and (max(all_scores) - min(all_scores)) < 10:
                return False
            return True

        result = await self.call_llm_json(
            prompt, system, complexity="plus", validator=_validate_match, max_retries=2, timeout=60
        )

        scores = result if isinstance(result, list) else result.get("raw", [])
        if isinstance(scores, str):
            try:
                scores = json.loads(scores)
            except Exception:
                scores = []

        candidates = []

        # 调试：记录 LLM 返回内容
        score_list = scores if isinstance(scores, list) else []
        print(f"[Match] LLM returned {len(score_list)} scores for {len(resumes)} resumes", flush=True)

        # 用索引追踪已匹配的 score，比 id() 更可靠
        consumed_indices = set()

        for r_idx, r in enumerate(resumes):
            score = None
            r_id = r.get("id", "")
            r_name = r.get("name", "")

            # 策略1：序号匹配（LLM 返回的 id 字段是序号）
            seq = str(r_idx + 1)
            if isinstance(score_list, list):
                for i, s in enumerate(score_list):
                    if i not in consumed_indices and str(s.get("id", "")) == seq:
                        score = s
                        consumed_indices.add(i)
                        break

            # 策略2：精确姓名匹配
            if not score and r_name and isinstance(score_list, list):
                for i, s in enumerate(score_list):
                    if i not in consumed_indices and s.get("name") == r_name:
                        score = s
                        consumed_indices.add(i)
                        break

            # 策略3：模糊姓名匹配（包含关系）
            if not score and r_name and isinstance(score_list, list):
                for i, s in enumerate(score_list):
                    if i in consumed_indices:
                        continue
                    s_name = s.get("name", "")
                    if s_name and (r_name in s_name or s_name in r_name):
                        score = s
                        consumed_indices.add(i)
                        print(f"[Match] Fuzzy matched {r_name} -> {s_name}", flush=True)
                        break

            # 策略4：位置兜底 — LLM 按输入顺序输出，同数量时按序匹配
            if not score and isinstance(score_list, list) and r_idx < len(score_list):
                if r_idx not in consumed_indices:
                    score = score_list[r_idx]
                    consumed_indices.add(r_idx)
                    print(f"[Match] Position fallback: {r_name} -> scores[{r_idx}]", flush=True)

            if not score:
                score = {}
                print(f"[Match] WARNING: No score matched for {r_name} (id={r_id})", flush=True)

            await self._progress(f"已评估 {r.get('name', '?')}：综合分 {score.get('overall_score', 0)}")

            candidate = {
                **r,
                "tech_score": score.get("tech_score", 0),
                "experience_score": score.get("experience_score", 0),
                "education_score": score.get("education_score", 0),
                "major_match_score": score.get("major_match_score", 0),
                "culture_score": score.get("culture_score", 0),
                "salary_risk": score.get("salary_risk", 0),
                "overall_score": score.get("overall_score", 0),
                "reason": score.get("reason", "评分解析异常"),
                "red_flags": score.get("red_flags", []),
                "interview_focus": score.get("interview_focus", ""),
            }
            candidates.append(candidate)

        # 服务业场景：稳定性评分修正
        if is_service:
            for candidate in candidates:
                stability_factors = []

                # 因素1：上一份工作时长
                resume_text = candidate.get("resume_text", "")
                work_history = candidate.get("work_history", [])
                if work_history:
                    last_duration = work_history[0].get("duration_months", 0)
                else:
                    # 从简历文本推断（简单启发式）
                    import re as _re

                    dur_match = _re.search(r"(\d+)[年个]", resume_text)
                    last_duration = int(dur_match.group(1)) * 12 if dur_match else 0

                if last_duration >= 24:
                    stability_factors.append(100)
                elif last_duration >= 12:
                    stability_factors.append(90)
                elif last_duration >= 6:
                    stability_factors.append(80)
                elif last_duration >= 3:
                    stability_factors.append(60)
                elif last_duration > 0:
                    stability_factors.append(40)
                else:
                    stability_factors.append(50)

                # 因素2：同行业经验
                industry_exp = candidate.get("industry_experience", "") or resume_text
                if any(kw in industry_exp for kw in ["餐饮", "茶饮", "奶茶", "咖啡", "火锅", "食材", "零售"]):
                    stability_factors.append(90)
                elif any(kw in industry_exp for kw in ["零售", "服务", "酒店", "超市"]):
                    stability_factors.append(75)
                else:
                    stability_factors.append(50)

                # 因素3：通勤便利
                distance = candidate.get("commute_distance_km", None)
                if distance is not None:
                    if distance <= 3:
                        stability_factors.append(90)
                    elif distance <= 5:
                        stability_factors.append(80)
                    elif distance <= 10:
                        stability_factors.append(60)
                    else:
                        stability_factors.append(40)
                else:
                    stability_factors.append(60)

                stability_score = round(sum(stability_factors) / len(stability_factors), 1)
                candidate["stability_score"] = stability_score

                # 稳定性占 25%
                original_score = candidate.get("overall_score", 0)
                candidate["overall_score"] = round(0.75 * original_score + 0.25 * stability_score, 1)

        candidates.sort(key=lambda x: x["overall_score"], reverse=True)

        shortlist_min = thresholds["shortlist_min"]
        reject_below = thresholds["reject_below"]

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "candidates": candidates,
                "shortlisted": [c for c in candidates if c["overall_score"] >= shortlist_min],
                "rejected": [c for c in candidates if c["overall_score"] < reject_below],
                "thresholds": thresholds,
                "weights": weights,
                "status": "completed",
            },
            duration_ms=int((time.time() - start) * 1000),
        )
