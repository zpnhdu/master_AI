"""面试副驾驶 - 面试官的AI助手（参考北森 AI面试助手）

功能：
1. 面试前：秒看简历 + 推荐面试题 + 风险点提示
2. 面试中：实时追问建议 + 回答质量评估
3. 面试后：自动生成面试评价 + 评分卡

北森的核心差异化：
- 面试前：秒看简历，推荐贴合岗位的面试题
- 面试中：实时转写 + 深度追问建议
- 面试后：自动生成面试评价
"""

import json
from typing import Any

from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


class InterviewCopilot(BaseAgent):
    """面试副驾驶 — 面试官的AI实时助手"""

    async def run(self, input: ToolInput) -> ToolOutput:
        """Dispatch to the appropriate copilot method based on params."""
        try:
            action = input.params.get("action", "briefing")
            if action == "followup":
                result = await self.suggest_followup({"context": input.context, **input.params})
            elif action == "evaluate":
                result = await self.generate_evaluation({"context": input.context, **input.params})
            else:
                result = await self.prepare_briefing({"context": input.context, **input.params})
            return ToolOutput(status=AgentStatus.SUCCESS, data=result)
        except Exception as e:
            return ToolOutput(status=AgentStatus.FAILED, error=str(e))

    async def prepare_briefing(self, context: dict[str, Any]) -> dict[str, Any]:
        """面试前准备：秒看简历 + 风险点 + 推荐问题"""
        candidate = context.get("candidate", {})
        jd = context.get("jd", {})
        role = context.get("role", "")
        interview_questions = context.get("interview_questions", [])

        system = """你是一个资深面试官的AI助手。你的任务是在面试前帮面试官快速了解候选人。

核心原则：
1. 30秒内让面试官掌握候选人关键信息
2. 突出与JD匹配/不匹配的关键点
3. 标注需要验证的风险点
4. 推荐最有价值的追问方向

输出JSON格式。"""

        prompt = f"""岗位：{role}
JD核心要求：{json.dumps(jd, ensure_ascii=False)[:500] if isinstance(jd, dict) else str(jd)[:500]}

候选人：{candidate.get("name", "")}
经验：{candidate.get("years_experience", 0)}年 · {candidate.get("current_company", "")}
技能：{", ".join(candidate.get("skills", []))}
AI匹配评分：综合{candidate.get("overall_score", 0)}分
AI评价：{candidate.get("reason", "")}
风险点：{", ".join(candidate.get("red_flags", []))}
面试重点：{candidate.get("interview_focus", "")}

已准备的面试题：
{json.dumps(interview_questions[:3], ensure_ascii=False)[:500] if interview_questions else "无"}

请生成面试官简报：
{{
    "candidate_snapshot": "50字候选人快照（如：5年React经验，字节背景，综合85分，核心风险：无B端经验）",
    "key_matches": ["与JD高度匹配的3个关键点"],
    "risk_points": ["需要面试验证的3个风险点"],
    "must_ask_questions": [
        {{
            "question": "必须追问的问题",
            "reason": "为什么要问这个（20字）",
            "what_to_listen_for": "听什么（期望的回答方向）"
        }}
    ],
    "interview_strategy": "面试策略建议（30字，如：先从项目深挖入手，重点验证B端经验真实性）",
    "red_flag_verification": [
        {{
            "flag": "风险点描述",
            "verification_question": "验证性提问",
            "positive_signal": "正面信号（说明风险不存在）",
            "negative_signal": "负面信号（确认风险存在）"
        }}
    ],
    "interviewer_checklist": ["□ 确认候选人当前公司和职级", "□ 验证XX项目中的具体角色", "□ 追问跳槽原因（风险点）", "□ 考察系统设计能力（必考）"]
}}"""
        result = await self.call_llm_json(prompt, system, complexity="plus")
        if isinstance(result, dict) and "candidate_snapshot" in result:
            return {"status": "completed", "briefing": result}
        return {"status": "error", "briefing": {}}

    async def suggest_followup(self, context: dict[str, Any]) -> dict[str, Any]:
        """面试中追问建议：根据候选人回答给出追问方向"""
        question = context.get("question", "")
        answer = context.get("answer", "")
        candidate = context.get("candidate", {})
        role = context.get("role", "")
        elapsed_minutes = context.get("elapsed_minutes", 0)
        total_minutes = context.get("total_minutes", 60)
        remaining_minutes = max(0, total_minutes - elapsed_minutes)

        system = """你是面试中的AI实时助手。根据候选人的回答，给面试官提供追问建议。

核心原则：
1. 判断回答质量（是否具体、是否有数据、是否有深度）
2. 识别回答中的可疑点（可能是编造的）
3. 给出2-3个精准追问方向
4. 使用北森三层追问法：结果层→行为层→动机层

输出JSON格式。"""

        prompt = f"""岗位：{role}
候选人：{candidate.get("name", "")}

面试官问题：{question}
候选人回答：{answer[:1000]}

面试进度：已进行{elapsed_minutes}分钟，剩余{remaining_minutes}分钟

请分析回答并给出追问建议：
{{
    "answer_quality": "优秀/良好/一般/较差",
    "quality_score": 0-100,
    "strengths": ["回答中的亮点（1-2个）"],
    "weaknesses": ["回答中的不足（1-2个）"],
    "suspicious_points": ["可疑点（如有）"],
    "followup_suggestions": [
        {{
            "layer": "结果层/行为层/动机层",
            "question": "追问问题",
            "purpose": "追问目的（15字）"
        }}
    ],
    "real_time_note": "给面试官的实时备注（20字，如：回答缺少具体数据，建议追问量化结果）",
    "time_management": {{
        "elapsed_minutes": {elapsed_minutes},
        "remaining_minutes": {remaining_minutes},
        "suggestion": "根据剩余时间的面试节奏建议（如：建议花15分钟在系统设计题上）"
    }}
}}"""
        result = await self.call_llm_json(prompt, system, complexity="flash")
        if isinstance(result, dict) and "followup_suggestions" in result:
            return {"status": "completed", "followup": result}
        return {"status": "error", "followup": {}}

    async def generate_evaluation(self, context: dict[str, Any]) -> dict[str, Any]:
        """面试后评价：自动生成面试评价和评分卡"""
        candidate = context.get("candidate", {})
        role = context.get("role", "")
        qa_history = context.get("qa_history", [])
        eval_form = context.get("evaluation_form", [])
        peer_data = context.get("peer_comparison_data", {})

        system = """你是面试评价专家。基于面试问答记录，生成结构化的面试评价。

核心原则：
1. 每个评分维度必须有证据支撑（引用具体回答）
2. 评分要有区分度（不要都给3-4分）
3. 最终建议要明确
4. 使用1-5分制，每个分数对应明确的行为描述

输出JSON格式。"""

        qa_text = (
            "\n".join(
                [
                    f"Q{i + 1}: {qa.get('question', '')}\nA{i + 1}: {qa.get('answer', '')}"
                    for i, qa in enumerate(qa_history)
                ]
            )
            if qa_history
            else "无面试记录"
        )

        eval_dims_text = ""
        if eval_form:
            eval_dims_text = "评估维度：" + ", ".join([f"{d['name']}({int(d['weight'] * 100)}%)" for d in eval_form])

        peer_text = ""
        if peer_data:
            peer_text = f"\n横向对比：已评估{peer_data.get('total', 0)}人，当前排名第{peer_data.get('rank', '?')}名"

        prompt = f"""岗位：{role}
候选人：{candidate.get("name", "")}
{eval_dims_text}{peer_text}

面试问答记录：
{qa_text[:3000]}

请生成面试评价：
{{
    "dimension_scores": [
        {{
            "dimension": "维度名称",
            "score": 1-5,
            "evidence": "评分证据（引用候选人具体回答，30字）",
            "behavioral_description": "行为描述（20字，如：能用STAR法清晰描述项目经验）"
        }}
    ],
    "overall_score": 1-5,
    "overall_comment": "总体评价（80字）",
    "key_highlights": ["面试亮点（2-3个）"],
    "key_concerns": ["面试顾虑（1-2个）"],
    "recommendation": "强烈推荐/推荐/待定/不推荐",
    "next_step": "建议下一步（如：建议安排技术总监终面，重点考察系统设计能力）",
    "comparison_note": "与其他候选人对比备注（如有）",
    "peer_comparison": {{
        "this_candidate_rank": {peer_data.get("rank", 0)},
        "total_evaluated": {peer_data.get("total", 0)},
        "strongest_dimension": "该候选人最强维度名称",
        "weakest_dimension": "该候选人最弱维度名称"
    }}
}}"""
        result = await self.call_llm_json(prompt, system, complexity="plus")
        if isinstance(result, dict) and "dimension_scores" in result:
            return {"status": "completed", "evaluation": result}
        return {"status": "error", "evaluation": {}}
