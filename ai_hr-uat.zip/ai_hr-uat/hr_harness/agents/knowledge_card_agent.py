"""Knowledge Card Agent - Generate school/company profiles using LLM built-in knowledge"""

import re

from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


class KnowledgeCardAgent(BaseAgent):
    async def run(self, input: ToolInput) -> ToolOutput:
        context = dict(input.params)
        for stage_output in input.context.values():
            if isinstance(stage_output, dict):
                context.update(stage_output)
        resumes = context.get("resumes", [])

        if not resumes:
            return ToolOutput(status=AgentStatus.SUCCESS, data={"knowledge_cards": [], "status": "no_resumes"})

        # 从简历中提取学校和公司名
        entities = self._extract_entities(resumes)

        if not entities:
            return ToolOutput(status=AgentStatus.SUCCESS, data={"knowledge_cards": [], "status": "no_entities"})

        # 为每个实体生成知识卡片
        cards = []
        for entity in entities:
            card = await self._generate_card(entity)
            if card:
                cards.append(card)

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={"knowledge_cards": cards, "status": "completed"},
        )

    def _extract_entities(self, resumes: list[dict]) -> list[dict]:
        """从简历中提取学校和公司名称"""
        seen = set()
        entities = []

        for resume in resumes:
            # 学校
            education = resume.get("education", "")
            school = resume.get("school", "")
            school_name = school or self._extract_school(education)
            if school_name and school_name not in seen and len(school_name) >= 2:
                seen.add(school_name)
                entities.append({"name": school_name, "type": "school"})

            # 公司
            company = resume.get("current_company", "") or resume.get("company", "")
            if company and company not in seen and len(company) >= 2:
                seen.add(company)
                entities.append({"name": company, "type": "company"})

        return entities

    def _extract_school(self, education_text: str) -> str:
        """从学历文本中提取学校名"""
        if not education_text:
            return ""
        # 常见学校关键词匹配
        patterns = [
            r"([一-龥]{2,10}(?:大学|学院|University|Institute))",
            r"((?:清华|北大|复旦|浙大|上交|中科大|南大|武大|华中科技|西安交大|哈工大)[一-龥]*)",
        ]
        for pattern in patterns:
            match = re.search(pattern, education_text)
            if match:
                return match.group(1)
        return ""

    async def _generate_card(self, entity: dict) -> dict:
        """为单个实体生成知识卡片"""
        name = entity["name"]
        entity_type = entity["type"]

        if entity_type == "school":
            system = """你是教育领域专家。用 2-3 句话简要介绍这所学校：
1. 学校层次（985/211/双一流/QS排名）
2. 优势学科
3. 知名校友或行业影响力
输出 JSON：{"description": "简介", "highlights": ["亮点1", "亮点2"], "tier": "学校层次"}
简洁专业，不超过 80 字。"""
            prompt = f"介绍这所学校：{name}"
        else:
            system = """你是商业领域专家。用 2-3 句话简要介绍这家公司：
1. 公司规模和行业地位
2. 核心业务/产品
3. 技术实力或行业影响力
输出 JSON：{"description": "简介", "highlights": ["亮点1", "亮点2"], "tier": "公司层次"}
简洁专业，不超过 80 字。"""
            prompt = f"介绍这家公司：{name}"

        result = await self.call_llm_json(prompt, system, complexity="flash")

        if not isinstance(result, dict):
            return None

        return {
            "entity_name": name,
            "entity_type": entity_type,
            "description": result.get("description", ""),
            "highlights": result.get("highlights", []),
            "tier": result.get("tier", ""),
        }
