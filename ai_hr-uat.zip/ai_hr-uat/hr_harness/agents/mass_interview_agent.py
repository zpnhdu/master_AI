"""Mass Interview Agent — 锅圈岗位出题 + 实时评分 + 追问逻辑.

Designed for high-volume, mobile-first interview scenarios.
Generates role-specific interview questions per candidate, scores each answer in real-time.
"""

import json
from typing import Optional

# ── 锅圈岗位模板 ──────────────────────────────────────────

ROLE_TEMPLATES = {
    "stir_fry_gm": {
        "name": "小炒事业部总经理",
        "question_count": 3,
        "duration_minutes": 18,
        "time_limit_seconds": 300,
        "eval_dims": {
            "战略规划": 0.30,
            "运营管理": 0.30,
            "行业认知": 0.20,
            "领导力": 0.20,
        },
        "question_dim_map": {
            0: "行业认知",
            1: "运营管理",
            2: "战略规划",
        },
        "scoring_hint": "考察连锁餐饮管理经验、炒菜机器人等智能设备认知、加盟体系搭建能力。要有具体方法论和数据思维。",
        "questions": [
            {
                "type": "行业认知",
                "text": "你如何看待炒菜机器人外卖这个赛道？和传统餐饮外卖相比，核心差异在哪里？",
                "tts_prefix": "好的，第一题：",
                "focus": "行业认知",
                "expected_points": ["对赛道的理解深度", "能对比传统外卖模式", "有行业趋势判断"],
            },
            {
                "type": "运营管理",
                "text": "如果让你从零搭建一个加盟门店的运营体系，你会从哪几个方面入手？",
                "tts_prefix": "好的，第二题：",
                "focus": "运营管理",
                "expected_points": ["有体系化思路", "涵盖标准、培训、监督", "考虑成本与效率平衡"],
            },
            {
                "type": "战略规划",
                "text": "给你一个省区市场，第一年要开出50家门店并实现盈利，你的打法和节奏是怎样的？",
                "tts_prefix": "好的，最后一题：",
                "focus": "战略规划",
                "expected_points": ["有阶段性目标拆解", "考虑选址和供应链", "风险预判和应对"],
            },
        ],
        "sample_questions": [
            "你如何看待炒菜机器人外卖这个赛道？",
            "从零搭建加盟门店运营体系，你会从哪入手？",
            "第一年50家门店的打法和节奏是怎样的？",
        ],
    },
    "camping_gm": {
        "name": "文旅露营总经理",
        "question_count": 3,
        "duration_minutes": 18,
        "time_limit_seconds": 300,
        "eval_dims": {
            "战略规划": 0.30,
            "商务拓展": 0.25,
            "行业认知": 0.25,
            "团队管理": 0.20,
        },
        "question_dim_map": {
            0: "行业认知",
            1: "商务拓展",
            2: "战略规划",
        },
        "scoring_hint": "考察文旅露营行业经验、政企合作能力、从0到1项目落地经验。要有具体的项目案例和数据。",
        "questions": [
            {
                "type": "行业认知",
                "text": "露营行业这两年竞争很激烈，你认为锅圈做露营的核心差异化优势在哪里？",
                "tts_prefix": "好的，第一题：",
                "focus": "行业认知",
                "expected_points": ["对竞争格局有判断", "能结合锅圈资源分析", "有差异化思路"],
            },
            {
                "type": "商务拓展",
                "text": "你要去谈一个景区合作，对方已经有其他露营品牌入驻了，你怎么说服他们选择我们？",
                "tts_prefix": "好的，第二题：",
                "focus": "商务拓展",
                "expected_points": ["有谈判策略", "能突出自身优势", "考虑长期合作模式"],
            },
            {
                "type": "战略规划",
                "text": "第一年要做10个营地，每个都要盈利，你的选址逻辑和运营模型是怎样的？",
                "tts_prefix": "好的，最后一题：",
                "focus": "战略规划",
                "expected_points": ["有清晰的选址标准", "有盈利模型思考", "考虑规模化节奏"],
            },
        ],
        "sample_questions": [
            "锅圈做露营的核心差异化优势在哪里？",
            "怎么说服景区选择我们的露营品牌？",
            "10个营地的选址逻辑和运营模型？",
        ],
    },
    "admin_assistant": {
        "name": "行政助理前台",
        "question_count": 2,
        "duration_minutes": 12,
        "time_limit_seconds": 300,
        "eval_dims": {
            "沟通表达": 0.35,
            "服务意识": 0.35,
            "执行力": 0.30,
        },
        "question_dim_map": {
            0: "服务意识",
            1: "执行力",
        },
        "scoring_hint": "考察沟通表达能力、服务意识、应变能力。形象气质和普通话是加分项，但面试主要看态度和逻辑。",
        "questions": [
            {
                "type": "情景模拟",
                "text": "同时有三件事：一位重要访客到了、电话一直在响、领导让你马上打印一份文件。你会怎么处理？",
                "tts_prefix": "好的，第一题：",
                "focus": "服务意识",
                "expected_points": ["能分清优先级", "有具体处理顺序", "体现服务意识"],
            },
            {
                "type": "态度测试",
                "text": "行政工作有时候很琐碎，比如订水、修打印机、跑腿盖章，你怎么看这些工作？能长期做吗？",
                "tts_prefix": "好的，最后一题：",
                "focus": "执行力",
                "expected_points": ["对行政工作有正确认知", "不排斥琐碎事务", "有长期职业规划"],
            },
        ],
        "sample_questions": [
            "同时有三件事要处理，你会怎么做？",
            "你怎么看行政工作中的琐碎事务？",
        ],
    },
    "private_domain_director": {
        "name": "私域运营总监",
        "question_count": 3,
        "duration_minutes": 18,
        "time_limit_seconds": 300,
        "eval_dims": {
            "运营策略": 0.35,
            "数据分析": 0.25,
            "用户增长": 0.25,
            "团队管理": 0.15,
        },
        "question_dim_map": {
            0: "运营策略",
            1: "用户增长",
            2: "数据分析",
        },
        "scoring_hint": "考察私域运营方法论、用户生命周期管理、GMV转化经验。要有具体数据和案例支撑。",
        "questions": [
            {
                "type": "运营策略",
                "text": "锅圈有几千家门店，每个店都有企业微信和社群，你会设计什么样的私域运营体系来串联门店和总部？",
                "tts_prefix": "好的，第一题：",
                "focus": "运营策略",
                "expected_points": ["有体系化框架", "总部与门店分工明确", "有SOP和赋能思路"],
            },
            {
                "type": "用户增长",
                "text": "现在私域用户增长遇到瓶颈，新客获客成本越来越高，你有什么破局思路？请给一个具体的方案。",
                "tts_prefix": "好的，第二题：",
                "focus": "用户增长",
                "expected_points": ["有裂变或转介绍思路", "方案具体可落地", "有成本意识"],
            },
            {
                "type": "数据分析",
                "text": "如果你发现私域用户的复购率连续三个月下降，你会从哪些数据维度去分析原因？",
                "tts_prefix": "好的，最后一题：",
                "focus": "数据分析",
                "expected_points": ["有数据维度拆解", "不只描述现象要推断原因", "有改进方向"],
            },
        ],
        "sample_questions": [
            "你会设计什么样的私域体系串联门店和总部？",
            "私域用户增长遇到瓶颈怎么破局？",
            "复购率连续下降，从哪些维度分析？",
        ],
    },
    "thirdparty_ops_manager": {
        "name": "三方运营高级经理",
        "question_count": 3,
        "duration_minutes": 18,
        "time_limit_seconds": 300,
        "eval_dims": {
            "平台运营": 0.35,
            "数据分析": 0.25,
            "资源整合": 0.25,
            "执行力": 0.15,
        },
        "question_dim_map": {
            0: "平台运营",
            1: "资源整合",
            2: "数据分析",
        },
        "scoring_hint": "考察美团饿了么抖音等平台运营经验、ROI优化能力、服务商管理经验。要有具体的平台数据和案例。",
        "questions": [
            {
                "type": "平台运营",
                "text": "美团、饿了么、抖音本地生活这三个平台的流量逻辑有什么不同？你的运营策略分别是什么？",
                "tts_prefix": "好的，第一题：",
                "focus": "平台运营",
                "expected_points": ["理解各平台差异", "有针对性策略", "不是泛泛而谈"],
            },
            {
                "type": "资源整合",
                "text": "你在管理服务商的时候遇到过什么棘手的情况？你是怎么处理的？",
                "tts_prefix": "好的，第二题：",
                "focus": "资源整合",
                "expected_points": ["有真实案例", "有管理方法", "体现谈判和协调能力"],
            },
            {
                "type": "数据分析",
                "text": "一个省区的线上订单量下降了15%，但GMV只降了5%，你怎么解读这个数据？下一步会做什么？",
                "tts_prefix": "好的，最后一题：",
                "focus": "数据分析",
                "expected_points": ["能解读客单价变化", "不只描述数据要行动", "有具体改进措施"],
            },
        ],
        "sample_questions": [
            "美团、饿了么、抖音的流量逻辑有什么不同？",
            "管理服务商遇到过什么棘手情况？",
            "订单量降15%但GMV只降5%，你怎么解读？",
        ],
    },
    "general": {
        "name": "通用岗位",
        "question_count": 3,
        "duration_minutes": 12,
        "time_limit_seconds": 180,
        "eval_dims": {
            "专业能力": 0.40,
            "问题解决": 0.35,
            "沟通表达": 0.25,
        },
        "question_dim_map": {
            0: "专业能力",
            1: "问题解决",
            2: "沟通表达",
        },
        "scoring_hint": "只依据岗位题目的评分锚点和候选人的回答证据评分，不补充未表达的信息。",
        "questions": [],
        "sample_questions": [],
    },
}


# ── 维度描述字典 ──────────────────────────────────────────────

DIM_DESCRIPTIONS = {
    "战略规划": "能否制定清晰的中长期目标和落地路径，有阶段性拆解和风险预判",
    "运营管理": "能否搭建体系化的运营框架，涵盖标准、流程、培训和监督",
    "行业认知": "对所在行业赛道的理解深度，能否判断竞争格局和趋势",
    "领导力": "能否带团队、分配任务、推动执行、处理冲突",
    "团队管理": "能否搭建和管理高效团队，有人员培养和激励方法",
    "商务拓展": "能否开拓和维护合作伙伴关系，有谈判和资源整合能力",
    "运营策略": "能否制定清晰的运营目标和执行策略，有体系化思维",
    "用户增长": "能否设计有效的用户增长和留存方案，有裂变和转化经验",
    "数据分析": "能否从数据中发现问题和机会，有数据驱动决策的能力",
    "平台运营": "能否理解和运用各平台的规则和流量逻辑，有针对性策略",
    "资源整合": "能否整合内外部资源达成目标，有服务商管理和商务谈判能力",
    "沟通表达": "说话是否清晰有条理，态度是否得体，能否让人听懂",
    "服务意识": "能否站在对方角度思考，主动提供帮助，处理突发情况",
    "执行力": "交代的事情能否落实到位，靠谱不敷衍，有闭环意识",
    "专业能力": "是否掌握岗位所需的核心知识和技能，能用具体经历或结果证明",
    "问题解决": "能否识别关键问题、形成可执行方案，并说明结果和复盘",
}


# ── 红线关键词/模式 ──────────────────────────────────────────

RED_FLAG_PATTERNS = [
    # 简历造假嫌疑
    ("经验", ["记不清了", "太久了忘了", "好像是", "大概吧"]),
    # 明显不尊重
    ("态度", ["随便", "无所谓", "都行", "不知道"]),
    # 明显短期过渡
    ("稳定性", ["先干着看看", "过渡一下", "骑驴找马", "干不了几天"]),
]


# ── 评分 rubric ──────────────────────────────────────────────

SCORING_RUBRIC_VERSION = "behavioral_v2"
VIDEO_FINAL_SCORE_VERSION = "valid_question_average_v1"


VIDEO_GENERAL_CRITERIA = (
    ("job_coverage", "岗位要点", 0.35),
    ("professional_accuracy", "专业准确性", 0.25),
    ("analytical_logic", "分析逻辑", 0.15),
    ("solution_feasibility", "方案可执行性", 0.15),
    ("evidence_boundaries", "证据与边界", 0.10),
)
VIDEO_SCORING_DIMENSIONS = {name: weight for _, name, weight in VIDEO_GENERAL_CRITERIA}
VIDEO_CRITERION_DIMENSIONS = {criterion_id: name for criterion_id, name, _ in VIDEO_GENERAL_CRITERIA}
VIDEO_SCORING_PRIMARY_DIMENSION = "五维综合评分"


def _general_criterion_anchors(criterion_id: str, expected_points: Optional[list[str]]) -> dict[str, str]:
    """Build observable 0-4 anchors for one universal video scoring facet."""
    points = [str(point).strip() for point in (expected_points or []) if str(point).strip()]
    points_text = "、".join(points) if points else "题目要求的核心内容"
    anchors = {
        "job_coverage": {
            "0": f"未回答，或内容与{points_text}无关",
            "1": f"仅零散提及{points_text}中的个别内容，没有实质说明",
            "2": f"覆盖部分要点，但关键内容缺失或展开不足：{points_text}",
            "3": f"覆盖大部分核心要点，说明较具体，基本满足题目要求：{points_text}",
            "4": f"完整覆盖核心要点或给出等价高质量回答，并清楚说明依据、取舍与结果：{points_text}",
        },
        "professional_accuracy": {
            "0": "核心概念或结论明显错误，无法支持岗位判断",
            "1": "存在较多专业错误，主要依赖空泛表述",
            "2": "基本概念正确，但关键判断、数据口径或方法存在不足",
            "3": "专业判断总体准确，方法适用，只有次要遗漏",
            "4": "专业判断准确严谨，能说明适用条件、关键假设及例外情况",
        },
        "analytical_logic": {
            "0": "没有形成可理解的分析过程",
            "1": "观点堆砌，前后关系不清，结论缺少依据",
            "2": "有基本结构，但因果链、优先级或关键推导不完整",
            "3": "结构清晰，能从问题拆解到结论，主要推导有依据",
            "4": "分析层次清晰，能比较方案、处理权衡并验证关键假设",
        },
        "solution_feasibility": {
            "0": "没有提出有效方案或结论",
            "1": "只有方向性口号，没有具体动作",
            "2": "提出基本步骤，但缺少资源、优先级、指标或落地条件",
            "3": "方案步骤明确，包含关键资源、优先级或验证指标，可以实际执行",
            "4": "方案完整可执行，明确阶段、资源、衡量指标及调整机制",
        },
        "evidence_boundaries": {
            "0": "没有任何依据，或使用明显虚构、矛盾的信息",
            "1": "只有主观判断，没有案例、数据、验证方式或边界说明",
            "2": "有少量依据，但证据较弱，未说明风险或适用边界",
            "3": "提供可信案例、数据或验证方法，并识别主要风险或边界",
            "4": "证据充分可核验，主动说明数据口径、限制条件、风险及复盘方式",
        },
    }
    return anchors[criterion_id]


def build_video_scoring_rubric(expected_points: Optional[list[str]], question_dimension: str = "") -> dict:
    """Build the frozen five-facet rubric shared by every video question."""
    return {
        "version": SCORING_RUBRIC_VERSION,
        "criteria": [
            {
                "id": criterion_id,
                "name": name,
                "dimension": name,
                "weight": weight,
                "anchors": _general_criterion_anchors(criterion_id, expected_points),
            }
            for criterion_id, name, weight in VIDEO_GENERAL_CRITERIA
        ],
    }


def _normalize_scoring_rubric(
    scoring_rubric: Optional[dict],
    expected_points: Optional[list[str]],
    primary_dim: str,
) -> dict:
    """Return the current universal rubric; legacy/custom rubrics are not reused."""
    return build_video_scoring_rubric(expected_points, primary_dim or "综合表现")


# ── 出题 system prompt ───────────────────────────────────────

GEN_QUESTIONS_SYSTEM = """你是一个资深面试出题专家。你的任务是为候选人生成岗位针对性强、能考察真实能力的面试题。

出题原则：
1. 岗位针对性：每道题要紧密结合岗位职责和任职要求来设计
2. 情景化：用真实工作场景出题，让候选人能想象具体画面
3. 开放性：不要问"是/否"题，要引导候选人多说、说深
4. 递进深度：3道题应该由浅入深，最后一题考察战略高度
5. 口语化但专业：题目口语化，但考察点要专业

按给定JSON格式输出。每题除了题面，还必须包含可观察、可区分的0-4级行为锚点；不要使用“较好”“有深度”等无法验证的空泛描述。"""


GEN_QUESTIONS_USER = """请为以下候选人生成{question_count}道面试题：

候选人姓名：{candidate_name}
应聘岗位：{role}
岗位类型：{job_family}
工作年限：{years}年
过往经验：{experience}

{template_hint}

输出JSON数组，每道题格式：
{{
  "type": "行业认知/运营管理/战略规划/情景模拟/案例分析/行为面试",
  "question": "题目文本（口语化，50字以内）",
  "expected_points": ["要点1", "要点2", "要点3"],
  "scoring_rubric": {{
    "version": "behavioral_v2",
    "criteria": "由程序统一生成岗位要点、专业准确性、分析逻辑、方案可执行性、证据与边界五项标准"
  }},
  "time_limit_seconds": 300,
  "answer_mode": "video"
}}

只输出JSON数组，不要其他文字。"""


# ── 评分 system prompt（动态维度版）──────────────────────────

SCORE_ANSWER_SYSTEM = """你是{role_name}岗位面试评分证据分析专家。

本题主要考察维度：{primary_dim}
该维度评分标准：{dim_description}

评分原则：
1. 只依据候选人回答中可观察的证据判断，不得补充候选人未表达的信息。
2. 逐项对照0-4级行为锚点选择level，不直接给百分制总分；最终分数由程序确定性计算。
3. evidence必须引用或忠实概括回答中的依据；没有证据时不能给3级或4级。
4. 数据不是所有题目的必需项；只有评分项明确要求数据时，缺少数据才影响该项。
5. 语速、口音、音量和停顿不得影响专业能力分；只有“沟通表达”评分项可谨慎参考语音特征。
6. 评分信息不足或ASR文本明显异常时，应降低confidence，不要猜测。

风险判断：
- 只有回答中存在明确、可引用的严重矛盾、歧视违法意图或诚信问题，才能标记high/critical。
- “记不清”“好像是”或短期求职意向本身只能作为review风险，不能单独认定造假或严重红线。
- 每个风险必须包含evidence和confidence；证据不足时返回空数组。

输出合法JSON，不要Markdown或其他文字。"""


SCORE_ANSWER_USER = """题目：{question}
本题考察维度：{primary_dim}
期望要点：{expected_points}
结构化评分锚点：{scoring_rubric}

候选人{name}的回答：{answer}

{audio_features_hint}

请逐项判断档位并给出证据。level只能是0、1、2、3、4；confidence范围为0-1。

输出JSON：
{{
  "criteria": [
    {{"id": "与评分锚点一致", "level": 3, "evidence": "回答中的具体依据", "confidence": 0.85}}
  ],
  "overall_confidence": 0.85,
  "red_flags": [
    {{"type": "诚信风险", "severity": "review/high/critical", "evidence": "候选人原话", "confidence": 0.9}}
  ],
  "comment": "面向HR的证据化评语",
  "candidate_feedback": "面向候选人的改进建议"
}}"""


# ── Agent 类 ────────────────────────────────────────────────


class MassInterviewAgent:
    """百人面试出题+评分Agent。轻量级，不继承BaseAgent（独立调用模式）。"""

    def __init__(self, llm_client=None):
        self.llm = llm_client

    def _get_llm(self):
        if self.llm:
            return self.llm
        from hermes_wrapper.client import HermesClient

        return HermesClient()

    def detect_job_family(self, role: str) -> str:
        """Detect job family from role name — matches the 5 锅圈 roles."""
        role_lower = role.lower()
        families = [
            ("stir_fry_gm", ["小炒", "炒菜", "事业部总经理", "餐饮总经理"]),
            ("camping_gm", ["露营", "文旅", "营地"]),
            ("admin_assistant", ["行政", "前台", "助理"]),
            ("private_domain_director", ["私域", "运营总监"]),
            ("thirdparty_ops_manager", ["三方", "第三方", "平台运营", "高级经理"]),
        ]
        for family, keywords in families:
            if any(kw in role_lower for kw in keywords):
                return family
        return "general"

    def get_template(self, role: str) -> dict:
        """Get role template for the given role."""
        family = self.detect_job_family(role)
        return ROLE_TEMPLATES.get(family, ROLE_TEMPLATES["general"])

    async def generate_questions(
        self,
        candidate_name: str,
        role: str,
        resume_text: str = "",
        years: str = "",
        question_count: int = None,
    ) -> list[dict]:
        """Generate interview questions for a candidate — now takes fixed questions from template (no LLM call).

        Returns list of question dicts with type, question, tts_prefix, focus, expected_points,
        time_limit_seconds, and answer_mode fields.
        """
        template = self.get_template(role)
        fixed_questions = template.get("questions", [])
        time_limit = template.get("time_limit_seconds", 300)

        if not fixed_questions:
            # 降级处理：生成失败时使用模板示例问题，并补齐当前版行为锚点。
            return self._fallback_questions(template, question_count or template.get("question_count", 5))

        result = []
        for i, q in enumerate(fixed_questions):
            expected_points = q.get("expected_points", ["回答清晰", "态度积极"])
            primary_dim = q.get("focus", "")
            result.append(
                {
                    "type": q.get("type", "情景模拟"),
                    "question": q["text"],
                    "tts_prefix": q.get("tts_prefix", ""),
                    "focus": primary_dim,
                    "expected_points": expected_points,
                    "scoring_rubric": _normalize_scoring_rubric(q.get("scoring_rubric"), expected_points, primary_dim),
                    "time_limit_seconds": time_limit,
                    "answer_mode": "video",
                }
            )

        # 已指定 question_count 时应用问题数量限制
        if question_count and question_count < len(result):
            result = result[:question_count]

        return result

    def _fallback_questions(self, template: dict, count: int) -> list[dict]:
        """Generate fallback questions from template samples."""
        samples = template.get("sample_questions", [])
        qtypes = template.get("question_types", ["情景模拟", "行为面试", "态度测试"])
        questions = []
        for i in range(min(count, len(samples))):
            expected_points = ["回答清晰", "有具体例子", "态度积极"]
            primary_dim = qtypes[i % len(qtypes)] if qtypes else "综合表现"
            questions.append(
                {
                    "type": primary_dim,
                    "question": samples[i],
                    "expected_points": expected_points,
                    "scoring_rubric": _normalize_scoring_rubric(None, expected_points, primary_dim),
                    "time_limit_seconds": 300,
                    "answer_mode": "video",
                }
            )
        while len(questions) < count:
            expected_points = ["动机明确", "了解岗位", "态度积极"]
            questions.append(
                {
                    "type": "态度测试",
                    "question": "你为什么想做这份工作？你觉得自己的优势是什么？",
                    "expected_points": expected_points,
                    "scoring_rubric": _normalize_scoring_rubric(None, expected_points, "综合表现"),
                    "time_limit_seconds": 300,
                    "answer_mode": "text",
                }
            )
        return questions

    @staticmethod
    def technical_failure_result(rubric: dict, primary_dim: str, reason: str) -> dict:
        """Represent an unavailable ASR/model result as a transparent zero-score answer."""
        criteria = [
            {
                "id": criterion["id"],
                "name": criterion["name"],
                "dimension": criterion["dimension"],
                "weight": criterion["weight"],
                "level": 0,
                "score": 0,
                "evidence": f"系统异常：{reason}",
                "confidence": 0.0,
            }
            for criterion in rubric["criteria"]
        ]
        return {
            "score": 0,
            "level": "poor",
            "primary_dim_score": 0,
            "primary_dim": primary_dim,
            "hit_points": [],
            "missed_points": [criterion["name"] for criterion in rubric["criteria"]],
            "comment": f"本题未能完成自动评分：{reason}。已按 0 分计入总分。",
            "candidate_feedback": "",
            "red_flag": False,
            "red_flag_reason": "",
            "red_flags": [],
            "risk_signals": [],
            "criteria": criteria,
            "scoring_confidence": 0.0,
            "rubric_version": rubric["version"],
            "should_follow_up": False,
            "follow_up_question": "",
            "technical_failure": True,
            "failure_reason": reason,
            "asr_failed": False,
            "scoring_failed": False,
        }

    async def score_answer(
        self,
        question: str,
        expected_points: list[str],
        candidate_name: str,
        answer: str,
        role_name: str = "",
        primary_dim: str = "",
        dim_description: str = "",
        audio_features: dict = None,
        question_index: int = 0,
        scoring_hint: str = "",
        scoring_rubric: dict = None,
    ) -> dict:
        """Score a single answer. No follow-up in 2-question mode.

        Args:
            role_name: 岗位名称（如"店员"）
            primary_dim: 本题主要考察维度（如"服务意识"）
            dim_description: 维度描述文本
            audio_features: 音频特征字典（duration_seconds, silence_count等）
            question_index: 题目序号
            scoring_hint: 岗位评分提示词（从模板注入）
        """
        primary_dim = VIDEO_SCORING_PRIMARY_DIMENSION
        dim_description = "统一按岗位要点、专业准确性、分析逻辑、方案可执行性、证据与边界五项评分。"
        rubric = _normalize_scoring_rubric(scoring_rubric, expected_points, primary_dim)
        answer_text = (answer or "").strip()
        invalid_transcript = (
            answer_text in ("[视频回答]", "[音频回答]", "[视频语音转文字待接入ASR服务]")
            or answer_text.startswith("[ASR")
            or answer_text.startswith("[语音识别")
            or answer_text.startswith("[音频提取")
            or answer_text.startswith("[语音转文字失败")
        )
        if invalid_transcript:
            reason = "音频提取失败" if answer_text.startswith("[音频提取") else "语音转写失败"
            return self.technical_failure_result(rubric, primary_dim, reason)

        if len(answer_text) < 5:
            criterion_results = [
                {
                    "id": criterion["id"],
                    "name": criterion["name"],
                    "dimension": criterion["dimension"],
                    "weight": criterion["weight"],
                    "level": 0,
                    "score": 0,
                    "evidence": "有效回答不足",
                    "confidence": 1.0,
                }
                for criterion in rubric["criteria"]
            ]
            return {
                "score": 0,
                "level": "poor",
                "primary_dim_score": 0,
                "primary_dim": primary_dim,
                "hit_points": [],
                "missed_points": [criterion["name"] for criterion in rubric["criteria"]],
                "comment": "未提供足够的有效回答证据。",
                "candidate_feedback": "请结合具体做法、案例或结果完整作答。",
                "red_flag": False,
                "red_flag_reason": "",
                "red_flags": [],
                "risk_signals": [],
                "criteria": criterion_results,
                "scoring_confidence": 1.0,
                "rubric_version": rubric["version"],
                "should_follow_up": False,
                "follow_up_question": "",
                "scoring_failed": False,
            }

        # 构建音频特征提示
        audio_features_hint = ""
        if audio_features:
            parts = []
            dur = audio_features.get("duration_seconds", 0)
            if dur:
                parts.append(f"回答时长{dur}秒")
            sc = audio_features.get("silence_count", 0)
            if sc:
                parts.append(f"停顿{sc}次")
            vol = audio_features.get("mean_volume_db")
            if vol is not None:
                parts.append(f"音量{vol}dB")
            if parts:
                audio_features_hint = (
                    "语音特征参考："
                    + "，".join(parts)
                    + "\n这些特征只能辅助沟通表达项，不得影响专业、经验或业务能力评分。"
                )

        # 使用动态维度 prompt
        system_prompt = SCORE_ANSWER_SYSTEM.format(
            role_name=role_name or "服务行业",
            primary_dim=primary_dim or "综合表现",
            dim_description=dim_description or "回答是否完整、有逻辑、态度积极",
        )

        user_prompt = SCORE_ANSWER_USER.format(
            question=question,
            primary_dim=primary_dim or "综合表现",
            expected_points=", ".join(expected_points),
            scoring_rubric=json.dumps(rubric, ensure_ascii=False),
            name=candidate_name,
            answer=answer_text[:3000],
            audio_features_hint=audio_features_hint,
        )

        try:
            from hermes_wrapper.models import LLMRequest

            llm = self._get_llm()
            req = LLMRequest(
                prompt=user_prompt,
                system=system_prompt,
                temperature=0.1,
            )
            response = await llm.chat(req)
            if response.error:
                raise RuntimeError(response.error)
            text = response.content.strip()
            if "```" in text:
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            result = json.loads(text)

            raw_criteria = result.get("criteria")
            if not isinstance(raw_criteria, list):
                raise ValueError("missing criteria assessments")
            by_id = {
                str(item.get("id")): item
                for item in raw_criteria
                if isinstance(item, dict) and item.get("id") is not None
            }

            criterion_results = []
            weighted_score = 0.0
            weighted_confidence = 0.0
            for criterion in rubric["criteria"]:
                assessment = by_id.get(criterion["id"])
                if not assessment:
                    raise ValueError(f"missing criterion {criterion['id']}")
                level = assessment.get("level")
                confidence = assessment.get("confidence")
                if not isinstance(level, (int, float)) or isinstance(level, bool) or level not in (0, 1, 2, 3, 4):
                    raise ValueError(f"invalid level for {criterion['id']}")
                if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not 0 <= confidence <= 1:
                    raise ValueError(f"invalid confidence for {criterion['id']}")
                evidence = str(assessment.get("evidence") or "").strip()
                if level >= 3 and not evidence:
                    confidence = min(float(confidence), 0.49)
                criterion_score = round(float(level) / 4 * 100)
                weighted_score += criterion_score * criterion["weight"]
                weighted_confidence += float(confidence) * criterion["weight"]
                criterion_results.append(
                    {
                        "id": criterion["id"],
                        "name": criterion["name"],
                        "dimension": criterion["dimension"],
                        "weight": criterion["weight"],
                        "level": int(level),
                        "score": criterion_score,
                        "evidence": evidence,
                        "confidence": round(float(confidence), 3),
                    }
                )

            raw_overall_confidence = result.get("overall_confidence")
            if (
                isinstance(raw_overall_confidence, (int, float))
                and not isinstance(raw_overall_confidence, bool)
                and 0 <= raw_overall_confidence <= 1
            ):
                scoring_confidence = min(float(raw_overall_confidence), weighted_confidence)
            else:
                scoring_confidence = weighted_confidence

            raw_flags = result.get("red_flags") if isinstance(result.get("red_flags"), list) else []
            red_flags = []
            risk_signals = []
            for raw_flag in raw_flags:
                if not isinstance(raw_flag, dict):
                    continue
                severity = str(raw_flag.get("severity") or "review").lower()
                flag_confidence = raw_flag.get("confidence", 0)
                if (
                    not isinstance(flag_confidence, (int, float))
                    or isinstance(flag_confidence, bool)
                    or not 0 <= flag_confidence <= 1
                ):
                    flag_confidence = 0
                flag = {
                    "type": str(raw_flag.get("type") or "其他风险"),
                    "severity": severity,
                    "evidence": str(raw_flag.get("evidence") or "").strip(),
                    "confidence": round(float(flag_confidence), 3),
                }
                if severity in ("high", "critical") and flag_confidence >= 0.8 and flag["evidence"]:
                    red_flags.append(flag)
                else:
                    risk_signals.append(flag)

            score = round(weighted_score)
            level_name = "excellent" if score >= 85 else "good" if score >= 70 else "average" if score >= 50 else "poor"
            hit_points = [item["name"] for item in criterion_results if item["level"] >= 3]
            missed_points = [item["name"] for item in criterion_results if item["level"] <= 1]
            red_flag_reason = "；".join(flag["evidence"] for flag in red_flags)
            output = {
                "score": score,
                "level": level_name,
                "primary_dim_score": score,
                "primary_dim": primary_dim,
                "hit_points": hit_points,
                "missed_points": missed_points,
                "comment": str(result.get("comment") or "已按行为锚点完成证据化评分。"),
                "candidate_feedback": str(result.get("candidate_feedback") or ""),
                "red_flag": bool(red_flags),
                "red_flag_reason": red_flag_reason,
                "red_flags": red_flags,
                "risk_signals": risk_signals,
                "criteria": criterion_results,
                "scoring_confidence": round(scoring_confidence, 3),
                "rubric_version": rubric["version"],
                "should_follow_up": False,
                "follow_up_question": "",
                "scoring_failed": False,
            }
            return output
        except Exception:
            return self.technical_failure_result(rubric, primary_dim, "AI 评分服务或结果校验异常")

    async def evaluate_final(
        self,
        candidate_name: str,
        role: str,
        questions: list[dict],
        answers: list[dict],
        template: dict = None,
    ) -> dict:
        """Generate final interview evaluation after all questions.

        Only behavioral_v2 question results participate in aggregation.
        The final score is the arithmetic mean of all valid question scores.
        """
        expected_criterion_ids = {criterion_id for criterion_id, _, _ in VIDEO_GENERAL_CRITERIA}

        red_flags = []
        seen_red_flags = set()
        if not questions:
            return {
                "interview_score": 0,
                "provisional_score": None,
                "dimension_scores": {dimension: 0 for dimension in VIDEO_SCORING_DIMENSIONS},
                "summary": f"{candidate_name}未生成可评分题目，按 0 分处理。",
                "strengths": [],
                "weaknesses": list(VIDEO_SCORING_DIMENSIONS)[:2],
                "red_flags": [],
                "trend": "unknown",
                "recommendation": "not_recommend",
                "recommend_reason": "未生成可评分题目，按 0 分处理",
                "score_version": VIDEO_FINAL_SCORE_VERSION,
                "score_calculation": "five_dimension_weighted_average",
                "scoring_status": "succeeded",
                "score_status": "final",
                "failed_questions": [],
                "scored_question_count": 0,
                "total_question_count": 0,
                "score_coverage_ratio": 1,
                "dimension_coverage": {
                    "covered": list(VIDEO_SCORING_DIMENSIONS),
                    "uncovered": [],
                    "ratio": 1.0,
                    "status": "complete",
                },
                "dim_detail": {dimension: [] for dimension in VIDEO_SCORING_DIMENSIONS},
            }

        question_scores: list[float] = []
        for index in range(len(questions)):
            question = questions[index] if isinstance(questions[index], dict) else {}
            answer = answers[index] if index < len(answers) else None
            if isinstance(answer, dict):
                answer_flags = answer.get("red_flags") if isinstance(answer.get("red_flags"), list) else []
                if answer_flags:
                    for flag in answer_flags:
                        if not isinstance(flag, dict):
                            continue
                        reason = str(flag.get("evidence") or flag.get("reason") or "触发红线")
                        key = (index, str(flag.get("type") or "其他风险"), reason)
                        if key in seen_red_flags:
                            continue
                        seen_red_flags.add(key)
                        red_flags.append(
                            {
                                "question_index": index,
                                "type": key[1],
                                "severity": str(flag.get("severity") or "high"),
                                "reason": reason,
                                "confidence": flag.get("confidence"),
                            }
                        )
            criteria = answer.get("criteria") if isinstance(answer, dict) else None
            criteria_valid = (
                len(criteria or []) == len(VIDEO_GENERAL_CRITERIA)
                and all(
                    isinstance(criterion, dict)
                    and str(criterion.get("id") or "") in expected_criterion_ids
                    and isinstance(criterion.get("score"), (int, float))
                    and not isinstance(criterion.get("score"), bool)
                    and isinstance(criterion.get("weight"), (int, float))
                    and not isinstance(criterion.get("weight"), bool)
                    and criterion.get("weight") > 0
                    for criterion in (criteria or [])
                )
                and {str(criterion.get("id") or "") for criterion in (criteria or [])} == expected_criterion_ids
            )
            if (
                not isinstance(answer, dict)
                or answer.get("scoring_failed")
                or answer.get("asr_failed")
                or answer.get("rubric_version") != SCORING_RUBRIC_VERSION
                or not criteria_valid
            ):
                rubric = question.get("scoring_rubric") if isinstance(question.get("scoring_rubric"), dict) else {}
                rubric = _normalize_scoring_rubric(
                    rubric,
                    question.get("expected_points", []),
                    VIDEO_SCORING_PRIMARY_DIMENSION,
                )
                answer = self.technical_failure_result(
                    rubric,
                    VIDEO_SCORING_PRIMARY_DIMENSION,
                    "评分结果结构异常，已按 0 分处理",
                )
                if index < len(answers):
                    answers[index] = answer
                else:
                    answers.append(answer)

            criteria = answer["criteria"]
            criteria_weight = sum(float(criterion["weight"]) for criterion in criteria)
            question_score = round(
                sum(float(criterion["score"]) * float(criterion["weight"]) for criterion in criteria) / criteria_weight
            )
            question_scores.append(float(question_score))

        # Keep the final video aggregation identical to written tests: aggregate
        # each of the five fixed criteria across questions, then apply their
        # fixed weights to the candidate total. Do not reuse role dimensions.
        dimension_values: dict[str, list[tuple[float, float]]] = {
            dimension: [] for dimension in VIDEO_SCORING_DIMENSIONS
        }
        dim_detail: dict[str, list] = {dimension: [] for dimension in VIDEO_SCORING_DIMENSIONS}
        for question_index, answer in enumerate(answers[: len(questions)]):
            if not isinstance(answer, dict):
                continue
            question = questions[question_index] if isinstance(questions[question_index], dict) else {}
            for criterion in answer.get("criteria", []):
                dimension = VIDEO_CRITERION_DIMENSIONS.get(
                    str(criterion.get("id") or ""),
                    str(criterion.get("name") or ""),
                )
                if dimension not in VIDEO_SCORING_DIMENSIONS:
                    continue
                criterion_score = criterion.get("score")
                criterion_weight = criterion.get("weight")
                if (
                    not isinstance(criterion_score, (int, float))
                    or isinstance(criterion_score, bool)
                    or not isinstance(criterion_weight, (int, float))
                    or isinstance(criterion_weight, bool)
                    or criterion_weight <= 0
                ):
                    continue
                dimension_values[dimension].append((float(criterion_score), float(criterion_weight)))
                dim_detail[dimension].append(
                    {
                        "question_index": question_index,
                        "question": question.get("question", ""),
                        "score": round(float(criterion_score)),
                        "weight": round(float(criterion_weight), 6),
                        "criteria": [criterion],
                    }
                )

        dim_scores = {}
        for dimension, values in dimension_values.items():
            if values:
                value_weight = sum(weight for _, weight in values)
                dim_scores[dimension] = round(sum(score * weight for score, weight in values) / value_weight)
        covered_weight = sum(VIDEO_SCORING_DIMENSIONS[dimension] for dimension in dim_scores)
        interview_score = round(
            sum(dim_scores[dimension] * VIDEO_SCORING_DIMENSIONS[dimension] for dimension in dim_scores)
            / covered_weight
        )
        uncovered_dimensions = [dimension for dimension in VIDEO_SCORING_DIMENSIONS if dimension not in dim_scores]
        dimension_coverage = {
            "covered": list(dim_scores),
            "uncovered": uncovered_dimensions,
            "ratio": round(covered_weight / sum(VIDEO_SCORING_DIMENSIONS.values()), 3),
            "status": "complete" if not uncovered_dimensions else "partial",
        }

        # ── 趋势分析（>=3题才有意义，2题模式跳过）──
        all_scores = question_scores
        trend = "stable"
        if len(all_scores) >= 3:
            mid = len(all_scores) // 2
            first_half_avg = sum(all_scores[:mid]) / mid
            second_half_avg = sum(all_scores[mid:]) / len(all_scores[mid:])
            diff = second_half_avg - first_half_avg
            if diff > 10:
                trend = "improving"
            elif diff < -10:
                trend = "declining"

        scored_question_count = len(question_scores)
        score_coverage_ratio = round(scored_question_count / len(questions), 3)

        # ── 推荐等级 + 红线降级 ──
        if interview_score >= 85:
            recommendation = "strong_recommend"
        elif interview_score >= 70:
            recommendation = "recommend"
        elif interview_score >= 55:
            recommendation = "consider"
        else:
            recommendation = "not_recommend"

        # 红线降级逻辑
        if len(red_flags) >= 2:
            recommendation = "not_recommend"
        elif len(red_flags) == 1:
            downgrade = {
                "strong_recommend": "recommend",
                "recommend": "consider",
                "consider": "not_recommend",
            }
            recommendation = downgrade.get(recommendation, recommendation)

        # ── 构建摘要 ──
        strong_dims = [k for k, v in dim_scores.items() if v >= 75]
        weak_dims = [k for k, v in dim_scores.items() if v < 60]

        summary_parts = [f"{candidate_name}五维加权得分{interview_score}分。"]
        if strong_dims:
            summary_parts.append(f"强项：{'、'.join(strong_dims)}")
        if weak_dims:
            summary_parts.append(f"待提升：{'、'.join(weak_dims)}")
        if red_flags:
            summary_parts.append(f"红线警告：{len(red_flags)}项")
        if uncovered_dimensions:
            summary_parts.append(f"未覆盖维度：{'、'.join(uncovered_dimensions)}")
        if trend == "improving":
            summary_parts.append("越答越好")
        elif trend == "declining":
            summary_parts.append("后程乏力")

        recommend_reasons = {
            "strong_recommend": "强烈推荐",
            "recommend": "推荐进入复试",
            "consider": "可考虑",
            "not_recommend": "建议淘汰",
        }

        return {
            "interview_score": interview_score,
            "provisional_score": None,
            "dimension_scores": dim_scores,
            "summary": "。".join(summary_parts),
            "strengths": strong_dims[:3],
            "weaknesses": weak_dims[:2],
            "red_flags": red_flags,
            "trend": trend,
            "recommendation": recommendation,
            "recommend_reason": recommend_reasons.get(recommendation, ""),
            "score_version": VIDEO_FINAL_SCORE_VERSION,
            "score_calculation": "five_dimension_weighted_average",
            "scoring_status": "succeeded",
            "score_status": "final",
            "failed_questions": [],
            "scored_question_count": scored_question_count,
            "total_question_count": len(questions),
            "score_coverage_ratio": score_coverage_ratio,
            "dimension_coverage": dimension_coverage,
            "dim_detail": dim_detail,
        }

    # ── 多模态视频分析 ────────────────────────────────────────

    VIDEO_ROLE_FOCUS = {
        "stir_fry_gm": "自信气场、条理清晰、专业沉稳",
        "camping_gm": "自信气场、沟通热情、开拓精神",
        "admin_assistant": "微笑热情、耐心细致、态度得体",
        "private_domain_director": "思路清晰、数据敏感、表达有条理",
        "thirdparty_ops_manager": "干练利索、逻辑清晰、执行力强",
    }

    async def video_evaluate(
        self,
        frame_paths: list,
        audio_features: dict,
        role: str,
        question: str,
    ) -> dict:
        """多模态分析：截帧 + 音频特征 → 非语言评分。

        Returns dict with expression_score, eye_contact_score,
        body_language_score, professional_image_score, nonverbal_overall.
        """
        if not frame_paths:
            return {"nonverbal_overall": 0, "error": "no_frames"}

        family = self.detect_job_family(role)
        role_focus = self.VIDEO_ROLE_FOCUS.get(family, "表情自然、仪态得体")

        system = f"""你是服务行业面试视频分析专家。
请根据面试视频截帧分析候选人的非语言表现。

重点观察（针对{role or "服务行业"}岗位）：{role_focus}

评估维度：
- 表情状态：微笑/自然 vs 紧张/冷漠
- 眼神交流：看镜头 vs 低头/看别处
- 肢体语言：自然大方 vs 僵硬拘谨
- 职业形象：穿着整洁、适合服务岗位

注意：不要评估五官、体型、肤色、年龄。
只看穿着是否整洁得体、表情是否自然、姿态是否自信。

输出JSON：
{{
  "expression_score": 75,
  "eye_contact_score": 80,
  "body_language_score": 70,
  "professional_image_score": 85,
  "nonverbal_overall": 78,
  "highlights": ["微笑自然", "眼神交流好"],
  "concerns": ["手势略显僵硬"],
  "confidence": 0.8
}}"""

        # 构建多模态消息
        import base64

        content = []
        for fp in frame_paths:
            try:
                with open(fp, "rb") as f:
                    img_b64 = base64.b64encode(f.read()).decode()
                content.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"},
                    }
                )
            except Exception:
                continue

        if not content:
            return {"nonverbal_overall": 0, "error": "no_readable_frames"}

        audio_desc = ""
        if audio_features:
            dur = audio_features.get("duration_seconds", 0)
            sc = audio_features.get("silence_count", 0)
            vol = audio_features.get("mean_volume_db", "未知")
            audio_desc = f"语音特征：回答时长{dur}秒，停顿{sc}次，音量{vol}dB"

        content.append(
            {
                "type": "text",
                "text": f"题目：{question}\n{audio_desc}\n请分析截帧中候选人的非语言表现。",
            }
        )

        try:
            from hermes_wrapper.models import LLMRequest

            llm = self._get_llm()
            req = LLMRequest(
                prompt="",  # 文本位于 content_parts 中
                system=system,
                temperature=0.2,
                content_parts=content,  # 多模态消息（image_url + text）
            )
            response = await llm.chat(req)
            if response.error:
                raise RuntimeError(response.error)
            text = response.content.strip()
            if "```" in text:
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            result = json.loads(text)

            # 确保 nonverbal_overall 存在
            if "nonverbal_overall" not in result:
                scores = [
                    result.get("expression_score", 50),
                    result.get("eye_contact_score", 50),
                    result.get("body_language_score", 50),
                    result.get("professional_image_score", 50),
                ]
                result["nonverbal_overall"] = round(sum(scores) / len(scores))

            return result

        except Exception as e:
            return {"nonverbal_overall": 0, "error": str(e)[:100]}
