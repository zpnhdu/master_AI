"""JD Agent - Generate job descriptions with ontology + knowledge base"""

import re
import time

from app.infrastructure.timeout_policy import BusinessTimeoutError
from app.xiao_wen_context import XIAO_WEN_MODEL
from hr_harness.agents.base import BaseAgent
from hr_harness.agents.quiz_agent import format_quiz_answers_for_jd
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput
from knowledge import get_knowledge_base
from ontology import get_ontology_engine

SERVICE_ROLE_KEYWORDS = (
    "奶茶",
    "茶饮",
    "调饮",
    "咖啡",
    "吧台",
    "服务员",
    "店员",
    "收银",
    "店长",
    "副店",
    "储备",
    "兼职",
    "小时工",
)

JOB_TYPE_GUIDANCE = {
    "tech": "突出技术栈、工程交付、系统质量和可量化技术成果。",
    "product": "突出用户研究、产品规划、需求管理和业务结果。",
    "operations": "突出运营策略、活动执行、用户增长和经营指标。",
    "sales": "突出客户拓展、销售过程、业绩目标和客户维护。",
    "supply_chain": "突出采购、库存、供应商协同和履约指标。",
    "service": "突出门店/服务流程、顾客体验、排班和经营指标。",
    "management": "突出团队管理、目标拆解、组织协同和经营结果。",
    "function": "突出专业职能、流程规范、风险控制和内部协作。",
    "general": "根据岗位职责选择最匹配的行业表达，避免套用无关模板。",
}


def is_service_job(role: str, pipeline_type: str) -> bool:
    """Use the selected job type as authority and keywords only as fallback."""
    if pipeline_type == "service":
        return True
    if pipeline_type and pipeline_type != "general":
        return False
    normalized_role = (role or "").lower()
    return any(keyword in normalized_role for keyword in SERVICE_ROLE_KEYWORDS)


def extract_location_hint(user_hints: str, explicit_location: str = "") -> str:
    """Resolve the job location, preferring the pipeline's explicit location."""
    explicit = str(explicit_location or "").strip()
    if explicit:
        return explicit

    hints = str(user_hints or "")
    marker_match = re.search(r"(?:工作地点|工作城市|地点)\s*[:：]\s*([^。；;\n,，]+)", hints)
    if marker_match:
        return marker_match.group(1).strip()

    city_match = re.search(
        r"(北京|上海|深圳|杭州|广州|成都|南京|武汉|西安|长沙|苏州|郑州|天津|重庆|厦门|合肥|远程|remote|海外|硅谷|新加坡|东京|伦敦)",
        hints,
    )
    return city_match.group(1) if city_match else ""


class JDAgent(BaseAgent):
    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        role = input.params.get("role", "店长")
        memory_context = input.params.get("memory_context", "")
        user_hints = input.params.get("user_hints", "")
        pipeline_id = input.pipeline_id
        quiz_answers = input.params.get("quiz_answers", [])
        company_config = input.params.get("company_config", {})
        pipeline_type = input.params.get("pipeline_type", "general")
        model = XIAO_WEN_MODEL
        complexity = input.params.get("complexity", "plus")
        temperature = input.params.get("temperature")
        llm_max_retries = int(input.params.get("llm_max_retries", 1))

        async def progress(msg):
            if hasattr(self, "_progress_cb") and self._progress_cb:
                await self._progress_cb(msg)

        await progress("分析岗位需求...")

        # 从流水线地点或用户输入中提取地点和薪资
        location_hint = extract_location_hint(user_hints, input.params.get("location_hint", ""))
        salary_hint = ""
        if user_hints:
            sal_match = re.search(r"(\d+[-~]\d+[kK]|\d+[kK])", user_hints)
            if sal_match:
                salary_hint = sal_match.group(1)

        # 本体规则
        ontology = get_ontology_engine(pipeline_id)
        ontology_context = ontology.build_jd_prompt_context(role)

        # 知识库检索：找历史JD模式和行业基准
        kb = get_knowledge_base()
        kb_results = kb.search(f"{role} 岗位职责 任职要求 薪资", top_k=3)
        kb_context = ""
        if kb_results:
            kb_context = "\n【知识库参考】\n" + "\n".join(f"- [{k['title']}] {k['content'][:200]}" for k in kb_results)

        # 公司信息上下文
        company_context = ""
        if company_config and company_config.get("company_name"):
            benefits_list = company_config.get("default_benefits", [])
            benefits_str = "、".join(benefits_list) if benefits_list else "五险一金、带薪年假"
            company_context = f"""
【公司信息】
公司：{company_config.get("company_name", "")}（{company_config.get("company_en", "")}）
行业：{company_config.get("industry", "")}
规模：{company_config.get("company_size", "")}
公司介绍：{company_config.get("company_intro", "")}
公司标配福利（JD中应包含这些）：{benefits_str}
"""
            if company_config.get("company_website"):
                company_context += f"官网：{company_config.get('company_website', '')}\n"

        # KG 上下文注入（新增）
        kg_context = input.params.get("kg_context", {})
        kg_section = ""
        if kg_context:
            scenarios = kg_context.get("scenarios", [])
            methods = kg_context.get("methods", [])
            rules = kg_context.get("rules", [])
            parts = []
            if scenarios:
                parts.append("适用场景：" + "、".join(s["name"] for s in scenarios[:2]))
            if methods:
                parts.append("推荐方法：" + "、".join(m["name"] for m in methods[:3]))
            if rules:
                parts.append("适用规则：" + "、".join(r["name"] for r in rules[:2]))
            if parts:
                kg_section = "\n\n【知识图谱参考】\n" + "\n".join(parts)

        type_guidance = JOB_TYPE_GUIDANCE.get(pipeline_type, JOB_TYPE_GUIDANCE["general"])
        system = f"""你是一个资深HRBP，在互联网、零售、餐饮、服务等多个行业有丰富招聘经验，擅长根据不同行业特点撰写能吸引优秀人才的JD。
{company_context}{kg_section}
岗位类型：{pipeline_type}。类型写作要求：{type_guidance}
核心原则：
1. 职责描述必须具体可衡量 — 用数字和交付物定义（如"月度销售额达成率≥110%"而非"负责销售工作"）
2. 任职要求必须分层 — 硬性要求（必须满足）和加分项（锦上添花）明确区分
3. 薪资必须对标目标行业市场 — 参考同级别岗位真实薪资带
4. 福利要有差异化 — 不要写"五险一金"这种标配，写真正有吸引力的
5. 团队/门店介绍要有画面感 — 让候选人能想象在这里工作的场景
6. location 和 salary_range 必须基于用户输入，如果用户没有指定则根据岗位和行业给出合理默认值
7. 门店/服务类岗位的 department 应贴近实际（如"XX门店""XX分店"，而非互联网式命名）

【互联网/技术岗JD示例】
职责（好的写法）：
✅ "主导设计系统从0到1建设，年度交付≥3个核心组件库，覆盖80%业务线"
✅ "推动前端性能治理，首屏LCP从3s优化到1.2s"
职责（坏的写法）：
❌ "负责前端开发工作"

【服务/零售岗JD示例】
职责（好的写法）：
✅ "全面负责门店日常运营，月度营业额目标达成率≥110%，顾客满意度评分≥4.5/5"
✅ "管理8人团队，制定排班计划，新员工7天内独立上岗"
✅ "把控饮品出品质量，顾客投诉率控制在0.5%以下"
任职要求（好的写法）：
✅ "2年以上连锁零售/食材门店管理经验，曾管理≥5人团队"
✅ "熟悉食品安全规范，持有健康证"
职责（坏的写法）：
❌ "负责门店管理工作"（太泛，无衡量标准）
❌ "服务好顾客"（没有具体标准）

{ontology_context}
{kb_context}

禁止：
- 不要写"负责XX工作"这种废话，要写具体的交付物和衡量标准
- 技术岗不要写"良好的沟通能力"这种万金油要求，要写具体的协作场景；服务岗可以要求沟通能力但需具体化（如"能独立处理顾客投诉"）
- 不要编造不存在的福利
- 互联网技术岗薪资通常30-60K·14-16薪；服务/零售岗通常4-15K；请根据岗位合理设定
- 服务/零售岗的名称不要加"高级""资深"等互联网前缀，用行业通用名称（如"店长""咖啡师"）

输出严格的JSON格式，不要有其他文字。"""

        memory_section = f"\n\n【历史经验参考】\n{memory_context}" if memory_context else ""
        hints_section = f"\n\n【HR补充要求】\n{user_hints}" if user_hints else ""
        quiz_section = f"\n\n{format_quiz_answers_for_jd(quiz_answers)}" if quiz_answers else ""

        # 地点和薪资的明确指令
        loc_sal_instruction = ""
        if location_hint:
            loc_sal_instruction += f"\n**工作地点必须设为：{location_hint}**"
        else:
            loc_sal_instruction += (
                "\n**如果用户未指定工作地点，请根据岗位和行业默认设一个合理城市（北京/上海/深圳/杭州之一）**"
            )
        if salary_hint:
            loc_sal_instruction += f"\n**薪资范围必须与用户指定的一致：{salary_hint}**"
        else:
            loc_sal_instruction += "\n**如果用户未指定薪资，请根据岗位级别和城市给出合理薪资范围**"

        prompt = f"""请为以下岗位撰写一份JD：

岗位类型：{pipeline_type}
岗位：{role}{hints_section}{quiz_section}{memory_section}
类型要求：{type_guidance}
{loc_sal_instruction}

输出JSON格式：
{{
    "company_name": "{company_config.get("company_name", "")}",
    "title": "岗位全称（如：高级前端工程师 / 资深产品经理）",
    "department": "所属部门",
    "location": "工作地点（城市）",
    "salary_range": "XX-XXK·XX薪（对标一线城市市场）",
    "responsibilities": [
        "职责1：具体交付物+衡量标准（如：主导XX模块从0到1，年度交付≥N个迭代）",
        "职责2",
        "职责3",
        "职责4",
        "职责5"
    ],
    "requirements": [
        "硬性要求1：可量化（如：5年以上XX领域经验，至少2个从0到1项目）",
        "硬性要求2",
        "硬性要求3",
        "加分项1",
        "加分项2"
    ],
    "tech_stack": ["核心技能1", "核心技能2", ...]（技术岗填技术栈如React/Python；服务岗填行业技能如门店管理/饮品制作/客户服务等），
    "benefits": [
        "差异化福利1（如：年度海外技术峰会参会支持）",
        "差异化福利2",
        "差异化福利3",
        "差异化福利4"
    ],
    "team_intro": "50字团队介绍（有画面感，让候选人能想象在这里工作的场景）"
}}"""

        # 服务业 JD 专属模板
        is_service_role = is_service_job(role, pipeline_type)

        if is_service_role:
            com_name = company_config.get("company_name", "")
            prompt = f"""请为以下岗位撰写一份JD：

岗位：{role}{hints_section}{quiz_section}{memory_section}
{loc_sal_instruction}

输出JSON格式：
{{
    "company_name": "{com_name}",
    "title": "岗位全称（如：食材导购 / 店长助理 / 仓储员）",
    "department": "门店名称（如：{com_name}XX路店）",
    "location": "门店所在城市和区域",
    "salary_range": "XX-XX元/月",
    "work_hours": "排班制（如：早班7:00-15:00 / 中班10:00-18:00 / 晚班14:00-22:00，月休4-6天）",
    "responsibilities": [
        "职责1：具体操作（如：按SOP标准陈列食材，确保品质新鲜）",
        "职责2（如：维护吧台卫生，执行每日清洁 checklist）",
        "职责3（如：接待顾客，提供热情周到的点单和推荐服务）",
        "职责4",
        "职责5"
    ],
    "requirements": [
        "硬性要求1（如：年满18周岁，持有效健康证或入职前办理）",
        "硬性要求2（如：能适应排班制，包括周末和节假日）",
        "硬性要求3",
        "加分项1（如：有餐饮/零售服务行业经验）",
        "加分项2（如：住址距门店30分钟通勤内）"
    ],
    "tech_stack": ["饮品制作", "收银系统操作", "顾客服务", "卫生清洁", "库存盘点"],
    "benefits": [
        "差异化福利1（如：每日免费饮品畅饮）",
        "差异化福利2（如：阶梯薪资，满3/6/12月调薪）",
        "差异化福利3（如：清晰晋升通道：店员→训练员→副店长→店长）",
        "差异化福利4（如：月度团建+生日福利+节日福利）"
    ],
    "career_path": "店员→训练员→副店长→店长→区域经理",
    "team_intro": "30字门店团队介绍（如：年轻活力的团队，平均年龄25岁，氛围轻松愉快）"
}}"""

        def _validate_jd(result):
            """JD 输出校验：确保职责≥3条、要求≥3条；技术岗需有 tech_stack，服务岗可为空"""
            if not isinstance(result, dict):
                return False
            resp = len(result.get("responsibilities", [])) >= 3
            req = len(result.get("requirements", [])) >= 3
            return resp and req

        await progress("AI 正在撰写专业 JD...")
        try:
            result = await self.call_llm_json(
                prompt,
                system,
                complexity=complexity,
                temperature=temperature,
                model=model,
                json_mode=True,
                validator=_validate_jd,
                max_retries=llm_max_retries,
            )

            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"jd": result if isinstance(result, dict) else {}, "role": role, "status": "completed"},
                tokens_used=500,
                duration_ms=int((time.time() - start) * 1000),
            )
        except BusinessTimeoutError:
            raise
        except Exception as e:
            return ToolOutput(
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )
