"""Poster Agent - Generate recruitment posters from JD using templates"""

import json
import time
from datetime import datetime
from html import escape
from typing import Optional

from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput

POSTER_CHANNELS = {
    "long": {"label": "招聘长图", "width": 1080, "height": 2340},
    "xhs": {"label": "小红书", "width": 1080, "height": 1440},
    "moments": {"label": "朋友圈", "width": 1080, "height": 1920},
    "douyin": {"label": "抖音", "width": 1080, "height": 1920},
}


def _html(value) -> str:
    """Escape text inserted into poster HTML."""
    return escape(str(value or ""), quote=True)


def _html_lines(value) -> str:
    """Escape text and preserve intentional line breaks in poster copy."""
    return "<br>".join(
        _html(part.strip()) for part in str(value or "").replace("<br>", "\n").splitlines() if part.strip()
    )


def _as_list(value, fallback=None) -> list:
    """Normalize JD fields that may be list, string, or empty."""
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        parts = [part.strip(" \n\r\t-•·；;") for part in value.replace("\n", "；").split("；")]
        return [part for part in parts if part]
    return fallback or []


def _limit_text(value, max_len: int) -> str:
    """Keep poster copy compact enough for fixed-size layouts."""
    text = str(value or "").strip().replace("\n", " ")
    if len(text) <= max_len:
        return text
    for sep in ["，", "。", "；", ",", ";", " "]:
        head = text.split(sep)[0].strip()
        if 8 <= len(head) <= max_len:
            return head
    return text[: max_len - 1].rstrip("，。；,; ") + "…"


def _limit_list(items, limit: int, max_len: int, fallback=None) -> list:
    rows = [_limit_text(item, max_len) for item in _as_list(items, fallback)]
    return [row for row in rows if row][:limit]


def _date_theme(current_date: str) -> dict:
    """Build a current-date theme; avoid stale holiday copy outside its season."""
    try:
        dt = datetime.strptime(current_date[:10], "%Y-%m-%d")
    except (TypeError, ValueError):
        dt = datetime.now()
    month = dt.month
    if month in {2, 3}:
        return {"theme": "春招", "scene": "这个春天", "apply": "春招不观望，投递正当时"}
    if month in {4, 5}:
        return {"theme": "春日", "scene": "这个春日", "apply": "春日开新局，投递正当时"}
    if month in {6, 7, 8}:
        return {"theme": "夏日", "scene": "这个夏天", "apply": "夏日不躺平，投递正当时"}
    if month in {9, 10}:
        return {"theme": "金秋", "scene": "这个金秋", "apply": "金秋不躺平，投递正当时"}
    if month in {11, 12}:
        return {"theme": "年末", "scene": "这个年末", "apply": "年末冲一把，投递正当时"}
    return {"theme": "新年", "scene": "这个新年", "apply": "新年开新局，投递正当时"}


def _sanitize_time_terms(value: str, current_date: str) -> str:
    theme = _date_theme(current_date)
    text = str(value or "")
    if theme["theme"] != "金秋":
        text = text.replace("十一", theme["theme"]).replace("国庆", theme["theme"]).replace("金秋", theme["scene"])
    return text


def _resolve_template_id(template_id: str, company_name: str, role: str) -> str:
    """Resolve poster template while keeping legacy company config compatible."""
    valid_templates = [
        "guoquan_green_recruit",
        "guoquan_red",
        "chagee_red",
        "tech_blue",
        "startup_green",
        "corporate_gold",
    ]
    normalized = template_id if template_id in valid_templates else ""
    if normalized in {"guoquan_red", "chagee_red"} and "锅圈" in company_name:
        return "guoquan_green_recruit"
    if normalized:
        return "guoquan_red" if normalized == "chagee_red" else normalized

    if "锅圈" in company_name:
        return "guoquan_green_recruit"

    role_lower = role.lower()
    if any(k in role_lower for k in ["产品", "运营", "市场", "销售"]):
        return "startup_green"
    if any(k in role_lower for k in ["hr", "人事", "行政", "财务"]):
        return "corporate_gold"
    return "tech_blue"


def _render_check_rows(items: list, limit: int = 4) -> str:
    rows = []
    for item in items[:limit]:
        rows.append(
            '<div class="gq-check-row"><span class="gq-check">✓</span>'
            f'<span class="gq-check-text">{_html(item)}</span></div>'
        )
    return "".join(rows)


def _render_story_columns(highlights: list) -> str:
    left = highlights[0] if highlights else "平台够大，机会够多，在万店品牌里练就经营视角。"
    right = highlights[1] if len(highlights) > 1 else "底薪是锅底，提成是涮菜，你的增长配得上回报。"
    return f"""
    <div class="gq-story-grid">
      <div class="gq-story">
        <div class="gq-story-title">晋升像火锅沸腾，从青铜到王者不绕路！</div>
        <div class="gq-story-text">{_html(left)}</div>
      </div>
      <div class="gq-story">
        <div class="gq-story-title">底薪是锅底，提成是涮菜。</div>
        <div class="gq-story-text">{_html(right)}</div>
      </div>
    </div>"""


def _build_dynamic_poster_copy(
    title: str,
    responsibilities: list,
    highlights: list,
    company_short: str,
    current_date: str = "",
    llm_copy: Optional[dict] = None,
) -> dict:
    """Build poster headline copy from JD content."""
    theme = _date_theme(current_date or datetime.now().strftime("%Y-%m-%d"))
    joined = "，".join([title, *responsibilities, *highlights])
    if any(keyword in joined for keyword in ["销售", "门店", "加盟", "运营", "区域"]):
        future_role = "门店CEO"
        hero_sub = f"{theme['scene']}，下到一线也能抵达远方<br>加入{company_short}，把门店经验练成增长能力！"
    elif any(keyword in joined for keyword in ["市场", "品牌", "增长"]):
        future_role = "增长操盘手"
        hero_sub = f"{theme['scene']}，不止曝光能抵达远方<br>加入{company_short}，让品牌增长一路加速！"
    else:
        future_role = "业务负责人"
        hero_sub = f"{theme['scene']}，不止旅行能抵达远方<br>加入{company_short}，让职业一路加速前进！"
    copy = {
        "hero_kicker": f"{theme['theme']}“薪”机会",
        "hero_title": f"{company_short}等你来“刷”新纪录！",
        "hero_sub": hero_sub,
        "slogan": f"我们不只招人，我们培养未来的“{future_role}”",
        "apply_title": theme["apply"],
    }
    if isinstance(llm_copy, dict):
        for key in ["hero_kicker", "hero_title", "hero_sub", "slogan", "apply_title"]:
            if llm_copy.get(key):
                copy[key] = _sanitize_time_terms(llm_copy[key], current_date)
    return copy


def _render_guoquan_green_recruit(data: dict) -> str:
    """锅圈绿色招聘长图模板，支持不同渠道尺寸。"""
    channel = data.get("channel", "long")
    channel_cfg = POSTER_CHANNELS.get(channel, POSTER_CHANNELS["long"])
    width = int(data.get("canvas_width") or channel_cfg["width"])
    height = int(data.get("canvas_height") or channel_cfg["height"])
    compact = channel in {"xhs", "moments", "douyin"}

    title = data.get("title", "连锁门店销售经理")
    company_short = data.get("company_short") or "锅圈"
    location = data.get("location") or "全国"
    salary = data.get("salary") or "薪资面议"
    department = data.get("department") or "门店经营"
    stock_code = data.get("stock_code") or "02517.HK"
    apply_email = data.get("apply_email") or ""
    apply_url = data.get("apply_url") or ""
    qr_code = data.get("hr_qr_code") or data.get("qr_code") or ""
    company_logo = data.get("company_logo") or "/brand/guoquan-logo.svg"
    mascot_image = data.get("mascot_image") or "/brand/guoquan-mascot.png"
    poster_bg_image = data.get("poster_bg_image") or ""
    current_date = data.get("current_date") or datetime.now().strftime("%Y-%m-%d")
    if poster_bg_image.endswith("guoquan-poster-bg.svg"):
        poster_bg_image = ""

    responsibilities = _as_list(data.get("responsibilities"), ["门店经营诊断与下店指导", "加盟商赋能与营销落地"])
    requirements = _as_list(data.get("requirements"), ["大专及以上", "零售、连锁、商超经验优先", "接受长期出差"])
    highlights = _as_list(data.get("highlights"), ["万店品牌，平台够大，机会够多", "在一线经营里练出区域负责人视角"])
    dynamic_copy = _build_dynamic_poster_copy(title, responsibilities, highlights, company_short, current_date)
    hero_kicker = data.get("hero_kicker") or dynamic_copy["hero_kicker"]
    hero_title = data.get("hero_title") or dynamic_copy["hero_title"]
    hero_sub = data.get("hero_sub") or dynamic_copy["hero_sub"]
    slogan = data.get("slogan") or dynamic_copy["slogan"]
    apply_title = data.get("apply_title") or dynamic_copy["apply_title"]

    become_rows = responsibilities[:4]
    if len(become_rows) < 4:
        become_rows.extend(
            [
                "门店经营的诊断师，下店指导陈列、促销、服务与运营",
                "加盟商眼中的最强导师，帮门店提升业绩",
                "区域市场的节奏掌控者，洞察竞争动态",
                "经营标准和食品安全标准守卫者",
            ][: 4 - len(become_rows)]
        )

    expect_rows = requirements[: 3 if compact else 4]
    story_html = "" if compact else _render_story_columns(highlights)
    qr_html = (
        f'<img class="gq-qr" src="{_html(qr_code)}" alt="投递二维码">'
        if qr_code
        else '<div class="gq-qr-placeholder">QR</div>'
    )
    apply_url_html = f'<div class="gq-apply-url">{_html(apply_url)}</div>' if apply_url else ""
    bg_style = f"background-image:url({_html(poster_bg_image)});" if poster_bg_image else ""

    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* {{ box-sizing: border-box; }}
html, body {{ margin: 0; padding: 0; background: #0a8f18; font-family: "PingFang SC", "Microsoft YaHei", Arial, sans-serif; }}
.gq-poster {{
  width: {width}px; height: {height}px; position: relative; overflow: hidden; color: #173318;
  padding: 36px 42px 38px; background:
    radial-gradient(circle at 18% 7%, rgba(222,255,94,.82), transparent 22%),
    radial-gradient(circle at 88% 20%, rgba(255,239,61,.46), transparent 18%),
    linear-gradient(180deg, #8bea2c 0%, #16b52d 34%, #05891f 100%);
  {bg_style} background-size: cover; background-position: center;
}}
.gq-poster:before {{ content:""; position:absolute; inset:0; background:
  linear-gradient(90deg, rgba(255,255,255,.14) 1px, transparent 1px),
  linear-gradient(180deg, rgba(255,255,255,.10) 1px, transparent 1px);
  background-size: 92px 92px; opacity:.24; }}
.gq-poster:after {{ content:"GUO QUAN  GUO QUAN  GUO QUAN  GUO QUAN"; position:absolute; left:-50px; top:830px;
  width:1200px; height:34px; color:rgba(8,118,19,.42); font-size:28px; font-weight:800; letter-spacing:8px;
  transform:rotate(-2deg); background:rgba(232,255,82,.62); white-space:nowrap; }}
.gq-layer {{ position: relative; z-index: 1; }}
.gq-top {{ display:flex; align-items:flex-start; justify-content:space-between; color:#16311a; font-weight:800; }}
.gq-brand {{ display:flex; align-items:center; gap:14px; }}
.gq-logo {{ width:82px; height:82px; object-fit:contain; background:rgba(255,255,255,.2); border-radius:12px; padding:5px; }}
.gq-cctv {{ font-size:42px; line-height:1; letter-spacing:-2px; }}
.gq-partner {{ margin-top:10px; font-size:24px; font-weight:500; }}
.gq-stock {{ font-size:24px; }}
.gq-clip {{ position:absolute; left:455px; top:112px; width:190px; height:78px; border-radius:18px; background:linear-gradient(180deg,#14c51c,#069118);
  box-shadow:0 18px 0 #fff, 0 24px 24px rgba(0,101,14,.24); z-index:2; }}
.gq-clip:before {{ content:""; position:absolute; left:82px; top:-150px; border-left:48px solid transparent; border-right:48px solid transparent; border-top:170px solid #089516; }}
.gq-hero {{ margin:92px auto 0; width:890px; min-height:414px; padding:62px 58px 48px; border-radius:34px;
  background:linear-gradient(180deg,#27d63b 0%,#02b82a 58%,#008d20 100%);
  box-shadow:0 18px 0 rgba(255,255,255,.92), 0 34px 58px rgba(0,88,11,.36); color:#fff; transform:rotate(-2.8deg); position:relative; z-index:2; }}
.gq-hero-kicker {{ font-size:84px; line-height:1; font-weight:900; letter-spacing:4px; text-shadow:6px 7px 0 rgba(0,92,13,.5); }}
.gq-hero-kicker .yellow {{ color:#eaff57; }}
.gq-hero-title {{ margin-top:28px; max-width:760px; font-size:56px; line-height:1.16; font-weight:900; color:#fff;
  text-shadow:5px 6px 0 rgba(0,92,13,.5); }}
.gq-hero-title .yellow {{ color:#eaff57; }}
.gq-hero-sub {{ margin-top:28px; margin-left:190px; font-size:34px; line-height:1.45; font-weight:900;
  color:#fff; text-shadow:4px 5px 0 rgba(0,92,13,.42); }}
.gq-mascot {{ position:absolute; left:52px; top:662px; width:188px; height:272px; border-radius:24px; overflow:visible;
  transform:rotate(-4deg); filter:drop-shadow(0 14px 18px rgba(0,73,12,.22)); z-index:3; }}
.gq-mascot-img {{ width:100%; height:100%; object-fit:contain; object-position:center; }}
.gq-star {{ position:absolute; right:70px; top:668px; width:112px; height:112px; background:#ffef3d; clip-path:polygon(50% 0%,61% 34%,98% 35%,68% 56%,79% 91%,50% 70%,21% 91%,32% 56%,2% 35%,39% 34%); filter:drop-shadow(0 8px 10px rgba(0,0,0,.18)); z-index:2; }}
.gq-card {{ margin-top:118px; background:#fff; border-radius:30px; padding:34px 40px 28px;
  box-shadow:0 18px 38px rgba(0,83,17,.26); border:6px solid rgba(218,255,199,.78); }}
.gq-channel-safe {{ position:relative; z-index:1; }}
.gq-slogan {{ display:inline-block; max-width:calc(100% - 260px); margin-left:260px; padding:16px 30px; border-radius:20px; background:#03a51c;
  color:#fff; font-size:34px; font-weight:900; }}
.gq-title {{ margin-top:26px; color:#069121; font-size:52px; line-height:1.15; font-weight:900;
  text-shadow:0 8px 0 #f6df26; }}
.gq-meta {{ display:none; }}
.gq-pill {{ display:none; }}
.gq-section {{ margin-top:24px; padding-top:22px; border-top:2px dashed #d7d7d7; }}
.gq-section:first-of-type {{ border-top:0; padding-top:0; }}
.gq-section-title {{ font-size:32px; font-weight:900; color:#111; margin-bottom:14px; }}
.gq-bullet {{ font-size:27px; line-height:1.64; color:#555; }}
.gq-check-row {{ display:flex; align-items:flex-start; gap:12px; margin:10px 0; }}
.gq-check {{ flex:0 0 auto; width:32px; height:32px; border:4px solid #19aa39; border-radius:50%; color:#19aa39;
  display:flex; align-items:center; justify-content:center; font-size:24px; font-weight:900; line-height:1; }}
.gq-check-text {{ font-size:27px; line-height:1.42; color:#565656; }}
.gq-story-grid {{ display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-top:22px; padding-top:20px; border-top:2px dashed #d7d7d7; }}
.gq-story:first-child {{ border-right:2px dashed #d7d7d7; padding-right:22px; }}
.gq-story-title {{ color:#e61717; font-size:25px; font-weight:900; line-height:1.32; }}
.gq-story-text {{ margin-top:10px; color:#555; font-size:24px; line-height:1.48; }}
.gq-apply {{ margin-top:22px; background:#fff; border-radius:28px; padding:24px 34px; display:grid; grid-template-columns:1fr 210px;
  gap:24px; align-items:center; box-shadow:0 16px 34px rgba(0,78,14,.22); }}
.gq-apply-title {{ font-size:33px; font-weight:900; color:#111; margin-bottom:18px; }}
.gq-apply-row {{ margin-top:10px; font-size:28px; font-weight:900; color:#07851b; }}
.gq-apply-label {{ background:#08a51c; color:#fff; padding:4px 12px; margin-right:8px; }}
.gq-apply-url {{ margin-top:8px; color:#666; font-size:20px; font-weight:700; word-break:break-all; }}
.gq-qr, .gq-qr-placeholder {{ width:188px; height:188px; background:#fff; border:8px solid #fff; object-fit:cover; }}
.gq-qr-placeholder {{ border:8px solid #fff; position:relative;
  background-color:#fff;
  background-image:
    linear-gradient(90deg,#111 10px,transparent 10px),
    linear-gradient(#111 10px,transparent 10px),
    repeating-linear-gradient(90deg,#111 0 8px,transparent 8px 18px),
    repeating-linear-gradient(0deg,#111 0 8px,transparent 8px 18px);
  background-size:42px 42px,42px 42px,34px 34px,34px 34px;
  background-position:10px 10px,10px 10px,4px 4px,4px 4px;
  image-rendering:pixelated; }}
.gq-qr-placeholder:before, .gq-qr-placeholder:after {{ content:""; position:absolute; width:48px; height:48px; border:10px solid #111; background:#fff; }}
.gq-qr-placeholder:before {{ left:8px; top:8px; box-shadow:104px 0 0 -10px #fff,104px 0 0 0 #111,0 104px 0 -10px #fff,0 104px 0 0 #111; }}
.gq-qr-placeholder:after {{ right:14px; bottom:14px; width:22px; height:22px; border-width:8px; }}
.gq-footer {{ display:flex; justify-content:space-between; gap:16px; margin-top:28px; color:rgba(221,255,168,.75); font-size:22px; font-weight:900; }}
.gq-footer span {{ flex:1; border:2px solid rgba(221,255,168,.45); padding:12px 8px; text-align:center; }}
.channel-xhs .gq-hero {{ margin-top:56px; min-height:326px; padding:48px 50px 38px; }}
.channel-xhs .gq-hero-kicker {{ font-size:62px; }}
.channel-xhs .gq-hero-title {{ font-size:42px; max-width:720px; }}
.channel-xhs .gq-hero-sub {{ font-size:24px; margin-left:148px; }}
.channel-xhs .gq-mascot {{ top:462px; left:58px; width:150px; height:218px; transform:rotate(-4deg); }}
.channel-xhs .gq-card {{ margin-top:78px; padding:30px 36px 20px; max-height:548px; overflow:hidden; }}
.channel-xhs .gq-section.extra, .channel-xhs .gq-footer {{ display:none; }}
.channel-xhs .gq-slogan {{ max-width:calc(100% - 206px); margin-left:206px; font-size:24px; padding:12px 22px; }}
.channel-xhs .gq-title {{ font-size:42px; }}
.channel-xhs .gq-section {{ margin-top:16px; padding-top:16px; }}
.channel-xhs .gq-section-title {{ font-size:26px; margin-bottom:10px; }}
.channel-xhs .gq-bullet {{ font-size:20px; line-height:1.45; }}
.channel-xhs .gq-check-text {{ font-size:20px; line-height:1.28; }}
.channel-xhs .gq-check-row {{ margin:6px 0; }}
.channel-xhs .gq-check {{ width:24px; height:24px; font-size:18px; border-width:3px; }}
.channel-xhs .gq-apply {{ margin-top:28px; padding:18px 24px; grid-template-columns:1fr 128px; border-radius:22px; z-index:3; }}
.channel-xhs .gq-apply-title {{ font-size:24px; margin-bottom:10px; }}
.channel-xhs .gq-apply-row {{ font-size:20px; margin-top:7px; }}
.channel-xhs .gq-qr, .channel-xhs .gq-qr-placeholder {{ width:118px; height:118px; }}
.channel-xhs .gq-qr-placeholder {{ background:#fff; border:3px solid #08a51c; border-radius:12px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:4px; }}
.channel-xhs .gq-qr-placeholder:before {{ content:"📱"; font-size:36px; position:static; width:auto;height:auto;border:0;background:none;box-shadow:none; }}
.channel-xhs .gq-qr-placeholder:after {{ content:"扫码投递"; position:static; font-size:12px; color:#08a51c; font-weight:700; width:auto;height:auto;border:0;background:none; }}
.channel-moments .gq-card, .channel-douyin .gq-card {{ margin-top:132px; max-height:840px; overflow:hidden; }}
.channel-douyin .gq-title {{ font-size:48px; }}
.channel-moments .gq-apply, .channel-douyin .gq-apply {{ margin-top:32px; padding:24px 34px; grid-template-columns:1fr 188px; border-radius:28px; z-index:3; }}
</style></head><body>
<main class="gq-poster channel-{_html(channel)}">
  <div class="gq-layer">
    <header class="gq-top">
      <div>
        <div class="gq-brand"><img class="gq-logo" src="{_html(company_logo)}" alt="{_html(company_short)}"><div class="gq-cctv">CCTV</div></div>
        <div class="gq-partner">CCTV体育频道美食合作伙伴</div>
      </div>
      <div class="gq-stock">股票代码：{_html(stock_code)}</div>
    </header>

    <div class="gq-clip"></div>
    <section class="gq-hero">
            <div class="gq-hero-kicker">{_html(hero_kicker)}</div>
      <div class="gq-hero-title">{_html(hero_title)}</div>
      <div class="gq-hero-sub">{_html_lines(hero_sub)}</div>
    </section>
    <div class="gq-mascot"><img class="gq-mascot-img" src="{_html(mascot_image)}" alt="{_html(company_short)}品牌形象"></div>
    <div class="gq-star"></div>

    <section class="gq-card gq-channel-safe">
      <div class="gq-slogan">{_html(slogan)}</div>
      <h1 class="gq-title">岗位：{_html(title)}</h1>
      <div class="gq-meta">
        <span class="gq-pill">{_html(department)}</span>
        <span class="gq-pill">{_html(location)}</span>
        <span class="gq-pill">{_html(salary)}</span>
      </div>
      <div class="gq-section">
        <div class="gq-section-title">你将成为：</div>
        <div class="gq-bullet">{"".join(f"·{_html(item)}<br>" for item in become_rows[:4])}</div>
      </div>
      <div class="gq-section">
        <div class="gq-section-title">我们希望你：</div>
        {_render_check_rows(expect_rows, 4)}
      </div>
      {story_html}
    </section>

    <section class="gq-apply">
      <div>
        <div class="gq-apply-title">{_html(apply_title)}：</div>
        <div class="gq-apply-row"><span class="gq-apply-label">方式一</span> 邮箱甩简历 → {_html(apply_email)}</div>
        <div class="gq-apply-row"><span class="gq-apply-label">方式二</span> 扫码一键起飞 →</div>
        {apply_url_html}
      </div>
      <div>{qr_html}</div>
    </section>

    <footer class="gq-footer">
      <span>万店品牌，圈你入局</span><span>锅圈速度，带你原地起飞！</span><span>这个秋天，一起“锅”出个未来！</span>
    </footer>
  </div>
</main>
</body></html>"""


def _hex_to_rgb(hex_color: str) -> str:
    """Convert hex color to RGB string for rgba()"""
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        return f"{r},{g},{b}"
    except (ValueError, IndexError):
        return "196,18,48"


def _darken_color(hex_color: str, factor: float) -> str:
    """将 hex 颜色加深"""
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        r, g, b = int(r * (1 - factor)), int(g * (1 - factor)), int(b * (1 - factor))
        return f"#{r:02x}{g:02x}{b:02x}"
    except (ValueError, IndexError):
        return hex_color


def _lighten_color(hex_color: str, factor: float) -> str:
    """将 hex 颜色变浅"""
    h = hex_color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        r = min(255, int(r + (255 - r) * factor))
        g = min(255, int(g + (255 - g) * factor))
        b = min(255, int(b + (255 - b) * factor))
        return f"#{r:02x}{g:02x}{b:02x}"
    except (ValueError, IndexError):
        return hex_color


def _render_poster_html(template_id: str, data: dict) -> str:
    """生成品牌招聘海报（食材零售 / 科技风双模式）"""
    if template_id == "guoquan_green_recruit":
        return _render_guoquan_green_recruit(data)

    title = data.get("title", "诚聘英才")
    salary = data.get("salary", "面议")
    location = data.get("location", "上海")
    highlights = data.get("highlights", [])
    requirements = data.get("requirements", [])
    team_intro = data.get("team_intro", "")
    department = data.get("department", "")
    company_name = data.get("company_name", "")
    company_short = data.get("company_short", company_name)
    brand_color = data.get("brand_color", "")
    brand_color_secondary = data.get("brand_color_secondary", "")
    company_logo = data.get("company_logo", "")
    poster_bg_image = data.get("poster_bg_image", "")

    themes = {
        "tech_blue": {
            "bg1": "#030712",
            "bg2": "#0f172a",
            "bg3": "#1e293b",
            "accent": "#38bdf8",
            "accent2": "#818cf8",
            "accent3": "#06b6d4",
            "glow1": "rgba(56,189,248,0.12)",
            "glow2": "rgba(129,140,248,0.08)",
            "card_bg": "rgba(255,255,255,0.03)",
            "card_border": "rgba(255,255,255,0.06)",
        },
        "startup_green": {
            "bg1": "#022c22",
            "bg2": "#064e3b",
            "bg3": "#065f46",
            "accent": "#34d399",
            "accent2": "#a78bfa",
            "accent3": "#2dd4bf",
            "glow1": "rgba(52,211,153,0.12)",
            "glow2": "rgba(167,139,250,0.08)",
            "card_bg": "rgba(255,255,255,0.03)",
            "card_border": "rgba(255,255,255,0.06)",
        },
        "corporate_gold": {
            "bg1": "#0c0a09",
            "bg2": "#1c1917",
            "bg3": "#292524",
            "accent": "#fbbf24",
            "accent2": "#fb923c",
            "accent3": "#f59e0b",
            "glow1": "rgba(251,191,36,0.12)",
            "glow2": "rgba(251,146,60,0.08)",
            "card_bg": "rgba(255,255,255,0.03)",
            "card_border": "rgba(255,255,255,0.06)",
        },
        "guoquan_red": {
            "bg1": "#1a0a0a",
            "bg2": "#2d0f0f",
            "bg3": "#3d1515",
            "accent": "#E60012",
            "accent2": "#FF6B00",
            "accent3": "#FF4458",
            "glow1": "rgba(196,18,48,0.15)",
            "glow2": "rgba(212,168,83,0.10)",
            "card_bg": "rgba(255,255,255,0.04)",
            "card_border": "rgba(212,168,83,0.15)",
        },
    }
    t = themes.get(template_id, themes["tech_blue"])

    # 如果传入了品牌色，覆盖模板默认色
    if brand_color:
        t = dict(t)
        t["accent"] = brand_color
        t["accent3"] = brand_color
        t["glow1"] = f"rgba({_hex_to_rgb(brand_color)},0.15)"
    if brand_color_secondary:
        t = dict(t) if brand_color else t
        t["accent2"] = brand_color_secondary
        t["glow2"] = f"rgba({_hex_to_rgb(brand_color_secondary)},0.10)"

    # 派生颜色
    t["accent_dark"] = _darken_color(t["accent"], 0.45)
    t["accent_light"] = _lighten_color(t["accent"], 0.15)

    # 公司名首字用于顶部展示
    co_initial = company_short[0] if company_short else "锅"
    co_name = company_name or "锅圈食汇"

    # 亮点和要求的 HTML — 锅圈食汇和科技风使用不同样式
    is_guoquan = template_id == "guoquan_red"
    if is_guoquan:
        highlights_html = _render_hl_guoquan(highlights)
        req_tags = _render_req_guoquan(requirements)
    else:
        hl_icons = ["🎯", "⚡", "🔥", "💎"]
        highlights_html = "".join(
            f'<div style="display:flex;align-items:flex-start;gap:12px;padding:14px 16px;'
            f"background:{t['card_bg']};border:1px solid {t['card_border']};"
            f'border-radius:12px;margin-bottom:8px">'
            f'<span style="flex-shrink:0;font-size:18px;line-height:1">{hl_icons[i]}</span>'
            f'<span style="font-size:15px;color:#e2e8f0;line-height:1.6">{h}</span></div>'
            for i, h in enumerate(highlights[:4])
        )
        req_tags = "".join(
            f'<span style="display:inline-flex;align-items:center;gap:4px;'
            f"padding:7px 16px;border-radius:20px;font-size:13px;font-weight:500;"
            f"color:{t['accent']};background:{t['glow1']};"
            f'border:1px solid rgba(255,255,255,0.08);margin:4px">'
            f'<span style="width:4px;height:4px;border-radius:50%;background:{t["accent"]};opacity:0.6"></span>'
            f"{r}</span>"
            for r in requirements[:5]
        )

    dept_html = f'<span class="dept-tag">{department}</span>' if department else ""
    team_html = f'<div class="team-section"><div class="team-intro">{team_intro}</div></div>' if team_intro else ""

    # 底图样式
    bg_image_style = ""
    bg_overlay = ""
    if poster_bg_image:
        bg_image_style = f"background-image:url({poster_bg_image});background-size:cover;background-position:center;"
        bg_overlay = '<div class="bg-overlay"></div>'

    # Logo HTML（带 fallback）
    if company_logo:
        logo_html = f"<img src=\"{company_logo}\" style=\"width:100%;height:100%;object-fit:contain;border-radius:inherit\" onerror=\"this.style.display='none';this.parentElement.textContent='{co_initial}';this.parentElement.style.display='flex';this.parentElement.style.alignItems='center';this.parentElement.style.justifyContent='center';this.parentElement.style.fontSize='18px';this.parentElement.style.fontWeight='800';this.parentElement.style.color='#fff'\">"
    else:
        logo_html = co_initial

    is_guoquan = template_id == "guoquan_red"

    if is_guoquan:
        return _render_guoquan_poster(
            t,
            title,
            salary,
            location,
            highlights,
            requirements,
            team_intro,
            department,
            co_name,
            co_initial,
            logo_html,
            dept_html,
            team_html,
            highlights_html,
            req_tags,
            poster_bg_image,
            bg_image_style,
            bg_overlay,
        )
    else:
        return _render_tech_poster(
            t,
            title,
            salary,
            location,
            highlights,
            requirements,
            team_intro,
            department,
            co_name,
            co_initial,
            logo_html,
            dept_html,
            team_html,
            highlights_html,
            req_tags,
            poster_bg_image,
            bg_image_style,
            bg_overlay,
        )


def _render_tech_poster(
    t,
    title,
    salary,
    location,
    highlights,
    requirements,
    team_intro,
    department,
    co_name,
    co_initial,
    logo_html,
    dept_html,
    team_html,
    highlights_html,
    req_tags,
    poster_bg_image,
    bg_image_style,
    bg_overlay,
):
    """科技风海报（tech_blue / startup_green / corporate_gold）"""
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{
  font-family: 'Inter', -apple-system, 'PingFang SC', 'Helvetica Neue', sans-serif;
  background: {t["bg1"]}; color: #fff; width: 100%; overflow: hidden;
  -webkit-font-smoothing: antialiased;
}}
.poster {{
  position: relative; padding: 36px 28px 28px; overflow: hidden;
  background: {t["bg1"]}; color: #fff; {bg_image_style}
}}
.bg-overlay {{ position:absolute; inset:0; background:linear-gradient(135deg, {t["bg1"]}dd, {t["bg2"]}cc); z-index:0; }}
.bg-grid {{ position:absolute; inset:0; opacity:0.03; z-index:0;
  background-image:linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px),linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px);
  background-size:40px 40px; }}
.bg-glow-1 {{ position:absolute; width:500px; height:500px; top:-200px; right:-150px; border-radius:50%; z-index:0;
  background:radial-gradient(circle,{t["glow1"]},transparent 65%); filter:blur(40px); }}
.bg-glow-2 {{ position:absolute; width:350px; height:350px; bottom:-100px; left:-100px; border-radius:50%; z-index:0;
  background:radial-gradient(circle,{t["glow2"]},transparent 65%); filter:blur(50px); }}
.content {{ position:relative; z-index:1; }}
.top-bar {{ display:flex; align-items:center; justify-content:space-between; margin-bottom:32px; }}
.hiring-badge {{ display:inline-flex; align-items:center; gap:6px; padding:6px 16px; border-radius:24px;
  font-size:11px; font-weight:700; letter-spacing:2px; text-transform:uppercase;
  color:{t["accent"]}; background:linear-gradient(135deg,{t["glow1"]},{t["glow2"]});
  border:1px solid rgba(255,255,255,0.08); backdrop-filter:blur(8px); }}
.hiring-dot {{ width:6px; height:6px; border-radius:50%; background:{t["accent"]}; box-shadow:0 0 8px {t["accent"]}; }}
.dept-tag {{ font-size:13px; color:rgba(255,255,255,0.45); background:{t["card_bg"]}; padding:3px 10px; border-radius:6px; border:1px solid {t["card_border"]}; }}
.hero {{ margin-bottom:36px; }}
.hero-title {{ font-size:40px; font-weight:900; line-height:1.2; letter-spacing:-0.5px; margin-bottom:18px;
  color:#fff; text-shadow:0 0 30px {t["glow1"]},0 2px 4px rgba(0,0,0,0.3); }}
.hero-sub {{ display:flex; align-items:center; gap:16px; flex-wrap:wrap; }}
.salary-pill {{ display:inline-flex; align-items:center; padding:10px 24px; border-radius:28px;
  font-size:22px; font-weight:800; letter-spacing:0.5px; color:#fff;
  background:linear-gradient(135deg,{t["accent"]},{t["accent2"]});
  box-shadow:0 4px 20px {t["glow1"]},inset 0 1px 0 rgba(255,255,255,0.15); }}
.location-text {{ font-size:14px; color:rgba(255,255,255,0.5); display:flex; align-items:center; gap:4px; }}
.sep {{ height:1px; margin:0 0 32px; background:linear-gradient(90deg,{t["accent"]}33,{t["card_border"]},transparent); }}
.grid {{ display:flex; gap:24px; }} .grid .col {{ flex:1; min-width:0; }}
.sec-head {{ display:flex; align-items:center; gap:8px; margin-bottom:16px; }}
.sec-icon {{ width:28px; height:28px; border-radius:8px; display:flex; align-items:center; justify-content:center;
  font-size:14px; background:{t["glow1"]}; border:1px solid {t["card_border"]}; }}
.sec-title {{ font-size:13px; font-weight:700; color:rgba(255,255,255,0.7); letter-spacing:1px; text-transform:uppercase; }}
.cta {{ margin-top:32px; padding:20px 24px; border-radius:16px;
  background:linear-gradient(135deg,{t["glow1"]},rgba(255,255,255,0.01));
  border:1px solid {t["card_border"]}; text-align:center; position:relative; overflow:hidden; }}
.cta::before {{ content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,transparent 40%,{t["glow1"]} 100%); opacity:0.5; }}
.cta-inner {{ position:relative; z-index:1; }}
.cta-main {{ font-size:16px; font-weight:700; color:{t["accent"]}; letter-spacing:0.5px; }}
.cta-sub {{ font-size:11px; color:rgba(255,255,255,0.35); margin-top:6px; letter-spacing:0.5px; }}
@media (max-width:520px) {{ .poster {{ padding:24px 16px 20px; }} .hero-title {{ font-size:28px; }} .grid {{ flex-direction:column; gap:24px; }} .salary-pill {{ font-size:17px; padding:6px 16px; }} }}
</style></head><body>
<div class="poster">
  {bg_overlay}<div class="bg-grid"></div><div class="bg-glow-1"></div><div class="bg-glow-2"></div>
  <div class="content">
    <div class="top-bar">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,{t["accent"]},{t["accent2"]});display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:#fff;flex-shrink:0;overflow:hidden">{logo_html}</div>
        <div class="hiring-badge"><span class="hiring-dot"></span>WE ARE HIRING</div>
      </div>
      {dept_html}
    </div>
    <div class="hero">
      <div class="hero-title">{title}</div>
      <div class="hero-sub"><span class="salary-pill">{salary}</span><span class="location-text">📍 {location}</span></div>
    </div>
    <div class="sep"></div>
    <div class="grid">
      <div class="col"><div class="sec-head"><div class="sec-icon">✨</div><div class="sec-title">岗位亮点</div></div>{highlights_html}</div>
      <div class="col"><div class="sec-head"><div class="sec-icon">🎯</div><div class="sec-title">核心要求</div></div><div style="display:flex;flex-wrap:wrap">{req_tags}</div></div>
    </div>
    {team_html}
    <div class="cta"><div class="cta-inner"><div class="cta-main">投递简历 → 加入{co_name}</div><div class="cta-sub">AI 智能匹配 · 48h 内反馈 · 全程透明</div></div></div>
  </div>
</div>
</body></html>"""


def _render_guoquan_poster(
    t,
    title,
    salary,
    location,
    highlights,
    requirements,
    team_intro,
    department,
    co_name,
    co_initial,
    logo_html,
    dept_html,
    team_html,
    highlights_html,
    req_tags,
    poster_bg_image,
    bg_image_style,
    bg_overlay,
):
    """锅圈食汇食材零售风海报 — 红色边框、火锅食材装饰、优雅排版"""
    accent = t["accent"]
    accent2 = t["accent2"]
    gold_line = '<div class="gold-line"></div>'
    # 食材装饰 SVG（火锅轮廓、蒸汽、食材图标、波纹）
    brand_decor = f"""<div class="brand-decor" aria-hidden="true">
      <svg viewBox="0 0 400 200" xmlns="http://www.w3.org/2000/svg">
        <!-- 左上角 — 火锅食材装饰 -->
        <g transform="translate(20,30)" opacity="0.12">
          <path d="M20 45 Q20 25 25 15 Q30 5 35 15 Q40 25 40 45" stroke="{accent2}" stroke-width="1.5" fill="none"/>
          <path d="M25 45 Q25 30 30 20 Q35 10 35 20 Q35 30 35 45" stroke="{accent2}" stroke-width="1" fill="none" opacity="0.6"/>
        </g>
        <!-- 右上角 — 火锅轮廓 -->
        <g transform="translate(320,20)" opacity="0.10">
          <path d="M10 50 Q10 35 25 32 L40 32 Q55 35 55 50 Z" fill="{accent2}"/>
          <path d="M12 53 Q32 57 52 53" stroke="{accent2}" stroke-width="1.5" fill="none"/>
          <ellipse cx="32" cy="27" rx="16" ry="3" fill="{accent}" opacity="0.5"/>
          <!-- 蒸汽 -->
          <path d="M28 24 Q25 16 28 10" stroke="{accent2}" stroke-width="0.6" fill="none" opacity="0.4"/>
          <path d="M32 23 Q34 14 31 8" stroke="{accent2}" stroke-width="0.5" fill="none" opacity="0.3"/>
          <path d="M36 24 Q38 15 35 9" stroke="{accent2}" stroke-width="0.6" fill="none" opacity="0.35"/>
        </g>
        <!-- 底部 — 红色波纹 -->
        <g transform="translate(0,140)" opacity="0.06">
          <path d="M0 20 Q25 5 50 20 Q75 35 100 20 Q125 5 150 20 Q175 35 200 20 Q225 5 250 20 Q275 35 300 20 Q325 5 350 20 Q375 35 400 20" stroke="{accent2}" stroke-width="1.5" fill="none"/>
          <path d="M0 35 Q30 22 60 35 Q90 48 120 35 Q150 22 180 35 Q210 48 240 35 Q270 22 300 35 Q330 48 360 35 Q390 22 400 30" stroke="{accent2}" stroke-width="1" fill="none"/>
          <path d="M0 48 Q40 38 80 48 Q120 58 160 48 Q200 38 240 48 Q280 58 320 48 Q360 38 400 45" stroke="{accent2}" stroke-width="0.6" fill="none"/>
        </g>
        <!-- 左下角 — 食材图标 -->
        <g transform="translate(40,155)" opacity="0.08">
          <ellipse cx="0" cy="0" rx="8" ry="3" fill="{accent2}" transform="rotate(25)"/>
          <ellipse cx="15" cy="-5" rx="7" ry="2.5" fill="{accent2}" transform="rotate(-15 15 -5)"/>
          <ellipse cx="-8" cy="8" rx="6" ry="2.5" fill="{accent2}" transform="rotate(40 -8 8)"/>
        </g>
        <!-- 右侧 — 网格装饰 -->
        <g transform="translate(355,100)" opacity="0.07">
          <rect x="0" y="0" width="30" height="30" rx="3" stroke="{accent2}" stroke-width="0.8" fill="none"/>
          <line x1="15" y1="0" x2="15" y2="30" stroke="{accent2}" stroke-width="0.5"/>
          <line x1="0" y1="15" x2="30" y2="15" stroke="{accent2}" stroke-width="0.5"/>
          <circle cx="15" cy="15" r="6" stroke="{accent2}" stroke-width="0.6" fill="none"/>
          <circle cx="15" cy="15" r="2" fill="{accent2}"/>
        </g>
      </svg>
    </div>"""

    # 底图：品牌背景 SVG（食材、烟火）
    if not poster_bg_image:
        brand_bg = """<div class="brand-bg" aria-hidden="true">
          <svg viewBox="0 0 400 600" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <radialGradient id="glow1"><stop offset="0%" stop-color="#E60012" stop-opacity="0.12"/><stop offset="100%" stop-color="transparent"/></radialGradient>
              <radialGradient id="glow2"><stop offset="0%" stop-color="#FF6B00" stop-opacity="0.06"/><stop offset="100%" stop-color="transparent"/></radialGradient>
            </defs>
            <rect width="400" height="600" fill="#1a0a0a"/>
            <!-- 光晕 -->
            <ellipse cx="320" cy="100" rx="250" ry="200" fill="url(#glow1)"/>
            <ellipse cx="80" cy="480" rx="200" ry="180" fill="url(#glow2)"/>
            <!-- 远山剪影 -->
            <path d="M0 500 Q50 420 100 460 Q150 380 200 430 Q250 360 300 410 Q350 350 400 400 L400 600 L0 600 Z" fill="#2d0f0f" opacity="0.4"/>
            <path d="M0 520 Q60 470 120 500 Q180 440 240 480 Q300 430 360 470 Q380 450 400 460 L400 600 L0 600 Z" fill="#1a0a0a" opacity="0.6"/>
            <!-- 云雾线条 -->
            <path d="M-20 160 Q60 140 140 165 Q220 140 300 160 Q360 145 420 155" stroke="#FF6B00" stroke-width="0.4" fill="none" opacity="0.08"/>
            <path d="M-20 280 Q80 260 160 275 Q240 255 320 270 Q370 260 420 268" stroke="#FF6B00" stroke-width="0.3" fill="none" opacity="0.06"/>
          </svg>
        </div>"""
    else:
        brand_bg = ""

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Serif+SC:wght@400;600;700;900&display=swap');
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{
  font-family: 'Inter', 'PingFang SC', 'Noto Serif SC', 'STSong', serif;
  background: #1a0a0a; color: #f5f0eb; width: 100%; overflow: hidden;
  -webkit-font-smoothing: antialiased;
}}
.poster {{
  position: relative; padding: 0; overflow: hidden;
  background: linear-gradient(180deg, #1a0a0a 0%, #2d0f0f 40%, #1a0a0a 100%);
  color: #f5f0eb; min-height: 600px; {bg_image_style}
}}
.bg-overlay {{
  position: absolute; inset: 0; z-index: 0;
  background: linear-gradient(180deg, rgba(26,10,10,0.75) 0%, rgba(45,15,15,0.65) 50%, rgba(26,10,10,0.8) 100%);
}}
.brand-bg {{
  position: absolute; inset: 0; z-index: 0; overflow: hidden;
}}
.brand-bg svg {{
  width: 100%; height: 100%; object-fit: cover;
}}

/* ── 顶部 Banner 区 ── */
.banner {{
  position: relative; z-index: 1;
  padding: 0 28px;
  background: linear-gradient(180deg, rgba(196,18,48,0.12) 0%, rgba(26,10,10,0) 100%);
  border-bottom: 1px solid rgba(212,168,83,0.18);
}}
.banner-inner {{
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 0 16px;
}}
.banner-brand {{
  display: flex; align-items: center; gap: 12px;
}}
.banner-logo {{
  width: 48px; height: 48px; border-radius: 14px;
  background: linear-gradient(135deg, {t["accent"]}, {t["accent_dark"]});
  display: flex; align-items: center; justify-content: center;
  font-size: 20px; font-weight: 900; color: #fff;
  box-shadow: 0 4px 20px rgba({_hex_to_rgb(t["accent"])},0.3);
  flex-shrink: 0; overflow: hidden;
}}
.banner-name {{
  font-size: 18px; font-weight: 700; color: #f5f0eb;
  letter-spacing: 1px;
}}
.banner-sub {{
  font-size: 11px; color: rgba(212,168,83,0.7);
  letter-spacing: 2px; text-transform: uppercase;
  margin-top: 2px;
}}
.banner-badge {{
  display: inline-flex; align-items: center; gap: 6px;
  padding: 6px 16px; border-radius: 20px;
  font-size: 11px; font-weight: 700; letter-spacing: 2px;
  color: {t["accent2"]};
  border: 1px solid rgba({_hex_to_rgb(t["accent2"])},0.3);
  background: rgba({_hex_to_rgb(t["accent2"])},0.06);
  backdrop-filter: blur(8px);
}}
.banner-dot {{
  width: 6px; height: 6px; border-radius: 50%;
  background: {t["accent2"]}; box-shadow: 0 0 8px rgba({_hex_to_rgb(t["accent2"])},0.5);
}}

/* ── 金色装饰线 ── */
.gold-line {{
  width: 100%; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(212,168,83,0.5) 20%, rgba(212,168,83,0.7) 50%, rgba(212,168,83,0.5) 80%, transparent);
  margin: 0;
}}

/* ── 主体内容 ── */
.main-body {{
  position: relative; z-index: 1;
  padding: 24px 28px 20px;
}}

/* 岗位标题 */
.job-title {{
  font-family: 'Noto Serif SC', 'STSong', 'PingFang SC', serif;
  font-size: 42px; font-weight: 900; line-height: 1.25;
  letter-spacing: 2px; margin-bottom: 16px;
  color: #fff;
  text-shadow: 0 2px 8px rgba(196,18,48,0.3);
}}
.job-title-en {{
  font-family: 'Inter', sans-serif;
  font-size: 13px; font-weight: 400; color: rgba(212,168,83,0.5);
  letter-spacing: 3px; text-transform: uppercase;
  margin-bottom: 20px;
}}

/* 薪酬 + 地点 */
.meta-row {{
  display: flex; align-items: center; gap: 16px; margin-bottom: 28px; flex-wrap: wrap;
}}
.salary-tag {{
  display: inline-flex; align-items: center; gap: 6px;
  padding: 12px 24px; border-radius: 30px;
  font-size: 22px; font-weight: 800;
  color: #fff;
  background: linear-gradient(135deg, {t["accent"]}, {t["accent_light"]});
  box-shadow: 0 6px 24px rgba({_hex_to_rgb(t["accent"])},0.35), inset 0 1px 0 rgba(255,255,255,0.15);
}}
.salary-icon {{ font-size: 16px; }}
.location-tag {{
  display: inline-flex; align-items: center; gap: 4px;
  padding: 8px 16px; border-radius: 20px;
  font-size: 14px; color: rgba(255,255,255,0.6);
  border: 1px solid rgba(255,255,255,0.12);
  background: rgba(255,255,255,0.03);
}}

/* 食材装饰 */
.brand-decor {{
  padding: 0 28px; position: relative; z-index: 1;
  color: rgba(212,168,83,0.3);
}}
.brand-decor svg {{
  width: 100%; height: auto;
}}

/* 双栏 */
.two-col {{
  display: flex; gap: 20px;
}}
.two-col .col {{ flex: 1; min-width: 0; }}

/* 区块 */
.section-label {{
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 14px;
}}
.section-label .sl-dot {{
  width: 8px; height: 8px; border-radius: 2px;
  background: {t["accent2"]}; box-shadow: 0 0 6px rgba({_hex_to_rgb(t["accent2"])},0.4);
}}
.section-label .sl-text {{
  font-size: 13px; font-weight: 700; color: rgba(212,168,83,0.8);
  letter-spacing: 1.5px; text-transform: uppercase;
}}

/* 亮点卡片 */
.hl-card {{
  display: flex; align-items: flex-start; gap: 12px;
  padding: 14px 16px; margin-bottom: 8px;
  border-radius: 12px;
  background: rgba(255,255,255,0.025);
  border: 1px solid rgba(212,168,83,0.1);
  transition: border-color 0.2s;
}}
.hl-card:hover {{ border-color: rgba(212,168,83,0.25); }}
.hl-num {{
  width: 24px; height: 24px; border-radius: 6px; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 700;
  background: rgba(196,18,48,0.2); color: #E8384F;
}}
.hl-text {{
  font-size: 15px; color: #e8d5c8; line-height: 1.6; font-weight: 500;
}}

/* 要求标签 */
.req-tag {{
  display: inline-flex; align-items: center; gap: 4px;
  padding: 7px 14px; border-radius: 18px;
  font-size: 13px; font-weight: 500; margin: 3px;
  color: rgba(255,255,255,0.7);
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
}}
.req-dot {{
  width: 4px; height: 4px; border-radius: 50%;
  background: {t["accent2"]}; opacity: 0.6;
}}

/* 团队介绍 */
.team-section {{ margin-top: 20px; }}
.team-intro {{
  padding: 16px 18px; border-radius: 12px;
  background: rgba(255,255,255,0.02);
  border: 1px solid rgba(212,168,83,0.1);
  font-size: 13px; color: rgba(255,255,255,0.45); line-height: 1.8;
  font-style: italic; letter-spacing: 0.5px;
}}

/* 底部 CTA */
.cta-section {{
  position: relative; z-index: 1;
  padding: 20px 28px 24px;
  background: linear-gradient(180deg, rgba(196,18,48,0.08) 0%, rgba(196,18,48,0.15) 100%);
  border-top: 1px solid rgba(212,168,83,0.12);
  text-align: center;
}}
.cta-text {{
  font-size: 17px; font-weight: 700; color: {t["accent2"]};
  letter-spacing: 1px; margin-bottom: 6px;
}}
.cta-subtext {{
  font-size: 11px; color: rgba(255,255,255,0.3);
  letter-spacing: 1px;
}}

/* 响应式 */
@media (max-width: 520px) {{
  .banner {{ padding: 0 16px; }}
  .main-body {{ padding: 16px; }}
  .job-title {{ font-size: 28px; letter-spacing: 1px; }}
  .two-col {{ flex-direction: column; gap: 16px; }}
  .salary-tag {{ font-size: 17px; padding: 8px 18px; }}
  .cta-section {{ padding: 16px; }}
}}
</style></head><body>
<div class="poster">
  {brand_bg}
  {bg_overlay}

  <!-- 顶部 Banner -->
  <div class="banner">
    <div class="banner-inner">
      <div class="banner-brand">
        <div class="banner-logo">{logo_html}</div>
        <div>
          <div class="banner-name">{co_name}</div>
          <div class="banner-sub">烧烤火锅食材 一站配齐</div>
        </div>
      </div>
      <div class="banner-badge"><span class="banner-dot"></span>正在招聘</div>
    </div>
  </div>
  {gold_line}

  <!-- 主体内容 -->
  <div class="main-body">
    <!-- 岗位标题 -->
    <div class="job-title-en">Career Opportunity</div>
    <div class="job-title">{title}</div>

    <!-- 薪酬地点 -->
    <div class="meta-row">
      <div class="salary-tag"><span class="salary-icon">💰</span>{salary}</div>
      <div class="location-tag">📍 {location}</div>
      {dept_html}
    </div>

    <!-- 双栏 -->
    <div class="two-col">
      <div class="col">
        <div class="section-label"><div class="sl-dot"></div><div class="sl-text">岗位亮点</div></div>
        {highlights_html}
      </div>
      <div class="col">
        <div class="section-label"><div class="sl-dot"></div><div class="sl-text">我们需要你</div></div>
        <div style="display:flex;flex-wrap:wrap">{req_tags}</div>
      </div>
    </div>

    {team_html}
  </div>

  <!-- 食材装饰分隔 -->
  {brand_decor}

  <!-- 底部 CTA -->
  <div class="cta-section">
    <div class="cta-text" style="font-size:15px;color:#fff;margin-top:4px">投递简历 → 加入{co_name}</div>
    <div class="cta-subtext">AI 智能匹配 · 48h 内反馈 · 全程透明</div>
  </div>
</div>
</body></html>"""


def _render_poster_variants(template_id: str, data: dict) -> dict:
    """Render every supported channel variant from the same poster data."""
    variants = {}
    for channel, cfg in POSTER_CHANNELS.items():
        channel_data = {
            **data,
            "channel": channel,
            "canvas_width": cfg["width"],
            "canvas_height": cfg["height"],
        }
        variants[channel] = {
            "label": cfg["label"],
            "width": cfg["width"],
            "height": cfg["height"],
            "poster_html": _render_poster_html(template_id, channel_data),
        }
    return variants


def render_guoquan_default_poster(fields: Optional[dict] = None) -> dict:
    """Render the deterministic Guoquan green poster from Xiao Hai fields."""
    fields = fields if isinstance(fields, dict) else {}
    title = str(fields.get("jobTitle") or fields.get("title") or "招聘岗位").strip()
    company_name = str(fields.get("companyName") or fields.get("company_name") or "锅圈食汇").strip()
    company_short = str(fields.get("companyShort") or ("锅圈" if "锅圈" in company_name else company_name)).strip()
    responsibilities = _as_list(
        fields.get("responsibilities") or fields.get("you_will_become"),
        ["负责门店日常运营与服务", "执行食品安全与清洁巡检", "积极推动门店业绩增长", "完成原料盘点与经营复盘"],
    )
    requirements = _as_list(
        fields.get("requirements"),
        ["年满十八周岁且持有效健康证", "适应早晚轮班及周末排班", "无严重过敏史并熟悉基础制作流程"],
    )
    highlights = _as_list(
        fields.get("highlights") or fields.get("benefits"),
        ["晋升路径清晰，专业带教成长快", "底薪是锅底，提成是涮菜"],
    )
    current_date = str(fields.get("current_date") or datetime.now().strftime("%Y-%m-%d"))
    poster_data = {
        "title": title,
        "salary": fields.get("salary") or "面议",
        "location": fields.get("location") or "全国",
        "department": fields.get("department") or "门店经营",
        "highlights": highlights,
        "responsibilities": responsibilities,
        "requirements": requirements,
        "company_name": company_name,
        "company_short": company_short,
        "company_logo": fields.get("companyLogo") or "/brand/guoquan-logo.svg",
        "mascot_image": fields.get("mascotImage") or "/brand/guoquan-mascot.png",
        "apply_email": fields.get("email") or fields.get("apply_email") or "",
        "apply_url": fields.get("deliveryLink") or fields.get("delivery_link") or fields.get("apply_url") or "",
        "hr_qr_code": fields.get("qr_code") or fields.get("qrCode") or "",
        "stock_code": fields.get("stockCode") or "02517.HK",
        "current_date": current_date,
    }
    location_prefix = str(poster_data["location"]).strip()
    if location_prefix in {"全国", "不限", ""}:
        location_prefix = ""
    poster_data.update(
        {
            "hero_kicker": f"寻味青春·热招{title}",
            "hero_title": f"{company_name}{location_prefix}旗舰店招募",
            "hero_sub": "排班灵活月休四天<br>阶梯调薪年终享双薪",
            "slogan": "专业带教助你直通店长",
            "apply_title": f"扫码开启你的{title}生涯",
        }
    )
    for key in ["hero_kicker", "hero_title", "hero_sub", "slogan", "apply_title"]:
        if fields.get(key):
            poster_data[key] = fields[key]

    variants = _render_poster_variants("guoquan_green_recruit", poster_data)
    return {
        "poster_html": variants["long"]["poster_html"],
        "poster_data": poster_data,
        "variants": variants,
        "template_id": "guoquan_green_recruit",
        "status": "completed",
    }


def _apply_poster_overrides(poster_data: dict, overrides: dict) -> dict:
    """Apply Xiao Hai AI copy edits without replacing JD/company source of truth."""
    if not isinstance(overrides, dict) or not overrides:
        return poster_data

    merged = dict(poster_data)
    allowed_keys = {
        "salary",
        "location",
        "department",
        "highlights",
        "requirements",
        "responsibilities",
        "apply_email",
        "apply_url",
        "qr_code",
        "hr_qr_code",
        "stock_code",
        "hero_kicker",
        "hero_title",
        "hero_sub",
        "slogan",
        "apply_title",
    }
    for key in allowed_keys:
        value = overrides.get(key)
        if value not in (None, "", []):
            merged[key] = value
    return merged


def _render_hl_guoquan(highlights):
    """锅圈食汇风格亮点卡片"""
    icons = ["🍵", "✨", "🔥", "💎"]
    return "".join(
        f'<div class="hl-card"><div class="hl-num">{icons[i]}</div><div class="hl-text">{h}</div></div>'
        for i, h in enumerate(highlights[:4])
    )


def _render_req_guoquan(requirements):
    """锅圈食汇风格要求标签"""
    return "".join(f'<span class="req-tag"><span class="req-dot"></span>{r}</span>' for r in requirements[:6])


class PosterAgent(BaseAgent):
    async def _generate_ai_copy(
        self,
        jd: dict,
        company_short: str,
        current_date: str,
        instruction: str = "",
        current_poster: Optional[dict] = None,
    ) -> dict:
        """Use the model to write compact poster copy from JD, date, and edit instruction."""
        system = """你是锅圈食汇资深招聘海报文案设计师。
你必须根据 JD、公司配置和当前日期写海报文案，不要照抄用户改稿要求。
所有输出都要短句化，适合 1080px 宽竖版海报：亮点每条 10-18 个汉字，职责/要求每条 14-24 个汉字。
除非当前日期接近 9-10 月中秋/国庆档，否则禁止使用“十一”“国庆”“金秋”。
输出严格 JSON：
{
  "hero_kicker": "顶部主标题",
  "hero_title": "顶部副标题",
  "hero_sub": "两行副文案，用<br>分行",
  "slogan": "培养口号",
  "apply_title": "投递区标题",
  "highlights": ["亮点1", "亮点2", "亮点3", "亮点4"],
  "responsibilities": ["职责1", "职责2", "职责3", "职责4"],
  "requirements": ["要求1", "要求2", "要求3"]
}"""
        prompt = {
            "current_date": current_date,
            "company_short": company_short,
            "jd": jd,
            "current_poster": current_poster or {},
            "edit_instruction": instruction,
        }

        def validator(result):
            return isinstance(result, dict) and isinstance(result.get("highlights"), list)

        result = await self.call_llm_json(
            json.dumps(prompt, ensure_ascii=False),
            system,
            complexity="flash",
            temperature=0.65 if instruction else 0.45,
            validator=validator,
            max_retries=1,
            timeout=45,
        )
        if not isinstance(result, dict):
            return {}

        cleaned = {}
        for key, max_len in {
            "hero_kicker": 12,
            "hero_title": 22,
            "slogan": 26,
            "apply_title": 18,
        }.items():
            if result.get(key):
                cleaned[key] = _sanitize_time_terms(_limit_text(result[key], max_len), current_date)
        if result.get("hero_sub"):
            lines = _as_list(str(result["hero_sub"]).replace("<br>", "\n"))
            cleaned["hero_sub"] = "<br>".join(
                _sanitize_time_terms(_limit_text(line, 24), current_date) for line in lines[:2]
            )
        cleaned["highlights"] = [
            _sanitize_time_terms(row, current_date) for row in _limit_list(result.get("highlights"), 4, 18)
        ]
        cleaned["responsibilities"] = _limit_list(result.get("responsibilities"), 4, 24)
        cleaned["requirements"] = _limit_list(result.get("requirements"), 3, 24)
        return {key: value for key, value in cleaned.items() if value not in ("", [])}

    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        jd = data.get("jd", {})
        role = data.get("role", "高级前端工程师")
        company_config = data.get("company_config", {})

        if not isinstance(jd, dict) or not jd:
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"poster_html": "", "status": "no_jd"},
                duration_ms=int((time.time() - start) * 1000),
            )

        # 公司配置优先：品牌色、公司名、底图均从配置取，JD 数据为 fallback
        brand_color = company_config.get("brand_color", "")
        brand_color_secondary = company_config.get("brand_color_secondary", "")
        company_name = company_config.get("company_name", "") or jd.get("company_name", "") or "锅圈食汇"
        company_short = company_config.get("company_short", "") or company_name
        poster_bg_image = company_config.get("poster_bg_image", "")
        current_date = data.get("current_date") or datetime.now().strftime("%Y-%m-%d")
        instruction = str(data.get("instruction") or "").strip()
        initial_copy = await self._generate_ai_copy(jd, company_short, current_date)
        highlights = initial_copy.get("highlights", [])

        template_id = _resolve_template_id(company_config.get("poster_template", ""), company_name, role)

        # 清洗薪资格式：去掉逗号分隔，统一展示（8-12K，13薪 → 8-12K · 13薪）
        raw_salary = jd.get("salary_range", "") or "面议"
        salary = (
            raw_salary.replace("，", " · ")
            .replace(", ", " · ")
            .replace(",", " · ")
            .replace("/", " · ")
            .replace("  ", " ")
        )

        poster_data = {
            "title": jd.get("title", role),
            "salary": salary,
            "location": jd.get("location", "上海"),
            "department": jd.get("department", ""),
            "highlights": highlights or ["有竞争力的薪酬", "技术驱动的团队", "扁平化管理"],
            "requirements": initial_copy.get("requirements") or jd.get("requirements", [])[:5],
            "responsibilities": initial_copy.get("responsibilities") or jd.get("responsibilities", [])[:5],
            "team_intro": jd.get("team_intro", ""),
            "company_name": company_name,
            "company_short": company_short,
            "company_logo": company_config.get("company_logo", ""),
            "mascot_image": company_config.get("mascot_image", "") or "/brand/guoquan-mascot.png",
            "brand_color": brand_color,
            "brand_color_secondary": brand_color_secondary,
            "poster_bg_image": poster_bg_image,
            "apply_email": data.get("apply_email") or data.get("hr_contact") or "",
            "apply_url": data.get("apply_url") or "",
            "hr_qr_code": data.get("hr_qr_code") or data.get("qr_code") or "",
            "stock_code": company_config.get("stock_code", "02517.HK"),
            "current_date": current_date,
        }
        poster_data.update(
            _build_dynamic_poster_copy(
                poster_data["title"],
                _as_list(poster_data.get("responsibilities")),
                highlights,
                company_short,
                current_date,
                initial_copy,
            )
        )
        poster_data = _apply_poster_overrides(poster_data, data.get("poster_overrides", {}))
        if instruction and instruction != "手动调整海报标题与培养口号":
            revised_copy = await self._generate_ai_copy(jd, company_short, current_date, instruction, poster_data)
            poster_data = _apply_poster_overrides(poster_data, revised_copy)

        variants = _render_poster_variants(template_id, poster_data)
        poster_html = variants["long"]["poster_html"]

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "poster_html": poster_html,
                "poster_data": poster_data,
                "variants": variants,
                "template_id": template_id,
                "status": "completed",
            },
            duration_ms=int((time.time() - start) * 1000),
        )
