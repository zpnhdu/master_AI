"""Base agent class - uses hermes_wrapper for LLM calls"""

import time
from abc import ABC
from collections.abc import Callable
from typing import Optional

from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline
from hermes_wrapper.client import get_client
from hermes_wrapper.models import LLMRequest
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


class BaseAgent(ABC):
    """Base class - each agent uses hermes_wrapper for LLM calls"""

    def __init__(self):
        self.llm = get_client()
        self._active_deadline: TimeoutDeadline | None = None

    async def execute(self, context: dict) -> dict:
        """Backward-compatible bridge: legacy callers pass a flat dict,
        this wraps it into ToolInput, calls run(), and extracts data.
        New code should use run(ToolInput) → ToolOutput directly."""
        pipeline_id = context.get("pipeline_id", "legacy")
        previous_deadline = self._active_deadline
        self._active_deadline = context.get("deadline")
        try:
            output = await self.run(ToolInput(pipeline_id=pipeline_id, params=context))
        finally:
            self._active_deadline = previous_deadline
        if output.status == AgentStatus.SUCCESS:
            return output.data
        return {"error": output.error, "status": "failed"}

    async def run_with_deadline(self, input: ToolInput, deadline: TimeoutDeadline) -> ToolOutput:
        """Run an agent while exposing its shared business deadline to LLM helpers."""
        previous_deadline = self._active_deadline
        self._active_deadline = deadline
        try:
            return await self.run(input)
        finally:
            self._active_deadline = previous_deadline

    async def run(self, input: ToolInput) -> ToolOutput:
        """Default: raw LLM passthrough. Override for agent-specific prompt logic."""
        start = time.time()
        try:
            prompt = input.params.get("raw_prompt", "")
            system = input.params.get("raw_system", "")
            model = input.params.get("model", "qwen3.6-flash")
            timeout = input.params.get("timeout", 60)
            deadline = input.params.get("deadline")
            temperature = input.params.get("temperature", 0.3)
            json_mode = bool(input.params.get("json_mode", False))
            enable_thinking = input.params.get("enable_thinking")
            result = await self._raw_call_json(
                prompt,
                system,
                model,
                timeout,
                temperature,
                json_mode,
                deadline=deadline,
                agent=input.params.get("agent_id"),
                operation=input.params.get("operation"),
                pipeline_id=input.pipeline_id,
                enable_thinking=enable_thinking,
            )
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data=result,
                tokens_used=len(str(result)) // 4,
                duration_ms=int((time.time() - start) * 1000),
                logs=["LLM passthrough call completed"],
            )
        except BusinessTimeoutError:
            raise
        except Exception as e:
            return ToolOutput(
                status=AgentStatus.FAILED,
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

    async def _raw_call_json(
        self,
        prompt: str,
        system: str,
        model: str,
        timeout: int,
        temperature: float = 0.3,
        json_mode: bool = False,
        deadline: TimeoutDeadline | None = None,
        agent: str | None = None,
        operation: str | None = None,
        pipeline_id: str | None = None,
        enable_thinking: bool | None = None,
    ) -> dict:
        """Direct LLM JSON call with model+timeout — used by default run() and action_handler migration."""
        deadline = self._resolve_deadline(deadline)
        request_timeout = self._request_timeout(timeout, deadline)
        req = LLMRequest(prompt=prompt, system=system, model=model, temperature=temperature)
        req.timeout = request_timeout
        req.enable_thinking = enable_thinking
        request_kwargs = {"deadline": deadline} if deadline is not None else {}
        if agent:
            request_kwargs["agent"] = agent
        if operation:
            request_kwargs["operation"] = operation
        if pipeline_id:
            request_kwargs["pipeline_id"] = pipeline_id
        if json_mode:
            return await self.llm.chat_json(req, json_mode=True, **request_kwargs)
        return await self.llm.chat_json(req, **request_kwargs)

    async def call_llm(
        self,
        prompt: str,
        system: str = "",
        complexity: str = "plus",
        temperature: float = None,
        deadline: TimeoutDeadline | None = None,
    ) -> str:
        """Async LLM call via hermes_wrapper"""
        deadline = self._resolve_deadline(deadline)
        req = LLMRequest(
            prompt=prompt,
            system=system,
            complexity=complexity,
        )
        if deadline is not None:
            req.timeout = deadline.require_remaining()
        if temperature is not None:
            req.temperature = temperature
        request_kwargs = {"deadline": deadline} if deadline is not None else {}
        resp = await self.llm.chat(req, **request_kwargs)
        if resp.error:
            return f"[LLM Error: {resp.error}]"
        return resp.content

    async def call_llm_json(
        self,
        prompt: str,
        system: str = "",
        complexity: str = "plus",
        temperature: float = None,
        validator: Optional[Callable] = None,
        max_retries: int = 2,
        timeout: int = None,
        deadline: TimeoutDeadline | None = None,
        model: str | None = None,
        json_mode: bool = False,
    ) -> dict:
        """Call LLM and parse JSON response with optional validation and retry.

        Args:
            prompt: The user prompt
            system: System prompt
            complexity: LLM complexity level (flash/plus/max)
            temperature: Optional temperature override
            validator: Optional callable(result) -> bool. If returns False, retry with corrective prompt.
            max_retries: Max retry attempts when validator fails (default 2)
            timeout: HTTP timeout in seconds (default: model default)
            deadline: Total business execution budget shared by retries and downstream calls.
        """
        deadline = self._resolve_deadline(deadline)
        last_result = None

        for attempt in range(max_retries + 1):
            request_timeout = self._request_timeout(timeout, deadline)
            req = LLMRequest(
                prompt=prompt,
                system=system,
                model=model or "",
                complexity=complexity,
            )
            req.timeout = request_timeout
            if temperature is not None:
                req.temperature = temperature

            request_kwargs = {"deadline": deadline} if deadline is not None else {}
            if json_mode:
                request_kwargs["json_mode"] = True
            result = await self.llm.chat_json(req, **request_kwargs)
            last_result = result

            # 未配置校验器或校验通过时立即返回
            if validator is None:
                return result

                # 结果为空时跳过校验（LLM 调用失败）
            if result is None or (isinstance(result, dict) and not result):
                if attempt < max_retries:
                    prompt = prompt + "\n\n【修正要求】上一次未能生成有效JSON输出，请严格按照要求的格式重新输出。"
                    continue
                return last_result

                # 运行校验器
            try:
                if validator(result):
                    return result
            except Exception:
                pass

                # 校验失败时追加纠正提示并重试
            if attempt < max_retries:
                prompt = (
                    prompt
                    + "\n\n【修正要求】上一次输出不符合格式要求或内容不完整，请严格按照要求重新输出，确保所有必填字段都存在且格式正确。"
                )

        return last_result

    @staticmethod
    def _request_timeout(timeout: int | None, deadline: TimeoutDeadline | None):
        if deadline is None:
            return timeout if timeout is not None else LLMRequest().timeout
        return deadline.require_remaining()

    def _resolve_deadline(self, deadline: TimeoutDeadline | None) -> TimeoutDeadline | None:
        return deadline or self._active_deadline
