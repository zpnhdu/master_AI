"""Video Agent - 分步深度面试分析：对标 HireVue 评估体系

评估维度参考 HireVue 三大评分维度：
- Content Quality（对标 Language）：用词精准度、关键词匹配、技术深度
- Delivery（对标 Speech/Structure）：表达逻辑、条理性、数据佐证能力
- Behavioral Evidence（对标 STAR）：行为证据完整性（S/T/A/R 四要素）
- Role Competency：岗位胜任力（基于 JD 要求）
- Growth Potential：成长潜力（学习意愿、适应性）
"""

import asyncio
import os
import tempfile
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, Optional

from app.media_storage import get_media_storage
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


def _materialize_video_source(pipeline_id: str, video: dict) -> tuple[Path, Callable[[], None]]:
    """Resolve a local or OSS video to a path usable by ffmpeg."""
    stored_filename = video.get("stored_filename", "")
    storage_key = video.get("storage_key", "")
    if storage_key:
        storage = get_media_storage(video.get("storage_backend") or None)
        if not storage.exists(storage_key):
            raise FileNotFoundError(storage_key)
        fd, temp_path = tempfile.mkstemp(prefix="video_source_", suffix=Path(stored_filename).suffix or ".webm")
        os.close(fd)
        Path(temp_path).write_bytes(storage.read(storage_key))
        path = Path(temp_path)
        return path, lambda: path.unlink(missing_ok=True)

    upload_dir = Path(__file__).resolve().parents[2] / "uploads"
    return upload_dir / pipeline_id / stored_filename, lambda: None


class VideoAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self._progress_cb: Optional[Callable] = None

    async def _progress(self, msg: str):
        """Send progress update to frontend"""
        if self._progress_cb:
            await self._progress_cb(msg)

    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        videos = data.get("videos", [])
        if videos:
            result_data = await self._analyze_videos(data, videos)
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data=result_data,
                duration_ms=int((time.time() - start) * 1000),
            )
        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "status": "waiting_for_videos",
                "assessments": [],
                "message": "等待上传面试视频。请上传面试录播视频（MP4/WebM）或面试文字记录（TXT/PDF）。没有视频也可以跳过。",
            },
            duration_ms=int((time.time() - start) * 1000),
        )

    async def _analyze_videos(self, context: dict[str, Any], videos: list) -> dict[str, Any]:
        candidates = context.get("candidates", [])
        interviews = context.get("interviews", [])
        role = context.get("role", "")
        pipeline_id = context.get("pipeline_id", "")

        if not candidates:
            return {"assessments": [], "status": "no_candidates"}

        # 本体引擎：获取岗位评分权重和规则
        ontology_context = ""
        try:
            from ontology import get_ontology_engine

            ontology = get_ontology_engine(pipeline_id)
            ontology_context = ontology.build_match_prompt_context(role)
        except Exception:
            pass

        interview_map = {i["candidate_id"]: i for i in interviews}
        video_map = {}
        matched_cids = set()

        for v in videos:
            cid = v.get("candidate_id", "")
            cname = v.get("candidate_name", "")
            if cid:
                video_map[cid] = v
                matched_cids.add(cid)
            elif cname:
                for c in candidates:
                    if c["name"] == cname or cname.lower() in c["name"].lower() or c["name"].lower() in cname.lower():
                        video_map[c["id"]] = v
                        matched_cids.add(c["id"])
                        break

        unmatched_videos = [v for v in videos if not any(vv is v for vv in video_map.values())]
        unmatched_candidates = [c for c in candidates if c["id"] not in matched_cids]
        for i, v in enumerate(unmatched_videos):
            if i < len(unmatched_candidates):
                c = unmatched_candidates[i]
                video_map[c["id"]] = v
                matched_cids.add(c["id"])

        assessments = []
        total = len([c for c in candidates if c["id"] in video_map])
        idx = 0
        for cand in candidates:
            video = video_map.get(cand["id"])
            if not video:
                continue

            idx += 1
            interview = interview_map.get(cand["id"], {})
            questions = interview.get("questions", [])
            content = video.get("transcript", "") or video.get("notes", "") or video.get("text", "")

            video_meta = {
                "filename": video.get("filename", ""),
                "file_size": video.get("file_size", 0),
                "file_type": video.get("file_type", ""),
                "is_video": video.get("is_video", False),
                "download_url": video.get("download_url", ""),
                "source": video.get("source", ""),
            }

            questions_text = (
                "\n".join(
                    [f"Q{i + 1}({q.get('type', '')}): {q.get('question', '')}" for i, q in enumerate(questions[:5])]
                )
                if questions
                else "无具体面试题"
            )

            # 真实视频文件：用 qwen-vl-max 直接分析视频
            if video.get("is_video") and video.get("stored_filename"):
                file_size = video.get("file_size", 0)
                size_mb = f"{file_size / 1024 / 1024:.1f}MB" if file_size else ""
                await self._progress(f"🎬 正在分析 {cand['name']} 的面试视频（{size_mb}），预计需要1-3分钟...")
                video_content = await self._analyze_real_video(pipeline_id, video, role, cand, questions_text)
                if video_content and not video_content.startswith("[视频分析失败"):
                    content = video_content
                    await self._progress(f"✅ {cand['name']}：视频分析完成（{len(content)}字）")
                else:
                    await self._progress(f"⚠️ {cand['name']}：视频分析失败，使用文字记录")

            # ====== 第一步：基础评估（5维度+Competency+证据+STAR） ======
            await self._progress(f"正在评估 {cand['name']}（{idx}/{total}）：基础维度+Competency分析...")
            interview = interview_map.get(cand["id"], {})
            basic = await self._call_basic(
                role, cand, questions_text, content, ontology_context, jd=context.get("jd"), interview=interview
            )

            # ====== 第二步：深度分析（切片+逐题+关键时刻+STAR提取） ======
            await self._progress(f"正在评估 {cand['name']}（{idx}/{total}）：面试切片+逐题分析+STAR提取...")
            deep = await self._call_deep(role, cand, questions_text, content)

            # 合并结果
            assessment = {
                "candidate_id": cand["id"],
                "candidate_name": cand["name"],
                "dimensions": basic.get("dimensions", {}),
                "dimension_evidence": basic.get("dimension_evidence", {}),
                "jd_competencies": basic.get("jd_competencies", []),
                "highlights": basic.get("highlights", []),
                "concerns": basic.get("concerns", []),
                "overall_impression": basic.get("overall_impression", ""),
                "recommendation": basic.get("recommendation", "待定"),
                "salary_negotiation_tip": basic.get("salary_negotiation_tip", ""),
                "communication_style": basic.get("communication_style", ""),
                "interview_duration_estimate": basic.get("interview_duration_estimate", ""),
                # 深度分析字段
                "segments": deep.get("segments", []),
                "key_moments": deep.get("key_moments", []),
                "question_analysis": deep.get("question_analysis", []),
                "star_analysis": deep.get("star_analysis", []),
                # 元数据
                "video_meta": video_meta,
            }
            assessments.append(assessment)

        # 百分位排名（对标 HireVue Competency Ranking）
        if len(assessments) >= 2:
            self._compute_percentile_rankings(assessments)

        # 评估一致性校准（对标 Modern Hire Bias Calibration）
        bias_report = self._compute_bias_report(assessments)

        return {
            "assessments": assessments,
            "status": "completed",
            "video_count": len(videos),
            "bias_report": bias_report,
        }

    def _compute_percentile_rankings(self, assessments: list):
        """计算百分位排名（对标 HireVue Competency Ranking）

        为每个候选人的每个维度和Competency计算在所有候选人中的百分位。
        """
        total = len(assessments)

        # 收集所有维度分数
        dim_scores = {}  # {维度键: [评分1, 评分2, ...]}
        for a in assessments:
            for dim_key, score in a.get("dimensions", {}).items():
                if dim_key not in dim_scores:
                    dim_scores[dim_key] = []
                dim_scores[dim_key].append(score)

        # 计算每个候选人的维度百分位
        for a in assessments:
            percentile = {}
            for dim_key, score in a.get("dimensions", {}).items():
                scores_list = sorted(dim_scores.get(dim_key, []))
                rank = sum(1 for s in scores_list if s <= score)
                percentile[dim_key] = round(rank / total * 100) if total > 0 else 0
            a["dimension_percentile"] = percentile

        # 收集 Competency 分数并计算百分位
        comp_names = set()
        for a in assessments:
            for c in a.get("jd_competencies", []):
                comp_names.add(c.get("name", ""))

        for comp_name in comp_names:
            if not comp_name:
                continue
            comp_scores = []
            for a in assessments:
                for c in a.get("jd_competencies", []):
                    if c.get("name") == comp_name:
                        comp_scores.append(c.get("score", 0))

            sorted_scores = sorted(comp_scores)
            for a in assessments:
                for c in a.get("jd_competencies", []):
                    if c.get("name") == comp_name:
                        score = c.get("score", 0)
                        rank = sum(1 for s in sorted_scores if s <= score)
                        c["percentile"] = round(rank / total * 100) if total > 0 else 0

    def _compute_bias_report(self, assessments: list) -> dict:
        """评估一致性校准（对标 Modern Hire Bias Calibration）

        检测 AI 评估是否存在系统性偏差：
        - 分数分布是否过于集中（缺乏区分度）
        - 各维度间相关性是否异常
        - 推荐等级分布是否合理
        """
        if len(assessments) < 2:
            return {"status": "insufficient_data", "message": "候选人数量不足，无法进行偏差分析"}

        # 分数分布分析
        all_scores = []
        for a in assessments:
            for score in a.get("dimensions", {}).values():
                if isinstance(score, (int, float)):
                    all_scores.append(score)

        if not all_scores:
            return {"status": "no_scores"}

        avg_score = sum(all_scores) / len(all_scores)
        min_score = min(all_scores)
        max_score = max(all_scores)
        score_range = max_score - min_score

        # 推荐等级分布
        rec_counts = {}
        for a in assessments:
            rec = a.get("recommendation", "待定")
            rec_counts[rec] = rec_counts.get(rec, 0) + 1

        # 偏差检测结果
        warnings = []
        if score_range < 20:
            warnings.append(
                f"评分区分度不足：所有维度分数范围为 {min_score}-{max_score}（差距仅{score_range}分），建议增加区分度"
            )
        if avg_score > 80:
            warnings.append(f"评分偏高：平均分 {avg_score:.0f}，可能存在宽松偏差")
        if avg_score < 40:
            warnings.append(f"评分偏低：平均分 {avg_score:.0f}，可能存在严苛偏差")
        if len(rec_counts) <= 1:
            warnings.append("推荐等级过于集中：所有候选人获得相同推荐等级")

        # 维度间相关性检测（简化版：如果所有维度分数高度一致，可能缺乏独立思考）
        dim_correlation_warnings = []
        for a in assessments:
            dims = list(a.get("dimensions", {}).values())
            if len(dims) >= 3:
                dim_avg = sum(dims) / len(dims)
                deviations = [abs(d - dim_avg) for d in dims if isinstance(d, (int, float))]
                if deviations and max(deviations) < 10:
                    dim_correlation_warnings.append(
                        f"{a.get('candidate_name', '?')}：所有维度分数过于接近（最大偏差仅{max(deviations):.0f}分）"
                    )

        return {
            "status": "completed",
            "total_candidates": len(assessments),
            "score_distribution": {
                "average": round(avg_score, 1),
                "min": min_score,
                "max": max_score,
                "range": score_range,
            },
            "recommendation_distribution": rec_counts,
            "warnings": warnings,
            "dimension_correlation_warnings": dim_correlation_warnings[:5],
            "calibration_suggestion": "建议定期对比 AI 评分与 HR 最终决策的偏差，持续校准评分标准"
            if warnings
            else "当前评估分布合理",
        }

    async def _call_basic(
        self,
        role: str,
        cand: dict,
        questions_text: str,
        content: str,
        ontology_context: str = "",
        jd: dict = None,
        interview: dict = None,
    ) -> dict:
        """第一步：N维度评估 + JD Competency 提取（维度从 Interview Agent 的 evaluation_form 动态读取）"""

        ontology_section = f"\n{ontology_context}" if ontology_context else ""

        # JD Competency 提取
        jd_requirements = []
        if jd and isinstance(jd, dict):
            jd_requirements = jd.get("requirements", [])[:5]
        jd_req_text = "\n".join([f"- {r}" for r in jd_requirements]) if jd_requirements else ""
        jd_section = f"\n\n【JD任职要求（从中提取Competency）】\n{jd_req_text}" if jd_req_text else ""

        # 从 Interview Agent 输出的 evaluation_form 动态生成评估维度
        eval_form = (interview or {}).get("evaluation_form", [])

        if eval_form and len(eval_form) >= 3:
            dim_lines = []
            dim_keys = []
            for d in eval_form:
                name = d["name"]
                weight = d.get("weight", 0.2)
                desc = d.get("desc", "")
                key = name.replace(" ", "_")
                dim_keys.append(key)
                dim_lines.append(f"""{name}({key}) — 权重{int(weight * 100)}%：
- {desc}
- 90+: 该维度表现卓越，有具体案例和数据支撑
- 70-89: 表现良好，基本满足岗位要求
- 50-69: 表现一般，有明显短板
- 30-49: 表现较差
- 0-29: 无法评估或完全不匹配""")

            dim_section = "\n\n".join(dim_lines)
            dims_template = ",\n    ".join([f'"{k}": {{"score": 分数, "evidence": "具体证据"}}' for k in dim_keys])
            dim_context = f"\n\n评估维度（0-100分，基于岗位定制评估表，必须有区分度和证据引用）：\n\n{dim_section}"
        else:
            dim_keys = ["content_quality", "delivery", "behavioral_evidence", "role_competency", "growth_potential"]
            dim_context = """
评估维度（0-100分，对标 HireVue 评估体系，必须有区分度和证据引用）：

内容质量(content_quality) — 对标 HireVue Language 维度：
- 候选人回答的用词精准度、技术关键词覆盖、回答深度
- 90+: 回答包含具体数据和案例，技术概念解释精准有深度
- 70-89: 回答准确但缺乏深度，缺少数据支撑
- 50-69: 泛泛而谈，技术概念有偏差
- 30-49: 答非所问，概念错误
- 0-29: 无法给出有效回答

表达与逻辑(delivery) — 对标 HireVue Speech + Structure 维度：
- 回答的条理性、逻辑连贯性、数据佐证能力
- 90+: 条理清晰，重点突出，善用数据和类比
- 70-89: 逻辑通顺，偶有跳跃但整体可理解
- 50-69: 表达散乱，需要追问才能理清思路
- 30-49: 前后矛盾或明显逻辑错误
- 0-29: 无法理解其表达

行为证据(behavioral_evidence) — 对标 STAR 完整性：
- 回答中 Situation/Task/Action/Result 四要素的完整度
- 90+: STAR 四要素完整，有量化结果
- 70-89: 有情境和行动描述，但缺少量化结果
- 50-69: 只说了做了什么，缺少背景和结果
- 30-49: 描述模糊，无法判断真实性
- 0-29: 无有效行为证据

岗位胜任力(role_competency) — 基于 JD 要求评估专业能力：
- 90+: 专业能力完全覆盖 JD 要求，有超出预期的表现
- 70-89: 核心能力匹配 JD，个别要求略弱
- 50-69: 部分能力匹配，有明显短板
- 30-49: 能力偏差较大
- 0-29: 完全不匹配

成长潜力(growth_potential) — 学习意愿、适应性、自我驱动：
- 90+: 主动分享学习路径，对新技术有热情，有清晰的成长规划
- 70-89: 有学习意识但缺乏主动性
- 50-69: 被动学习，缺乏深度
- 30-49: 无成长意识
- 0-29: 抵触学习新事物"""
            dims_template = """"content_quality": {"score": 分数, "evidence": "引用面试中的具体表现"},
    "delivery": {"score": 分数, "evidence": "具体证据"},
    "behavioral_evidence": {"score": 分数, "evidence": "STAR完整度"},
    "role_competency": {"score": 分数, "evidence": "与JD匹配度"},
    "growth_potential": {"score": 分数, "evidence": "具体证据"}"""

        system = f"""你是一个资深面试官，擅长通过面试记录评估候选人。
{dim_context}
{ontology_section}

关键原则：
1. 评分要有区分度 — 不同维度分数要有差异，好的给90+，差的给40以下
2. 亮点和担忧要具体 — 必须引用面试记录中的原文或具体表现
3. 推荐要明确 — 强烈推荐/推荐/待定/不推荐
4. 每个维度的证据必须引用面试记录中的具体表现
5. JD Competency：从JD任职要求中提取3-5个核心能力，每个能力独立评分并给出行为锚定描述

输出JSON格式。"""

        prompt = f"""岗位：{role}
候选人：{cand["name"]}，{cand["years_experience"]}年经验，{cand["current_company"]}，现薪{cand["current_salary"]}
技能：{", ".join(cand["skills"])}
{jd_section}

面试题：
{questions_text}

面试记录：
{content[:5000]}

输出JSON：
{{
  "dimensions": {{
    {dims_template}
  }},
  "jd_competencies": [
    {{
      "name": "从JD提取的能力名称",
      "score": 分数0-100,
      "behavioral_anchor": "该候选人在此能力上的具体行为表现",
      "jd_requirement": "对应的JD原文要求"
    }}
  ],
  "highlights": ["具体亮点", "亮点2"],
  "concerns": ["具体担忧"],
  "overall_impression": "80字总体印象（要有画面感，让HR能快速判断）",
  "recommendation": "强烈推荐/推荐/待定/不推荐",
  "salary_negotiation_tip": "薪资建议30字",
  "communication_style": "沟通风格15字",
  "interview_duration_estimate": "约X分钟"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="plus", temperature=0.3)
        if isinstance(result, dict) and "dimensions" in result:
            dims_raw = result["dimensions"]
            dims_flat = {}
            dims_evidence = {}
            for dim_key, dim_val in dims_raw.items():
                if isinstance(dim_val, dict):
                    dims_flat[dim_key] = dim_val.get("score", 0)
                    dims_evidence[dim_key] = dim_val.get("evidence", "")
                else:
                    dims_flat[dim_key] = dim_val
                    dims_evidence[dim_key] = ""
            result["dimensions"] = dims_flat
            result["dimension_evidence"] = dims_evidence
            return result
        return {}

    async def _call_deep(self, role: str, cand: dict, questions_text: str, content: str) -> dict:
        """第二步：面试切片 + 逐题评估 + 关键时刻 + STAR 结构化提取"""
        system = """你是一个面试分析专家，擅长从面试记录中提取关键信息。

分析要求：
1. 面试切片(segments)：将面试过程按主题切分为3-5个片段，每个片段要有标题、摘要、评级、详细分析
2. 关键时刻(key_moments)：标记面试中的亮点时刻和风险时刻，至少2个
3. 逐题分析(question_analysis)：对每道面试题的回答质量打分并点评
4. STAR提取(star_analysis)：对候选人提到的项目经验，提取STAR四要素

评级标准：
- 优秀：回答超出预期，有独到见解或深度思考
- 良好：回答准确完整，达到岗位要求
- 一般：回答基本正确但缺乏深度或有遗漏
- 较差：回答错误、答非所问或无法回答

STAR 提取规则：
- Situation: 候选人描述的背景/情境（如"当时公司正在做XX项目"）
- Task: 面临的任务或挑战（如"需要把首屏性能从3s优化到1.5s"）
- Action: 采取的具体行动（如"我用了虚拟列表+SSR+图片懒加载"）
- Result: 量化结果（如"LCP降低52%，用户留存提升8%"）
- 如果某个要素缺失，标注为"未提及"

输出JSON格式，不要其他文字。"""

        prompt = f"""岗位：{role}，候选人：{cand["name"]}

面试题：
{questions_text}

面试记录：
{content[:5000]}

请分析面试过程，输出JSON：
{{
  "segments": [
    {{"label": "片段标题", "summary": "内容摘要30字", "rating": "优秀/良好/一般/较差", "detail": "表现分析50字（引用具体表现）"}}
  ],
  "key_moments": [
    {{"type": "highlight或risk", "description": "描述30字", "impact": "影响说明20字"}}
  ],
  "question_analysis": [
    {{"question": "题目摘要15字", "score": 分数0-100, "comment": "点评30字"}}
  ],
  "star_analysis": [
    {{
      "topic": "项目/话题名称",
      "situation": "背景情境（或'未提及'）",
      "task": "任务挑战（或'未提及'）",
      "action": "具体行动（或'未提及'）",
      "result": "量化结果（或'未提及'）",
      "completeness": "完整/部分/缺失"
    }}
  ]
}}

要求：segments至少3个片段，key_moments至少2个（至少1个highlight+1个risk），question_analysis覆盖所有面试题，star_analysis提取所有项目经验。"""
        result = await self.call_llm_json(prompt, system, complexity="flash", temperature=0.3)
        if isinstance(result, dict) and ("segments" in result or "question_analysis" in result):
            return result
        return {"segments": [], "key_moments": [], "question_analysis": [], "star_analysis": []}

    async def _analyze_real_video(
        self, pipeline_id: str, video: dict, role: str, cand: dict, questions_text: str
    ) -> str:
        """用 qwen-vl-max 分析真实视频文件（通过 hermes 网关）

        流程：ffmpeg 提取关键帧+音频 → 帧走 image_url 发给 qwen-vl-max → 音频转录合并
        """
        import base64
        import glob
        import subprocess

        stored_filename = video.get("stored_filename", "")
        if not stored_filename:
            return ""

        try:
            video_path_obj, cleanup_source = _materialize_video_source(pipeline_id, video)
        except FileNotFoundError:
            print(f"[Video] File not found: {stored_filename}", flush=True)
            return ""
        video_path = str(video_path_obj)

        if not video_path_obj.exists():
            print(f"[Video] File not found: {video_path}", flush=True)
            return ""

        file_size = video_path_obj.stat().st_size
        print(f"[Video] Analyzing real video: {stored_filename} ({file_size / 1024 / 1024:.1f}MB)", flush=True)

        # 在 to_thread 中执行 ffmpeg 提取（关键帧 + 音频）
        def extract_frames_and_audio():
            temp_dir = tempfile.mkdtemp(prefix="video_analysis_")
            try:
                # 关键帧：每10秒1帧，最多8帧
                frames_dir = os.path.join(temp_dir, "frames")
                os.makedirs(frames_dir, exist_ok=True)
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        video_path,
                        "-vf",
                        "fps=1/10,select='lt(n,8)'",
                        "-vsync",
                        "vfr",
                        os.path.join(frames_dir, "frame_%03d.jpg"),
                    ],
                    capture_output=True,
                    timeout=60,
                )
                frame_files = sorted(glob.glob(os.path.join(frames_dir, "frame_*.jpg")))

                # 音频提取
                audio_path = os.path.join(temp_dir, "audio.wav")
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        video_path,
                        "-vn",
                        "-acodec",
                        "pcm_s16le",
                        "-ar",
                        "16000",
                        "-ac",
                        "1",
                        audio_path,
                    ],
                    capture_output=True,
                    timeout=60,
                )

                # 读取帧图片为 base64
                frame_data = []
                for fp in frame_files[:8]:
                    with open(fp, "rb") as img_f:
                        frame_data.append(base64.b64encode(img_f.read()).decode())

                # 读取音频
                audio_bytes = b""
                if os.path.exists(audio_path) and os.path.getsize(audio_path) > 0:
                    with open(audio_path, "rb") as af:
                        audio_bytes = af.read()

                return frame_data, audio_bytes
            finally:
                import shutil

                shutil.rmtree(temp_dir, ignore_errors=True)

        try:
            frame_data, audio_bytes = await asyncio.to_thread(extract_frames_and_audio)
        finally:
            cleanup_source()
        print(f"[Video] Extracted {len(frame_data)} frames, audio {len(audio_bytes)} bytes", flush=True)

        # 音频转录
        transcript = ""
        if audio_bytes:
            from app.multimodal import transcribe_audio

            transcript = await asyncio.to_thread(transcribe_audio, f"{stored_filename}.wav", audio_bytes)
            if transcript.startswith("["):
                transcript = ""
            print(f"[Video] Transcript: {len(transcript)} chars", flush=True)

        if not frame_data and not transcript:
            print("[Video] No frames or transcript extracted", flush=True)
            return ""

        # 构建多模态消息：关键帧 image_url + 文本 prompt
        from hermes_wrapper.models import LLMRequest

        content_parts = []
        for img_b64 in frame_data:
            content_parts.append(
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"},
                }
            )

        transcript_section = f"\n音频转录内容：\n{transcript}\n" if transcript else ""
        analysis_prompt = f"""你是一位资深技术面试官，正在观看候选人 {cand["name"]} 的面试录像。
以下是从视频中按时间顺序提取的关键帧截图{transcript_section}
岗位：{role}
候选人：{cand["name"]}，{cand.get("years_experience", "?")}年经验，{cand.get("current_company", "")}
技能：{", ".join(cand.get("skills", []))}

面试题：
{questions_text}

请结合画面和音频转录，分析以下内容：
1. 候选人的每道回答要点（逐题记录）
2. 表达能力：语速、语调、逻辑连贯性
3. 技术深度：回答中体现的技术理解程度
4. 行为证据：候选人提到的具体项目、数据、结果（STAR要素）
5. 非语言信息：自信程度、眼神交流、肢体语言

请用结构化文本输出完整分析（2000字以内）。"""

        content_parts.append({"type": "text", "text": analysis_prompt})

        # 通过 hermes 调用 qwen-vl-max
        req = LLMRequest(
            content_parts=content_parts,
            model="qwen-vl-max",
            timeout=300,
            temperature=0.3,
        )
        resp = await self.llm.chat(req, agent="video", operation="video_analysis", pipeline_id=pipeline_id)

        if resp.error:
            print(f"[Video] qwen-vl-max error: {resp.error}", flush=True)
            return ""

        print(f"[Video] qwen-vl-max result: {len(resp.content)} chars, starts: {resp.content[:80]}", flush=True)
        return resp.content
