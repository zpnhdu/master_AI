"""Interview Agent - Personalized interview questions leveraging match analysis"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import time

from app.job_types import JOB_TYPE_LABELS, normalize_job_type
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput
from knowledge import get_knowledge_base
from ontology import get_ontology_engine

logger = logging.getLogger(__name__)

SHARED_QUESTION_PROMPT_VERSION = "jd_shared_v1"
SHARED_QUESTION_MODEL = "qwen-plus"


def _stable_hash(value) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def get_shared_question_knowledge(role: str) -> tuple[str, str]:
    """Retrieve the small RAG context used by shared JD-level question generation."""
    kb_results = get_knowledge_base().search(f"{role} 面试题 面试技巧 评估标准", top_k=2)
    if kb_results:
        kb_results = [item for item in kb_results if item.get("score", 0) > 0.3 or len(kb_results) <= 1]
    compact = [
        {
            "id": item.get("id", ""),
            "title": item.get("title", ""),
            "content": str(item.get("content", ""))[:300],
        }
        for item in (kb_results or [])
    ]
    context = "\n".join(f"- [{item['title']}] {item['content']}" for item in compact)
    return context, _stable_hash(compact)


def build_shared_question_cache_metadata(
    jd: dict,
    role: str,
    pipeline_job_type: str,
    kb_revision: str,
    question_count: int,
    memory_revision: str = "",
) -> dict:
    jd_revision = _stable_hash({"jd": jd, "role": role, "pipeline_job_type": pipeline_job_type})
    cache_key = _stable_hash(
        {
            "jd_revision": jd_revision,
            "kb_revision": kb_revision,
            "memory_revision": memory_revision,
            "question_count": int(question_count),
            "prompt_version": SHARED_QUESTION_PROMPT_VERSION,
        }
    )
    return {
        "cache_key": cache_key,
        "jd_revision": jd_revision,
        "kb_revision": kb_revision,
        "memory_revision": memory_revision,
        "question_count": int(question_count),
        "prompt_version": SHARED_QUESTION_PROMPT_VERSION,
        "model": SHARED_QUESTION_MODEL,
    }


JOB_TYPE_INTERVIEW_FOCUS = {
    "技术岗": "工程实现、系统设计、技术取舍、故障排查与交付质量",
    "产品岗": "用户洞察、需求判断、产品规划、数据决策与跨团队协作",
    "运营岗": "用户增长、活动运营、数据复盘、资源协调与执行落地",
    "销售岗": "客户洞察、商机推进、谈判转化、目标管理与客户经营",
    "供应链岗": "供需计划、采购履约、库存周转、成本质量与风险处置",
    "服务岗": "客户服务、现场应变、流程规范、协作意识与服务质量",
    "管理岗": "战略拆解、经营决策、组织建设、绩效管理与风险控制",
    "职能岗": "专业制度、流程治理、内部协同、合规意识与服务支撑",
    "通用岗": "岗位核心技能、问题解决、沟通协作、学习能力与责任意识",
}

# 岗位族面试锚定模板（对标 Greenhouse Scorecard + Modern Hire Competency）
ROLE_FAMILY_TEMPLATES = {
    "frontend": {
        "must_ask": ["组件设计与复用能力", "性能优化实战经验", "前端工程化体系"],
        "common_pitfalls": ["只考算法不考工程能力", "不问CSS/布局/可访问性基础", "忽略浏览器原理"],
        "eval_focus": "关注代码质量、架构决策、性能数据",
    },
    "backend": {
        "must_ask": ["并发与分布式处理", "数据库设计与优化", "系统设计与故障排查"],
        "common_pitfalls": ["不问线上故障处理经验", "忽略运维和可观测性", "不考容量规划"],
        "eval_focus": "关注系统设计思维、问题定位速度、方案权衡能力",
    },
    "fullstack": {
        "must_ask": ["前后端协作设计", "全链路问题排查", "API设计与版本管理"],
        "common_pitfalls": ["只问一端忽略另一端", "不问部署和CI/CD", "不考端到端思维"],
        "eval_focus": "关注跨层理解深度、独立交付能力",
    },
    "data": {
        "must_ask": ["数据建模与ETL", "指标体系建设", "数据质量治理"],
        "common_pitfalls": ["只问SQL不问数据思维", "忽略数据治理", "不考业务理解"],
        "eval_focus": "关注数据敏感度、业务理解、技术落地能力",
    },
    "product": {
        "must_ask": ["需求优先级与ROI判断", "数据驱动决策", "跨部门协作与冲突处理"],
        "common_pitfalls": ["只问理论不问实操", "忽略商业思维", "不考用户研究能力"],
        "eval_focus": "关注优先级判断力、数据敏感度、用户同理心",
    },
    "design": {
        "must_ask": ["设计系统与规范建设", "用户体验度量", "设计与开发协作"],
        "common_pitfalls": ["只看作品集不问设计决策", "忽略数据验证", "不问可用性测试"],
        "eval_focus": "关注设计思维过程、数据驱动迭代、落地可行性",
    },
    "devops": {
        "must_ask": ["CI/CD流水线设计", "容器化与编排", "监控告警与故障恢复"],
        "common_pitfalls": ["只问工具不问原理", "忽略安全合规", "不考容量规划"],
        "eval_focus": "关注自动化思维、故障处理速度、安全意识",
    },
    "default": {
        "must_ask": ["岗位核心技能实操", "问题解决方法论", "团队协作与沟通"],
        "common_pitfalls": ["只问理论不问实操", "问题太泛无针对性"],
        "eval_focus": "关注专业能力、学习意愿、文化匹配",
    },
    "executive": {
        "must_ask": ["战略规划与落地能力", "0-1业务搭建经验", "团队搭建与管理", "经营数据分析与决策"],
        "common_pitfalls": ["只问管理理论不问实操", "不问行业认知深度", "忽略资源整合能力"],
        "eval_focus": "关注战略视野、行业资源、经营思维、团队领导力",
    },
    "operations": {
        "must_ask": ["平台规则与流量逻辑", "数据驱动决策", "活动策划与ROI", "用户增长与留存"],
        "common_pitfalls": ["只问理论不问数据", "不问实操案例", "忽略平台差异"],
        "eval_focus": "关注数据分析能力、平台理解深度、活动策划创意、执行力",
    },
    "admin_clerical": {
        "must_ask": ["接待礼仪与沟通", "多任务处理与优先级", "文书档案规范", "突发事件应对"],
        "common_pitfalls": ["问太抽象的问题", "不问细节执行力", "忽略形象气质"],
        "eval_focus": "关注服务意识、细心程度、应变能力、沟通态度",
    },
    "fnb_management": {
        "must_ask": ["成本管控与利润分析", "食品安全与卫生标准", "人员培训与排班", "供应链与设备管理"],
        "common_pitfalls": ["只问管理不问实操", "不问食品安全意识", "忽略成本控制能力"],
        "eval_focus": "关注餐饮行业认知、成本意识、团队管理、实操能力",
    },
}

# 蓝领岗位族模板（百人面试专用）
BLUE_COLLAR_TEMPLATES = {
    "shop_staff": {
        "name": "店员/服务员/导购",
        "must_ask": ["顾客投诉处理", "高峰期应对", "团队协作"],
        "common_pitfalls": ["过于抽象", "不问实际场景", "忽略态度"],
        "eval_focus": "关注服务意识、应变能力、沟通态度",
    },
    "barista": {
        "name": "咖啡师/调饮师",
        "must_ask": ["饮品制作标准", "食品安全", "客户体验"],
        "common_pitfalls": ["只问技术不问服务", "忽略卫生意识"],
        "eval_focus": "关注专业技能、服务意识、卫生习惯",
    },
    "store_manager": {
        "name": "店长/主管",
        "must_ask": ["团队管理", "业绩目标", "突发事件处理"],
        "common_pitfalls": ["只问理论不问实操", "忽略管理经验"],
        "eval_focus": "关注管理能力、业务思维、应变能力",
    },
    "delivery": {
        "name": "外卖员/配送员",
        "must_ask": ["路线规划", "客户沟通", "安全驾驶"],
        "common_pitfalls": ["不问安全意识", "忽略客户服务"],
        "eval_focus": "关注执行力、安全意识、服务态度",
    },
    "cashier": {
        "name": "收银员/理货员",
        "must_ask": ["收银操作", "客户服务", "细心程度"],
        "common_pitfalls": ["不问责任心", "忽略诚信"],
        "eval_focus": "关注细心负责、服务态度、执行力",
    },
    "food_retail": {
        "name": "食材导购/仓储员",
        "must_ask": ["食材保鲜知识", "顾客推荐能力", "库存管理"],
        "common_pitfalls": ["只问销售不问食品安全", "忽略冷链知识"],
        "eval_focus": "关注服务意识、食材认知、卫生习惯、沟通能力",
    },
}

# 锅圈 5 大岗位预设笔试题库（每岗 3 道：方案题 + 数据分析题 + 项目/深挖题）
# 用于笔试/面试场景：命中岗位时直接使用预设题（稳定可演示），未命中则走 LLM 动态生成
GUOQUAN_QUESTION_BANK = {
    "小炒事业部总经理": {
        "name": "锅圈小炒事业部总经理",
        "eval_form_name": "小炒事业部总经理",
        "questions": [
            {
                "type": "方案设计",
                "question": "锅圈计划在华南新开小炒事业部，目标 1 年 50 家门店、单店月营收 30 万、盈亏平衡 8 个月。请设计从 0 到 1 的落地方案，包括：选址模型（坪效/租金/客流指标）、出品标准化（炒菜机器人+厨师配比）、加盟/直营模式选择、人员培训体系（需覆盖粤普双语门店）与成本控制（食材成本率目标 30% 以内）。",
                "duration": "20分钟",
                "follow_up": "如果预算砍半，哪些环节优先级最高？如果首店商圈选错，如何止损？",
                "reason": "考察事业部总经理的从 0 到 N 业务搭建与成本经营能力",
                "expected_points": ["选址指标量化", "出品标准化路径", "成本控制措施", "培训体系设计"],
                "difficulty": "高",
                "scoring_rubric": {
                    "excellent": "方案完整量化，覆盖选址/出品/模式/培训/成本五要素，有清晰的里程碑与风险预案",
                    "good": "方案较完整，主要要素有覆盖，量化指标基本合理",
                    "average": "方案有框架但缺量化细节或关键要素",
                    "poor": "方案空泛，缺乏可执行性",
                    "no_answer": "无法给出有效方案",
                },
            },
            {
                "type": "数据分析",
                "question": "某小炒门店月营收 25 万，食材成本率 38%，人力成本率 22%，房租占比 12%，上月利润 2 万。同商圈竞店食材成本率 31%、人力成本率 18%。请分析：①利润偏低的原因；②给出具体的降本方案（目标将利润率从 8% 提升至 15%）；③如何用数据监控落地效果。",
                "duration": "15分钟",
                "follow_up": "如果供应商报价降不下来，替代方案是什么？",
                "reason": "考察经营数据敏感度与成本管控实操能力",
                "expected_points": ["识别食材/人力成本偏高", "给出可量化降本措施", "建立监控指标"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "准确定位成本问题，给出量化降本方案与监控机制",
                    "good": "定位基本准确，方案可行但缺量化",
                    "average": "分析表面，方案缺少关键细节",
                    "poor": "分析偏差或方案不可行",
                    "no_answer": "无法给出有效分析",
                },
            },
            {
                "type": "项目深挖",
                "question": "请用 STAR 法讲述你主导过的一个餐饮连锁 0 到 1（或扩张）项目：背景（Situation，含市场/竞对/资源约束）、任务（Task，含目标数字）、行动（Action，你具体做了什么、团队多少人、你负责哪部分）、结果（Result，含营收/门店数/成本变化数据）。",
                "duration": "15分钟",
                "follow_up": "过程中最大的失败是什么？如果重来会怎么改？",
                "reason": "基于简历项目深挖，验证从 0 到 1 实操真实性与复盘能力",
                "expected_points": ["STAR 四要素完整", "有量化结果", "体现复盘与成长"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "STAR 完整，结果量化，复盘深入",
                    "good": "STAR 基本完整，有数据支撑",
                    "average": "结构不完整或数据模糊",
                    "poor": "叙述混乱或无法验证",
                    "no_answer": "无法给出有效回答",
                },
            },
        ],
    },
    "文旅露营总经理": {
        "name": "锅圈文旅（露营）总经理",
        "eval_form_name": "文旅露营总经理",
        "questions": [
            {
                "type": "方案设计",
                "question": "锅圈计划在华东（杭州/湖州/黄山候选）落地露营业务，目标 2 年 10 个营地、单营地年营收 300 万、整体盈利。请设计落地策略：①选址评估模型（客源/交通/土地性质/政策合规）；②营地业态组合（住宿/餐饮/活动/零售）与坪效测算；③政策申报路径（文旅部规范、土地手续）；④团队架构与 0 到 1 里程碑。",
                "duration": "20分钟",
                "follow_up": "冬季营地淡季如何平衡客流？如果拿不到政府地，替代方案？",
                "reason": "考察文旅露营行业的战略规划、政策敏感度与 0 到 1 落地能力",
                "expected_points": ["选址量化模型", "业态组合与坪效", "政策路径清晰", "里程碑合理"],
                "difficulty": "高",
                "scoring_rubric": {
                    "excellent": "策略完整，选址/业态/政策/团队四要素量化且可执行",
                    "good": "策略较完整，主要要素覆盖",
                    "average": "有框架但缺量化或政策细节",
                    "poor": "策略空泛",
                    "no_answer": "无法给出有效策略",
                },
            },
            {
                "type": "数据分析",
                "question": "某露营营地上季度营收 250 万，其中住宿 100 万、餐饮 60 万、活动 50 万、零售 40 万；客流 2 万人，周末客流占 70%；获客成本 80 元/人，复购率 12%。请分析：①营收结构是否健康；②周末拥挤/工作日闲置如何优化；③如何提升复购率与单客消费。",
                "duration": "15分钟",
                "follow_up": "如果年客流目标提升 50%，营销预算怎么分？",
                "reason": "考察经营数据分析与运营优化能力",
                "expected_points": ["识别结构问题", "工作日激活方案", "复购提升策略"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "分析全面，方案有数据支撑可落地",
                    "good": "分析合理，方案基本可行",
                    "average": "分析表面化",
                    "poor": "分析偏差",
                    "no_answer": "无法给出有效分析",
                },
            },
            {
                "type": "项目深挖",
                "question": "请用 STAR 法讲述你主导过的露营/文旅项目 0 到 1（或盈利突破）经历：背景、任务（含目标数字）、行动（你做了什么、团队规模、你负责哪部分）、结果（含客流/营收/盈利数据），并说明遇到的重大困难与应对。",
                "duration": "15分钟",
                "follow_up": "项目最接近失败的时刻是什么？如何扭转？",
                "reason": "验证 0 到 1 落地的真实性与抗压能力",
                "expected_points": ["STAR 完整", "量化结果", "困难与复盘"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "STAR 完整，结果量化，复盘深刻",
                    "good": "STAR 基本完整",
                    "average": "结构不完整或数据模糊",
                    "poor": "无法验证真实经历",
                    "no_answer": "无法给出有效回答",
                },
            },
        ],
    },
    "行政助理前台": {
        "name": "行政助理（前台）",
        "eval_form_name": "行政助理前台",
        "questions": [
            {
                "type": "方案设计",
                "question": "公司前台接到通知：明天上午 10 点有 30 人规模的重要客户团来访，涉及展厅参观、会议室接待、午餐安排，同时今天下午有 2 个会议冲突需协调。请设计接待与协调方案，包括：接待动线、人员分工、会议协调优先级、应急预案（如客户早到/设备故障）。",
                "duration": "15分钟",
                "follow_up": "如果 10 点时 VIP 客户和 CEO 行程同时冲突，怎么处理？",
                "reason": "考察前台接待统筹、多任务处理与应变能力",
                "expected_points": ["接待动线清晰", "分工明确", "优先级合理", "有应急预案"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "方案完整，动线/分工/优先级/预案四要素齐全且可执行",
                    "good": "方案较完整，主要要素覆盖",
                    "average": "方案有框架但缺细节",
                    "poor": "方案混乱",
                    "no_answer": "无法给出有效方案",
                },
            },
            {
                "type": "情景模拟",
                "question": "一位情绪激动的访客在前台大声投诉（因预约被拒），同时电话在响、CEO 的客人即将到访。请描述你会如何处理这三件事的优先级与具体动作，并说明如何让投诉者满意同时不影响公司形象。",
                "duration": "10分钟",
                "follow_up": "如果投诉者坚持要见领导，你怎么办？",
                "reason": "考察情绪管理、优先级判断与沟通技巧",
                "expected_points": ["优先级判断", "情绪安抚", "话术得体", "维护公司形象"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "处理成熟，优先级合理，话术得体",
                    "good": "处理方向正确",
                    "average": "处理较生硬",
                    "poor": "处理不当",
                    "no_answer": "无法给出有效回应",
                },
            },
            {
                "type": "细节执行",
                "question": "请描述你整理一份会议纪要的过程：参会人 20 人、发言 2 小时、涉及 5 个决策项，如何确保纪要准确、格式规范、当天下发？请举一个你实际做过的行政文书/档案工作的具体例子。",
                "duration": "10分钟",
                "follow_up": "如果会后 3 小时领导就要纪要，你怎么压缩时间？",
                "reason": "考察文书规范与细节执行力",
                "expected_points": ["记录方法", "格式规范", "效率意识"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "方法清晰，有实际案例支撑",
                    "good": "方法合理",
                    "average": "方法模糊",
                    "poor": "无实操经验",
                    "no_answer": "无法给出有效回答",
                },
            },
        ],
    },
    "私域运营总监": {
        "name": "锅圈私域运营总监",
        "eval_form_name": "私域运营总监",
        "questions": [
            {
                "type": "方案设计",
                "question": "锅圈现有 10000+ 门店，私域用户池 50 万，目标 1 年做到 500 万私域用户、私域 GMV 占比从 15% 提升至 35%。请设计私域体系搭建方案：①引流路径（门店扫码/外卖卡券/社群裂变）；②留存运营（企微/社群/小程序矩阵、会员体系与积分）；③转化打法（KOC/达人、直播、秒杀）；④组织与 SOP（总部-门店分工、300 家试点门店节奏）。",
                "duration": "20分钟",
                "follow_up": "如果 500 万目标砍到 200 万，策略怎么变？如果门店执行意愿低怎么办？",
                "reason": "考察私域体系从 0 到 1 搭建与规模化运营能力",
                "expected_points": ["引流路径量化", "留存体系设计", "转化打法", "组织与SOP"],
                "difficulty": "高",
                "scoring_rubric": {
                    "excellent": "方案完整，引流/留存/转化/组织四要素量化且可落地",
                    "good": "方案较完整",
                    "average": "有框架缺细节",
                    "poor": "方案空泛",
                    "no_answer": "无法给出有效方案",
                },
            },
            {
                "type": "数据分析",
                "question": "某品牌私域月 GMV 800 万：企微群 GMV 400 万（群数 2000，活跃率 25%）、小程序 GMV 300 万（月活 20 万，转化率 2%）、视频号 100 万（场均 5 万 GMV，月 20 场）。获客成本：门店扫码 3 元/人、付费投流 15 元/人。请分析：①各渠道健康度；②资源应向哪个渠道倾斜；③如何把活跃率/转化率提升 50%。",
                "duration": "15分钟",
                "follow_up": "如果投流 ROI 低于 1.5 是否继续？",
                "reason": "考察数据分析与 ROI 决策能力",
                "expected_points": ["渠道对比分析", "资源分配建议", "优化动作可量化"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "分析全面，建议有数据支撑",
                    "good": "分析合理",
                    "average": "分析表面",
                    "poor": "分析偏差",
                    "no_answer": "无法给出有效分析",
                },
            },
            {
                "type": "项目深挖",
                "question": "请用 STAR 法讲述你搭建私域用户池/会员体系的项目：背景、任务（含用户量/GMV 目标）、行动（你的策略与执行、团队规模、你负责哪部分）、结果（含用户数/复购率/GMV 占比数据），以及遇到的最大瓶颈与解法。",
                "duration": "15分钟",
                "follow_up": "如果让你重做，哪一步会换一种方式？",
                "reason": "验证私域实操真实性与方法论",
                "expected_points": ["STAR 完整", "量化结果", "瓶颈与解法"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "STAR 完整，数据详实，复盘深入",
                    "good": "STAR 基本完整",
                    "average": "数据模糊",
                    "poor": "无法验证",
                    "no_answer": "无法给出有效回答",
                },
            },
        ],
    },
    "三方运营高级经理": {
        "name": "锅圈三方运营高级经理",
        "eval_form_name": "三方运营高级经理",
        "questions": [
            {
                "type": "方案设计",
                "question": "锅圈 10000+ 门店计划在美团/点评/饿了么/抖音本地生活四平台做三方运营，目标平台 GMV 年增长 60%、占比从 30% 提升至 45%。请设计：①平台分工策略（各平台主攻什么品类/场景）；②门店矩阵运营体系（总部 SOP+门店执行）；③投放与活动策略（预算分配、大促节奏、ROI 目标）；④商家 BD 与平台资源谈判（KA 协议、费率优化）。",
                "duration": "20分钟",
                "follow_up": "如果平台费率上涨 2 个点，怎么应对？",
                "reason": "考察三方平台运营体系搭建与资源整合能力",
                "expected_points": ["平台分工", "门店矩阵", "投放活动", "BD谈判"],
                "difficulty": "高",
                "scoring_rubric": {
                    "excellent": "方案完整，四要素量化且可执行",
                    "good": "方案较完整",
                    "average": "有框架缺细节",
                    "poor": "方案空泛",
                    "no_answer": "无法给出有效方案",
                },
            },
            {
                "type": "数据分析",
                "question": "某品牌平台月 GMV 3000 万：美团 1500 万（费率 6%，客单 45 元）、抖音 900 万（费率 8%，客单 60 元，投放 ROI 2.0）、饿了么 600 万（费率 7%）。平台总退款率 5%，差评率 1.2%。请分析：①各平台效率对比；②预算（月 100 万）应如何分配；③如何降低退款率与差评率。",
                "duration": "15分钟",
                "follow_up": "如果抖音 ROI 降到 1.2，是停投还是调整？",
                "reason": "考察平台数据分析与投放决策能力",
                "expected_points": ["平台效率对比", "预算分配建议", "退款差评优化"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "分析全面，建议量化可执行",
                    "good": "分析合理",
                    "average": "分析表面",
                    "poor": "分析偏差",
                    "no_answer": "无法给出有效分析",
                },
            },
            {
                "type": "项目深挖",
                "question": "请用 STAR 法讲述你操盘过的平台运营/多平台运营项目：背景、任务（含 GMV/ROI 目标）、行动（你的策略、投放/BD/活动具体动作、团队与分工）、结果（含 GMV/ROI/评分数据），以及最难的平台或最失败的一次活动复盘。",
                "duration": "15分钟",
                "follow_up": "如果平台规则突然变化（如流量分配改版），你怎么应对？",
                "reason": "验证平台运营实操真实性与应变能力",
                "expected_points": ["STAR 完整", "量化结果", "复盘深刻"],
                "difficulty": "中",
                "scoring_rubric": {
                    "excellent": "STAR 完整，数据详实，复盘深入",
                    "good": "STAR 基本完整",
                    "average": "数据模糊",
                    "poor": "无法验证",
                    "no_answer": "无法给出有效回答",
                },
            },
        ],
    },
}

# 锅圈 5 大岗位专属评估表（维度+权重+评分锚点）
GUOQUAN_EVAL_FORMS = {
    "小炒事业部总经理": [
        {"name": "经营能力", "weight": 0.25, "desc": "成本管控、利润分析、经营数据驱动"},
        {"name": "从0到1搭建", "weight": 0.25, "desc": "连锁/餐饮业务 0 到 N 落地实操"},
        {"name": "团队领导力", "weight": 0.20, "desc": "团队搭建、人才培养、跨部门协同"},
        {"name": "行业认知", "weight": 0.15, "desc": "餐饮行业趋势、竞对分析、供应链理解"},
        {"name": "文化匹配", "weight": 0.15, "desc": "价值观契合、抗压能力、工作风格"},
    ],
    "文旅露营总经理": [
        {"name": "战略规划", "weight": 0.25, "desc": "文旅行业趋势判断、中长期规划"},
        {"name": "0到1落地", "weight": 0.25, "desc": "营地/文旅项目从0到1盈利实操"},
        {"name": "资源整合", "weight": 0.20, "desc": "政企资源、土地谈判、供应链"},
        {"name": "经营能力", "weight": 0.15, "desc": "营收利润管控、数据分析"},
        {"name": "文化匹配", "weight": 0.15, "desc": "行业热爱、抗压、价值观契合"},
    ],
    "行政助理前台": [
        {"name": "服务意识", "weight": 0.30, "desc": "接待礼仪、主动服务、客户导向"},
        {"name": "形象气质", "weight": 0.20, "desc": "仪表得体、普通话标准、亲和力"},
        {"name": "应变能力", "weight": 0.20, "desc": "突发事件处理、多任务优先级"},
        {"name": "沟通能力", "weight": 0.15, "desc": "表达清晰、倾听理解、跨部门协调"},
        {"name": "细心程度", "weight": 0.15, "desc": "文书准确、档案管理、流程规范"},
    ],
    "私域运营总监": [
        {"name": "私域体系搭建", "weight": 0.25, "desc": "企微/社群/小程序矩阵、用户池规模化"},
        {"name": "数据分析", "weight": 0.25, "desc": "数据敏感度、ROI分析、用户分层"},
        {"name": "用户运营", "weight": 0.20, "desc": "会员体系、复购提升、精细化运营"},
        {"name": "资源整合", "weight": 0.15, "desc": "KOC/达人运营、跨部门协同"},
        {"name": "文化匹配", "weight": 0.15, "desc": "价值观、自驱力、团队风格"},
    ],
    "三方运营高级经理": [
        {"name": "平台运营", "weight": 0.30, "desc": "美团/点评/抖音/饿了么规则与打法"},
        {"name": "数据分析", "weight": 0.25, "desc": "GMV/ROI分析、投放优化"},
        {"name": "商家BD", "weight": 0.15, "desc": "平台资源谈判、KA合作"},
        {"name": "活动策划", "weight": 0.15, "desc": "大促活动、爆品打造"},
        {"name": "文化匹配", "weight": 0.15, "desc": "执行力、价值观、团队协作"},
    ],
}

# 岗位关键词 → 预设题库/评估表映射（命中即用预设题，未命中走 LLM 动态生成）
GUOQUAN_ROLE_KEYWORDS = [
    ("小炒事业部总经理", ["小炒", "炒菜机器人", "中餐厨师"]),
    ("文旅露营总经理", ["文旅", "露营"]),
    ("行政助理前台", ["行政助理", "前台"]),
    ("私域运营总监", ["私域", "社群运营", "用户运营总监"]),
    ("三方运营高级经理", ["三方运营", "平台运营", "o2o"]),
]


def _match_guoquan_preset(role: str) -> dict | None:
    """按岗位名/关键词匹配锅圈预设题库。命中返回题库 dict，未命中返回 None。"""
    if not role:
        return None
    role_lower = role.lower()
    # 1) 岗位名直接包含（如“锅圈小炒事业部总经理”）
    for key in GUOQUAN_QUESTION_BANK:
        if key in role:
            return GUOQUAN_QUESTION_BANK[key]
    # 2) 关键词匹配
    for key, keywords in GUOQUAN_ROLE_KEYWORDS:
        if any(kw in role_lower for kw in keywords):
            return GUOQUAN_QUESTION_BANK[key]
    return None


# 结构化面试评估表模板（参考 tom-hr-skill 的评估表设计）
TECH_EVAL_FORM = [
    {"name": "编码能力", "weight": 0.30, "desc": "代码实现质量、边界处理、性能意识"},
    {"name": "系统设计", "weight": 0.25, "desc": "架构思维、技术选型、扩展性考虑"},
    {"name": "问题解决", "weight": 0.20, "desc": "分析框架、拆解能力、根因定位"},
    {"name": "沟通表达", "weight": 0.15, "desc": "技术解释清晰度、类比使用、逻辑性"},
    {"name": "文化匹配", "weight": 0.10, "desc": "团队协作风格、价值观、自驱力"},
]

NON_TECH_EVAL_FORM = [
    {"name": "专业能力", "weight": 0.30, "desc": "岗位核心技能的实操深度和广度"},
    {"name": "问题解决", "weight": 0.20, "desc": "面对复杂业务场景的分析和决策能力"},
    {"name": "沟通协作", "weight": 0.20, "desc": "跨部门协作、冲突处理、影响力"},
    {"name": "学习能力", "weight": 0.15, "desc": "新知识获取速度、自驱力、知识迁移"},
    {"name": "文化匹配", "weight": 0.15, "desc": "价值观、工作风格、团队融入度"},
]

EXECUTIVE_EVAL_FORM = [
    {"name": "战略思维", "weight": 0.25, "desc": "中长期规划能力、业务全局观、行业趋势判断"},
    {"name": "经营能力", "weight": 0.25, "desc": "营收利润管控、成本优化、数据驱动决策"},
    {"name": "团队领导力", "weight": 0.20, "desc": "团队搭建、人才培养、跨部门协同"},
    {"name": "行业资源", "weight": 0.15, "desc": "行业人脉、政企关系、供应链资源"},
    {"name": "文化匹配", "weight": 0.15, "desc": "价值观契合、品牌认同、工作风格"},
]

ADMIN_EVAL_FORM = [
    {"name": "服务意识", "weight": 0.25, "desc": "接待礼仪、主动服务、客户导向"},
    {"name": "形象气质", "weight": 0.20, "desc": "仪表得体、普通话标准、亲和力"},
    {"name": "沟通能力", "weight": 0.20, "desc": "表达清晰、倾听理解、跨部门协调"},
    {"name": "细心程度", "weight": 0.20, "desc": "文书准确、档案管理、流程规范"},
    {"name": "多任务处理", "weight": 0.15, "desc": "优先级判断、并行处理、应变能力"},
]

OPERATIONS_EVAL_FORM = [
    {"name": "平台运营", "weight": 0.25, "desc": "平台规则理解、流量获取、店铺管理"},
    {"name": "数据分析", "weight": 0.25, "desc": "数据敏感度、ROI分析、竞品分析"},
    {"name": "活动策划", "weight": 0.20, "desc": "创意策划、执行落地、效果复盘"},
    {"name": "资源整合", "weight": 0.15, "desc": "服务商管理、BD资源、商务谈判"},
    {"name": "执行力", "weight": 0.15, "desc": "目标拆解、进度管控、结果导向"},
]


class InterviewAgent(BaseAgent):
    @staticmethod
    def _normalize_generated_questions(questions: list[dict]) -> list[dict]:
        """Normalize generated question difficulty and duration across all paths."""
        difficulty_map = {
            "低": "简单",
            "简": "简单",
            "简单": "简单",
            "中": "中等",
            "中等": "中等",
            "高": "困难",
            "难": "困难",
            "困难": "困难",
        }
        normalized = []
        for question in questions or []:
            if not isinstance(question, dict):
                continue
            item = dict(question)
            item["difficulty"] = difficulty_map.get(str(item.get("difficulty", "中等")), "中等")
            item["duration"] = "3分钟"
            for field in ("competency_ref", "dimension"):
                value = item.get(field)
                if isinstance(value, str):
                    item[field] = re.sub(
                        r"^\s*(?:\u80fd\u529b\u5730\u56fe\u7ef4\u5ea6|\u5c97\u4f4d\u7ef4\u5ea6)\s*[:\uff1a]\s*",
                        "",
                        value,
                    ).strip()
            normalized.append(item)
        return normalized

    def _resolve_pipeline_job_type(self, value: str) -> tuple[str, str]:
        """Use the pipeline setting as the primary job-family constraint."""
        try:
            code = normalize_job_type(value)
        except ValueError:
            code = "general"
        return code, JOB_TYPE_LABELS[code]

    def _detect_role_type(self, role: str) -> str:
        """Detect role type: technical or non-technical"""
        role_lower = role.lower()
        tech_keywords = [
            "工程师",
            "开发",
            "架构",
            "前端",
            "后端",
            "全栈",
            "算法",
            "数据",
            "运维",
            "devops",
            "sre",
            "测试",
            "qa",
            "安全",
            "ios",
            "android",
            "java",
            "python",
            "go",
            "c++",
            "rust",
        ]
        for kw in tech_keywords:
            if kw in role_lower:
                return "technical"
        return "non_technical"

    def _detect_role_family(self, role: str) -> dict:
        """Detect role family and return template"""
        role_lower = role.lower()
        family_map = {
            "frontend": ["前端", "frontend", "web"],
            "backend": ["后端", "backend", "服务端", "java", "go", "python"],
            "fullstack": ["全栈", "fullstack", "full-stack"],
            "data": ["数据", "data", "算法", "ai", "机器学习", "大模型"],
            "product": ["产品", "product", "pm"],
            "design": ["设计", "design", "ux", "ui"],
            "devops": ["运维", "devops", "sre", "基础设施", "infra"],
            "executive": ["总经理", "ceo", "cto", "coo", "事业部", "vp", "负责人", "总裁"],
            "operations": ["运营", "私域", "社群", "用户增长", "三方", "o2o", "外卖", "电商"],
            "admin_clerical": ["行政", "前台", "文秘", "助理", "文员", "秘书"],
            "fnb_management": ["餐饮", "小炒", "厨师", "厨房", "食品", "门店", "火锅"],
        }
        for family, keywords in family_map.items():
            if any(kw in role_lower for kw in keywords):
                return ROLE_FAMILY_TEMPLATES[family]
        return ROLE_FAMILY_TEMPLATES["default"]

    def _get_eval_form(self, role: str, role_family: dict) -> list:
        """根据岗位族选择评估表"""
        role_lower = role.lower()
        family_key = "default"
        family_map = {
            "executive": ["总经理", "ceo", "cto", "coo", "事业部", "vp", "负责人", "总裁"],
            "operations": ["运营", "私域", "社群", "用户增长", "三方", "o2o", "外卖", "电商"],
            "admin_clerical": ["行政", "前台", "文秘", "助理", "文员", "秘书"],
        }
        for key, keywords in family_map.items():
            if any(kw in role_lower for kw in keywords):
                family_key = key
                break

        EVAL_FORM_MAP = {
            "executive": EXECUTIVE_EVAL_FORM,
            "operations": OPERATIONS_EVAL_FORM,
            "admin_clerical": ADMIN_EVAL_FORM,
        }
        return EVAL_FORM_MAP.get(family_key, NON_TECH_EVAL_FORM)

    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        candidates = data.get("candidates", [])
        jd = data.get("jd", {})
        role = data.get("role", "")
        configured_job_type = data.get("pipeline_type", "")
        if configured_job_type:
            pipeline_job_type, pipeline_job_type_label = self._resolve_pipeline_job_type(configured_job_type)
        else:
            detected_job_type = "tech" if self._detect_role_type(role) == "technical" else "general"
            pipeline_job_type, pipeline_job_type_label = self._resolve_pipeline_job_type(detected_job_type)
        pipeline_id = data.get("pipeline_id", input.pipeline_id)
        actor_user_id = str(data.get("actor_user_id") or data.get("owner_user_id") or "")
        if not actor_user_id and pipeline_id:
            try:
                from app.db import get_pipeline

                actor_user_id = str((get_pipeline(pipeline_id) or {}).get("owner_user_id") or "")
            except Exception:
                logger.exception("Failed to resolve interview memory owner", extra={"pipeline_id": pipeline_id})
        memory_context = str(data.get("interview_memory_context") or "")
        if not memory_context and pipeline_id:
            try:
                from hr_harness.memory.core import MemorySystem

                memory_context = MemorySystem(pipeline_id, actor_user_id=actor_user_id).get_interview_context(role)
            except Exception:
                logger.exception("Failed to load interview memory", extra={"pipeline_id": pipeline_id})
        memory_revision = _stable_hash(memory_context) if memory_context else ""
        company_config = data.get("company_config", {})
        company_name = company_config.get("company_name", "") if company_config else ""
        previous_questions = data.get("previous_questions", []) or []
        previous_question_text = "\n".join(
            f"- {q.get('question', q.get('text', ''))[:300]}"
            for q in previous_questions
            if isinstance(q, dict) and q.get("question", q.get("text", ""))
        )
        regeneration_constraint = (
            "\n\n【重新生成约束】\n"
            "这是重新生成，不要复用上一版题目的题面、场景、数字、追问方向或题型组合。"
            "必须换一个新的业务场景和切入角度；下面是上一版题目，仅用于避重：\n"
            f"{previous_question_text}\n"
            if previous_question_text
            else ""
        )

        # 出题数量：1-20，缺省按预设/3 道
        try:
            question_count = int(data.get("question_count") or 3)
        except (TypeError, ValueError):
            question_count = 3
        question_count = max(1, min(20, question_count))

        # KG 上下文注入：面试方法推荐
        kg_context = input.params.get("kg_context", {})
        kg_methods_section = ""
        if kg_context:
            methods = kg_context.get("methods", [])
            interview_methods = [m for m in methods if any(t in m.get("tags", []) for t in ["面试方法", "评估方法"])]
            if interview_methods:
                methods_text = "\n".join(
                    [f"- {m['name']}: {m.get('definition', '')[:60]}" for m in interview_methods[:3]]
                )
                kg_methods_section = f"\n\n【推荐面试方法】\n{methods_text}\n请根据岗位特点选择合适的面试方法设计题目。"

        # 服务业面试题指南
        is_service_role = any(
            kw in role.lower()
            for kw in [
                "火锅",
                "食材",
                "导购",
                "零售",
                "奶茶",
                "茶饮",
                "调饮",
                "咖啡",
                "吧台",
                "服务员",
                "店员",
                "收银",
                "店长",
                "副店",
                "储备",
                "兼职",
                "小时工",
            ]
        )
        service_interview_guide = ""
        if is_service_role:
            service_interview_guide = """
【服务业/零售门店岗位面试题设计指南】
面试题应包含以下类型（根据岗位选择3-5题）：

1. 实操题（必选）：让候选人现场制作一杯饮品或模拟收银接待
   - 评估维度：操作规范、卫生习惯、时间控制、成品质量

2. 情景题（必选）：模拟门店常见场景
   - 示例："顾客说饮品太甜要求重做，但门店正在排队，你怎么处理？"
   - 评估维度：服务态度、应变能力、优先级判断

3. 态度题（必选）：考察出勤意愿和工作态度
   - 示例："你能接受早班7点到店吗？周末和节假日需要排班，你的时间安排是？"
   - 评估维度：出勤意愿、时间灵活度、吃苦耐劳

4. 稳定题（推荐）：考察留存可能性
   - 示例："你上一份工作做了多久？为什么离开？"
   - 评估维度：稳定性、离职原因合理性

5. 管理题（储备干部必选）：考察管理潜力
   - 示例："如果两个店员同时请假，当天排班怎么调整？"
   - 评估维度：排班能力、应急处理、全局观

注意：服务业面试不要问"你的职业规划""你的优缺点"这类白领面试题。"""
            kg_methods_section += service_interview_guide

        if not candidates:
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"interviews": [], "status": "no_candidates"},
                duration_ms=int((time.time() - start) * 1000),
            )

        # 出题门槛与筛查通过线一致（threshold=50）：综合分≥50 即生成面试题，
        # 避免“已通过筛查但没题”导致发起面试时报错
        # Batch questions are JD-based and shared by every shortlisted candidate.
        qualified = candidates

        # JD-level shared question set: one explicit qwen-plus call, no competency-map
        # stage and no candidate/resume fields in the prompt. The persisted metadata is
        # used by app.services to reuse the set when JD/KB/count are unchanged.
        kb_context = str(data.get("shared_kb_context") or "")
        kb_revision = str(data.get("shared_kb_revision") or "")
        if not kb_revision:
            kb_context, kb_revision = get_shared_question_knowledge(role)
        cache_metadata = build_shared_question_cache_metadata(
            jd,
            role,
            pipeline_job_type_label,
            kb_revision,
            question_count,
            memory_revision,
        )
        questions = await self._generate_shared_questions(
            jd=jd,
            role=role,
            pipeline_job_type_label=pipeline_job_type_label,
            kb_context=kb_context,
            question_count=question_count,
            previous_questions=previous_questions,
            memory_context=memory_context,
        )
        if len(questions) < question_count:
            preset = _match_guoquan_preset(role)
            fallback = list((preset or {}).get("questions", []))[:question_count]
            if len(fallback) >= question_count:
                questions = self._normalize_generated_questions(fallback)

        role_type = "technical" if pipeline_job_type == "tech" else "non_technical"
        role_family = self._detect_role_family(role)
        evaluation_form = TECH_EVAL_FORM if role_type == "technical" else self._get_eval_form(role, role_family)
        shared_questions = [dict(question) for question in questions[:question_count]]
        interviews = [
            {
                "candidate_id": candidate.get("id") or candidate.get("candidate_id", ""),
                "candidate_name": candidate.get("name", ""),
                "interview_strategy": f"基于{role} JD 的统一结构化面试",
                "questions": [dict(question) for question in shared_questions],
                "time_allocation": {
                    "total_minutes": 3 * len(shared_questions),
                    "per_question": [3] * len(shared_questions),
                },
                "evaluation_form": evaluation_form,
                "role_type": role_type,
                "source": "jd_shared",
            }
            for candidate in qualified
        ]
        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "interviews": interviews,
                "shared_question_set": {**cache_metadata, "questions": shared_questions},
                "status": "completed",
            },
            duration_ms=int((time.time() - start) * 1000),
        )

    async def _generate_shared_questions(
        self,
        *,
        jd: dict,
        role: str,
        pipeline_job_type_label: str,
        kb_context: str,
        question_count: int,
        previous_questions: list | None = None,
        memory_context: str = "",
    ) -> list[dict]:
        """Generate one compact JD-level set with a single explicit qwen-plus call."""
        jd_text = json.dumps(jd, ensure_ascii=False, separators=(",", ":"), default=str)
        avoid_text = ""
        if previous_questions:
            previous_text = "\n".join(
                f"- {str(item.get('question') or item.get('text') or '')[:220]}"
                for item in previous_questions
                if isinstance(item, dict)
            )
            if previous_text:
                avoid_text = f"\n不要复用以下旧题的场景或数字：\n{previous_text}"

        system = """你是资深招聘面试题设计专家。只依据 JD、岗位类型和提供的知识库参考出题；
不得引用、推测或要求任何候选人的姓名、简历、公司、年限、技能和个人风险。
只返回 JSON，不要解释。"""
        prompt = f"""岗位：{role}
岗位类型：{pipeline_job_type_label}
JD：{jd_text[:3500]}
知识库参考：
{kb_context[:1200] if kb_context else "无"}

历史面试经验参考：
{memory_context[:1800] if memory_context else "无"}

生成恰好 {question_count} 道所有候选人共用的面试题。每题必须是独立、完整、可直接作答的真实业务场景，
包含必要数字或约束，题面控制在 80-160 字，不使用①②③拆分子问题。
每题只返回这些字段：
- type：自我介绍/项目经验/技术深度/综合面试之一
- question：题目正文
- duration：固定为3分钟
- difficulty：简单/中等/困难之一
- competency_ref：考察维度，10字以内
- expected_points：3个简短评分要点，每个20字以内
{avoid_text}

返回格式：{{"questions":[{{"type":"综合面试","question":"...","duration":"3分钟","difficulty":"中等","competency_ref":"经营分析","expected_points":["要点1","要点2","要点3"]}}]}}"""
        result = await self.call_llm_json(
            prompt,
            system,
            model=SHARED_QUESTION_MODEL,
            complexity="plus",
            max_retries=0,
            timeout=60,
            json_mode=True,
        )
        raw_questions = result.get("questions", []) if isinstance(result, dict) else result
        if not isinstance(raw_questions, list):
            return []
        normalized = self._normalize_generated_questions(raw_questions[:question_count])
        return [item for item in normalized if item.get("question")]

    def _build_technical_prompt(
        self,
        cand: dict,
        jd: dict,
        role: str,
        kb_context: str,
        role_family: dict = None,
        ontology_context: str = "",
        company_name: str = "",
        kg_methods_section: str = "",
        question_count: int = 3,
        pipeline_job_type_label: str = "技术岗",
    ) -> tuple:
        """Build prompt for technical roles, leveraging match analysis"""

        # 利用match阶段的red_flags和interview_focus
        red_flags = cand.get("red_flags", [])
        interview_focus = cand.get("interview_focus", "")

        red_flags_text = (
            "\nAI匹配发现的风险点（面试题要针对性验证）：\n" + "\n".join(f"- {rf}" for rf in red_flags)
            if red_flags
            else ""
        )
        focus_text = f"\nAI建议的面试重点：{interview_focus}" if interview_focus else ""

        # 岗位族锚定
        family_text = ""
        if role_family:
            must_ask = "、".join(role_family.get("must_ask", []))
            pitfalls = "、".join(role_family.get("common_pitfalls", []))
            eval_focus = role_family.get("eval_focus", "")
            family_text = f"""
【岗位族面试锚定】
必须考察的方向：{must_ask}
常见出题陷阱（避免）：{pitfalls}
评估重点：{eval_focus}
"""

        ontology_section = f"\n{ontology_context}" if ontology_context else ""

        co_intro = f"你代表{company_name}进行面试。" if company_name else ""
        system = f"""你是一个在互联网、零售、餐饮、服务等多行业有10年经验的资深面试官，面试过500+候选人。{co_intro}

设计原则：
0. 岗位类型约束：当前流水线明确标记为「{pipeline_job_type_label}」。题目必须优先遵循该岗位类型，不得仅根据岗位名称猜测为其他类型。重点考察：{JOB_TYPE_INTERVIEW_FOCUS[pipeline_job_type_label]}
1. 题目必须贴近实际工作 — 不是抽象算法题，而是候选人日常会遇到的真实场景问题
2. 题目要有梯度 — 基础能力(40分) + 进阶应用(30分) + 边界处理(20分) + 综合决策(10分)
3. 案例分析题考察权衡取舍 — 给具体的业务困境让候选人在约束条件下做决策
4. 项目深挖要追问细节 — 从简历中找到一个具体项目/经历，追问到候选人无法编造的程度
5. 利用AI匹配的风险点 — 针对red_flags设计验证性问题
6. 行业适配 — 技术岗侧重工程能力和系统设计；服务/零售岗侧重运营管理、客户服务、团队协作
7. 题型区分 — 每道题的 type 必须按题目内容真实区分，从【自我介绍 / 项目经验 / 技术深度 / 综合面试】中选择，禁止全部标成同一类型
{family_text}
{kb_context}{ontology_section}{kg_methods_section}

禁止：
- 技术岗不要出纯算法题（如反转链表、二叉树遍历）
- 不要问"你有什么优缺点"这种废话
- 不要出和候选人经验无关的题

输出JSON格式。"""

        jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)
        jd_requirements = jd.get("requirements", []) if isinstance(jd, dict) else []
        jd_req_refs = ", ".join([f"第{i + 1}条：{r[:30]}" for i, r in enumerate(jd_requirements[:5])])

        prompt = f"""岗位：{role}
岗位类型：{pipeline_job_type_label}
JD核心要求：{jd_text}
JD任职要求摘要：{jd_req_refs if jd_req_refs else "无"}

候选人：{cand["name"]}
经验：{cand["years_experience"]}年 · {cand["current_company"]}
技能：{", ".join(cand["skills"])}
简历：{cand["resume_text"]}
AI匹配评价：{cand.get("reason", "")}
{red_flags_text}{focus_text}

请设计 {question_count} 道综合技术面试题（题面为自然语言描述，不拆子项、不列清单），输出JSON：
{{
    "candidate": "{cand["name"]}",
    "interview_strategy": "面试策略概述（30字，说明如何利用候选人优势、验证风险点）",
    "questions": [
        {{
            "type": "自我介绍|项目经验|技术深度|综合面试（按题目内容选其一，每题不同，禁止全部同类型）",
            "question": "用自然语言描述一个真实的技术场景或业务问题（100-200字），嵌入约束条件（QPS/数据量/团队规模/时间限制等）。不要用①②③子项或列表——让候选人自己拆解和设计方案。",
            "duration": "3分钟",
            "follow_up": "追问方向1；追问方向2",
            "reason": "为什么出这道题（要关联候选人的具体经验或风险点，以及JD的哪条要求）",
            "jd_requirement_ref": "对应JD中的第N条任职要求",
            "expected_points": ["架构设计", "工程实现", "trade-off权衡"],
            "difficulty": "困难",
            "scoring_rubric": {{
                "excellent": "方案完整考虑了扩展性/容错/监控，能量化trade-off，代码规范",
                "good": "核心架构合理，考虑了主要约束，实现思路清晰",
                "average": "方案可行但缺少关键考量（如容错、扩展、边界）",
                "poor": "架构有明显缺陷或无法满足约束条件",
                "no_answer": "无法给出有效方案"
            }}
        }}
    ],
    "time_allocation": {{"综合技术面试": "3分钟"}}
}}"""
        prompt += f"\nquestions 数组必须恰好包含 {question_count} 个完整对象，不得只返回示例中的 1 个。"
        prompt += f"\n题型要求：{question_count} 道题的 type 必须覆盖【自我介绍/项目经验/技术深度/综合面试】中的至少 3 种，第 1 题建议为自我介绍类。"
        return system, prompt

    def _build_non_technical_prompt(
        self,
        cand: dict,
        jd: dict,
        role: str,
        kb_context: str,
        role_family: dict = None,
        ontology_context: str = "",
        company_name: str = "",
        kg_methods_section: str = "",
        question_count: int = 3,
        pipeline_job_type_label: str = "通用岗",
    ) -> tuple:
        """Build prompt for non-technical roles"""

        red_flags = cand.get("red_flags", [])
        interview_focus = cand.get("interview_focus", "")

        red_flags_text = "\nAI匹配发现的风险点：\n" + "\n".join(f"- {rf}" for rf in red_flags) if red_flags else ""
        focus_text = f"\nAI建议的面试重点：{interview_focus}" if interview_focus else ""

        # 岗位族锚定
        family_text = ""
        if role_family:
            must_ask = "、".join(role_family.get("must_ask", []))
            pitfalls = "、".join(role_family.get("common_pitfalls", []))
            eval_focus = role_family.get("eval_focus", "")
            family_text = f"""
【岗位族面试锚定】
必须考察的方向：{must_ask}
常见出题陷阱（避免）：{pitfalls}
评估重点：{eval_focus}
"""

        ontology_section = f"\n{ontology_context}" if ontology_context else ""

        co_intro2 = f"你代表{company_name}进行面试。" if company_name else ""
        system = f"""你是一个在互联网、零售、餐饮、服务等多行业有8年经验的资深HR面试官，擅长通过行为面试法（STAR）和情景模拟评估候选人。{co_intro2}

设计原则：
0. 岗位类型约束：当前流水线明确标记为「{pipeline_job_type_label}」。题目必须优先遵循该岗位类型，不得仅根据岗位名称猜测为其他类型。重点考察：{JOB_TYPE_INTERVIEW_FOCUS[pipeline_job_type_label]}
1. 案例分析题要有真实业务场景 — 不是抽象的"你怎么看"，而是给一个与岗位相关的具体业务困境让候选人决策
2. 情景模拟题要有冲突 — 技术服务岗侧重跨部门协作冲突、紧急需求变更；零售服务岗侧重顾客投诉处理、突发事件应对、团队管理
3. 逻辑思维题要有数据 — 给一组业务数据让候选人分析（如门店经营数据、销售趋势），而不是纯抽象推理
4. 项目经验题要用STAR法 — Situation/Task/Action/Result，追问到具体数字和结果
5. 行业适配 — 根据岗位自动选场景：技术岗用产品上线/系统故障场景；服务岗用门店运营/顾客投诉/团队管理场景
6. 题目类型标签：type 使用「自我介绍」「项目经验」「技术深度」「综合面试」四种之一，不要使用「案例分析」「情景模拟」等其他标签
7. 题型区分 — 每道题的 type 必须按题目内容真实区分，从【自我介绍 / 项目经验 / 技术深度 / 综合面试】中选择，禁止全部标成同一类型
{family_text}
{kb_context}{ontology_section}{kg_methods_section}

禁止：
- 不要问"你的优缺点是什么"这种废话
- 不要问"你5年后的职业规划"这种空话
- 不要给与岗位行业无关的场景

输出JSON格式。"""

        jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)
        jd_requirements = jd.get("requirements", []) if isinstance(jd, dict) else []
        jd_req_refs = ", ".join([f"第{i + 1}条：{r[:30]}" for i, r in enumerate(jd_requirements[:5])])

        prompt = f"""岗位：{role}
岗位类型：{pipeline_job_type_label}
JD核心要求：{jd_text}
JD任职要求摘要：{jd_req_refs if jd_req_refs else "无"}

候选人：{cand["name"]}
经验：{cand["years_experience"]}年 · {cand["current_company"]}
技能：{", ".join(cand["skills"])}
简历：{cand["resume_text"]}
AI匹配评价：{cand.get("reason", "")}
{red_flags_text}{focus_text}

请设计 {question_count} 道综合面试题（题面为自然语言描述，不拆子项、不列清单），输出JSON：
{{
    "candidate": "{cand["name"]}",
    "interview_strategy": "面试策略概述（30字）",
    "questions": [
        {{
            "type": "自我介绍|项目经验|技术深度|综合面试（按题目内容选其一，每题不同，禁止全部同类型）",
            "question": "用自然语言描述一个完整的业务场景（100-200字），嵌入具体数字和约束条件。不要用①②③子项或列表——让候选人自己组织答案结构。",
            "duration": "3分钟",
            "follow_up": "追问方向1；追问方向2",
            "reason": "为什么出这道题（关联候选人的经验或风险点，以及JD的哪条要求）",
            "jd_requirement_ref": "对应JD中的第N条任职要求",
            "expected_points": ["维度A的要点", "维度B的要点", "维度C的要点"],
            "difficulty": "困难",
            "scoring_rubric": {{
                "excellent": "分析全面深刻，方案可落地，考虑了多维度约束和风险",
                "good": "分析较全面，方案基本可行，有核心维度覆盖",
                "average": "分析有遗漏，方案缺少关键细节或多维度考量",
                "poor": "分析偏离问题或方案不可行",
                "no_answer": "无法给出有效分析"
            }}
        }}
    ],
    "time_allocation": {{"综合面试": "3分钟"}}
}}"""
        prompt += f"\nquestions 数组必须恰好包含 {question_count} 个完整对象，不得只返回示例中的 1 个。"
        prompt += f"\n题型要求：{question_count} 道题的 type 必须覆盖【自我介绍/项目经验/技术深度/综合面试】中的至少 3 种，第 1 题建议为自我介绍类。"
        return system, prompt

    # ── C方法：JD深度解读 → 能力地图 → 深题生成（仅 5 个锅圈预设岗）──

    def _company_context(self, company_config: dict) -> str:
        """把公司配置转成注入 prompt 的上下文文本。"""
        if not company_config:
            return ""
        name = company_config.get("company_name", "")
        industry = company_config.get("industry", "")
        size = company_config.get("company_size", "")
        desc = company_config.get("company_description", "")
        parts = []
        if name:
            parts.append(f"公司：{name}")
        if industry:
            parts.append(f"行业：{industry}")
        if size:
            parts.append(f"规模：{size}")
        if desc:
            parts.append(f"简介：{desc}")
        return "\n".join(parts) if parts else ""

    async def _build_competency_map(
        self,
        role: str,
        jd: dict,
        company_config: dict,
        preset: dict,
        cand: dict,
        pipeline_job_type_label: str = "通用岗",
    ) -> dict:
        """Step 1: JD 深度解读 → 输出「岗位能力地图」。

        LLM 扮演行业资深顾问（非 HR 面试官），从商业视角拆解 JD：
        - 这个岗位要解决什么核心商业问题
        - 关键经营指标是什么
        - 同体量公司怎么做（行业对标）
        - 候选人简历里有哪些风险点需要验证
        - 面试应该考察哪些维度 + 权重 + 评分锚点
        """
        co = self._company_context(company_config)
        preset_name = preset.get("name", role)

        # 预设题库概要（注入行业 domain knowledge，不让 LLM 凭空猜）
        preset_brief = ""
        for q in preset.get("questions", []):
            preset_brief += f"- [{q.get('type', '')}] {q.get('question', '')[:80]}…\n"

        jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)

        system = f"""你是一位在零售、餐饮、文旅、消费品等行业深耕 15 年的资深商业顾问，
专为 CEO/VP 级别招聘提供岗位画像和面试策略。

你的任务是：阅读 JD 和公司背景，扮演"能看透这个岗位到底要解决什么商业问题"的顾问，
输出一份结构化的「岗位能力地图」。

{co}

岗位：{role}（{preset_name}）
岗位类型：{pipeline_job_type_label}

【岗位类型约束】
流水线已明确指定为「{pipeline_job_type_label}」。能力地图和后续题目必须优先围绕该类型的核心职责、业务场景和评估维度设计，不得仅根据岗位名称推断为其他类型。
重点考察：{JOB_TYPE_INTERVIEW_FOCUS[pipeline_job_type_label]}

【该岗位预设题库概要（作行业参考，不要照抄）】
{preset_brief if preset_brief else "无"}

请严格按以下 JSON 格式输出（所有字段必填，中文）：
{{
    "core_challenge": "这个岗位要解决的核心商业问题（80字以内，必须带具体数字或指标）",
    "key_metrics": ["考核指标1", "考核指标2", "考核指标3"],
    "industry_benchmark": "同体量/同类型公司的行业做法和竞争要点（80字以内）",
    "candidate_risks": ["从简历发现的疑点1", "从简历发现的疑点2"],
    "evaluation_dimensions": [
        {{"name": "维度名", "weight": 0.XX, "anchor": "这个维度具体看什么（30字）"}}
    ],
    "strategy": "面试策略概述（50字）"
}}

要求：
- core_challenge 必须包含具体的数字或指标（如"1年内500万私域用户"而非"做大私域"）
- evaluation_dimensions 必须 5 个维度，权重之和 = 1.0
- candidate_risks 必须基于候选人简历中的真实疑点（经验空窗、行业跨度、项目规模等）
- industry_benchmark 必须是这个行业/岗位的真实竞争逻辑"""

        prompt = f"""JD 正文：
{jd_text}

候选人简历摘要：
姓名：{cand.get("name", "")}
经验：{cand.get("years_experience", "?")}年 · 当前公司：{cand.get("current_company", "")}
技能：{", ".join(cand.get("skills", []))}
简历文本：{(cand.get("resume_text", "") or "")[:600]}

请基于以上信息输出岗位能力地图 JSON。"""

        result = await self.call_llm_json(prompt, system, complexity="flash")
        if isinstance(result, dict) and "core_challenge" in result:
            return result
        # LLM 失败降级：返回基于预设的基础能力地图
        return {
            "core_challenge": f"评估{role}岗位的核心胜任力",
            "key_metrics": ["岗位核心指标一", "岗位核心指标二", "岗位核心指标三"],
            "industry_benchmark": "行业标准做法",
            "candidate_risks": [],
            "evaluation_dimensions": GUOQUAN_EVAL_FORMS.get(preset.get("eval_form_name", ""), NON_TECH_EVAL_FORM),
            "strategy": f"基于【{preset_name}】岗位能力模型的结构化深度面试",
        }

    async def _generate_deep_questions(
        self,
        comp_map: dict,
        preset: dict,
        cand: dict,
        jd: dict,
        role: str,
        company_config: dict,
        question_count: int = 3,
        pipeline_job_type_label: str = "通用岗",
        regeneration_constraint: str = "",
    ) -> list[dict]:
        """Step 2: 基于能力地图 + 预设题库参考 → LLM 生成个性化深题。

        保留预设题的题型结构（方案设计 + 数据分析 + 项目深挖）和行业领域知识，
        但题面、数据、追问、评分锚点全部根据能力地图和候选人简历个性化。
        """
        co = self._company_context(company_config)
        preset_name = preset.get("name", role)

        # 预设题库原文（领域知识底座，让 LLM 了解这个岗位的行业数字和业务逻辑）
        preset_questions_json = json.dumps(preset.get("questions", []), ensure_ascii=False, indent=2)

        # 能力地图 JSON
        comp_json = json.dumps(comp_map, ensure_ascii=False, indent=2)

        jd_text = json.dumps(jd, ensure_ascii=False) if isinstance(jd, dict) else str(jd)

        system = f"""你是一位在零售、餐饮、文旅、消费品等行业有 12 年经验的高管猎头顾问，
面试过 800+ 总监及以上级别候选人。你的面试以"单题破局"著称——
每题都能把一个真实商业困境揉进场景，让候选人在约束条件下展示真实决策水平。

{co}

岗位：{role}（{preset_name}）
岗位类型：{pipeline_job_type_label}

【岗位类型约束】
流水线已明确指定为「{pipeline_job_type_label}」。预设题库仅作行业参考，题目必须优先符合该岗位类型的核心职责、业务场景和评估维度。
重点考察：{JOB_TYPE_INTERVIEW_FOCUS[pipeline_job_type_label]}

【岗位能力地图】（Step 1 输出的，精准描述了这个岗位的商业本质）
{comp_json}

【预设题库参考】（同岗位的行业标准题，含真实的业务数字、行业逻辑和出题框架。
你可以参考其中的数字和业务逻辑，但题面、追问、评分锚点必须根据能力地图和候选人个性化）
{preset_questions_json}

出题原则：
1. 输出 {question_count} 道独立的综合大题——每题用自然语言描述一个完整的商业场景，不要用 ①②③ 或列表拆分子问题
2. 每题面必须嵌入具体的商业数字和约束——让候选人自己拆解、自己给出分析框架
3. {question_count} 道题分别覆盖能力地图中权重最高的 {min(question_count, 5)} 个维度（不足时按权重循环补足），每道题的 reason 明确说明
4. 每题配套 1-2 条追问方向（follow_up）
5. difficulty="困难"
6. 题型区分 — 每道题的 type 必须按题目内容真实区分，从【自我介绍 / 项目经验 / 技术深度 / 综合面试】中选择；{question_count} 道题覆盖至少 3 种，禁止全部标成同一类型

输出严格的 JSON 数组（{question_count} 道题）："""

        prompt = f"""请根据以上能力地图和预设题库参考，为以下候选人设计 {question_count} 道独立综合面试题：

候选人：{cand.get("name", "")}
经验：{cand.get("years_experience", "?")}年 · {cand.get("current_company", "")}
技能：{", ".join(cand.get("skills", []))}
简历关键词：{(cand.get("resume_text", "") or "")[:400]}

JD 原文：
{jd_text[:1000]}

请输出 {question_count} 道题的 JSON 数组：
[
  {{
    "type": "自我介绍|项目经验|技术深度|综合面试（按题目内容选其一，每题不同，禁止全部同类型）",
    "question": "题面用自然语言描述（100-200字），把一个真实商业场景讲清楚，嵌入具体数字和约束条件。不要用①②③子项或列表——让候选人自己组织答案结构。",
    "duration": "3分钟",
    "follow_up": "追问方向",
    "reason": "为什么出这道题（说明覆盖能力地图的哪个维度 + 针对候选人什么风险点）",
    "expected_points": ["评分要点1", "评分要点2", "评分要点3"],
    "difficulty": "困难",
    "scoring_rubric": {{"excellent": "...", "good": "...", "average": "...", "poor": "...", "no_answer": "..."}},
    "competency_ref": "能力地图维度：XX"
  }},
  ...
]

要求：
- {question_count} 道题分别覆盖能力地图中权重最高的 {min(question_count, 5)} 个维度
- 题面必须是自然语言叙述，不拆子项、不列清单
- 必须引用公司真实数据和行业数字
- 题型要求：{question_count} 道题的 type 必须覆盖【自我介绍/项目经验/技术深度/综合面试】中的至少 3 种"""

        result = await self.call_llm_json(
            prompt + regeneration_constraint,
            system,
            complexity="flash",
            temperature=0.9 if regeneration_constraint else None,
        )
        if isinstance(result, list) and len(result) >= 2:
            return self._normalize_generated_questions(result[:question_count])
        if isinstance(result, dict) and "questions" in result:
            return self._normalize_generated_questions(result["questions"][:question_count])
        if regeneration_constraint:
            logger.warning("Regenerate returned no valid LLM questions; preserving the existing question set")
            return []
        # LLM 降级：回落到预设题库原文（截断到目标数量）
        return self._normalize_generated_questions(list(preset.get("questions", []))[:question_count])
