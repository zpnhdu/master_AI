"""Report Agent - Comprehensive hiring report with data-driven decisions"""

import json
import os
import time
from collections.abc import Callable
from typing import Optional

from app.assessment_flow import COMPARISON_DIMENSIONS
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput
from knowledge import get_knowledge_base


def _hiring_report_model() -> str:
    """Resolve the report-specific model after runtime environment loading."""
    return os.getenv("HIRING_REPORT_MODEL", "qwen3.6-flash").strip() or "qwen3.6-flash"


class ReportAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self._progress_cb: Optional[Callable] = None

    async def _progress(self, msg: str):
        """Send progress update to frontend"""
        if self._progress_cb:
            await self._progress_cb(msg)

    async def run(self, input: ToolInput) -> ToolOutput:
        start = time.time()
        data = dict(input.params)
        for _stage_output in input.context.values():
            if isinstance(_stage_output, dict):
                for k, v in _stage_output.items():
                    data.setdefault(k, v)

        candidates = data.get("candidates", [])
        assessments = data.get("assessments", [])
        assessment_packages = data.get("assessment_packages", [])
        interview_records = data.get("interview_records", [])
        jd = data.get("jd", {})
        role = data.get("role", "")
        company_config = data.get("company_config", {})
        company_name = company_config.get("company_name", "") if company_config else ""

        if not candidates:
            return ToolOutput(
                status=AgentStatus.SUCCESS,
                data={"report": {"error": "无候选人数据"}, "status": "no_data"},
                duration_ms=int((time.time() - start) * 1000),
            )

        # 优先按 ID 匹配，失败时按姓名匹配
        assess_map = {}
        for a in assessments:
            assess_map[a.get("candidate_id", "")] = a
        rec_map = {}
        for r in interview_records:
            rec_map[r.get("candidate_id", "")] = r

        def _find_match(c, map_dict):
            """Find match by candidate ID or name"""
            cid = c.get("id") or c.get("candidate_id") or ""
            if cid in map_dict:
                return map_dict[cid]
            cname = (c.get("name") or "").strip()
            if cname:
                for v in map_dict.values():
                    if (v.get("candidate_name") or "").strip() == cname:
                        return v
            return {}

        package_by_id = {package.get("candidate_id", ""): package for package in assessment_packages}
        package_by_name = {package.get("candidate_name", "").strip(): package for package in assessment_packages}

        def _text_list(value):
            if isinstance(value, list):
                return [str(item) for item in value]
            return [str(value)] if value else []

        # 知识库检索：录用决策参考
        kb = get_knowledge_base()
        kb_results = kb.search(f"{role} 录用决策 薪资谈判 入职培养", top_k=2)
        kb_context = ""
        if kb_results:
            kb_context = "\n【知识库参考】\n" + "\n".join(f"- [{k['title']}] {k['content'][:150]}" for k in kb_results)

        cand_summaries = []

        for c in candidates:
            assess = _find_match(c, assess_map)
            rec = _find_match(c, rec_map)
            package = package_by_id.get(c.get("id") or c.get("candidate_id") or "", {})
            dims = assess.get("dimensions", {})
            evidence = assess.get("dimension_evidence", {})

            # 构建维度评分文本（含证据）— 从评估结果动态读取维度
            dim_lines = []
            dims = assess.get("dimensions", {})
            if dims:
                dim_keys = [(k, k) for k in dims.keys()]
            else:
                dim_keys = [
                    ("content_quality", "内容质量"),
                    ("delivery", "表达逻辑"),
                    ("behavioral_evidence", "行为证据"),
                    ("role_competency", "岗位胜任力"),
                    ("growth_potential", "成长潜力"),
                ]
            for key, label in dim_keys:
                score = dims.get(key, "N/A")
                ev = evidence.get(key, "")
                ev_text = f"（证据：{ev}）" if ev else ""
                dim_lines.append(f"- {label}：{score}%{ev_text}")
            dim_text = "\n".join(dim_lines)
            comparison_text = (
                "、".join(f"{name}{score}分" for name, score in assess.get("comparison_dimensions", {}).items())
                or "暂无完整五维评分"
            )

            # 结构化候选人摘要
            summary = f"""【{c["name"]}】
背景：{c.get("years_experience", 0)}年经验 · {c.get("current_company", "")} · 现薪{c.get("current_salary", "")}
学历：{c.get("education", "未提及")} · {c.get("major", "未提及")}
技能栈：{", ".join(c.get("skills", []))}

AI匹配评分：
- 技术匹配：{c.get("tech_score", 0)}%
- 经验匹配：{c.get("experience_score", 0)}%
- 学历背景：{c.get("education_score", 0)}%
- 专业匹配：{c.get("major_match_score", 0)}%
- 文化匹配：{c.get("culture_score", 0)}%
- 薪资风险：{c.get("salary_risk", 0)}%（100=低风险）
- 综合分：{c.get("overall_score", 0)}%

面试表现（如有）：
{dim_text}

面试答题记录（如有）：
{chr(10).join("Q" + str(i + 1) + ": " + a.get("question", "")[:80] + "..." + chr(92) + "n答: " + a.get("answer", "")[:200] for i, a in enumerate(rec.get("answers", []) if rec.get("answers") else []) if a.get("answer", "").strip())}

统一评估总分：{package.get("overall_score", assess.get("overall_score", "N/A"))}
统一五维评分：{comparison_text}
评分来源：{json.dumps(package.get("score_provenance", assess.get("score_provenance", [])), ensure_ascii=False)}
亮点：{", ".join(_text_list(assess.get("highlights")) or ["无"])}
担忧：{", ".join(_text_list(assess.get("concerns")) or ["无"])}
AI评价：{c.get("reason", "N/A")}
录用建议：{assess.get("recommendation", "N/A")}
薪资谈判提示：{assess.get("salary_negotiation_tip", "N/A")}"""
            cand_summaries.append(summary)

        # KG 评估维度注入
        kg_context = input.params.get("kg_context", {})
        kg_eval_section = ""
        if kg_context:
            methods = kg_context.get("methods", [])
            eval_dimensions = [m["name"] for m in methods if any(t in m.get("tags", []) for t in ["评估方法"])]
            if eval_dimensions:
                kg_eval_section = f"\n\n【推荐评估维度】\n请参考以下评估方法撰写报告：{', '.join(eval_dimensions[:3])}"

        # 薪资未知时的报告提示
        salary_note = ""
        salary_range = jd.get("salary_range", "") if isinstance(jd, dict) else ""
        if not salary_range or any(kw in str(salary_range) for kw in ["市场", "面议", "待定"]):
            salary_note = "\n注意：本岗位薪资为「根据市场情况」，薪资策略请基于行业水平和候选人当前薪资给出建议范围。"

        co_for = f"你代表{company_name}撰写报告。" if company_name else ""
        system = f"""你是一个资深HR总监，服务过互联网、零售、餐饮等多个行业，撰写过200+份录用决策报告。{co_for}

核心原则：
1. 数据驱动 — 每个结论都要有数据支撑
2. 统一评估包优先 — 只能解释已完成评估环节中的证据，不得用简历分补齐缺失评估
3. 明确排序 — 录用排序必须明确，不要模棱两可（如"强烈推荐A，推荐B，C作为备选"）
4. 最终得分(final_score)必须原样使用统一评估包的 overall_score，不得自行重算或改分
5. 薪资策略要具体 — 根据行业和岗位给出合理范围
6. 风险要有应对 — 不要只列风险，要给应对方案
{salary_note}

{kb_context}{kg_eval_section}

禁止：
- 不要给所有人都推荐（要有区分度）
- 不要编造数据
- 不得为缺失数据编造分数、薪资或经历

输出JSON格式。"""

        prompt = f"""岗位：{role}
JD薪资范围：{jd.get("salary_range", "未知") if isinstance(jd, dict) else "未知"}

候选人完整评估数据：
{chr(10).join(cand_summaries)}

请撰写录用决策报告：
{{
    "executive_summary": "100字执行摘要（要有数据，如：本次招聘共评估5人，综合分最高89%，推荐录用A和B）",
    "ranking": [
        {{
            "rank": 1,
            "candidate_id": "候选人ID",
            "name": "姓名",
            "final_score": "统一评估包中的overall_score，必须原样输出",
            "recommendation": "强烈推荐录用/推荐录用/建议复试/不推荐",
            "ai_evaluation": "该候选人的综合AI评价（100字，必须结合评分、优势和风险进行判断）",
            "hiring_advice": "针对该候选人的录用建议（60字，说明建议动作和理由）",
            "key_strengths": ["具体优势1（要有数据，如：技术匹配92%，面试表现优秀）", "优势2"],
            "risks": ["具体风险及应对（如：担心稳定性→建议设置6个月试用期考核）"],
            "salary_strategy": {{
                "current": "当前薪资",
                "suggested": "建议offer（如：45K·16薪）",
                "max_budget": "上限（如：50K·16薪）",
                "negotiation_tip": "具体策略（如：候选人当前薪资偏低，可尝试平薪或小幅涨幅，强调成长空间）"
            }},
            "onboarding_plan": "入职培养建议（50字，要可执行，如：前3个月安排张三导师，每周1次1v1，重点培养XX能力）"
        }}
    ],
    "team_fit_analysis": "团队匹配度分析（100字，要具体，如：A的技术栈与团队现有XX项目高度匹配，可快速上手）",
    "market_insights": "市场洞察（如：该岗位市场供需比1:3，建议加快决策避免候选人流失）",
    "next_steps": [
        {{"action": "具体行动（如：本周内发出offer）", "owner": "负责人", "deadline_days": 数字, "priority": "high/medium/low"}}
    ],
    "risk_assessment": "整体风险评估和备选方案（如：若A拒绝offer，B可作为备选，但需重新评估XX能力）"
}}"""

        await self._progress(f"正在综合分析 {len(candidates)} 位候选人数据，生成录用决策报告...")

        def _validate_report(result):
            """Report 输出校验：ranking 非空且每人有 salary_strategy"""
            if not isinstance(result, dict):
                return False
            ranking = result.get("ranking", [])
            if not isinstance(ranking, list) or len(ranking) == 0:
                return False
            for r in ranking:
                if not isinstance(r, dict):
                    return False
                if "salary_strategy" not in r:
                    return False
            return True

        try:
            result = await self.call_llm_json(
                prompt,
                system,
                complexity="plus",
                model=_hiring_report_model(),
                validator=_validate_report,
                max_retries=1,
            )
        except Exception:
            result = None
        if not isinstance(result, dict) or not result:
            result = {"executive_summary": "AI 报告解读暂不可用，以下排名来自已完成的统一评估结果。"}
        ranking = result.get("ranking", [])
        normalized_ranking = []
        included_ids = set()
        assessment_by_id = {item.get("candidate_id", ""): item for item in assessments}
        for item in ranking:
            if not isinstance(item, dict):
                continue
            package = package_by_id.get(item.get("candidate_id", "")) or package_by_name.get(
                str(item.get("name", "")).strip()
            )
            if not package:
                continue
            candidate_id = package["candidate_id"]
            assessment = assessment_by_id.get(candidate_id, {})
            item["candidate_id"] = candidate_id
            item["name"] = package.get("candidate_name", item.get("name", ""))
            item["final_score"] = package["overall_score"]
            item["recommendation"] = assessment.get("recommendation", item.get("recommendation", ""))
            item.setdefault(
                "ai_evaluation",
                "；".join(_text_list(assessment.get("highlights"))) or "暂无补充综合评价",
            )
            item.setdefault(
                "hiring_advice",
                assessment.get("recommendation", "建议 HR 结合岗位优先级复核后推进"),
            )
            item["score_provenance"] = package.get("score_provenance", [])
            normalized_ranking.append(item)
            included_ids.add(candidate_id)

        for package in assessment_packages:
            candidate_id = package["candidate_id"]
            if candidate_id in included_ids:
                continue
            assessment = assessment_by_id.get(candidate_id, {})
            normalized_ranking.append(
                {
                    "candidate_id": candidate_id,
                    "name": package.get("candidate_name", ""),
                    "final_score": package["overall_score"],
                    "recommendation": assessment.get("recommendation", "待HR决策"),
                    "ai_evaluation": "；".join(_text_list(assessment.get("highlights")))
                    or "AI 报告解读暂不可用，请结合已完成评估证据复核。",
                    "hiring_advice": assessment.get("recommendation", "建议 HR 复核后决策"),
                    "key_strengths": _text_list(assessment.get("highlights")),
                    "risks": _text_list(assessment.get("concerns")),
                    "salary_strategy": {
                        "current": "待确认",
                        "suggested": "待HR确认",
                        "max_budget": "待HR确认",
                        "negotiation_tip": "根据公司薪酬带宽与候选人期望协商",
                    },
                    "onboarding_plan": "待HR制定",
                    "score_provenance": package.get("score_provenance", []),
                }
            )
        normalized_ranking.sort(key=lambda item: item["final_score"], reverse=True)
        for index, item in enumerate(normalized_ranking, 1):
            item["rank"] = index
        result["ranking"] = normalized_ranking
        result["comparison_matrix"] = {
            "dimensions": list(COMPARISON_DIMENSIONS),
            "candidates": [
                {
                    "candidate_id": item["candidate_id"],
                    "name": item.get("name", ""),
                    "scores": [
                        assessment_by_id.get(item["candidate_id"], {}).get("comparison_dimensions", {}).get(dimension)
                        for dimension in COMPARISON_DIMENSIONS
                    ],
                }
                for item in normalized_ranking
            ],
            "source": "deterministic_assessment",
        }
        await self._progress("录用决策报告生成完成")

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={
                "report": result if isinstance(result, dict) else {"raw": str(result)},
                "candidates": candidates,
                "assessments": assessments,
                "status": "completed",
            },
            duration_ms=int((time.time() - start) * 1000),
        )
