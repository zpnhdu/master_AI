"""Tool Protocol — standardized agent input/output/config types (Dify-pattern)"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class AgentStatus(Enum):
    """Agent execution status — maps to Dify's node execution states"""

    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    NEEDS_HUMAN = "needs_human"


@dataclass
class ToolInput:
    """Standardized agent input.

    context carries a pipeline-level cumulative context — the union of all
    prior stages' ToolOutput.data, keyed by stage_id. Downstream agents
    can read any upstream stage's output from this dict.
    """

    pipeline_id: str
    candidate_id: Optional[str] = None
    params: dict[str, Any] = field(default_factory=dict)
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolOutput:
    """Standardized agent output.

    status indicates the outcome. data carries the payload on SUCCESS.
    error carries the failure reason on FAILED. tokens_used and duration_ms
    enable cost tracking. logs carry per-step progress messages.
    """

    status: AgentStatus
    data: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    tokens_used: int = 0
    duration_ms: int = 0
    logs: list[str] = field(default_factory=list)


@dataclass
class ToolConfig:
    """Per-agent independent configuration. Stored in DB, read before each call.

    agent_id matches the stage_id key in agent_registry (e.g. 'jd_writer').
    agent_name is the short name (小文/小海/etc). display_name is the
    human-readable label shown in the admin panel.
    """

    agent_id: str
    agent_name: str
    display_name: str
    model: str = "qwen3.6-flash"
    complexity: str = "plus"
    temperature: float = 0.7
    timeout: int = 120
    retry_count: int = 2
    enabled: bool = True
    human_approval: bool = False
