"""Supervisor Agent - LLM-powered dynamic pipeline planning (业务编排层)"""

import asyncio
import glob
import json
import os
import uuid
from collections.abc import Callable
from typing import Any

import yaml

from app.audit.audit_trail import audit
from app.audit.logger import get_logger
from app.db import (
    create_pipeline,
    create_stage,
    get_pipeline,
    get_stages,
    save_candidate,
    save_message,
    transaction,
    update_candidate,
    update_pipeline,
    update_stage,
)
from app.infrastructure.timeout_policy import BusinessTimeoutError, TimeoutDeadline, get_agent_timeout
from hermes_wrapper.client import get_client
from hermes_wrapper.models import LLMRequest
from hr_harness.agents.interview_agent import InterviewAgent
from hr_harness.agents.jd_agent import JDAgent
from hr_harness.agents.match_agent import MatchAgent
from hr_harness.agents.poster_agent import PosterAgent
from hr_harness.agents.profile_agent import ProfileAgent
from hr_harness.agents.report_agent import ReportAgent
from hr_harness.agents.video_agent import VideoAgent
from hr_harness.memory import MemorySystem

logger = get_logger("supervisor")


def _jd_only_plan() -> dict[str, Any]:
    """Return the deterministic plan used by the initial JD-only entry point."""
    return {
        "thinking": "先根据岗位信息生成可编辑 JD 初稿",
        "pipeline": [
            {
                "stage_id": "jd_write",
                "stage_name": "JD撰写",
                "description": "撰写岗位JD",
                "depends_on": [],
            }
        ],
        "estimated_time": "30秒",
        "notes": "仅生成JD",
        "_source": "initial_jd",
    }


def _stage_persistence_values(status, output: dict) -> tuple[str, dict]:
    """Translate DAG results to the status/output contract used by API readers."""
    if status.value == "success":
        return "done", output
    return status.value, output


class SupervisorAgent:
    """Orchestrates recruitment pipeline with LLM-powered dynamic planning"""

    def __init__(self):
        from app.environment import load_environment

        load_environment()

        self.llm = get_client()

        self.agent_registry = {
            "jd_write": {
                "agent": JDAgent,
                "name": "JD撰写",
                "desc": "根据岗位需求撰写专业JD",
                "enabled": True,
                "role_id": "xiao_wen",
            },
            "profile_build": {
                "agent": ProfileAgent,
                "name": "职位画像",
                "desc": "基于本体生成22维候选人画像",
                "enabled": True,
                "role_id": "xiao_wen",
            },
            "poster_gen": {
                "agent": PosterAgent,
                "name": "招聘海报",
                "desc": "根据JD生成招聘海报",
                "enabled": True,
                "role_id": "xiao_hai",
            },
            "match": {
                "agent": MatchAgent,
                "name": "AI匹配",
                "desc": "对候选人与JD进行多维度匹配评分",
                "enabled": True,
                "role_id": "xiao_shai",
            },
            "interview_gen": {
                "agent": InterviewAgent,
                "name": "面试题生成",
                "desc": "为入围候选人生成针对性面试题",
                "enabled": True,
                "role_id": "xiao_mian",
            },
            "video_assess": {
                "agent": VideoAgent,
                "name": "视频面试评估",
                "desc": "模拟视频面试并给出评估报告",
                "enabled": False,
                "role_id": "xiao_mian",
            },
            "report": {
                "agent": ReportAgent,
                "name": "录用报告",
                "desc": "生成综合录用决策报告",
                "enabled": True,
                "role_id": "xiao_ping",
            },
        }

        self.memory = None
        self._spec_cache = None

    def _enabled_stages(self) -> set:
        """返回当前启用的阶段 ID 集合"""
        return {sid for sid, cfg in self.agent_registry.items() if cfg.get("enabled", True)}

    def _enabled_registry(self) -> dict:
        """返回当前启用的 agent_registry"""
        return {sid: cfg for sid, cfg in self.agent_registry.items() if cfg.get("enabled", True)}

    def _load_specs(self) -> list[dict]:
        """Load all plan specs from YAML files (cached)"""
        if self._spec_cache is not None:
            return self._spec_cache

        specs_dir = os.path.join(os.path.dirname(__file__), "specs")
        specs = []
        for f in glob.glob(os.path.join(specs_dir, "*.yaml")):
            try:
                with open(f, encoding="utf-8") as fh:
                    spec = yaml.safe_load(fh)
                    role_patterns = spec.get("role_patterns") or spec.get("keywords")
                    pipeline = spec.get("pipeline") or spec.get("stages")
                    if role_patterns and pipeline:
                        spec["role_patterns"] = role_patterns
                        spec["pipeline"] = pipeline
                        spec["_file"] = os.path.basename(f)
                        specs.append(spec)
            except Exception as e:
                logger.error(f"Failed to load {f}: {e}", extra={"source": "Spec"})

        self._spec_cache = specs
        logger.info(f"Loaded {len(specs)} plan specs: {[s['_file'] for s in specs]}", extra={"source": "Spec"})
        return specs

    def _match_spec(self, role: str):
        """Try to match role against spec patterns. Returns spec dict or None."""
        specs = self._load_specs()
        role_lower = role.lower()

        for spec in specs:
            for pattern in spec.get("role_patterns", []):
                if pattern.lower() in role_lower:
                    logger.info(f"Matched '{role}' → {spec['_file']} (pattern: {pattern})", extra={"source": "Spec"})
                    return spec

        logger.info(f"No match for '{role}', will use LLM planning", extra={"source": "Spec"})
        return None

    def _spec_to_plan(self, spec: dict) -> dict[str, Any]:
        """Convert a matched spec to plan format"""
        return {
            "thinking": spec.get("thinking", "标准招聘流程"),
            "pipeline": spec.get("pipeline", []),
            "estimated_time": spec.get("estimated_time", "3-5分钟"),
            "notes": spec.get("notes", ""),
            "_source": "spec",
            "_spec_file": spec.get("_file", ""),
        }

    async def _call_llm_json(self, prompt: str, system: str = "", model: str = "qwen3.6-flash") -> dict:
        """LLM call via hermes_wrapper"""
        import time as _time

        req = LLMRequest(
            prompt=prompt,
            system=system,
            model=model,
            temperature=0.3,
            timeout=60,
        )
        start = _time.time()
        result = await self.llm.chat_json(req)
        latency_ms = int((_time.time() - start) * 1000)

        # 记录token用量
        try:
            from app.audit.token_tracker import record_usage

            record_usage(
                model=model,
                token_usage={
                    "prompt_tokens": max(len(prompt) // 2, 100),
                    "completion_tokens": 500,
                },
                agent="orchestrator",
                operation="chat_json",
                latency_ms=latency_ms,
            )
        except Exception:
            pass

        return result

    async def plan_pipeline(self, role: str, user_hints: str = "") -> dict[str, Any]:
        """Use LLM to dynamically plan the pipeline based on the request, driven by ontology"""

        # 优先尝试规格匹配，不消耗 Token 且可立即完成
        matched_spec = self._match_spec(role)
        if matched_spec:
            plan = self._spec_to_plan(matched_spec)
            enabled_ids = self._enabled_stages()
            plan["pipeline"] = [s for s in plan["pipeline"] if s.get("stage_id") in enabled_ids]
            if plan["pipeline"]:
                return plan

        # 获取记忆上下文
        memory_context = self.memory.build_system_context() if self.memory else ""

        # 获取用于驱动流水线规划的本体规则
        ontology_context = ""
        try:
            from ontology.engine import OntologyEngine

            engine = OntologyEngine()
            tree = engine.get_tree()
            if tree and tree.nodes:
                ontology_lines = []
                for node in tree.nodes:
                    rules = engine.get_rules_for_node(node.id)
                    if rules:
                        rule_summary = "; ".join([f"{r.name}({r.type})" for r in rules[:5]])
                        ontology_lines.append(f"- {node.name}: {rule_summary}")
                if ontology_lines:
                    ontology_context = "\n\n【招聘本体规则（必须遵守）】\n" + "\n".join(ontology_lines)
                    ontology_context += "\n\n本体约束：AI打分必须遵守本体硬性规则，筛选阈值不可自主修改。"
        except Exception as e:
            logger.error(f"Ontology load failed: {e}", extra={"source": "Supervisor"})

        enabled = self._enabled_registry()
        agent_lines = "\n".join(f"- {sid}: {cfg['name']} - {cfg['desc']}" for sid, cfg in enabled.items())

        system = f"""你是AI HR的Pipeline规划大脑。你的职责是根据HR的招聘需求和招聘本体规则，动态规划执行流水线。

你有以下可用的Agent模块（stage_id必须严格使用以下值）：
{agent_lines}

规划原则：
1. 根据需求选择合适的Agent组合，不是每次都需要全部Agent
2. JD生成后流水线即完成，HR会手动上传简历后触发AI匹配
3. 如果HR说"只要JD"，就只规划jd_write
4. 每个阶段要有明确的输入和预期输出
5. 考虑历史经验，优化流程
6. stage_id必须严格使用上面列出的值
7. 本体规则约束所有AI判断，评分权重和筛选阈值来自本体引擎

输出JSON格式：
{{
    "thinking": "你的思考过程（50字以内）",
    "pipeline": [
        {{
            "stage_id": "jd_write",
            "stage_name": "JD撰写",
            "description": "这个阶段要做什么（20字）",
            "depends_on": []
        }}
    ],
    "estimated_time": "预估总时间",
    "notes": "给HR的说明（30字）"
}}"""

        memory_section = f"\n\n【历史经验】\n{memory_context}" if memory_context else ""

        prompt = f"""HR需求：帮我招一个{role}
补充要求：{user_hints or "无"}{memory_section}{ontology_context}

请规划执行流水线："""

        plan = await self._call_llm_json(prompt, system, "qwen3.6-flash")

        # 规范化 stage_id
        enabled_ids = self._enabled_stages()
        name_to_id = {v["name"]: k for k, v in self.agent_registry.items()}

        if plan.get("pipeline"):
            normalized = []
            for stage in plan["pipeline"]:
                sid = stage.get("stage_id", "")
                if sid not in enabled_ids:
                    sname = stage.get("stage_name", "")
                    sid = name_to_id.get(sname, sid)
                if sid in enabled_ids:
                    stage["stage_id"] = sid
                    normalized.append(stage)
            plan["pipeline"] = normalized

        # 校验并执行降级处理
        if not plan.get("pipeline"):
            plan = {
                "thinking": "标准招聘流程",
                "pipeline": [
                    {"stage_id": "jd_write", "stage_name": "JD撰写", "description": "撰写岗位JD", "depends_on": []},
                    {
                        "stage_id": "match",
                        "stage_name": "AI匹配",
                        "description": "多维度匹配评分",
                        "depends_on": ["jd_write"],
                    },
                ],
                "estimated_time": "1-2分钟",
                "notes": "JD生成 + AI匹配",
            }

        # 根据用户提示应用智能简化
        plan = self._auto_simplify_pipeline(role, user_hints, plan)

        return plan

    def _auto_simplify_pipeline(self, role: str, user_hints: str, plan: dict) -> dict:
        """根据用户意图自动精简流程"""
        hints = (user_hints or "").lower()
        enabled_ids = self._enabled_stages()

        # 确保只保留启用的阶段
        plan["pipeline"] = [s for s in plan["pipeline"] if s.get("stage_id") in enabled_ids]

        # 只要JD
        if ("jd" in hints or "描述" in hints or "岗位说明" in hints) and any(
            kw in hints for kw in ["只要", "只写", "只需要", "帮我写"]
        ):
            plan["pipeline"] = [s for s in plan["pipeline"] if s.get("stage_id") == "jd_write"]
            if not plan["pipeline"]:
                plan["pipeline"] = [
                    {"stage_id": "jd_write", "stage_name": "JD撰写", "description": "撰写岗位JD", "depends_on": []}
                ]
            plan["estimated_time"] = "30秒"
            plan["notes"] = "仅生成JD"
            return plan

        return plan

    async def run_pipeline(
        self,
        role: str,
        user_hints: str = "",
        quiz_answers: list = None,
        on_stage_start: Callable = None,
        on_stage_done: Callable = None,
        on_stage_card: Callable = None,
        on_stage_retrying: Callable = None,
        on_stage_progress: Callable = None,
        on_pipeline_done: Callable = None,
        on_error: Callable = None,
        on_plan_ready: Callable = None,
        engine_version: int = 2,
        pipeline_type: str = "tech",
        enabled_agents: list = None,
        extra_fields: dict = None,
        pipeline_id: str = None,
        exclude_stages: set = None,
        skip_planning: bool = False,
    ) -> dict[str, Any]:
        """Run the recruitment pipeline. engine_version=2 uses DAGEngine (default)."""

        if not pipeline_id:
            pipeline_id = f"p_{uuid.uuid4().hex[:8]}"
        # 未提供 enabled_agents 时，根据 agent_registry 计算默认值
        if enabled_agents is None:
            default_enabled = [sid for sid, cfg in self.agent_registry.items() if cfg.get("enabled", True)]
        else:
            default_enabled = enabled_agents
        # 仅在记录不存在时创建，自动运行使用预先创建的记录
        existing = get_pipeline(pipeline_id)
        if not existing:
            create_pipeline(pipeline_id, role, pipeline_type=pipeline_type, enabled_agents=default_enabled)
        # 仅持久化流水线字段。运行时上下文（例如知识图谱和公司配置）
        # 会传递给下方 Agent，不得临时写入数据库列。
        runtime_extra_fields = extra_fields or {}
        persisted_extra_fields = {
            key: value for key, value in runtime_extra_fields.items() if key in {"agents", "screen_template_id"}
        }
        if persisted_extra_fields:
            from app.db import get_db

            conn = get_db()
            for key, value in persisted_extra_fields.items():
                stored_value = json.dumps(value) if isinstance(value, (list, dict)) else str(value)
                conn.execute(f"UPDATE pipelines SET {key}=? WHERE id=?", (stored_value, pipeline_id))
            conn.commit()
        audit(
            "pipeline.started",
            f"开始招聘流水线: {role} ({pipeline_id})",
            entity_type="pipeline",
            entity_id=pipeline_id,
            details={"role": role, "hints": user_hints},
        )

        self.memory = MemorySystem(pipeline_id)

        # 为该流水线创建隔离画像
        from hermes_wrapper.profile import get_profile_manager

        pm = get_profile_manager()
        self.profile = pm.get_or_create(pipeline_id, role, user_hints)

        plan = _jd_only_plan() if skip_planning else await self.plan_pipeline(role, user_hints)

        update_pipeline(
            pipeline_id,
            "running_auto" if exclude_stages else "running",
            {
                "plan": plan,
                "user_hints": user_hints,
            },
        )

        if on_plan_ready:
            await on_plan_ready(plan, pipeline_id)

        thinking = plan.get("thinking", "")
        notes = plan.get("notes", "")
        save_message(
            pipeline_id,
            "assistant",
            f"🧠 AI HR思考：{thinking}\n📋 计划：{notes}",
            card_type="plan_card",
            card_data=plan,
        )

        memory_context = self.memory.build_system_context() if self.memory else ""
        jd_context = self.memory.get_jd_context(role) if self.memory else ""
        match_context = self.memory.get_match_context() if self.memory else ""

        from app.db import get_company_config

        context = {
            "role": role,
            "pipeline_type": pipeline_type,
            "user_hints": user_hints,
            "quiz_answers": quiz_answers or [],
            "memory_context": memory_context,
            "pipeline_id": pipeline_id,
            "profile_id": pipeline_id,  # 画像隔离
            "company_config": get_company_config(),
        }
        # 海报 agent 读取归属 HR 的用户级联系方式与二维码（公司级 HR 配置已移除）
        from app.user_mailbox import resolve_pipeline_hr, resolve_user_qr

        hr_user = resolve_pipeline_hr(get_pipeline(pipeline_id))
        context["hr_contact"] = (hr_user.get("hr_contact") or "").strip() if hr_user else ""
        context["hr_qr_code"] = resolve_user_qr(hr_user) if hr_user else ""
        from app.xiao_wen_context import merge_runtime_context

        context = merge_runtime_context(context, runtime_extra_fields)
        results = {}

        save_message(pipeline_id, "user", f"帮我招一个{role}" + (f"，{user_hints}" if user_hints else ""))

        stages = plan.get("pipeline", [])

        # V2 DAG 引擎路径（默认）
        if engine_version >= 2:
            try:
                stage_names = {
                    stage["stage_id"]: stage.get(
                        "stage_name", self.agent_registry.get(stage["stage_id"], {}).get("name", stage["stage_id"])
                    )
                    for stage in stages
                }

                async def on_stage_update(stage_id, status, output):
                    stage_name = stage_names.get(stage_id, stage_id)
                    output_data = output.data if output else {}
                    if status.value == "running":
                        existing_stage = next(
                            (item for item in get_stages(pipeline_id) if item["stage_id"] == stage_id), None
                        )
                        if existing_stage:
                            update_stage(pipeline_id, stage_id, "running")
                        else:
                            create_stage(pipeline_id, stage_id, stage_name)
                        if on_stage_start:
                            await on_stage_start(stage_id, stage_name)
                    elif status.value == "success":
                        update_stage(pipeline_id, stage_id, "done", output_data)
                        if on_stage_done:
                            await on_stage_done(stage_id, stage_name, output_data)
                    elif status.value == "needs_human":
                        update_stage(pipeline_id, stage_id, "waiting_human", output_data)
                    elif status.value == "failed":
                        error = output.error if output else "Unknown error"
                        update_stage(pipeline_id, stage_id, "failed", {"error": error})
                        if on_error:
                            await on_error(stage_id, stage_name, error)

                callbacks = {
                    "on_stage_progress": on_stage_progress,
                    "on_stage_update": on_stage_update,
                }
                dag_results = await self._run_pipeline_v2(
                    pipeline_id,
                    role,
                    context,
                    stages,
                    callbacks,
                    exclude_stages=exclude_stages,
                )
                results = {}
                for sr in dag_results:
                    results[sr.stage_id] = sr.output.data
                    results[f"{sr.stage_id}_status"] = sr.status.value

                statuses = {sr.status.value for sr in dag_results}
                human_gate_planned = any(
                    stage.get("stage_id") in {"match", "interview_gen", "video_assess", "report"} for stage in stages
                )
                if "failed" in statuses:
                    final_status = "failed"
                elif "needs_human" in statuses or exclude_stages or human_gate_planned:
                    final_status = "waiting_human"
                else:
                    final_status = "completed"
                update_pipeline(pipeline_id, final_status)
                result = {
                    "status": final_status,
                    "pipeline_id": pipeline_id,
                    "stages_completed": len(dag_results),
                    "plan": plan,
                    "results": results,
                }
                if on_pipeline_done:
                    await on_pipeline_done(result)
                return result
            except Exception as e:
                import traceback as _traceback

                logger.error(f"V2 DAG engine failed, falling back to V1: {e}\n{_traceback.format_exc()}")

            # V1 手动循环（降级方案）
        # 并行组定义：组内 stage 若同时出现在 pipeline 中则并行执行
        parallel_groups = [("publish", "crawl")]
        stage_id_set = {s["stage_id"] for s in stages}
        executed_stages = set()

        async def _run_single_stage(stage_def):
            """执行单个 stage 的完整逻辑（含重试、回调、持久化）"""
            sid = stage_def["stage_id"]
            sname = stage_def.get("stage_name", self.agent_registry.get(sid, {}).get("name", sid))

            agent_class = self.agent_registry[sid]["agent"]
            agent = agent_class()

            if on_stage_progress and hasattr(agent, "_progress_cb"):

                async def _stage_progress_cb(msg, _stage_id=sid):
                    await on_stage_progress(_stage_id, msg)

                agent._progress_cb = _stage_progress_cb

            create_stage(pipeline_id, sid, sname)

            if on_stage_start:
                await on_stage_start(sid, sname)

            try:
                stage_ctx = dict(context)
                if sid == "jd_write" and jd_context:
                    stage_ctx["memory_context"] = jd_context
                elif sid == "match" and match_context:
                    stage_ctx["memory_context"] = match_context

                stage_config = stage_def.get("config", {})
                if stage_config:
                    stage_ctx["stage_config"] = stage_config

                output = None
                max_retries = 3
                last_error = None
                deadline = TimeoutDeadline(get_agent_timeout(sid), agent_id=sid)
                stage_ctx["deadline"] = deadline

                for attempt in range(max_retries):
                    try:
                        if attempt > 0 and on_stage_retrying:
                            await on_stage_retrying(sid, sname, attempt + 1, max_retries)

                        output = await asyncio.wait_for(
                            agent.execute(stage_ctx),
                            timeout=deadline.require_remaining(),
                        )

                        if isinstance(output, dict) and output.get("parse_error"):
                            last_error = output.get("error", "LLM返回解析失败")
                            logger.warning(
                                f"{sname} attempt {attempt + 1} parse error, retrying...",
                                extra={"source": "Supervisor"},
                            )
                            continue

                        break

                    except BusinessTimeoutError as e:
                        last_error = str(e)
                        logger.error(f"{sname} timed out: {e}", extra={"source": "Supervisor"})
                        break
                    except asyncio.TimeoutError:
                        last_error = f"执行超时（{deadline.timeout_seconds:g}s），请检查 LLM 服务是否正常"
                        logger.error(f"{sname} timed out", extra={"source": "Supervisor"})
                        break
                    except Exception as e:
                        last_error = str(e)
                        logger.error(f"{sname} attempt {attempt + 1} exception: {e}", extra={"source": "Supervisor"})
                        if attempt < max_retries - 1:
                            await asyncio.sleep(min(2, deadline.require_remaining()))
                            continue

                if output is None or (isinstance(output, dict) and output.get("parse_error")):
                    error_msg = last_error or "未知错误"
                    logger.error(
                        f"{sname} failed after {max_retries} attempts: {error_msg}", extra={"source": "Supervisor"}
                    )
                    audit(
                        "agent.failed",
                        f"{sname} 重试{max_retries}次后失败: {error_msg}",
                        entity_type="stage",
                        entity_id=pipeline_id,
                        details={"stage_id": sid, "error": error_msg},
                    )
                    update_stage(pipeline_id, sid, "failed", {"error": error_msg, "retries": max_retries})

                    if on_error:
                        await on_error(sid, sname, f"重试{max_retries}次后仍失败，已跳过")

                    save_message(
                        pipeline_id, "system", f"⚠️ {sname}执行失败（已重试{max_retries}次），AI HR已跳过此阶段继续执行"
                    )
                    return {"type": "failed"}

                waiting_status = output.get("status", "") if isinstance(output, dict) else ""
                if waiting_status in ("waiting_for_resumes", "waiting_for_videos"):
                    wait_type = "简历" if "resumes" in waiting_status else "面试视频"
                    pipeline_status = waiting_status
                    logger.info(
                        f"{sname} is waiting for user input ({wait_type}), pausing pipeline",
                        extra={"source": "Supervisor"},
                    )
                    update_stage(pipeline_id, sid, "waiting", output)

                    save_message(
                        pipeline_id,
                        "assistant",
                        f"⏸️ 流水线已暂停，等待上传{wait_type}",
                        card_type="waiting_card",
                        card_data={"message": output.get("message", ""), "stage_id": sid},
                    )

                    if on_stage_done:
                        await on_stage_done(sid, sname, output)

                    if on_stage_card:
                        await on_stage_card(
                            sid,
                            {
                                "type": "waiting_card",
                                "data": {"message": output.get("message", ""), "stage_id": sid},
                                "summary": f"等待上传{wait_type}",
                            },
                        )

                    update_pipeline(pipeline_id, pipeline_status)
                    return {
                        "type": "waiting",
                        "stage_id": sid,
                        "wait_type": wait_type,
                        "pipeline_status": pipeline_status,
                    }

                results[sid] = output
                context.update(output)

                with transaction() as txn:
                    update_stage(pipeline_id, sid, "done", output, conn=txn)

                    if sid == "match" and "candidates" in output:
                        for c in output["candidates"]:
                            save_candidate(pipeline_id, c, conn=txn)

                    if sid == "video_assess" and "assessments" in output:
                        for a in output["assessments"]:
                            cid = a.get("candidate_id")
                            if cid:
                                update_candidate(cid, {"video_assessment": a}, conn=txn)

                    card = self._build_stage_card(sid, output, pipeline_id)

                    if card:
                        save_message(
                            pipeline_id,
                            "assistant",
                            card.get("summary", f"{sname}完成"),
                            card_type=card["type"],
                            card_data=card.get("data", {}),
                            conn=txn,
                        )

                if on_stage_done:
                    await on_stage_done(sid, sname, output)

                if card and on_stage_card:
                    await on_stage_card(sid, card)

                return {"type": "done"}

            except Exception as e:
                logger.error(f"{sname} unexpected error: {e}", extra={"source": "Supervisor"})
                update_stage(pipeline_id, sid, "failed", {"error": str(e)})
                if on_error:
                    await on_error(sid, sname, f"意外错误，已跳过: {str(e)[:100]}")
                save_message(pipeline_id, "system", f"⚠️ {sname}意外错误，AI HR已跳过继续执行")
                return {"type": "failed"}

        enabled_ids = self._enabled_stages()

        for stage_def in stages:
            stage_id = stage_def["stage_id"]
            stage_name = stage_def.get("stage_name", self.agent_registry.get(stage_id, {}).get("name", stage_id))

            if stage_id in executed_stages:
                continue

            if stage_id not in enabled_ids:
                logger.info(f"跳过已禁用阶段: {stage_id}", extra={"source": "Supervisor"})
                executed_stages.add(stage_id)
                continue

            if exclude_stages and stage_id in exclude_stages:
                logger.info(f"跳过排除阶段: {stage_id}", extra={"source": "Supervisor"})
                executed_stages.add(stage_id)
                continue

            # match/poster_gen 及后续阶段不在初始流水线中执行，等用户手动触发
            if stage_id in ("match", "poster_gen", "interview_gen", "video_assess", "report"):
                logger.info(f"跳过{stage_id}阶段（等待简历上传后手动触发）", extra={"source": "Supervisor"})
                continue

            if stage_id not in self.agent_registry:
                if on_error:
                    await on_error(stage_id, stage_name, f"未知Agent: {stage_id}")
                continue

            # 检查是否属于并行组
            matched_group = None
            for pg in parallel_groups:
                if stage_id in pg:
                    matched_group = pg
                    break

            if matched_group:
                group_defs = [sd for sd in stages if sd["stage_id"] in matched_group and sd["stage_id"] in stage_id_set]
                for gd in group_defs:
                    executed_stages.add(gd["stage_id"])

                # 只有组内多个 stage 都存在时才真正并行，否则退化为串行
                if len(group_defs) > 1:
                    logger.info(f"并行执行: {[d['stage_id'] for d in group_defs]}", extra={"source": "Supervisor"})
                    tasks = [_run_single_stage(gd) for gd in group_defs]
                    task_results = await asyncio.gather(*tasks, return_exceptions=True)

                    waiting_result = None
                    for gd, tr in zip(group_defs, task_results):
                        if isinstance(tr, Exception):
                            logger.error(f"{gd['stage_id']} parallel error: {tr}", extra={"source": "Supervisor"})
                        elif isinstance(tr, dict) and tr.get("type") == "waiting":
                            waiting_result = tr

                    if waiting_result:
                        result = {
                            "pipeline_id": pipeline_id,
                            "role": role,
                            "status": waiting_result["pipeline_status"],
                            "stages_completed": len(results),
                            "plan": plan,
                            "message": f"请上传{waiting_result['wait_type']}后继续",
                        }
                        if on_pipeline_done:
                            await on_pipeline_done(result)
                        return result

                    continue
                # len == 1 时退化为串行，继续走下面的 _run_single_stage

            agent_class = self.agent_registry[stage_id]["agent"]
            agent = agent_class()

            # 注入进度回调（支持 _progress_cb 的 Agent，绑定当前 stage_id）
            if on_stage_progress and hasattr(agent, "_progress_cb"):
                _sid = stage_id

                async def _stage_progress_cb(msg, _stage_id=_sid):
                    await on_stage_progress(_stage_id, msg)

                agent._progress_cb = _stage_progress_cb

            create_stage(pipeline_id, stage_id, stage_name)

            if on_stage_start:
                await on_stage_start(stage_id, stage_name)

            try:
                if stage_id == "jd_write" and jd_context:
                    context["memory_context"] = jd_context
                elif stage_id == "match" and match_context:
                    context["memory_context"] = match_context

                stage_config = stage_def.get("config", {})
                if stage_config:
                    context["stage_config"] = stage_config

                output = None
                max_retries = 3
                last_error = None
                deadline = TimeoutDeadline(get_agent_timeout(stage_id), agent_id=stage_id)
                stage_context = dict(context)
                stage_context["deadline"] = deadline

                for attempt in range(max_retries):
                    try:
                        if attempt > 0 and on_stage_retrying:
                            await on_stage_retrying(stage_id, stage_name, attempt + 1, max_retries)

                        # 全局超时：单个 stage 最多 120s，防止 LLM 端点 hang 住整个流水线
                        output = await asyncio.wait_for(
                            agent.execute(stage_context),
                            timeout=deadline.require_remaining(),
                        )

                        if isinstance(output, dict) and output.get("parse_error"):
                            last_error = output.get("error", "LLM返回解析失败")
                            logger.warning(
                                f"{stage_name} attempt {attempt + 1} parse error, retrying...",
                                extra={"source": "Supervisor"},
                            )
                            continue

                        break

                    except BusinessTimeoutError as error:
                        last_error = str(error)
                        logger.error(f"{stage_name} timed out", extra={"source": "Supervisor"})
                        break
                    except asyncio.TimeoutError:
                        last_error = f"执行超时（{deadline.timeout_seconds:g}s），请检查 LLM 服务是否正常"
                        logger.error(f"{stage_name} timed out", extra={"source": "Supervisor"})
                        break
                    except Exception as e:
                        last_error = str(e)
                        logger.error(
                            f"{stage_name} attempt {attempt + 1} exception: {e}", extra={"source": "Supervisor"}
                        )
                        if attempt < max_retries - 1:
                            await asyncio.sleep(min(2, deadline.require_remaining()))
                            continue

                if output is None or (isinstance(output, dict) and output.get("parse_error")):
                    error_msg = last_error or "未知错误"
                    logger.error(
                        f"{stage_name} failed after {max_retries} attempts: {error_msg}", extra={"source": "Supervisor"}
                    )
                    audit(
                        "agent.failed",
                        f"{stage_name} 重试{max_retries}次后失败: {error_msg}",
                        entity_type="stage",
                        entity_id=pipeline_id,
                        details={"stage_id": stage_id, "error": error_msg},
                    )
                    update_stage(pipeline_id, stage_id, "failed", {"error": error_msg, "retries": max_retries})

                    if on_error:
                        await on_error(stage_id, stage_name, f"重试{max_retries}次后仍失败，已跳过")

                    save_message(
                        pipeline_id,
                        "system",
                        f"⚠️ {stage_name}执行失败（已重试{max_retries}次），AI HR已跳过此阶段继续执行",
                    )
                    continue

                waiting_status = output.get("status", "") if isinstance(output, dict) else ""
                if waiting_status in ("waiting_for_resumes", "waiting_for_videos"):
                    wait_type = "简历" if "resumes" in waiting_status else "面试视频"
                    pipeline_status = waiting_status
                    logger.info(
                        f"{stage_name} is waiting for user input ({wait_type}), pausing pipeline",
                        extra={"source": "Supervisor"},
                    )
                    update_stage(pipeline_id, stage_id, "waiting", output)

                    save_message(
                        pipeline_id,
                        "assistant",
                        f"⏸️ 流水线已暂停，等待上传{wait_type}",
                        card_type="waiting_card",
                        card_data={"message": output.get("message", ""), "stage_id": stage_id},
                    )

                    if on_stage_done:
                        await on_stage_done(stage_id, stage_name, output)

                    if on_stage_card:
                        await on_stage_card(
                            stage_id,
                            {
                                "type": "waiting_card",
                                "data": {"message": output.get("message", ""), "stage_id": stage_id},
                                "summary": f"等待上传{wait_type}",
                            },
                        )

                    update_pipeline(pipeline_id, pipeline_status)

                    result = {
                        "pipeline_id": pipeline_id,
                        "role": role,
                        "status": pipeline_status,
                        "stages_completed": len(results),
                        "plan": plan,
                        "message": f"请上传{wait_type}后继续",
                    }

                    if on_pipeline_done:
                        await on_pipeline_done(result)

                    return result

                results[stage_id] = output
                context.update(output)

                # 原子写入：在同一事务中保存阶段状态、候选人和消息
                with transaction() as txn:
                    update_stage(pipeline_id, stage_id, "done", output, conn=txn)

                    if stage_id == "match" and "candidates" in output:
                        for c in output["candidates"]:
                            save_candidate(pipeline_id, c, conn=txn)

                    if stage_id == "video_assess" and "assessments" in output:
                        for a in output["assessments"]:
                            cid = a.get("candidate_id")
                            if cid:
                                update_candidate(cid, {"video_assessment": a}, conn=txn)

                    card = self._build_stage_card(stage_id, output, pipeline_id)

                    if card:
                        save_message(
                            pipeline_id,
                            "assistant",
                            card.get("summary", f"{stage_name}完成"),
                            card_type=card["type"],
                            card_data=card.get("data", {}),
                            conn=txn,
                        )

                if on_stage_done:
                    await on_stage_done(stage_id, stage_name, output)

                if card and on_stage_card:
                    await on_stage_card(stage_id, card)

            except Exception as e:
                logger.error(f"{stage_name} unexpected error: {e}", extra={"source": "Supervisor"})
                update_stage(pipeline_id, stage_id, "failed", {"error": str(e)})
                if on_error:
                    await on_error(stage_id, stage_name, f"意外错误，已跳过: {str(e)[:100]}")
                save_message(pipeline_id, "system", f"⚠️ {stage_name}意外错误，AI HR已跳过继续执行")
                continue

        # 检查是否有未执行的阶段需要等待用户输入
        if exclude_stages:
            update_pipeline(pipeline_id, "waiting_human")
            save_message(
                pipeline_id,
                "assistant",
                "自动阶段已完成，流水线正在等待人工筛选与评估。",
                card_type="waiting_card",
                card_data={"status": "waiting_human", "excluded_stages": sorted(exclude_stages)},
            )
            result = {
                "pipeline_id": pipeline_id,
                "role": role,
                "status": "waiting_human",
                "stages_completed": len(results),
                "plan": plan,
            }
            if on_pipeline_done:
                await on_pipeline_done(result)
            return result

        planned_ids = {s["stage_id"] for s in stages}
        match_planned = "match" in planned_ids
        match_done = "match" in results

        if match_planned and not match_done:
            # JD 已完成，但还没有简历进行匹配 → 暂停等待上传
            update_pipeline(pipeline_id, "waiting_for_resumes")

            save_message(
                pipeline_id,
                "assistant",
                "⏸️ JD已生成，请上传候选人简历后开始AI匹配",
                card_type="waiting_card",
                card_data={"message": "JD已完成撰写，下一步：导入简历进行AI匹配"},
            )

            result = {
                "pipeline_id": pipeline_id,
                "role": role,
                "status": "waiting_for_resumes",
                "stages_completed": len(results),
                "plan": plan,
                "message": "请上传简历后开始AI匹配",
            }
            if on_pipeline_done:
                await on_pipeline_done(result)
            return result

        update_pipeline(pipeline_id, "completed")
        audit(
            "pipeline.completed",
            f"招聘流水线完成: {role} ({pipeline_id})",
            entity_type="pipeline",
            entity_id=pipeline_id,
            details={"role": role, "stages": len(stages), "completed": len(results)},
        )

        self._learn_from_pipeline(pipeline_id, results)

        result = {
            "pipeline_id": pipeline_id,
            "role": role,
            "status": "completed",
            "stages": len(stages),
            "plan": plan,
        }

        if on_pipeline_done:
            await on_pipeline_done(result)

        return result

    def _build_stage_card(self, stage_id: str, output: dict, pipeline_id: str) -> dict:
        """Build a card for the frontend based on stage output"""
        if stage_id == "jd_write":
            jd = output.get("jd", {})
            return {
                "type": "jd_card",
                "data": {"jd": jd, "pipeline_id": pipeline_id},
                "summary": f"JD已生成：{jd.get('title', '')} · {jd.get('salary_range', '')}",
            }
        elif stage_id == "profile_build":
            profile = output.get("profile", {})
            dim_count = len(profile.get("dimensions", {}))
            return {
                "type": "profile_card",
                "data": {"profile": profile, "pipeline_id": pipeline_id},
                "summary": f"22维画像已生成：{dim_count}个维度",
            }
        elif stage_id == "poster_gen":
            poster_data = dict(output)
            poster_data["pipeline_id"] = pipeline_id
            return {"type": "poster_card", "data": poster_data, "summary": "招聘海报已生成"}
        elif stage_id == "publish":
            published = output.get("published_count", 0)
            return {"type": "publish_card", "data": output, "summary": f"已发布{published}个渠道"}
        elif stage_id == "crawl":
            count = output.get("resume_count", 0)
            return {"type": "crawl_card", "data": output, "summary": f"获取{count}份简历"}
        elif stage_id == "match":
            candidates = output.get("candidates", [])
            shortlisted = output.get("shortlisted", [])
            return {
                "type": "match_card",
                "data": output,
                "summary": f"{len(candidates)}人评估，{len(shortlisted)}人入围",
            }
        elif stage_id == "interview_gen":
            interviews = output.get("interviews", [])
            return {"type": "interview_card", "data": output, "summary": f"为{len(interviews)}人生成面试题"}
        elif stage_id == "video_assess":
            assessments = output.get("assessments", [])
            return {"type": "assessment_card", "data": output, "summary": f"{len(assessments)}人视频评估完成"}
        elif stage_id == "report":
            return {"type": "report_card", "data": output, "summary": "录用决策报告已生成"}
        return None

    def _learn_from_pipeline(self, pipeline_id: str, results: dict):
        """Learn patterns from completed pipeline + 人才库沉淀 + 数据闭环"""
        if not self.memory:
            return

        if "jd_write" in results:
            jd = results["jd_write"].get("jd", {})
            role = jd.get("title", "")
            if role:
                self.memory.record_jd_feedback(role, "", {"jd_generated": "true"})

        if "match" in results:
            candidates = results["match"].get("candidates", [])
            if candidates:
                avg_score = sum(c.get("overall_score", 0) for c in candidates) / len(candidates)
                self.memory.record_match_feedback(
                    f"pipeline_{pipeline_id}", "completed", f"avg_score:{avg_score:.1f}, count:{len(candidates)}"
                )

        if "report" in results:
            report = results["report"].get("report", {})
            ranking = report.get("ranking", [])
            if ranking:
                top = ranking[0]
                self.memory.record_hiring_decision(
                    top.get("name", ""),
                    top.get("recommendation", ""),
                    top.get("salary_suggestion", ""),
                    f"score:{top.get('final_score', top.get('overall_score', 0))}",
                )

        # === 人才库沉淀（P0-1）：所有候选人自动入库 ===
        try:
            from app.db import add_to_talent_pool, get_candidates

            all_candidates = get_candidates(pipeline_id)
            role = ""
            if "jd_write" in results:
                role = results["jd_write"].get("jd", {}).get("title", "")

            for c in all_candidates:
                outcome = c.get("status", "pooled")
                # 标记 silver medalist：高分但未最终录用
                if c.get("overall_score", 0) >= 70 and outcome not in ("offered", "shortlisted"):
                    outcome = "silver_medalist"

                add_to_talent_pool(
                    {
                        **c,
                        "best_role": role,
                        "source_pipeline": pipeline_id,
                        "outcome": outcome,
                        "tags": [role, c.get("source", ""), outcome] if role else [],
                    }
                )
            logger.info(f"已沉淀 {len(all_candidates)} 位候选人到人才库", extra={"source": "TalentPool"})
        except Exception as e:
            logger.error(f"沉淀失败: {e}", extra={"source": "TalentPool"})

        # === 数据闭环（P0-5）：招聘结果反哺评分权重 ===
        try:
            if "report" in results and "match" in results:
                report = results["report"].get("report", {})
                ranking = report.get("ranking", [])
                match_candidates = results["match"].get("candidates", [])
                if ranking and match_candidates:
                    # 找到最终推荐的候选人，对比初始评分与最终结果
                    recommended_names = {r.get("name", "") for r in ranking if "推荐" in r.get("recommendation", "")}
                    cand_by_name = {c.get("name", ""): c for c in match_candidates}

                    for name in recommended_names:
                        cand = cand_by_name.get(name, {})
                        if cand:
                            score = cand.get("overall_score", 0)
                            self.memory.record_hiring_decision(
                                name,
                                "recommended_hired",
                                cand.get("current_salary", ""),
                                f"initial_score:{score}, outcome:hired",
                            )
                    logger.info(f"数据闭环：{len(recommended_names)} 位推荐候选人已标注", extra={"source": "DataLoop"})
        except Exception as e:
            logger.error(f"闭环失败: {e}", extra={"source": "DataLoop"})

    @property
    def stage_order(self):
        return [
            "jd_write",
            "profile_build",
            "poster_gen",
            "publish",
            "crawl",
            "match",
            "interview_gen",
            "video_assess",
            "report",
        ]

    async def _run_pipeline_v2(
        self, pipeline_id: str, role: str, context: dict, stages: list, callbacks: dict, exclude_stages: set = None
    ) -> list:
        """Execute pipeline using the new DAG engine (V2 architecture).

        Reads agent configs from DB for hot-reload support.
        Falls back to defaults if agent_configs table is empty.
        Respects pipeline-level enabled_agents for per-pipeline agent toggling.
        """
        from app.db import get_agent_config, get_pipeline
        from hr_harness.dag_engine import DAGEngine, StageDefinition
        from hr_harness.tool_protocol import ToolConfig

        engine = DAGEngine(on_stage_update=callbacks.get("on_stage_update"))

        # 读取流水线级 enabled_agents（各流水线独立开关）
        pipeline_data = get_pipeline(pipeline_id)
        pipeline_enabled_agents = None
        if pipeline_data and pipeline_data.get("enabled_agents"):
            configured_ids = set(pipeline_data["enabled_agents"])
            # 界面存储六个角色 ID（xiao_wen、xiao_mian 等），DAG 则执行阶段 ID。
            # 为兼容现有流水线记录，此处同时接受两种形式。
            pipeline_enabled_agents = {
                stage_id
                for stage_id, config in self.agent_registry.items()
                if stage_id in configured_ids or config.get("role_id") in configured_ids
            }

        stage_defs = []
        for stage in stages:
            sid = stage["stage_id"]
            sname = stage.get("stage_name", self.agent_registry.get(sid, {}).get("name", sid))
            agent_cls = self.agent_registry.get(sid, {}).get("agent")
            if not agent_cls:
                continue

            # 优先检查流水线级 enabled_agents
            if pipeline_enabled_agents is not None and sid not in pipeline_enabled_agents:
                logger.info(f"Skipping stage {sid} (disabled by pipeline config)", extra={"source": "DAG"})
                continue

            # 检查调用方指定的排除阶段，例如自动运行会跳过仅限手动执行的阶段
            if exclude_stages and sid in exclude_stages:
                logger.info(f"Skipping stage {sid} (excluded by caller)", extra={"source": "DAG"})
                continue

            # 从数据库读取配置以支持热更新，失败时使用默认值
            db_config = get_agent_config(sid)
            if db_config:
                config = ToolConfig(
                    agent_id=sid,
                    agent_name=db_config.get("agent_name", sname),
                    display_name=db_config.get("display_name", sname),
                    model=db_config.get("model", "qwen3.6-flash"),
                    complexity=db_config.get("complexity", "plus"),
                    temperature=db_config.get("temperature", 0.7),
                    timeout=db_config.get("timeout", 120),
                    retry_count=0 if sid in {"jd_write", "profile_build"} else db_config.get("retry_count", 2),
                    enabled=bool(db_config.get("enabled", 1)),
                    human_approval=bool(db_config.get("human_approval", 0)),
                )
            else:
                config = ToolConfig(
                    agent_id=sid,
                    agent_name=sname,
                    display_name=sname,
                    enabled=self.agent_registry.get(sid, {}).get("enabled", True),
                    retry_count=0 if sid in {"jd_write", "profile_build"} else 2,
                )

            if config.enabled:
                agent = agent_cls()
                if callbacks.get("on_stage_progress") and hasattr(agent, "_progress_cb"):

                    async def _pg(msg, _sid=sid):
                        await callbacks["on_stage_progress"](_sid, msg)

                    agent._progress_cb = _pg
                stage_defs.append(StageDefinition(stage_id=sid, agent=agent, config=config))

        results = await engine.execute(stage_defs, pipeline_id=pipeline_id, initial_params=context)
        return results

    @property
    def stage_names(self):
        return {k: v["name"] for k, v in self.agent_registry.items()}
