"""面试安排自动化 - 时间段生成 + 邀请 + 提醒（参考北森/Moka面试安排）

功能：
1. 为候选人生成可选时间段
2. 生成面试邀请（含面试题摘要、注意事项）
3. 生成面试提醒消息
4. 自动分发面试资料给面试官
"""

from collections.abc import Callable
from datetime import datetime, timedelta
from typing import Optional

from app.db import save_outreach_event
from hr_harness.agents.base import BaseAgent
from hr_harness.tool_protocol import AgentStatus, ToolInput, ToolOutput


class SchedulingAgent(BaseAgent):
    """面试安排Agent"""

    def __init__(self):
        super().__init__()
        self._progress_cb: Optional[Callable] = None

    async def _progress(self, msg: str):
        if self._progress_cb:
            await self._progress_cb(msg)

    async def run(self, input: ToolInput) -> ToolOutput:
        context = dict(input.params)
        for stage_output in input.context.values():
            if isinstance(stage_output, dict):
                context.update(stage_output)
        candidates = context.get("candidates", [])
        interviews = context.get("interviews", [])
        role = context.get("role", "")
        pipeline_id = context.get("pipeline_id", input.pipeline_id)

        if not candidates:
            return ToolOutput(status=AgentStatus.SUCCESS, data={"schedules": [], "status": "no_candidates"})

        interview_map = {i["candidate_id"]: i for i in interviews}
        shortlisted = [c for c in candidates if c.get("overall_score", 0) >= 60]
        if not shortlisted:
            shortlisted = candidates[:3]

        schedules = []
        for cand in shortlisted:
            await self._progress(f"正在为 {cand['name']} 安排面试...")
            interview = interview_map.get(cand.get("id"), {})

            schedule = await self._generate_schedule(role, cand, interview, pipeline_id)
            schedules.append(schedule)

        await self._progress(f"已生成 {len(schedules)} 份面试安排")

        return ToolOutput(
            status=AgentStatus.SUCCESS,
            data={"schedules": schedules, "total": len(schedules), "status": "completed"},
        )

    async def _generate_schedule(self, role: str, cand: dict, interview: dict, pipeline_id: str) -> dict:
        """为单个候选人生成面试安排"""
        questions = interview.get("questions", [])
        strategy = interview.get("interview_strategy", "")
        time_alloc = interview.get("time_allocation", {})

        # 计算预估面试时长
        total_minutes = 0
        for duration in time_alloc.values():
            if isinstance(duration, str):
                try:
                    total_minutes += int(duration.replace("分钟", "").replace("min", ""))
                except ValueError:
                    total_minutes += 15
            elif isinstance(duration, (int, float)):
                total_minutes += int(duration)
        if total_minutes == 0:
            total_minutes = 60

        # 生成面试时间建议（未来3天的下午时段）
        now = datetime.now()
        slots = []
        for day_offset in range(1, 4):
            slot_date = now + timedelta(days=day_offset)
            for hour in [14, 15, 16]:
                slot_time = slot_date.replace(hour=hour, minute=0, second=0)
                slots.append(
                    {
                        "datetime": slot_time.strftime("%Y-%m-%d %H:%M"),
                        "display": slot_time.strftime("%m月%d日 %H:%M"),
                        "weekday": ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][slot_time.weekday()],
                    }
                )

        # 生成面试邀请文本
        system = """你是一个专业的HR面试协调员，负责撰写清晰、友好的面试邀请。

要求：
1. 简洁明了，包含岗位、时间、面试形式
2. 给出2-3个可选时间段
3. 说明面试准备事项
4. 语气专业但友好

输出JSON格式。"""

        questions_summary = ""
        if questions:
            q_types = [q.get("type", "") for q in questions[:3]]
            questions_summary = f"\n面试环节：{'、'.join(q_types)}"
            if time_alloc:
                time_parts = [f"{k} {v}" for k, v in time_alloc.items()]
                questions_summary += f"\n时间分配：{', '.join(time_parts)}"

        prompt = f"""岗位：{role}
候选人：{cand["name"]}
面试预估时长：{total_minutes}分钟{questions_summary}
面试策略：{strategy}

可选时间段：
{chr(10).join(f"- {s['display']}({s['weekday']})" for s in slots[:6])}

请生成面试邀请：
{{
    "invitation_text": "面试邀请正文（150字以内，HR可直接发送）",
    "duration_minutes": {total_minutes},
    "preparation_tips": ["候选人需要准备的事项1", "事项2"],
    "interview_format": "线上视频/线下到场/电话",
    "recommended_slot": "推荐的首选时间"
}}"""
        result = await self.call_llm_json(prompt, system, complexity="flash")
        if not isinstance(result, dict):
            result = {}

        invitation = result.get(
            "invitation_text",
            f"您好 {cand['name']}，邀请您参加{role}的面试，预计{total_minutes}分钟。请选择方便的时间。",
        )

        # 记录安排事件
        save_outreach_event(
            pipeline_id=pipeline_id,
            candidate_id=cand.get("id", ""),
            candidate_name=cand.get("name", ""),
            event_type="interview_schedule",
            content=invitation,
        )

        return {
            "candidate_id": cand.get("id", ""),
            "candidate_name": cand.get("name", ""),
            "available_slots": slots,
            "invitation_text": invitation,
            "duration_minutes": total_minutes,
            "preparation_tips": result.get("preparation_tips", []),
            "interview_format": result.get("interview_format", "线上视频"),
            "questions_summary": [
                {"type": q.get("type", ""), "topic": q.get("question", "")[:50]} for q in questions[:5]
            ],
            "interview_strategy": strategy,
            "time_allocation": time_alloc,
        }
