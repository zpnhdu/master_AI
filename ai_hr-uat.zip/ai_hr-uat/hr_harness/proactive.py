"""主动推进引擎 - Pipeline健康巡检（参考 Moka Eva 主动推进模式）

功能：
1. 检测卡住的pipeline（长时间无进展）
2. 检测面试反馈超时
3. 检测高匹配候选人未被联系
4. 生成行动建议
"""

from datetime import datetime
from typing import Any

from app.db import get_db

# 超时阈值（小时）
STUCK_PIPELINE_HOURS = 48
STALE_CANDIDATE_HOURS = 72
FEEDBACK_TIMEOUT_HOURS = 24


def check_pipeline_health(pipeline_id: str = "") -> dict[str, Any]:
    """检查pipeline健康状态，返回需要关注的项"""
    conn = get_db()
    alerts = []
    now = datetime.now()

    # 1. 卡住的pipeline
    stuck = _check_stuck_pipelines(conn, now, pipeline_id)
    alerts.extend(stuck)

    # 2. 高匹配未联系
    unreached = _check_unreached_candidates(conn, now, pipeline_id)
    alerts.extend(unreached)

    # 3. 面试反馈超时
    feedback = _check_feedback_timeout(conn, now, pipeline_id)
    alerts.extend(feedback)

    # 4. Pipeline统计
    stats = _get_quick_stats(conn, pipeline_id)

    return {
        "alerts": alerts,
        "alert_count": len(alerts),
        "stats": stats,
        "checked_at": now.strftime("%Y-%m-%d %H:%M"),
    }


def _check_stuck_pipelines(conn, now: datetime, pipeline_id: str = "") -> list[dict]:
    """检测长时间无进展的pipeline"""
    alerts = []
    sql = """
        SELECT p.id, p.role, p.status, p.updated_at, ps.stage_id, ps.stage_name
        FROM pipelines p
        LEFT JOIN pipeline_stages ps ON p.id = ps.pipeline_id
        WHERE p.status IN ('running', 'waiting_for_resumes', 'waiting_for_videos')
    """
    params: list = []
    if pipeline_id:
        sql += " AND p.id = ?"
        params.append(pipeline_id)

    sql += " ORDER BY p.updated_at"
    rows = conn.execute(sql, params).fetchall()

    seen = set()
    for row in rows:
        pid = row["id"]
        if pid in seen:
            continue
        seen.add(pid)

        try:
            updated = datetime.strptime(row["updated_at"], "%Y-%m-%d %H:%M:%S")
            hours_idle = (now - updated).total_seconds() / 3600
        except (ValueError, TypeError):
            hours_idle = 0

        if hours_idle > STUCK_PIPELINE_HOURS:
            alerts.append(
                {
                    "type": "stuck_pipeline",
                    "severity": "warning",
                    "pipeline_id": pid,
                    "role": row["role"],
                    "hours_idle": round(hours_idle, 1),
                    "current_stage": row["stage_name"] or "未知",
                    "message": f"岗位「{row['role']}」已在{row['stage_name'] or '某'}阶段停滞 {int(hours_idle)} 小时",
                    "action": "review_pipeline",
                }
            )

    return alerts


def _check_unreached_candidates(conn, now: datetime, pipeline_id: str = "") -> list[dict]:
    """检测高匹配但未被联系的候选人"""
    alerts = []
    sql = """
        SELECT c.id, c.name, c.overall_score, c.status, c.pipeline_id, p.role
        FROM candidates c
        JOIN pipelines p ON c.pipeline_id = p.id
        WHERE c.overall_score >= 80 AND c.status = 'matched'
    """
    params: list = []
    if pipeline_id:
        sql += " AND c.pipeline_id = ?"
        params.append(pipeline_id)

    sql += " ORDER BY c.overall_score DESC"
    rows = conn.execute(sql, params).fetchall()

    for row in rows:
        # 检查是否已有触达记录
        outreach = conn.execute(
            "SELECT COUNT(*) as c FROM outreach_events WHERE candidate_id = ?", (row["id"],)
        ).fetchone()["c"]

        if outreach == 0:
            alerts.append(
                {
                    "type": "unreached_talent",
                    "severity": "info",
                    "pipeline_id": row["pipeline_id"],
                    "candidate_id": row["id"],
                    "candidate_name": row["name"],
                    "score": row["overall_score"],
                    "role": row["role"],
                    "message": f"高分候选人「{row['name']}」（{row['overall_score']}分）尚未被联系",
                    "action": "outreach_candidate",
                }
            )

    return alerts


def _check_feedback_timeout(conn, now: datetime, pipeline_id: str = "") -> list[dict]:
    """检测面试完成但反馈超时"""
    alerts = []
    sql = """
        SELECT c.id, c.name, c.status, c.pipeline_id, p.role,
               ps.completed_at as interview_done_at
        FROM candidates c
        JOIN pipelines p ON c.pipeline_id = p.id
        JOIN pipeline_stages ps ON c.pipeline_id = ps.pipeline_id
            AND ps.stage_id = 'interview_gen' AND ps.status = 'done'
        WHERE c.status IN ('matched', 'interviewed')
    """
    params: list = []
    if pipeline_id:
        sql += " AND c.pipeline_id = ?"
        params.append(pipeline_id)

    rows = conn.execute(sql, params).fetchall()

    for row in rows:
        if not row["interview_done_at"]:
            continue
        try:
            done_at = datetime.strptime(row["interview_done_at"], "%Y-%m-%d %H:%M:%S")
            hours_since = (now - done_at).total_seconds() / 3600
        except (ValueError, TypeError):
            continue

        if hours_since > FEEDBACK_TIMEOUT_HOURS and row["status"] != "shortlisted":
            # 检查是否已有评估
            video = conn.execute("SELECT video_assessment FROM candidates WHERE id = ?", (row["id"],)).fetchone()
            has_assessment = False
            if video and video["video_assessment"]:
                try:
                    import json

                    assessment = json.loads(video["video_assessment"])
                    has_assessment = bool(assessment.get("dimensions"))
                except (json.JSONDecodeError, TypeError, AttributeError):
                    pass

            if not has_assessment:
                alerts.append(
                    {
                        "type": "feedback_timeout",
                        "severity": "warning",
                        "pipeline_id": row["pipeline_id"],
                        "candidate_id": row["id"],
                        "candidate_name": row["name"],
                        "role": row["role"],
                        "hours_since_interview": round(hours_since, 1),
                        "message": f"候选人「{row['name']}」面试已完成 {int(hours_since)} 小时，尚未收到评估反馈",
                        "action": "request_feedback",
                    }
                )

    return alerts


def _get_quick_stats(conn, pipeline_id: str = "") -> dict:
    """快速统计"""
    pid_filter = ""
    params: list = []
    if pipeline_id:
        pid_filter = "WHERE pipeline_id = ?"
        params = [pipeline_id]

    total = conn.execute(f"SELECT COUNT(*) as c FROM candidates {pid_filter}", params).fetchone()["c"]

    shortlisted = conn.execute(
        f"SELECT COUNT(*) as c FROM candidates {pid_filter} {'AND' if pid_filter else 'WHERE'} status='shortlisted'",
        params,
    ).fetchone()["c"]

    avg_score = (
        conn.execute(
            f"SELECT AVG(overall_score) as avg FROM candidates {pid_filter} {'AND' if pid_filter else 'WHERE'} overall_score > 0",
            params,
        ).fetchone()["avg"]
        or 0
    )

    return {
        "total_candidates": total,
        "shortlisted": shortlisted,
        "avg_score": round(avg_score, 1),
    }
