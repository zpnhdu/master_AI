"""规则来源追溯"""

from app.db import get_memory_rules
from typing import Optional


class Trace:
    """ARON学习规则追溯 - 每条规则可追溯来源"""

    @staticmethod
    def trace_rule(memory_id: str) -> Optional[dict]:
        """追溯单条规则的完整来源链"""
        rules = get_memory_rules()
        target = None
        for r in rules:
            if r["id"] == memory_id:
                target = r
                break

        if not target:
            return None

        content = target.get("content", {})
        if isinstance(content, str):
            import json

            try:
                content = json.loads(content)
            except:
                content = {}

        return {
            "id": target["id"],
            "ontology_node": target.get("ontology_node_id", ""),
            "rule_type": target.get("rule_type", ""),
            "source": target.get("source", ""),
            "source_detail": target.get("source_detail", ""),
            "content": content,
            "confidence": target.get("confidence", 0),
            "usage_count": target.get("usage_count", 0),
            "growth_stage": target.get("growth_stage", "short"),
            "is_active": bool(target.get("is_active", 1)),
            "created_at": target.get("created_at", ""),
            "updated_at": target.get("updated_at", ""),
            "trace_chain": Trace._build_chain(target),
        }

    @staticmethod
    def _build_chain(rule: dict) -> list[dict]:
        """构建来源链：从原始操作到当前规则"""
        chain = []
        source = rule.get("source", "")
        detail = rule.get("source_detail", "")

        chain.append(
            {
                "step": 1,
                "event": f"HR操作: {source}",
                "detail": detail,
                "timestamp": rule.get("created_at", ""),
            }
        )

        if rule.get("usage_count", 0) > 1:
            chain.append(
                {
                    "step": 2,
                    "event": f"重复学习 {rule['usage_count']} 次",
                    "detail": f"置信度提升至 {rule.get('confidence', 0):.0%}",
                    "timestamp": rule.get("updated_at", ""),
                }
            )

        stage = rule.get("growth_stage", "short")
        if stage in ("mid", "long"):
            chain.append(
                {
                    "step": 3,
                    "event": f"成长阶段升级: {stage}",
                    "detail": "mid" and "已聚合为岗位专属规则" or "已沉淀为人才画像",
                    "timestamp": rule.get("updated_at", ""),
                }
            )

        return chain

    @staticmethod
    def trace_by_source(pipeline_id: str = "", source: str = "") -> list[dict]:
        """按来源类型追溯所有规则"""
        rules = get_memory_rules(pipeline_id=pipeline_id)
        result = []
        for r in rules:
            if source and r.get("source", "") != source:
                continue
            result.append(
                {
                    "id": r["id"],
                    "source": r.get("source", ""),
                    "source_detail": r.get("source_detail", ""),
                    "ontology_node": r.get("ontology_node_id", ""),
                    "confidence": r.get("confidence", 0),
                    "growth_stage": r.get("growth_stage", "short"),
                    "is_active": bool(r.get("is_active", 1)),
                }
            )
        return result
