"""歧视维度屏蔽 + 合规检查"""

from typing import Optional

# 禁止用于评分/筛选的歧视维度
DISCRIMINATION_FIELDS = {
    "age",
    "年龄",
    "gender",
    "性别",
    "ethnicity",
    "民族",
    "种族",
    "religion",
    "宗教",
    "hometown",
    "籍贯",
    "户籍",
    "marital_status",
    "婚姻状况",
    "pregnancy",
    "怀孕",
    "disability",
    "残疾",
    "political",
    "政治面貌",
    "appearance",
    "外貌",
    "height",
    "身高",
    "weight",
    "体重",
}

# 敏感信息字段（需脱敏）
SENSITIVE_FIELDS = {
    "phone",
    "手机",
    "电话",
    "id_card",
    "身份证",
    "address",
    "地址",
    "住址",
    "email",
    "邮箱",
    "bank_account",
    "银行卡",
}


class Guardrails:
    """ARON合规护栏 - 防止歧视性学习和隐私泄露"""

    @staticmethod
    def check_discrimination(field: str, content: str = "") -> Optional[dict]:
        """检查是否涉及歧视维度"""
        field_lower = field.lower().strip()

        # 直接命中字段名
        if field_lower in DISCRIMINATION_FIELDS:
            return {
                "blocked": True,
                "reason": f"字段「{field}」属于歧视维度，禁止用于评分/筛选",
                "field": field,
            }

        # 检查内容中是否包含歧视性关键词
        content_lower = content.lower() if content else ""
        for df in DISCRIMINATION_FIELDS:
            if df in content_lower and len(df) > 1:
                return {
                    "blocked": True,
                    "reason": f"内容中包含歧视性关键词「{df}」",
                    "field": field,
                    "keyword": df,
                }

        return None

    @staticmethod
    def check_hard_rule_override(field: str, ontology_engine=None) -> Optional[dict]:
        """检查是否试图覆盖本体硬性规则"""
        if not ontology_engine:
            return None

        all_rules = ontology_engine.tree.get_all_rules()
        for rule in all_rules:
            if rule.rule_type == "hard" and rule.field == field and rule.is_active:
                return {
                    "blocked": True,
                    "reason": f"字段「{field}」有硬性规则({rule.id})，学习不可覆盖",
                    "rule_id": rule.id,
                }
        return None

    @staticmethod
    def mask_sensitive(text: str) -> str:
        """脱敏处理"""
        import re

        # 手机号脱敏
        text = re.sub(r"1[3-9]\d{9}", lambda m: m.group()[:3] + "****" + m.group()[7:], text)
        # 身份证脱敏
        text = re.sub(r"\d{17}[\dXx]", lambda m: m.group()[:6] + "********" + m.group()[14:], text)
        # 邮箱脱敏
        text = re.sub(r"(\w{2})\w+(@\w+)", r"\1***\2", text)
        return text

    @staticmethod
    def validate_learning(field: str, content: str = "", ontology_engine=None) -> dict:
        """完整的学习前校验"""
        # 1. 歧视检查
        disc = Guardrails.check_discrimination(field, content)
        if disc:
            return disc

        # 2. 硬性规则覆盖检查
        hard = Guardrails.check_hard_rule_override(field, ontology_engine)
        if hard:
            return hard

        return {"blocked": False}
