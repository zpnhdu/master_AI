"""分层成长引擎 - 短/中/长期学习阶段管理"""

from app.db import get_memory_rules


class GrowthEngine:
    """ARON分层成长引擎

    短期（1-3次招聘）：JD、简历筛选、面试打分贴合HR个人偏好
    中期（5-10场招聘）：自动生成岗位专属打分权重
    长期（季度级招聘）：沉淀各岗位完整人才画像
    """

    # 阶段阈值
    SHORT_THRESHOLD = 3  # usage_count 不超过 3 时归为短期记忆
    MID_THRESHOLD = 10  # usage_count 不超过 10 时归为中期记忆
    # 大于 10 次时归为长期记忆

    @staticmethod
    def compute_stage(usage_count: int) -> str:
        """根据使用次数计算成长阶段"""
        if usage_count <= GrowthEngine.SHORT_THRESHOLD:
            return "short"
        elif usage_count <= GrowthEngine.MID_THRESHOLD:
            return "mid"
        else:
            return "long"

    @staticmethod
    def promote_if_needed(memory_id: str, current_stage: str, usage_count: int) -> str:
        """检查是否需要升级阶段，返回新阶段"""
        new_stage = GrowthEngine.compute_stage(usage_count)
        if new_stage != current_stage:
            # 阶段升级时提升置信度
            return new_stage
        return current_stage

    @staticmethod
    def aggregate_weights(pipeline_id: str, role: str = "") -> dict[str, float]:
        """中期成长：聚合同类规则，生成岗位专属权重

        当同一岗位的评分权重被HR多次调整后，
        自动聚合为新的岗位专属权重。
        """
        rules = get_memory_rules(
            pipeline_id=pipeline_id,
            ontology_node_id="evaluation",
            is_active=True,
        )

        if not rules:
            return {}

        # 找到所有权重调整记录
        weight_records = []
        for r in rules:
            content = r.get("content", {})
            if isinstance(content, str):
                import json

                try:
                    content = json.loads(content)
                except:
                    continue
            if "weights" in content:
                weight_records.append(
                    {
                        "weights": content["weights"],
                        "confidence": r.get("confidence", 0.5),
                        "usage_count": r.get("usage_count", 0),
                    }
                )

        if not weight_records:
            return {}

        # 加权平均（按置信度和使用次数加权）
        total_weight = 0
        aggregated = {}
        for rec in weight_records:
            w = rec["confidence"] * (1 + rec["usage_count"] * 0.1)
            total_weight += w
            for k, v in rec["weights"].items():
                if k not in aggregated:
                    aggregated[k] = 0
                aggregated[k] += v * w

        if total_weight > 0:
            aggregated = {k: v / total_weight for k, v in aggregated.items()}
            # 归一化
            total = sum(aggregated.values())
            if total > 0:
                aggregated = {k: round(v / total, 3) for k, v in aggregated.items()}

        return aggregated

    @staticmethod
    def build_talent_profile(pipeline_id: str, role: str = "") -> dict:
        """长期成长：沉淀岗位人才画像

        汇总所有高置信度学习规则，生成完整人才画像。
        """
        rules = get_memory_rules(
            pipeline_id=pipeline_id,
            is_active=True,
        )

        profile = {
            "role": role,
            "jd_patterns": [],
            "screening_preferences": [],
            "scoring_weights": {},
            "hiring_patterns": [],
            "total_learnings": len(rules),
        }

        for r in rules:
            content = r.get("content", {})
            if isinstance(content, str):
                import json

                try:
                    content = json.loads(content)
                except:
                    continue

            node_id = r.get("ontology_node_id", "")
            if node_id in ("jd_mgmt", "jd_info"):
                profile["jd_patterns"].append(
                    {
                        "content": content,
                        "confidence": r.get("confidence", 0),
                    }
                )
            elif node_id == "screening":
                profile["screening_preferences"].append(
                    {
                        "content": content,
                        "confidence": r.get("confidence", 0),
                    }
                )
            elif node_id == "evaluation":
                if "weights" in content:
                    profile["scoring_weights"] = content["weights"]
            elif node_id in ("offer_mgmt", "interview"):
                profile["hiring_patterns"].append(
                    {
                        "content": content,
                        "confidence": r.get("confidence", 0),
                    }
                )

        return profile

    @staticmethod
    def get_growth_summary(pipeline_id: str) -> dict:
        """获取成长阶段摘要"""
        from app.db import get_memory_stats

        stats = get_memory_stats(pipeline_id)

        stages = stats.get("by_stage", {})
        total = stats.get("total", 0)

        if total == 0:
            current_stage = "none"
            desc = "尚未开始学习"
        elif stages.get("long", 0) > 0:
            current_stage = "long"
            desc = "已沉淀完整人才画像，统一团队招聘标准"
        elif stages.get("mid", 0) > 0:
            current_stage = "mid"
            desc = "已生成岗位专属打分权重，筛选精准度提升"
        else:
            current_stage = "short"
            desc = "正在学习HR个人偏好，减少人工修正"

        return {
            "current_stage": current_stage,
            "description": desc,
            "stats": stats,
        }
