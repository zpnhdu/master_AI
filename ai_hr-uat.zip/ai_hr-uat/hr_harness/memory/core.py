"""AI HR记忆系统核心 - 整合本体引擎 + 成长引擎 + 合规护栏"""

import hashlib
import json
import uuid
from typing import Any

from app.db import (
    get_learnings,
    get_memory_rules,
    get_preferences,
    reset_memory_rules,
    save_learning,
    save_memory_rule,
    save_preference,
    toggle_memory_rule,
)
from hr_harness.memory.growth import GrowthEngine
from hr_harness.memory.guardrails import Guardrails


class MemorySystem:
    """AI HR记忆系统 - 持续学习HR偏好，绑定本体节点"""

    def __init__(self, pipeline_id: str = "", actor_user_id: str = ""):
        self.pipeline_id = pipeline_id
        self.actor_user_id = actor_user_id
        self.preferences = get_preferences()
        self.guardrails = Guardrails()
        self.growth = GrowthEngine()
        self._refresh_learnings()

    def _refresh_learnings(self):
        """Refresh learnings from DB, scoped to current pipeline"""
        pid = self.pipeline_id if self.pipeline_id else None
        self.jd_patterns = get_learnings("jd_pattern", pipeline_id=pid)
        self.match_weights = get_learnings("match_weight", pipeline_id=pid)
        self.interview_patterns = get_learnings("interview_pattern", pipeline_id=pid)
        self.hiring_patterns = get_learnings("hiring_pattern", pipeline_id=pid)
        self.feedback_log = get_learnings("feedback", pipeline_id=pid)
        # 新版记忆规则
        self.memory_rules = get_memory_rules(
            pipeline_id=self.pipeline_id, is_active=True, actor_user_id=self.actor_user_id
        )

    # ============ 新版学习接口（绑定本体节点） ============

    def learn_from_jd_edit(self, role: str, field: str, change: Any, jd_changes: dict = None):
        """从JD编辑中学习 - 绑定本体 jd_mgmt/jd_info 节点"""
        # 合规检查
        check = self.guardrails.validate_learning(field, str(change))
        if check.get("blocked"):
            print(f"[Memory] Blocked: {check['reason']}")
            return {"blocked": True, "reason": check["reason"]}

        memory_id = f"jd_{role}_{field}_{uuid.uuid4().hex[:6]}"
        content = {"field": field, "change": change, "role": role}

        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id="jd_info",
            rule_type="preference",
            content=content,
            source="jd_edit",
            source_detail=f"HR修改JD字段{field}: {change}",
            confidence=0.6,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
        )

        # 兼容旧版
        if jd_changes:
            for f, c in jd_changes.items():
                save_learning(
                    "jd_pattern", f"{role}_{f}", f"HR修改了{f}: {c}", confidence=0.6, pipeline_id=self.pipeline_id
                )
        save_learning("feedback", f"jd_{role}", f"jd_edit:{field}", confidence=0.7, pipeline_id=self.pipeline_id)
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id}

    def learn_from_candidate_action(
        self, candidate_id: str, candidate_name: str, action: str, reason: str = "", scores: dict = None
    ):
        """从候选人操作中学习 - 绑定本体 screening/evaluation 节点"""
        # 合规检查
        check = self.guardrails.validate_learning("candidate_action", reason)
        if check.get("blocked"):
            return {"blocked": True, "reason": check["reason"]}

        memory_id = f"cand_{action}_{candidate_id}_{uuid.uuid4().hex[:6]}"
        content = {
            "candidate_id": candidate_id,
            "candidate_name": candidate_name,
            "action": action,
            "reason": reason,
        }
        if scores:
            content["scores"] = scores

        # 确定本体节点
        node_id = "screening" if action in ("shortlist", "reject") else "evaluation"

        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id=node_id,
            rule_type="pattern",
            content=content,
            source="candidate_action",
            source_detail=f"HR对{candidate_name}执行{action}: {reason}",
            confidence=0.7,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
        )

        # 如果是入围/淘汰，学习筛选阈值
        if action == "shortlist" and scores:
            overall = scores.get("overall_score", 0)
            if overall > 0:
                save_memory_rule(
                    memory_id=f"threshold_shortlist_{self.pipeline_id}",
                    ontology_node_id="screening",
                    rule_type="weight",
                    content={"threshold": "shortlist_min", "value": overall},
                    source="candidate_action",
                    source_detail=f"入围候选人{candidate_name}综合分{overall}",
                    confidence=0.5,
                    growth_stage="short",
                    pipeline_id=self.pipeline_id,
                )

        # 兼容旧版
        save_learning(
            "hiring_pattern",
            f"decision_{candidate_name}",
            f"{action}: {reason}",
            confidence=0.7,
            pipeline_id=self.pipeline_id,
        )
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id}

    def learn_from_score_override(self, candidate_id: str, candidate_name: str, old_scores: dict, new_scores: dict):
        """从分数修正中学习 - 绑定本体 evaluation 节点"""
        memory_id = f"score_{candidate_id}_{uuid.uuid4().hex[:6]}"

        # 计算差异
        diffs = {}
        for k in new_scores:
            if k in old_scores and new_scores[k] != old_scores[k]:
                diffs[k] = {"old": old_scores[k], "new": new_scores[k]}

        content = {
            "candidate_id": candidate_id,
            "candidate_name": candidate_name,
            "diffs": diffs,
            "new_scores": new_scores,
        }

        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id="evaluation",
            rule_type="weight",
            content=content,
            source="score_override",
            source_detail=f"HR修正{candidate_name}评分",
            confidence=0.8,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
        )

        # 兼容旧版
        save_learning(
            "feedback",
            f"score_override_{candidate_id}",
            json.dumps(new_scores, ensure_ascii=False),
            pipeline_id=self.pipeline_id,
        )
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id, "diffs": diffs}

    def learn_from_chat(self, preference_type: str, content: str, source_detail: str = ""):
        """从聊天对话中学习HR偏好 - 如'我想要更多图表'、'评分标准太松了'等"""
        memory_id = f"chat_{preference_type}_{uuid.uuid4().hex[:6]}"

        # 合规检查
        check = self.guardrails.validate_learning(preference_type, content)
        if check.get("blocked"):
            return {"blocked": True, "reason": check["reason"]}

        # 映射到本体节点
        node_map = {
            "visualization": "evaluation",
            "scoring": "evaluation",
            "screening": "screening",
            "communication": "interview_mgmt",
            "workflow": "recruitment_mgmt",
            "general": "recruitment_mgmt",
        }
        node_id = node_map.get(preference_type, "recruitment_mgmt")

        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id=node_id,
            rule_type="preference",
            content={"type": preference_type, "preference": content},
            source="chat_learning",
            source_detail=source_detail or f"HR在对话中表达偏好: {content}",
            confidence=0.5,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
        )

        # 同时存为全局偏好
        save_preference(f"chat_{preference_type}", content, "chat")
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id, "node": node_id}

    def learn_from_interview_question_edit(
        self,
        role: str,
        operation: str,
        before: dict | None = None,
        after: dict | None = None,
        actor_user_id: str = "",
    ) -> dict:
        """Learn a reusable interview-design preference from an HR question edit."""
        before = dict(before or {})
        after = dict(after or {})
        competency = str(
            after.get("competency_ref")
            or after.get("dimension")
            or before.get("competency_ref")
            or before.get("dimension")
            or after.get("type")
            or before.get("type")
            or "general"
        ).strip()
        detail = f"{operation}: {before.get('question', '')} -> {after.get('question', '')}"
        check = self.guardrails.validate_learning("interview_question", detail)
        if check.get("blocked"):
            return {"blocked": True, "reason": check["reason"]}

        learner = actor_user_id or self.actor_user_id or "legacy"
        identity = f"{learner}|{role.strip().lower()}|{operation}|{competency.lower()}"
        memory_id = f"interview_question_{hashlib.sha256(identity.encode('utf-8')).hexdigest()[:16]}"
        content = {
            "role": role,
            "operation": operation,
            "competency": competency,
            "before": before,
            "after": after,
        }
        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id="interview_mgmt",
            rule_type="pattern",
            content=content,
            source="interview_question_edit",
            source_detail=detail[:190],
            confidence=0.6,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
            actor_user_id=actor_user_id or self.actor_user_id,
        )
        save_learning(
            "interview_pattern",
            identity,
            json.dumps(content, ensure_ascii=False),
            confidence=0.6,
            pipeline_id=self.pipeline_id,
        )
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id}

    def learn_from_interview_score_override(
        self,
        role: str,
        modality: str,
        old_score: float | None,
        new_score: float,
        reason: str,
        actor_user_id: str = "",
    ) -> dict:
        """Learn how HR calibrates an interview score and why."""
        check = self.guardrails.validate_learning("interview_scoring", reason)
        if check.get("blocked"):
            return {"blocked": True, "reason": check["reason"]}

        direction = "increase" if old_score is not None and new_score > old_score else "decrease"
        if old_score is None or new_score == old_score:
            direction = "set"
        learner = actor_user_id or self.actor_user_id or "legacy"
        identity = f"{learner}|{role.strip().lower()}|{modality}|{direction}"
        memory_id = f"interview_score_{hashlib.sha256(identity.encode('utf-8')).hexdigest()[:16]}"
        content = {
            "role": role,
            "modality": modality,
            "old_score": old_score,
            "new_score": new_score,
            "direction": direction,
            "reason": reason,
        }
        save_memory_rule(
            memory_id=memory_id,
            ontology_node_id="interview_mgmt",
            rule_type="weight",
            content=content,
            source="interview_score_override",
            source_detail=f"HR adjusted {modality} score from {old_score} to {new_score}: {reason}"[:190],
            confidence=0.7,
            growth_stage="short",
            pipeline_id=self.pipeline_id,
            actor_user_id=actor_user_id or self.actor_user_id,
        )
        save_learning(
            "interview_pattern",
            identity,
            json.dumps(content, ensure_ascii=False),
            confidence=0.7,
            pipeline_id=self.pipeline_id,
        )
        self._refresh_learnings()
        return {"learned": True, "memory_id": memory_id}

    # ============ 查询接口 ============

    def get_jd_context(self, role: str) -> str:
        """Get learned JD patterns for this role type"""
        context_parts = []
        role_key = role.replace(" ", "_").lower()

        for p in self.jd_patterns:
            if role_key in p["key"].lower() or "通用" in p["key"]:
                context_parts.append(
                    f"- 历史经验: {p['value']} (置信度:{p['confidence']:.0%}, 使用{p['usage_count']}次)"
                )

        # 新版记忆规则
        for r in self.memory_rules:
            if r.get("ontology_node_id") in ("jd_mgmt", "jd_info"):
                content = r.get("content", {})
                if isinstance(content, str):
                    try:
                        content = json.loads(content)
                    except:
                        continue
                if content.get("role", "").lower() == role_key or not content.get("role"):
                    context_parts.append(
                        f"- 学习规则: {r.get('source_detail', '')} (置信度:{r.get('confidence', 0):.0%})"
                    )

        for key, val in self.preferences.items():
            if "jd" in key.lower() or "招聘" in key.lower():
                context_parts.append(f"- HR偏好: {val}")

        return "\n".join(context_parts) if context_parts else ""

    def get_match_context(self) -> str:
        """Get learned matching weights"""
        context_parts = []
        for w in self.match_weights:
            context_parts.append(f"- {w['key']}: {w['value']} (置信度:{w['confidence']:.0%})")

        # 新版：聚合权重
        agg = self.growth.aggregate_weights(self.pipeline_id)
        if agg:
            parts = [f"{k}={int(v * 100)}%" for k, v in agg.items()]
            context_parts.append(f"- 学习到的评分权重: {', '.join(parts)}")

        return "\n".join(context_parts) if context_parts else ""

    def get_interview_context(self, role: str) -> str:
        """Return active, role-relevant question and score preferences for Xiao Mian."""
        if not self.actor_user_id:
            return ""
        role_key = role.strip().lower()
        context_parts = []
        # Interview preferences are reusable across completed pipelines. Keep
        # pipeline-local rules first, then include active rules learned from
        # earlier pipelines for the same role. Global rules (pipeline_id="")
        # remain available to every role.
        scoped_rules = get_memory_rules(
            pipeline_id=self.pipeline_id,
            ontology_node_id="interview_mgmt",
            is_active=True,
            actor_user_id=self.actor_user_id,
        )
        historical_rules = get_memory_rules(
            ontology_node_id="interview_mgmt",
            is_active=True,
            actor_user_id=self.actor_user_id,
        )
        seen_ids = set()
        rules = []
        for rule in [*scoped_rules, *historical_rules]:
            rule_id = str(rule.get("id") or "")
            if rule_id and rule_id in seen_ids:
                continue
            if rule_id:
                seen_ids.add(rule_id)
            rules.append(rule)
        for rule in rules:
            content = rule.get("content") or {}
            if not isinstance(content, dict):
                continue
            learned_role = str(content.get("role") or "").strip().lower()
            if learned_role and role_key and learned_role not in role_key and role_key not in learned_role:
                continue
            confidence = float(rule.get("confidence") or 0)
            if rule.get("source") == "interview_question_edit":
                operation = content.get("operation", "update")
                competency = content.get("competency", "general")
                after = content.get("after") or {}
                before = content.get("before") or {}
                if operation == "delete":
                    summary = f"avoid questions like: {before.get('question', '')}"
                elif operation == "add":
                    summary = f"prefer questions like: {after.get('question', '')}"
                else:
                    summary = (
                        f"for {competency}, prefer '{after.get('question', '')}' "
                        f"over '{before.get('question', '')}'"
                    )
                context_parts.append(f"- Question preference ({confidence:.0%}): {summary}")
            elif rule.get("source") == "interview_score_override":
                context_parts.append(
                    f"- Scoring preference ({confidence:.0%}): for {content.get('modality', 'interview')}, "
                    f"HR changed {content.get('old_score')} to {content.get('new_score')} because "
                    f"{content.get('reason', '')}"
                )
            if len(context_parts) >= 8:
                break
        return "\n".join(context_parts)

    def get_growth_summary(self) -> dict:
        """获取成长阶段摘要"""
        return self.growth.get_growth_summary(self.pipeline_id)

    # ============ 控制接口 ============

    def toggle_rule(self, memory_id: str, is_active: bool) -> dict:
        """开关单条学习规则"""
        toggle_memory_rule(memory_id, is_active)
        self._refresh_learnings()
        return {"status": "toggled", "memory_id": memory_id, "is_active": is_active}

    def reset(self, scope: str = "pipeline") -> dict:
        """重置学习数据"""
        count = reset_memory_rules(self.pipeline_id, scope)
        self._refresh_learnings()
        return {"status": "reset", "deleted_count": count, "scope": scope}

    # ============ 兼容旧版接口 ============

    def record_jd_feedback(self, role: str, feedback: str, jd_changes: dict = None):
        """Learn from JD edits (backward compatible)"""
        self.learn_from_jd_edit(role, "manual_edit", feedback, jd_changes)

    def record_match_feedback(self, candidate_name: str, action: str, reason: str = ""):
        """Learn from candidate selection decisions (backward compatible)"""
        self.learn_from_candidate_action("", candidate_name, action, reason)

    def record_hiring_decision(self, candidate_name: str, decision: str, salary: str = "", notes: str = ""):
        """Learn from final hiring decisions (backward compatible)"""
        save_learning(
            "hiring_pattern",
            f"final_{candidate_name}",
            json.dumps({"decision": decision, "salary": salary, "notes": notes}, ensure_ascii=False),
            confidence=0.9,
            pipeline_id=self.pipeline_id,
        )
        self._refresh_learnings()

    def update_preference(self, key: str, value: str, source: str = "user"):
        """Update HR preference (global)"""
        save_preference(key, value, source)
        self.preferences = get_preferences()

    def get_optimization_summary(self) -> dict:
        """Get summary of what AI HR has learned"""
        self._refresh_learnings()
        growth = self.get_growth_summary()
        return {
            "jd_patterns_learned": len(self.jd_patterns),
            "match_weights_learned": len(self.match_weights),
            "hiring_patterns_learned": len(self.hiring_patterns),
            "feedback_received": len(self.feedback_log),
            "preferences_set": len(self.preferences),
            "memory_rules": len(self.memory_rules),
            "growth_stage": growth.get("current_stage", "none"),
            "growth_description": growth.get("description", ""),
            "top_learnings": [
                {"category": l["category"], "key": l["key"], "value": l["value"], "confidence": l["confidence"]}
                for l in sorted(
                    self.jd_patterns + self.match_weights + self.hiring_patterns,
                    key=lambda x: x["confidence"],
                    reverse=True,
                )[:5]
            ],
        }

    def build_system_context(self) -> str:
        """Build context string for LLM calls"""
        parts = ["【AI HR记忆系统】"]

        if self.preferences:
            parts.append("HR偏好:")
            for k, v in list(self.preferences.items())[:5]:
                parts.append(f"  - {k}: {v}")

        high_conf = [l for l in self.jd_patterns + self.match_weights + self.hiring_patterns if l["confidence"] >= 0.7]
        if high_conf:
            parts.append("高置信度经验:")
            for l in high_conf[:3]:
                parts.append(f"  - [{l['category']}] {l['value']}")

        # 成长阶段
        growth = self.get_growth_summary()
        if growth.get("current_stage") != "none":
            parts.append(f"成长阶段: {growth['description']}")

        return "\n".join(parts) if len(parts) > 1 else ""
