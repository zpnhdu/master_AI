module.exports = {
  extends: ["@commitlint/config-conventional"],
  rules: {
    "type-enum": [2, "always", ["feat", "fix", "docs", "style", "refactor", "perf", "test", "chore"]],
    "scope-enum": [1, "always", ["pipeline", "interview", "agent", "kg", "frontend", "api", "feishu", "rpa", "infra"]],
    "subject-empty": [2, "never"],
    "subject-max-length": [2, "always", 72],
  },
};
